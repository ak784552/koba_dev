static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testgwnsl.c libakx.a -o testgwnsl
*/
#include "akxcommon.h"
main()
{
	static char *sep=" \t,;()[]{}/<>='\"!^*+-";
	char buf[256],wd[256];
	int n,opt;
	SSPL_S sspl;

	printf("Enter MAXCHECK(<=256)==>");
	gets(buf);
	sspl.wdmax=atoi(buf);
	printf("Enter OPT==>");
	gets(buf);
	opt=atoi(buf);
	sspl.wd = wd;
	for (;;) {
		printf("Enter==>");
		gets(buf);
		sspl.sp = 0;
		*wd = '\0';
		while((n=akxtgwnsl(buf, strlen(buf), &sspl, sep, opt))>=0 &&
		      sspl.attr[0]) {
			printf("pos=%d n=%d wd=[%s] attr=%08x\n",sspl.sp,n,wd,*(int *)sspl.attr);
			*wd = '\0';
		}
	}
}
