static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_comma.c libakx_no_iconv.a -o test_comma
*/
#include "akxcommon.h"
int main()
{
	char buf[16],wd[128];
	int len;

	for (;;) {
		printf("Enter number ==>");
		gets(wd);
		len = strlen(wd);
		if (!len) break;
		len = akxtncomma2(buf,sizeof(buf),wd,len);
		*(buf+len) = '\0';
		printf("len=%d buf=[%s]\n",len,buf);
	}
}
