static char sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �t�H�[�}�b�g�f�[�^�t�B���h�t���[����������             *
*                                                                             *
*      �֐����@�@�@�F�@int cl_rp_frm_nfrm_gen( pGNCB , pBuff , len )          *
*                                                                             *
*      ������      �F�@(I) GrpNodeCB   *pGNCB                                 *
*                    �@(I) char        *pBuff                                 *
*                    �@(I) int         *len                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
static int fmconv();

int cl_rp_frm_nfrm_gen(pLeaf)
Leaf  *pLeaf;
{
	int rc;
	int i ;
	int point;
	char   wBuff[6];
	cmdInfo   *pwcmd;
	tdtINFO_PARM  *pInfoParm;
	prmList    prm_list;
	ScrPrCT    *pScCT;
	tdtINFO_PARM  InfoParm;
	MCAT       *mcat;
	char *p;
	int  len;

	if (!pLeaf) return( ERROR );
	pwcmd = &(pLeaf->cmd);

	if ( pwcmd->prmnum != 2 ) {
		ERROROUT("Parameter number != 1!! (FM form_data)");
		return ECL_EX_OUTPUT;
	}

	if (!(pScCT = cl_search_src_ct())) return (ERROR);
	if (rc= cl_gx_get_info_parm(pScCT,'r',pwcmd->prmp[1],&pInfoParm)) return( rc );
	if (pInfoParm->pi_attr != DEF_ZOK_BULK) {
		ERROROUT(FORMAT(117));
		return( ECL_SCRIPT_ERROR );
	}

	if (rc=cl_make_list_pbody()) return rc;
	mcat = &pCLprocTable->ListPBody->mCat;
	if ((rc=axtmcats(mcat, "FM"))<0) return rc;
	if (rc=cmpktform(&prm_list,pInfoParm)) return rc;
	p   = prm_list.VarBD;
	len = prm_list.VarLen;
	if (len > 8) {
		if (*(p+6)==0x50 && *(p+7)==0x00) {
			p   += 6;
			len -= 6;
		}
	}
	rc=axtmcat(mcat,p,len);
	Free(prm_list.VarBD);
	if (rc<0) return rc;

    return( NORMAL );
}

/********************************************/
/*											*/
/*	Format conversion OS/2 --> Windows 		*/
/*											*/
/********************************************/
#define	    PRINT(x)	x
#ifdef L_END
#define CL_NTOHL(x) (x)
#define CL_NTOHS(x) (x)
#else
#define CL_NTOHL(x) ((x<<24)&0xff000000 | (x<<8)&0x00ff0000 |\
                  (x>>8)&0x0000ff00 | (x>>24)&0x000000ff)
#define CL_NTOHS(x) ((x<<8)&0xff00 | (x>>8)&0x00ff)
#endif
typedef	unsigned char UCHAR;

typedef struct DHEAD_S {
    UCHAR atr;
    UCHAR len;
    char llen[4];
} dhead_s;

/* Form Header */
static char	id[2];
static long	fmlen;
static unsigned char	form;
static unsigned char	mojiza;
static short	houkou;
static short	wsize;
static short	hsize;
static short	npage;
static short	wchar;
static short	hchar;
static short	nheader;
static short	nfooter;
static short	sotowaku;
static short	umrg;
static short	clrg;
static short	lmrg;
static short	rmrg;

/* Field Data */
static short	fldn;
static long	fldlen;
static short	flag;
static short	actpos;
static short	actlen;
static unsigned char	waku;
static unsigned char	kasen;
static short	fsx;
static short	fsy;
static short	fex;
static short	fey;
static unsigned char	datr;
static unsigned char	io;
static unsigned char	node;
static unsigned char	fldk;

/* Moji Data */
static unsigned char	moji;
static unsigned char	ume;
static unsigned char	kaz;
static unsigned char	msz;
static long	color;
static short	fh;
static short	fw;
static short	tind;
static short	xind;
static short	nm4;

/* 1/4 Data */
static short udpos;
static short udshu;

/* Group Inf. */
static short grpno;
static short tplno;
static short ngrp;
static short ndat;
static short fldno;

static long fmanal();

static FILE *fp,*fp2;
static char dat[4096];
static char wrk[4096];
static char *pfpos;

static MCAT mcat;
static long fmlen1;
static long addlen;
static long addfldlen;
static long posdtlen;
static long posfmlen2;
static long posfldlen;
static long posactlen;

static int fmconv(pmcat,pVarBD,lVarLen)
MCAT *pmcat;
char *pVarBD;
long lVarLen;
{
	char *p, *actp;
	short sw;
	short x_offset=0;
	long lw,len,dtlen;
	int i,j,rc;
	long posfm;
	long posfmlen;

	mcat.mc_extlen = 4096;
	mcat.mc_maxcnt = 0;
	mcat.mc_extcnt = 0;
	mcat.mc_alclen = 0;
	mcat.mc_bufp = NULL;
	mcat.mc_ipos = 0;
	posfmlen = 0;

	p = malloc(4096);
	pfpos = pVarBD + 6;
	lVarLen -= 6;
	len=2;
	memcpy(dat,pfpos,len);
	pfpos += len;
	lVarLen -= len;
	while (len>0) {
		if (posfmlen>0) {
			fmlen1 += addfldlen;
			memcpy(mcat.mc_bufp+posfmlen,(char *)&fmlen1,4);
		}
		if (!memcmp(dat,"FM",2)) {
			posfm=akxtmcat(&mcat,dat,2);
			len=6;
			memcpy(dat,pfpos,len);
			pfpos += len;
			lVarLen -= len;
			if (dat[0]!=0x50) {
				ERROROUT("fmanal : dat error!!");
				return -1;
			}
			memcpy((char *)&fmlen1,dat+2,4);
			ERROROUT1("FM bulk len = %d",fmlen1);
			posfm=akxtmcat(&mcat,dat,6);
			posfmlen = posfm - 4;
			addlen = 0;
		}
		else if (!memcmp(dat,"GR",2)) {
			len=20;
			memcpy(dat+2,pfpos,len);
			pfpos += len;
			lVarLen -= len;
			dat[22]='\0';
			ERROROUT(dat);
			akxtmcat(&mcat,dat,22);
		}
		else if (!memcmp(dat,"DT",2)) {
			len=10;
			memcpy(dat+2,pfpos,len);
			pfpos += len;
			lVarLen -= len;
			dat[12]='\0';
			ERROROUT(dat);
			akxtmcat(&mcat,dat,12);
			len=2;
			memcpy(dat,pfpos,len);
			pfpos += len;
			lVarLen -= len;
			if (*dat==0x50) {
				akxtmcat(&mcat,dat,2);
				len=4;
				memcpy(dat,pfpos,len);
				pfpos += len;
				lVarLen -= len;
				memcpy((char *)&lw,dat,4); dtlen = CL_NTOHL(lw);
				ERROROUT1("DT bulk len = %d",dtlen);
				posfm=akxtmcat(&mcat,dat,4);
				posdtlen = posfm - 4;
				p = realloc(p,dtlen);
				len=dtlen;
				memcpy(p,pfpos,len);
				pfpos += len;
				lVarLen -= len;
				if (!(memcmp(p,"FM",2))) {
					if ((rc=fmanal(p,len))<0) break;
					else if (rc == 100) {
						if (p) Free(p);
						if (mcat.mc_bufp) Free(mcat.mc_bufp);
						return rc;
					}
					else {
						dtlen += addfldlen;
						lw = CL_NTOHL(dtlen);
						memcpy(mcat.mc_bufp+posdtlen,(char *)&lw,4);
						addlen += addfldlen;
					}
				}
			}
			else {
				ERROROUT("fmanal : dat error!!");
				return -1;
			}
		}
		else {
			ERROROUT("fmanal : dat error!!");
			return -1;
		}
		if (lVarLen > 0) {
			len=2;
			memcpy(dat,pfpos,len);
			pfpos += len;
			lVarLen -= len;
		}
		else len = 0;
	}
	if (posfmlen>0) {
		fmlen1 += addfldlen;
		memcpy(mcat.mc_bufp+posfmlen,(char *)&fmlen1,4);
	}
	memcpy(pVarBD+2,(char *)&mcat.mc_ipos,4);
	if ((rc=akxtmcat(pmcat, pVarBD ,6))<0) return rc;
	if ((rc=akxtmcat(pmcat,mcat.mc_bufp,mcat.mc_ipos))<0) return rc;
	if (p) Free(p);
	if (mcat.mc_bufp) Free(mcat.mc_bufp);
	
	return(0);
}

static long fmanal(p,datlen)
char *p;
long datlen;
{
	char *actp, *pw1, *pw2, *pio;
	short sw;
	long lw, len, fmlen, ld;
	int i,j,ix;
	long posfm;

	addfldlen = 0;
	posfm=akxtmcat(&mcat,p,6);
	posfmlen2 = posfm - 4;
	p += 2;
	memcpy((char *)&lw,p,4); p += 4; len = fmlen = CL_NTOHL(lw);
	ERROROUT1("fmlen = %d",fmlen);
	akxtmcat(&mcat,p,28);
	datlen -= (len+6);
	form = *p++; len--;
	mojiza = *p++; len--;
	if (!(mojiza & 0x01)) return 100;
	memcpy((char *)&sw,p,2); p += 2; len -= 2; houkou = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; wsize = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; hsize = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; npage = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; wchar = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; hchar = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; nheader = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; nfooter = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; sotowaku = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; umrg = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; clrg = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; lmrg = CL_NTOHS(sw);
	memcpy((char *)&sw,p,2); p += 2; len -= 2; rmrg = CL_NTOHS(sw);

	while (len>0) {
		memcpy((char *)&sw,p,2); fldn = CL_NTOHS(sw);
		if (fldn<0) break;
		actp = p;
		posfm=axtmcat(&mcat,p,6);
		posfldlen = posfm - 4;
		p += 2;
		memcpy((char *)&lw,p,4); p += 4; fldlen = CL_NTOHL(lw);
		ERROROUT2("pos = %d, fldlen = %d",posfldlen,fldlen);
		posfm=akxtmcat(&mcat,p,4);
		posactlen = posfm - 2;
		memcpy((char *)&sw,p,2); p += 2; flag = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; actpos = CL_NTOHS(sw);
		actp += actpos;
		akxtmcat(&mcat,p,16);
		memcpy((char *)&sw,p,2); p += 2; actlen = CL_NTOHS(sw);
		waku = *p++;
		kasen = *p++;
		memcpy((char *)&sw,p,2); p += 2; fsx = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; fsy = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; fex = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; fey = CL_NTOHS(sw);
		datr = *p++;
		io = *p++;
		node = *p++;
		fldk = *p++;
		if (fldlen>26 && !datr) {
			akxtmcat(&mcat,p,12);
			moji = *p++;
			ume = *p++;
			kaz = *p++;
			msz = *p++;
			memcpy((char *)&lw,p,4); p += 4; color = CL_NTOHL(lw);
			memcpy((char *)&sw,p,2); p += 2; fh = CL_NTOHS(sw);
			memcpy((char *)&sw,p,2); p += 2; fw = CL_NTOHS(sw);
			if (fldlen>38 && p != actp) {
				for (i=0;i<fh;i++) {
					akxtmcat(&mcat,p,6);
					memcpy((char *)&sw,p,2); p += 2; tind = CL_NTOHS(sw);
					memcpy((char *)&sw,p,2); p += 2; xind = CL_NTOHS(sw);
					memcpy((char *)&sw,p,2); p += 2; nm4 = CL_NTOHS(sw);
					akxtmcat(&mcat,p,4*nm4);
					for (j=0;j<nm4;j++) {
						memcpy((char *)&sw,p,2); p += 2; udpos = CL_NTOHS(sw);
						memcpy((char *)&sw,p,2); p += 2; udshu = CL_NTOHS(sw);
					}
				}
			}
			else {
				lw = 6*fh;
				memset(wrk,0,lw);
				akxtmcat(&mcat,wrk,lw);
				addfldlen += lw;
				actpos += lw;
				ld = fldlen + lw;
				lw = CL_NTOHL(ld);
				memcpy(mcat.mc_bufp+posfldlen,(char *)&lw,4);
				sw = CL_NTOHS(actpos);
				memcpy(mcat.mc_bufp+posactlen,(char *)&sw,2);
				ERROROUT2("add pos = %d, fldlen = %d",posfldlen,ld);
			}
		}
		if (actlen>0) {
			akxtmcat(&mcat,p,actlen);
			p += actlen;
		}
		len -= fldlen;
	}
	/* ffffffffffff */
	akxtmcat(&mcat,p,6);
	p += 6;
	len -= 6;
	while (len>0) {
		akxtmcat(&mcat,p,8);
		memcpy((char *)&sw,p,2); p += 2; grpno = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; tplno = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; ngrp  = CL_NTOHS(sw);
		memcpy((char *)&sw,p,2); p += 2; ndat  = CL_NTOHS(sw);
		akxtmcat(&mcat,p,(ngrp+ndat)*2);
		for (i=0;i<ngrp;i++) {
			memcpy((char *)&sw,p,2); p += 2; fldno = CL_NTOHS(sw);
		}
		for (i=0;i<ndat;i++) {
			memcpy((char *)&sw,p,2); p += 2; fldno = CL_NTOHS(sw);
		}
		len -= (4+ngrp+ndat)*2;
	}
	akxtmcat(&mcat,p,datlen);
	fmlen += addfldlen;
	lw = CL_NTOHL(fmlen);
	memcpy(mcat.mc_bufp+posfmlen2,(char *)&lw,4);
	return (0);
}
