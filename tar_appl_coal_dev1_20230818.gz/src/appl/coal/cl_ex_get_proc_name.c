static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  													      *
*                                                                             *
*      �֐����@�@�@�F�@int cl_ex_get_proc_name( pparmList , pBuff , plen )    *
*                      (I)prmList	*pparmList                                *
*                      (O)char		*pBuff		                              *
*                      (O)int		*plen		                              *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

int cl_trim_proc_name(p0,len0,pr_nam)
char *p0;
int  len0;
ParList *pr_nam;
{
	static char *PAT=" \t\n\r";
	int len;

	len = akxtstrim2(0,p0,len0,pr_nam,PAT);
	return len;
}

int cl_ex_get_proc_name(pparmList, Obj, pr_nam)
parmList *pparmList;
int  *Obj;
ParList *pr_nam;
{
	static char *_fn_="cl_ex_get_proc_name";
	int  rc,len,pos,n;
	char *p,*pn;
	tdtINFO_PARM InfoParm;

	p   = pparmList->prp;
	len = pparmList->prmlen;
DEBUGOUTL2(110,"cl_ex_get_proc_name:Enter len=%d p=[%s]",len,p);
	if (cl_trim_proc_name(p,len,pr_nam) < len) {
		p   = pr_nam->par;
		len = pr_nam->parlen;
	}
	if (*p=='{' && p[len-1]=='}') ;
	else if (!cl_is_proc_scr_name(p,len)) {
		pparmList->prp    = p;
		pparmList->prmlen = len;
		if (rc=cl_arg_to_char_opt(pparmList,Obj,&InfoParm,FORMAT(326),D_GX_OPT_PROC_NAME)) return rc;	/* "�葱����" */
		p   = InfoParm.pi_data;
		len = InfoParm.pi_dlen;
		if (cl_trim_proc_name(p,len,pr_nam) < len) {
			p   = pr_nam->par;
			len = pr_nam->parlen;
		}
	}
DEBUGOUTL2(120,"cl_ex_get_proc_name: len=%d p=[%s]",len,p);
	n = len;
	if (n <= 0) {
		ERROROUT2(FORMAT(327),_fn_,FORMAT(114));	/* %s: %s����NULL�ł��B */
		rc = ECL_SCRIPT_ERROR;
	}

DEBUGOUTL1(110,"cl_ex_get_proc_name:Exit rc=%d",rc);
	return rc;
}

/*int cl_exe_proc_name_check(pr_nam)*/
/*	opt = 0x0001 : Ok '.' in name    */
/*        0x0002 : OK '-' in name    */ 
/*        0x0010 : Check sysvar_name */
/*        0x0020 : Check yoyakugo    */
/*        0x1000 : for var name      */
int cl_dot_name_check_opt(func,pr_nam,opt)
char *func;
ParList *pr_nam;
int opt;
{
	static char *_fn_="cl_dot_name_check_opt";
	int  rc,len,pos,n,opt10,opt20,iVAR,m;
	char *p,*pn,*nam;

	opt10 = opt & 0x10;
	opt20 = opt & 0x20;
	iVAR = opt & 0x1000;
	rc = 0;
	p   = pr_nam->par;
	len = pr_nam->parlen;
DEBUGOUTL3(110,"%s:Enter len=%d p=[%s]",_fn_,len,p);
	n = len;
	if (iVAR) {
		pn = FORMAT(329);	/* �ϐ� */
		m = Var_NM_MAX;
	}
	else {
		pn = FORMAT(114);	/* �葱�� */
		m = PR_NM_DEF;
	}
	while (len > 0) {
		n = akxnskipto(p,len,".");
DEBUGOUTL2(120,"%s: n=%d",_fn_,n);
		nam = strtemp(p,n);
		if (n > m) {
						/* %s: %s��[%s]���������܂�(len=%d > %d)�B*/
			if (func) ERROROUT5(FORMAT(112),func,pn,nam,n,m);
			rc = ECL_SCRIPT_ERROR;
		}
		else if (n<=0 || n==len-1) {
			rc = ECL_SCRIPT_ERROR;
			n = 0;
		}
		else if (cl_chk_name_opt(p,n,opt)) {
						/* %s: %s��[%s]���s���ł��B */
			if (func) ERROROUT3(FORMAT(113),func,pn,nam);
			rc = ECL_SCRIPT_ERROR;
		}
		if (!rc && opt10) {
			if (cl_chk_sysvar_name(p,n)) {
				if (func) ERROROUT2(FORMAT(453),func,nam);
				rc = ECL_EX_DEFINE;
			}
		}
		if (!rc && opt20) {
			if (cl_is_yoyakugo(strtemp(p,n))) {
				if (func) ERROROUT2(FORMAT(121),func,nam);
				rc = ECL_EX_DEFINE;
			}
		}
		if (rc) break;
		len -= ++n;
		p += n;
	}
	if (n <= 0) {
		if (func) ERROROUT2(FORMAT(327),func,pn);	/* %s: %s����NULL�ł��B */
		rc = ECL_SCRIPT_ERROR;
	}
DEBUGOUTL2(110,"%s:Exit rc=%d",_fn_,rc);
	return rc;
}

int cl_dot_name_check(pr_nam)
ParList *pr_nam;
{
	static char *_fn_="cl_dot_name_check";

	return cl_dot_name_check_opt(_fn_,pr_nam,0);
}

int cl_exe_proc_name_check(pr_nam)
ParList *pr_nam;
{
	static char *_fn_="cl_exe_proc_name_check";

	return cl_dot_name_check_opt(_fn_,pr_nam,0x32);
}

int cl_ex_get_proc_scr_name(pparmList,Obj,pr_nam,sc_nam)
parmList *pparmList;
int  *Obj;
ParList *pr_nam,*sc_nam;
{
	static char *C_SEP=" \t@'";
	int  ret,len,n,i,pos;
	char *p,*da[2],na[2],*pp,c;
	SSPL_S ssp;
	int atr;
	char wrk[4096];
	parmList parm;
	ParList par[2];

	ret = 0;
	p   = pparmList->prp;
	len = pparmList->prmlen;
DEBUGOUTL2(110,"cl_ex_get_proc_scr_name:Enter len=%d p=[%s]",len,p);
	if (cl_trim_proc_name(p,len,pr_nam) < len) {
		p   = pr_nam->par;
		len = pr_nam->parlen;
	}
	if (*p=='{' && p[len-1]=='}') {
		sc_nam->par = p;
		sc_nam->parlen = len;
		pr_nam->par = NULL;
		pr_nam->parlen = 0;
		return 0;
	}
	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk)-1;
	i = 0;
	while ((n=akxtgwnsl(p,len,&ssp,C_SEP,0x43)) >= 0) {
DEBUGOUTL4(120,"cl_ex_get_proc_scr_name: n=%d atr=%d sp=%d wd=[%s]",n,ssp.attr[0],ssp.sp,ssp.wd);
		c = *ssp.wd;
		if (c == '@') {
			i = ssp.sp - 1;
DEBUGOUTL1(120,"cl_ex_get_proc_scr_name: i=%d\n",i);
			break;
		}
	}
	if (i > 0) {
		par[0].par = p;
		par[0].parlen = i;
		par[1].par = p + i + 1;
		par[1].parlen = len - (i+1);
		pp = wrk;
		len = 2;
		for (i=0;i<2;i++) {
			parm.prp    = pp;
			parm.prmlen = par[i].parlen;
			parm.opt    = 0;
			parm.bxobj  = NULL;
			memzcpy(parm.prp,par[i].par,parm.prmlen);
DEBUGOUTL3(120,"cl_ex_get_proc_scr_name: i=%d parm.prmlen=%d parm.prp=[%s]",i,parm.prmlen,parm.prp);
			if (ret = cl_ex_get_proc_name(&parm,Obj,&par[i])) return ret;
DEBUGOUTL2(120,"cl_ex_get_proc_scr_name: na=%d da=[%s]",par[i].parlen,par[i].par);
			pp += parm.prmlen+1;
			len += par[i].parlen;
		}
		i = 1;
	}
	else {
		sc_nam->par = NULL;
		sc_nam->parlen = 0;
		if (ret = cl_ex_get_proc_name(pparmList,Obj,pr_nam)) return ret;
		p = pr_nam->par;
		if ((i=instrchar(p,'@',0)) > 0) {
			len = pr_nam->parlen;
			par[0].par = p;
			par[0].parlen = i - 1;
			par[1].par = p + i;
			par[1].parlen = len - i;
			len++;
		}
		else {
		}
	}
	if (i > 0) {
		pp = cl_tmp_const_malloc(len);
		memzcpy(pp,par[0].par,par[0].parlen);
		pr_nam->par = pp;
		pr_nam->parlen = par[0].parlen;
		pp += par[0].parlen + 1;
		memzcpy(pp,par[1].par,par[1].parlen);
		sc_nam->par = pp;
		sc_nam->parlen = par[1].parlen;
	}
DEBUGOUTL1(110,"cl_ex_get_proc_scr_name:Exit ret=%d",ret);
	return 0;
}
