static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  							                              *
*                                                                             *
*      �֐����@�@�@�F�@int cl_input_gr( pFrameTbl )						      *
*                      (I)pFrameInfo	*pFrameTbl						      *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

int cl_input_gr(pFrameTbl, parmlen)
pFrameInfo	pFrameTbl;
int parmlen;
{
	int i,j,rc,iSel;
	ScrPrCT *pScCT;
	ProcCT  *proc;
	char    *pSel,*pNam;
	ONTBL   *pOntbl;

	pScCT = cl_search_src_ct();

DEBUGOUTL1(LVL_XML,"cl_input_gr:1: OnSelect = %d",pScCT->OnSelect);

	if (pScCT->OnSelect>=0 && cmn_chk_stat(GR3_PR,&pScCT->ptype)!=L_OFF) {
		cmn_set_stat(GR3_PR,&pScCT->ptype,L_OFF);
		pOntbl = pScCT->ONCOND[pScCT->OnSelect];
		if (pNam=pOntbl->PrName[2]) {
			if (rc=cl_input_exec_proc(pOntbl->PrSel[2],pNam)) return rc;
			if (cmn_chk_stat(NEW_SC,&pCLprocTable->ScrSt) != L_OFF) {
				cmn_set_stat(NEW_SC,&pCLprocTable->ScrSt,L_OFF);
				return 0;
			}
			proc = cl_search_proc_ct();
			if (cmn_chk_stat(RTN_PR|SCR_PR,&proc->ptype) != L_OFF) return (0);
			if (pGlobTable->error != 0) {
				cmn_set_stat(RET_PR,&proc->ptype,L_ON);
				return (0);
			}
		}
	}

	if (rc = cl_input_gr_set(pFrameTbl)) {
		ERROROUT("cl_input_gr return error");
		return rc;
	}
	cmn_set_stat(GR3_PR,&pScCT->ptype,L_OFF);

DEBUGOUTL1(LVL_XML,"cl_input_gr:2: OnSelect = %d",pScCT->OnSelect);

	if (pScCT->OnSelect >= 0) pOntbl = pScCT->ONCOND[pScCT->OnSelect];
	else pOntbl = NULL;

	iSel = 0;
	if (pFrameTbl->field_1 == 99009) {
		if (pOntbl && pOntbl->PrName[2]) {
			iSel = pOntbl->PrSel[2];
			pNam = pOntbl->PrName[2];
		}
	}
	else {
		if ((rc=cl_search_ontbl(pFrameTbl)) != NORMAL) {
			ERROROUT("cl_input_gr: skip data");
		}
		else if (pScCT->OnSelect >= 0) {
			pOntbl = pScCT->ONCOND[pScCT->OnSelect];
			iSel = pOntbl->PrSel[0];
			pNam = pOntbl->PrName[0];
		}
		if (pFrameTbl->field_1 < 99000) cmn_set_stat(GR3_PR,&pScCT->ptype,L_ON);
	}
	proc = cl_search_proc_ct();
	proc->INPCB.curaddr = (char *)proc->INPCB.parmtop + parmlen;
	proc->INPCB.curlen = parmlen;

DEBUGOUTL1(LVL_XML,"cl_input_gr: iSel = %d",iSel);

	if (iSel) {
		if (rc=cl_input_exec_proc(iSel,pNam)) return rc;
	}

	return NORMAL;
}

int cl_input_xml_tag(pFrameTbl, sp)
pFrameInfo	pFrameTbl;
int sp;
{
	int i,j,rc,iSel;
	ScrPrCT *pScCT;
	ProcCT  *proc;
	char    *pSel,*pNam;
	ONTBL   *pOntbl;

	pScCT = cl_search_src_ct();

DEBUGOUTL1(LVL_XML,"cl_input_xml_tag:1: OnSelect = %d",pScCT->OnSelect);

	if (pScCT->OnSelect>=0 && cmn_chk_stat(GR3_PR,&pScCT->ptype)!=L_OFF) {
		cmn_set_stat(GR3_PR,&pScCT->ptype,L_OFF);
		pOntbl = pScCT->ONCOND[pScCT->OnSelect];
		if (pNam=pOntbl->PrName[2]) {
			if (rc=cl_input_exec_proc(pOntbl->PrSel[2],pNam)) return rc;
			if (cmn_chk_stat(NEW_SC,&pCLprocTable->ScrSt) != L_OFF) {
				cmn_set_stat(NEW_SC,&pCLprocTable->ScrSt,L_OFF);
				return 0;
			}
			proc = cl_search_proc_ct();
			if (cmn_chk_stat(RTN_PR|SCR_PR,&proc->ptype) != L_OFF) return (0);
			if (pGlobTable->error != 0) {
				cmn_set_stat(RET_PR,&proc->ptype,L_ON);
				return (0);
			}
		}
	}

	if (rc = cl_input_gr_set(pFrameTbl)) {
		ERROROUT("cl_input_gr return error");
		return rc;
	}

	iSel = 0;
	if ((rc=cl_search_ontbl(pFrameTbl)) != NORMAL) {
		ERROROUT("cl_input_xml_tag: skip data");
	}
	else if (pScCT->OnSelect >= 0) {
		pOntbl = pScCT->ONCOND[pScCT->OnSelect];
		if (pFrameTbl->field_1 == 99009) {
			iSel = pOntbl->PrSel[2];
			pNam = pOntbl->PrName[2];
		}
		else {
			iSel = pOntbl->PrSel[0];
			pNam = pOntbl->PrName[0];
		}
	}
	proc = cl_search_proc_ct();
	proc->INPCB.curaddr = (char *)proc->INPCB.parmtop + sp;
	proc->INPCB.curlen = sp;

DEBUGOUTL1(LVL_XML,"cl_input_xml_tag: iSel = %d",iSel);

	if (iSel) {
		if (rc=cl_input_exec_proc(iSel,pNam)) return rc;
	}
	/* 2007.11.08 == to != */
	if (cmn_chk_stat(GR3_PR,&pScCT->ptype) != L_OFF) pScCT->OnSelect = -1;

	return NORMAL;
}
