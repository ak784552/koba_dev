static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       long       col_mn_tr_leave              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/

#include "colmn.h"
extern condList  CLcList;	/* ��񃊃X�g */

int col_mn_tr_leave()
{
	int rc;

	if (CLcList.cmd.prmnum == 0) {
		ERROROUT1(FORMAT(44),"col_mn_tr_leave");
		return ECL_TR_LEAVE;
	}
	else if (CLcList.cmd.prmnum > 1) {
		ERROROUT1(FORMAT(41),"col_mn_tr_leave");
		return ECL_TR_LEAVE;
	}


	/* �m�[�h�̗̈���m�� */
	if (!(rc = cl_make_leaf()))

	/* �m�[�h���X�^�b�N�ɐς� */
		rc = cl_push();

	return rc;
}
