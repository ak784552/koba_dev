static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/* ��������									*/
/*	 FROM  �ߍ쐬�֐�						*/
/*------------------------------------------*/
/*					  ver 0.1				*/
/********************************************/
#include "colmn.h"

#define BUFF_SIZE 1024

extern ViewTBL ViewTbl;

char *cl_sl_ext_from()
{
	char *buf_front;
	char *buf_back;
	char *buf;
	char tblnam[40];
	char *view;
	char *alias;
	char flg_front;
	char flg_back;
	int   i;

	if(!(buf_front = (char *)Malloc(BUFF_SIZE))) {
		ERROROUT("memory allocate error");
		return NULL;
	}
	if(!(buf_back = (char *)Malloc(BUFF_SIZE))) {
		Free(buf_front);
		ERROROUT("memory allocate error");
		return NULL;
	}

	/*
	*** from���߂̐���
	 */
	flg_front = 0;
	flg_back = 0;
	memset(buf_front,0,sizeof(BUFF_SIZE));
	memset(buf_back,0,sizeof(BUFF_SIZE));

	/* ���ڐ������[�v */
	for (i=0;i<ViewTbl.iItemNum;i++) {
		/* �Ώۃt���O��ON�̏ꍇ */
#if 0
printf("No=%d,ViewName=%s,ObjFlag=0x%x\n",i,ViewTbl.Line[i].ViewName,
										ViewTbl.Line[i].ObjFlag);
#endif
		if(ViewTbl.Line[i].ObjFlag & 0x05) { /* �������� */
			memset(tblnam,0,sizeof(tblnam));
			view = ViewTbl.Line[i].ViewName;
			if(!*view){
				Free(buf_front);
				Free(buf_back);
				ERROROUT("no from clause");
				return NULL;
			}
			alias = ViewTbl.Line[i].ALIASNAME;
			if(!*alias){
				Free(buf_front);
				Free(buf_back);
				ERROROUT("no from clause");
				return NULL;
			}
			/* 2�Ԗڈȍ~�̃r���[����ALIASNAME -> "," */
			sprintf(tblnam, (flg_front) ? ", %s %s" : "%s %s", view, alias);
			strcat(buf_front, tblnam);
			flg_front = 1;
		}
		else if(ViewTbl.Line[i].ObjFlag & 0x02) { /* �����Ȃ�,�\�����ڂ̂� */
			memset(tblnam,0,sizeof(tblnam));
			view = ViewTbl.Line[i].ViewName;
			if(!*view){
				Free(buf_front);
				Free(buf_back);
				ERROROUT("no from clause");
				return NULL;
			}
			alias = ViewTbl.Line[i].ALIASNAME;
			if(!*alias){
				Free(buf_front);
				Free(buf_back);
				ERROROUT("no from clause");
				return NULL;
			}
			/* 2�Ԗڈȍ~�̃r���[����ALIASNAME -> "," */
			sprintf(tblnam, (flg_back) ? ", %s %s" : "%s %s", view, alias);
			strcat(buf_back, tblnam);
			flg_back = 1;
		}
	}
	if (!(buf = Malloc(strlen(buf_front)+strlen(buf_back)+8))){
		Free(buf_front);
		Free(buf_back);
		ERROROUT("memory allocate error");
		return NULL;
	}

	strcpy(buf," from ");

	if (flg_front) {
#if 0
printf("flg_front ON ,buf_front=%s\n",buf_front);
#endif
		strcat(buf,buf_front);
		if (flg_back){
			strcat(buf,",");
			strcat(buf,buf_back);
		}
	}
	else if (flg_back){
#if 0
printf("flg_back ON ,buf_back=%s\n",buf_back);
#endif
			strcat(buf,buf_back);
	}
	else {/* �e�q�n�l���߂Ȃ� */
		Free(buf_front);
		Free(buf_back);
		Free(buf);
		ERROROUT("no from clause");
		return NULL;
	}

	/* from���߂̕�����̃|�C���^�[�����^�[�� */
#if 0
printf("buf_len=%d\n,buf=%s\n",strlen(buf),buf);
#endif
	Free(buf_front);
	Free(buf_back);
	return buf;
}
