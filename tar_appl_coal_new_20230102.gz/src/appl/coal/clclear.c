static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************/
/*                                       */
/*                 cl_ct_clear           */
/*---------------------------------------*/
/*  �X�N���v�g�e�[�u���ƃv���V�[�W���[   */
/*  �e�[�u���̍폜                       */
/*---------------------------------------*/
/*                                       */
/*****************************************/
#include "colmn.h"

extern CLPRTBL   *pGLprocTable;
extern CLPRTBL   *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern tdtLruScrHead *tpLruScrHeadImp;
extern tdtLruScrHead *tpLruScrHead;
extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */

int addrchk(file,line,p)
char *file;
int  line;
char *p;
{
	char w[128];

	if (!p) return 0;
	if (!akxm_addrchk(p)) {
		sprintf(w,"address invalid (0x%08x)",p);
		akb_error_out(file,line,w);
		return 0;
	}
	return 1;
}

int cl_ct_clear()
{
	ScrPrCT        *Dummy;
	SearchResult   *DummySE;
	ListPacBody    *DummyLP;
	VarTBL         *DummyVR;
	ConstantCt     *DummyCN;
	AKAMSGCOM      *tpMsgCom;
	tdtRbChain *xha;
	int i,m;
	long *argv[2],lVal,ih;
	tdtInfoParm *pInfoParm;

	if (ADDRCHK(CLSTCB.TopStack)) {
		cl_leaf_clear(CLSTCB.TopStack);
		CLSTCB.TopStack = NULL;
	}
	if (pCLprocTable->CmdPacketp) {
		tpMsgCom = (AKAMSGCOM *)pCLprocTable->CmdPacketp;
		if (tpMsgCom->msg_pmsg) {
			Free(tpMsgCom->msg_pmsg);
			tpMsgCom->msg_pmsg = NULL;
		}
	}
	if (pCLprocTable->WaitPacketp) {
		Free(pCLprocTable->WaitPacketp);
		pCLprocTable->WaitPacketp = (char *)NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->PrCTp=%08x\n",pCLprocTable->PrCTp);
*/
	if (ADDRCHK(pCLprocTable->PrCTp)) {
		Dummy = pCLprocTable->PrCTp;
		cl_scr_clear(Dummy);
		pCLprocTable->PrCTp = NULL;
	}

	if (ADDRCHK(pCLprocTable->SearchRsltF)) {
		DummySE = pCLprocTable->SearchRsltF;
		cl_rslt_clear(DummySE);
		pCLprocTable->SearchRsltF = NULL;
	}

	if (pCLprocTable->ListPBody != NULL) {
		cl_list_pac_clear(pCLprocTable->ListPBody);
		pCLprocTable->ListPBody = NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->Vary=%08x\n",pCLprocTable->Vary);
*/
	if (ADDRCHK(DummyVR=pCLprocTable->Vary)) {
#if 0	/* 2022.9.21 */
		pCLprocTable->Vary->varnam_dolu = 1;
		xha = (tdtRbChain *)pCLprocTable->Vary->pha_vnam;
		m = akxs_xhasl(xha,'M',0,NULL);
printf("cl_ct_clear: m=%d\n",m);
		for (i=1;i<=m;i++) {
			if ((ih=akxs_xhasl(xha,'K',i,argv)) > 0) {
				pInfoParm = (tdtInfoParm *)*argv[0];
				lVal = (long)argv[1];
			/*	akxs_xhasl(xha,'D',pInfoParm,NULL);	*/
printf("cl_ct_clear:cl_free_info_parm: i=%d pInfoParm=%08x ih=%d lVal=%08x\n",i,pInfoParm,ih,lVal);
				if (!(lVal & 0xf0000000)) {
printf("cl_ct_clear:cl_free_info_parm: id=[%c] pi_scale=%02x\n",pInfoParm->pi_id,pInfoParm->pi_scale);
				/*	cl_free_info_parm(pInfoParm);	*/
				}
			/*	Free(pInfoParm);	*/
			}
		}
printf("cl_ct_clear:akxs_xhasl_free: DummyVR->pha_vnam=%08x\n",DummyVR->pha_vnam);
		akxs_xhasl_free(DummyVR->pha_vnam);
printf("cl_ct_clear:Free: DummyVR=%08x\n",DummyVR);
		Free(DummyVR);
#else
		vary_clear(DummyVR);
#endif
		pCLprocTable->Vary = NULL;
	}
	if (ADDRCHK(pCLprocTable->pha_vnam)) {
		akxs_xhash_free(pCLprocTable->pha_vnam);
		pCLprocTable->pha_vnam = NULL;
	}
	if (ADDRCHK(pCLprocTable->pTBL_vnam)) {
		cl_free_var_ent(pCLprocTable->pTBL_vnam);
		Free(pCLprocTable->pTBL_vnam[0]);
		Free(pCLprocTable->pTBL_vnam);
		pCLprocTable->pTBL_vnam = NULL;
	}

	if (ADDRCHK(pCLprocTable->pha_fp)) {
		cl_free_fp(pCLprocTable->pha_fp);
		pCLprocTable->pha_fp = NULL;
	}

	if (ADDRCHK(pCLprocTable->pha_env)) {
		cl_env_reset(pCLprocTable->pha_env);
		pCLprocTable->pha_env = NULL;
	}

	if (ADDRCHK(pCLprocTable->ConstCt)) {
		DummyCN = pCLprocTable->ConstCt;
		const_ct_clear ( DummyCN );
		pCLprocTable->ConstCt = NULL ;
	}
#if 0	/* 2021.7.13 */
	if (ADDRCHK(pCLprocTable->pha_gid)) {
		akxs_xhasl_free(pCLprocTable->pha_gid);
		pCLprocTable->pha_gid = NULL;
	}
#endif
	cl_tmp_const_clear(2);

	pCLprocTable->CurScr = NULL;
	pCLprocTable->CurProc = NULL;

	pGlobTable->tuppl  = 0;
	pGlobTable->column = 0;
	pGlobTable->error  = 0;
	pGlobTable->Return = 0;
	pGlobTable->Retval = NULL;
	pGlobTable->exception = 0;
	pGlobTable->try_level = 0;

	return 0;
}

/**************************************************/
/*   �X�N���v�g�e�[�u���̍폜 (cl_scr_clear)      */
/**************************************************/
static void _free_const(scrconst)
ScrConstCt *scrconst;
{
	Leaf *leaf;
	char *p;
	int  cno;
#if 0
	if (leaf=scrconst->NodeLeaf) {
		if ((cno=leaf->cmd.cid)==C_NODE_IMPORT || cno==C_NODE_SCRIPT) {
/*
printf("_free_const: node=%08x pFlag=%02x\n",cno,leaf->pFlag);
*/
			if (leaf->pFlag & D_LEAF_CACHED) cl_lru_scr_era(scrconst->pId);
			else cl_leaf_clear(leaf->leftleaf);
			Free(leaf);
		}
	}
#endif
	if (p=scrconst->pId) Free(p);
	Free(scrconst);
}

int cl_scr_clear( Dummy )
ScrPrCT    *Dummy;
{
	int i,j,cno;
	ONTBL *pOntbl;
	char  *p;
	tdtRbCtl *pCt;
	Leaf *leaf;
	tdtInfoParm **Obj0;
	tdtREDIRECT *red;
	MCAT2 *mcat2;
/*ProcCT *proc;*/
/*
printf("cl_scr_clear: Dummy=%08x [%s] called.\n",Dummy,Dummy->pId);
*/
	if (ADDRCHK(Dummy->ProCT)) {
/*
proc = Dummy->ProCT;
printf("cl_scr_clear: proc=%08x [%s] called.\n",proc,proc->ProcNM);
*/
		cl_prc_clear(Dummy->ProCT);
	}
	Dummy->ProCT = NULL;

	if (ADDRCHK(Dummy->Vary)) {
/*
printf("            [%s] start vary_clear.\n",Dummy->pId);
*/
		vary_clear( Dummy->Vary );
	}
	Dummy->Vary = NULL;
	if (Dummy->ONCOND) {
		for (i=0;i<Dummy->on_num_max;i++) {
			if (pOntbl = Dummy->ONCOND[i]) {
				for (j=0;j<4;j++) {
					if ((p=pOntbl->PrName[j])) Free(p);
				}
				Free (pOntbl);
			}
		}
		Free(Dummy->ONCOND);
		Dummy->ONCOND = NULL;
	}
	if ( ADDRCHK(Dummy->nextScCT) )  cl_scr_clear( Dummy->nextScCT );
	Dummy->nextScCT = NULL;
	if (!(Dummy->pFlag & D_LEAF_IMPORTMODE)) {
/*
printf("            [%s] pFlag=%02x\n",Dummy->pId,Dummy->pFlag);
*/
		if (Dummy->pFlag & D_LEAF_CACHED) cl_lru_scr_era(tpLruScrHead,Dummy->pId);
		else if (ADDRCHK(leaf=Dummy->TreeTop))  cl_leaf_clear(leaf);
	}
/*
printf("cl_scr_clear: Dummy->ConstCt=%08x\n",Dummy->ConstCt);
*/
	if (ADDRCHK(Dummy->ConstCt)) const_ct_clear(Dummy->ConstCt);

	if (pCt=Dummy->pListImport) {
		akxs_list_free(pCt,_free_const);
	}

	if (ADDRCHK(Dummy->Obj)) {
/*
printf("cl_scr_clear: Dummy->Obj=%08x\n",Dummy->Obj);
*/
		if (Obj0 = Dummy->Obj->Obj0) {
			if (Obj0[0]) Free(Obj0[0]);
			Free(Obj0);
		}
		Free(Dummy->Obj);
	}

	if (ADDRCHK(Dummy->ProcIndex)) {
		akxs_xhash_free(Dummy->ProcIndex);
	}
#if 0
	if (pCt=Dummy->pListExport) {
		akxs_list_free(pCt,NULL);
	}
#endif
	if (ADDRCHK(red=Dummy->redirect)) {
		if (Dummy->pFlag2 & D_PFLAG2_ALC_HDNM) {
			if (ADDRCHK(p=red->HereDoc_nm)) Free(p);
		}
		Free(red);
	}
#if 1	/* 2022.10.30 */
	if (ADDRCHK(mcat2=Dummy->pErrmsgOnce)) {
		if (p=mcat2->mc_bufp) Free(p);
		Free(mcat2);
	}
#endif
	Free(Dummy);
	return 0;
}

/***************************************************/
/*   �v���V�[�W���[�e�[�u���̍폜 (cl_prc_clear)   */
/***************************************************/
/* add 2001.1.12 Koba */
int cl_prc_ct_clear(proc)
ProcCT    *proc;
{
	BlockCB *pBlockCB,*wB;
	ConstantCt *DummyG;
	int i,j;
	tdtInfoParm **Obj0;
	char *p;
	tdtREDIRECT *red;

	if (!proc) return 0;
/*
printf("cl_prc_ct_clear: proc=%08x ProcNM=[%s]\n",proc,proc->ProcNM);
*/
	cl_tmp_const_ct_set(NULL);

	pBlockCB = proc->pTopBlockCB;
	while (pBlockCB) {
		if (pBlockCB->pEachParm) Free(pBlockCB->pEachParm);
		wB = pBlockCB->nextBlockCB;
		Free (pBlockCB);
		pBlockCB = wB;
	}
	proc->pTopBlockCB = NULL;
	if (proc->INPCB.parmtop) {
		Free(proc->INPCB.parmtop);
		proc->INPCB.parmtop = NULL;
	}

	akxs_rb_free(proc->pRetStack);

	if (proc->pha_vnam) akxs_xhash_free(proc->pha_vnam);
	if (proc->pTBL_vnam) {
		if (!(proc->pFlag & D_PFLAG_PARM_COPY)) cl_free_var_ent(proc->pTBL_pasento);
		cl_free_var_ent(proc->pTBL_vnam);
		Free(proc->pTBL_vnam[0]);
		Free(proc->pTBL_vnam);
	}

	if (ADDRCHK(p=proc->ProcNM)) Free(p);
	if (ADDRCHK(proc->pTmpConstCt)) const_ct_clear(proc->pTmpConstCt);
	if (ADDRCHK(proc->Obj)) {
		Obj0 = proc->Obj->Obj0;
		if (p=(char *)Obj0[0]) Free(p);
		Free(Obj0);
		Free(proc->Obj);
	}
	if (ADDRCHK(p=proc->ProcPath)) {
/*
printf("cl_prc_ct_clear: path=[%s]\n",p);
*/
		if (*p == '*') Free(p);
	}
	if (ADDRCHK(red=proc->redirect)) {
		if (proc->pFlag2 & D_PFLAG2_ALC_HDNM) {
			if (ADDRCHK(p=red->HereDoc_nm)) Free(p);
		}
		Free(red);
	}

	return 0;
}

int cl_prc_clear(Dummy)
ProcCT *Dummy;
{
/*
printf("cl_prc_clear: Dummy=%08x [%s] Dummy->nextPCT=%08x\n",Dummy,Dummy->ProcNM,Dummy->nextPCT);
*/
	if (ADDRCHK(Dummy->nextPCT)) {
		cl_prc_clear(Dummy->nextPCT);
		Dummy->nextPCT = NULL;
	}
	cl_prc_ct_clear(Dummy);
	Free(Dummy);
	return 0;
}

/**********************************************/
/*                                            */
/*             cl_leaf_clear                  */
/*--------------------------------------------*/
/*                                            */
/*         �@���[�t�e�[�u���̍폜             */
/*--------------------------------------------*/
/*                                            */
/**********************************************/
/*  */
int cl_leaf_clear(Dummy)
Leaf *Dummy;
{
	Leaf *leaf;
/*
if (ADDRCHK(Dummy)) printf("cl_leaf_clear: [%s]\n",cl_get_pcmd_line(Dummy));
*/
	if (ADDRCHK(leaf=Dummy->rightleaf)) cl_leaf_clear(leaf);
/*
else akxaxdump("ADDRCHK",Dummy,sizeof(Leaf));
*/
	if (ADDRCHK(leaf=Dummy->leftleaf))  cl_leaf_clear(leaf);
	Free(Dummy);

	return 0;
}

/**********************************************/
/*                                            */
/*              cl_rslt_clear                 */
/*--------------------------------------------*/
/*                                            */
/*         �������ʍ\���̂̍폜               */
/*--------------------------------------------*/
/*                                            */
/**********************************************/
/* */
int cl_rslt_clear( Dummy )
SearchResult *Dummy;
{
	cl_result_clear ( Dummy );
	Free ( Dummy );
	return ( 0 );
}

/***********************************************/
/*    �������ʍ\���̂̍폜  (cl_result_clear)  */
/***********************************************/

int cl_result_clear(Dummy)
SearchResult *Dummy;
{
	if ( ADDRCHK(Dummy->Next) ){
		cl_result_clear(Dummy->Next);
		Free(Dummy->Next);
		Dummy->Next = NULL;
	}
	if ( Dummy->szType[0] == 'F' ) {
		if ( Dummy->pzFileName ) Free(Dummy->pzFileName);
	}
	else if ( Dummy->szType[0] == 'B' ) {
		if ( Dummy->iIndex ) Free ( Dummy->iIndex - 2);
		if ( Dummy->RslBody ) Free ( Dummy->RslBody );
		if ( Dummy->pzFileName ) Free(Dummy->pzFileName);
	}
	if (Dummy->sAreaId) Free(Dummy->sAreaId);
	return 0;
}

/***********************************************/
/*      ���C�A�E�g�f�[�^�̏�����               */
/***********************************************/
/*   */

int cl_list_pac_clear(DummyA)
ListPacBody *DummyA ;
{
	if (ADDRCHK(DummyA)) {
		if (ADDRCHK(DummyA->mCat.mc_bufp)) Free(DummyA->mCat.mc_bufp);
	}
	return 0;
}

/******************************************************/
/*         �p�����[�^���X�g �̏�����                  */
/******************************************************/
int prm_list_clear(DummyE)
prmList *DummyE;
{
	if (DummyE->VarBD) Free(DummyE->VarBD);
	return 0;
}

int info_parm_clear(DummyE)
tdtInfoParm *DummyE;
{
	cl_free_info_parm(DummyE);
	memset(DummyE,0,sizeof(tdtInfoParm));
	return 0;
}

/*******************************************************/
/*           �ϐ��e�[�u���̏�����                      */
/*******************************************************/
int vary_clear(DummyF)
VarTBL *DummyF;
{
	int  i;
	char *p;

	cl_free_var_ent(DummyF->pTBL_igeta);
	cl_free_var_ent(DummyF->pTBL_pasento);
	cl_free_var_ent(DummyF->pTBL_dolu);

	cl_free_var_ent(DummyF->pTBL_vnam);
	akxs_xhash_free(DummyF->pha_vnam);

	p = (char *)DummyF->pTBL_dolu;
	if (p) {
		Free(DummyF->pTBL_dolu[0]);
		Free(p);
	}

	Free(DummyF);
	return 0;
}

/*******************************************************/
/*           CONSTANT�e�[�u���̏�����                  */
/*******************************************************/
int const_ct_clear(DummyG)
ConstantCt *DummyG;
{
	if (ADDRCHK(DummyG)) {
		akxm_cct_mem_free(DummyG);
	}
	return 0;
}
