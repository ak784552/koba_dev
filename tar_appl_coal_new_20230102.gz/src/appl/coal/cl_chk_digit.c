static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*		���l�f�[�^�̃`�F�b�N				*/
/*											*/
/********************************************/
#include "colmn.h"

int cl_chk_digit(rad, buf, len)
int  rad;
char *buf;
int  len;
{
	int i,n,rad1,iUL;
	char *p=buf;

	len = akxqnumUL(p,len,&iUL);
	rad1 = rad - 1;
	for (i=0;i<len;i++) {
		n = *p++ - '0';
		if (n<0 || n>rad1) return -(i+1);
	}
	return 0;
}

int cl_chk_digit_x(buf, len)
char *buf;
int  len;
{
	int i;
	char c,*p=buf;

	for (i=0;i<len;i++) {
		if (!isdigit(c = *p++)) {
			if ((c>='a' && c<='f') ||
			    (c>= 'A' && c<='F'))
				continue;
			else
				return -1;
		}
	}
	return 0;
}

/********1*********2*********3*********4*********5*********6*****/
/*	-1234[U[L]]													*/
/*	-1234.567													*/
/*	-1234.567F													*/
/*	-1234.567D													*/
/*	-1234.567[E]+10												*/
/*	-1234.567[D]-10												*/
/*	0x0123456789ABCDEF, 0o01234567, 0b01						*/
/*	opt : AKX_CNVN_OPT_COMMA : �J���}�𖳎�����					*/
/*		  AKX_CNVN_OPT_MSIGN : ��������������					*/
/*		  AKX_CNVN_OPT_DIGIT : 0x,0o,0b�`�����G���[�ɂ��Ȃ�		*/
/*		  AKX_CNVN_OPT_FU_MPA: +123+01 ���̎w���`����MPA�Ƃ���	*/
/*	ret =  0 : int												*/
/*		=  1 : double											*/
/*		=  2 : decimal											*/
/*		=  8 : int ket over										*/
/*		= 0x10 : unsigned										*/
/*		= 0x20 : long											*/
/*		= 0x40 : image											*/
/*		= -1 : buf==NULL or buf_len<0							*/
/*		  -2 : ��												*/
/*		  -3 : �����̂�											*/
/*		  -4 : 0x,0o,0b �`���G���[								*/
/*		  -5 : �����܂��͏����_�����鐔����G���[				*/
/*		  -6 : E,F,D �`���G���[									*/
/*		  -7 : �����d��											*/
/****************************************************************/
int cl_chk_digit_fopt(rad, buf, len, opt)
int  rad;
char *buf;
int  len,opt;
{
#if 1	/* 2021.10.1 */
	int ret,iParm[4],m;
/*
printf("cl_chk_digit_fopt:Enter rad=%d opt=%08x len=%d buf=[%s]\n",rad,opt,len,buf);
*/
	ret = akxqnumber(buf,len,opt,iParm);
/*
printf("cl_chk_digit_fopt: ret=%d iParm=%04x %d %d %d\n",ret,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
	if (ret >= 0) {
		m = iParm[3];
		if (ret == 2) ret = iParm[0] & AKX_NUM_ULI;
		else if (ret == 10) ret = 0;
		else if (ret == 8) ret = 2;
		else if (ret==3 || ret==4) ret -= 2;
		else ret = -5;
		if (ret==1 || ret==2) ret |= iParm[0] & AKX_NUM_ULI;
	}
#else
	int i,n,rad1,ret,opt2,m;
	char c,*p,cc;

	for (i=0,p=buf;i<len;i++,p++) {
		if ((c=*p)==' ' || c=='\t' || c=='+' || c=='-') ;
		else break;
	}
	if (i >= len) return 0;

	m = 0;
	ret = 0;
	opt2 = opt & AKX_CNVN_OPT_COMMA;
	if (c == ',') {
		cc = *(p+1);
		if (opt2 && i<len && ((cc>='0' && cc<='9') || cc=='.')) {
			i++;
			c = *(++p);
			ret = 4;
		}
	}
	if (c == '.') {
		if (++i >= len) return 2;	/* DECIMAL */
		c = *(++p);
		ret |= 2;
	}
	rad1 = rad - 1;
	n = c - '0';
	if (n<0 || n>rad1) return -1;
	if (n>0) m++;
	i++;
	p++;
	if (opt & AKX_CNVN_OPT_DIGIT) {
		for (;i<len;i++,p++) {
			cc = *p;
			if ((c=toupper(cc))=='B' || c=='O' || c=='X') {
				if (ret) return -1;
				return 0;
			}
			else if (c=='.') {
				if (ret & 0x03) return -1;
				ret |= 2;
			}
			else if (c=='-' || c=='+') {
				ret |= 2;
			}
			else if (cc=='E') return 2;	/* DECIMAL */
			else if (c=='E' || c=='F' || c=='D') return 1;	/* DOUBLE */
			else if (c==',') {
				if (opt2) ret |= 4;
			}
			else if (c!='0' || m>0) m++;
		}
	}
	else {
		for (;i<len;i++,p++) {
			cc = *p;
			if ((c=toupper(cc))=='.') ret = 2;
			else if (cc=='E') return 2;	/* DECIMAL */
			else if (c=='E' || c=='F' || c=='D') ret = 1;
			else if (c==' ') ;
			else if (c=='-' || c=='+') {
				ret |= 2;
			}
			else if (c==',' && opt2) ret |= 4;
			else {
				n = c - '0';
				if (n<0 || n>rad1) return -1;
				if (n>0 || m>0) m++;
			}
		}
	}
	if (ret) {
		if (ret & 0x01) ret = 1;
		else if (ret & 0x06) ret = 2;
		else ret = 0;
	}
#endif
	if (!ret) {
#if defined(_LP64)
		if (m >= 20)
#else
		if (m >= 11)
#endif
			ret = 8;
	}
/*
printf("cl_chk_digit_fopt:Exit ret=%d\n",ret);
*/
	return ret;
}

int cl_chk_digit_f(rad, buf, len)
int  rad;
char *buf;
int  len;
{
	int ret;

	if ((ret=cl_chk_digit_fopt(rad,buf,len,0)) > 0) ret &= 16+32;
	return ret;
}

int cl_chk_mybe_num(buf,len)
char *buf;
int len;
{
	ParList pa_dat;
	char c;
	int ret;

	ret = 0;
	if (akxtstrim2(2,buf,len,&pa_dat," \t") > 0) {
		c = *pa_dat.par;
		if (c=='+' || c=='-' || c=='.' || (c>='0' && c<='9')) ret = 1;
	}
	return ret;
}
