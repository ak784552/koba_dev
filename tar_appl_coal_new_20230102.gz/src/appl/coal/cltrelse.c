static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       long       col_mn_tr_else               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else()
{
	static int able[]={C_IF,C_ELSEIF};
	static int deny[]={C_ELSE,C_ELSEL};
	char *p;
	int  cnum,i;
	int  rc;

	if (CLcList.cmd.prmnum > 0) {
		p = CLcList.cmd.prmp[0]->prp;
		cnum = cl_cmd_chk_cid(p);
		if (cnum == C_IF) {
			CLcList.cmd.cid = C_ELSEIF;
			CLcList.cmd.prmnum--;
			for (i=0;i<CLcList.cmd.prmnum;i++)
				CLcList.cmd.prmp[i]->prp = CLcList.cmd.prmp[i+1]->prp;
			return col_mn_tr_else_if();
		}
		else {
			/* %s: �]���ȃp�����[�^[%s]������܂��B */
			ERROROUT2(FORMAT(43),"col_mn_tr_else",p);
			return ECL_TR_ELSE;
		}
	}
	if (!(rc=cl_tr_end_node_check(deny,1,able,2))) rc = cl_tr_else_nest_check();
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_default()
{
	static int able[]={C_SWITCH,C_CASE};
	static int deny[]={C_DEFAULT/*,C_SWITCH*/};
	int rc;

	return col_mn_tr_elseNode(deny,1,able,2);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_finally()
{
	static int able[]={C_TRY,C_CATCH};
	static int deny[]={C_FINALLY/*,C_TRY*/};
	int  rc;

	return col_mn_tr_elseNode(deny,1,able,2);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_else_nest_check()
{
	int  rc ,tree;

	tree = cl_nest_tag(2);
	if ( tree != -1 ) {
		rc=cl_change_tree( CLSTCB.nestLev2 );
/*
		if (rc) return (rc);
*/
		cl_search_nest(2);
	}
	else return ECL_TR_ELSE;

	return cl_make_push_leaf();
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_elseNode(deny,nd,able,na)
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_prmnum_check())) {
		if (!(rc=cl_tr_end_node_check(deny,nd,able,na))) rc = cl_tr_else_nest_check();
	}
	return rc;
}
