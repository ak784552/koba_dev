static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int        cl_er_lk_proc_ct             */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/*                 -2   :�X�N���v�g�e�[�u����    */
/*                       �v���V�[�W�������݂�    */
/*                       �Ȃ�                    */
/* --------------------------------------------- */
/*  Function :                                   */
/*   �n���ꂽ�X�N���v�g�e�[�u���������P�[�W����  */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"

extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;

int cl_er_lk_proc_ct()
{
	ScrPrCT  *Dummy;
	ProcCT   *Temp,*proc;
	char cFlag;
	int ret;

	Dummy = cl_search_src_ct();
	if (Dummy == NULL) return SysError;
	if (!(proc = cl_search_proc_ct())) return SysError;

DEBUGOUTL3(102,"cl_er_lk_proc_ct: procct=%08x,name=[%s] pFlag=%02x",proc,proc->ProcNM,proc->pFlag);

	cFlag = proc->pFlag;
	if (!(Temp=proc->prePCT)) {
#ifndef PROC_NO_FREE	/* 2021.2.5 */
		Dummy->ProCT = NULL;
#endif
		ret = -2;
	}
	else {
#ifndef PROC_NO_FREE	/* 2021.2.5 */
		Temp->nextPCT = NULL;
#endif
#if 1	/* 2022.11.17 */
		ret = 0;
	}
	pCLprocTable->CurProc = Temp;
	Dummy->CurProc = Temp;
#else
		pCLprocTable->CurProc = Temp;
		Dummy->CurProc = Temp;
		ret = 0;
	}
#endif

	if (!(cFlag & D_PFLAG_NO_FREE)) {
		akxs_xhasl(pGLprocTable->pha_gid,'D',proc->ProcGid,0);
#ifdef PROC_NO_FREE	/* 2021.2.5 */
		if (proc->ProcNM) {
			Free(proc->ProcNM);
			proc->ProcNM = NULL;
		}
		cl_set_obj0_used(0);
		proc->Obj->used = 0;
		proc->ptype = '\0';
#else
		cl_prc_ct_clear(proc);	/* add 2001.1.12 Koba */
		Free(proc);
#endif
	}

	return ret;
}
