static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	  �����ړI�@�@�F  ���Z����												*
*																			*
*	  �֐����@�@�@�F�@int cl_gx_funcBexp(pInfoParmW,pOperator,nparm,pParm)	*
*						tdtInfoParm *pInfoParmW;							*
*						char *pOperator;									*
*						tdtInfoParm *pParm;									*
*						int nparm;											*
*																			*
*	  �߂�l�@�@�@�F�@ERROR									�@				*
*					  NORMAL												*
*																			*
*	  �����T�v�@�@�F�@														*
*																			*
*****************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];

int replace();
int condas();
int cl_func_conv_parm();
int cl_func_f();
int cl_func_list();
int cl_set_list();
int cl_ope_list();
int cl_cons_list();
int cl_set_array();
int cl_array_ope();
int cl_array_map();
int cl_func_set_struct();
int cl_func_count();
int cl_func_index();
int cl_cmpt_is();
int cl_cmpt_to_number();
int cl_cmpt_math();
int cl_cmpt_to_bulk();
int cl_cmpt_to_bulks();
int cl_func_to_char();
int cl_func_to_date();
int cl_func_date_add();
int cl_func_date_diff();
int cl_func_add_months();
int cl_func_last_day();
int cl_func_add_to_date();
int cl_func_set_date_part();
int cl_cmpt_to();
int rep_condas();
int substrm();
int concat();
int cl_get_args();
int cl_get_word();
int cl_split();
int cl_trim();
int cl_strings();
int cl_leftm();
int cl_rightm();
int cl_rlpad();
int cl_chr();
int cl_asc();
int cl_shsbs();
int cl_replace();
int cl_repchar();
int cl_repstrs();
int cl_rep_like();
int cl_in_like();
int cl_in_regex();
int cl_rep_regex();
int cl_glip();
int cl_grep();
int cl_ex_shell();
int cl_ex_no_free();
int cl_ex_shut_ctl();
int cl_ex_exit();
int cl_edit();
int cl_eedit();
int cl_lenm();
int cl_lenw();
int cl_func_env();
int cl_func_get_time();
int cl_ex_eval();
int cl_ex_ecmd();
int cl_ex_nval();
int cl_ex_nsval();
int cl_ex_ndef();
int cl_ex_decode();
int cl_ex_iif();
int cl_ex_sort();
int cl_ex_round();
int cl_ex_xhash();
int cl_ex_channel();
int cl_func_mem_used();
int cl_func_print();
/*int cl_func_fprint();*/
int cl_func_sprint();
int cl_func_printf();
int cl_func_new();
int cl_func_times();
int cl_func_getval();
int cl_func_str_add();
int cl_func_str_exp();
int cl_func_str_conv();
int cl_func_range();
int cl_func_complex();
int cl_func_redirect();
int cl_func_dec_max_pre();

/*	name		nparm ope					kubun		reta    arg_kbn ret_kbn */
static qOpeTable tOpeTbl[]=
	{"IS"			,2,D_FUC_IS				,IS			,DEF_ZOK_BINA,2,3,cl_cmpt_is	/* 2-->3*/
	,"MOD"			,2,D_FUC_MOD			,MATH		,DEF_ZOK_BINA,0,4,cl_cmpt_math
	,"TO_NUMBER"	,1,D_FUC_TO_NUMBER		,TO			,DEF_ZOK_BINA,0,4,cl_cmpt_to_number
	,"TO_BULK"		,1,D_FUC_TO_BULK		,TO			,DEF_ZOK_BULK,9,2,cl_cmpt_to_bulk
	,"TO_BULKS"		,1,D_FUC_TO_BULKS		,TO			,DEF_ZOK_BULK,9,2,cl_cmpt_to_bulks
	,"TO_CHAR"		,1,D_FUC_TO_CHAR		,TO			,DEF_ZOK_CHAR,0,1,cl_func_to_char
	,"TO_DATE"		,1,D_FUC_TO_DATE		,TO			,DEF_ZOK_DATE,0,1,cl_func_to_date
	,"DATE_ADD"		,3,D_FUC_DATE_ADD		,TO			,DEF_ZOK_DATE,0,1,cl_func_date_add
	,"DATE_DIFF"	,3,D_FUC_DATE_DIFF		,TO			,DEF_ZOK_DATE,0,1,cl_func_date_diff
	,"ADD_MONTHS"	,2,D_FUC_ADD_MONTHS		,TO			,DEF_ZOK_DATE,0,1,cl_func_add_months
	,"LAST_DAY"		,1,D_FUC_LAST_DAY		,TO			,DEF_ZOK_DATE,0,1,cl_func_last_day
	,"ADD_TO_DATE"	,3,D_FUC_ADD_TO_DATE	,TO			,DEF_ZOK_DATE,0,1,cl_func_add_to_date
	,"SET_DATE_PART",3,D_FUC_SET_DATE_PART	,TO			,DEF_ZOK_DATE,0,1,cl_func_set_date_part
	,"TO"			,2,D_FUC_TO				,TO			,DEF_ZOK_CHAR,2,6,cl_cmpt_to
	,"LIKE"			,2,D_FUC_LIKE			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iLIKE"		,2,D_FUC_ILIKE			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"REGEX"		,2,D_FUC_REGEX			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iREGEX"		,2,D_FUC_IREGEX			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"MAX"			,1,D_FUC_MAX			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"MIN"			,1,D_FUC_MIN			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"SUM"			,1,D_FUC_SUM			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"AVG"			,1,D_FUC_AVG			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"ABS"			,1,D_FUC_ABS			,MATH		,DEF_ZOK_BINA,0,5,cl_cmpt_math
	,"LENG"			,1,D_FUC_LEN			,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_lenm	/* 2-->3*/
	,"LENGTH"		,1,D_FUC_LEN			,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_lenm	/* 2-->3*/
	,"LENB"			,1,D_FUC_LENB			,FUNCTION	,DEF_ZOK_BINA,0x8d,3,cl_lenm	/* 2-->3*/
	,"LENW"			,1,D_FUC_LENW			,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_lenw	/* 2-->3*/
	,"REP"			,2,D_FUC_REP			,STRING		,DEF_ZOK_CHAR,10,2,replace
	,"CONDAS"		,2,D_FUC_CONDAS			,STRING		,DEF_ZOK_CHAR,10,2,condas
	,"SUBSTR"		,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x0b,2,substrm
	,"SUBSTRB"		,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x8b,2,substrm
	,"MID"			,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x0b,2,substrm
	,"MIDB"			,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x8b,2,substrm
	,"CONCAT"		,1,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat
	,"&+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat
	,"|+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat
	,"GETARGS"		,2,D_FUC_GETARGS		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_get_args	/* 2-->3*/
	,"GETWORD"		,2,D_FUC_GETWORD		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_get_word	/* 2-->3*/
	,"SPLIT"		,2,D_FUC_SPLIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_split
	,"AND"			,1,D_FUC_AND			,LOGICAL	,DEF_ZOK_BINA,0,0,NULL
	,"OR"			,1,D_FUC_OR				,LOGICAL	,DEF_ZOK_BINA,0,0,NULL
	,"EQ"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"NE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"GT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"GE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"LT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"LE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iEQ"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iNE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iGT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iGE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iLT"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iLE"			,2,D_FUC_EQ				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"IN"			,2,D_FUC_IN				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iIN"			,2,D_FUC_IIN			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INSTR"		,2,D_FUC_INSTR			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INiSTR"		,2,D_FUC_INISTR			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INrSTR"		,2,D_FUC_INRSTR			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INirSTR"		,2,D_FUC_INIRSTR		,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"SKIP_OPT"		,2,D_FUC_SKIP_OPT		,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"TRIM"			,1,D_FUC_TRIM			,STRING		,DEF_ZOK_CHAR,1,2,cl_trim
	,"STRINGS"		,2,D_FUC_STRINGS		,STRING		,DEF_ZOK_CHAR,1,2,cl_strings
	,"LEFT"			,2,D_FUC_LEFT			,STRING		,DEF_ZOK_CHAR,0x0d,2,cl_leftm
	,"LEFTB"		,2,D_FUC_LEFTB			,STRING		,DEF_ZOK_CHAR,0x8d,2,cl_leftm
	,"RIGHT"		,2,D_FUC_RIGHT			,STRING		,DEF_ZOK_CHAR,0x0d,2,cl_rightm
	,"RIGHTB"		,2,D_FUC_RIGHTB			,STRING		,DEF_ZOK_CHAR,0x8d,2,cl_rightm
	,"RPAD"			,2,D_FUC_RPAD			,STRING		,DEF_ZOK_CHAR,0x0e,2,cl_rlpad
	,"LPAD"			,2,D_FUC_LPAD			,STRING		,DEF_ZOK_CHAR,0x0e,2,cl_rlpad
	,"RPADB"		,2,D_FUC_RPADB			,STRING		,DEF_ZOK_CHAR,0x8e,2,cl_rlpad
	,"LPADB"		,2,D_FUC_LPADB			,STRING		,DEF_ZOK_CHAR,0x8e,2,cl_rlpad
	,"CHR"			,1,D_FUC_CHR			,STRING		,DEF_ZOK_CHAR,1,2,cl_chr
	,"ASC"			,1,D_FUC_ASC			,STRING		,DEF_ZOK_BINA,0x0d,3,cl_asc	/* 2-->3 */
	,"ASCB"			,1,D_FUC_ASCB			,STRING		,DEF_ZOK_BINA,0x8d,3,cl_asc	/* 2-->3 */
	,"EDIT"			,2,D_FUC_EDIT			,STRING		,DEF_ZOK_CHAR,1,2,cl_edit
	,"EEDIT"		,2,D_FUC_EEDIT			,STRING		,DEF_ZOK_CHAR,1,2,cl_eedit
	,"REPLACE"		,3,D_FUC_REPLACE		,STRING		,DEF_ZOK_CHAR,1,2,cl_replace
	,"REPCHAR"		,3,D_FUC_REPCHAR		,STRING		,DEF_ZOK_CHAR,1,2,cl_repchar
	,"REPSTRS"		,4,D_FUC_REPSTRS		,STRING		,DEF_ZOK_CHAR,1,2,cl_repstrs
	,"REPLIKE"		,3,D_FUC_REPLIKE		,STRING		,DEF_ZOK_CHAR,1,2,cl_rep_like
	,"REPREGEX"		,3,D_FUC_REPREGEX		,STRING		,DEF_ZOK_CHAR,1,2,cl_rep_regex
	,"SHSBS"		,2,D_FUC_SHSBS			,STRING		,DEF_ZOK_CHAR,0,1,cl_shsbs
	,"GLIP"			,2,D_FUC_GLIP			,STRING		,DEF_ZOK_CHAR,0,1,cl_glip
	,"GREP"			,2,D_FUC_GREP			,STRING		,DEF_ZOK_CHAR,0,1,cl_grep
	,"INLIKE"		,4,D_FUC_INLIKE			,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_in_like	/* 2-->3 */
	,"INREGEX"		,4,D_FUC_INREGEX		,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_in_regex
	,"STR_ADD"		,2,D_FUC_STR_ADD		,STRING		,DEF_ZOK_CHAR,2,1,cl_func_str_add
	,"STR_EXP"		,3,D_FUC_STR_EXP		,STRING		,DEF_ZOK_CHAR,2,1,cl_func_str_exp
	,"STR_CONV"		,1,D_FUC_STR_CONV		,STRING		,DEF_ZOK_CHAR,0,1,cl_func_str_conv	/* 1,2-->0,1 */
	,"FOPEN"		,1,D_FUC_FOPEN			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FCLOSE"		,1,D_FUC_FCLOSE			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FGETLINE"		,1,D_FUC_FGETLINE		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"FPUTLINE"		,1,D_FUC_FPUTLINE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FELREAD1"		,2,D_FUC_FELREAD1		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"FELWRITE"		,2,D_FUC_FELWRITE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FELWRITE1"	,2,D_FUC_FELWRITE1		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"UNLINK"		,1,D_FUC_UNLINK			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"POPEN"		,1,D_FUC_POPEN			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"PCLOSE"		,1,D_FUC_PCLOSE			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"GETLINE"		,0,D_FUC_GETLINE		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"PUTLINE"		,0,D_FUC_PUTLINE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"ELREAD1"		,1,D_FUC_ELREAD1		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"ELWRITE"		,1,D_FUC_ELWRITE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"ELWRITE1"		,1,D_FUC_ELWRITE1		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"OPENDIR"		,1,D_FUC_OPENDIR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"READDIR"		,1,D_FUC_READDIR		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"CLOSEDIR"		,1,D_FUC_CLOSEDIR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"STAT"			,1,D_FUC_STAT			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FPSTAT"		,1,D_FUC_FPSTAT			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"GETCHAR"		,0,D_FUC_GETCHAR		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"PUTCHAR"		,1,D_FUC_PUTCHAR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"GETC"			,1,D_FUC_GETC			,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"PUTC"			,2,D_FUC_PUTC			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"SYSLOG"		,2,D_FUC_SYSLOG			,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"LOGOUT"		,2,D_FUC_LOGOUT			,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"GETLOGPARM"	,2,D_FUC_GETLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"SETLOGPARM"	,2,D_FUC_SETLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"RESLOGPARM"	,1,D_FUC_RESLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"SHELL"		,1,D_FUC_SHELL			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_shell	/* 2-->3*/
	,"NOFREE"		,0,D_FUC_NOFREE			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_no_free	/* 2-->3*/
	,"SHUTCTL"		,0,D_FUC_SHUTCTL		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_shut_ctl	/* 2-->3*/
	,"EXIT"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_exit	/* 2-->3*/
	,"BYE"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_exit	/* 2-->3*/
	,"QUIT"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_exit	/* 2-->3*/
	,"SETENV"		,2,D_FUC_SETENV			,FUNCTION	,DEF_ZOK_BINA,2,2,cl_func_env
	,"UNSETENV"		,1,D_FUC_UNSETENV		,FUNCTION	,DEF_ZOK_BINA,2,2,cl_func_env
	,"PUTENV"		,1,D_FUC_PUTENV			,FUNCTION	,DEF_ZOK_BINA,2,2,cl_func_env
	,"GETENV"		,1,D_FUC_GETENV			,FUNCTION	,DEF_ZOK_CHAR,2,2,cl_func_env
	,"GETTIME"		,0,D_FUC_GETTIME		,FUNCTION	,DEF_ZOK_DECI,0,1,cl_func_get_time
	,"EVAL"			,1,D_FUC_EVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_eval
	,"ECMD"			,1,D_FUC_ECMD			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_ecmd
	,"NVAL"			,2,D_FUC_NVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nval
	,"NULLIF"		,2,D_FUC_NVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nval
	,"NSVAL"		,2,D_FUC_NSVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nsval
	,"NDEF"			,1,D_FUC_NDEF			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_ndef
	,"DECODE"		,3,D_FUC_DECODE			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_decode
	,"IIF"			,3,D_FUC_IIF			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_iif
	,"XHASH"		,2,D_FUC_XHASH			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_xhash	/* 2-->3*/
	,"CHANNEL"		,2,D_FUC_CHANNEL		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_channel	/* 2-->3*/
	,"GETMEMUSED"	,0,D_FUC_GETMEMUSED		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_func_mem_used	/* 2-->3 */
	,"LPRINT"		,0,D_FUC_LPRINT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"PRINT"		,0,D_FUC_PRINT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"ECHO"			,0,D_FUC_ECHO			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"SAY"			,0,D_FUC_ECHO			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"FPRINT"		,0,D_FUC_FPRINT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print
	,"SPRINT"		,0,D_FUC_SPRINT			,FUNCTION	,DEF_ZOK_CHAR,2,2,cl_func_sprint
	,"PRINTF"		,0,D_FUC_PRINTF			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_printf
	,"FPRINTF"		,0,D_FUC_FPRINTF		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_printf

	,"$"			,0,D_FUC_DOL			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm
	,"#"			,0,D_FUC_IGE			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm
	,"%"			,0,D_FUC_PAS			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm
	,"FF"			,1,D_FUC_TO_FUNC		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_func_f
	,"SETARRAY"		,3,D_FUC_SET_ARRAY		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_set_array	/* 2-->3*/
	,"ARRAYCLR"		,1,D_FUC_ARRAY_CLR		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYCPY"		,3,D_FUC_ARRAY_CPY		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYCMP"		,3,D_FUC_ARRAY_CMP		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYBXP"		,3,D_FUC_ARRAY_BXP		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYMAP"		,2,D_FUC_ARRAY_MAP		,FUNCTION	,DEF_ZOK_BULK,0,1,cl_array_map
	,"SET_ARRAY"	,3,D_FUC_SET_ARRAY		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_set_array	/* 2-->3*/
	,"SET_STRUCT"	,2,D_FUC_SET_STRUCT		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_func_set_struct
	,"COUNTV"		,1,D_FUC_COUNT			,FUNCTION	,DEF_ZOK_BINA,7,3,cl_func_count
	,"FL"			,1,D_FUC_LIST			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_func_list
	,"LIST"			,1,D_FUC_SET_LIST		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_set_list
	,"APPEND"		,1,D_FUC_SET_LIST		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_set_list
	,"FIRST"		,1,D_FUC_FIRST			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_ope_list
	,"REST"			,1,D_FUC_REST			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_ope_list
	,"CONS"			,1,D_FUC_CONS			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_cons_list
	,"LIST_REF"		,1,D_FUC_LIST_REF		,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_ope_list
	,"INDEXA"		,2,D_FUC_INDEX			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_func_index	/* 2-->3*/
	,"SORT"			,2,D_FUC_SORT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_sort	/* 2-->3*/
	,"ROUND"		,1,D_FUC_ROUND			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_ex_round
	,"NEW"			,1,D_FUC_NEW			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_new
	,"TIMES"		,0,D_FUC_TIMES			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_times
	,"GETVAL"		,2,D_FUC_GETVAL			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_getval
	,"RANGE"		,2,D_FUC_RANGE			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_range
	,"COMPLEX"		,2,D_FUC_COMPLEX		,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_complex
	,"REDIRECT"		,1,D_FUC_REDIRECT		,FUNCTION	,DEF_ZOK_BINA,0,1,cl_func_redirect
	,"DEC_MAX_PRE"	,0,D_FUC_DEC_PRE		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_func_dec_max_pre

	,"SQRT"			,1,D_FUC_SQRT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SIN"			,1,D_FUC_SIN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"COS"			,1,D_FUC_COS			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"TAN"			,1,D_FUC_TAN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ASIN"			,1,D_FUC_ASIN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ACOS"			,1,D_FUC_ACOS			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ATAN"			,1,D_FUC_ATAN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ATAN2"		,2,D_FUC_ATAN2			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"LN"			,1,D_FUC_LOG			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"LOG"			,1,D_FUC_LOG			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"LOG10"		,1,D_FUC_LOG10			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"EXP"			,1,D_FUC_EXP			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"POWER"		,2,D_FUC_POWER			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"RAND1"		,0,D_FUC_RAND1			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SRAND1"		,1,D_FUC_SRAND1			,FUNCMATH	,0			 ,0,0,NULL
	,"DRAND48"		,0,D_FUC_RAND1			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SRAND48"		,1,D_FUC_SRAND1			,FUNCMATH	,0			 ,0,0,NULL
	,"CBRT"			,1,D_FUC_CBRT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SINH"			,1,D_FUC_SINH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"COSH"			,1,D_FUC_COSH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"TANH"			,1,D_FUC_TANH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ATANH"		,1,D_FUC_ATANH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"RINT"			,1,D_FUC_RINT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"FLOOR"		,1,D_FUC_FLOOR			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"CEIL"			,1,D_FUC_CEIL			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL

	,"CCHAR"		,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL
	,"CSTRING"		,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL
	,"CSTR"			,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL
	,"CINT"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CBIN"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CLONG"		,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CLNG"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CFLOAT"		,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CFLT"			,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CDOUBLE"		,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CDBL"			,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CDEC"			,1,D_FUC_CDEC			,FUNCCAST	,DEF_ZOK_DECI,0,0,NULL
	,"CDECIMAL"		,1,D_FUC_CDEC			,FUNCCAST	,DEF_ZOK_DECI,0,0,NULL
	,"CBULK"		,1,D_FUC_CBULK			,FUNCCAST	,DEF_ZOK_BULK,0,0,NULL
	,"CDATE"		,1,D_FUC_CDATE			,FUNCCAST	,DEF_ZOK_DATE,0,0,NULL
	,"CVARI"		,1,D_FUC_CVARIANT		,FUNCCAST	,DEF_ZOK_VARI,0,0,NULL
	,"CVARIANT"		,1,D_FUC_CVARIANT		,FUNCCAST	,DEF_ZOK_VARI,0,0,NULL

	,NULL,0,0,0,0,0,0,NULL
	};
static int max_tOpeTbl=0;

/****************************************/
/*										*/
/****************************************/
static tdtInfoParm **_mv_pnam_parm(nparm,ppParm0)
int nparm;
tdtInfoParm *ppParm0[];
{
	int i,j,i1;
	tdtInfoParm *pInfoParm,*pInfo,**ppParm;

	if (nparm > 1) {
		j = 0;
		for (i=0;i<nparm;i++) {
			pInfoParm = ppParm[i];
			if (pInfoParm->pi_id == D_DATA_ID_PNAME) j++;
		}
/*
printf("_mv_pnam_parm: nparm=%d j=%d\n",nparm,j);
*/
		if (!j || j==nparm) return ppParm0;
		if (!(ppParm=(tdtInfoParm **)cl_tmp_const_malloc(sizeof(tdtInfoParm *)*nparm))) return NULL;
		i1 = 0;
		j = nparm - j;
		for (i=0;i<nparm;i++) {
/*
printf("_mv_pnam_parm: i1=%d j=%d\n",i1,j);
*/
			pInfoParm = ppParm0[i];
			if (pInfoParm->pi_id == D_DATA_ID_PNAME)
				ppParm[j++] = pInfoParm;
			else
				ppParm[i1++] = pInfoParm;
		}
	}
	return ppParm;
}

/****************************************/
/*										*/
/****************************************/
char *cl_get_func_name(no,parm)
int no,parm[];
{
	qOpeTable *pot;
	char *p;

	if (!max_tOpeTbl) cl_get_func_info("X",NULL);
	if (no>=0 && no<max_tOpeTbl) {
		pot = &tOpeTbl[no];
		p = pot->name;
		if (parm) {
			parm[0] = pot->mpara;
			parm[1] = pot->ope;
			parm[2] = pot->kubun;
			parm[3] = pot->reta;
			parm[4] = no;
		}
	}
	else p = "";
	return p;
}

/****************************************/
/*										*/
/****************************************/
qOpeTable *cl_get_func_info(pName,parm)
char *pName;
int  parm[];
{
	static XHASHB *xhp=NULL;
	static int iTry=1;
	qOpeTable *pot,**ppot;
	char *p,w[2];
	int i,len,ii,*pii;

	if (iTry && !xhp) {
		if (xhp=akxs_xhash_new2(0,200,199,sizeof(qOpeTable *))) {
			xhp->xha_id[0] = 'h';
			for (ii=0,pot=&tOpeTbl[0];p=pot->name;ii++,pot++) {
				if ((i=akxs_xhash2(xhp,'S',p,&ii)) <= 0) {	/* �ۑ��������f�[�^��(ii)�ւ̃|�C���^��ݒ肷�� */
					akxs_xhash_free(xhp);
					xhp = NULL;
					break;
				}
			}
			max_tOpeTbl = ii;
		}
		iTry = 0;
	}
	mem_set_int(parm,0,5);
	if (xhp) {
		if ((i=akxs_xhash2(xhp,'R',pName,&pii)) > 0) {	/* �ۑ����ꂽ�f�[�^��ւ̃|�C���^��Ԃ��G���A(pii)�̃|�C���^��ݒ肷�� */
			ii = *pii;
			pot = &tOpeTbl[ii];
			if (parm) {
				parm[0] = pot->mpara;
				parm[1] = pot->ope;
				parm[2] = pot->kubun;
				parm[3] = pot->reta;
				parm[4] = ii;
			}
/*
printf("cl_get_func_info: pName=[%s] i=%d\n",pName,i);
*/
			return pot;
		}
	}
	if ((len=strlen(pName)) > 1) {
		if (akxnskipin(pName,len,"$%#") >= len) {
			w[0] = *pName;
			w[1] = '\0';
			return cl_get_func_info(w,parm);
		}
	}

	return NULL;
}

/****************************************/
/*										*/
/****************************************/
char *cl_get_func_info_ope(func_ope,parm)
int func_ope;
int parm[];
{
	qOpeTable *pot;
	char *p;
	int ii;
	short ope;

	ope = func_ope;
	for (ii=0,pot=&tOpeTbl[0];p=pot->name;ii++,pot++) {
		if (pot->ope == ope) {
			if (parm) {
				parm[0] = pot->mpara;
				parm[1] = pot->ope;
				parm[2] = pot->kubun;
				parm[3] = pot->reta;
				parm[4] = ii;
			}
			break;
		}
	}
	if (!p) p = "";
	return p;
}

/****************************************/
/*										*/
/****************************************/
/* arg_kbn
	0	exfunc(pInfoParmW,nparm,ppParm);
	1	exfunc(&pWork,nparm,ppParm);
	2	exfunc(&pWork,pOperator,nparm,ppParm,ope,opt);
	7	exfunc(pWork,nparm,ppParm,0);
	9	exfunc(&pWork,nparm,ppParm,iParm);
   10	rep_condas(&pWork,nparm,ppParm,exfunc);
   11	substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
   12	concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
   13	exfunc(&pWork,mflg,nparm,ppParm);
   14	exfunc(&pWork,mflg,nparm,ppParm,ope,pOperator);
   16	cl_gx_copy_info(pInfoParmW, pInfoParm1);
	9	cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
   18	cl_cmpt_math(iMPA,pOperator,pInfoParm1,pInfoParm2,iParm);
*/
/* ret_kbn
	0
	1	exfunc(pInfoParmW,nparm,ppParm);
	2	exfunc(&pWork,nparm,ppParm);
	3	exfunc(pWork,nparm,ppParm);
	4	cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
	5	ABS()
	6	if ((rc=cl_cmpt_to(&pWork,pOperator,nparm,ppParm,ope,opt)) > 0)
*/
int cl_gx_func_bexp(pInfoParmW,pOperator,nparm,ppParm,opt,pParm)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *pParm,*ppParm[];
int nparm,opt;
{
	tdtInfoParm *pInfoParm1;
	tdtInfoParm *pInfoParm2;
	tdtInfoParm *pInfoParm3;
	int rc,ope,kubun,mflg,arg_kbn,ret_kbn;
	int dtlen,dtatr,scale,len,iParm[5],iVal,iAULN;
	long lValz[NMPA_LONG],*lVal;
	char *pWork,*p,c;
	qOpeTable *pot;
	ScrPrCT	  *pScCT;
	int  (*exfunc)();
/*
printf("cl_gx_func_bexp:func=[%s] nparm=%d\n",pOperator,nparm);
*/
	ope = 0;
	if (!(pGlobTable->options[7] & 0x01)) {
		rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
		if (rc != ECL_NOT_FOUND_FUNC) return rc;
	}
	if ((c=*pOperator)>='0' && c<='9') {
		if (pot = &tOpeTbl[atoi(pOperator)])
			pOperator = pot->name;
	}
	else pot = cl_get_func_info(pOperator,iParm);
	if (pot) {
		if (nparm < pot->mpara/*iParm[0]*/) {
			/* �֐�(%s)�̈���������܂���B */
			ERROROUT1(FORMAT(211),pOperator);
			return ECL_SCRIPT_ERROR;
		}
		ope   = pot->ope;	/*iParm[1];*/
		kubun = pot->kubun;	/*iParm[2];*/
		dtatr = pot->reta;	/*iParm[3];*/
		arg_kbn = pot->arg_kbn;
		ret_kbn = pot->ret_kbn;
		exfunc = pot->func;
	}

DEBUGOUTL5(161,"cl_gx_func_bexp:func=[%s] nparm=%d ope=%d kubun=%d dtatr=%d",
pOperator,nparm,ope,kubun,dtatr);

	if (!ope) {
		if (pGlobTable->options[7] & 0x01) {
			rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
			if (rc != ECL_NOT_FOUND_FUNC) return rc;
		}
		/* [%s]�͊֐��ł͂���܂���B */
		ERROROUT1(FORMAT(212),pOperator);
		return ECL_SCRIPT_ERROR;
	}

	pInfoParm1 = ppParm[0];
	if (nparm >= 2) pInfoParm2 = ppParm[1];
	else pInfoParm2 = NULL;
	scale = 0x40;
	pWork = (char *)&(pInfoParmW->pi_pos);
	mem_set_int(iParm,0,5);
	dtlen = 0;
	mflg = pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX;
	if (arg_kbn & 0x80) mflg = 0;
	arg_kbn &= 0x7f;
	iAULN = 0;	/* add 2022.7.2 */
	cl_parm_set0(pInfoParmW);	/* add 2021.9.14 */

	gtIter_ctl[0].itc_circ_ref = NULL;
	gtIter_ctl[1].itc_circ_ref = NULL;

#if 1	/* 2022.10.19 */
	ppParm = _mv_pnam_parm(nparm,ppParm);
#endif
if (exfunc == NULL) {
	if (kubun == FUNCFILE) {
		pGlobTable->err_no = 0;
		iParm[0] = 0;
		if ((rc = func_file(&pWork,pOperator,nparm,ppParm,ope,iParm)) > 0)
			dtatr = rc;

DEBUGOUTL5(161,"cl_gx_func_bexp: rc=%d iParm[1]..[4]=%d %d %d %d",rc,iParm[1],iParm[2],iParm[3],iParm[4]);

		if (rc==ECL_END_OF_FILE || rc==ECL_IN_ERROR) cl_null_data(pInfoParmW);
	/*	pInfoParmW->pi_alen = iParm[2];	 del 2021.9.13 */
		/* add 2022.7.2 */
		if (ope==D_FUC_FOPEN || ope==D_FUC_POPEN || ope==D_FUC_OPENDIR)
			iAULN = iParm[D_IPARM_FLAG] & D_AULN_FILE_POINTER;	/* D_AULN_FILE_POINTER�������Ă��� */
	}
	else if (kubun == COMP) {
		if ((rc = cl_func_comp(&pWork,pOperator,nparm,ppParm,ope)) > 0)
			dtatr = rc;
	}
	else if (kubun == FUNCMATH) {
		return func_math2(pInfoParmW,pOperator,nparm,ppParm,ope);
	}
	else if (kubun == FUNCLOG) {
		pGlobTable->err_no = 0;
		if (ope == D_FUC_GETLOGPARM)
			rc = func_get_log_parm(pWork,nparm,ppParm);
		else if (ope == D_FUC_SETLOGPARM)
			rc = func_set_log_parm(pWork,nparm,ppParm);
		else if (ope == D_FUC_RESLOGPARM)
			rc = func_res_log_parm(pWork,nparm,ppParm);
		else
			rc = func_log(pWork,pOperator,nparm,ppParm,ope);
	}
	else if (kubun == FUNCCAST) {
		return cl_func_conv(pInfoParmW,ope,pOperator,nparm,ppParm);
	}
	else if (kubun == LOGICAL) {
		if ((rc = cl_func_logic(&pWork,pOperator,nparm,ppParm,ope)) > 0)
			dtatr = rc;
	}
	else {
			/* [%s]�͎�������Ă��܂���B */
			ERROROUT1(FORMAT(213),pOperator);
			return ECL_SCRIPT_ERROR;
	}
}
else if (ret_kbn <= 2) {
	if (ret_kbn == 1) {
		if (arg_kbn <= 1)
			rc = exfunc(pInfoParmW,nparm,ppParm);
		else	/* arg_kbn == 2 */
			rc = exfunc(pInfoParmW,pOperator,nparm,ppParm,ope,opt);
		return rc;
	}
	else {	/* ret_kbn == 2 */
		if (arg_kbn <= 10) {
			if (arg_kbn <= 2) {
				if (arg_kbn <= 1)
					rc = exfunc(&pWork,nparm,ppParm);
				else	/* arg_kbn == 2 */
					rc = exfunc(&pWork,pOperator,nparm,ppParm,ope,opt);
				if (!pWork) dtatr = 0;
			}
			else if (arg_kbn <= 9)
				rc = exfunc(&pWork,nparm,ppParm,iParm);
			else	/* arg_kbn == 10 */
				rc = rep_condas(&pWork,nparm,ppParm,exfunc);
		}
		else if (arg_kbn <= 12) {
			if (arg_kbn == 11) {
				if (nparm >= 3) pInfoParm3 = &pParm[2];
				else pInfoParm3 = NULL;
				rc = substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
			}
			else	/* arg_kbn <= 12 */
				rc = concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
		}
		else if (arg_kbn == 13)
			rc = exfunc(&pWork,mflg,nparm,ppParm);
		else	/* arg_kbn == 14 */
			rc = exfunc(&pWork,mflg,nparm,ppParm,ope,pOperator);
	}
}
else if (ret_kbn <= 6) {
	if (ret_kbn == 3) {
			if (arg_kbn == 0)
				rc = exfunc(pWork,nparm,ppParm);
			else if (arg_kbn == 2)
				rc = exfunc(pWork,pOperator,nparm,ppParm,ope,opt);
			else if (arg_kbn == 7)
				rc = exfunc(pWork,nparm,ppParm,0);
			else	/*arg_kbn == 13 */
				rc = exfunc(pWork,mflg,nparm,ppParm);
	}
	else if (ret_kbn==4 || ret_kbn==5) {
		if (ret_kbn==5) {
	/*	case D_FUC_ABS:	*/
			if (nparm > 1) {
					/* %s: �]���ȃp�����[�^(nparm=%d)������܂��B*/
				ERROROUT2(FORMAT(267),"cl_gx_func_bexp",nparm);
				return ECL_SCRIPT_ERROR;
			}
			if (pInfoParm1->pi_attr == DEF_ZOK_DATE) {
				cl_gx_copy_info(pInfoParmW, pInfoParm1);
				return 0;
			}
			else pInfoParm2 = pInfoParm1;
		}
/*	case D_FUC_MOD:
	case D_FUC_TO_NUMBER:	*/
			lVal = cl_get_tmpMPA(lValz);
			if (ope == D_FUC_TO_NUMBER)
				rc = cl_cmpt_to_number(lVal,nparm,ppParm,iParm);
			else
				return cl_cmpt_math_info(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
#if 1	/* 2022.7.17 */
			pWork = (char *)lVal;
#else
			if (rc > 0) {
				dtatr = iParm[0];
				dtlen = iParm[1];
				iAULN = iParm[D_IPARM_FLAG] & D_AULN_OVERFLOW;	/* add 2022.7.2 *//* mod 2022.7.13 */
				if (dtlen < 0) dtlen = -dtlen;
				if (dtatr == DEF_ZOK_BINA) {
					if (dtlen == sizeof(int)) {
						memcpy(&iVal,lVal,sizeof(int));
						pInfoParmW->pi_pos = iVal;
						iParm[1] = dtlen = sizeof(long);
					}
					else
						memcpy(pWork,lVal,dtlen);
				}
				else if (dtatr == DEF_ZOK_FLOA) {
					memcpy(pWork,lVal,dtlen);
				}
				else if (dtatr == DEF_ZOK_DECI) {
					rc = cl_set_parm_mpa(pInfoParmW,lVal);
					pInfoParmW->pi_hlen = iParm[2];		/* precision */
					pInfoParmW->pi_pos  = iParm[3];		/* scale */
					if (iParm[1] < 0) pInfoParmW->pi_alen = D_AULN_OVERFLOW;
					else pInfoParmW->pi_alen = iAULN;
					return rc;
				}
			}
#endif
	}
	else {	/* ret_kbn==6 */
		if (arg_kbn == 2) {
			if ((rc=exfunc(&pWork,pOperator,nparm,ppParm,ope,opt)) > 0) {
				dtatr = rc;
				iParm[0] = dtatr;
			}
		}
	}
}
else {
/*
	switch (ope) {
	case D_FUC_DOL:
	case D_FUC_IGE:
	case D_FUC_PAS:
			return cl_func_conv_parm(pInfoParmW,nparm,ppParm,0,pOperator,opt);

	case D_FUC_TO_FUNC:
			return cl_func_f(pInfoParmW,nparm,ppParm);

	case D_FUC_LIST:
			return cl_func_list(pInfoParmW,nparm,ppParm);

	case D_FUC_SET_LIST:
			return cl_set_list(pInfoParmW,nparm,ppParm);

	case D_FUC_FIRST:
	case D_FUC_REST:
	case D_FUC_LIST_REF:
			return cl_ope_list(pInfoParmW,nparm,ppParm,ope,NULL,0);

	case D_FUC_CONS:
			return cl_cons_list(pInfoParmW,nparm,ppParm);

	case D_FUC_SET_ARRAY:
			rc = cl_set_array(pWork,nparm,ppParm);
			break;
	case D_FUC_ARRAY_CPY:
	case D_FUC_ARRAY_CLR:
	case D_FUC_ARRAY_CMP:
	case D_FUC_ARRAY_BXP:
			rc = cl_array_ope(pWork,nparm,ppParm,ope);
			break;
	case D_FUC_ARRAY_MAP:
			return cl_array_map(pInfoParmW,nparm,ppParm);

	case D_FUC_INDEX:
			rc = cl_func_index(pWork,nparm,ppParm);
			break;
	case D_FUC_COUNT:
			rc = cl_func_count(pWork,nparm,ppParm,0);
			break;
	case D_FUC_IS:
			rc = cl_cmpt_is(pWork,pOperator,nparm,ppParm);
			break;
	case D_FUC_ABS:
			if (pInfoParm1->pi_attr == DEF_ZOK_DATE) {
				cl_gx_copy_info(pInfoParmW, pInfoParm1);
				return 0;
			}
			else pInfoParm2 = pInfoParm1;
	case D_FUC_MOD:
	case D_FUC_TO_NUMBER:
			if (ope == D_FUC_TO_NUMBER)
				rc = cl_cmpt_to_number(iMPA,nparm,pParm,iParm);
			else
				rc = cl_cmpt_math(iMPA,pOperator,pInfoParm1,pInfoParm2);
			if (rc > 0) {
				dtatr = rc;
				if (dtatr == DEF_ZOK_BINA) {
					pInfoParmW->pi_pos  = iMPA[0];
				}
				else if (dtatr == DEF_ZOK_FLOA) {
					dtlen = sizeof(double);
					memcpy(&pInfoParmW->pi_pos,iMPA,dtlen);
				}
				else if (dtatr == DEF_ZOK_DECI) {
					return cl_set_parm_mpa(pInfoParmW,iMPA);
				}
			}
			break;
	case D_FUC_TO_BULK:
			rc = cl_cmpt_to_bulk(&pWork,nparm,ppParm,iParm);
			break;
	case D_FUC_TO_BULKS:
			rc = cl_cmpt_to_bulks(&pWork,nparm,ppParm,iParm);
			break;
	case D_FUC_TO_CHAR:
			rc = cl_func_to_char(&pWork,nparm,ppParm);
			break;
	case D_FUC_TO_DATE:
			return cl_func_to_date(pInfoParmW,nparm,ppParm);

	case D_FUC_DATE_ADD:
			return cl_func_date_add(pInfoParmW,nparm,ppParm);

	case D_FUC_DATE_DIFF:
			return cl_func_date_diff(pInfoParmW,nparm,ppParm);

	case D_FUC_ADD_MONTHS:
			return cl_func_add_months(pInfoParmW,nparm,ppParm);

	case D_FUC_LAST_DAY:
			return cl_func_last_day(pInfoParmW,nparm,ppParm);

	case D_FUC_SET_DATE_PART:
			return cl_func_set_date_part(pInfoParmW,nparm,ppParm);

	case D_FUC_TO:
			if ((rc = cl_cmpt_to(&pWork,pOperator,nparm,ppParm)) > 0) {
				dtatr = rc;
				iParm[0] = dtatr;
			}
			break;
	case D_FUC_REP:
			rc = rep_condas(&pWork,nparm,ppParm,replace);
			break;
	case D_FUC_CONDAS:
			rc = rep_condas(&pWork,nparm,ppParm,condas);
			break;
	case D_FUC_SUBSTRB:
			mflg = 0;
	case D_FUC_SUBSTR:
			if (nparm >= 3) pInfoParm3 = &pParm[2];
			else pInfoParm3 = NULL;
			rc = substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
			break;
	case D_FUC_CONCAT:
			rc = concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
			break;
	case D_FUC_GETARGS:
			rc = cl_get_args(pWork,nparm,ppParm);
			break;
	case D_FUC_GETWORD:
			rc = cl_get_word(pWork,nparm,ppParm);
			break;
	case D_FUC_TRIM:
			rc = cl_trim(&pWork,nparm,ppParm);
			break;
	case D_FUC_STRINGS:
			rc = cl_strings(&pWork,nparm,ppParm);
			break;
	case D_FUC_LEFTB:
			mflg = 0;
	case D_FUC_LEFT:
			rc = cl_leftm(&pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_RIGHTB:
			mflg = 0;
	case D_FUC_RIGHT:
			rc = cl_rightm(&pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_RPADB:
	case D_FUC_LPADB:
			mflg = 0;
	case D_FUC_RPAD:
	case D_FUC_LPAD:
			rc = cl_rlpad(&pWork,mflg,nparm,ppParm,ope,pOperator);
			break;
	case D_FUC_CHR:
			rc = cl_chr(&pWork,nparm,ppParm);
			break;
	case D_FUC_ASCB:
			mflg = 0;
	case D_FUC_ASC:
			rc = cl_asc(pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_EDIT:
			rc = cl_edit(&pWork,nparm,ppParm);
			break;
	case D_FUC_REPLIKE:
			rc = cl_rep_like(&pWork,nparm,ppParm);
			break;
	case D_FUC_SBS:
			rc = cl_sbs(&pWork,nparm,ppParm);
			break;
	case D_FUC_INLIKE:
			rc = cl_in_like(pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_LENB:
			mflg = 0;
	case D_FUC_LEN:
			rc = cl_lenm(pWork,mflg,1,ppParm);
			break;
	case D_FUC_SHELL:
			rc = cl_ex_shell(pWork,nparm,ppParm);
			break;
	case D_FUC_NOFREE:
			rc = cl_ex_no_free(pWork,nparm,ppParm);
			break;
	case D_FUC_SHUTCTL:
			rc = cl_ex_shut_ctl(pWork,nparm,ppParm);
			break;
	case D_FUC_EXIT:
			rc = cl_ex_exit(pWork,nparm,ppParm);
			break;
	case D_FUC_EVAL:
			return cl_ex_eval(pInfoParmW,nparm,ppParm);

	case D_FUC_NVAL:
			return cl_ex_nval(pInfoParmW,nparm,ppParm);

	case D_FUC_NDEF:
			return cl_ex_ndef(pInfoParmW,nparm,ppParm);

	case D_FUC_XHASH:
			rc = cl_ex_xhash(pWork,nparm,ppParm);
			break;
	case D_FUC_CHANNEL:
			rc = cl_ex_channel(pWork,nparm,ppParm);
			break;
	case D_FUC_SETENV:
	case D_FUC_UNSETENV:
	case D_FUC_PUTENV:
	case D_FUC_GETENV:
			rc = cl_func_env(&pWork,nparm,ppParm,ope,pOperator);
			if (!pWork) dtatr = 0;
			break;
	case D_FUC_SORT:
			rc = cl_ex_sort(pWork,nparm,ppParm);
			break;
	case D_FUC_GETTIME:
			return cl_func_get_time(pInfoParmW,nparm,ppParm);
	case D_FUC_ROUND:
			return cl_ex_round(pInfoParmW,nparm,ppParm);
	case D_FUC_DECODE:
			return cl_ex_decode(pInfoParmW,nparm,ppParm);

	case D_FUC_GETMEMUSED:
			rc = cl_func_mem_used(pWork,nparm,ppParm);
			break;
	case D_FUC_LPRINT:
	case D_FUC_PRINT:
	case D_FUC_ECHO:
			rc = cl_func_print(pWork,nparm,ppParm,ope);
			break;
	case D_FUC_NEW:
			return cl_func_new(pInfoParmW,nparm,ppParm);
	case D_FUC_TIMES:
			return cl_func_times(pInfoParmW,nparm,ppParm);
	case D_FUC_GETVAL:
			return cl_func_getval(pInfoParmW,nparm,ppParm);

	default:
*/
			/* [%s]�͎�������Ă��܂���B */
			ERROROUT1(FORMAT(213),pOperator);
			return ECL_SCRIPT_ERROR;
/*	}	*/

}
	if (rc < 0) return rc;
	if (pGlobTable->exception && pGlobTable->try_level>0) {
		if ((rc=pGlobTable->exception) > 0) rc = -rc;
		return rc;
	}
/*
printf("cl_gx_func_bexp: iParm=%d %d %d %d %d\n",iParm[0],iParm[1],iParm[2],iParm[3],iParm[4]);
*/
#if 1	/* 2022.7.17 */
	rc = cl_set_parm(pInfoParmW,pWork,dtatr,iParm);
#else
	rc = 0;
	if (iParm[0] > 0) {
#if 1	/* 2022.7.18 */
		rc = cl_set_parm(pInfoParmW,pWork,dtatr,iParm);
#else
		if (iParm[0] == DEF_ZOK_BINA) {
			if (iParm[1] != sizeof(long)) {
				memcpy(&iVal,pWork,sizeof(int));
				pInfoParmW->pi_pos = iVal;
			}
			dtlen = sizeof(long);
			if (iParm[D_IPARM_FLAG] & DEF_ZOK_USMASK) scale = D_DATA_UNSIGNED;
		}
		else if (iParm[0] == DEF_ZOK_DECI) {
			scale = 0;
			dtlen = sizeofMPA();
			pInfoParmW->pi_hlen = iParm[2];		/* precision */
			pInfoParmW->pi_pos  = iParm[3];		/* scale */
		}
		else if (iParm[0] == DEF_ZOK_FLOA) {
			dtlen = sizeof(double);
		}
		else {
			scale = 0;
			dtlen = iParm[1];
		}
#endif
	}
	else {
		if (dtatr == DEF_ZOK_BINA) {
#if 0	/* 2022.7.18 */
			memcpy(&iVal,pWork,sizeof(int));
			pInfoParmW->pi_pos = iVal;
#endif
			dtlen = sizeof(long);
		}
		else if (dtatr == DEF_ZOK_FLOA) dtlen = sizeof(double);
		else {
			scale = 0;
			if (dtatr == DEF_ZOK_CHAR) {
				if (pWork) dtlen = strlen(pWork);
			}
			else if (dtatr==DEF_ZOK_DECI || dtatr==DEF_ZOK_DATE) dtlen = sizeofMPA();
		}
#if 0	/* 2022.7.18 */
	}
#endif
	if (dtatr) {
		pInfoParmW->pi_id = ' ';
		pInfoParmW->pi_attr = dtatr;
		pInfoParmW->pi_scale= scale;
		pInfoParmW->pi_code = CLcommon.cDataCode;
		pInfoParmW->pi_dlen = dtlen;
		pInfoParmW->pi_data = pWork;
		pInfoParmW->pi_alen = iAULN;	/* 2022.7.2 iParm[D_IPARM_OVER];*/
	}
	else cl_null_parm(pInfoParmW);
#if 1	/* 2022.7.18 */
	}
#endif
#endif
DEBUGOUT_InfoParm(194,"cl_gx_func_bexp: dtatr=%d",pInfoParmW,dtatr,0);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_parm(pInfoParmW,pWork,dtatr,iParm)
tdtInfoParm *pInfoParmW;
char *pWork;
int dtatr,iParm[];
{
	int ret,iVal,dtlen,scale,precision,dec_scale,iSCA,iFLAG,iAULN,code_type;
	long lValue;
	double dValue;
	ParList2 par2;

	/* cl_gx_func_bexp()����Ă΂ꂽ�Ƃ��́ApWork �� pInfoParmW->pi_pos ���w���Ă���̂ŁA
	   �ŏ��� pInfoParmW �̓N���A�ł��Ȃ� */
	ret = iAULN = precision = dec_scale = scale = dtlen = code_type = 0;
	if (iParm[D_IPARM_ATTR] > 0) {
		dtatr = iParm[D_IPARM_ATTR];
		dtlen = iParm[D_IPARM_SIZE];
		iSCA  = iParm[D_IPARM_SCA];
		iFLAG = iParm[D_IPARM_FLAG] | (dtatr & DEF_ZOK_USMASK);
		dtatr &= DEF_ZOK_MASK;
		if (iFLAG & AKX_NUM_I) scale |= D_DATA_IMAGE;
		iAULN = iFLAG & (D_AULN_OVERFLOW | D_AULN_FILE_POINTER);
		if (dtatr == DEF_ZOK_BINA) {
			if (iFLAG & DEF_ZOK_USMASK) scale |= D_DATA_UNSIGNED;
		}
		else if (dtatr == DEF_ZOK_DECI) {
			precision = iParm[D_IPARM_PRE];	/* precision */
			dec_scale = iSCA;				/* scale */
		}
		else code_type = iParm[D_IPARM_PRE];
		if (dtlen < 0) dtlen = -dtlen;	/* ����͕s�v�Ǝv���邪�O�̂��ߎc�� */
	}
	else {
		dtatr &= DEF_ZOK_MASK;
		if (dtatr == DEF_ZOK_CHAR) {
			if (pWork) dtlen = strlen(pWork);
		}
		else if (dtatr == DEF_ZOK_BINA) dtlen = sizeof(long);
		else if (dtatr == DEF_ZOK_FLOA) dtlen = sizeof(double);
		else if (dtatr==DEF_ZOK_DECI || dtatr==DEF_ZOK_DATE) dtlen = sizeofMPA();
	}

	if (dtatr == DEF_ZOK_CHAR) {
		if ((ret=cl_sep_string_with_type(&par2,pWork,dtlen)) > 0) {
			code_type = par2.option;
			pWork = par2.par;
			dtlen = par2.parlen;
		}

printf("cl_set_parm: dtlen=%d code_type=%d\n",dtlen,code_type);

		ret = cl_set_parm_char2(pInfoParmW,pWork,dtlen,code_type);
	}
	else if (dtatr == DEF_ZOK_BINA) {
#if defined(_LP64)
		if (dtlen == sizeof(long)) {
			memcpy(&lValue,pWork,sizeof(long));
			cl_set_parm_long(pInfoParmW,lValue);
		}
		else {
			memcpy(&iVal,pWork,sizeof(int));
			cl_set_parm_int(pInfoParmW,iVal);
		}
#else
		memcpy(&lValue,pWork,sizeof(long));
		cl_set_parm_long(pInfoParmW,lValue);
#endif
	}
	else if (dtatr == DEF_ZOK_FLOA) {
		memcpy(&dValue,pWork,sizeof(double));
		ret = cl_set_parm_double(pInfoParmW,dValue);
	}
	else if (dtatr == DEF_ZOK_DECI) {
		ret = cl_set_parm_mpa(pInfoParmW,pWork);
		pInfoParmW->pi_hlen = precision;
		pInfoParmW->pi_pos  = dec_scale;
	}
	else if (dtatr == DEF_ZOK_DATE) {
		ret = cl_set_parm_date(pInfoParmW,pWork);
	}
	else if (dtatr) {
		pInfoParmW->pi_id = ' ';
		pInfoParmW->pi_attr = dtatr;
		pInfoParmW->pi_code = CLcommon.cDataCode;
		pInfoParmW->pi_dlen = dtlen;
		pInfoParmW->pi_data = pWork;
	}
	if (dtatr) {
		pInfoParmW->pi_scale|= scale;
		pInfoParmW->pi_alen |= iAULN;
	}
	else cl_null_parm(pInfoParmW);

DEBUGOUT_InfoParm(194,"cl_set_parm: dtatr=%d ret=%d",pInfoParmW,dtatr,ret);

	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_ex_method(pInfoParmW,pInfoParm1,optW,p2,len2)
tdtInfoParm *pInfoParmW,*pInfoParm1;
int optW;
char *p2;
int len2;
{
	tdtInfoParm *ppParm[2];

	ppParm[0] = pInfoParm1;
	return cl_gx_func_bexp(pInfoParmW,p2,1,ppParm,optW,pInfoParm1);
}

/****************************************/
/*										*/
/****************************************/
int cl_set_system_method(pInfoParmW,pInfoParm1,pInfoParm2,optW,p2,len2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
char *p2;
int len2;
{
	tdtInfoParm *pInfoParm;

	cl_gx_copy_info(pInfoParmW,pInfoParm2);
	if (!(pInfoParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
	cl_gx_rep_info_set_ign(pInfoParm,pInfoParm1,1);
	pInfoParmW->pi_hlen = (long)pInfoParm;

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_func_method(pInfoParmW,pInfoParmM,nparm,ppParm,opt,pParm)
tdtInfoParm *pInfoParmW,*pInfoParmM;
tdtInfoParm *pParm,*ppParm[];
int nparm,opt;
{
	tdtInfoParm *pParmW,**ppParmW,*pInfoParm,*ppParm0[1];
	int i,len,rc;
	Leaf *wkleaf,*nodeleaf;
	char *name,*p,id,c;
	ProcCT *cur_procct;
	ScrPrCT *pScCT;

DEBUGOUT_InfoParm(161,"cl_gx_func_method:pInfoParmM: nparm=%d opt=%08x",pInfoParmM,nparm,opt);
DEBUGOUT_InfoParm(161,"cl_gx_func_method:pInfoParmW:",pInfoParmW,0,0);

	p = pInfoParmW->pi_paux;
	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	pInfoParmW->pi_paux = p;
	if (pInfoParmM->pi_hlen) {
#if 1	/* 2021.4.27 */
/*
printf("cl_gx_func_method: nparm=%d pInfoParmM->pi_hlen=%08x\n",nparm,pInfoParmM->pi_hlen);
*/
		ppParm0[0] = pParm;
		ppParmW = ppParm0;
		if (rc=cl_gx_parm_conv_arg(NULL,1,nparm,NULL,NULL,0,&ppParmW,NULL)) return rc;
		ppParm = ppParmW;
		pParm = ppParm[0];
		cl_gx_copy_info(pParm,pInfoParmM->pi_hlen);
		nparm++;
#else
		nparm++;
		len = nparm*sizeof(tdtInfoParm);
		if (!(pParmW=(tdtInfoParm *)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
		memcpy(pParmW+1,pParm,len-sizeof(tdtInfoParm));
		cl_gx_copy_info(pParmW,pInfoParmM->pi_hlen);
		pParm = pParmW;
		len = nparm*sizeof(tdtInfoParm *);
		if (!(ppParmW=(tdtInfoParm **)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
		for (i=0;i<nparm;i++) ppParmW[i] = pParmW++;
		ppParm = ppParmW;
#endif
	}
/*
printf("cl_gx_func_method: pInfoParmM->pi_pos=%08x\n",pInfoParmM->pi_pos);
*/
	wkleaf = NULL;
	pInfoParm = NULL;
	name = pInfoParmM->pi_data;
	if (pInfoParmM->pi_pos & ~0x0f) {
		wkleaf = (Leaf *)pInfoParmM->pi_pos;
		nodeleaf = (Leaf *)pInfoParmM->pi_paux;
/*
if (wkleaf) {
printf("cl_gx_func_method: name=[%s] wkleaf=%08x nodeleaf=%08x pi_alen=%04x\n",
name,wkleaf,nodeleaf,pInfoParmM->pi_alen);
}
*/
	}
	if ((c=*name)=='$' || c=='%' || c=='#') {
		opt |= cl_gx_get_opt_from_aux1(pInfoParmM->pi_aux[1]);
	}
	else if (pInfoParmM->pi_pos != 1) {	/* '{}'�łȂ��֐��̂Ƃ��́A�֐����̃��[�J���ϐ����쐬���� */
		pInfoParm = pInfoParmW;
		pScCT = cl_search_src_ct();
		/* $�t���œo�^����邽�߁A�ϐ��Ƃ��Ă͎Q�Ƃł��Ȃ� */
		cl_gx_get_lg_var_ent(pScCT,'s',"",&pInfoParmW,stradd("$",name),D_GX_OPT_SET_LOCAL);
		cl_parm_set0(pInfoParmW);	/* add 2022.3.28 */
		pInfoParmW->pi_paux = p;	/* 2021.2.22 */
	}
	if (wkleaf && pInfoParmM->pi_alen==D_AULN_SET_POS_LEAF) {
		cur_procct = cl_search_proc_ct();
		rc = cl_exec_func_setup_proc(name,pInfoParmW,nparm,ppParm,wkleaf,nodeleaf,0,NULL);
		if (!rc) {
			rc = cl_exec_func_execute(cur_procct);
		}
		if ((id=pInfoParmW->pi_id)=='R' || id=='A') pInfoParmW->pi_hlen = cur_procct->ProcGid;
	}
	else {
		rc = cl_gx_func_bexp(pInfoParmW,pInfoParmM->pi_data,nparm,ppParm,opt,pParm);
	}
	if (pInfoParm) cl_gx_copy_info_opt(pInfoParm,pInfoParmW,1);
/*
printf("cl_gx_func_method: rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int rep_condas(pAns,nparm,ppParm,func)
char **pAns;
int nparm;
tdtInfoParm	*ppParm[];
int (*func)();
{
	tdtInfoParm *pInfoParm1,tInfoParm;
	tdtInfoParm *pInfoParm2;
	int  rc,len1,code_type;
	char *p1;
	ParList3 par3;

	pInfoParm1 = ppParm[0];
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			code_type = cl_get_char_code_type(pInfoParm1,1);
		/*	p1   = pInfoParm1->pi_data;
			len  = pInfoParm1->pi_dlen;	*/
			if ((rc=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"")) < 0) return rc;
			p1 = par3.par;
			len1 = par3.parlen;
			pInfoParm1 = &tInfoParm;
			cl_set_parm_char2(pInfoParm1,p1,len1,code_type);
			pInfoParm2 = ppParm[rc];
		}
	}
	return func(pAns,pInfoParm1,pInfoParm2);
}
