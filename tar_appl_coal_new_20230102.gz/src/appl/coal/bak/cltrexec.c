static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_exec                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_exec()
{
	int rc;
	char *p;
	qSubCommand *sc;

	if (CLcList.cmd.cid == C_CALL) {
		if ((rc=cl_tr_insert(0,"IP")) < 0) return rc;
		CLcList.cmd.cid = C_EXEC;
	}
	if ( CLcList.cmd.prmnum < 2 ) {
		ERROROUT1(FORMAT(42),"col_mn_tr_exec");
		return ( ECL_TR_EXEC );
	}

	p = CLcList.cmd.prmp[0]->prp;
#if 1
	if (!(sc = cl_tr_sc_set_scno(0,0x01,0x80))) {
#else
	if ( ( stricmp(p, "IP" ) != 0 )&&
		 ( stricmp(p, "EP" ) != 0 )&&
		 ( stricmp(p, "SC" ) != 0 )&&
		 ( stricmp(p, "SM" ) != 0 )) {
#endif
		ERROROUT1(FORMAT(86),p);	/* col_mn_tr_exec: �葱�����[%s]������Ă��܂��B */
		return ( ECL_TR_EXEC );
	}

	if (!(rc = cl_make_leaf())) rc = cl_push();

	return rc;
}
#if 0
/*********************************************/
/*                                           */
/*********************************************/
int ColMnTrInteractive()
{
	int rc;

	if (!(rc = cl_make_leaf())) rc = cl_push();

	return rc;
}
#endif
