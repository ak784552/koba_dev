static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************************
*																				*
*	�����ړI	�F	��r���Z����												*
*																				*
*	�֐���		�F	int cl_cmpt_comp(pAns , pOprtr , pInfoParm1 , pInfoParm2)	*
*						(O)int	*pAns											*
*						(I)char	*pOprtr											*
*						(I)tdtInfoParm *pInfoParm1								*
*						(I)tdtInfoParm *pInfoParm2								*
*																				*
*	�߂�l		�F	ERROR														*
*					NORMAL														*
*																				*
*	�����T�v	�F																*
*																				*
*********************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];

static char *Enzan[]={
	"EQ","iEQ","==","",
	"NE","iNE","!=","<>","><","",
	"GT",">","",
	"LT","<","",
	"GE",">=","=>","",
	"LE","<=","=<","",
	"LIKE","iLIKE","",
	"IN","iIN","",
	"INSTR","INiSTR","INrSTR","INirSTR","",
	"REGEX","iREGEX","",
	"SKIP_OPT","",
	NULL};
static unsigned char jg[6][3]={
	{0,1,0},
	{1,0,1},
	{0,0,1},
	{1,0,0},
	{0,1,1},
	{1,1,0}};

/********************************************/
/* opt : 0x01 : �G���[���b�Z�[�W���o�͂���B*/
/*       0x10 : LIKE�ȍ~�����Z�q�Ƃ���B	*/
/* �ԋp : >=0 : ���Z�q����					*/
/*        < 0 : ���Z�q�Ȃ�					*/
/********************************************/
int _get_comp_no(pOprtr,opt)
char *pOprtr;
int opt;
{
	int i,opr;
	opr = akxs_seqr_str(Enzan,-1,pOprtr,0x11);
	if (!(opt & 0x10) && opr>=7) opr = 0;
	if (!opr) {
#if 1
		if (opt & 0x01) {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
		}
#endif
		opr = -1;
	}
	else opr--;
	return opr;
}
/*
	opt : 0x0001 : ignore case
	      0x4000 : comp string
*/
int _memcmplen(p1,len1,p2,len2,opt)
char *p1,*p2;
int  len1,len2,opt;
{
	int result;

	if (opt & 0x4000)
		return akxmbncmp_opt(p1,len1,p2,len2,opt & ~0x4000);
	else if (!len1 && !len2) result = 0;
	else if(len1 < len2) {
		if (!(result = memcmp(p1,p2,len1)))
			result = -1;
	}
	else if(len1 > len2) {
		if (!(result = memcmp(p1,p2,len2)))
			result = 1;
	}
	else
		result = memcmp(p1,p2,len1);
	return result;
}

static int _comp_array(pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)
long *pAns;
char *pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
int cmp_opt;
{
	tdtInfoParm *ppParm[6],Info,Info1;

	cl_set_parm_char(&Info1,pOprtr,strlen(pOprtr));
	cl_null_parm(&Info);
	ppParm[0] = pInfoParm1;
	ppParm[1] = &Info;
	ppParm[2] = pInfoParm2;
	ppParm[3] = &Info;
	ppParm[4] = &Info;
	ppParm[5] = &Info1;
	return cl_array_ope_opt(pAns,6,ppParm,D_FUC_ARRAY_CMP,cmp_opt);
}

int cl_cmpt_comp(ppAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp)
char		**ppAns;
char		*pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
int			narg;
parmList    *prmp[];
{
	return cl_cmpt_comp_opt(ppAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp,0);
}

/****************************************************/
/* cmp_opt : DEF_ZOK_DATA : �f�[�^���[�h�ɂ���B	*/
/****************************************************/
int cl_cmpt_comp_opt(ppAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp,cmp_opt)
char **ppAns,*pOprtr;
tdtInfoParm *pInfoParm1,*pInfoParm2;
int narg,cmp_opt;
parmList *prmp[];
{
	int    rc,atr1,atr2,result,len1,len2,like,opt,mflg,flags[2];
	long   Val1z[NMPA_LONG],Val2z[NMPA_LONG],*Val1,*Val2;
	long   Value1,Value2,*pAns;
	ulong  uValue1,uValue2;
	int    ope,parm[5],nparm,iDATA1,iDATA2,iUNSIGNED1,iUNSIGNED2;
	double dVal1,dVal2;
	char   *dat1,*dat2,id1,id2,*pStr;
	char   errbuf[256];
	MPA *mpa1,*mpa2,*mpa,ma1z,ma2z,*ma1,*ma2;
	tdtInfoParm **ppParm,*pParm,InfoParmW,*ppParm0[PM_MAX];

	int opr,i;
/*
printf("cl_cmpt_comp: pOprtr=[%s] cmp_opt=%08x\n",pOprtr,cmp_opt);
*/
DEBUGOUT_InfoParm(110,"cl_cmpt_comp:1: pOprtr=[%s] narg=%d",pInfoParm1,pOprtr,narg);
DEBUGOUT_InfoParm(110,"cl_cmpt_comp:2:",pInfoParm2,0,0);

#if 0
	if (cl_check_data_id(pInfoParm1,0x04)<0 ||
	    cl_check_data_id(pInfoParm2,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
#endif
	pStr = *ppAns;
	pAns = (long *)pStr;
	*pAns = 0;
	rc = NORMAL;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;

	if (!id1 || !id2) {
		if ((opr=_get_comp_no(pOprtr,1)) < 0) return ECL_SCRIPT_ERROR;
		result = id1 - id2;
		if (result<0) i = 0;
		else if (result>0) i = 2;
		else i = 1;
		*pAns = jg[opr][i];
		return DEF_ZOK_BINA;
	}

	opr = _get_comp_no(pOprtr,0);
/*
printf("cl_cmpt_comp: opr=%d id1=[%c] id2=[%c]\n",opr,id1,id2);
*/
	len1 = pInfoParm1->pi_dlen;
	len2 = pInfoParm2->pi_dlen;
	if (opr<0 && id1==' ' && strchr(" RALN",id2)) ;
#if 1	/* 2021.11.24 */
	else if ((id1==' ' && len1==0) || (id2==' ' && len2==0)) ;
#endif
	else if (id1 != id2) {
		/* �p�����[�^�̃f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B */
		ERROROUT2(FORMAT(241),id1,id2);
		return ECL_SCRIPT_ERROR;
	}
	if (cmp_opt & DEF_ZOK_DATA) {
		iDATA1 = 1;
		iDATA2 = 1;
	}
	else {
		iDATA1 = pInfoParm1->pi_aux[0] & DEF_ZOK_DATA;
		iDATA2 = pInfoParm2->pi_aux[0] & DEF_ZOK_DATA;
	}
	atr1 = pInfoParm1->pi_attr;
	atr2 = pInfoParm2->pi_attr;
	dat1 = pInfoParm1->pi_data;
	dat2 = pInfoParm2->pi_data;
  if (id1 == ' ') {
	iUNSIGNED1 = iUNSIGNED2 = 0;
	if (atr1 == DEF_ZOK_BINA) iUNSIGNED1 = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
	if (atr2 == DEF_ZOK_BINA) iUNSIGNED2 = pInfoParm2->pi_scale & D_DATA_UNSIGNED;
	if (opr >= 0) {
		if ((atr1==DEF_ZOK_CHAR && !len1) || (atr2==DEF_ZOK_CHAR && !len2) ||
		    (atr1==atr2) ||
		    ((atr1==DEF_ZOK_BINA || atr1==DEF_ZOK_FLOA || atr1==DEF_ZOK_DECI || atr1==DEF_ZOK_DATE) &&
		     (atr2==DEF_ZOK_BINA || atr2==DEF_ZOK_FLOA || atr2==DEF_ZOK_DECI || atr2==DEF_ZOK_DATE))) {
			;
		}
		else if (!(pGlobTable->options[1] & 0x01) && atr1!=DEF_ZOK_BULK && atr2!=DEF_ZOK_BULK) {
			if (atr1 == 1) {
				pInfoParm1 = &InfoParmW;
				if ((rc=cl_conv_const_n_str(&InfoParmW, dat1, len1)) < 0) return rc;
				atr1 = pInfoParm1->pi_attr;
				len1 = pInfoParm1->pi_dlen;
				dat1 = pInfoParm1->pi_data;
			}
			else if (atr2 == 1) {
				pInfoParm2 = &InfoParmW;
				if ((rc=cl_conv_const_n_str(&InfoParmW, dat2, len2)) < 0) return rc;
				atr2 = pInfoParm2->pi_attr;
				len2 = pInfoParm2->pi_dlen;
				dat2 = pInfoParm2->pi_data;
			}
		}
		else {
/*
printf("cl_cmpt_comp: attr1 = %d, attr2 = %d\n",atr1,atr2);
*/
			/* �p�����[�^�̌^(attr1=%d attr2=%d)�������Ă��܂���B */
			ERROROUT2(FORMAT(242),atr1,atr2);
			return ECL_SCRIPT_ERROR;
		}

		if ((atr1 == DEF_ZOK_BINA || atr1 == DEF_ZOK_FLOA || atr1==DEF_ZOK_DECI) &&
		    (atr2 == DEF_ZOK_BINA || atr2 == DEF_ZOK_FLOA || atr2==DEF_ZOK_DECI)) {
			if (len1==0 || dat1==NULL) {
				ERROROUT1(FORMAT(243),FORMAT(248));	/* ���p�����[�^���k���ł��B */
			 	return ECL_SCRIPT_ERROR;
			}
			if (len2==0 || dat2==NULL) {
				ERROROUT1(FORMAT(243),FORMAT(249));	/* ���p�����[�^���k���ł��B */
			 	return ECL_SCRIPT_ERROR;
			}
			mpa1 = (MPA *)dat1;
			mpa2 = (MPA *)dat2;
			if (atr1 == DEF_ZOK_BINA) {
				Value1 = cl_get_data_long(pInfoParm1);
				uValue1 = Value1;
			}
			else if (atr1 == DEF_ZOK_FLOA)
				memcpy(&dVal1, dat1, sizeof(double));
			if (atr2 == DEF_ZOK_BINA) {
				Value2 = cl_get_data_long(pInfoParm2);
				uValue2 = Value2;
			}
			else if (atr2 == DEF_ZOK_FLOA)
				memcpy(&dVal2, dat2, sizeof(double));
			if (atr1 == DEF_ZOK_FLOA || atr2 == DEF_ZOK_FLOA) {
				if (atr1 == DEF_ZOK_BINA) {
					if (iUNSIGNED1) dVal1 = uValue1;
					else dVal1 = Value1;
				}
				else if (atr1 == DEF_ZOK_DECI) m_dset(&dVal1,mpa1);
				if (atr2 == DEF_ZOK_BINA) {
					if (iUNSIGNED2) dVal2 = uValue2;
					else dVal2 = Value2;
				}
				else if (atr2 == DEF_ZOK_DECI) m_dset(&dVal2,mpa2);
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) dVal1 = X_MAX(dVal1,dVal2);
					else if (!stricmp(pOprtr,"MIN")) dVal1 = X_MIN(dVal1,dVal2);
					else return -1;
					memcpy(pAns,&dVal1,sizeof(double));
					return DEF_ZOK_FLOA;
				}
				else {
					if (dVal1 == dVal2)
						result = 0;
					else if (dVal1 > dVal2)
						result = 1 ;
					else
						result = -1;
				}
			}
			else if (atr1 == DEF_ZOK_DECI || atr2 == DEF_ZOK_DECI/* ||
			         (atr1==DEF_ZOK_DATE && atr2==DEF_ZOK_DATE)*/) {
				Val1 = cl_get_tmpMPA(Val1z);
				Val2 = cl_get_tmpMPA(Val2z);
				if (atr1 == DEF_ZOK_BINA) {
					mpa1 = (MPA *)Val1;
					m_l2mpau(Value1,mpa1,iUNSIGNED1);
				}
				if (atr2 == DEF_ZOK_BINA) {
					mpa2 = (MPA *)Val2;
					m_l2mpau(Value2,mpa2,iUNSIGNED2);
				}
				result = m_cmp(mpa1,mpa2);
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) mpa = result>0 ? mpa1: mpa2;
					else if (!stricmp(pOprtr,"MIN")) mpa = result<0 ? mpa1: mpa2;
					else return -1;
					memcpy(pAns,mpa,sizeofMPA());
					return DEF_ZOK_DECI;
				}
			}
			else {
				if (toupper(*pOprtr) == 'M') {
					if (iUNSIGNED1 | iUNSIGNED2) {
						if (!stricmp(pOprtr,"MAX")) Value1 = X_MAX(uValue1,uValue2);
						else if (!stricmp(pOprtr,"MIN")) Value1 = X_MIN(uValue1,uValue2);
						else return -1;
					}
					else {
						if (!stricmp(pOprtr,"MAX")) Value1 = X_MAX(Value1,Value2);
						else if (!stricmp(pOprtr,"MIN")) Value1 = X_MIN(Value1,Value2);
						else return -1;
					}
					*pAns = Value1;
					return DEF_ZOK_BINA;
				}
				else {
					if ( Value1 == Value2 )
						result = 0;
					else if ( Value1 > Value2 )
						result = 1;
					else
						result = -1;
				}
			}
		}
		else if (atr1==DEF_ZOK_DATE || atr2==DEF_ZOK_DATE) {
			ma1 = (MPA *)cl_get_tmpMPA(&ma1z);
			ma2 = (MPA *)cl_get_tmpMPA(&ma2z);
			if ((rc=cl_get_parm_date(pInfoParm1,ma1,"CMP DATE1")) < 0) return rc;
			if ((rc=cl_get_parm_date(pInfoParm2,ma2,"CMP DATE2")) < 0) return rc;
			result = _memcmplen(ma1->num,ma1->len,ma2->num,ma2->len,0);
			if (toupper(*pOprtr) == 'M') {
				if (!stricmp(pOprtr,"MAX")) mpa = result>0 ? ma1: ma2;
				else if (!stricmp(pOprtr,"MIN")) mpa = result<0 ? ma1: ma2;
				else return -1;
				memcpy(pAns,mpa,sizeofMPA());
				return DEF_ZOK_DATE;
			}
		}
		else {	/* CHAR */
			if (!stricmp(pOprtr,"iEQ") || !stricmp(pOprtr,"iNE")) opt = 1;
			else opt = 0;
/*
printf("cl_cmpt_comp: opt=%d\n",opt);
*/
			result = _memcmplen(dat1,len1,dat2,len2,opt | 0x4000);
		}
	}
	else {
/*
printf("op=[%s] len1=%d s1=[%.*s] len2=%d s2=[%.*s]\n",pOprtr,
pInfoParm1->pi_dlen,pInfoParm1->pi_dlen,pInfoParm1->pi_data,
pInfoParm2->pi_dlen,pInfoParm2->pi_dlen,pInfoParm2->pi_data);
*/
#if 1	/* 2021.8.4 */
		if (stricmp(pOprtr,"IN") && stricmp(pOprtr,"iIN")) {
			if (atr1 != 1) {
				if ((len1=parm_to_char_tmp(pInfoParm1,&dat1,0)) < 0) return len1;
			}
			if (atr2 != 1) {
				if ((len2=parm_to_char_tmp(pInfoParm2,&dat2,0)) < 0) return len2;
			}
		}
#endif
#if 1	/* 2021.4.23 �֐����Ă΂��悤�ɕύX in cl_gx_bexp() *//* 2021.4.25 ���ɖ߂� */
		mflg = (pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX) ? 0x04 : 0;
		opt = 0;
		if (!stricmp(pOprtr,"LIKE")||(opt=!stricmp(pOprtr,"iLIKE"))) {
			rc = akxs_xlike(dat1,len1,dat2,len2,opt);
			if (rc < 0) return rc;
			else if (rc > 0) result = 0;	/* unmatch */
			else result = 1;	/* match */
			*pAns = result;
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"IN")||(opt=!stricmp(pOprtr,"iIN"))) {
			if (cl_get_func_info(pOprtr,parm)) {
				ope = parm[1];
				if ((rc=cl_gx_parm_conv_arg(NULL,2,narg,prmp,NULL,0,&ppParm,NULL)) < 0) return rc;
				ppParm[0] = pInfoParm1;
				ppParm[1] = pInfoParm2;
				nparm = narg + 2;
				atr1 = cl_func_comp(ppAns,pOprtr,nparm,ppParm,ope);
			}
			else atr1 = ECL_SCRIPT_ERROR;
		}
		else if (!stricmp(pOprtr,"INSTR")||(opt=!stricmp(pOprtr,"INiSTR"))) {
/*
printf("cl_cmpt_comp: opt=%d\n",opt);
*/
			*pAns = akxs_in_mem_opt(dat1,len1,dat2,len2,opt+mflg);
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"INrSTR")||(opt=!stricmp(pOprtr,"INirSTR"))) {
/*
printf("cl_cmpt_comp: R opt=%d\n",opt);
*/
			*pAns = akxs_in_mem_opt(dat1,len1,dat2,len2,opt+2+mflg);
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"REGEX")||(opt=!stricmp(pOprtr,"iREGEX"))) {
			flags[0] = REG_EXTENDED;
			if (opt) flags[0] |= REG_ICASE;
			flags[1] = 0;
			if (*dat1 || !*dat2) {
				rc = akxs_regex(dat2,dat1,0,NULL,flags,sizeof(errbuf),errbuf);
/*
printf("cl_cmpt_comp: regex rc=%d\n",rc);
*/
				if (rc && rc!=REG_NOMATCH) {
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					return ECL_SCRIPT_ERROR;
				}
				else rc = rc ? 0 : 1;
			}
			else if (!strcmp(dat2,"()")) rc = 1;
			else rc = 0;
			*pAns = rc;
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"SKIP_OPT")) {
			opt = (pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX) ? 0x04 : 0;
			rc = akx_skip_opt(dat1,len1,dat2,opt|0x08);
			len1 = akxqmlen(dat1,len1);
			if (rc >= len1) rc = 0;
			else rc++;
			*pAns = rc;
			atr1 = DEF_ZOK_BINA;
		}
		else {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
			atr1 = ECL_SCRIPT_ERROR;
		}
		return atr1;
#endif
#if 0
		if (!stricmp(pOprtr,"iEQ") || !stricmp(pOprtr,"iNE")) opt = 1;
		else opt = 0;
/*
printf("cl_cmpt_comp: opt=%d\n",opt);
*/
		result = _memcmplen(dat1,len1,dat2,len2,opt | 0x4000);
#endif
	}
  }
  else if (id1=='L' || id1=='N') {
		parm[0] = parm[1] = 0;
		parm[2] = -1;
		if ((rc=cl_comp_list(pOprtr,pInfoParm1,pInfoParm2,parm,cmp_opt)) >= 0) {
			*pAns = rc;
			rc = DEF_ZOK_BINA;
		}
		return rc;
  }
  else if ((id1=='A' || id1=='R') && (id2=='A' || id2=='R') && iDATA1 && iDATA2) {
		if ((rc=_comp_array(pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)) >= 0)
			 rc = DEF_ZOK_BINA;
		return rc;
  }
  else {
		if (opr < 0) {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
			*pAns = 0;
			return ECL_SCRIPT_ERROR;
		}
		opt = 0;
		result = _memcmplen(dat1,len1,dat2,len2,opt);
  }
	if (result<0) i = 0;
	else if (result>0) i = 2;
	else i = 1;
	*pAns = jg[opr][i];
/*
printf("cl_cmpt_comp: opr=%d, result=%d\n",opr,result);
*/

	return DEF_ZOK_BINA;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_comp(ppWork,pOperator,nparm,ppParm,ope)
char **ppWork;
char *pOperator;
tdtInfoParm **ppParm;
int nparm,ope;
{
	tdtInfoParm *pInfoParm,tInfoParm;
	int  i,len1,len2,iRc,pos[2],attr,opt,pos_min,pos_max,lenm,i1,optw;
	char *pWork;
	char ww[64],*pp[2],*pp0,*p,c;
	int  rc,atr1,atr2,iAttr[3],result,iVal,Val1[2];
	long lVal1z[NMPA_LONG],lVal2z[NMPA_LONG],*lVal1,*lVal2;
	long Value1,Value2;
	double  dValue1,dValue2,dVal;
	char    op;
	char    errbuf[256];
	MPA     *mpa1,*mpa2,*mpa,ma1z,ma2z,*ma1,*ma2;
	parmList pList;
/*
printf("cl_func_comp: pOperator=[%s] ope=%d nparm=%d\n",pOperator,ope,nparm);
*/
	pGlobTable->error = 0;
	pWork = *ppWork;
	iRc = attr = opt = 0;
	pInfoParm = ppParm[0];
	if (cl_check_data_id(pInfoParm,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
	if (ope==D_FUC_IN && pInfoParm->pi_id==' ' && ((atr1=pInfoParm->pi_attr)>=2 && atr1<=4)) {
		iRc = cl_in_number(ppWork,pInfoParm,nparm-1,ppParm+1,0);
		return iRc;
	}
	lVal1 = cl_get_tmpMPA(lVal1z);
	lVal2 = cl_get_tmpMPA(lVal2z);
	switch (ope) {
	case D_FUC_ILIKE:
		opt++;
	case D_FUC_LIKE:
/*
printf("cl_func_comp: opt=%d nparm=%d\n",opt,nparm);
*/
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,pp,&len1,NULL,NULL,"LIKEs")) < 0) return i1;
		if (i1 < nparm-1) {
			pInfoParm = ppParm[nparm-1];
			if (pInfoParm->pi_attr == DEF_ZOK_BINA) {
				opt |= cl_get_data_int(pInfoParm) & 0x03;
				nparm--;
/*
printf("cl_func_comp:LIKE: i1=%d opt=%d nparm=%d\n",i1,opt,nparm);
*/
			}
		}
		for (i=i1;i<nparm;i++) {
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) goto Err;
			len2 = iRc;
			if ((iRc=akxs_xlike(pp[0],len1,pp[1],len2,opt))<0)
				goto Err;
/*
printf("cl_func_comp: i=%d iRc=%d\n",i,iRc);
*/
			if (!iRc) break;
		}
		iRc = iRc ? 0 : i-i1+1;
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	case D_FUC_INIRSTR:
		opt++;
	case D_FUC_INRSTR:
		opt++;
	case D_FUC_INISTR:
	case D_FUC_IIN:
		opt++;
	case D_FUC_INSTR:
	case D_FUC_IN:
		opt += (pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX) ? D_COMP_OPT_NEW_LEX : 0;
		if (ope==D_FUC_IIN || ope==D_FUC_IN) opt += D_COMP_FUN_IN;
#if 1	/* 2021.5.29 */
		iRc = cl_in_string(ppWork,nparm,ppParm,opt);
#else
/*
printf("cl_func_comp: opt=%d\n",opt);
*/
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,pp,&len1,&lenm,pos,"INSTRs")) < 0) return i1;
		if (i1 < nparm-1) {
			pInfoParm = ppParm[nparm-1];
			if (pInfoParm->pi_attr == DEF_ZOK_BINA) {
				optw = cl_get_data_int(pInfoParm);
				opt |= (optw & 0x01) | ((optw & 0x02)<<4);
				nparm--;
/*
printf("cl_func_comp:IN: i1=%d opt=%d nparm=%d\n",i1,opt,nparm);
*/
			}
		}
		pp0 = pp[0];
#if 0	/* 2020.12.29 */ /* pp0�������Ƃ��́A�r���ň�v�����ꍇ�A�S�ϊ������ʂɂȂ� */
		if (opt & 0x20) {
			if (!(p=cl_tmp_const_malloc(len1*4+1))) return ECL_MALLOC_ERROR;
			if ((len1=akxctozen(len1,pp0,p)) < 0) return -1;
			pp0 = p;
		}
		if (opt & 0x01) {
			if (!(p=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
			if ((len1=akxcuppern(p,pp0,len1)) < 0) return -1;
			pp0 = p;
		}
#endif
		pos_min = lenm + 1;
		pos_max = 0;
		for (i=i1;i<nparm;i++) {
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) goto Err;
			len2 = iRc;
			if ((iRc=akxs_in_mem_opt(pp0,len1,pp[1],len2,opt)) < 0) goto Err;
/*
printf("cl_func_comp: i=%d iRc=%d\n",i,iRc);
*/
			if (iRc) {
				if (opt & 0x08) {
					pos_max = i - i1 + 1;
					break;
				}
				else {
					if (iRc < pos_min) pos_min = iRc;
					if (iRc > pos_max) pos_max = iRc;
				}
			}
		}
/*
printf("cl_func_comp: nparm=%d i1=%d opt=%d pos=%d lenm=%d pos_min=%d pos_max=%d\n",
nparm,i1,opt,pos[0],lenm,pos_min,pos_max);
*/
		if (opt & 0x08) {
			pos_min = pos_max;
		}
		else {
			if (opt & 0x02) pos_min = pos_max;
			else if (pos_min == lenm+1) pos_min = 0;
			if (!(pGlobTable->options[17] & 0x01) && pos_min) pos_min += pos[0] - 1;
		}
		memcpy(pWork,&pos_min,sizeof(int));
		*ppWork = pWork;
		iRc = DEF_ZOK_BINA;
#endif
		break;
	case D_FUC_MAX:
	case D_FUC_MIN:
	case D_FUC_SUM:
	case D_FUC_AVG:
#if 1	/* 2021.7.27 */
		if ((iRc = cl_func_agg(&tInfoParm,nparm,ppParm,ope)) > 0) {
			if (iRc==DEF_ZOK_CHAR || iRc==DEF_ZOK_BULK || iRc==DEF_ZOK_DATE || iRc==DEF_ZOK_DECI)
				*ppWork = tInfoParm.pi_data;
			else memcpy(pWork,tInfoParm.pi_data,tInfoParm.pi_dlen);
		}
		else if (!iRc) iRc = ECL_SYSTEM_ERROR;
#else
		pInfoParm = ppParm[0];
		attr = pInfoParm->pi_attr;
		if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_FLOA || attr==DEF_ZOK_DECI) {
			if ((rc=cl_get_parm_mpa(pInfoParm,lVal1,"Parm1:",iAttr)) < 0)
				return rc;
			else if (rc > 0) return ECL_SCRIPT_ERROR;
			atr1 = iAttr[0];
			if (atr1 == DEF_ZOK_BINA) Value1 = lVal1[0];
			else if (atr1 == DEF_ZOK_FLOA)
				memcpy(&dValue1,lVal1,sizeof(double));
			else if (atr1 == DEF_ZOK_DECI) mpa1 = (MPA *)lVal1;
			else return ECL_SCRIPT_ERROR;
			for (i=1;i<nparm;i++) {
				if ((rc=cl_get_parm_mpa(ppParm[i],lVal2,"Parm1:",iAttr)) < 0)
					return rc;
				else if (rc > 0) return ECL_SCRIPT_ERROR;
				atr2 = iAttr[0];
				if (atr2 == DEF_ZOK_BINA) Value2 = lVal2[0];
				else if (atr2 == DEF_ZOK_FLOA)
					memcpy(&dValue2,lVal2,sizeof(double));
				else if (atr2 == DEF_ZOK_DECI) mpa2 = (MPA *)lVal2;
				else return ECL_SCRIPT_ERROR;
				if (atr1 == DEF_ZOK_BINA) {
					if (atr2 == DEF_ZOK_FLOA) Value2 = cl_chk_over_flow_d2_l(dValue2,"cl_func_comp");
					else if (atr2 == DEF_ZOK_DECI) m_mpa2l(mpa2,&Value2);
					if (ope == D_FUC_MAX) {
						if (Value2 > Value1) Value1 = Value2;
					}
					else {
						if (Value2 < Value1) Value1 = Value2;
					}
				}
				else if (atr1 == DEF_ZOK_DECI) {
					mpa2 = (MPA *)lVal2;
					if (atr2 == DEF_ZOK_BINA) m_l2mpa(Value2,mpa2);
					else if (atr2 == DEF_ZOK_FLOA) m_d2mpa(dValue2,mpa2);
					result = m_cmp(mpa1,mpa2);
					if (ope == D_FUC_MAX) mpa = result>0 ? mpa1 : mpa2;
					else mpa = result<0 ? mpa1 : mpa2;
					if (mpa1 != mpa) memcpy(mpa1,mpa,sizeofMPA());
				}
				else {
					if (atr2 == DEF_ZOK_BINA) dValue2 = Value2;
					if (ope == D_FUC_MAX) {
						if (dValue2 > dValue1) dValue1 = dValue2;
					}
					else {
						if (dValue2 < dValue1) dValue1 = dValue2;
					}
				}
			}
			if (atr1 == DEF_ZOK_BINA) memcpy(pWork,&Value1,sizeof(long));
			else if (atr1 == DEF_ZOK_DECI) {
				if (!(pWork=cl_tmp_const_malloc(sizeofMPA()))) return ECL_MALLOC_ERROR;
				memcpy(pWork,mpa1,sizeofMPA());
				*ppWork = pWork;
/*
printf("cl_func_comp: atr1=%d\n",atr1);
*/
			}
			else memcpy(pWork,&dValue1,sizeof(double));
			iRc = atr1;
		}
		else if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_DATE) {
			if (attr==DEF_ZOK_CHAR) {
				iRc = parm_to_char_tmp(ppParm[0],&pp[0],0);
				len1 = iRc;
				opt = 0x4000;	/* 2020.2.22 Add */
			}
			else {
				mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
				mpa2 = (MPA *)cl_get_tmpMPA(&ma2z);
				iRc = cl_get_parm_date(ppParm[0],mpa1,"MAX/MIN");
				pp[0] = mpa1->num;
				len1 = mpa1->len;
/*
printf("cl_func_comp: len1=%d pp[0]=%08x\n",len1,pp[0]);
*/
			}
			if (iRc < 0) goto Err;
			for (i=1;i<nparm;i++) {
				if (attr==DEF_ZOK_CHAR) {
					iRc = parm_to_char_tmp(ppParm[i],&pp[1],0);
					len2 = iRc;
				}
				else {
					iRc = cl_get_parm_date(ppParm[i],mpa2,"MAX/MIN");
					pp[1] = mpa2->num;
					len2 = mpa2->len;
/*
printf("cl_func_comp: len2=%d pp[1]=%08x\n",len2,pp[1]);
*/
				}
				if (iRc < 0) goto Err;
				rc = _memcmplen(pp[0],len1,pp[1],len2,opt);	/* 2020.2.22 0-->opt */
				if (((ope==D_FUC_MAX) && (rc<0)) ||
				    ((ope==D_FUC_MIN) && (rc>0))) {
					pp[0] = pp[1];
					len1 = len2;
/*
printf("cl_func_comp: len1=%d pp[0]=%08x\n",len1,pp[0]);
*/
					if (attr==DEF_ZOK_DATE) {
						mpa = mpa2;
						mpa2 = mpa1;
						mpa1 = mpa;
					}
				}
			}
			if (attr==DEF_ZOK_CHAR) pWork = pp[0];
			else {
				if (!(pWork=cl_tmp_const_malloc(sizeofMPA()))) return ECL_MALLOC_ERROR;
				memcpy(pWork,mpa1,sizeofMPA());
/*
printf("cl_func_comp: attr=%d\n",attr);
*/
			}
			*ppWork = pWork;
			iRc = attr;
		}
		else {
			/* %s: �p�����[�^�̌^(%d)�������Ă��܂���B */
			ERROROUT2(FORMAT(285),"cl_func_comp",attr);
			return -1;
		}
#endif
		break;
	case D_FUC_IREGEX:
		opt++;
	case D_FUC_REGEX:
		Val1[0] = REG_EXTENDED;
		if (opt) Val1[0] |= REG_ICASE;
		Val1[1] = 0;
		pp[1] = &ww[32];
		if ((i1=cl_get_str_pos(nparm,ppParm,0,pp,&len1,NULL,NULL,"REGEXs")) < 0) return i1;
		pp0 = strmem(pp[0],len1);
/*
printf("cl_func_comp: opt=%1d Val1[0]=%02x pp0=[%s] len1=%d\n",opt,Val1[0],pp0,len1);
*/
		for (i=i1;i<nparm;i++) {
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) goto Err;
/*
printf("cl_func_comp:                  pp[%d]=[%s]\n",i,pp[1]);
*/
			if (*pp[0] || !*pp[1]) {
				iRc = akxs_regex(pp[1],pp0,0,NULL,Val1,sizeof(errbuf),errbuf);
/*
printf("cl_func_comp: regex iRc=%d\n",iRc);
*/
				if (iRc && iRc!=REG_NOMATCH) {
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					iRc = -1;
					goto Err;
				}
			}
			else if (!strcmp(pp[1],"()")) iRc = 0;
			else iRc = 1;
			if (!iRc) break;
		}
		iRc = iRc ? 0 : i-i1+1;
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	case D_FUC_SKIP_OPT:
		opt = (pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX) ? 0x04 : 0;
		opt |= 0x08;
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,pp,Val1,&lenm,pos,"SKIP_OPT")) < 0) return i1;
		if (nparm <= i1) {
			ERROROUT1(FORMAT(42),"cl_func_comp");	/* %s: �p�����[�^������܂���B*/
			iRc = ECL_SCRIPT_ERROR;
			goto Err;
		}
		if ((iRc=parm_to_char(ppParm[i1],&pp[1],NULL)) < 0) goto Err;
		Val1[1] = iRc;
/*
printf("cl_func_comp: skip_opt: pp[0]=[%s] Val1[0]=%d i1=%d pp[1]=[%s] Val1[1]=%d lenm=%d pos=%d\n",
pp[0],Val1[0],i1,pp[1],Val1[1],lenm,pos[0]);
*/
		i1++;
		if (nparm > i1) {
			pInfoParm = ppParm[i1];
			if (pInfoParm->pi_attr==DEF_ZOK_CHAR) {
				p = pInfoParm->pi_data;
				len1 = pInfoParm->pi_dlen;
				for (i=0;i<len1;i++) {
					c = toupper(*p++);
					if (c=='I') opt |= 0x01;
					else if (c=='R') opt |= 0x02;
					else if (c=='M') opt |= 0x04;
					else if (c=='B') opt &= ~0x04;
					else if (c=='T') opt |= 0x08;
					else if (c=='N') opt &= ~0x08;
				}
			}
			else {
				opt &= 0x04;
				if (iRc=cl_get_parm_bin(pInfoParm,&iVal,"skip_opt")) goto Err;
				opt |= iVal;
			}
/*
printf("cl_func_comp: skip_opt: opt=%08x\n",opt);
*/
		}
		iRc = akx_skip_opt(pp[0],Val1[0],pp[1],opt);
/*
printf("cl_func_comp: skip_opt: iRc=%d lenm=%d pos=%d\n",iRc,lenm,pos[0]);
*/
		pos[0]--;
		if (!(pGlobTable->options[17] & 0x08)) {
			iRc += pos[0];
			lenm += pos[0];
		}
		if (!(opt & 0x02)) {
			if ((opt & 0x08) && (iRc>=lenm)) iRc = 0;
			else iRc++;
		}
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	default:
		ERROROUT2("pOperator(%s)��ope(%d)���s���ł��B",pOperator,ope);
		return ECL_SCRIPT_ERROR;
	}
 Err:
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int _get_str_pos(pos,ppp0,plen1,plenm)
int pos[];
char **ppp0;
int *plen1,*plenm;
{
	static char null_str[2]={'\0','\0'};	/* 2021.7.28 add */
	parmList pList;
	char *pp0;
	int mflg,rc,len1,lenm;
/*
printf("cl_get_str_pos: pos=%d ppp0=%08x plen1=%08x plenm=%08x\n",
pos,ppp0,plen1,plenm);
*/
	if (pCLprocTable->CurScr)
		mflg = pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX;
	else mflg = 1;
	pp0 = *ppp0;
/*
printf("_get_str_pos:1: pp0=[%s]\n",pp0);
*/
	if (plen1) len1 = *plen1;
	else len1 = strlen(pp0);
	lenm = len1;
	if (lenm>0 && mflg) lenm = akxqmlen(pp0,len1);
	if (lenm > 0) {
		if (pos[0] <= 0) ;
		else if (pos[0] <= lenm) {
			if (pos[1] < 0) lenm -= pos[0] - 1;
			else lenm = pos[1];
			if (mflg) {
				len1 = substr_mlen(&pList,pp0,len1,pos[0],lenm);
				pp0 = pList.prp;
				if (plen1) *plen1 = len1;
			}
			else pp0 += pos[0] - 1;
			*ppp0 = pp0;
		}
		else {
			*ppp0 = null_str;	/* 2021.7.28 ""-->null_str */
			lenm = len1 = 0;
			if (plen1) *plen1 = len1;
		}
	}
	if (plenm) *plenm = lenm;
/*
printf("_get_str_pos: mflg=%08x len1=%d lenm=%d pos=%d\n",mflg,len1,lenm,pos[0]);
printf("_get_str_pos:2: *ppp0=%08x pp0=[%s]\n",*ppp0,pp0);
*/
	return 0;
}

/********1*********2*********3*********4*********5********6*********7/
/* �@�\ : �J�n�ʒu�ƒ��������߂�									*/
/* ���� : i         : �J�n�ʒu��Ԃ�pos�̈ʒu						*/
/*		              pInfoParm���͈͎w��̂Ƃ��́A0�Œ�			*/
/*		  pInfoParm : �p�����[�^�̃|�C���^							*/
/*		  pos       : pos[i] : �J�n�ʒu 							*/
/*		            : pos[1] : ���� (�͈͎w��̂Ƃ��̂ݐݒ�)		*/
/* �ԋp : ���^�[���R�[�h											*/
/*		  = 0 : ����												*/
/*		  < 0 : �G���[												*/
/* �쐬 : 20XX.XX.XX Akito Konayashi								*/
/* �X�V :															*/
/********************************************************************/
int _get_pos_len(i,pInfoParm,pos)
int i;
tdtInfoParm *pInfoParm;
int pos[];
{
	int rc;
	tdtInfoParm tInfoParm;

	if (pInfoParm->pi_id != ' ') return ECL_SYNTAX_ERROR;
	else if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) {
		if (i) {
			/* _get_pos: �͈͎w�肪�擪�ȊO�ɂ���܂��Bi=%d */
			ERROROUT1(FORMAT(250),i);
			return ECL_SCRIPT_ERROR;
		}
		if (rc=cl_get_parm_bin(pInfoParm,pos,"str_pos1")) return rc;
		cl_gx_copy_info(&tInfoParm,pInfoParm);
		if (tInfoParm.pi_attr == DEF_ZOK_BINA) tInfoParm.pi_pos = tInfoParm.pi_hlen;
		else tInfoParm.pi_data += tInfoParm.pi_dlen;
		if (rc=cl_get_parm_bin(&tInfoParm,&pos[1],"str_pos2")) return rc;
		pos[1] -= pos[0] - 1;
	}
	else {
		if (rc=cl_get_parm_bin(pInfoParm,&pos[i],"str_posi")) return rc;
	}
	return 0;
}

/********1*********2*********3*********4*********5********6*********7/
/* �@�\ : �u������[,�J�n�ʒu[,����]]�v�`������͂���				*/
/* ���� : nparm	 : �p�����[�^��										*/
/*		  ppParm : �p�����[�^�̃|�C���^�z��							*/
/*		  i1     : ������̃p�����[�^�ʒu(�擪��0)					*/
/*		  ppp0   : ������J�n�ʒu�̃|�C���^��Ԃ�					*/
/*		  plen1  : ����(�o�C�g)										*/
/*		  plenm  : ����(����) 										*/
/*		  ppos   : (������݂̂̂Ƃ��́A����)						*/
/*		           pos[0] : �J�n�ʒu(����)							*/
/*		         : pos[1] : ����(����)								*/
/*		  msg    : �Ăяo�����̃R�����g								*/
/* �ԋp : >0 : �u������,�J�n�ʒu[,������]�v�̎��̃p�����[�^�ʒu		*/
/*		  <0 : �G���[												*/
/* �쐬 : 20XX.XX.XX Akito Konayashi								*/
/* �X�V :															*/
/********************************************************************/
int cl_get_str_pos(nparm,ppParm,i1,ppp0,plen1,plenm,ppos,msg)
int nparm;
tdtInfoParm *ppParm[];
int i1;
char **ppp0;
int *plen1,*plenm,ppos[];
char *msg;
{
	tdtInfoParm *pInfoParm;
	int len1,lenm,rc,iGET,pos[2],mflg;
	char *pp0;

	if (nparm < i1+1) return -1;
	*ppp0 = NULL;
	if ((rc=parm_to_char(ppParm[i1],ppp0,NULL)) < 0) return rc;
	lenm = len1 = rc;
	i1++;
	pos[1] = -1;
	if (nparm >= i1+1) {
		if (!(pInfoParm = ppParm[i1])) return -2;
		if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_BINA) {
			if (rc=_get_pos_len(0,pInfoParm,pos)) return rc;
			i1++;
			iGET = 1;
			if (nparm >= i1+1) {
				if (!(pInfoParm = ppParm[i1])) return -111;
				if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_BINA) {
					if (rc=_get_pos_len(1,pInfoParm,pos)) return rc;
					i1++;
				}
			}
		}
		else {
			iGET = 0;
			pos[0] = 1;
		}
		if (ppos) {
			ppos[0] = pos[0];
			ppos[1] = pos[1];
		}
	}
	else {
		if (ppos) {
			pos[0] = ppos[0];
			pos[1] = ppos[1];
		}
		else  return -11;
		iGET = 1;
	}
	if (iGET) {
		if (rc=_get_str_pos(pos,ppp0,&len1,&lenm)) return rc;
	}
	else {
		mflg = pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX;
		if (len1>0 && mflg) lenm = akxqmlen(*ppp0,len1);
	}
	if (plen1) *plen1 = len1;
	if (plenm) *plenm = lenm;
	return i1;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_str_pos2(nparm,pParm,i1,ppp0,plen1,plenm,ppos,msg)
int nparm;
tdtInfoParm *pParm;
int i1;
char **ppp0;
int *plen1,*plenm,*ppos;
char *msg;
{
	tdtInfoParm *ppParm[3];
	int rc,pos[2];

	ppParm[0] = &pParm[0];
	ppParm[1] = &pParm[1];
	if (nparm > 2) ppParm[2] = &pParm[2];
	if (ppos) pos[0] = *ppos;
	pos[1] = -1;
	rc = cl_get_str_pos(nparm,ppParm,i1,ppp0,plen1,plenm,pos,msg);
	if (ppos) *ppos = pos[0];
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_str_pos(pInfoParmW,pInfoParm1,optW,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
{
	parmList pList;
	tdtInfoParm  tInfoParm,tInfoParm2[2],*pInfoParm;
	int pos[2],len1,rc,nparm,i,j;
	char *pp0,*p,c;

DEBUGOUTL1(161,"--->cl_gx_str_pos: optW=%08x",optW);
DEBUGOUT_InfoParm(161,"pInfoParm1:",pInfoParm1,0,0);
DEBUGOUT_InfoParm(161,"pInfoParm2:",pInfoParm2,0,0);

	if (pInfoParm1->pi_id != ' ') return ECL_SYNTAX_ERROR;

	if (pInfoParm2->pi_attr==DEF_ZOK_CHAR) {
		p = pInfoParm2->pi_data;
		len1 = pInfoParm2->pi_dlen;
		if (pInfoParm2->pi_alen & D_AULN_NAME_DATA) {
			memset(&pList,0,sizeof(parmList));
			pList.prp = p;
			pList.prmlen = len1;
			if ((rc=cl_conv_arg(&pList,&tInfoParm)) < 0) {
				if (rc != ECL_DEFINED_ARRAY) return rc;
			}
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos:1: rc=%d",&tInfoParm,rc,0);
*/
			if (rc == NAME_CONST) {
				pList.prp = tInfoParm.pi_data;
				pList.prmlen = tInfoParm.pi_dlen;
				if (rc = cl_conv_parm(&pList,&tInfoParm)) {
					if (rc != ECL_DEFINED_ARRAY) return rc;
				}
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos:2: rc=%d",&tInfoParm,rc,0);
*/
			}
			if (tInfoParm.pi_id != ' ') return ECL_SYNTAX_ERROR;
			pInfoParm2 = &tInfoParm;
		}
		else if ((c=*p)=='%' || c=='#' || c=='/') {
/*
printf("cl_gx_str_pos: p=[%s]\n",p);
*/
			return cl_gx_str_edit(pInfoParmW,pInfoParm1,p,len1);
		}
	}
	pos[1] = -1;
	if (pInfoParm2->pi_attr==DEF_ZOK_CHAR && !(pInfoParm2->pi_alen & D_AULN_RANGE_DATA)) {
		if (rc= cl_gx_exps_obj_opt(pInfoParm2->pi_data,NULL,NULL,tInfoParm2,D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE)) return rc;
		if ((tInfoParm2[0].pi_alen & D_AULN_PARMINFO2) &&
		    (nparm=X_MIN(tInfoParm2[1].pi_pos,2))) {
			pInfoParm = (tdtInfoParm *)tInfoParm2[1].pi_data;
		}
		else {
			nparm = 1;
			pInfoParm = tInfoParm2;
		}
		for (i=0;i<nparm;i++,pInfoParm++) {
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos: i=%d",pInfoParm,i,0);
*/
			if (rc=_get_pos_len(i,pInfoParm,pos)) return rc;
			if (pos[1] >= 0) break;
		}
	}
	else if (rc=_get_pos_len(0,pInfoParm2,pos)) return rc;

	if ((rc=cl_get_str_pos(1,&pInfoParm1,0,&pp0,&len1,NULL,pos,"str_pos")) < 0) return rc;
/*
printf("cl_gx_str_pos: len1=%d pos[0]=%d pp0=%08x\n",len1,pos[0],pp0);
*/
	*(pp0+len1) = '\0';
	cl_set_parm_char(pInfoParmW,pp0,len1);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_str_edit_like(ptext,len1,pat0,patlen0,c,c2)
char **ptext,*pat0,c,c2;
int len1,patlen0;
{
	tdtInfoParm pParm[2],*ppParm[2];
	tdtLike *plike;
	int iRc,patlen,iOpt[5];
	int pos[4],len[7],mflg,pos1;
	char *text,*p1[7],w1[128],*pat,*p;

	text = *ptext;
/*
printf("cl_gx_str_edit_like:Enter len1=%d text=[%s] patlen0=%d pat0=[%s] c2=[%c]\n",len1,text,patlen0,pat0,c2);
*/
	*pat0 = '%';
	patlen0++;
	akxtsrepc(pat0,'*','%');
	akxtsrepc(pat0,'?','_');
	if (c == '#') {
		pat0++;
		strcat(pat0,"%");
	}
	else {
		if (c2) c2 = '\0';
		else c2 = c;
	}
	mflg = 0;
	cl_set_parm_char(&pParm[0],text,len1);
	cl_set_parm_char(&pParm[1],pat0,patlen0);
	ppParm[0] = &pParm[0];
	ppParm[1] = &pParm[1];
	p1[0] = w1;
	plike = NULL;
	if (iRc=_get_line_pat(2,ppParm,p1,len,iOpt,pos,&plike,3)) return iRc;
/*
printf("cl_gx_str_edit_like: len=%d %d %d %d %d %d %d\n",len[0],len[1],len[2],len[3],len[4],len[5],len[6]);
*/
	patlen = len[4];
	pat = p1[4];
/*
printf("cl_gx_str_edit_like: patlen=%d pat=[%s] c2=[%c]\n",patlen,pat);
*/
	memset(pos,0,sizeof(int)*4);
	if (patlen > 0) {
		while (len1 > 0) {
/*
printf("cl_gx_str_edit_like: p1[0]=[%s] len[0]=%d\n",p1[0],len[0]);
*/
			if (!(iRc=akxs_pxlike(plike,pat,patlen))) {
/*
printf("cl_gx_str_edit_like: pos=%d %d %d %d\n",pos[0],pos[1],pos[2],pos[3]);
*/
				if (mflg) pos1 = pos[2] + pos[3];
				else      pos1 = pos[0] + pos[1];
/*
printf("cl_gx_str_edit_like: pos1=%d\n",pos1);
*/
				if (!c2) break;
			}
			else {
				if (iRc > 0) iRc = 0;
				break;
			}
		}
		if (!iRc) {
			if (c == '#') {
				len1 -= pos1;
				text += pos1;
			}
			else {
				len1 = pos1 - 1;
			}
			if (p=cl_tmp_const_malloc(len1+1)) {
				memzcpy(p,text,len1);
				*ptext = p;
				iRc = len1;
			}
			else iRc = ECL_MALLOC_ERROR;
		}
	}
/*	akxs_xlike_free(plike);	*/
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_str_rep(pp1,len1,pat,patlen,c2)
char **pp1,*pat,c2;
int len1,patlen;
{
	char c,*p1,*p;
	int rc,i,len;
	tdtInfoParm pParm[5],*ppParm[5];

	p1 = *pp1;
/*
printf("_gx_str_rep:Enter len1=%d p1=[%s] patlen=%d pat=[%s] c2=[%c]\n",len1,p1,patlen,pat,c2);
*/
	/* REPLIKE(line,pat,rep,opt,escape)	*/
	cl_set_parm_char(pParm,p1,len1);
	p = pat;
	for (i=0;i<patlen;i++) {
		if ((c=*p++) == '\\') {
			p++;
			i++;
		}
		else if (c == '/') break;
	}
	if (!i) {
		return ECL_SYNTAX_ERROR;
	}
	else if (i >= patlen) {
		return ECL_SYNTAX_ERROR;
	}
	*(p-1) = '\0';
/*
printf("_gx_str_rep: i=%d pat=[%s] p=[%s]\n",i,pat,p);
*/
	cl_set_parm_char(&pParm[1],pat,i);
	cl_set_parm_char(&pParm[2],p,patlen-i-1);
	p = "";
	len = 0;
	if (c2) {
		p = "g";
		len = 1;
	}
	cl_set_parm_char(&pParm[3],p,len);
	cl_set_parm_char(&pParm[4],"\\",1);
	for (i=0;i<5;i++) ppParm[i] = &pParm[i];
	rc = cl_rep_like(pp1,5,ppParm);
	len1 = strlen(p1);
	return len1;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_str_edit(pInfoParmW,pInfoParm1,pat0,patlen)
tdtInfoParm *pInfoParmW,*pInfoParm1;
char *pat0;
int patlen;
{
	char *p1,c,c2,*pat,*p;
	int rc,len1,i,len,posa[4],lena[7];
	tdtInfoParm pParm[5],*ppParm[5];
/*
printf("cl_gx_str_edit:Enter patlen=%d pat0=[%s]\n",patlen,pat0);
*/
	if (patlen >= 2) {
		p1 = NULL;
		if ((len1=parm_to_char(pInfoParm1,&p1,NULL)) < 0) return len1;
		patlen--;
		c = *pat0++;
		c2 = *pat0;
		if (c == c2) {
			if (patlen < 2) {
				return ECL_SYNTAX_ERROR;
			}
			pat0++;
			patlen--;
		}
		else c2 = '\0';
		if (!(pat=cl_tmp_const_malloc(patlen+3))) return ECL_MALLOC_ERROR;
		memzcpy(pat+1,pat0,patlen);
		if (c=='%' || c=='#') {
			len1 = _gx_str_edit_like(&p1,len1,pat,patlen,c,c2);
/*
printf("cl_gx_str_edit: len1=%d p1=[%s]\n",len1,p1);
*/		}
		else if (c == '/') {
			pat++;
			if ((len1=_gx_str_rep(&p1,len1,pat,patlen,c2)) < 0) return len1;
		}
	}
	cl_set_parm_char(pInfoParmW,p1,len1);
	return 0;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/*	���� :  iParm		: iParm[0] : �Ώ�1�̔�r�J�n�ʒu				*/
/*						  iParm[1] : �Ώ�2�̔�r�J�n�ʒu				*/
/*						  iParm[2] : ��r��							*/
/*									   < 0 : �Ώۂ̍ő���܂Ŕ�r���� */
/*			cmp_opt		: ��r�I�v�V����								*/
/*							= 0x01 : ��r�Ώۂ̐����܂߂đS�Ă��A		*/
/*									 ��v�����Ƃ��A1��Ԃ�				*/
/*	�ԋp :  cmp_opt��0x01��												*/
/*			=0�̂Ƃ��A��v��											*/
/*			=1�̂Ƃ��A1/0=��v/�s��v									*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_comp_list(pOprtr,pInfoParm1,pInfoParm2,iParm,cmp_opt)
char *pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
int iParm[],cmp_opt;
{
	tdtInfoParm *p1,*p2;
	int i1,i2,ix1,ix2,nm,Ans,rc,nu1,nu2,match,*pAns,ret;
	tdtRbCtl *pCt1,*pCt2;
	char *nam;
/*
printf("cl_comp_list:Enter pOprtr=[%s] iParm=%d %d %d cmp_opt=%08x\n",
pOprtr,iParm[0],iParm[1],iParm[2],cmp_opt);
*/
	if ((ix1=iParm[0]) < 0) ix1 = 0;
	if ((ix2=iParm[1]) < 0) ix2 = 0;
	nm  = iParm[2];
	Ans = 0;
	pCt1 = (tdtRbCtl *)pInfoParm1->pi_data;
	pCt2 = (tdtRbCtl *)pInfoParm2->pi_data;
/*
printf("cl_comp_list: pCt1=%08x pCt2=%08x\n",pCt1,pCt2);
*/
	/* �z�Q�Ə������`�F�b�N */
/*
printf("cl_comp_list: itc_circ_ref=%08x\n",gtIter_ctl[0].itc_circ_ref);
*/
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
		if (!(gtIter_ctl[1].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}
	/* �z�Q�Ƃ��`�F�b�N */
	nam = cl_gx_get_name_from_id(pInfoParm1->pi_id);
	if ((ret=_iterate_circ_ref(&gtIter_ctl[0],pCt1,nam)) == 1) return 0;
	else if (ret < 0) return ret;
	nam = cl_gx_get_name_from_id(pInfoParm2->pi_id);
	if ((ret=_iterate_circ_ref(&gtIter_ctl[1],pCt2,nam)) == 1) return 0;
	else if (ret < 0) return ret;

	match = 0;
	nu1 = pCt1->rb_used - ix1;
	nu2 = pCt2->rb_used - ix2;
	if (nm >= 0) {
		if (nu1 > nm) nu1 = nm;
		if (nu2 > nm) nu2 = nm;
	}
/*
printf("cl_comp_list:nu1=%d nu2=%d\n",nu1,nu2);
*/
	if (nu1>0 && nu2>0 && (!(cmp_opt & 0x01) || nu1==nu2)) {
		akxs_rb_read(pCt1,0);
		akxs_rb_read(pCt2,0);
		while (ix1-- > 0) {
			if (!(p1=(tdtInfoParm *)akxs_rb_read(pCt1,1))) break;
		}
		while (ix2-- > 0) {
			if (!(p2=(tdtInfoParm *)akxs_rb_read(pCt2,1))) break;
		}
		while (p1=(tdtInfoParm *)akxs_rb_read(pCt1,1)) {
			if (!(p2 = (tdtInfoParm *)akxs_rb_read(pCt2,1))) break;
			pAns = &Ans;
			if ((rc=cl_cmpt_comp_opt(&pAns,pOprtr,p1,p2,0,NULL,cmp_opt | DEF_ZOK_DATA)) < 0) {
/*
printf("cl_comp_list:rc=%d\n",rc);
*/
				Ans = rc;
				break;
			}
			else if (!Ans) {
/*
printf("cl_comp_list:Ans=%d\n",Ans);
*/
				break;
			}
			match++;
/*
printf("cl_comp_list:rc=%d Ans=%d match=%d\n",rc,Ans,match);
*/
			if (nm>0 && match>=nm) break;
		}
	}
	if (Ans && (!(cmp_opt & 0x01))) Ans = match;
	return Ans;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
#if 1
static int _mk_comp_ans(ppWork,i1,pLay,attr)
char **ppWork;
int i1,attr;
MCAT *pLay;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int iRc,n,i,ix,ilay;
	long *layer;
	char wrk[30],*p,*pAns,*fmt;

	layer = (long *)pLay->mc_bufp;
	ilay = pLay->mc_ipos - 1;
	ix = layer[ilay];
	if (!ix && !ilay) {
		if (!(pAns=cl_tmp_const_malloc(sizeof(int)))) return ECL_MALLOC_ERROR;
		memcpy(pAns,&i1,sizeof(int));
		iRc = DEF_ZOK_BINA;
/*
printf("_mk_comp_ans: Exit iRc=%d i=%d\n",iRc,i);
*/
	}
	else {
		mcat.mc_ipos = 0;
		sprintf(wrk,"%d",i1);
		akxtmcats(&mcat,wrk);
		for (i=0;i<ilay;i++) {
			sprintf(wrk," %d",layer[i]);
			akxtmcats(&mcat,wrk);
		}
		sprintf(wrk," %d",layer[ilay]-1);
		akxtmcats(&mcat,wrk);
		pAns = mcat.mc_bufp;
		iRc = DEF_ZOK_CHAR;
	}
	*ppWork = pAns;
	return iRc;
}
#else
static int _mk_comp_ans(ppWork,i,ppAns,attr)
char **ppWork,**ppAns;
int i,attr;
{
	int iRc,n;
	char wrk[30],*p,*pAns,*fmt;
/*
printf("_mk_comp_ans: Enter pWork=[%s] i=%d ppAns=%08x attr=%d\n",*ppWork,i,ppAns,attr);
*/
	if (ppAns) {
		pAns = *ppAns;
		if (attr == DEF_ZOK_CHAR) {
			if (!(p=cl_tmp_const_malloc(strlen(pAns)+11+2))) return ECL_MALLOC_ERROR;
			sprintf(p,"%d %s",i,pAns);
		}
		else {
			memcpy(&n,pAns,sizeof(int));
			if (n) sprintf(wrk,"%d %d",i,n);
			else   sprintf(wrk,"%d",i);
			if (!(p=cl_tmp_const_malloc(strlen(wrk)+1))) return ECL_MALLOC_ERROR;
			strcpy(p,wrk);
		}
		iRc = DEF_ZOK_CHAR;
/*
printf("_mk_comp_ans: Exit iRc=%d p=[%s]\n",iRc,p);
*/
	}
	else {
		if (!(p=cl_tmp_const_malloc(sizeof(int)))) return ECL_MALLOC_ERROR;
		memcpy(p,&i,sizeof(int));
		iRc = DEF_ZOK_BINA;
/*
printf("_mk_comp_ans: Exit iRc=%d i=%d\n",iRc,i);
*/
	}
	*ppWork = p;
	return iRc;
}
#endif
/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string1(pInfoParm0,pInfoParm,opt)
tdtInfoParm *pInfoParm0,*pInfoParm;
int opt;
{
	int iRc,len2;
	char *pp,wrk[12];

	if (pInfoParm->pi_id==' ') {
		pp = wrk;
		if ((iRc=parm_to_char(pInfoParm,&pp,NULL)) >= 0) {
			len2 = iRc;
			iRc = akxs_in_mem_opt(pInfoParm0->pi_data,pInfoParm0->pi_dlen,pp,len2,opt);
/*
printf("cl_in_string1: iRc=%d\n",iRc);
*/
			if (iRc > 0) {
				if (opt & D_COMP_FUN_IN) {
					/*pInfoParm0->pi_pos = pInfoParm0->pi_len + 1*/;
				}
				else {
					if (iRc < pInfoParm0->pi_hlen) pInfoParm0->pi_hlen = iRc;
					if (iRc > pInfoParm0->pi_pos)  pInfoParm0->pi_pos  = iRc;
				}
			}
		}
	}
	else iRc = ECL_SCRIPT_ERROR;
	return iRc;
}

#if 0
/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_str_array(ppAns,pp0,len1,pInfoParm1,opt)
char **ppAns,*pp0;
int len1,opt;
tdtInfoParm *pInfoParm1;
{
	int iRc,i,nm1,ix1,iParm[4];
	tdtInfoParm *pInfoParm,*ppParm[1],***pTBL1;
	tdtArrayIndex tIndex1;
/*
printf("cl_in_str_array: Enter pAns=[%s]\n",*ppAns);
*/
	if ((iRc=cl_get_array_info(pInfoParm1,&tIndex1,&pTBL1,iParm)) >= 0) {
		if (tIndex1.xhp) iRc = ECL_SCRIPT_ERROR;
		else {
			nm1 = iParm[3] - iParm[2] + 1;	/* iParm[2],iParm[3]�́AParmNo�ł̒l�ɂȂ��Ă��� */
			ix1  = iParm[2];
			for (i=0;i<nm1;i++,ix1++) {
				if ((iRc=cl_array_get_info_parm(&pInfoParm,&tIndex1,pTBL1,ix1,'r')) < 0) break;
				if (iRc = cl_in_string1(ppAns,pp0,len1,pInfoParm,opt | 0x80)) {
					if (iRc > 0) {
						iRc = _mk_comp_ans(ppAns,i+1,ppAns,iRc);
/*
printf("cl_in_str_array: i+1=%d pAns=[%s]\n",i+1,*ppAns);
*/
					}
					break;
				}
			}
		}
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_str_list(ppAns,pp0,len1,pInfoParm1,opt)
char **ppAns,*pp0;
int len1,opt;
tdtInfoParm *pInfoParm1;
{
	int iRc,i,n;
	char *pAns,wrk[24],*p;
	tdtInfoParm *pInfoParm,*ppParm[1];
	tdtRbCtl *pCt;

	iRc = 0;
	pCt = (tdtRbCtl *)pInfoParm1->pi_data;
	if (akxs_rb_used(pCt)) {
		akxs_rb_read(pCt,0);
		i = 1;
		while (pInfoParm=(tdtInfoParm *)akxs_rb_read(pCt,1)) {
			if (iRc = cl_in_string1(ppAns,pp0,len1,pInfoParm,opt | 0x80)) {
				if (iRc > 0) {
					iRc = _mk_comp_ans(ppAns,i,ppAns,iRc);
				}
				break;
			}
			i++;
		}
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string_sub(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,**ppParm;
int nparm,opt;
{
	int iRc,i,n,attr,len2;
	char id,wrk[12],*pp,**ppWork;
	tdtInfoParm *pInfoParm;
/*
printf("cl_in_string1: Enter opt=%08x pAns=[%s]\n",opt,*ppAns);
*/
	iRc = 0;
	ppWork = ppAns;
	pp = wrk;
	for (i=0;i<nparm;i++) {
		if (pInfoParm = ppParm[i]) {
			if (!cl_is_undef_parm(pInfoParm) && !cl_is_null_parm(pInfoParm)) {
				if ((id=pInfoParm->pi_id) == ' ') {
					iRc = cl_in_string1(pInfoParm0,pInfoParm,opt);
					ppWork = NULL;
					if (iRc > 0) iRc = DEF_ZOK_BINA;
				}
				else if (id=='A' || id=='R') {
					iRc = cl_in_number_array(ppAns,pInfoParm0,pInfoParm);
				}
				else if (id=='L' || id=='N') {
					iRc = cl_in_number_list(ppAns,pInfoParm0,pInfoParm);
				}
				else {
					iRc = ECL_SCRIPT_ERROR;
				}
				if (iRc>0 && !(opt & 0x80)) {
					iRc = _mk_comp_ans(ppAns,i+1,ppWork,iRc);
/*
printf("cl_in_string1: opt=%08x i+1=%d pAns=[%s]\n",opt,i+1,*ppAns);
*/
				}
			}
		}
	}
	return iRc;
}
#endif
/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string(ppWork,nparm,ppParm,opt)
char **ppWork;
tdtInfoParm **ppParm;
int nparm,opt;
{
	tdtInfoParm tInfoParm,*pInfoParm;
	int  i,len1,len2,iRc,pos[2],attr,pos_min,pos_max,lenm,i1,optw;
	char *pWork;
	char ww[64],*pp[2],*pp0,*p,c;
	int  rc,atr1,atr2,iAttr[3],result;

	pp[1] = ww + 32;
	if ((i1=cl_get_str_pos(nparm,ppParm,0,pp,&len1,&lenm,pos,"INSTRs")) < 0) return i1;
	if (i1 < nparm-1) {
		pInfoParm = ppParm[nparm-1];
		if (pInfoParm->pi_attr == DEF_ZOK_BINA) {
			optw = cl_get_data_int(pInfoParm);
			opt |= (optw & D_COMP_OPT_IGN_CASE) | ((optw & D_COMP_OPT_IGN_HZ)<<4);
			nparm--;
/*
printf("cl_in_string: i1=%d opt=%d nparm=%d\n",i1,opt,nparm);
*/
		}
	}
/*
printf("cl_in_string: nparm=%d i1=%d opt=%08x pos=%d lenm=%d\n",nparm,i1,opt,pos[0],lenm);
*/
	pp0 = pp[0];
#if 0	/* 2020.12.29 */ /* pp0�������Ƃ��́A�r���ň�v�����ꍇ�A�S�ϊ������ʂɂȂ� */
	if (opt & 0x20) {
		if (!(p=cl_tmp_const_malloc(len1*4+1))) return ECL_MALLOC_ERROR;
		if ((len1=akxctozen(len1,pp0,p)) < 0) return -1;
		pp0 = p;
	}
	if (opt & 0x01) {
		if (!(p=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
		if ((len1=akxcuppern(p,pp0,len1)) < 0) return -1;
		pp0 = p;
	}
#endif
	pos_min = lenm + 1;
	pos_max = 0;
	memset(*ppWork,0,sizeof(int));
	cl_set_parm_char(&tInfoParm,pp0,len1);
	tInfoParm.pi_hlen = pos_min;
	tInfoParm.pi_pos  = pos_max;
/*	tInfoParm.pi_len = i1;	*/
	tInfoParm.pi_paux = (char *)cl_in_string1;
	iRc = cl_in_number_sub(ppWork,&tInfoParm,nparm-i1,ppParm+i1,opt);
/*
printf("cl_in_string: iRc=%d\n",iRc);
*/
	if (iRc>0 && iRc != 1) {
		pos_min = tInfoParm.pi_hlen;
		pos_max = tInfoParm.pi_pos;
/*
printf("cl_in_string: pos_min=%d pos_max=%d\n",pos_min,pos_max);
*/
		if (opt & D_COMP_FUN_IN) {
			pos_min = pos_max;
		}
		else {
			if (opt & D_COMP_FUN_REVERCE) pos_min = pos_max;
			else if (pos_min == lenm+1) pos_min = 0;
			if (!(pGlobTable->options[17] & 0x01) && pos_min) pos_min += pos[0] - 1;
		}
/*
printf("cl_in_string: pos_min=%d\n",pos_min);
*/
		pWork = *ppWork;
		memcpy(pWork,&pos_min,sizeof(int));
		iRc = DEF_ZOK_BINA;
	}
	else if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*	iRc > 0 : ��v�����ԍ�												*/
/*	    = 0 : ��v���Ȃ�����											*/
/*	    < 0 : �G���[													*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number1(pInfoParm0,pInfoParm,opt)
tdtInfoParm *pInfoParm0,*pInfoParm;
int opt;
{
	static char *msg="cl_in_number1:";
	int iRc,atr0,atr;
	long lValue0,lValue;
	double dValue0,dValue;
	MPA *ma0,maz,*ma;
	char id;

	iRc = 0;
	if (pInfoParm0->pi_id==' ' && pInfoParm->pi_id==' ') {
		if ((atr0=pInfoParm0->pi_attr) == DEF_ZOK_BINA) {
			memcpy((char *)&lValue0,pInfoParm0->pi_data,sizeof(long));
			if ((iRc=cl_get_parm_bin(pInfoParm,&lValue,msg)) >= 0) {
				if (lValue0 == lValue) iRc = 1;
			}
		}
		else if (atr0 == DEF_ZOK_FLOA) {
			memcpy((char *)&dValue0,pInfoParm0->pi_data,sizeof(double));
			if ((iRc=cl_get_parm_double(pInfoParm,&dValue,msg)) >= 0) {
				if (dValue0 == dValue) iRc = 1;
			}
		}
		else if (atr0 == DEF_ZOK_DECI) {
			ma0 = (MPA *)pInfoParm0->pi_data;
			ma = (MPA *)cl_get_tmpMPA(&maz);
			if ((iRc=cl_get_parm_dec(pInfoParm,ma,msg)) >= 0) {
				if (!m_cmp(ma0,ma)) iRc = 1;
			}
		}
		else iRc = ECL_SCRIPT_ERROR;
	/*	if (iRc > 0) pInfoParm0->pi_pos = pInfoParm0->pi_len + 1;	*/
	}
	else iRc = ECL_SCRIPT_ERROR;
	return iRc;
}
#if 0
/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number_array(ppAns,pInfoParm0,pInfoParm1,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,*pInfoParm1;
int opt;
{
	int iRc,i,nm1,ix1,iParm[4];
	tdtInfoParm *pInfoParm,*ppParm[1],***pTBL1;
	tdtArrayIndex tIndex1;
/*
printf("cl_in_number_array: Enter pAns=[%s]\n",*ppAns);
*/
	if ((iRc=cl_get_array_info(pInfoParm1,&tIndex1,&pTBL1,iParm)) >= 0) {
		if (tIndex1.xhp) iRc = ECL_SCRIPT_ERROR;
		else {
			nm1 = iParm[3] - iParm[2] + 1;	/* iParm[2],iParm[3]�́AParmNo�ł̒l�ɂȂ��Ă��� */
			ix1  = iParm[2];
			for (i=0;i<nm1;i++,ix1++) {
				if ((iRc=cl_array_get_info_parm(ppParm,&tIndex1,pTBL1,ix1,'r')) < 0) break;
				if (iRc = cl_in_number_sub(ppAns,pInfoParm0,1,ppParm,opt | D_COMP_OPT_NOT_SET)) {
					if (iRc>0 && (opt & D_COMP_FUN_IN)) {
						iRc = _mk_comp_ans(ppAns,i+1,ppAns,iRc);
/*
printf("cl_in_number_array: i+1=%d pAns=[%s]\n",i+1,*ppAns);
*/
					}
					break;
				}
			}
		}
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number_list(ppAns,pInfoParm0,pInfoParm1,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,*pInfoParm1;
int opt;
{
	int iRc,i,n;
	char *pAns,wrk[24],*p;
	tdtInfoParm *pInfoParm,*ppParm[1];
	tdtRbCtl *pCt;

	iRc = 0;
	pCt = (tdtRbCtl *)pInfoParm1->pi_data;
	if (akxs_rb_used(pCt)) {
		akxs_rb_read(pCt,0);
		i = 1;
		while (pInfoParm=(tdtInfoParm *)akxs_rb_read(pCt,1)) {
			ppParm[0] = pInfoParm;
			if (iRc = cl_in_number_sub(ppAns,pInfoParm0,1,ppParm,opt | D_COMP_OPT_NOT_SET)) {
				if (iRc > 0) {
					iRc = _mk_comp_ans(ppAns,i,ppAns,iRc);
				}
				break;
			}
			i++;
		}
	}
	return iRc;
}
#endif
/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number_sub(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,**ppParm;
int nparm,opt;
{
	int iRc,i,i1;
	int rc,max_layer;
	char id,**ppWork;
	tdtInfoParm *pInfoParm;
	int (*exfunc)();
	tdtIterate_ctl tIter_ctl;
	tdtIterate tIter;
	MCAT2 *layer;

	max_layer = -1;
	tIter_ctl.itc_pIter = &tIter;
	layer = akxs_layer_new(100,cl_tmp_const_malloc,NULL);
/*
printf("cl_in_number: Enter opt=%d pAns=[%s]\n",opt,*ppAns);
*/
	iRc = 0;
	exfunc = (int(*)())pInfoParm0->pi_paux;
	ppWork = ppAns;
	for (i=0;i<nparm;i++) {
		if (pInfoParm = ppParm[i]) {
#if 1
		  if ((rc=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm,max_layer)) < 0) {
		      iRc = rc;
		      break;
		  }
		  for (;;) {
			if ((rc=cl_iterate_info(&tIter_ctl)) < 0) {
				iRc = rc;
				break;
			}
			if (!(pInfoParm=tIter.it_pInfo)) break;
			akxs_layer_set(layer,tIter_ctl.itc_layer,tIter.it_ix);
/*
printf("cl_in_number: layer=%d ix=%d\n",tIter_ctl.itc_layer,tIter.it_ix);
*/
#endif
			if (cl_check_data_id(pInfoParm,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
			if (!cl_is_null_parm(pInfoParm)) {
				i1 = i + 1;
				if ((id=pInfoParm->pi_id) == ' '){
				/*	pInfoParm0->pi_len = i;	*/
					iRc = exfunc(pInfoParm0,pInfoParm,opt);
/*
printf("cl_in_number: i1=%d iRc=%d\n",i1,iRc);
*/
					ppWork = NULL;
					if (iRc > 0) {
						iRc = DEF_ZOK_BINA;
						if (opt & D_COMP_FUN_IN) pInfoParm0->pi_pos = i1;
					}
				}
#if 0
				else if (id=='A' || id=='R')
					iRc = cl_in_number_array(ppAns,pInfoParm0,pInfoParm,opt);
				else if (id=='L' || id=='N')
					iRc = cl_in_number_list(ppAns,pInfoParm0,pInfoParm,opt);
#endif
				else 
					iRc = ECL_SCRIPT_ERROR;
				if (iRc) {
					if (iRc>0 && (opt & D_COMP_FUN_IN) && !(opt & D_COMP_OPT_NOT_SET)) {
#if 1
						iRc = _mk_comp_ans(ppAns,i1,layer,iRc);
#else
						iRc = _mk_comp_ans(ppAns,i1,ppWork,iRc);
#endif
/*
printf("cl_in_number: opt=%d i1=%d pAns=[%s]\n",opt,i1,*ppAns);
*/
					}
					if (opt & D_COMP_FUN_IN) break;
				}
			}
#if 1
		  }
/*
printf("cl_in_number: id=[%c](%02x) iRc=%d\n",id,id,iRc);
*/
		  if (iRc) break;
#endif
		}
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*	iRc > 0 : ��v�����ԍ�												*/
/*	    = 0 : ��v���Ȃ�����											*/
/*	    < 0 : �G���[													*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtInfoParm *pInfoParm0,**ppParm;
int nparm,opt;
{
	tdtInfoParm tInfoParm;
	int iRc;

	memset(*ppAns,0,sizeof(int));
	tInfoParm = *pInfoParm0;
/*	tInfoParm.pi_len = 0;	*/
	tInfoParm.pi_paux = (char *)cl_in_number1;
	iRc = cl_in_number_sub(ppAns,&tInfoParm,nparm,ppParm,D_COMP_FUN_IN);
	if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)
tdtInfoParm *pInfoParm,*pInfoParm1,*pInfoParm2;
int ope;
{
	int ret,rc,attr1,attr2,opt,iAttr[3],len1,len2,attr,iUNSIG1,iUNSIG2,over_or_under;
	char *p1,*p2;
	MPA *mpa1,*mpa2,ma1z,ma2z,*ma1,*ma2;
	double dVal1,dVal2;
	long lVal1,lVal2,Valz[NMPA_LONG],*Val;
	ulong ulVal1,ulVal2,ulVal3;
	tdtInfoParm tInfoParm1,tInfoParm2,*pInfoParm3;

DEBUGOUT_InfoParm(198,"cl_comp_info:1 ope=%08x",pInfoParm1,ope,0);
DEBUGOUT_InfoParm(198,"cl_comp_info:2 ope=%08x",pInfoParm2,ope,0);
	iUNSIG1 = iUNSIG2 = ret = 0;
	attr1 = pInfoParm1->pi_attr;
	attr2 = pInfoParm2->pi_attr;
	if ((((attr1==DEF_ZOK_DATE && attr2==DEF_ZOK_DATE) ||
	      (attr1==DEF_ZOK_BULK && attr2==DEF_ZOK_BULK) ||
	      (attr1==DEF_ZOK_CHAR && attr2==DEF_ZOK_DATE) ||
	      (attr1==DEF_ZOK_DATE && attr2==DEF_ZOK_CHAR)) && (ope==D_FUC_MAX || ope==D_FUC_MIN)) ||
	    (attr1==DEF_ZOK_CHAR && attr2==DEF_ZOK_CHAR)) {
		opt = 0;
		if (attr1==DEF_ZOK_DATE || attr2==DEF_ZOK_DATE) {
			if (attr1==DEF_ZOK_CHAR || attr2==DEF_ZOK_CHAR) {
				if (attr1 == DEF_ZOK_CHAR) pInfoParm3 = pInfoParm1;
				else pInfoParm3 = pInfoParm2;
				if ((ret=cl_func_to_date(&tInfoParm1,1,&pInfoParm3)) < 0) {
							/*%s: ���t������[%s]������Ă��܂��Bret=%d */
					ERROROUT3(FORMAT(622),"cl_comp_info",pInfoParm3->pi_data,ret);
					return ECL_SCRIPT_ERROR;
				}
				if (attr1 == DEF_ZOK_CHAR) {
					pInfoParm1 = &tInfoParm1;
					attr1 = pInfoParm1->pi_attr;
				}
				else {
					pInfoParm2 = &tInfoParm1;
					attr2 = pInfoParm2->pi_attr;
				}
			}
			if (attr1 == DEF_ZOK_DATE) {
				mpa1 = (MPA *)pInfoParm1->pi_data;
				p1   = mpa1->num;
				len1 = mpa1->len;
			}
			if (attr2 == DEF_ZOK_DATE) {
				mpa2 = (MPA *)pInfoParm2->pi_data;
				p2   = mpa2->num;
				len2 = mpa2->len;
			}
		}
		else {
			p1   = pInfoParm1->pi_data;
			len1 = pInfoParm1->pi_dlen;
			p2   = pInfoParm2->pi_data;
			len2 = pInfoParm2->pi_dlen;
			if (attr1 == DEF_ZOK_CHAR) {
				if (ope == D_FUC_SUM) {
					rc = cl_conv_const_n_str(&tInfoParm1,p1,len1);
					if (!rc) rc = cl_conv_const_n_str(&tInfoParm2,p2,len2);
					if (!rc) rc = cl_comp_info(pInfoParm,&tInfoParm1,&tInfoParm2,ope);
					return rc;
				}
				else opt = 0x4000;
			}
		}
/*
printf("cl_comp_info: len1=%d p1=%08x\n",len1,p1);
*/
		rc = _memcmplen(p1,len1,p2,len2,opt);
		if (((ope==D_FUC_MAX) && (rc<0)) || ((ope==D_FUC_MIN) && (rc>0)))
			pInfoParm1 = pInfoParm2;
		*pInfoParm = *pInfoParm1;
	}
	else if (attr1>=1 && attr1<=4 && attr2>=1 && attr2<=4) {
		rc = 0;
		if (attr1 == DEF_ZOK_CHAR) {
			attr1 = attr2;
			if (attr2 == DEF_ZOK_FLOA) {
				rc = cl_get_parm_double(pInfoParm1,&dVal1,"1",iAttr);
				rc = cl_get_parm_double(pInfoParm2,&dVal2,"2",iAttr);
			}
			else if (attr2 == DEF_ZOK_DECI) {
				mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
				rc = cl_get_parm_dec(pInfoParm1,mpa1,"1",iAttr);
				mpa2 = (MPA *)pInfoParm2->pi_data;
			}
			else if (attr2 == DEF_ZOK_BINA) {
				rc = cl_get_parm_long(pInfoParm1,&lVal1,"1");
				lVal2 = cl_get_data_long(pInfoParm2);
				iUNSIG2 = pInfoParm2->pi_scale & D_DATA_UNSIGNED;
				ulVal2 = lVal2;
			}
		}
		else if (attr1 == DEF_ZOK_BINA) {
			iUNSIG1 = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
			if (attr2 == DEF_ZOK_FLOA) {
				rc = cl_get_parm_double(pInfoParm1,&dVal1,"1",iAttr);
				attr1 = attr2;
				rc = cl_get_parm_double(pInfoParm2,&dVal2,"2",iAttr);
			}
			else if (attr2 == DEF_ZOK_DECI) {
				mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
				rc = cl_get_parm_dec(pInfoParm1,mpa1,"1",iAttr);
				attr1 = attr2;
				mpa2 = (MPA *)pInfoParm2->pi_data;
			}
			else {
				lVal1 = cl_get_data_long(pInfoParm1);
				rc = cl_get_parm_long(pInfoParm2,&lVal2,"1");
				ulVal1 = lVal1;
			}
		}
		else if (attr1 == DEF_ZOK_DECI) {
			if (attr2 == DEF_ZOK_FLOA) {
				rc = cl_get_parm_double(pInfoParm1,&dVal1,"1",iAttr);
				rc = cl_get_parm_double(pInfoParm2,&dVal2,"2",iAttr);
				attr1 = attr2;
			}
			else {
				mpa1 = (MPA *)pInfoParm1->pi_data;
				mpa2 = (MPA *)cl_get_tmpMPA(&ma2z);
				rc = cl_get_parm_dec(pInfoParm2,mpa2,"2",iAttr);
			}
		}
		else if (attr1 == DEF_ZOK_FLOA) {
			rc = cl_get_parm_double(pInfoParm1,&dVal1,"1",iAttr);
			rc = cl_get_parm_double(pInfoParm2,&dVal2,"2",iAttr);
		}
		if ((ret=rc) > 0) ret = ECL_SCRIPT_ERROR;
		else if (!ret) {
			if (attr1 == DEF_ZOK_BINA) {
				if (iUNSIG1 | iUNSIG2) {
					if (ope == D_FUC_SUM) {
						ulVal3 = ulVal1 + ulVal2;
						mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
						over_or_under = 0;
						ulVal1 = cl_chk_over_flow_ulong_add(ulVal3,ulVal1,ulVal2,"Add",&over_or_under,mpa1);
						if (over_or_under) {
							cl_set_parm_mpa(pInfoParm,mpa1);
							return 0;
						}
					}
					else if (ope == D_FUC_MAX)
						ulVal1 = X_MAX(ulVal1,ulVal2);
					else
						ulVal1 = X_MIN(ulVal1,ulVal2);
					lVal1 = ulVal1;
				}
				else {
					if (ope == D_FUC_SUM) lVal1 += lVal2;
					else {
						rc = lVal1 - lVal2;
						if (ope == D_FUC_MIN) rc = -rc;
						if (rc < 0) lVal1 = lVal2;
					}
				}
				cl_set_parm_long(pInfoParm,lVal1);
				if (iUNSIG1 | iUNSIG2) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
			}
			else if (attr1 == DEF_ZOK_FLOA) {
				if (ope == D_FUC_SUM) dVal1 += dVal2;
				else {
					if (dVal1 < dVal2) rc = -1;
					else rc = 1;
					if (ope == D_FUC_MIN) rc = -rc;
					if (rc < 0) dVal1 = dVal2;
				}
				cl_set_parm_double(pInfoParm,dVal1);
			}
			else if (attr1 == DEF_ZOK_DECI) {
				if (ope == D_FUC_SUM) rc = m_add1(mpa1,mpa2);
				else {
					rc = m_cmp(mpa1,mpa2);
					if (ope == D_FUC_MIN) rc = -rc;
					if (rc < 0) mpa1 = mpa2;
				}
				cl_set_parm_mpa(pInfoParm,mpa1);
			}
		}
	}
	else {
		if (attr1<1 || attr1>6) attr = attr1;
		if (attr2<1 || attr2>6) attr = attr2;
		/* %s: �p�����[�^�̌^(%d)�������Ă��܂���B */
		ERROROUT2(FORMAT(285),"cl_comp_info",attr);
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_agg_sub(pInfoParmW,nparm,ppParm,ope,pInfoParm0)
tdtInfoParm *pInfoParmW,**ppParm,*pInfoParm0;
int nparm,ope;
{
	tdtInfoParm *pInfoParm,*pInfoParm1,*pInfoParm2,tInfoParm,tInfoParm1,***pTBL1;
	tdtArrayIndex tIndex1;
	char id,wk[2],*pWork;
	int  i,k,ret,iParm[4],ix1,nm1,len1,attr;
	long lSum;
	tdtRbCtl *pCt;
	int max_layer;
	tdtIterate_ctl tIter_ctl;
	tdtIterate tIter;

	max_layer = -1;
	tIter_ctl.itc_pIter = &tIter;

	pGlobTable->error = 0;
	ret = 0;
	lSum = pInfoParmW->pi_len;
/*
printf("cl_func_agg_sub:Enter ope=%d nparm=%d lSum=%d\n",ope,nparm,lSum);
*/
	pInfoParm = &tInfoParm;
/*
	if (pInfoParm0) pInfoParm1 = pInfoParm0;
	else {	*/
		pInfoParm1 = &tInfoParm1;
		cl_parm_set0(pInfoParm1);
/*	}	*/
	for (i=0;i<nparm;i++) {
		pInfoParm2 = ppParm[i];
#if 1
		if (cl_is_undef_parm(pInfoParm2) || cl_is_null_parm(pInfoParm2)) continue;

		if ((ret=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm2,max_layer)) < 0) break;
		for (;;) {
			if ((ret=cl_iterate_info(&tIter_ctl)) < 0) break;
			if (!(pInfoParm2=tIter.it_pInfo)) break;
/*
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:pInfoParm1",pInfoParm1,ret,0);
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:pInfoParm2",pInfoParm2,ret,0);
*/
			if (cl_is_undef_parm(pInfoParm1) || cl_is_null_parm(pInfoParm1)) {
				cl_gx_copy_info2(pInfoParm1,pInfoParm2);
				lSum++;
			}
			else if (!cl_is_undef_parm(pInfoParm2) && !cl_is_null_parm(pInfoParm2)) {
				if ((ret=cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)) < 0) break;
				cl_gx_copy_info2(pInfoParm1,pInfoParm);
				lSum++;
			}
		}
		if (ret < 0) break;
#else
		id = pInfoParm2->pi_id;
		if (cl_is_undef_parm(pInfoParm2) || cl_is_null_parm(pInfoParm2)) ;
		else if (id == ' ') {
			if (cl_is_undef_parm(pInfoParm1) || cl_is_null_parm(pInfoParm1)) {
				pInfoParm1 = pInfoParm2;
				lSum++;
			}
			else {
				if ((ret=cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)) < 0) break;
				pInfoParm1 = pInfoParm;
				lSum++;
			}
/*
printf("cl_func_agg_sub: lSum=%d\n",lSum);
*/
		}
		else if (id=='A' || id=='R') {
			if ((ret=cl_get_array_info(pInfoParm2,&tIndex1,&pTBL1,iParm)) >= 0) {
				if (tIndex1.xhp) ret = ECL_SCRIPT_ERROR;
				else {
					nm1 = iParm[3] - iParm[2] + 1;	/* iParm[2],iParm[3]�́AParmNo�ł̒l�ɂȂ��Ă��� */
					ix1  = iParm[2];
					for (k=0;k<nm1;k++,ix1++) {
						if ((ret=cl_array_get_info_parm(&pInfoParm2,&tIndex1,pTBL1,ix1,'r')) < 0) break;
						tInfoParm.pi_len = lSum;
						if ((ret=cl_func_agg_sub(&tInfoParm,1,&pInfoParm2,ope,pInfoParm1)) < 0) break;
						lSum = tInfoParm.pi_len;
						pInfoParm1 = &tInfoParm;
					}
				}
			}
		}
		else if (id=='L' || id=='N') {
			pCt = (tdtRbCtl *)pInfoParm2->pi_data;
			if (akxs_rb_used(pCt)) {
				akxs_rb_read(pCt,0);
				while (pInfoParm2=(tdtInfoParm *)akxs_rb_read(pCt,1)) {
					tInfoParm.pi_len = lSum;
					if ((ret=cl_func_agg_sub(&tInfoParm,1,&pInfoParm2,ope,pInfoParm1)) < 0) break;
					lSum = tInfoParm.pi_len;
					pInfoParm1 = &tInfoParm;
				}
			}
		}
		else ret = -200;
		if (ret < 0) {
			if (ret == -200) {
				wk[0] = id;
				wk[1] = '\0';
				ERROROUT1(FORMAT(158),wk);	/* %s�͎w��ł��܂���B*/
				ret = ECL_SCRIPT_ERROR;
			}
			break;
		}
#endif
	}
	if (ret >= 0) {
		cl_gx_copy_info(pInfoParmW, pInfoParm1);
		pInfoParmW->pi_scale &= ~D_DATA_MALLOC;
		pInfoParmW->pi_len = lSum;
		attr = pInfoParmW->pi_attr;
		len1 = pInfoParmW->pi_dlen;
		if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK || attr==DEF_ZOK_DATE || attr==DEF_ZOK_DECI) {
			if (!(pWork=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
			memcpy(pWork,pInfoParm1->pi_data,len1);
			if (attr == DEF_ZOK_CHAR) *(pWork+len1) = '\0';
			pInfoParmW->pi_data = pWork;
		}
		ret = 0;
	}
/*
printf("cl_func_agg_sub:Exit lSum=%d ret=%d\n",lSum,ret);
*/
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:Exit ret=%d",pInfoParmW,ret,0);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_agg(pInfoParmW,nparm,ppParm,ope0)
tdtInfoParm *pInfoParmW,**ppParm;
int nparm,ope0;
{
	int ret,ope,attr,iAttr[4];
	long lSum,lVal1,lVal2;
	double dVal1,dVal2;
	MPA ma1z,ma2z,*mpa1,*ma1,*ma2;

	ret = 0;
	if ((ope=ope0) == D_FUC_AVG) ope = D_FUC_SUM;
	cl_null_data(pInfoParmW);
	pInfoParmW->pi_len = 0;
	ret = cl_func_agg_sub(pInfoParmW,nparm,ppParm,ope,NULL);
	if (!ret) {
		if (cl_is_undef_parm(pInfoParmW) || cl_is_null_parm(pInfoParmW)) {
			ERROROUT1(FORMAT(372),"cl_func_agg");	/* %s: �f�[�^����0�ł��B*/
		/*	if (ope0 == D_FUC_SUM) cl_set_parm_long(pInfoParmW,0);
			else */cl_null_data(pInfoParmW);
		}
		else if (ope0 == D_FUC_AVG) {
			lSum = pInfoParmW->pi_len;
			attr = pInfoParmW->pi_attr;
			if (attr == DEF_ZOK_FLOA) {
				cl_get_parm_double(pInfoParmW,&dVal1,"1",iAttr);
				cl_set_parm_double(pInfoParmW,dVal1/lSum);
			}
			else if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_DECI) {
				mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
				if (!(ret=cl_get_parm_dec(pInfoParmW,mpa1,"1",iAttr))) {
					ma2 = (MPA *)cl_get_tmpMPA(&ma2z);
					m_l2mpa(lSum,ma2);
					m_div1(mpa1,ma2);
					cl_set_parm_mpa(pInfoParmW,mpa1);
				}
				else if (ret > 0) ret = ECL_SCRIPT_ERROR;
			}
			else ret = -1;
		}
	}
	if (!ret) ret = pInfoParmW->pi_attr;
	return ret;
}
