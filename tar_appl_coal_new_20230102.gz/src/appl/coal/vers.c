char version[] ="@(#) ***[V/R=7.2.1 (new)]***";

