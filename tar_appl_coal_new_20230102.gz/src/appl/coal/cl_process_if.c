static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �h�e�R�}���h���C��                                     *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_if( pLeaf )                             *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
#define NEORET
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

/********************************************/
/*											*/
/********************************************/
static int _is_if_exec(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
/*	IfCB *next;	*/
	BlockCB *next;

	next = proc->pTopBlockCB;
	while (next) {
		if (next->Blockleaf == leaf) {

DEBUGOUTL2(190,"_is_if_exec: found leaf=%08x in IfCB=%08x",leaf,next);

			return next->TureFlag;
		}
		next = next->nextBlockCB;
	}
	return -1;
}

/********************************************/
/*											*/
/********************************************/
int cl_process_if(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int  rc;
	int  Tupple;
	int  Value;
	int  Flag;
	BlockCB *pIfCB;

DEBUGOUTL1(110,"cl_process_if: enter proc=%08x",pProc);
	if (rc = cl_if_pre_proc(pLeaf, pProc)) return rc;

	if ((Flag = cl_if_comp_ctl(pLeaf,pProc)) < NORMAL) return ECL_EX_IF;

	if (Flag == L_ON) {
		pIfCB = pProc->pcrBlockCB;
		pIfCB->TureFlag = L_ON;
		pIfCB->Blockleaf = pLeaf;
		pProc->Nextleaf = pLeaf->leftleaf;
DEBUGOUTL1(110,"cl_process_if: push [ %s ]",cl_get_pcmd_line(pLeaf->rightleaf));
		cl_ret_leaf_push(pProc,pLeaf->rightleaf);
	}
	else {
		pProc->Nextleaf = pLeaf->rightleaf;
	}

	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_process_switch(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int  rc;
	tdtInfoParm	InfoParm;
	int i,len;
	parmList **prmp,*pparmList;
	char *p,work[32],*pp;

DEBUGOUTL1(110,"cl_process_switch: enter proc=%08x",pProc);
	if (rc = cl_if_pre_proc(pLeaf, pProc)) return rc;

	if (!pLeaf->cmd.prmnum) {
		ERROROUT1(FORMAT(92),"cl_process_switch");	/* %s: �����K�v�ł� */
		return -1;
	}
	prmp = pLeaf->cmd.prmp;
	if (!(p=(char *)prmp[0]->bxobj)) {
		sprintf(work,"($_%08x_%08x ",pProc,pLeaf);
		len = strlen(work);
		if (!(p = cl_opt_malloc(D_OPT_ALC_LEAF,len+1))) return -1;
		memcpy(p,work,len+1);
		prmp[1]->bxobj = (GXObject *)p;
		prmp[1]->opt = D_GX_OPT_NO_USE_OBJ;
		work[--len] = '=';
		mcat.mc_ipos = 0;
		if (akxtmcat(&mcat,work+1,len)<0) return -1;
		for (i=0;i<pLeaf->cmd.prmnum;i++) {
			pparmList = prmp[i];
			if (i>0) akxtmcat(&mcat," ",1);
			if (akxtmcat(&mcat,pparmList->prp,pparmList->prmlen)<0) return -1;
		}
		if (akxtmcat(&mcat,"",1)<0) return -1;
/*
printf("cl_process_switch: buf=[%s]\n",mcat.mc_bufp);
*/
		pp = mcat.mc_bufp;
		len = mcat.mc_ipos;
	}
	else {
		strcpy(work,"NULL");
		pp = work;
		len = 4;
		p = (char *)prmp[1]->bxobj;
	}
	if (rc = cl_gx_expsn_obj_opt(pp,len,&(prmp[0]->bxobj),pProc->Obj,&InfoParm,0)) return rc;
	pProc->pcrBlockCB->pSwParm = p;

	pProc->Nextleaf = pLeaf->rightleaf;

	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_process_try(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int  rc,i,j,k,num,n,iUsed,nparm;
	tdtInfoParm *pInfoParm,tInfoParm2[2];
	parmList **prmp,*pparmList;
	BlockCB *pIfCB;
	FILE **p0,**p,*ptr;

DEBUGOUTL1(110,"cl_process_try: enter proc=%08x",pProc);
	if (rc = cl_if_pre_proc(pLeaf, pProc)) return rc;
	/* ���̏�Ԃ�ۑ����� */
	pIfCB = pProc->pcrBlockCB;
	pIfCB->try_level = pGlobTable->try_level;
	pIfCB->ucExcept = pProc->ucExcept;
	pIfCB->pFlag = pProc->pFlag;

	/* �V�K��TRY��Ԃ�ݒ肷�� */
	pProc->ucExcept = D_EXCEPT_TRY;
	pIfCB->TureFlag = L_ON;
	pIfCB->Blockleaf = pLeaf;
	pProc->Nextleaf = pLeaf->leftleaf;
DEBUGOUTL1(110,"cl_process_try: push [ %s ]",cl_get_pcmd_line(pLeaf->rightleaf));
	cl_ret_leaf_push(pProc,pLeaf->rightleaf);
	pGlobTable->try_level++;
	pGlobTable->exception = 0;
	*pGlobTable->errmsg = '\0';
/*
printf("cl_process_try: pGlobTable->try_level=%d\n",pGlobTable->try_level);
*/
#if 1	/* 2017.05.20 */
	if  ((num=pLeaf->cmd.prmnum) > 0) {
		if (!(p0 = (FILE **)cl_opt_malloc(D_OPT_ALC_LEAF,num*sizeof(char *)))) return -1;
		pIfCB->pSwParm = (char *)p0;
		iUsed = pIfCB->iUsed;
		pIfCB->iUsed = D_TRY_WITH;;
		prmp = pLeaf->cmd.prmp;
		p = p0;
		for (i=0;i<num;i++) {
			pparmList = prmp[i];
/*
printf("cl_process_try: i=%d len=%d prp=[%s]\n",i,pparmList->prmlen,pparmList->prp);
*/
			if (rc = cl_gx_expsn_obj_opt(pparmList->prp,pparmList->prmlen,
			                  &(pparmList->bxobj),pProc->Obj,tInfoParm2,D_GX_OPT_PARMINFO2)) break;
DEBUGOUT_InfoParm(200,"cl_process_try: i=%d",tInfoParm2,i,0);
#if 1
			nparm = cl_get_InfoParm2(tInfoParm2,&pInfoParm,NULL);
#else
			if ((tInfoParm2[0].pi_alen & D_AULN_PARMINFO2) &&
			    (nparm=tInfoParm2[1].pi_pos)) {
				pInfoParm = (tdtInfoParm *)tInfoParm2[1].pi_data;
			}
			else {
				nparm = 1;
				pInfoParm = tInfoParm2;
			}
#endif
			n = pIfCB->iLoopMax;
			for (j=1;j<=nparm;j++,pInfoParm++) {
				if (pInfoParm->pi_alen & D_AULN_FILE_POINTER) {
					ptr = (FILE *)cl_get_data_long(pInfoParm);
					if (akxs_seqr_ptr(p0,n,ptr) == 0) {
						*p++ = ptr;
						n++;
/*
printf("cl_process_try: j=%d n=%d ptr=%08x\n",j,n,ptr);
*/
					}
				}
			}
			pIfCB->iLoopMax = n;
		}
/*
printf("cl_process_try: pIfCB->iLoopMax=%d\n",pIfCB->iLoopMax);
*/
		pIfCB->iUsed = iUsed;
	}
#endif
/*
printf("cl_process_try:Exit rc=%d\n",rc);
*/
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_get_InfoParm2(tInfoParm2,ppInfoParm,flags)
tdtInfoParm tInfoParm2[],**ppInfoParm;
int flags[];
{
	tdtInfoParm *pInfoParm;
	int nparm,iPARMINFO2;

	if ((tInfoParm2[0].pi_alen & D_AULN_PARMINFO2) && (nparm=tInfoParm2[1].pi_pos)) {
		pInfoParm = (tdtInfoParm *)tInfoParm2[1].pi_data;
		iPARMINFO2 = 1;
	}
	else {
		nparm = 1;
		pInfoParm = tInfoParm2;
		iPARMINFO2 = 0;
	}
	*ppInfoParm = pInfoParm;
	if (flags) flags[0] = iPARMINFO2;
	return nparm;
}
