static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �R�}���h�����ϊ�                                       *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_arg( pparmList )                           *
*                      (I)prmList	*pparmList                                *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include "colmn.h"

int cl_conv_arg_opt_kind(pparmList, pInfoParm, opt, rc)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
int opt,rc;
{
	switch (rc) {
		case	PARAMETER :
			rc = cl_conv_parm_opt(pparmList, pInfoParm, opt);
			break;
		case	CONSTANT_NUM :
			rc = cl_conv_const_n( pparmList , pInfoParm );
			break;
		case	CONSTANT_CHR :
			rc = cl_conv_const_c( pparmList , pInfoParm );
			break;
		case	SYSVAR :
			rc = cl_conv_sysvar( pparmList , pInfoParm );
			break;
		case	NULL_PARM :
			rc = cl_null_parm(pInfoParm);
			break;
		case	0 :
			rc = ERROR;
			break;
		case	SEPARATOR :
			break;
		default:
			cl_set_parm_char2(pInfoParm,pparmList->prp,pparmList->prmlen,GET_TYPE_OPT(pparmList->opt));
			rc = NAME_CONST;
			break;
	}
	return rc;
}

int cl_conv_arg_opt(pparmList, pInfoParm, opt)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
int opt;
{
	int	rc;

	opt &= ~D_GX_OPT_STORE;
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	rc = cl_anal_parm(pparmList);
	return cl_conv_arg_opt_kind(pparmList,pInfoParm,opt,rc);
}

int cl_conv_arg( pparmList , pInfoParm )
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
{
	return cl_conv_arg_opt(pparmList, pInfoParm, 0);
}

/* K-00057 �ȉ��ǉ� */
int cl_arg_to_var(pparmList, Obj, pprList)
parmList *pparmList;
int      *Obj;
prmList  *pprList;
{
	int	rc;
	tdtInfoParm  InfoParm;

	memset(pprList,0,sizeof(prmList));
	rc = cl_gx_exp_obj(1,&pparmList,Obj,&InfoParm);
	if (rc == NORMAL) {
		rc = cmpktform( pprList , &InfoParm );
	}
	return( rc );
}

int cl_arg_to_char(pparmList,Obj,pInfoParm,msg)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
{
	return cl_arg_to_char_opt(pparmList,Obj,pInfoParm,msg,0);
}

int cl_arg_to_char_num(pparmList,Obj,pInfoParm,msg,opt,only_char)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
int       opt;
int       only_char;	/* =0:char or num, <>0: only char */
{
	int  rc,len,atr,opt_type,code_type;
	char *p,*dat;

	if (!(p=msg)) p = FORMAT(297);	/* �p�����[�^ */
#if 1	/* 2020.3.1 */
	dat = pparmList->prp;
	len = pparmList->prmlen;
	code_type = SET_TYPE_OPT(pparmList->opt);
DEBUGOUTL3(120,"cl_arg_to_char:Enter len=%d dat=[%s] p=[%s]",len,dat,p);
#if 1	/* 2020.3.15 */
	if (!cl_chk_name_opt(dat,len,pparmList->opt)) {
#else
	if ((rc=cl_is_exp(dat,len,opt)) < 0) return rc;
	else if (!rc) {
#endif
DEBUGOUTL3(120,"cl_arg_to_char: NAME_CONST rc=%d len=%d dat=[%s]",rc,len,dat);
		return cl_set_parm_char2(pInfoParm,dat,len,code_type);
	}
#endif
	rc = cl_anal_parm(pparmList);
	if (rc < 0) {
		ERROROUT1(FORMAT(298),p);	/* %s�擾�G���[ */
		return rc;
	}
	else if (rc == NULL_PARM) {
		rc = cl_null_parm(pInfoParm);
	}
	else {
		len = pparmList->prmlen;
		dat = pparmList->prp;
		opt_type = pparmList->opt & CD_TYPE_OPT_MASK;
		if (rc == NAME_CONST) {
		/*	if (akxnskipto(dat,len,"(") >= len) {	*/
			if (akx_skip_opt(dat,len,"(",0x08 | opt_type) >= len) {
				rc = cl_set_parm_char(pInfoParm,dat,len);
DEBUGOUTL2(120,"cl_arg_to_char: NAME_CONST2 len=%d dat=[%s]",len,dat);
				return rc;
			}
		}
		rc = cl_gx_exp_obj_opt(1,&pparmList,Obj,pInfoParm,opt);
		if (rc) {
			ERROROUT2(FORMAT(299),p,dat);	/* %s[%s]�Ɍ�肪����܂��B */
			rc = ECL_SCRIPT_ERROR;
		}
		else {
DEBUGOUT_InfoParm(120,"cl_arg_to_char_num: ",pInfoParm,0,0);
			atr = pInfoParm->pi_attr;
			if (only_char && atr != DEF_ZOK_CHAR) {
				ERROROUT2(FORMAT(300),p,dat);	/* %s[%s]�������^�ł͂���܂���B */
				rc = ECL_SCRIPT_ERROR;
			}
			else if (atr==DEF_ZOK_CHAR || atr==DEF_ZOK_BINA ||
			         atr==DEF_ZOK_FLOA || atr==DEF_ZOK_DECI) ;
			else {
				ERROROUT2(FORMAT(45),p,dat);	/* %s: �p�����[�^[%s]������Ă��܂��B */
				rc = ECL_SCRIPT_ERROR;
			}
		}
	}
	return rc;
}

int cl_arg_to_char_opt(pparmList,Obj,pInfoParm,msg,opt)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
int       opt;
{
	return cl_arg_to_char_num(pparmList,Obj,pInfoParm,msg,opt,1);
}

int cl_ot_conv_arg(pparmList,Obj,pValue)
parmList   *pparmList;
int        *Obj;
int		   *pValue;
{
	int			rc, Value;
	tdtInfoParm 	InfoParm;
	char        *pWork,*name;

	name = "cl_ot_conv_arg";
	pWork = pparmList->prp;
	rc = cl_gx_exp_obj(1,&pparmList,Obj,&InfoParm);
	if (rc) {
		ERROROUT2(FORMAT(45),name,pWork);	/* %s: �p�����[�^[%s]������Ă��܂��B */
		return ECL_EX_OUTPUT;
	}

	if (InfoParm.pi_attr != DEF_ZOK_BINA) {
		ERROROUT2(FORMAT(46),name,pWork);	/* "%s: �p�����[�^[%s]�����l�ł͂���܂���B */
		return ECL_EX_OUTPUT;
	}

/*	memcpy(pValue,InfoParm.pi_data,sizeof(int));	*/
	*pValue = Value = cl_get_data_long(&InfoParm);

	if (Value < 0 || Value > 99999) {
		ERROROUT2(FORMAT(116),name,Value);	/* %s: �l(%d)���͈͊O(0-99999)�ł��B */
		rc = ECL_EX_OUTPUT;
	}

	return rc;
}
