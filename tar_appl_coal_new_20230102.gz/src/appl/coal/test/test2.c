#if 1	/*   */
	printf("sizeof(a[10])=%d\n",sizeof(a));
#endif
