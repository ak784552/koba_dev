#include <stdio.h>

#define AKX_HASX_OPT_NO_NEXT	2
#define AKX_HASX_OPT_CASE_KEY	4
main()
{
	int a[10];
#ifdef
	aaaaaaaaa
#else
#if 0
	bbbbbbbbb
#else
	ccccccccc
#endif
#endif

#if 0	/*   */
	printf("sizeof(a[10])=%d\n",sizeof(a));
#else
#if 0
	printf("sizeof(ushort)=%d\n",sizeof(ushort));
#else
	printf("sizeof(unsigned short)=%d\n",sizeof(unsigned short));
#endif
	xxxxxxxxxxxxxxxxxxxx;
#endif

#if defined(_LP64)
		memcpy(pvalue,&lVal,sizeof(long));
#else
		*pvalue = lVal;
#endif
	return 0;
}
