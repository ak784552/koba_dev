/******************************************/
/*                                        */
/*             cmprot.h                   */
/*                                        */
/******************************************/
#ifndef _CMPROT_H
#define _CMPROT_H

/* cmpktform.c */
int cm_set_pkt_form(/*pInfoParm ,pBuff*/);
int cmn_i_to_a(/*n, str*/);

/* cmstat.c */
void   cmn_set_stat();
int    cmn_chk_stat();

/* cmitoa.c */
int cmn_mrzcpy(/*str1,str2,len*/);

int   akb_ptime ();
int   akb_errorout();
int   akxtgwse();
int   akbmeminit();
char *akbmalloc();
char *akbrealloc();
void  akbfree();
int   akbnofree();

#endif	/* _CMPROT_H */
