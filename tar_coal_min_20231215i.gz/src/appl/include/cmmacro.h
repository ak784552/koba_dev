/*static	char	sccsid[]="%Z% %M% %I% %E% %U%";*/
/******************************************/
/*                                        */
/*             cmmacro.h                  */
/*                                        */
/******************************************/
#ifndef _CMMACRO_H
#define _CMMACRO_H
typedef struct tm DATE;

#define axs_xhash     akxs_xhash
#define axccvn       akxccvn
#define axs_xhashFree akxs_xhashFree
#define axcetos      akxcetos
#define axcstoe      akxcstoe
#define axtmcats     akxtmcats
#define axtmcat      akxtmcat
#define axtgwsp      akxtgwsp
#define axaxdump     akxaxdump
#define axtgwse      akxtgwse
#define iskanji      akxqiskanji
#define axcstoj1     akxcstoj1
#define axcjtos1     akxcjtos1
#define axs_xhashInit akxs_xhashInit
#define akb_ptime    akbPtime

#define ConstantCt	tdtCONSTCT

#if defined(COAL) || defined(OLD_COAL)
#undef ERROROUT
#undef ERROROUT1
#undef ERROROUT2
#undef ERROROUT3
#undef ERROROUT4
#undef ERROROUT5
/*#undef ERROROUTRC
#undef ERROROUTS*/
#undef ERRORHOLD5

#undef PRINTOUT
#undef PRINTOUT1
#undef PRINTOUT2
#undef PRINTOUT3
#undef PRINTOUT4
#undef PRINTOUT5
#undef LOGOUT

#undef DEBUGOUTL
#undef DEBUGOUTL1
#undef DEBUGOUTL2
#undef DEBUGOUTL3
#undef DEBUGOUTL4
#undef DEBUGOUTL5
#undef DEBUGOUT_Leaf

#define CMSGLVL	1
#define CERROROUTL5(l,fmt,a1,a2,a3,a4,a5) \
		cl_log_out_l5(D_LOG_NO_ERROR,l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define ERROROUT1(fmt,a1) CERROROUTL5(CMSGLVL,fmt,a1,NULL,NULL,NULL,NULL)
#define ERROROUT2(fmt,a1,a2) CERROROUTL5(CMSGLVL,fmt,a1,a2,NULL,NULL,NULL)
#define ERROROUT3(fmt,a1,a2,a3) CERROROUTL5(CMSGLVL,fmt,a1,a2,a3,NULL,NULL)
#define ERROROUT4(fmt,a1,a2,a3,a4) CERROROUTL5(CMSGLVL,fmt,a1,a2,a3,a4,NULL)
#define ERROROUT5(fmt,a1,a2,a3,a4,a5) CERROROUTL5(CMSGLVL,fmt,a1,a2,a3,a4,a5)
/*#define ERROROUTRC(msg,rc) ERROROUT2("%s%d",msg,rc)
#define ERROROUTS(fmt,msg) ERROROUT1(fmt,msg)*/
#define ERROROUT(msg) ERROROUT1("%s",msg)
#define ERRORHOLD5(fmt,a1,a2,a3,a4,a5) \
		cl_log_out_opt_l5(D_LOG_NO_ERROR,CMSGLVL,0x01,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)

#define CPRINTOUTL5(l,fmt,a1,a2,a3,a4,a5) \
		cl_log_out_l5(D_LOG_NO_PRINT,l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define PRINTOUT1(fmt,a1) CPRINTOUTL5(CMSGLVL,fmt,a1,NULL,NULL,NULL,NULL)
#define PRINTOUT2(fmt,a1,a2) CPRINTOUTL5(CMSGLVL,fmt,a1,a2,NULL,NULL,NULL)
#define PRINTOUT3(fmt,a1,a2,a3) CPRINTOUTL5(CMSGLVL,fmt,a1,a2,a3,NULL,NULL)
#define PRINTOUT4(fmt,a1,a2,a3,a4) CPRINTOUTL5(CMSGLVL,fmt,a1,a2,a3,a4,NULL)
#define PRINTOUT5(fmt,a1,a2,a3,a4,a5) CPRINTOUTL5(CMSGLVL,fmt,a1,a2,a3,a4,a5)
#define PRINTOUT(msg) PRINTOUT1("%s",msg)
#define LOGOUT(msg) PRINTOUT(msg)

#define CDEBUGOUTL5(l,fmt,a1,a2,a3,a4,a5) \
		cl_log_out_l5(D_LOG_NO_DEBUG,l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define DEBUGOUTL1(level,fmt,a1) CDEBUGOUTL5(level,fmt,a1,NULL,NULL,NULL,NULL)
#define DEBUGOUTL2(level,fmt,a1,a2) CDEBUGOUTL5(level,fmt,a1,a2,NULL,NULL,NULL)
#define DEBUGOUTL3(level,fmt,a1,a2,a3) CDEBUGOUTL5(level,fmt,a1,a2,a3,NULL,NULL)
#define DEBUGOUTL4(level,fmt,a1,a2,a3,a4) CDEBUGOUTL5(level,fmt,a1,a2,a3,a4,NULL)
#define DEBUGOUTL5(level,fmt,a1,a2,a3,a4,a5) CDEBUGOUTL5(level,fmt,a1,a2,a3,a4,a5)
#define DEBUGOUTL(level,msg) DEBUGOUTL1(level,"%s",msg)
#define DEBUGOUT_InfoParm(level,fmt,pInfo,a1,a2) \
		cl_debug_out_info_parm(level,__FILE__,__LINE__,fmt,pInfo,a1,a2)
#define DEBUGOUT_InfoParm5(level,fmt,pInfo,a1,a2,a3,a4,a5) \
		cl_debug_out_info_parm5(level,__FILE__,__LINE__,fmt,pInfo,a1,a2,a3,a4,a5)
#define DEBUGOUT_Leaf(level,msg,leaf) \
		cl_log_debug_leaf(level,__FILE__,__LINE__,msg,leaf)
#endif

#define RETURN(x) {return cl_debug_out_return(__FILE__,__LINE__,__FUNCTION__,x);}

#define ADDRCHK(p)	addrchk(__FILE__,__LINE__,p)
#define FORMAT(no)	cl_get_format(no)
#define CHKSAVEINFO(msg) cl_log_chk_save_info(__FILE__,__LINE__,msg)

#if defined(_LP64)
#define CL_GET_VAL_BIN(Val) cl_get_val_long(Val)
#else
#define CL_GET_VAL_BIN(Val) Val[0]
#define cl_get_parm_long_opt(pInfoParm,pValue,pMsg,opt) cl_get_parm_bin_opt(pInfoParm,pValue,pMsg,opt)
#define cl_get_parm_ulong_opt(pInfoParm,pValue,pMsg,iUNSIG,opt) cl_get_parm_ubin_opt(pInfoParm,pValue,pMsg,iUNSIG,opt)
#define cl_get_parm_long(pInfoParm,pValue,pMsg) cl_get_parm_bin(pInfoParm,pValue,pMsg)
#define cl_get_parm_ulong(pInfoParm,pValue,pMsg,iUNSIG) cl_get_parm_ubin(pInfoParm,pValue,pMsg,iUNSIG)
#endif

#define CTMalloc(ConstCt,Len) \
		cl_const_ct_malloc2(ConstCt,Len,__FILE__,__LINE__)

#define TEMPMalloc(len) \
		cl_tmp_const_malloc2(len,__FILE__,__LINE__)

#define OPTMalloc(im,iLen) \
		cl_opt_malloc2(im,iLen,__FILE__,__LINE__)

#endif	/* _CMMACRO_H */
