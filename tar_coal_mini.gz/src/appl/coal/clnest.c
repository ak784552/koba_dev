static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       cl_check_nest                 */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*                                               */
/*       Out       1 - 5:Normal                  */
/*                -1    :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     ���[�t�̃l�X�g���x���ŏ��̕��𒲂ׂ�B    */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/

int cl_check_nest(y)
condList *y;
{
	CLNCB *p;

	p = y->clstcb;
	if      (p->nestLev1) return 1;
	else if (p->nestLev2) return 2;
	else if (p->nestLev3) return 3;
	else return NormalEnd;
}

/*************************************************/
/*  Program name                                 */
/*       int       cl_search_nest                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In        short    NestLevel            */
/*                                               */
/*       Out       1 - 5:Normal                  */
/*                -1    :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     ���[�t�̃l�X�g����������B                */
/*************************************************/

int cl_search_nest(y,NestLevel)
condList *y;
short  NestLevel;
{
	Leaf *SrLeaf;
	CLNCB *p;

	p = y->clstcb;
	SrLeaf = p->TopStack;

	for (;;) {
		if (SrLeaf->cmd.type == NestLevel) {
			switch (NestLevel) {
			case 1:
				p->nestLev1 = (Leaf *)SrLeaf;
				break;
			case 2:
				p->nestLev2 = (Leaf *)SrLeaf;
				break;
			case 3:
				p->nestLev3 = (Leaf *)SrLeaf;
				break;
			}
			break;
		}
		SrLeaf = SrLeaf->preleaf;
		if (!SrLeaf) {
			switch (NestLevel) {
			case 1:
				p->nestLev1 = NULL;
				break;
			case 2:
				p->nestLev2 = NULL;
				break;
			case 3:
				p->nestLev3 = NULL;
				break;
			}
			break;
		}
	}
	return NormalEnd;
}

/*************************************************/
/*  Program name                                 */
/*       int       cl_pre_nest                   */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In                                      */
/*             short   NestLevel                 */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     ���[�t���쐬���A�X�^�b�N�ɐςށB          */
/*************************************************/
int cl_pre_nest(y)
condList *y;
{
	int rc;

	switch (y->AddressRoot->cmd.type) {
	case 1:
		break;
	case 2:
	/*	rc = cl_check_nest();
		if ( rc == 1 ) rc = tcErrNest1(); */
		break;
	case 3:
	/*	rc = cl_check_nest();
		if ( rc == 1 ) rc = tcErrNest1();
		if ( rc == 2 ) rc = tcErrNest2(); */
		break;
	case 4:
	/*	rc = cl_check_nest();
		if ( rc == 1 ) rc = tcErrNest1();
		if ( rc == 2 ) rc = tcErrNest2();
		if ( rc == 3 ) rc = tcErrNest3(); */
		break;
	default:
		break;
	}
	return NormalEnd;
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_nest_tag                  */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         int   NestLevel              */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     ���ݏ������̎w�肳�ꂽ�l�X�g���x����      */
/*       �^�O��ʂ�Ԃ��B                        */
/*************************************************/
int cl_nest_tag(y,NestLevel)
condList *y;
short NestLevel;
{
	Leaf *Wleaf;
	int  cId;
	CLNCB *p;

	p = y->clstcb;
	switch (NestLevel) {
		case 1 :
			Wleaf = p->nestLev1;
			break;
		case 2 :
			Wleaf = p->nestLev2;
			break;
		case 3 :
			Wleaf = p->nestLev3;
			break;
		default :
			return SysError;
	}

/*	tId = (Wleaf!=NULL) ? Wleaf->cmd.cid : T_UNKNOWN;	*/

	if (!Wleaf) return SysError;

	cId = Wleaf->cmd.cid;

	return cId;
}
