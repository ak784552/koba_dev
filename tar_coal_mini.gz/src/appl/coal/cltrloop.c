static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_loop                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Justify no shori.                         */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"
#if 0
extern condList  CLcList;  /* ��񃊃X�g */
extern tableRoot CLtbl;   /* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */
#endif
#if 0
/********************************************/
/*											*/
/********************************************/
static int _change_from_for(y)
condList *y;
{
	static char *_func_="_change_from_for";
	static char sep[]={" \t\"'();"};
	SSP_S ssp;
	int rc,len,i,num,pnm_len,st_pos,nbun;
	int kk_level;	/* ()�̃l�X�g���x�� */
	char *pnm,buf[33];
	GWPRM_S gwprm;
	SSPL_S sspl;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum <= 1) return 0;
	memset(&sspl,0,sizeof(SSPL_S));
	gwprm.nparam = cmd->prmnum - 1;
	gwprm.maxlen = 0;
	gwprm.parmLp = &cmd->prmp[1];
	gwprm.iparam = 0;
	if (cl_gp_gwse(&gwprm,&sspl,sep,0x21) <= 0) return 0;
	if (*sspl.wd == '(') {
		nbun = 0;
		while (cl_gp_gwse(&gwprm,&sspl,sep,0x21) > 0) {
			if (*sspl.wd == ';') {
				nbun++;
				break;
			}
		}
		if (!nbun) return 0;
	}
	else return 0;
/*
printf("%s: nbun=%d\n",_func_,nbun);
*/
	if ((rc=cl_tr_gather(y,1)) < 0) return rc;
	pnm = cmd->prmp[1]->prp;
	pnm_len = cmd->prmp[1]->prmlen;
	num = cmd->prmnum;
/*
printf("%s: num=%d pnm_len=%d pnm=[%s]\n",_func_,num,pnm_len,pnm);
printf("%s: st_pos=%d\n",_func_,st_pos);
*/
	st_pos = 1;
	ssp.sp = st_pos;
	kk_level = 1;
	rc = nbun = 0;
	while ((len=akxtgwns(pnm,pnm_len,&ssp,sep,0x21)) > 0) {
		switch (*ssp.wd) {
		case '(':
			kk_level++;
			break;
		case ')':
			if (--kk_level <= 0) {
				if ((len=akxtpkns(pnm,pnm_len,&ssp," \t",0x21)) > 0) {
					memnzcpy(buf,ssp.wd,len,sizeof(buf));
				/*	if (stricmp(buf,"AS")) {	*/
						/* %s: �E����')'�̌��ɗ]���Ȍ��[%s]������܂��B(sp=%d) */
						ERROROUT3(FORMAT(96),_func_,buf,ssp.sp);
					 	rc = ECL_SCRIPT_ERROR;
						goto Err;
				/*	}	*/
				}
/*
printf("%s: st_pos=%d ssp.sp=%d\n",_func_,st_pos,ssp.sp);
*/
				if (rc=clparmset(y,pnm+st_pos,ssp.sp-st_pos-1)) goto Err;
			}
			break;
		case ';':
			rc = ECL_SCRIPT_ERROR;
			if (kk_level > 1) {
				/* %s: ��؂�';'�̈ʒu���s���ł��B(sp=%d) */
				ERROROUT2(FORMAT(97),_func_,ssp.sp);
				goto Err;
			}
			else if (++nbun > 2) {
				/* %s: ��؂�';'���������܂��B(sp=%d) */
				ERROROUT2(FORMAT(98),_func_,ssp.sp);
				goto Err;
			}
			if (rc=clparmset(y,pnm+st_pos,ssp.sp-st_pos-1))  goto Err;
			st_pos = ssp.sp;
			break;
		}
	}
 	rc = ECL_SCRIPT_ERROR;
	if (kk_level > 0) {
		ERROROUT1(FORMAT(99),_func_);	/* %s: ���ʂ����Ă��܂���B */
		goto Err;
	}
	else if (nbun < 2) {
		ERROROUT1(FORMAT(100),_func_);	/* %s: ��؂�';'������܂���B */
		goto Err;
	}
	num = --cmd->prmnum;
	for (i=1;i<num;i++) cmd->prmp[i] = cmd->prmp[i+1];
	return num;
 Err:
	cmd->prmnum = num;
 	return rc;
}

/********************************************/
/*											*/
/********************************************/
static int _change_from_to_step(y)
condList *y;
{
	static char *_fn_="_change_from_to_step";
	static char *p0=NULL;
	int ret,i,len,k,s,num,pos,len2,len3,f,len4;
	char *p1,*p2,*p3,*p,c,*argv[5];
	parmList **prmL;
	cmdInfo *cmd;

	cmd = y->cmd;
	num = cmd->prmnum;
	prmL = cmd->prmp;
	ret = 0;
	if (num>=3) {
		if (!stricmp(prmL[2]->prp,"TO")) {
			if (num == 3) {
				ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B */
				return ECL_SCRIPT_ERROR;
			}
			p1 = prmL[1]->prp;
			len = prmL[1]->prmlen;
			if ((pos=akxnskipto(p1,len,"=")) >= len) {
				/* %s: �����l��[%s]��'='������܂���B */
				ERROROUT2(FORMAT(485),_fn_,p1);
				return ECL_SCRIPT_ERROR;
			}
			p2 = p3 = NULL;
			f = 0;
			for (i=3;i<num;i++) {
				if (!cl_is_not_space(prmL[i])) {
					ERROROUT1(FORMAT(486),_fn_);	/* %s: �p�����[�^��NULL�ł��B */
					ret = ECL_SCRIPT_ERROR;
				}
				else {
					p = prmL[i]->prp;
					if (i!=4 && !stricmp(p,"STEP")) {
						ERROROUT1(FORMAT(487),_fn_);	/* %s: STEP�̈ʒu���s���ł��B */
						ret = ECL_SCRIPT_ERROR;
						f = 1;
					}
					else if (i == 3) p2 = p;
					else if (i == 5) p3 = p;
				}
			}
			if (num >= 5) {
				if (!f && stricmp(prmL[4]->prp,"STEP")) {
					ERROROUT1(FORMAT(488),_fn_);	/* %s: STEP������܂���B  */
					ret = ECL_SCRIPT_ERROR;
				}
				if (num == 5) {
					ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B */
					ret = ECL_SCRIPT_ERROR;
				}
				else if (num > 6) {
				/*	if (stricmp((p=prmL[6]->prp),"AS")) {	*/
						/* %s: �]���ȃp�����[�^[%s]������܂��B */
						ERROROUT2(FORMAT(43),_fn_,prmL[6]->prp);
						ret = ECL_SCRIPT_ERROR;
				/*	}	*/
				}
				if (ret) return ret;
			}
			len4 = 0;
			s = 1;
			if (p3) {
				if (!strcmp(p3,"1") || !strcmp(p3,"+1")) s = 1;
				else if (!strcmp(p3,"-1")) s = -1;
				else {
					s = 0;
					len4 = strlen(p3) + 9;
				}
			}
			len2 = len3 = pos + 5;
			len2 += strlen(p2);
			len = len2 + len3;
			if (len4) {
				len3 += len4;
				len += len4 + len2 + len3;
			}
			if (!(p=MRealloc(p0,len))) return -1;
			argv[1] = p;
			memcpy(p,p1,pos);
			if (p3) {
				if (s < 0) {
					strcpy(p+pos,"--");
/*
printf("%s: wrk2=[%s]\n",_fn_,p);
*/
					p += len3;
					argv[0] = p;
					memcpy(p,p1,pos);
					sprintf(p+pos,">=(%s)",p2);
/*
printf("%s: wrk1=[%s]\n",_fn_,p);
*/
				}
				else if (s == 0) {
					sprintf(p+pos,"+=(%s)",p3);
/*
printf("%s: wrk2=[%s]\n",_fn_,p);
*/
					p += len3;
					argv[0] = p;
					memcpy(p,p1,pos);
					sprintf(p+pos,"<=(%s)",p2);
/*
printf("%s: wrk1=[%s]\n",_fn_,p);
*/
					p += len2;
					argv[2] = p;
					sprintf(p,"%s>=0?1:-1",p3);
/*
printf("%s: wrk3=[%s]\n",_fn_,p);
*/
					p += len4 + 1;
					argv[3] = p;
					memcpy(p,p1,pos);
					sprintf(p+pos,">=(%s)",p2);
/*
printf("%s: wrk4=[%s]\n",_fn_,p);
*/
				}
			}
			if (s > 0) {
				strcpy(p+pos,"++");
/*
printf("%s: wrk2=[%s]\n",_fn_,p);
*/
				p += len3;
				argv[0] = p;
				memcpy(p,p1,pos);
				sprintf(p+pos,"<=(%s)",p2);
/*
printf("%s: wrk1=[%s]\n",_fn_,p);
*/
			}
			cmd->prmnum = 2;
			if (ret=clparmset(y,argv[0],strlen(argv[0]))) return ret;
			if (ret=clparmset(y,argv[1],strlen(argv[1]))) return ret;
			if (len4) {
				if (ret=clparmset(y,argv[2],strlen(argv[2]))) return ret;
				if (ret=clparmset(y,argv[3],strlen(argv[3]))) return ret;
			}
		}
	}
	return 0;
}
#endif
/********************************************/
/*											*/
/********************************************/
int col_mn_tr_loop(y)
condList *y;
{
	static char *_fn="col_mn_tr_loop";
	int rc,len,n,i,pnum,cid,scno;
	char *name,*pnm;
	cmdInfo *cmd;
	parmList **prmL;

	cmd = y->cmd;
#if 0
	if (cl_nest_tag(1) == SysError) {
		ERROROUT(FORMAT(101));
		return ( ECL_TR_LOOP );
	}
	rc = cl_search_active_loop(y);
	if ( rc ) {
		if (rc == -1) ERROROUT(FORMAT(101);
	/*	if (rc == -2) ERROROUT(FORMAT(102);	*/
		return ( ECL_TR_LOOP );
	}
#endif
/*
	if ((cid=cmd->cid)!=C_DO && !cmd->prmnum) {
		ERROROUT(FORMAT(103);
		return ( ECL_TR_LOOP );
	}
*/
	cid = cmd->cid;
	prmL = cmd->prmp;
#if 0
	if (cid==C_FOR && !strnicmp(cmd->prmp[0]->prp,"EACH",4)) ;
	else if (cid==C_FOR || cid==C_WHILE || cid==C_UNTIL) {
		cl_tr_insert(y,0,cl_gets_cmd_name(cid));
		cmd->cid = C_LOOP;
	}
#endif
	pnum = cmd->prmnum;
	if (pnum > 0)
		pnm = prmL[0]->prp;
	else pnm = "";

	scno = 0;
#if 0
	if (!strnicmp(pnm,"WHILE",5) || !strnicmp(pnm,"UNTIL",5) ||
	    !strnicmp(pnm,"EACH",4)) {
		cl_tr_split(y,0,"(");
		pnum = cmd->prmnum;
		pnm = prmL[0]->prp;
		if (pnum>=2 && !stricmp(pnm,"WHILE")) scno = D_LOOP_WHILE;
		else if (pnum>=2 && !stricmp(pnm,"UNTIL")) scno = D_LOOP_UNTIL;
		else if (pnum>=4) scno = D_LOOP_EACH;
		else scno = -1;
	}
	else if (!strnicmp(pnm,"FOR",3)) {
		cl_tr_split(y,0,"(");
		if ((rc=_change_from_for(y)) < 0) return rc;
		else if (!rc) {
			if (rc=_change_from_to_step(y)) return rc;
		}
		pnum = cmd->prmnum;
		if (pnum>=2) scno = D_LOOP_FOR;
		else scno = -1;
	}
#endif
/*
	else if (cid==C_DO && cmd->prmnum>0) {
		ERROROUT1(FORMAT(41),"ColMnTrDo");
		return  ECL_TR_LOOP;
	}
*/
	if (scno < 0) {
		ERROROUT1(FORMAT(42),_fn);
		return  ECL_TR_LOOP;
	}
	cmd->sub_cid |= scno;

	if (!(rc=cl_make_leaf(y))) {
		cl_pre_nest(y);
		if (!(rc=cl_push(y))) rc= cl_change_stcb(y);
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_tr_insert(y,ip,name)
condList *y;
int ip;
char *name;
{
	int rc,len,n,i,num;
	cmdInfo *cmd;

	cmd = y->cmd;
	num = cmd->prmnum;
	if (ip<num && num<y->max_prmnum) {
		for (i=num;i>ip;i--) cmd->prmp[i] = cmd->prmp[i-1];
		cmd->prmnum = ip;
		if (rc=clparmset(y,name,strlen(name))) return rc;
		n = cmd->prmnum = num + 1;
	}
	else n = 0;
	return n;
}

int cl_search_active_loop(y)
condList *y;
{
	Leaf  *Dummy;
	CLNCB *p;

	p = y->clstcb;
	if (!(Dummy = p->nestLev2)) return 0;
	while (Dummy) {

		if ( Dummy == p->nestLev1 ||
		    (Dummy->cmd.type == 0 && Dummy->cmd.cid == C_LOOP) )
			return ( 0 );
	/*
		else if ( Dummy->cmd.cid == C_LOOP ) return ( -2 );
	*/
		Dummy = Dummy->preleaf;
	}
	return -1;
}
