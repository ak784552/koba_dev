char version[] ="@(#) ***[V/R=1.1.2 (mini)]***";

