char version[] ="@(#) ***[V/R=1.1.3 (mini)]***";

