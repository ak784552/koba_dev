#!/bin/sh

if [ ! -r version ];then echo 3 > version;fi
if [ ! -r revision ];then echo 0 > revision;fi
touch revision

REVS=`expr \`cat revision\` + 1`

echo 'char version[] ="@(#) ***[V/R='`cat version`'.'$REVS]***'";' > vers.c
echo >> vers.c

echo $REVS>revision
