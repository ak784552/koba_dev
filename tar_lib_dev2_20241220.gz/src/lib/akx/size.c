static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#include <stdio.h>
#include <memory.h>
#include <time.h>
main()
{
	int a[10];
	unsigned short us;
	unsigned char  uc[2];

	printf("sizeof(int)=%d\n",sizeof(int));
	printf("sizeof(long)=%d\n",sizeof(long));
	printf("sizeof(char *)=%d\n",sizeof(char *));
	printf("sizeof(int a[10])=%d\n",sizeof(a));
	printf("sizeof(size_t)=%d\n",sizeof(size_t));
	printf("sizeof(off_t)=%d\n",sizeof(off_t));
	printf("sizeof(time_t)=%d\n",sizeof(time_t));

	uc[0] = 0x21;
	uc[1] = '%';
	memcpy(&us,uc,2);
	printf("memcpy: us=%04x\n",us);
	us = 0x21<<8 | '%';
	printf("shift:  us=%04x\n",us);

	printf("1.7976931348623157e+308=%.16e\n",1.7976931348623157e+308);	/* IEEE double */
	printf("-1.7976931348623157e+308=%.16e\n",-1.7976931348623157e+308);
	printf("2.2250738585072014e-308=%.16e\n",2.2250738585072014e-308);	/* ���̍ŏ��̐��K���� */

}
