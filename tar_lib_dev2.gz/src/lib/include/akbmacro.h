/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akbmacro.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.5.28						*/
/*																		*/
/************************************************************************/
#ifndef _AKBMACRO_H
#define _AKBMACRO_H

/* */

/*****************************************/
/*                                       */
/*****************************************/

#define  sswitch(a)  {char *_p = a; if(0){
#define  scase(b)    }else if (!strcmp(_p,b)){
#define  sicase(b)   }else if (!stricmp(_p,b)){
#define  sicase2(b,c)   }else if (!stricmp(_p,b) || !stricmp(_p,c)){
#define  sicase3(b,c,d)   }else if (!stricmp(_p,b) || !stricmp(_p,c) || !stricmp(_p,d)){
#define  sicase4(b,c,d,e)   }else if (!stricmp(_p,b) || !stricmp(_p,c) || !stricmp(_p,d) || !stricmp(_p,e)){
#define  sdefault    }else{
#define  endssw      }}
#define forever		for (;;)

/*****************************************/
/*                                       */
/*****************************************/

#define MACchk_0_9(n)   (n >= 0x30 && \
                         n <= 0x39 )   /* �����`�F�b�N                   */
#define MACchk_A_F(n)   (n >= 0x41 && \
                         n <= 0x46 )   /* �P�U�i���p���`�F�b�N�i�啶���j */
#define MACchk_a_f(n)   (n >= 0x61 && \
                         n <= 0x66 )   /* �P�U�i���p���`�F�b�N�i�������j */

#define ERROROUTLP(l,pri,msg) \
	akb_error_out_level_pri(l,__FILE__,__LINE__,pri,"%s",msg,NULL,NULL,NULL,NULL)
#define ERROROUTLP1(l,pri,fmt,a1) \
	akb_error_out_level_pri(l,__FILE__,__LINE__,pri,fmt,a1,NULL,NULL,NULL,NULL)
#define ERROROUTLP2(l,pri,fmt,a1,a2) \
	akb_error_out_level_pri(l,__FILE__,__LINE__,pri,fmt,a1,a2,NULL,NULL,NULL)
#define ERROROUTLP3(l,pri,fmt,a1,a2,a3) \
	akb_error_out_level_pri(l,__FILE__,__LINE__,pri,fmt,a1,a2,a3,NULL,NULL)
#define ERROROUTLP4(l,pri,fmt,a1,a2,a3,a4) \
	akb_error_out_level_pri(l,__FILE__,__LINE__,pri,fmt,a1,a2,a3,a4,NULL)
#define ERROROUTLP5(l,pri,fmt,a1,a2,a3,a4,a5) \
	akb_error_out_level_pri(l,__FILE__,__LINE__,pri,fmt,a1,a2,a3,a4,a5)

#define ERROROUTP(pri,msg)  ERROROUTLP(0,pri,msg)
#define ERROROUTP1(pri,fmt,a1) ERROROUTLP1(0,pri,fmt,a1)
#define ERROROUTP2(pri,fmt,a1,a2) ERROROUTLP2(0,pri,fmt,a1,a2)
#define ERROROUTP3(pri,fmt,a1,a2,a3) ERROROUTLP3(0,pri,fmt,a1,a2,a3)
#define ERROROUTP4(pri,fmt,a1,a2,a3,a4) ERROROUTLP4(0,pri,fmt,a1,a2,a3,a4)
#define ERROROUTP5(pri,fmt,a1,a2,a3,a4,a5) ERROROUTLP5(0,pri,fmt,a1,a2,a3,a4,a5)

#define ERROROUTL(l,msg) \
	akb_error_out_level(l,__FILE__,__LINE__,"%s",msg,NULL,NULL,NULL,NULL)
#define ERROROUTL1(l,fmt,a1) \
	akb_error_out_level(l,__FILE__,__LINE__,fmt,a1,NULL,NULL,NULL,NULL)
#define ERROROUTL2(l,fmt,a1,a2) \
	akb_error_out_level(l,__FILE__,__LINE__,fmt,a1,a2,NULL,NULL,NULL)
#define ERROROUTL3(l,fmt,a1,a2,a3) \
	akb_error_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,NULL,NULL)
#define ERROROUTL4(l,fmt,a1,a2,a3,a4) \
	akb_error_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,NULL)
#define ERROROUTL5(l,fmt,a1,a2,a3,a4,a5) \
	akb_error_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)

#define FERROROUTL(l,fp,msg) \
	akb_ferror_out_level(l,__FILE__,__LINE__,fp,"%s",msg,NULL,NULL,NULL,NULL)

#define ERROROUT(msg)  ERROROUTL(0,msg)
#define ERROROUT1(fmt,a1) ERROROUTL1(0,fmt,a1)
#define ERROROUT2(fmt,a1,a2) ERROROUTL2(0,fmt,a1,a2)
#define ERROROUT3(fmt,a1,a2,a3) ERROROUTL3(0,fmt,a1,a2,a3)
#define ERROROUT4(fmt,a1,a2,a3,a4) ERROROUTL4(0,fmt,a1,a2,a3,a4)
#define ERROROUT5(fmt,a1,a2,a3,a4,a5) ERROROUTL5(0,fmt,a1,a2,a3,a4,a5)

#ifdef DEBUGOUT_ON

#if 1

#define DEBUGOUTL(l,msg) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,l)) DEBUGOUT(msg);}
#define DEBUGOUTL1(l,fmt,a1) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,l)) DEBUGOUT1(fmt,a1);}
#define DEBUGOUTL2(l,fmt,a1,a2) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,l)) DEBUGOUT2(fmt,a1,a2);}
#define DEBUGOUTL3(l,fmt,a1,a2,a3) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,l)) DEBUGOUT3(fmt,a1,a2,a3);}
#define DEBUGOUTL4(l,fmt,a1,a2,a3,a4) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,l)) DEBUGOUT4(fmt,a1,a2,a3,a4);}
#define DEBUGOUTL5(l,fmt,a1,a2,a3,a4,a5) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,l)) DEBUGOUT5(fmt,a1,a2,a3,a4,a5);}
#define DEBUGOUT(msg) \
	akb_debug_out_level(0,__FILE__,__LINE__,"%s",msg,NULL,NULL,NULL,NULL)
#define DEBUGOUT1(fmt,a1) \
	akb_debug_out_level(0,__FILE__,__LINE__,fmt,a1,NULL,NULL,NULL,NULL)
#define DEBUGOUT2(fmt,a1,a2) \
	akb_debug_out_level(0,__FILE__,__LINE__,fmt,a1,a2,NULL,NULL,NULL)
#define DEBUGOUT3(fmt,a1,a2,a3) \
	akb_debug_out_level(0,__FILE__,__LINE__,fmt,a1,a2,a3,NULL,NULL)
#define DEBUGOUT4(fmt,a1,a2,a3,a4) \
	akb_debug_out_level(0,__FILE__,__LINE__,fmt,a1,a2,a3,a4,NULL)
#define DEBUGOUT5(fmt,a1,a2,a3,a4,a5) \
	akb_debug_out_level(0,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)

#define DEBUGENT(msg) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT2("==> %s: %s",__func__,msg));}
#define DEBUGENT1(fmt,a1) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT1(stradd5("==> ",__func__,": ",fmt,NULL),a1);}
#define DEBUGENT2(fmt,a1,a2) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT2(stradd5("==> ",__func__,": ",fmt,NULL),a1,a2);}
#define DEBUGENT3(fmt,a1,a2,a3) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT3(stradd5("==> ",__func__,": ",fmt,NULL),a1,a2,a3);}
#define DEBUGENT4(fmt,a1,a2,a3,a4) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT4(stradd5("==> ",__func__,": ",fmt,NULL),a1,a2,a3,a4);}
#define DEBUGENT5(fmt,a1,a2,a3,a4,a5) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT5(stradd5("==> ",__func__,": ",fmt,NULL),a1,a2,a3,a4,a5);}
#define DEBUGRET(msg) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBENT_LOG_GROUP)) \
		DEBUGOUT2("<== %s: %s",__func__,msg);}
#define DEBUGRET1(fmt,a1) \
	{if (LOGLEVELCHK(D_LOG_NO_DEBUG,AKBRET_LOG_GROUP)) \
		DEBUGOUT1(stradd5("<== ",__func__,": ",fmt,NULL),a1);}

#define CPRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5) \
		akb_prdbg_out_l5(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define PRDBGOUTL(l,msg) CPRDBGOUTL5(l,"%s",msg,NULL,NULL,NULL,NULL)
#define PRDBGOUTL1(l,fmt,a1) CPRDBGOUTL5(l,fmt,a1,NULL,NULL,NULL,NULL)
#define PRDBGOUTL2(l,fmt,a1,a2) CPRDBGOUTL5(l,fmt,a1,a2,NULL,NULL,NULL)
#define PRDBGOUTL3(l,fmt,a1,a2,a3) CPRDBGOUTL5(l,fmt,a1,a2,a3,NULL,NULL)
#define PRDBGOUTL4(l,fmt,a1,a2,a3,a4) CPRDBGOUTL5(l,fmt,a1,a2,a3,a4,NULL)
#define PRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5) CPRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5)

#define CERRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5) \
		akb_errdbg_out_l5(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define ERRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5) CERRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5)

#else /* 1 */

#define DEBUGOUTL(l,msg) \
	akb_debug_out_level(l,__FILE__,__LINE__,"%s",msg,NULL,NULL,NULL,NULL)
#define DEBUGOUTL1(l,fmt,a1) \
	akb_debug_out_level(l,__FILE__,__LINE__,fmt,a1,NULL,NULL,NULL,NULL)
#define DEBUGOUTL2(l,fmt,a1,a2) \
	akb_debug_out_level(l,__FILE__,__LINE__,fmt,a1,a2,NULL,NULL,NULL)
#define DEBUGOUTL3(l,fmt,a1,a2,a3) \
	akb_debug_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,NULL,NULL)
#define DEBUGOUTL4(l,fmt,a1,a2,a3,a4) \
	akb_debug_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,NULL)
#define DEBUGOUTL5(l,fmt,a1,a2,a3,a4,a5) \
	akb_debug_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define DEBUGOUT(msg)  DEBUGOUTL(0,msg)
#define DEBUGOUT1(fmt,a1) DEBUGOUTL1(0,fmt,a1)
#define DEBUGOUT2(fmt,a1,a2) DEBUGOUTL2(0,fmt,a1,a2)
#define DEBUGOUT3(fmt,a1,a2,a3) DEBUGOUTL3(0,fmt,a1,a2,a3)
#define DEBUGOUT4(fmt,a1,a2,a3,a4) DEBUGOUTL4(0,fmt,a1,a2,a3,a4)
#define DEBUGOUT5(fmt,a1,a2,a3,a4,a5) DEBUGOUTL5(0,fmt,a1,a2,a3,a4,a5)

#endif /* 1 */

#else /* DEBUGOUT_ON */

#define DEBUGOUTL(l,msg)
#define DEBUGOUTL1(l,fmt,a1)
#define DEBUGOUTL2(l,fmt,a1,a2)
#define DEBUGOUTL3(l,fmt,a1,a2,a3)
#define DEBUGOUTL4(l,fmt,a1,a2,a3,a4)
#define DEBUGOUTL5(l,fmt,a1,a2,a3,a4,a5)
#define DEBUGOUT(msg)
#define DEBUGOUT1(fmt,a1)
#define DEBUGOUT2(fmt,a1,a2)
#define DEBUGOUT3(fmt,a1,a2,a3)
#define DEBUGOUT4(fmt,a1,a2,a3,a4)
#define DEBUGOUT5(fmt,a1,a2,a3,a4,a5)
#define CPRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5)
#define PRDBGOUTL(l,msg) PRINTOUTL(l,msg)
#define PRDBGOUTL1(l,fmt,a1) PRINTOUTL1(l,fmt,a1)
#define PRDBGOUTL2(l,fmt,a1,a2) PRINTOUTL2(l,fmt,a1,a2)
#define PRDBGOUTL3(l,fmt,a1,a2,a3) PRINTOUTL3(l,fmt,a1,a2,a3)
#define PRDBGOUTL4(l,fmt,a1,a2,a3,a4) PRINTOUTL4(l,fmt,a1,a2,a3,a4)
#define PRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5) PRINTOUTL5(l,fmt,a1,a2,a3,a4,a5)
#define CERRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5)
#define ERRDBGOUTL5(l,fmt,a1,a2,a3,a4,a5) ERROROUTL5(l,fmt,a1,a2,a3,a4,a5)
#define DEBUGENT(fmt)
#define DEBUGENT1(fmt,a1)
#define DEBUGENT2(fmt,a1,a2)
#define DEBUGENT3(fmt,a1,a2,a3)
#define DEBUGENT4(fmt,a1,a2,a3,a4)
#define DEBUGENT5(fmt,a1,a2,a3,a4,a5)
#define DEBUGRET(fmt)
#define DEBUGRET1(fmt,a1)

#endif /* DEBUGOUT_ON */

#define PRINTOUTL(l,msg) \
	akb_print_out_level(l,__FILE__,__LINE__,"%s",msg,NULL,NULL,NULL,NULL)
#define PRINTOUTL1(l,fmt,a1) \
	akb_print_out_level(l,__FILE__,__LINE__,fmt,a1,NULL,NULL,NULL,NULL)
#define PRINTOUTL2(l,fmt,a1,a2) \
	akb_print_out_level(l,__FILE__,__LINE__,fmt,a1,a2,NULL,NULL,NULL)
#define PRINTOUTL3(l,fmt,a1,a2,a3) \
	akb_print_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,NULL,NULL)
#define PRINTOUTL4(l,fmt,a1,a2,a3,a4) \
	akb_print_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,NULL)
#define PRINTOUTL5(l,fmt,a1,a2,a3,a4,a5) \
	akb_print_out_level(l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)

#define FPRINTOUTL(l,fp,msg) \
	akb_fprint_out_level(l,__FILE__,__LINE__,fp,"%s",msg,NULL,NULL,NULL,NULL)

#define PRINTOUT(msg)  PRINTOUTL(0,msg)
#define PRINTOUT1(fmt,a1) PRINTOUTL1(0,fmt,a1)
#define PRINTOUT2(fmt,a1,a2) PRINTOUTL2(0,fmt,a1,a2)
#define PRINTOUT3(fmt,a1,a2,a3) PRINTOUTL3(0,fmt,a1,a2,a3)
#define PRINTOUT4(fmt,a1,a2,a3,a4) PRINTOUTL4(0,fmt,a1,a2,a3,a4)
#define PRINTOUT5(fmt,a1,a2,a3,a4,a5) PRINTOUTL5(0,fmt,a1,a2,a3,a4,a5)

#define LOGOUT(m) akb_log_out(m)
#define LOGBUF(l) akb_log_buf(l)
#define LOGBUFLEN(l) akb_log_buf_len(l)
#define LOGFLG(i,f) akb_log_flg(i,f)
#define LOGLEVEL(i,level) akb_log_level(i,level)
#define LOGLEVELCHK(i,level) (akb_log_level_check(i,level)>0)
#define LOGOUTCHECK(i,level) (akb_log_out_check(i,level,__FILE__,__LINE__)>0)
#define ERROROUTCHECK(level) LOGOUTCHECK(D_LOG_NO_ERROR,level)
#define PRINTOUTCHECK(level) LOGOUTCHECK(D_LOG_NO_PRINT,level)
#define DEBUGOUTCHECK(level) LOGOUTCHECK(D_LOG_NO_DEBUG,level)

#define TRACEOUTF(i,pack,flg,msg) \
	akb_trace_log_out(i,pack,flg,__FILE__,__LINE__,"%s",msg,NULL,NULL,NULL,NULL)
#define TRACEOUTF1(i,pack,flg,fmt,a1) \
	akb_trace_log_out(i,pack,flg,__FILE__,__LINE__,fmt,a1,NULL,NULL,NULL,NULL)
#define TRACEOUTF2(i,pack,flg,fmt,a1,a2) \
	akb_trace_log_out(i,pack,flg,__FILE__,__LINE__,fmt,a1,a2,NULL,NULL,NULL)
#define TRACEOUTF3(i,pack,flg,fmt,a1,a2,a3) \
	akb_trace_log_out(i,pack,flg,__FILE__,__LINE__,fmt,a1,a2,a3,NULL,NULL)
#define TRACEOUTF4(i,pack,flg,fmt,a1,a2,a3,a4) \
	akb_trace_log_out(i,pack,flg,__FILE__,__LINE__,fmt,a1,a2,a3,a4,NULL)
#define TRACEOUTF5(i,pack,flg,fmt,a1,a2,a3,a4,a5) \
	akb_trace_log_out(i,pack,flg,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)

#define TRACEOUTCH(i,pack,ch,msg) TRACEOUTF2(i,pack,2,"iCh=%d [%s]",ch,msg) 

/* �����n�̕����R�[�h��� */
#if 1	/* 2000.12.1 Koba */
#ifdef NO_PFMCDTYPE
#define AKBGETCDTYPE(x) 0
#define AKBPFMCDTYPE(x) 0
#else
#define AKBGETCDTYPE(x) ((x & AKB_PFM_CDTYPE)>>1)
#define AKBPFMCDTYPE(x) ((x<<1) & AKB_PFM_CDTYPE)
#endif
#else
#define AKBGETCDTYPE(x) 0
#define AKBPFMCDTYPE(x) 0
#endif

#define AKBGETHSIZEETC(pHead,ver,iHSize,lLen) \
{\
	ver = pHead->cph_prt.prt_ver;\
	lLen = ntohl(pHead->cph_plen);\
	iHSize = sizeof(tdtCommPackHead);\
}

#define AKBGETHSIZE(pHead,iHSize) \
{\
	iHSize = sizeof(tdtCommPackHead);\
}

#ifdef NO_QUE_PA
#define AKBWQGETPQ(WriteQue,iQTbl)	(&((qRWQue *)WriteQue)[iQTbl])
#else
#define AKBWQGETPQ(WriteQue,iQTbl)	(WriteQue[iQTbl])
#endif

#endif	/* _AKBMACRO_H */
