/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akaconst.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.29						*/
/*																		*/
/************************************************************************/
#ifndef _AKACONST_H
#define _AKACONST_H

/*** aka_register_class Option ***/
#define AKA_RCO_NOREPLY		0x01
#define AKA_RCO_NOWAITSHUT	0x02
#define AKA_RCO_RECVPROC	0x04
#define AKA_RCO_NODISPLAY	0x08
#define AKA_RCO_SYS_CLASS	0x10
#define AKA_RCO_NODROPCERR	0x20

/*** akbOption ***/
#define AKA_AKO_NOREPLY		AKB_AKO_NOREPLY			/* 0x01 */
#define AKA_AKO_CHANNEL		AKB_AKO_CHANNEL			/* 0x08 */

/*** Packet Form ***/
#define AKA_PFM_INDIRECT	AKB_PFM_INDIRECT
#define AKA_PFM_PRIORITY	AKB_PFM_PRIORITY
#define AKA_PFM_NEED_REPLY	AKB_PFM_NEED_REPLY

/*** Disposition ***/
#define AKA_REGIST_CLASS	256

/*** Shut Control **/
#define AKA_SHUT_GET        0
#define AKA_SHUT_MODE       1
#define AKA_SHUT_SUSPEND    2

#define AKA_SHUT_MODE_SHUT	0x01
#define AKA_SHUT_MODE_FSHUT	0x02

#define AKA_SHUT_SUSPEND_SET	0x01

/*** Timer ***/
/* int_max = 2,147,483,648 */
/* over flow days = int_max /(3600*24*AKA_TIMER_CLOCK) */
/* 1/  10 : 2485.51 days */
/* 1/  20 : 1242.76 */
/* 1/  50 :  497.10 */
/* 1/ 100 :  248.55 */
/* 1/1000 :   24.86 */
#define AKA_TIMER_CLOCK		50	/* 1/50 sec */

/*** MsgOption ***/
#define AKA_MSO_EXEC_NOFREE		0x80

/*** Log ***/
#define AKA_LOG_GROUP       0x10000000

/* Init Status */
#define AKA_IST_CONNECTED	0x01
#define AKA_IST_REGISTED	0x02
#define AKA_IST_INITIALIZED	0x04
#define AKA_IST_STANDALONE	0x80

#endif	/* _AKACONST_H */
