static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testecnv.c libakx_no_u8src.a -o testecnv
*/
#include "akxcommon.h"
main()
{
	tdtStplSql *pNS;
	char expbuf[256];
	int ret,num;

	pNS = NULL;
	ret = akxcecvn(&pNS,NULL,0,NULL);
	printf("ret=%d pNS=%08x\n",ret,pNS);
	for (;;) {
		printf("Enter exp ==>");
		gets(expbuf);
		if (!stricmp(expbuf,"/EOF")) break;
		ret = akxcecvn(&pNS,expbuf,strlen(expbuf),&num);
		printf("ret=%d num=%d %08x\n",ret,num,num);
	}
	akxs_stpl_sql_free(pNS);
}
