static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testgwns.c libakx_no_u8src.a -o testgwns
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256],sep[256];
	int n,max,attr=0,opt;
	SSP_S ssp;

	printf("Enter MAXCHECK==>");
	gets(buf);
	max=atoi(buf);
	printf("Enter sep==>");
	gets(sep);
	printf("Enter opt==>");
	gets(buf);
	n=akxcgcvn(buf,strlen(buf),&opt);
	printf("ret=%d opt=%08x\n",n,opt);
	if (n) exit(0);
	for (;;) {
		printf("Enter==>");
		gets(buf);
		ssp.sp = 0;
		ssp.wd = wd;
		while((n=akxtgwns(buf, max, &ssp, sep, opt))>0) {
			printf("pos=%d n=%d wd=[%s] attr=%08x\n",ssp.sp,n,wd,*(int *)ssp.attr);
		}
		printf("n=%d\n",n);
	/*	if (n<0) break;	*/
	}
}
