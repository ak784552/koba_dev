static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testgetline.c akxcom.a -o testgetline
*/
#include <stdio.h>
#include <stdio.h>
int main()
{
	char buf[256];
	int n,max,opt;
	FILE *fp;

	printf("Enter LINEMAX(<=256)==>");
	gets(buf);
	max=atoi(buf);
	if (max > 256) exit(1);
	printf("Enter opt==>");
	gets(buf);
	n=akxcgcvn(buf,strlen(buf),&opt);
	printf("ret=%d opt=%08x\n",n,opt);
	printf("Enter file:file name/stdin:- ==>");
	gets(buf);
	if (*buf != '-') {
		fp = fopen(buf,"r");
		if (fp) {
			while ((n=akxa_get_line(buf,max,fp,opt))>=0) {
				printf("n=%d\n",n);
				akxaxdump("",buf,n+1);
			}
			printf("n=%d\n",n);
			fclose(fp);
		}
	}
	else {
		fp = stdin;
		printf("Enter ==>");
		while ((n=akxa_get_line(buf,max,fp,opt))>=0) {
			printf("n=%d\n",n);
			akxaxdump("",buf,n+1);
		}
		printf("n=%d\n",n);
	}
}
