static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************/
/*												*/
/*	akxgmath.c									*/
/*												*/
/*		  coded by A.Kobayashi 2010.05.27		*/
/*												*/
/************************************************/
/* -185080101 �` -185089999 */
#include <math.h>
#include "akxcommon.h"

#define XDEBUG(x)
#define B_SRCH_SOSU_THRESHOLD_INX	22
#define B_SRCH_SOSU_MPA_THRESHOLD_INX	5

/* 01 */
long akxglsqrt(b)
long b;
{
	long x0,d,y;

	x0=b;
	if (x0 > 0) {
		x0=x0/2;
		if (x0 > 1) {
			while (d=((y=x0*x0)-b)/(2*x0)) {
				x0-=d;
			}
			if (y>b) x0--;
		}
		else x0=1;
	}
	return x0;
}

#define _DIFF(a,b) (a>b?a-b:b-a)
#define _ABS(a) (a>=0?a:-a)

/* 02 */
/************************************************/
/*	opt = 0 : 									*/
/*	�ԋp : opt=0								*/
/*			> 0 : ��v����Index+1				*/
/*			= 0 : ��v�Ȃ�						*/
/*			=-2 : �͈͊O						*/
/*		   opt<>0								*/
/*			> 0 : ��v����Index+1				*/
/*				  or l���傫���ŏ���Index+1	*/
/*			=-2 : �͈͊O						*/
/************************************************/
static int _b_search(sosu,max_size,l,opt)
long  *sosu,l;
int max_size,opt;
{
	int max,i,i1,i2,ret;
	long ll,m,m1;

	max = max_size;
	ll = l;
	if (!sosu) return -185080201;
	else if (ll == (m1=sosu[0])) return 1;
	else if (ll == (m=sosu[max-1])) return max;
	else if (ll>m1 && ll<m) {
		ret = 0;
		if (ll > sosu[B_SRCH_SOSU_THRESHOLD_INX-1]) {
			i1=0;
			i2=max-1;
			while (i2-i1>1) {
				i = (i1+i2)/2;
				m = sosu[i];

XDEBUG(XDEBUGOUTL5(0,"_b_search: ll=%d i1=%d i2=%d i=%d m=%d",ll,i1,i2,i,m);)

				if (ll == m) {
					ret = i + 1;
					break;
				}
				else if (ll < m) i2 = i;
				else i1 = i;
			}
			if (!ret && opt) ret = i2;
		}
		else {
			for (i=0;i<max_size;i++) {
				m = sosu[i];
				if (m == ll) {
					ret = i + 1;
					break;
				}
				else if (m > ll) break;
			}
			if (!ret && opt) ret = i + 1;
		}
		return ret;
	}
	return -2;
}

/* 03 */
static int _h_search(sosu,max_size,l)
long *sosu,l;
int max_size;
{
	int max,i,i1,i2,d;
	long ll,m,m1,m2,dy,dy1,dx1,dx1dy,dy2;

	max = max_size;
	ll = l;
	if (!sosu) return -185080301;
	else if (ll==(m1=sosu[0]) || ll==(m2=sosu[max-1])) return 1;
	else if (ll>m1 && ll<m2) {
		i1=0;
		i2=max-1;

XDEBUG(XDEBUGOUTL5(0,"_h_search: ll=%d",ll,0,0,0,0);)

		for (;;) {
			dx1 = i2 - i1;
			dy  = ll - m2;

XDEBUG(XDEBUGOUTL5(0,"    dx1=%d dy=%d",dx1,dy,0,0,0);)

			if ((_ABS(dx1)<=1) && (dy*(ll-m1))<=0) break;
			dy1 = m2 - m1;
			dx1dy = dx1 * dy;
			if (!(d=dx1dy/dy1)) {
				if (dx1dy*dy1>=0) d = 1;
				else d = - 1;
			}
			i = d + i2;
			m = sosu[i];

XDEBUG(XDEBUGOUTL5(0,"    dx1dy=%d dy1=%d d=%d P1(%d,%d)",dx1dy,dy1,d,i1,m1);)
XDEBUG(XDEBUGOUTL5(0,"            P2(%d,%d) P(%d,%d)",i2,m2,i,m,0);)

			if (ll == m) return 1;
			dy2 = m2 - m;
			if (((dy1>0) && (dy2>(-dy))) ||
			    ((dy1<0) && ((-dy2)>dy))) {
				m1 = m2;
				i1 = i2;
			}
			m2 = m;
			i2 = i;
		}
		return 0;
	}
	return -2;
}

/* 04 */
int akxgisqrt(b)
int b;
{
	return akxglsqrt((long)b);
}

/* 05 */
/************************************************/
/*	opt = 0 : 									*/
/*	�ԋp : opt=0								*/
/*			> 0 : ��v����Index+1				*/
/*			= 0 : ��v�Ȃ�						*/
/*			=-2 : �͈͊O						*/
/*		   opt<>0								*/
/*			> 0 : ��v����Index+1				*/
/*				  or l���傫���ŏ���Index+1	*/
/*			=-2 : �͈͊O						*/
/************************************************/
static int _b_search_mpa(sosu,max_size,l,opt)
MPA *sosu,*l;
int max_size,opt;
{
	int max,i,i1,i2,ret1,ret2;
	MPA *ll,*m;
	char buf[128];
/*
m_mpa2an(l,buf,sizeof(buf),0);
printf("_b_search_mpa:Enter opt=%d max_size=%d l=[%s]\n",opt,max_size,buf);
*/
	max = max_size;
	ll = l;
	if (!sosu) return -185080501;
	else if (!(ret1=m_cmp_a(ll,(sosu)))) return 1;
	else if (!(ret2=m_cmp_a(ll,(m=sosu+max-1)))) return max;
	else if (ret1>0 && ret2<0) {
		ret1 = 0;
		if (m_cmp_a(ll,sosu+B_SRCH_SOSU_MPA_THRESHOLD_INX-1) > 0) {
			i1=0;
			i2=max-1;
			while (i2-i1>1) {
				i = (i1+i2)/2;
				m = sosu+i;
/*
m_mpa2an(m,buf,sizeof(buf),0);
printf("_b_search_mpa: i1=%d i2=%d i=%d m=%s\n",i1,i2,i,buf);
*/
				if (!(ret2=m_cmp_a(ll, m))) {
					ret1 = i + 1;
					break;
				}
				else if (ret2 < 0) i2 = i;
				else i1 = i;
			}
/*
m_mpa2an(m,buf,sizeof(buf),0);
printf("_b_search_mpa: i1=%d i2=%d i=%d m=%s\n",i1,i2,i,buf);
*/
			if (!ret1 && opt) {
				ret1 = i2 + 1;
			}
		}
		else {
			for (i=0;i<max_size;i++) {
				m = sosu + i;
				if (!(ret2=m_cmp_a(ll, m))) {
					ret1 = i + 1;
					break;
				}
				else if (ret2 < 0) break;
			}
			if (!ret1 && opt) ret1 = i + 1;
		}
		return ret1;
	}
	return -2;
}

static int  gSosuTblSize=0;
static long *gSosuTbl=NULL;

/* 11 */
int akxg_sosu_chk_by_tbl_opt(sosu,max_size,l,opt)
long *sosu,l;
int max_size,opt;
{
	int i,max;
	long ll,l1,l2,*ip,m;

	ll = l;
	if (!(ll & 0x01)) return 0;
	else if (!(ip=sosu)) return -185081101;

	if (ll < 2) return 0;
/*	else if (ll == 2) return 1;	*/
	else if (ll <= 7) {
	/*	if (ll&0x01) */return 1;
	/*	return 0;	*/
	}

	/* search sosu table */
	max = max_size;
	if (ll==sosu[0] || ll==(m=sosu[max-1])) return 1;
	else if (ll < m) {
		if (opt) {
			if ((i=_h_search(sosu,max,ll)) >= 0) return i;
		}
		else {
			if ((i=_b_search(sosu,max,ll,0)) >= 0) return i;
		}
	}

	l2 = akxgisqrt(ll);
	for (i=0;i<max;i++,ip++) {
		if (!(ll % (m=*ip))) break;
		if (m > l2) break;
	}
	if (i>=max || m>l2) return 1;
	return 0;
}

/* 12 */
int akxg_sosu_chk_by_tbl(sosu,max_size,l)
int  *sosu,max_size;
int l;
{
	return akxg_sosu_chk_by_tbl_opt(sosu,max_size,l,0);
}

#define MAX_SOSU	32
static int cur_index = 0;
static int max_sosu = 0;
static int alc_sosu = 0;
static long *sosu = NULL;
static int cur_index_mpa = 0;
static int max_sosu_mpa = 0;
static int alc_sosu_mpa = 0;
static MPA *sosu_mpa = NULL;

/* 13 */
int akxg_sosu_tbl(pi)
long **pi;
{
	static long sosu[MAX_SOSU]={
	  2,  3,  5,  7, 11, 13, 17, 19, 23, 29,
	 31, 37, 41, 43, 47, 53, 59, 61, 67, 71,
	 73, 79, 83, 89, 97,101,103,107,109,113,
	127,131};
	long *piw;
	int size;

	if (!pi) return -185081301;
	if (gSosuTbl) {
		size = gSosuTblSize;
		piw = gSosuTbl;
	}
	else {
		size = MAX_SOSU;
		piw = sosu;
	}
	*pi = piw;
	return size;
}

/* 14 */
int akxg_sosu_chk(l)
int l;
{
	int  max_size,*sosu,i;

	max_size = akxg_sosu_tbl(&sosu);
/*
printf("akxg_sosu_chk: sosu=%08x max_size=%d\n",sosu,max_size);
*/
	if ((i=akxg_sosu_chk_by_tbl(sosu,max_size,l)) < 0) i = 0;
	return i;
}

/* 15 */
/************************************************/
/*	ii = 0 : cur_index = 0 �Ƃ���				*/
/*	ii > 0 : i�Ԗڂ̗v�f�̎��̑f����Ԃ�		*/
/*	ii < 0 : cur_index+1�̗v�f�̑f����Ԃ�		*/
/************************************************/
long akxg_sosu_next(ii)
int ii;
{
	int i,k;
	long ret,*pl,m,m_b;
/*
printf("akxg_sosu_next:Enter max_sosu=%d sosu=%08x ii=%d cur_index=%d\n",max_sosu,sosu,ii,cur_index);
*/
	ret = 0;
	if (!sosu) {
		max_sosu = akxg_sosu_tbl(&sosu);
		if (!(pl=(long *)Malloc(max_sosu*sizeof(long)))) return -185081501;
		memcpy(pl,sosu,max_sosu*sizeof(long));
		sosu = pl;
		alc_sosu = max_sosu;
	}
	if (ii) {
		if (ii < 0) {
			cur_index++;
			ii = cur_index;
		}
		if (ii <= max_sosu) {
			ret = sosu[ii-1];
			cur_index = ii;
		}
		else {
			m = sosu[max_sosu-1];
/*
printf("akxg_sosu_next: max_sosu=%d m=%d\n",max_sosu,m);
*/
			for (k=0;k<100;k++) {
				m_b = m;
				m += 2;
				if (m <= m_b) return MPA_ERR_OVERFLOW_I;
				if ((i=akxg_sosu_chk_by_tbl(sosu,max_sosu,m)) < 0) return -185081503;
				else if (i > 0) {
					if (max_sosu+1 > alc_sosu) {
						alc_sosu += 20;
						if (!(pl=(long *)Realloc(sosu,alc_sosu*sizeof(long)))) return -185081504;
						sosu = pl;
					}
					sosu[max_sosu++] = m;
					ret = m;
					break;
				}
			}
		}
	}
	else cur_index = 0;
	return ret;
}

/* 16 */
int akxg_sosu_next_tbl(pi)
long **pi;
{
	int ret;
/*
printf("akxg_sosu_next_tbl: sosu=%08x max_sosu=%d\n",sosu,max_sosu);
*/
	ret = 0;
	if (!sosu) {
		ret = akxg_sosu_next(0);
	}
	if (!ret) {
		ret = max_sosu;
		if (pi) *pi = sosu;
	}
	return ret;
}

/* 17 */
int akxg_sosu_over_by_tbl(sosu,max_size,m)
long *sosu,m;
int max_size;
{
	int i,ret;
/*
m_mpa2an(m,buf,sizeof(buf),0);
printf("akxg_sosu_over_mpa_by_tbl:Enter m=[%s]\n",buf);
*/
	ret = 0;
	if (m <= sosu[max_size-1]) {
		ret = 1;
		if (m <= sosu[B_SRCH_SOSU_THRESHOLD_INX-1]) {
			for (i=0;i<max_size;i++) {
				if (sosu[i] >= m) {
					ret = i + 1;
					break;
				}
			}
		}
		else {
			ret = _b_search(sosu,max_size,m,1);
		}
	}
	return ret;
}
/* 21 */
int akxg_sosu_chk_mpa_by_tbl(sosu_mpa,max_size_mpa,l)
MPA *sosu_mpa,*l;
int max_size_mpa;
{
	static MPA *sl2=NULL,*smm=NULL;
	int i,max;
	MPA *ll,*l1,*l2,*mm,*ip,*m,l2z,mmz;
	double dval;
	char buf[128];

	ll = l;
/*
m_mpa2an(ll,buf,sizeof(buf),0);
printf("akxg_sosu_chk_mpa_by_tbl:Enter max_size_mpa=%d ll=[%s]\n",max_size_mpa,buf);
*/
	l1 = m_get_i(2);
	mm = get_tmpMPA(&smm,&mmz);
	m_mod(mm,ll,l1);
	if (mm->zero) return 0;
	else if (!(ip=sosu_mpa)) return -185082101;

	l2 = get_tmpMPA(&sl2,&l2z);
	if ((i=m_cmp_a(ll,l1)) < 0) return 0;
	else if (!i) return 1;
	else if (m_cmp_a(ll,m_get_i(7)) <= 0) {
	/*	m_mod(mm,ll,l1);
		if (!mm->zero) */return 1;
	/*	return 0;	*/
	}

	/* search sosu table */
	max = max_size_mpa;
	m = sosu_mpa + max - 1;
/*
m_mpa2an(m,buf,sizeof(buf),0);
printf("akxg_sosu_chk_mpa_by_tbl: max=%d m=[%s]\n",max,buf);
*/
	if (!m_cmp_a(ll,sosu_mpa) || !m_cmp_a(ll,m)) return 1;
	else if (m_cmp_a(ll,m) <= 0) {
		if ((i=_b_search_mpa(sosu_mpa,max,ll,0)) > 0) return i;
	}

	m_mpa2d(ll,&dval);
	dval = sqrt(dval);
/*
printf("akxg_sosu_chk_mpa_by_tbl: dval=%f\n",dval);
*/
	m_d2mpa(dval,l2);
	for (i=0;i<max;i++,ip++) {
		m_mod(mm,ll,(m=ip));
		if (mm->zero) break;
		if (m_cmp_a(m,l2) > 0) break;
	}
	if (i>=max || m_cmp_a(m,l2)>0) return 1;
	return 0;
}

/* 22 */
int akxg_sosu_next_mpa_tbl(pi)
MPA **pi;
{
	int ret;
/*
printf("akxg_sosu_next_tbl: sosu=%08x max_sosu=%d\n",sosu,max_sosu);
*/
	ret = 0;
	if (!sosu_mpa) {
		ret = akxg_sosu_next_mpa(0,NULL);
	}
	if (!ret) {
		ret = max_sosu_mpa;
		if (pi) *pi = sosu_mpa;
	}
	return ret;
}

/* 23 */
/************************************************/
/*	ii = 0 : cur_index = 0 �Ƃ���				*/
/*	ii > 0 : i�Ԗڂ̗v�f�̎��̑f����Ԃ�		*/
/*	ii < 0 : cur_index+1�̗v�f�̑f����Ԃ�		*/
/************************************************/
int akxg_sosu_next_mpa(ii,ms)
int ii;
MPA *ms;
{
	static MPA *sm=NULL,*sm_b=NULL;
	int ret,i,k;
	long *pl;
	MPA *mpl,*m,*m_b,mz,m_bz;
	char buf[128];
/*
printf("akxg_sosu_next:Enter max_sosu=%d sosu=%08x ii=%d cur_index=%d\n",max_sosu,sosu,ii,cur_index);
*/
	ret = 0;
	if (!sosu_mpa) {
		max_sosu = akxg_sosu_tbl(&sosu);
		if (!(pl=(long *)Malloc(max_sosu*sizeof(long)))) return -185082301;
		memcpy(pl,sosu,max_sosu*sizeof(long));
		sosu = pl;
		alc_sosu = max_sosu;
		if (!(mpl=(MPA *)Malloc(max_sosu*sizeofMPA()))) return -185082302;
		sosu_mpa = mpl;
		max_sosu_mpa = max_sosu;
/*
printf("akxg_sosu_next: max_sosu_mpa=%d\n",max_sosu_mpa);
*/
		alc_sosu_mpa = max_sosu;
		for (i=0;i<max_sosu;i++) {
			m_l2mpa(sosu[i],sosu_mpa+i);
		}
	}
	if (ii) {
		if (ii < 0) {
			cur_index++;
			ii = cur_index;
		}
		if (ii <= max_sosu_mpa) {
			m_cpy(ms,sosu_mpa+ii-1,0);
			cur_index = ii;
			ret = 1;
		}
		else {
			m = get_tmpMPA(&sm,&mz);
			m_b = get_tmpMPA(&sm_b,&m_bz);
			m_cpy(m,sosu_mpa+max_sosu_mpa-1,0);
/*
m_mpa2an(m,buf,sizeof(buf),0);
printf("akxg_sosu_next: max_sosu_mpa=%d m=[%s]\n",max_sosu_mpa,buf);
*/
			for (k=0;k<100;k++) {
				m_cpy(m_b,m,0);
				m_add1(m,m_get_i(2));
			/*	if (m <= m_b) return MPA_ERR_OVERFLOW_I;	*/
				if ((i=akxg_sosu_chk_mpa_by_tbl(sosu_mpa,max_sosu_mpa,m)) < 0) return -185082303;
				else if (i > 0) {
					if (max_sosu_mpa+1 > alc_sosu_mpa) {
						alc_sosu_mpa += 20;
						if (!(mpl=(MPA *)Realloc(sosu_mpa,alc_sosu_mpa*sizeofMPA()))) return -185082304;
						sosu_mpa = mpl;
					}
					m_cpy(sosu_mpa+max_sosu_mpa++,m,0);
					if (ms) m_cpy(ms,m,0);
					ret = 1;
					break;
				}
			}
		}
	}
	else cur_index = 0;
	return ret;
}

/* 24 */
int akxg_sosu_over_mpa_by_tbl(mo,sosu_mpa,max_size_mpa,m)
MPA *sosu_mpa,*m,*mo;
int max_size_mpa;
{
	MPA *mp;
	int i,ret;
	char buf[128];
/*
m_mpa2an(m,buf,sizeof(buf),0);
printf("akxg_sosu_over_mpa_by_tbl:Enter m=[%s]\n",buf);
*/
	ret = 0;
	m_cpy(mo,m,0);
	if (m_cmp_a(m,sosu_mpa+max_size_mpa-1) <= 0) {
		ret = 1;
		if (m_cmp(m,sosu_mpa+B_SRCH_SOSU_MPA_THRESHOLD_INX-1) <= 0) {
			mp = sosu_mpa;
			for (i=0;i<max_size_mpa;i++,mp++) {
				if (m_cmp_a(mp,m) >= 0) {
					m_cpy(mo,mp,0);
					break;
				}
			}
		}
		else {
			ret = _b_search_mpa(sosu_mpa,max_size_mpa,m,1);
			if (ret > 0) m_cpy(mo,sosu_mpa+ret,0);
		}
	}
	return ret;
}
