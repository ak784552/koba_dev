static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_sosu_next.c libakx_no_iconv.a -o test_sosu_next
*/
#include "akxcommon.h"
main()
{
	char *p;
	int i,m;

	for (i=0;i<100;i++) {
		m = akxg_sosu_next(-1);
		if (m<0) break;
		printf("i=%d m=%d\n",i,m);
	}
}
