static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include test_code_conv.c libakx.a -o test_code_conv
*/
#include "akxcommon.h"

main()
{
	char inbuf[100]="AZaz09�`�a�b�������@��";	/* input buffer */
	char outbuf[80];			/* output buffer  */
	char outbuf2[80];			/* output buffer  */
	int  outleft;				/* number of bytes left in outbuf */

	outleft = sizeof(outbuf);
/*
	sub_code_conv(CD_TYPE_SJIS,CD_TYPE_EUC,inbuf,outbuf,outleft);
	sub_code_conv(CD_TYPE_EUC,CD_TYPE_SJIS,outbuf,outbuf2,outleft);
*/
/*
	sub_code_conv(CD_TYPE_SJIS,CD_TYPE_UTF8,inbuf,outbuf,outleft);
	sub_code_conv(CD_TYPE_UTF8,CD_TYPE_SJIS,outbuf,outbuf2,outleft);
*/
/*
	sub_code_conv(CD_TYPE_SJIS,CD_TYPE_EUC,inbuf,outbuf,outleft);
	sub_code_conv(CD_TYPE_EUC,CD_TYPE_UTF8,outbuf,outbuf2,outleft);
	sub_code_conv(CD_TYPE_UTF8,CD_TYPE_EUC,outbuf2,outbuf,outleft);
	sub_code_conv(CD_TYPE_EUC,CD_TYPE_SJIS,outbuf,outbuf2,outleft);
*/
	sub_code_conv(CD_TYPE_SJIS,CD_TYPE_JIS,inbuf,outbuf,outleft);
	sub_code_conv(CD_TYPE_JIS,CD_TYPE_EUC,outbuf,outbuf2,outleft);
	sub_code_conv(CD_TYPE_EUC,CD_TYPE_JIS,outbuf2,outbuf,outleft);
	sub_code_conv(CD_TYPE_JIS,CD_TYPE_SJIS,outbuf,outbuf2,outleft);
}

int sub_code_conv(int type_s,int type_d,char *inbuf,char *outbuf,int outleft)
{
	char *inptr; 				/* Pointer used for input buffer  */
	char *outptr;				/* Pointer used for output buffer */
	tdtCodeConv ct;				/* conversion descriptor		  */
	int  inleft;				/* number of bytes left in inbuf  */
	int rc,outlen;					/* return code of iconv()		 */

	if ((rc = akxc_code_conv_init(&ct,type_d,type_s)) < 0) {
		fprintf(stderr,"Cannot open converter from %d to %d\n",type_s,type_d);
		return -2;;
	}

	outlen = outleft;
	inleft = strlen(inbuf);
	inptr = inbuf;
	outptr = outbuf;
	akxaxdump(akxc_get_code_str(type_s),inbuf,inleft);

	rc = akxc_code_conv(&ct, &inptr, &inleft, &outptr, &outleft);
	if (rc == -1) {
		fprintf(stderr, "Error in converting characters. errno=%d\n",errno);
	}
	printf("rc=%d inleft=%d outleft=%d\n",rc,inleft,outleft);
	outlen -= outleft;
	outbuf[outlen]='\0';
	printf("%s\n",outbuf);
	akxaxdump(akxc_get_code_str(type_d),outbuf,outlen);
	return rc;
}
