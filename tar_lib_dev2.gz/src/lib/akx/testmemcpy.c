/*
	cc -S testmemcpy.c
*/
#include <stdio.h>
#include <stdio.h>
typedef struct {
	char a;
	char b;
	char c;
	char d;
} C4;

void sub(s,d)
char *s,*d;
{
	C4 ss,dd;
	int n;
/*
	d[0]=s[0];
	d[1]=s[1];
	d[2]=s[2];
	d[3]=s[3];

	memcpy(d,s,1);

	memcpy(d,s,2);

	memcpy(d,s,3);
*/
	memcpy(d,s,6);
/*
	n=4;
	memcpy(d,s,n);
	dd = ss;
*/
}

main()
{
	char s[10],d[10];

	sub(s,d);
}
