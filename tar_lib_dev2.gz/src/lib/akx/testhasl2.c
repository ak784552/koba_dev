static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testhasl2.c libakx.a -o testhasl2
*/
#include "akxcommon.h"

main()
{
	int n,i,ret,opt,*en,*fn;
	long key[2],*pk;
	char cmd[20],buf[128],c,*hkey[2];
	HASHB *ha;
	tdtHaslCell4 *cell,*ce;
	int max,pre;

	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl2_new2(8,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)hkey;
	hkey[0] = (char *)key;
	en = ha->ha_next;
	fn = en + max;
	cell = (tdtHaslCell4 *)ha->ha_reg;
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			ce = cell;
			printf(" i   en   fn flag  hkey0  hkey1 next   data\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %4d %4d %4d %6d %6d %4d %6d\n",
				       i,en[i],fn[i],ce->hc_flag,ce->hc_akey[0],ce->hc_akey[1],
				       ce->hc_next,ce->hc_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key0 ==>");
			gets(buf);
			key[0] = atoi(buf);
			printf("Enter key1 ==>");
			gets(buf);
			key[1] = atoi(buf);
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (ret=akxcgcvn (buf,strlen(buf),&n)) break;
				hkey[1] = (char *)n;
				ret = akxshasl2s(ha,key);
			}
			else if (c == 'r') {
				ret = akxshasl2r(ha,key);
				if (ret>0) printf("data=%d\n",hkey[1]);
			}
			else ret = akxshasl2d(ha,key);
			printf("ret=%d\n",ret);
			break;
		case 'k':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshasl2k(ha,key);
				if (ret > 0) printf("i=%d ret=%d key=%d %d data=%d\n",
				                    i,ret,key[0],key[1],hkey[1]);
			}
			break;
		case 'p':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshasl2p(ha);
				if (ret > 0) {
					pk = (long *)hkey[0];
					printf("i=%d ret=%d key=%d %d data=%d\n",
					       i,ret,pk[0],pk[1],hkey[1]);
				}
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
