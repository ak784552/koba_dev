static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#include <stdio.h>
#include <stdio.h>
typedef void * sql_context;

main()
{
	sql_context Ctx1,Ctx2;
	void *data;
	
	Ctx1 = (sql_context)1000;
	data = (void *)&Ctx1;
	Ctx2 = *(sql_context *)data;
	printf("Ctx1=%d Ctx2=%d\n",Ctx1,Ctx2);
}
