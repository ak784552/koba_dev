static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testmemchr.c akxcom.a -o testmemchr
*/
#include "akxcommon.h"
main()
{
	char s1[256],s2[256];
	int len,ret;

	printf("Enter opt(0/1) ==>");
	gets(s1);
	opt = atoi(s1);
	for (;;) {
		printf("Enter s1 ==>");
		gets(s1);
		printf("Enter s1(chr) ==>");
		gets(s2);
	/*
		strcpy(s1,"�i");
		strcpy(s2,"�I");
	*/
		printf("akx_mem_chr_opt: ret=%d\n",akx_mem_chr_opt(s1,s2,strlen(s1),opt));
	}
}
