static char sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testskipopt.c libakx.a -o testskipopt
*/
#include "akxcommon.h"

main()
{
	char buf[256],pat[256];
	int opt,ret,pos[4];

	printf("Enter option ==>");
	gets(buf);
	opt = atoi(buf);
	printf("Enter text ==>");
	gets(buf);
	for (;;) {
		printf("Enter pattern ==>");
		gets(pat);
		ret = akx_skip_opt(buf,strlen(buf),pat,opt);
		printf("ret=%d\n",ret);
	}
}
