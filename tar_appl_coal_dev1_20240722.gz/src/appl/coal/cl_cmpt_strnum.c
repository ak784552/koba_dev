static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/********1*********2*********3*********4*********5*********6*********7***
*																		*
*	���W���[�����F strnum���Z����										*
*																		*
*	�쐬 : 2017/07/01 Akito Kobayashi									*
*	�X�V : 																*
*************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];

static tdtCharAdd charnum[]={
	 {"�Z���O�l�ܘZ������",0,0,0,10,0}
	,{0,"0","9",0,10,0}
	,{0,"�O","�X",0,10,0}
	,{"Z","A","Z",0,26,1}
	,{"z","a","z",0,26,1}
	,{"�y","�`","�y",0,26,1}
	,{"��","��","��",0,26,1}
	,{"�]","�T","�]",0,10,1}
	,{"��","�@","�R",0,20,1}
	,{"��","��","��",0,26,1}
	};
static int max_charnum=10;

/****************************************/
/*										*/
/****************************************/
int cl_func_str_add(pInfoParmW,pOperator,nparm,ppParm,dummy,opt)
tdtINFO_PARM *pInfoParmW;
char *pOperator;
tdtINFO_PARM *ppParm[];
int  dummy,opt,nparm;
{
/*
printf("cl_func_str_add: nparm=%d pOperator=[%s] opt=%08x\n",nparm,pOperator,opt);
*/
	return cl_str_exp(pInfoParmW,"+",ppParm[0],ppParm[1]);
}

/****************************************/
/*										*/
/****************************************/
int cl_func_str_exp(pInfoParmW,pFuncName,nparm,ppParm,dummy,opt)
tdtINFO_PARM *pInfoParmW;
char *pFuncName;
tdtINFO_PARM *ppParm[];
int  dummy,opt,nparm;
{
	int ret,mc,len1;
	char c,*pOperator;
/*
printf("cl_func_str_exp: nparm=%d pFuncName=[%s] opt=%08x\n",nparm,pFuncName,opt);
*/
	ret = 0;
	pOperator = NULL;
	if ((len1 = parm_to_char(ppParm[1],&pOperator,NULL))<0) return -1;
	c = *pOperator;
	if (c == '*') mc = 21;
	else if (c == '+') mc = 24;
	else if (c == '-') mc = 25;
	else ret = -26211;
	
	if (!ret) ret = cl_str_exp(pInfoParmW,pOperator,ppParm[0],ppParm[2]);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _get_char_num(wrk,m,a_c,strnum)
char *wrk,*strnum;
int  m,a_c;
{
	int wlen,ret;
	char *p;
	ParList2 par2;
/*
printf("_get_char_num: mc=%d a_c=%08x\n",m,a_c);
*/
	if (!(p=strnum)) p = "";	/* 2021.9.18 */
	if (a_c == 1) {
/*
printf("_get_char_num: strnum=[%s]\n",strnum);
*/
		par2.option = 0;
		ret = substr_mlen(&par2,p,strlen(p),m+1,1);
		memzcpy(wrk,par2.par,par2.parlen);
		wlen = par2.parlen;
	}
	else {
#if 1	/* 2018.12.29 */
	/*	if (!(p=strnum)) p = "";	*/
		if (*p && !m) {
			strcpy(wrk,p);
			wlen = strlen(wrk);
		}
		else {
		m += a_c;
#if 1	/* 2017.11.23 */
		wlen = akxcul2mb(wrk,m);
#else
		memzcpy(wrk,&m,sizeof(int));
		wlen = strlen(wrk);
#endif
		}
#endif
	}
/*
printf("_get_char_num: wlen=%d wrk=[%s]\n",wlen,wrk);
*/
	return wlen;
}

/****************************************/
/*										*/
/****************************************/
int chk_char_num(c,len,iParm)
char *c;
int len,iParm[];
{
	int ic,ulstr1,ulstr2;
	int	i,ret,len1,len2,offset,n,mlen,attr,a_c,k;
	char *p,*str1,*str2,wrk[5];
/*
memzcpy(wrk,c,len);
printf("chk_char_num: c=[%s] len=%d\n",c,len);
*/
	a_c = 0;
	iParm[0] = 0;
	iParm[1] = 0;
#if 1
	if (*c==' ' || !strcmp(c,"�@")) {
	}
#else
	if (*c == '@') {
		a_c = chk_char_num("A",2,iParm);
		iParm[0] = 1;
	}
#endif
	else {
		ic = akxcmb2ul(c,len);
/*
printf("chk_char_num: ic=%08x\n",ic);
*/		for (i=0;i<max_charnum;i++) {
			offset = charnum[i].offset;
			p = charnum[i].str_num;
			str1 = charnum[i].str1;
			if (!str1) {
				if (p) {
					if ((k=akxs_in_str_opt(p,c,4)) > 0) {
						k += /*offset*/ - 1;
						a_c = 1;
					}
				}
			}
			else {
				ulstr1 = akxcmb2ul(str1,strlen(str1));
				if (!p) p = "";
/*
printf("chk_char_num: str1=%s ulstr1=%08x\n",str1,ulstr2);
*/
				if (!strcmp(p,c)) {
					a_c = ulstr1 - 1;
					k = 0;
				}
				else {
					str2 = charnum[i].str2;
					ulstr2 = akxcmb2ul(str2,strlen(str2));
/*
printf("chk_char_num: str2=%s ulstr2=%08x\n",str2,ulstr2);
*/
					if (ic>=ulstr1 && ic<=ulstr2) {
						a_c = ulstr1;
						if (*p) --a_c;
						k = ic - a_c;
					}
				}
			}
			if (a_c) {
				iParm[0] = i;
				iParm[1] = k;
				break;
			}
		}
	}
/*
printf("chk_char_num: a_c=%08x iParm=%d %d\n",a_c,iParm[0],iParm[1]);
*/
	return a_c;
}

/****************************************/
/*										*/
/****************************************/
int normalize_char_num(pDat,len)
char *pDat;
int len;
{
	int len0,len1,pos;
	char c,*p;

	if (!(p = pDat)) return -1;
	if (len > 0) {
		if ((c = *p)=='+' || c=='-') {
			p++;
			len--;
			len1 = 1;
		}
		else len1 = 0;
		if (len > 0) {
			pos = akxnskipin(p,len1,"@");
			if (pos > 0) {
				if (pos < len) pos++;
				len -= --pos;
				memzcpy(p,p+pos,len);
			}
		}
		len += len1;
	}
	return len;
}

/********1*********2*********3*********4*********5*******/
/* �@�\ : �����񒆂̐��������𔲂��o��					*/
/* ���� : IN  : pDat : ����������						*/
/*				len  : ����������(�o�C�g)				*/
/*				opt  : �����o��������̌`��				*/
/*						=0: ���̕����̂܂�				*/
/*						=1: �����̕���					*/
/*						=2: �����ԍ�					*/
/*						=0x4: ���������ȊO�����o��	*/
/*		  OUT : �Ȃ�									*/
/* �ԋp : �����o����������(null�I�[)					*/
/* �쐬 : 2017.10.14 Akito Konayashi					*/
/* �X�V :												*/
/********************************************************/
char *str_numberize(pList,pDat,len,opt)
parmList *pList;
char *pDat;
int len,opt;
{
	int opt4,m,a_c,iParm[2],ii,k,wlen,dlen;
	char *p,*d,*dp,wrk[5];

	pList->prp = NULL;
	pList->prmlen = 0;
	if (!pDat) return NULL;
	if (!(p=cl_tmp_const_malloc(len+1))) return NULL;
	memcpy(p,pDat,len);
	len = akxttrim(0,p,len);
	opt4 = opt & 0x04;
	opt = opt & 0x03;
	if (!(d=cl_tmp_const_malloc(len+1))) return NULL;
	dp = d;
	while (len > 0) {
		m = akxqkanjilen2(p,len);
		a_c = chk_char_num(p,m,iParm);
		if (a_c) {
			if (opt) {
				ii = iParm[0];		
				k = iParm[1];
				if (opt == 1) {
					wlen = _get_char_num(wrk,0,a_c,charnum[ii].str_num);
				}
				else if (opt == 2) {
					wrk[0] = k;
					wrk[1] = '\0';
					wlen = 1;
				};
				memcpy(dp,wrk,wlen);
			}
			else {
				memcpy(dp,p,m);
				wlen = m;
			}
			dp += wlen;
			dlen += wlen;
		}
		else if (opt4) {
			memcpy(dp,p,m);
			dp += m;
			dlen += m;
		}
		p += m;
		len -= m;
	}
	*dp = '\0';
	pList->prp = d;
	pList->prmlen = dlen;
	return d;
}

/****************************************/
/*										*/
/****************************************/
int str_exp_num(pList,mc,str,str_len,num,i0)
parmList *pList;
int mc,i0;
char *str;
int  str_len,num;
{
	int ret;
	char *rp;
	parmList rList;
/*
printf("str_exp_num:Enter: mc=%d str=[%s] str_len=%d num=%d i0=%d\n",mc,str,str_len,num,i0);
*/
	if (!(rp=cl_tmp_const_malloc(str_len+1))) return ECL_MALLOC_ERROR;
	cmn_mrzcpy(rp,str,str_len);
	memset(&rList,0,sizeof(parmList));
	if (!(ret=rstr_exp_num(pList,mc,rp,str_len,num,i0))) {
		cmn_mrzcpy(pList->prp,rList.prp,rList.prmlen);
	}
/*
printf("str_exp_num:Exit: prp=[%s] prmlen=%d\n",pList->prp,pList->prmlen);
*/
	return ret;
}
/****************************************/
/*										*/
/****************************************/
int rstr_exp_num(pList,mc,str,str_len,num,i0)
parmList *pList;
int mc,i0;
char *str;
int  str_len,num;
{
	int	 ret,len1,m,n,i,ii,mlen,attr,a_c,m_m,u,k,iParm[2],wlen,dlen,offset,u1,a,ku;
	char *p,*strnum,wrk[5],*pd,*pdat,c[5];
/*
printf("rstr_exp_num:Enter: mc=%d str=[%s] str_len=%d num=%d i0=%d\n",mc,str,str_len,num,i0);
*/
	ret = 0;
	pList->prp = NULL;
	pList->prmlen = 0;
	a_c = 0;
	offset = 0;
	strnum = NULL;
	p = str;
	len1 = str_len;
	if (!(pdat=pList->prp)) {
		if (!(pdat=cl_tmp_const_malloc(str_len+20))) return ECL_MALLOC_ERROR;
	}
	pd = pdat;
	*pd = '\0';
	dlen = 0;
	if (mc == 21) u = 0;
	else if (mc == 24) u = num;
	else u = -num;
/*
printf("rstr_exp_num: p=[%s] len1=%d u=%d\n",p,len1,u);
*/
	if (i0 <= 0) i0 = 1;
	i = 1;
	while (len1>0 && i<i0) {
		m = akxqkanjilen2(p,len1);
		i++;
		memzcpy(pd,p,m);
		pd += m;
		dlen += m;
		len1 -= m;
		p += m;
/*
*pd = '\0';
printf("rstr_exp_num: i=%d pdat=[%s] len1=%d\n",i,pdat,len1);
*/
	}
	while (len1 > 0) {
		if (mc==21 || u) {
			m = akxqkanjilen2(p,len1);
			memzcpy(c,p,m);
			a_c = chk_char_num(c,m,iParm);
			if (a_c) {
				ii = iParm[0];
				k  = iParm[1];
				m_m = charnum[ii].rad;
				if (mc == 21) k *= num;
/*
printf("rstr_exp_num: m_m=%d u=%d k=%d\n",m_m,u,k);
*/
				u1 = u;
#if 1	/* 2017.11.5 */
				ku = k + u;
				if (ku < 0) {
					n = (m_m-ku)/m_m;
					a = k + m_m*n;
					k = a + u;
					n = k % m_m;
					u = -(a / m_m);
				}
				else {
					n = ku % m_m;
					u = ku / m_m;
				}
				k = ku;
#else
				k += u ;
				n = k % m_m;
				u = k / m_m;
				if (n < 0) n += m_m;
#endif
/*
printf("rstr_exp_num: n=%d u=%d\n",n,u);
*/
				offset = charnum[ii].offset;
#if 0	/* 2018.12.30 */
				if (len1==m && offset>0 && u1<0 && k<0) {
					strcpy(wrk,"@");
					wlen = 1;
					u = 0;
				}
				else {
#endif
					strnum = charnum[ii].str_num;
					wlen = _get_char_num(wrk,n,a_c,strnum);
#if 0	/* 2018.12.30 */
				}
#endif
			}
			else {
				memzcpy(wrk,p,m);
				wlen = m;
			}
			memzcpy(pd,wrk,wlen);
			pd += wlen;
			dlen += wlen;
			len1 -= m;
			p += m;
/*
*pd = '\0';
printf("rstr_exp_num: pdat=[%s] len1=%d\n",pdat,len1);
*/
		}
		else {
			memzcpy(pd,p,len1);
			dlen += len1;
			break;
		}
	}
/*
printf("rstr_exp_num:loop out: pdat=[%s] dlen=%d len1=%d u=%d\n",pdat,dlen,len1,u);
*/
	if (u >= 0) {
		if (!a_c) {
			a_c = '0';
			m_m = 10;
			offset = 0;
		}
		while (u > 0) {
			n = u % m_m;
			u = u / m_m;
			if (n < 0) n += m_m;
			n -= offset;
			wlen = _get_char_num(wrk,n,a_c,strnum);
			memzcpy(pd,wrk,wlen);
			pd += wlen;
			dlen += wlen;
/*
printf("rstr_exp_num: pdat=[%s] dlen=%d u=%d\n",pdat,dlen,u);
*/
		}
	}
	else {
		memzcpy(pd,"-",1);
		dlen++;
		ret = 500;
	}
	pList->prp = pdat;
	pList->prmlen = dlen;
/*
printf("rstr_exp_num:Exit: pdat=[%s] len1=%d\n",pdat,len1);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int rstr_add_rstr(pList,mc,str1,strlen1,i0,str2,strlen2)
parmList *pList;
int mc,i0;
char *str1,*str2;
int  strlen1,strlen2;
{
	int  len1,len2,len3,m1,m2;
	int	 rc,n,i,j,a_c,k,iParm[2],ii0;
	char *p1,*p2,c[5],*p;
/*
printf("rstr_add_rstr: mc=%d str1=[%s] len1=%d i0=%d str2=[%s] len2=%d\n",
mc,str1,strlen1,i0,str2,strlen2);
*/
	p1 = str1;
	p2 = str2;
	len1 = strlen1;
	len2 = strlen2;
	n = i0 - 1;
	for (i=1;i<i0;i++) {
		m1 = akxqkanjilen2(p1,len1);
		len1 -= m1;
		p1 += m1;
		n--;
		if (len1 <= 0) break;
	}
/*
printf("rstr_add_rstr: len1=%d n=%d\n",len1,n);
*/
	ii0 = i0;
	while (len2>0 && len1>0) {
		m2 = akxqkanjilen2(p2,len2);
		memzcpy(c,p2,m2);
		a_c = chk_char_num(c,m2,iParm);
		if (a_c) {
			k  = iParm[1];
			while (len1 > 0) {
				m1 = akxqkanjilen2(p1,len1);
				memzcpy(c,p1,m1);
				a_c = chk_char_num(c,m1,iParm);
				if (a_c) break;
				p1 += m1;
				len1 -= m1;
			}
			if (len1 <= 0) break;
			rc = rstr_exp_num(pList,mc,str1,strlen1,k,ii0);
			str1 = pList->prp;
			len3 = pList->prmlen;
			if (len3 > strlen1) {
				len1 += len3 - strlen1;
				strlen1 = len3;
			}
			p1 += m1;
			len1 -= m1;
		}
		p2 += m2;
		len2 -= m2;
		ii0++;
	}
/*
printf("rstr_add_rstr: len1=%d len2=%d\n",len1,len2);
*/
	if (len2>0 && len1==0) {
		len3 = len2 + strlen1 + n;
		if (!(p1=cl_tmp_const_malloc(len3))) return ECL_MALLOC_ERROR;
		p = p1;
		memcpy(p1,str1,strlen1);
		p1 += strlen1;
		memset(p1,'_',n);
		p1 += n;
		memzcpy(p1,p2,len2);
		str1 = p;
		strlen1 = len3;
	}
	pList->prp = str1;
	pList->prmlen = strlen1;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_str_exp(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
char *pOperator;
{
	int ret,mc;
	char c;
/*
printf("cl_str_exp: pOperator=[%s]\n",pOperator);
*/
	ret = 0;
	c = *pOperator;
	if (c == '*') mc = 21;
	else if (c == '+') mc = 24;
	else if (c == '-') mc = 25;
	else ret = -26211;

	if (!ret) {
		if (pInfoParm1->pi_attr>1 || pInfoParm2->pi_attr>1 || mc==24 || mc==25)
			ret = cl_str_add(pInfoParmW,mc,pInfoParm1,pInfoParm2);
		else if (mc == 21)
			ret = cl_str_mult_str(pInfoParmW,pInfoParm1,pInfoParm2);
		else
			ret = -21321;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int  _set_result(pInfoParmW,pList,sign1)
tdtINFO_PARM *pInfoParmW;
parmList *pList;
int sign1;
{
	int	 len1,sign2;
	char *p1,*p2,*rp1;

	rp1 = pList->prp;
	len1 = pList->prmlen;
	p2 = rp1 + len1 - 1;
	if (*p2 == '-')  {
		sign2 = 1;
		*p2 = '\0';
		len1--;
		p2--;
	}
	else sign2 = 0;
	if ((sign1+sign2) == 1) {
		p2++;
		*p2++ = '-';
		len1++;
		*p2 = '\0';
	}
	if (!(p1=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
	cmn_mrzcpy(p1,rp1,len1);
	cl_set_parm_char(pInfoParmW,p1,len1);

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_str_add(pInfoParmW,mc0,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
int mc0;
tdtINFO_PARM *pInfoParm1,*pInfoParm2;
{
	parmList tList,tList1,tList2;
	tdtINFO_PARM *pInfo,info1,info2;
	long lval,lval0;
	int	 ret,i,len1,len2,atr1,atr2,sign[2],len[2],k,len1p,cmp,mc;
	char *p1,*p2,*p[2],*rp1,*p1p,wrk[16];

	mc = mc0;
/*
printf("cl_str_add: mc=%d\n",mc);
DEBUGOUT_InfoParm(0,"cl_str_add: pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(0,"cl_str_add: pInfoParm2=",pInfoParm2,0,0);
*/
	ret = 0;
	sign[0] = 0;
	sign[1] = 0;
	atr1 = pInfoParm1->pi_attr;
	atr2 = pInfoParm2->pi_attr;
/*
printf("cl_str_add: atr1=%d atr2=%d\n",atr1,atr2);
*/
	if (atr1>1 && atr2>1)
		ret = -21331;
	else if (atr1>1 || atr2>1) {
		pInfo = pInfoParm1;
		for (i=0;i<2;i++) {
			if (atr1 == 1) {
				p1 = NULL;
				if ((len1 = parm_to_char(pInfo,&p1,NULL))<0) return -1;
			}
			else {
				if (ret = cl_get_parm_bin(pInfo,&lval,"cl_str_add.p1")) return ret;
			}
			pInfo = pInfoParm2;
			atr1 = atr2;
		}
/*
printf("cl_str_add: len1=%d p1=[%s] lval=%d\n",len1,p1,lval);
*/
		p1p = p1;
		len1p = len1;
		lval0 = lval;
		if (*p1p == '-') {
			sign[0] = 1;
			p1p++;
			len1p--;
			if (mc == 25) mc = 24;
			else lval = -lval;
		}
#if 1
		if (mc == 21) {
			if (lval < 0) {
				sign[1] = 1;
				lval = -lval;
			}
			else if (!lval) sign[0] = 0;
		}
		else if (mc == 25) {
			mc = 24;
			lval = -lval;
		}
#endif
		len1 = normalize_char_num(p1p,len1p);
	/*	if ((!sign[0] && mc==24 && lval>0) || X_ABS(lval)<=9) {	*/
#if 0
			k = lval;
			if (*p1 == '-') {
				sign[0] = 1;
				p1++;
				len1--;
				if (mc==24 || mc==25) mc = 25 - (mc - 24);
			}
			if (mc == 25) k = -k;
			if (mc == 21) {
				if (k < 0) {
					sign[1] = 1;
					k = -k;
				}
				else if (!k) sign[0] = 0;
			}
#endif
			if (sign[0] != sign[1]) sign[0] = sign[0] + sign[1];
			if (!(rp1=cl_tmp_const_malloc(len1p+1))) return ECL_MALLOC_ERROR;
			cmn_mrzcpy(rp1,p1p,len1p);
/*
printf("cl_str_add: len1p=%d rp1=[%s]\n",len1p,rp1);
*/
			ret = rstr_exp_num(&tList,mc,rp1,len1p,lval,1);
	/*	}
		else {	*/
		if (ret == 500) {
#if 1	/* 2018.12.30 */
			ret = 0;
#else
#if 1	/* 2018.2.11 */
			len2 = cmn_i_to_a(lval0, wrk);
			cl_set_parm_char(&info2,wrk,len2);
#else
			p2 = str_numberize(&tList,p1p,len1p,5);
			if (ret = str_exp_num(&tList,24,p1p,len1p,X_ABS(lval),1)) return ret;
			i = strdiff(tList.prp,p2);
			if (i > 0) p2 = tList.prp + i;
			else p2 = tList.prp;
			cl_set_parm_char(&info2,p2,strlen(p2));
#endif
			cl_set_parm_char(&info1,p1,len1);
			return cl_str_add(pInfoParmW,mc,&info1,&info2);
#endif
		}
	}
	else if (mc == 21) {
		return cl_str_mult_str(pInfoParmW,pInfoParm1,pInfoParm2);
	}
	else {
		pInfo = pInfoParm1;
		for (i=0;i<2;i++) {
			p1 = NULL;
			if ((len1=parm_to_char(pInfo,&p1,NULL)) < 0) return -len1;
			if (*p1 == '-') {
				sign[i] = 1;
				p1++;
				len1--;
			}
			len1 = normalize_char_num(p1,len1);
			if (!(rp1=cl_tmp_const_malloc(len1+1))) return -1;
			cmn_mrzcpy(rp1,p1,len1);
			p[i] = rp1;
			len[i] = len1;
			pInfo = pInfoParm2;
		}
	/*
		if (sign[0] != sign[1]) {
			sign[0] = sign[0] + sign[1];
			mc = 25 - (mc - 24);
		}
	*/
		if (mc == 24) {
			if (sign[0] != sign[1]) {
				str_numberize(&tList1,p[0],2);
				str_numberize(&tList2,p[1],2);
				cmp = str_num_cmp(tList1.prp,tList1.prmlen,tList2.prp,tList2.prmlen);
				if (!cmp) {
					str_numberize(&tList,p[0],5);
					mc = 0;
				}
				else if (cmp > 0) {
					mc = 25;
				}
				else {
					p1 = p[0];
					p[0] = p[1];
					p[1] = p1;
					mc = 25;
					sign[0] = sign[1];
				}
			}
		}
		else {
			if (sign[0] != sign[1]) {
				mc = 24;
			}
			else {
				str_numberize(&tList1,p[0],2);
				str_numberize(&tList2,p[1],2);
				cmp = str_num_cmp(tList1.prp,tList1.prmlen,tList2.prp,tList2.prmlen);
				if (!cmp) {
					str_numberize(&tList,p[0],5);
					mc = 0;
				}
				else if (cmp < 0) {
					p1 = p[0];
					p[0] = p[1];
					p[1] = p1;
					mc = 25;
					sign[0] = 1 - sign[1];
				}
			}
		}
		if (mc) ret = rstr_add_rstr(&tList,mc,p[0],len[0],1,p[1],len[1]);
	}
	if (!ret) {
#if 1
		ret = _set_result(pInfoParmW,&tList,sign[0]);
#else
		rp1 = tList.prp;
		len1 = tList.prmlen;
		p2 = rp1 + len1 - 1;
		if (*p2 == '-')  {
			sign[1] = 1;
			*p2 = '\0';
			len1--;
		}
		else sign[1] = 0;
		if ((sign[0]+sign[1]) == 1) {
			*p2++ = '-';
			len1++;
			*p2 = '\0';
		}
		if (!(p1=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
		cmn_mrzcpy(p1,rp1,len1);
		cl_set_parm_char(pInfoParmW,p1,len1);
#endif
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_str_mult_str(pInfoParmW,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	parmList tList1,tList2,tListW;
	tdtINFO_PARM *pInfo;
	long lval;
	int	 ret,i,len1,len2,atr1,atr2,sign[2],len[2],m1,m2,a_c,k,iParm[2];
	char *p1,*p2,*p[2],*rp1,*dat,c[5],w[16];
/*
DEBUGOUT_InfoParm(0,"cl_str_mult_str: pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(0,"cl_str_mult_str: pInfoParm2=",pInfoParm2,0,0);
*/
	ret = 0;
	sign[0] = 0;
	sign[1] = 0;
	atr1 = pInfoParm1->pi_attr;
	atr2 = pInfoParm2->pi_attr;
/*
printf("cl_str_mult_str: atr1=%d atr2=%d\n",atr1,atr2);
*/
	if (atr1>1 || atr2>1) {
		return cl_str_add(pInfoParmW,24,pInfoParm1,pInfoParm2);
	}
	pInfo = pInfoParm1;
	for (i=0;i<2;i++) {
		p1 = w;
		if ((len1 = parm_to_char(pInfo,&p1,NULL))<0) return -len1;
		if (*p1 == '-') {
			sign[i] = 1;
			p1++;
			len1--;
		}
		len1 = normalize_char_num(p1,len1);
		if (!(rp1=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
		cmn_mrzcpy(rp1,p1,len1);
		p[i] = rp1;
		len[i] = len1;
		pInfo = pInfoParm2;
	}
	if (sign[0] != sign[1])
		sign[0] = sign[0] + sign[1];
	else
		sign[0] = 0;
	dat = NULL;
	p1 = p[0];
	p2 = p[1];
	len2 = len[1];
	len1 = len[0];
	if (!(tList1.prp=cl_tmp_const_malloc(len1+len2+1))) return ECL_MALLOC_ERROR;
	if (!(tList2.prp=cl_tmp_const_malloc(len1+len2+1))) return ECL_MALLOC_ERROR;
	if (!(tListW.prp=cl_tmp_const_malloc(len1+20))) return ECL_MALLOC_ERROR;
	i = 1;
	tList1.prmlen = 0;
	while (len2 > 0) {
		m2 = akxqkanjilen2(p2,len2);
		memzcpy(c,p2,m2);
		a_c = chk_char_num(c,m2,iParm);
		if (a_c) {
			k  = iParm[1];
			ret = rstr_exp_num(&tListW,21,p1,len1,k,1);
			if (!tList1.prmlen) {
				memzcpy(tList1.prp,tListW.prp,tListW.prmlen);
				tList1.prmlen = tListW.prmlen;
			}
			else {
				tList2.prp = tList1.prp;
				tList2.prmlen = tList1.prmlen;
				ret = rstr_add_rstr(&tList1,24,tList2.prp,tList2.prmlen,i,tListW.prp,tListW.prmlen);
			}
		}
		p2 += m2;
		len2 -= m2;
		i++;
	}
	ret = _set_result(pInfoParmW,&tList1,sign[0]);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int str_num_cmp(a,len_a,b,len_b)
char *a,*b;
int len_a,len_b;
{
	int d,ret;

	if (!b || len_a>len_b)
		ret = 1;
	else if (!a || len_a<len_b)
		ret = -1;
	else {
		d = akxmemcmp(a,b,len_a);
		if (d > 0) ret = 1;
		else if (d < 0) ret = -1;
		else ret = 0;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int strdiff(a,b)
char *a,*b;
{
	char *pa,*pb;
	int len_a,len_b,i,ii,m1,m2;

	if (!(pa=a) || !(pb=b)) return -1;
	len_a = strlen(pa);
	len_b = strlen(pb);
	i = 1;
	ii = 0;
	while (len_a>0 && len_b>0) {
		m1 = akxqkanjilen2(pa,len_a);
		m2 = akxqkanjilen2(pb,len_b);
		if (m1 != m2) {
			ii = i;
			break;
		}
		if (memcmp(pa,pb,m1)) {
			ii = i;
			break;
		}
		i += m1;
		pa += m1;
		pb += m2;
	}
	return ii;
}
