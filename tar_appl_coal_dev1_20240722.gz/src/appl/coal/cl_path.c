static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*******************************************************/
/* <cldPath.c>                                         */
/*      exec command  process                          */
/*******************************************************/
#include "colmn.h"

#undef DEBUG
extern condList *pCLcList;		/* ��񃊃X�g */
extern CLPRTBL   *pCLprocTable;
extern GlobalCt  *pGlobTable;

/**************************************************************/
/* cl_process_msg_pre_send                                    */
/**************************************************************/
int cl_process_msg_pre_send(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc = 0, cmd;

	if (leaf) {
		cmd = leaf->cmd.cid;
		proc->Curleaf = leaf;
		cl_ret_leaf_push(proc,leaf);
		if (cmd == C_SQL)
			rc = cl_process_sqlsnd(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		else if (cmd == C_SLEEP)
			rc = cl_process_sleep_snd(leaf->cmd.prmnum,leaf->cmd.prmp,proc);
		else if (cmd == C_MSG)
			rc = cl_process_messag_send(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		if (rc == ECL_EX_MSG_NO_SLEEP) {
			rc = 0;
		}
		else if (rc) {
			pGlobTable->error = rc;
			if (!pGlobTable->exception)
				pGlobTable->exception = cl_mk_exception_code(COMM_EXCEPTION,rc);
			pGlobTable->tuppl = 0;
		}
		else {
			cmn_set_stat(RTN_PR,&pCLprocTable->PrSt,L_ON);
			cmn_set_stat(RTN_PR,&proc->ptype,L_ON);
		}
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_msg_pre_return                                  */
/**************************************************************/
int cl_process_msg_pre_return(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
	ScrPrCT *scrprct;
	ProcCT  *procct;
	int rc, cmd;

	if (leaf) {
		procct = cl_search_proc_ct();
		if ((cmd=leaf->cmd.cid) == C_SQL)
			rc = cl_process_sqlrcv(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		else if (cmd == C_SLEEP)
			rc = cl_process_sleep_rcv(leaf->cmd.prmnum,leaf->cmd.prmp);
		else if (cmd == C_MSG)
			rc = cl_process_message_recv(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		if (pCLprocTable->WaitPacketp) Free(pCLprocTable->WaitPacketp);
		pCLprocTable->WaitPacketp = NULL;
		cmn_set_stat(RTN_PR,&procct->ptype,L_OFF);
		cmn_set_stat(RTN_PR,&pCLprocTable->PrSt,L_OFF);
	}
	else {
		ERROROUT("cl_process_msg_pre_return:leaf==NULL");
		rc = ECL_SYSTEM_ERROR;
	}

	return rc;
}

/**************************************************************/
/* cl_proc_bexp                                               */
/**************************************************************/
int cl_process_bexp(cid, leaf, proc)
int     cid;
Leaf    *leaf;
ProcCT  *proc;
{
	int rc;

	if (leaf && proc) {
		if (cid == C_BEXP) rc = cl_proc_bexp(leaf,proc);
		else rc = cl_process_let(leaf,proc);
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_read                                            */
/**************************************************************/
int cl_process_read(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc;

	if (leaf && proc) {
		rc = cl_proc_read(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_output                                          */
/**************************************************************/
int cl_process_output(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int   rc;

	if (leaf && proc)  rc = cl_proc_output(leaf,proc);
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_leave                                           */
/**************************************************************/
int cl_process_leave(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc;

	if (leaf && proc) {
		/* �k�d�`�u�d�������s */
		rc = cl_proc_leave(leaf, proc);
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_messag_send                                     */
/**************************************************************/
int cl_process_messag_send(nprm,prmp,pbxobj)
int nprm;
parmList *prmp[];
GXObject *pbxobj[];
{
	char *p;
	int rc;

	p = prmp[0]->prp;
 	if (!stricmp(p,"SEND") ||
 	    !stricmp(p,"POST") ||
 	    !stricmp(p,"REPLY"))
			rc = cl_process_msg_snd(nprm,prmp,pbxobj);
	else if (!stricmp(p,"SQL"))
			rc = cl_process_sqlsnd(nprm-1,prmp+1,pbxobj);
	else if (!stricmp(p,"SLEEP"))
			rc = cl_process_sleep_snd(nprm-1,prmp+1,pbxobj);
	else {
		ERROROUT1("[%s] not SQL,SLEEP,SEND,POST,REPLY",p);
		rc = ECL_EX_MSG;
	}
	return rc;
}

/**************************************************************/
/* cl_process_message_recv                                    */
/**************************************************************/
int cl_process_message_recv(nprm,prmp,pbxobj)
int nprm;
parmList *prmp[];
GXObject *pbxobj[];
{
	char *p;
	int rc;

	p = prmp[0]->prp;
 	if (!stricmp(p,"SEND") ||
 	    !stricmp(p,"POST") ||
 	    !stricmp(p,"REPLY"))
			rc = cl_process_msg_rcv(nprm,prmp,pbxobj);
	else if (!stricmp(p,"SQL"))
			rc = cl_process_sqlrcv(nprm-1,prmp+1,pbxobj);
	else if (!stricmp(p,"SLEEP"))
			rc = cl_process_sleep_rcv(nprm-1,prmp+1);
	else {
		ERROROUT1("[%s] not SQL,SLEEP,SEND,POST,REPLY",p);
		rc = ECL_SYSTEM_ERROR;
	}
	return rc;
}

/****************************************************/
/*													*/
/*		Interractive mode							*/
/*													*/
/***************************************************/
typedef struct {
	int init_flag;
	int n1;
	int n2;
	int auto_mode;
	int tree_mode;
	int run_mode;
	tdtQUE_CTL *pQue;
	tdtQUE_CTL *pQueAuto;
	M_FILE *mfp;
	tdtINFO_PARM *ppParm[3];
} tdtInteract;

/****************************************/
/*										*/
/****************************************/
static int _get_src(pQue,n,s,s_len)
tdtQUE_CTL *pQue;
int n;
char *s;
int s_len;
{
	int rc,nn;
	char *cp,*p;
/*
printf("_get_src: n=%d s_len=%d\n",n,s_len);
*/
	if (s_len <= 0) return -1;
	if (n > 0) {
		akxs_que_move(pQue,QUE_TOP);
		while ((rc=akxs_que_peek(pQue,QUE_PEEK_NEXT,&cp)) > 0) {
			memcpy(&nn,cp,sizeof(int));
/*
printf("_get_src: n=%d p=[%s]\n",nn,cp+sizeof(int));
*/
			if (n == nn) break;
		}
	}
	else {
		rc = akxs_que_peek(pQue,QUE_BOT,&cp);
/*
if (rc > 0) {
memcpy(&nn,cp,sizeof(int));
printf("_get_src: n=%d p=[%s]\n",nn,cp+sizeof(int));
}
*/
	}
	if (rc > 0) {
		strncpy(s,cp+sizeof(int),s_len-1);
		s[s_len-1] = '\0';
#if 1	/* 2023.11.4 */
		memcpy(&rc,cp,sizeof(int));
#else
		rc = strlen(s);
#endif
	}
	else *s = '\0';
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _add_src(prr,s,s_len)
tdtInteract *prr;
char *s;
int s_len;
{
	int rc,n;
	char *cp;
/*
printf("_add_src: n1=%d n2=%d s_len=%d s=[%s]\n",n1,n2,s_len,s);
*/
	
	if (s_len <= 0) return 0;
	if ((rc=akxs_que_peek(prr->pQue,QUE_BOT,&cp)) > 0) {
		memcpy(&n,cp,sizeof(int));
		n += prr->n2;
	}
	else n = prr->n1;
	cp = Malloc(sizeof(int)+s_len+1);
	memcpy(cp,&n,sizeof(int));
	memzcpy(cp+sizeof(int),s,s_len);
	akxs_que_put(prr->pQue,QUE_BOT,cp);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _ins_src(pQue,num,s,s_len)
tdtQUE_CTL *pQue;
int num;
char *s;
int s_len;
{
	int rc,n;
	char *cp;
/*
printf("_ins_src: num=%d s_len=%d s=[%s]\n",num,s_len,s);
*/
	akxs_que_move(pQue,QUE_TOP);
	n = 0;
	for (;;) {
		if ((rc=akxs_que_peek(pQue,QUE_PEEK_CUR,&cp)) < 0) return rc;
		else if (!rc) break;
		memcpy(&n,cp,sizeof(int));
/*
printf("_ins_src: peek: rc=%d n=%d\n",rc,n);
*/
		if (n >= num) break;
		akxs_que_move(pQue,QUE_NEXT);
	}
	if (n == num) {
		akxs_que_get(pQue,QUE_CUR,&cp);
		Free(cp);
		rc = num;
	}
	if (s_len > 0) {
		akxs_que_move(pQue,QUE_PREV);
		cp = Malloc(sizeof(int)+s_len+1);
		memcpy(cp,&num,sizeof(int));
		memzcpy(cp+sizeof(int),s,s_len);
		akxs_que_put(pQue,QUE_CUR,cp);
		rc = 0;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _list_src(pQue,argc,argv)
tdtQUE_CTL *pQue;
int argc;
char *argv[];
{
	int rc,n;
	char *cp,*p,*pp;
	Leaf *leafTop;
	condList *y;

	cp = argv[0];
	if (toupper(*cp)=='T'/* || !stricmp(cp,"tree")*/) {
		y = pCLcList;
	/*	if (leafTop = search_top_leaf(y))	*/
		leafTop = y->clstcb->TopTreeSave;
/*
printf("_list_src: leafTop=%08x\n",leafTop);
*/
		if (leafTop) {
/*
printf("_list_src: leftleaf=%08x rightleaf=%08x\n",leafTop->leftleaf,leafTop->rightleaf);
*/
			col_leaf_print(leafTop);
		}
	}
	else {
		akxs_que_move(pQue,QUE_TOP);
		while (akxs_que_peek(pQue,QUE_PEEK_NEXT,&cp) > 0) {
			memcpy(&n,cp,sizeof(int));
			p = cp + sizeof(int);
			cl_str_conv_put(&pp,p,strlen(p));
			printf("%5d %s\n",n,pp);
		/*	if (p != pp) Free(pp);	*/
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _renum_src(prr)
tdtInteract *prr;
{
	int rc,n,n2;
	char *cp;
	tdtQUE_CTL *pQue;

	n = prr->n1;
	n2 = prr->n2;
	pQue = prr->pQue;
	akxs_que_move(pQue,QUE_TOP);
	for (;;) {
		if ((rc=akxs_que_peek(pQue,QUE_PEEK_CUR,&cp)) <= 0) break;
		memcpy(cp,&n,sizeof(int));
		n += n2;
		akxs_que_move(pQue,QUE_NEXT);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _auto_mode(pQue,line,count)
tdtQUE_CTL *pQue;
char *line;
int count;
{
	int rc,pos;
	char *cp;

	if (pQue) {
		if ((rc=akxs_que_peek(pQue,QUE_PEEK_NEXT,&cp)) > 0) {
			strcpy(line,cp+sizeof(int));
			pos = strlen(line);
		}
		else pos = 0;
	}
	else {
		if (count == 1) {
			strcpy(line,"quit;");
			rc = 1;
			pos = strlen(line);
		}
		else {
			pos = rc = 0;
		}
	}
	strcpy(line+pos,"\n");
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _leaf_clear(ys)
CLNCB *ys;
{
	Leaf *leafTop;

	if (leafTop = ys->TopTreeSave) {
		cl_leaf_clear(leafTop);
		ys->TopTreeSave = NULL;
	}
	ys->TopStack = NULL;
}

/****************************************/
/*										*/
/****************************************/
static int _del_src(pQue,argc,argv)
tdtQUE_CTL *pQue;
int argc;
char *argv[];
{
	Leaf *leafTop;
	int i,rc,num,nn,flg,not_found,found;
	char *cp,w[16];
	condList *y;
	CLNCB *ys;

	y = pCLcList;
	ys = y->clstcb;
	flg = 1;
	found = 0;
	for (i=0;i<argc;i++) {
		flg = 0;
		cp = argv[i];
		if ((num=atoi(cp)) > 0) {
			akxs_que_move(pQue,QUE_TOP);
			not_found = 1;
			while ((rc=akxs_que_peek(pQue,QUE_CUR,&cp)) > 0) {
				memcpy(&nn,cp,sizeof(int));
/*
printf("_del_src: n=%d p=[%s]\n",nn,cp+sizeof(int));
*/
				if (num == nn) {
					rc = akxs_que_get(pQue,QUE_CUR,&cp);
					not_found = 0;
					found = 1;
					break;
				}
				akxs_que_move(pQue,QUE_NEXT);
			}
			if (not_found) {
				cmn_i_to_a(num,w);
				ERROROUT2(FORMAT(76),"_del_src",w);	/* %s: %s������܂���B*/
			}
		}
		else if (toupper(*cp)=='T'/* || !stricmp(cp,"tree")*/) ;
	}
	if (!flg && !found) return 0;

	if (flg) akxs_que_all_free(pQue);

#if 1	/* 2023.11.4 */
	_leaf_clear(ys);
#else
/*	if (leafTop = search_top_leaf(y)) {	*/
	if (leafTop = ys->TopTreeSave) {
		cl_leaf_clear(leafTop);
	}
	ys->TopTreeSave = NULL;
	ys->TopStack = NULL;
#endif
	return flg;
}

/****************************************/
/*										*/
/****************************************/
static int _edit_cmd(cmdio,eds)
char *cmdio,*eds;
{
	char c,tmp[BUFLEN],*cms,*cmd,*p,*pp;
	int  len_cms,len_eds,m_cms,m_eds;
/*
printf("_edit_cmd: eds=[%s]\n",eds);
*/
	len_cms = strlen(cmdio);
	len_eds = strlen(eds);
	cmd = tmp;
	cms = cmdio;
	while (c=*eds) {
/*
printf("_edit_cmd: cms=[%s]\n",cms);
*/
		m_eds = akxqkanjilen2(eds,len_eds);
		m_cms = akxqkanjilen2(cms,len_cms);
		len_eds -= m_eds;
		len_cms -= m_cms;
		if (m_eds == 1) {
/*
printf("_edit_cmd: c=[%c] m_eds=%d m_cms=%d len_eds=%d len_cms=%d\n",c,m_eds,m_cms,len_eds,len_cms);
*/
			if (c==' ') {
			/*	if (c=*cms++) {
					*cmd++ = *cms++;	*/
				if (*cms) {
					memzcpy(cmd,cms,m_cms);
					cmd += m_cms;
					cms += m_cms;
				}
				else {
					*cmd++ = c;
					*cmd   = '\0';
				}
			}
			else if (c=='#') {
			/*	if (*cms) cms++;	*/
				if (*cms) cms += m_cms;
			}
			else if (c=='^') {
			/*
				if (c=*eds++) {
					*cmd++ = c;
				}
			*/
				eds++;
				if (*eds) {
					m_eds = akxqkanjilen2(eds,len_eds);
					memzcpy(cmd,eds,m_eds);
					cmd += m_eds;
				/*	eds += m_eds;	*/
					len_eds -= m_eds;
				/*	cms += m_cms;	*/
					len_cms += m_cms;
				}
				else break;
			}
			else if (c=='%') {
				break;
			/*
				strcpy(cmd,eds);
				strcpy(cmdio,tmp);
				return 0;
			*/
			}
			else if (c=='\\') {
			/*	if (c=*eds++) {
					*cmd++ = c;
					if (*cms) cms++;	*/
				eds++;
				if (*eds) {
					m_eds = akxqkanjilen2(eds,len_eds);
					memzcpy(cmd,eds,m_eds);
					cmd += m_eds;
				/*	eds += m_eds;	*/
					len_eds -= m_eds;
					cms += m_cms;
				}
				else break;
			}
			else if (c==';') {
				*cmd++ = c;
				*cmd   = '\0';
			/*
				strcpy(cmdio,tmp);
				return 0;
			*/
				*cms   = '\0';
				break;
			}
			else {
				*cmd++ = c;
			/*	if (*cms) cms++;	*/
				if (*cms) cms += m_cms;
				*cmd   = '\0';
			}
		}
		else {
			memzcpy(cmd,eds,m_eds);
			cmd += m_eds;
			cms += m_cms;
		}
		eds += m_eds;
/*
printf("_edit_cmd: tmp=[%s]\n",tmp);
*/
	}
	strcpy(cmd,cms);
	strcpy(cmdio,tmp);
/*
printf("_edit_cmd: cmdio=[%s]\n",cmdio);
*/
	return strlen(cmdio);
}

/****************************************/
/*										*/
/****************************************/
static int _read_file(ppParm,line,count)
tdtINFO_PARM *ppParm[];
char *line;
int count;
{
	int rc,pos,fope,iParm[5];
	char *cp,*pOpe,*pAns;
	M_FILE *mfp;
/*
printf("_read_file: count=%d pGlobTable->error=%d\n",count,pGlobTable->error);
*/
	if (ppParm) {
		pOpe = "FGETLINE";
		fope = D_FUC_FGETLINE;
		for (;;) {
			mem_set_int(iParm,0,5);
			rc = func_file(&pAns,pOpe,1,ppParm,fope,iParm);
/*
printf("_read_file: rc=%d pGlobTable->error=%d\n",rc,pGlobTable->error);
*/
			if (!pGlobTable->error) {
				strcpy(line,pAns);
				pos = strlen(line);
				cl_puts(line);
				if (pos > 0) {
					rc = 1;
					break;
				}
			}
			else {
				pos = 0;
				rc = -1;
				break;
			}
		}
	}
	else {
		if (count == 1) {
			strcpy(line,"quit;");
			rc = 1;
			pos = strlen(line);
		}
		else {
			pos = rc = 0;
		}
	}
/*	strcpy(line+pos,"\n");	*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _set_input_file(buf,ssp,line,prr)
char *buf,*line;
SSPL_S *ssp;
tdtInteract *prr;
{
	FILE *fp;
	M_FILE *mfp;
	int rc,len,line_len,auto_mode;
	char *work,dir[256];
	tdtINFO_PARM **ppParm;

	prr->auto_mode = 0;
	prr->mfp = NULL;
	prr->run_mode = 0;
	ppParm = prr->ppParm;
	if ((len=akxtgwse(buf,ssp," \n",1)) > 0) {
		work = ssp->wd;
/*
printf("_set_input_file: work=[%s]\n",work);
*/
		if (fp = cl_lex_file_open(work,dir,"_set_input_file")) {
			if (mfp = m_fp_open(fp,work,"r")) {
				prr->mfp = mfp;
				cl_set_parm_long(ppParm[0],mfp);
				cl_set_parm_long(ppParm[2],0);
				if ((len=akxtgwse(buf,ssp," \n",1)) > 0) {
					if (toupper(*work) == 'R') prr->run_mode = 1;
				}
				rc = _read_file(ppParm,line,1);
				if (rc >= 0) {
					line_len = strlen(line);
					_add_src(prr,line,line_len);
					strcpy(line+line_len,"\n");
					prr->auto_mode = 2;
				}
			}
			else {
				printf("*** [%s] m_fp_open error.\n",work);
			}
		}
		else {
			printf("*** [%s] open error.\n",work);
		}
	}
	else printf("*** no file name.\n");
	return 0;
}

/********1*********2*********3*********4*********5*********6*/
/* �@�\ : lex()�̕����͂Ƃ��ČĂ΂�A����Ԃ�				*/
/* ���� : line     : �����͈�								*/
/*					   ���͉��s�R�[�h(LF)�ŏI���			*/
/*					   �������s�R�[�h�݂̂̂Ƃ��͓��͏I����	*/
/*					   ���Ȃ�(lex()�ŕ�����'\n'��len=1�̂Ƃ�)*/
/*		  line_max : �����͈�̃T�C�Y(�o�C�g)				*/
/************************************************************/
static int _editor(line,line_max)
char *line;
int line_max;
{
	static char *help[]=
{"/            ���͗�����ɕۑ����ꂽ�������s����B"
,"/list [tree] tree�Ȃ��̂Ƃ��́A���͗�����ɕۑ����ꂽ����\������B"
,"             tree�̂Ƃ��́A�����ς݃R�}���htree�݂̂�\������B"
,"/renum [�����l][,|��][�����l]"
,"             �̔Ԃ̃f�t�H���g�l��ύX���A�s�ԍ���U�蒼���B"
,"             �l���ȗ����邩�A�[���ȉ��̂Ƃ��́A�f�t�H���g�l�͕ύX����Ȃ��B"
,"/del [tree|no ...]"
,"             tree|no�Ȃ��̂Ƃ��́A���͗�����ɕۑ����ꂽ����"
,"             �����ς݃R�}���htree��S�č폜����B"
,"             tree�̂Ƃ��́A�����ς݃R�}���htree�݂̂��폜����B"
,"             no�̂Ƃ��́A���͗������no�s�ԍ��̍s���폜����B"
,"/tree        ���͗�����ɕۑ����ꂽ������R�}���htree�𐶐��������B"
,"/edit [no]   no�Ȃ��̂Ƃ��́A���O�̓��͍s��ҏW����B"
,"             no����̂Ƃ��́A���͗������no�s�ԍ��̍s��ҏW����B"
,"{/input |@[ ]}file_name [r]"
,"             �����t�@�C��������͂���Br����̂Ƃ��́A���͏I����̕������s����B"
,"//           ���͑���𒆎~����B"
,"/quit        �I������B"
,NULL
};
/*
	static tdtQUE_CTL *pQue=NULL,*pQueAuto=NULL;
	static int n1=10,n2=10,auto_mode=0,tree_mode=0,run_mode=0;
	static M_FILE *mfp=NULL;
	static tdtINFO_PARM tParm[3],*ppParm[3];
*/
	static tdtINFO_PARM tParm[3];
	static tdtInteract rr={0,10,10,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL};
	tdtInteract *prr;
	static char *sep=" @\n";
	char buff[128],work[128],*p,*argv[10],c,**he,cmds[BUFLEN],*pp,*buf;
	int rc,len,line_len,num,s_len,pos,argc,sp;
	SSP_S ssp;
	Leaf *leafTop,*leaf;
	condList *y;
	CLNCB *ys;
	ParList parl;

	y = pCLcList;
	ys = y->clstcb;
	if (!rr.init_flag) {
		rr.ppParm[0] = &tParm[0];
		rr.ppParm[1] = NULL;
		rr.ppParm[2] = &tParm[2];
		rr.init_flag = 1;
	}
	prr = &rr;
	if (!rr.pQue) rr.pQue = akxs_que_new(0,0);
	if (rr.auto_mode) {
		if (rr.mfp) {
			rc = _read_file(rr.ppParm,line,rr.auto_mode);
			if (rc > 0) {
				line_len = strlen(line);
				_add_src(prr,line,line_len);
				strcpy(line+line_len,"\n");
			}
			else if (rr.run_mode) {
				strcpy(line,"\n");
			}
		}
		else rc = _auto_mode(rr.pQueAuto,line,rr.auto_mode);
/*
printf("_editor:auto_mode: tree_mode=%d rc=%d line=[%s]\n",tree_mode,rc,line);
*/
		if (rc > 0) {
			rr.auto_mode++;
			return 0;
		}
		else {
			rr.mfp = NULL;
			rr.run_mode = rr.auto_mode = 0;
			if (!rr.tree_mode) return 0;
#if 1
		/* �����ɗ���Ƃ��́ACLSTCB.TopTreeSave�̓N���A����Ă���B
			if (leafTop = CLSTCB.TopTreeSave) {
				cl_leaf_clear(leafTop);
				CLSTCB.TopTreeSave = NULL;
			}
printf("_editor: TopTreeSave=%08x\n",leafTop);
		*/
			/* �����ł́A�܂��Alex()���甲���Ă��Ȃ����߁ACLSTCB.TopTree�ɓo�^���ꂽ�܂܂ŁA
			   leaf->leftleaf�ɓ����Ă��Ȃ����ACLSTCB.TopTreeSave�Ɉڂ���Ă����Ȃ��B
			   ���̂܂܁A"/"�����s�����CLSTCB.TopTree��2�d�ɓo�^����A���ʓI�ɁA
			   2�d�ɓo�^���ꂽ��Ԃ�CLSTCB.TopTreeSave�Ɉڂ����̂ŁA�����ŁA
			   CLSTCB.TopTree��CLSTCB.TopTreeSave�Ɉڂ��ACLSTCB.TopTree�𖢓o�^��Ԃɂ���B */
			if (leafTop = search_top_leaf(y)) {
/*
printf("_editor: TopTree=%08x\n",leafTop);
*/
				ys->TopTreeSave = leafTop;
				ys->TopStack = NULL;
			}
#endif
		}
	}
	rr.tree_mode = 0;
	for (;;) {
		printf("%s",y->fname);
#if 1
		if ((line_len=cl_getline(buff,sizeof(buff))) >= 0) {
		buf = buff;
#else
		if ((line_len=akxa_read_line_opt(buff,sizeof(buff),stdin,2)) >= 0) {
/*
akxaxdump("buf b",buf,line_len);
*/
			line_len = cl_str_conv_get(&buf,buff,line_len);
#endif
/*
akxaxdump("buf a",buf,line_len);
*/
			ssp.sp = 0;
			ssp.wd = work;
			if ((len=akxtgwse(buf,&ssp,sep,1)) > 0) {
				y->fname = ">";	/* prompt */
				if ((c=*work) == '/') {
					if (work[1] == '/') continue;
					pos = len + 1;
					sp = ssp.sp;
					argc = akxtgetargvn2(buf+sp,line_len-sp,argv,10,work+pos,sizeof(work)-pos,0x04);
					p = work + 1;
					if (!(c=toupper(*p)) || c=='T') {
						if (c == 'T') rr.tree_mode = 1;
						else rr.tree_mode = 0;
#if 1	/* 2023.11.4 */
						_leaf_clear(ys);
#else
						argv[0] = "tree";
						_del_src(NULL,1,argv);
#endif
						rr.auto_mode = 1;
						rr.pQueAuto = rr.pQue;
						akxs_que_move(rr.pQue,QUE_TOP,NULL);
						rc = _auto_mode(rr.pQue,line,rr.auto_mode);
/*
printf("_editor: work=[%s] auto_mode=%d tree_mode=%d rc=%d line=[%s]\n",work,auto_mode,tree_mode,rc,line);
*/
						if (rc > 0) {
							rr.auto_mode++;
							break;
						}
						else {
							rr.auto_mode = 0;
							if (!rr.tree_mode) break;
						}
					}
					else if (c=='L'/* || !stricmp(p,"list")*/) {
						_list_src(rr.pQue,argc,argv);
					}
					else if (c=='R'/* || !stricmp(work,"/renum")*/) {
						if ((num=atoi(argv[0])) > 0) rr.n1 = num;
						if ((num=atoi(argv[1])) > 0) rr.n2 = num;
						_renum_src(prr);
					}
					else if (c=='D'/* || !stricmp(work,"/del")*/) {
						if (_del_src(rr.pQue,argc,argv)) rr.pQue = akxs_que_new(0,0);
#if 1	/* 2023.11.4 */
						_leaf_clear(ys);
#endif
					}
					else if (c=='Q'/* || !stricmp(work,"/quit")*/) {
						argv[0] = "tree";
						_del_src(NULL,1,argv);
						rr.auto_mode = 1;
						rr.pQueAuto = NULL;
						rc = _auto_mode(NULL,line,rr.auto_mode);
						return 0;
					}
					else if (c=='H'/* || !stricmp(work,"/help")*/) {
						he = help;
						while (p = *he++) {
#if 1
							cl_puts(p);
#else
							strcpy(work,p);
							cl_str_conv_put(NULL,work,strlen(work));
							printf("%s\n",work);
#endif
						}
						putchar('\n');
					}
					else if (c=='E'/* || !stricmp(work,"/edit")*/) {
/*
printf("_editor: argc=%d argv[0]=[%s]\n",argc,argv[0]);
*/
						num = atoi(p=argv[0]);
#if 1	/* 2023.11.4 */
						rc = _get_src(rr.pQue,num,line,line_max);
						if (rc > 0) {
							len = strlen(line);
							num = rc;
#else
						if ((len=_get_src(rr.pQue,num,line,line_max)) > 0) {
#endif
							cl_str_conv_put(&p,line,len);
							printf("edit>%s\n",p);
						/*	if (p != line) Free(p);	*/
						/*	p = y->fname;
							y->fname = "edit>";	*//* prompt */
							printf("edit>");
							if ((line_len=akxa_read_line_opt(cmds,sizeof(cmds),stdin,2)) >= 0) {
								line_len = cl_str_conv_get(NULL,cmds,line_len);
								len = _edit_cmd(line,cmds);
#if 1	/* 2023.11.4 */
								if (num > 0) _ins_src(rr.pQue,num,line,len);
								else _add_src(prr,line,len);
#else
								_add_src(prr,line,len);
#endif
								strcpy(line+len,"\n");
								len++;
								cl_str_conv_put(&p,line,len);
								printf("%s",p);
							/*	if (p != line) Free(p);	*/
							/*	y->fname = p;	*/
								break;
							}
						/*	y->fname = p;	*/
						}
						else {
							printf("*** no number(%d) line.\n",num);
						}
					}
					else if (c=='I'/* || !stricmp(work,"/input")*/) {
						_set_input_file(buf,&ssp,line,prr);
						if (rr.auto_mode > 0) {
							break;
						}
					}
					else {
						printf("*** [%s] is no subcommand.\n",work);
					}
				}
				else if (c == '@') {
					_set_input_file(buf,&ssp,line,prr);
					if (rr.auto_mode > 0) {
						break;
					}
				}
				else {
					rc = akxcgcvn(work,len,&num);
					if (!rc || rc>1) {
						if (num <= 0) continue;
						rc--;
						if (rc > 0) {
							pos = ssp.sp - len + rc;
						}
						else {
							pos = ssp.sp + 1;
							if (akxtgwse(buf,&ssp," \n",1) <= 0) pos = line_len;
						}
						p = buf + pos;
						s_len = line_len - pos;
						rc = _ins_src(rr.pQue,num,p,s_len);
#if 1	/* 2023.11.4 */
/*
printf("_editor: rc=%d\n",rc);
*/
						if (rc > 0) {
							_leaf_clear(ys);
						}
#endif
					}
					else {
						p = buf;
						s_len = line_len;
						_add_src(prr,buf,line_len);
						memzcpy(line,p,s_len);
					/*	s_len = cl_str_conv_put(NULL,line,s_len);	*/
						strcpy(line+s_len,"\n");
						break;
					}
				}
			}
			else {
				strcpy(line,"\n");
				break;
			}
		}
	}
/*
printf("_editor: len=%d line=[%s]\n",len,line);
*/
#if 1
	if (leafTop = ys->TopTreeSave) {
		cl_leaf_clear(leafTop);
	}
	ys->TopTreeSave = NULL;
#endif
	return len;
}

/****************************************/
/* cl_process_interactive				*/
/****************************************/
int cl_process_interactive(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int len,rc,opt_in,dtype;
	int ret,ln;
	char *argv[2],*procPath;
	uchar *up;
	char buf[256];
	ScrPrCT *scrptct;
	Leaf tleaf,*leafTop;
	condList *y;
	CLNCB *ys;
	XHASHB *xha;

	if (!leaf || !proc) return ECL_SYSTEM_ERROR;
	if (!(scrptct=cl_search_src_ct())) return ECL_SYSTEM_ERROR;

	y = pCLcList;
	ys = y->clstcb;
	if (!(y->ConstCt=cl_const_ct_new())) {
		ERROROUT("Malloc ConstCt");
		return ECL_MALLOC_ERROR;
	}
#if 1
	y->fp = (FILE *)_editor;
	y->option |= D_SCRPT_FUNC;
#if 1	/* 2021.5.18 */
	dtype = akxt_get_code_type();
	if (opt_in = (cl_get_option(21,0)>>16) & 0x0f) dtype = opt_in;
	y->option |= D_CLST_OPT_USE_DTYPE | (dtype<<16);
#endif
#else
	y->fp = stdin;
#endif
	y->line = 0;
	y->fname = "coal>";	/* prompt */
	y->fullname = "stdin";
	memset(&tleaf,0,sizeof(Leaf));

#if 0	/* 2023.11.3 */
	if (!scrptct->ProcIndex2) {
		if (!(scrptct->ProcIndex2 = akxs_xhash_new2(0,10,7,sizeof(Leaf *)*2))) return -1;
	}
#endif
	if (!scrptct->ConstCt2) {
		if (!(scrptct->ConstCt2 = cl_const_ct_new())) {
			ERROROUT("Malloc ConstCt2");
			return ECL_MALLOC_ERROR;
		}
	}
	scrptct->sc_pFlag |= D_SCRPT_INTERACTIVE;
	rc = 0;
	for (;;) {
		ys->TopStack = NULL;
#if 1
		ys->TopTreeSave = leaf->leftleaf;
		leaf->leftleaf = NULL;
#else
		if (leaf->leftleaf) {
		/*	if (proc->Nextleaf == leaf->leftleaf) proc->Nextleaf = NULL;	*/
			cl_leaf_clear(leaf->leftleaf);
			leaf->leftleaf = NULL;
		}
#endif
	/*	printf("coal>");	*/
	/*	printf("Enter Command.\n");	*/
#if 1	/* 2023.11.3 */
		if (xha = scrptct->ProcIndex2) akxs_xhash_free(xha);
		if (!(scrptct->ProcIndex2 = akxs_xhash_new2(0,10,7,sizeof(Leaf *)*2))) return -1;
		len = cl_const_clear(scrptct->ConstCt2,0);
printf("cl_process_interactive: len=%d\n",len);
#endif
#if 1
		y->fname = "coal>";	/* prompt */
		if ((rc=cl_lex(y)) == -1) {
			printf("\n");
			break;
		}
		else if (!rc) {
			if (leafTop = search_top_leaf(y)) {
#if 1	/* 2023.11.3 */
				procPath = proc->ProcPath;
				argv[0] = procPath;
				ln = strlen(procPath);
				len = ln + 1;
				if (!(up=(uchar *)cl_intr_malloc(len+5))) return ECL_MALLOC_ERROR;
				up[0] = len;
				memcpy(up+1,procPath,ln);
				up[len] = '.';
				up[len+1] = 1;
				up[len+2] = 1;
				up[len+3] = ln;
				up[len+4] = '\0';
				argv[1] = (char *)up;
/*
printf("cl_set_func_body: up=%d [%s] %d %d %d\n",up[0],strname(up+1,ln+1),up[len+1],up[len+2],up[len+3]);
*/
				_set_node_path_sub(scrptct->ProcIndex2,leafTop,argv,NULL,D_OPT_ALC_INTRACT);
#endif
				cl_ret_leaf_push(proc,leaf);
				leaf->leftleaf = leafTop;
				proc->Nextleaf = leaf->leftleaf;
/*
printf("cl_process_interactive: leafTop=%08x leftleaf=%08x rightleaf=%08x\n",leafTop,leafTop->leftleaf,leafTop->rightleaf);
*/
			}
			else rc = -1;
		/*	ys->TopStack = NULL;	*/
			break;
		}
	}
#else
		if ((rc=cl_lex(y)) == -1) break;
		else {
			if (leafTop = search_top_leaf(y)) {
				rc = cl_node_process(leafTop,proc);
				if (!rc && cmn_chk_stat(SCR_ED,&pCLprocTable->ScrSt) != L_OFF) break;
				if (!pGlobTable->error && cmn_chk_stat(RTN_PR | RET_PR,&proc->ptype)!=L_OFF) break;
			}
		}
	}
	printf("\n");
#endif
	scrptct->sc_pFlag &= ~D_SCRPT_INTERACTIVE;
	y->option &= ~D_CLST_OPT_USE_DTYPE;
 	ys->TopStack = NULL;
	return rc;
}

/************************************/
/* cl_gx_ex_cmd						*/
/************************************/
int cl_gx_ex_cmd(pInfoParmW,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm2;
{
	MCAT mcat;
	tdtINFO_PARM *ppParm[1],tInfoParm;
	int rc,ret,flag,len,m;
	M_FILE *fpw, tmfp;
	tdtREDIRECT *red;
	char *p,*p1,*pp,c,*pszRet;
	ProcCT *proc;
	ConstantCt *pTmpConstCt0,*pTmpConstCt;
/*
printf("cl_gx_ex_cmd:Enter \n");
*/
	/*
	   !�Ŏn�܂�Ƃ��́Ashell()�Ŏ��s����
	*/
	if ((rc=parm_to_char_tmp(pInfoParm2,&p,0)) < 0) return rc;
	if (*p == '!') {
		rc--;
		if (*(p+rc) == M_KUGIRI) rc--;
/*
printf("cl_gx_ex_cmd: rc=%d\n",rc);
*/
		if ((rc=cl_sqlncnvt(p+1,rc,&pszRet,0x01)) < 0) return rc;
		p = pszRet;
		if (p1=cl_tmp_const_malloc(rc*2+9)) {
			memcpy(p1,"shell('",7);
			pp = p1 + 7;
			len = rc + 7;
			while (rc-- > 0 && (c = *p++)) {
				*pp++ = c;
				if (c == M_QUOTE1) {
					*pp++ = M_QUOTE1;
					len++;
				}
			}
			memcpy(pp,"');",4);
			len += 3;
/*
printf("cl_gx_ex_cmd: len=%d p1=[%s]\n",len,p1);
*/
		}
		pInfoParm2 = &tInfoParm;
		cl_set_parm_char(pInfoParm2,p1,len);
	}
	/*
	   �W���o�͂��������[�ɏo�͂���悤�ɐݒ肷��B
	*/
	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 128;
	proc = cl_search_proc_ct();
	red = proc->redirect;
	fpw = red->stdio[1];
/*
printf("cl_gx_ex_cmd: fpw=%08x\n",fpw);
*/
	memcpy(&tmfp,fpw,sizeof(M_FILE));
	flag = red->pFlag2;
	red->pFlag2 |= D_PFLAG2_STDOUT2MEM;
	fpw->m_mcat = &mcat;
/*
printf("cl_gx_ex_cmd: mcat=%08x\n",&mcat);
*/
	/*
	   �R�}���h�����s����B
	*/
	ppParm[0] = pInfoParm2;
	rc = cl_ex_ecmd(&ret,1,ppParm);
/*
printf("cl_gx_ex_cmd: rc=%d ret=%d\n",rc,ret);
*/
	/*
	   ���s���ʂ�ԋp����
	*/
	cl_set_parm_bin(pInfoParmW,ret);
	if (rc >= 0) {
		len = mcat.mc_ipos;
/*
printf("cl_gx_ex_cmd: mc_ipos=%d mc_bufp=[%s]\n",len,mcat.mc_bufp);
*/
		if (p = cl_tmp_const_malloc(len+1)) {
			memzcpy(p,mcat.mc_bufp,len);
#if 1	/* 2023.4.18 */
			if (cl_get_option(3,0) & 0x400) {
#else
			if (!(cl_get_option(3,0) & 0x400)) {
#endif
				m = akxnrskipin(p,len,"\r\n");
				if (m < len) {
					len = m;
					*(p+len) = '\0';
				}
			}
			cl_set_parm_char(pInfoParmW,p,len);
		}
		else rc = ECL_MALLOC_ERROR;
	}
	/*
	   �W���o�͂̐ݒ�𕜌�����B
	*/
	red->stdio[1] = fpw;
	memcpy(fpw,&tmfp,sizeof(M_FILE));
	red->pFlag2 = flag;
	if (p = mcat.mc_bufp) Free(p);
/*
printf("cl_gx_ex_cmd:Exit rc=%d\n",rc);
*/
	return rc;
}
