static char sccsid[]="%Z% %M% %I% %E% %U%";
#include "colmn.h"
/* */
extern ViewTBL  ViewTbl;
extern ItemTBL  ItemTbl;
extern ExtTBL   ExtTbl;
extern CatCondTBL   CatCondTbl;

extern CLPRTBL  CLprocTable;

extern tdtFrameInfo   FrameTbl;

extern int giItemSize;

extern int   ivElmts;
extern int   iiElmts;

extern char *szSummury[];
/* */
#define  D_VIEWTBL_MAX  26
#define  D_ITEMTBL_MAX  200

/* */
/********************************************/
/* ��������									*/
/*	 �r���[���̃e�[�u���쐬�֐�				*/
/*------------------------------------------*/
/********************************************/
/* */
int  cl_sl_tbl_mk_view(pFrameIf)
pFrameInfo  pFrameIf;
{

	static char cID = 'A';

	memset(&ViewTbl.Line[ivElmts],0,sizeof(ViewLine));

	if (ivElmts >= D_VIEWTBL_MAX) {
		ERROROUT("error table size over");
		return -1;
	}

	if (pFrameIf->iNode != 2) {
		ERROROUT("error node number");
		return -1;
	}

	if (pFrameIf->pDataTbl[1].len >
		sizeof(ViewTbl.Line[ivElmts].ViewName)-1) return -1;
	memcpy(ViewTbl.Line[ivElmts].ViewName,
			pFrameIf->pDataTbl[1].pData,
			pFrameIf->pDataTbl[1].len);
			/* pFrameIf->pDataTbl[0].pData, */
			/* pFrameIf->pDataTbl[0].len); */
/*
	ViewTbl.Line[ivElmts].ALIASNAME[0] = cID++;
*/
	ViewTbl.Line[ivElmts].ALIASNAME[0] = 'A'+ivElmts;
	ViewTbl.Line[ivElmts].ObjFlag      = 0;

	ivElmts++;

	return 0;
}
/********************************************/
/* ��������									*/
/*	 �������ڃe�[�u���쐬�֐�				*/
/*------------------------------------------*/
/********************************************/
/* */
int  cl_sl_tbl_mk_item_and_set_view(pFrameIf,iFrmNumber)
pFrameInfo  pFrameIf;
int  iFrmNumber;	/* >= 0 */
{
	char c,*dummy, *pC = NULL, buf[256];
	int iDispSq,w,rc,j,n,lw;
	SSP_S ssp;
	short sKind;

	if (iiElmts >= D_ITEMTBL_MAX) {
		ERROROUT("error table size over");
		return -1;
	}

	if (pFrameIf->iNode < D_KOUMOKU_SIZE) {
		ERROROUT("error node number");
		return -1;
	}

	ItemTbl.Line[iiElmts].ALIASNAME[0] = ViewTbl.Line[iFrmNumber].ALIASNAME[0];

	/* ���ږ� */
	if (pFrameIf->pDataTbl[0].len >sizeof(ItemTbl.Line[iiElmts].ItemName)-1)
#if 0
		return -1;
#else
		pFrameIf->pDataTbl[0].len=sizeof(ItemTbl.Line[iiElmts].ItemName)-1;
#endif
	memcpy(ItemTbl.Line[iiElmts].ItemName,
			pFrameIf->pDataTbl[0].pData,
			pFrameIf->pDataTbl[0].len);
	ItemTbl.Line[iiElmts].ItemName[pFrameIf->pDataTbl[0].len] = '\0';

	/* ���ڔԍ� */
	if (rc=axccvn(10,pFrameIf->pDataTbl[2].pData,pFrameIf->pDataTbl[2].len,
			  &ItemTbl.Line[iiElmts].ItemNumber)) return rc;

	/* ������ */
	if (pFrameIf->pDataTbl[3].len > sizeof(ItemTbl.Line[iiElmts].AttrName)-1)
		return -1;
	memcpy(ItemTbl.Line[iiElmts].AttrName,
			pFrameIf->pDataTbl[3].pData,
			pFrameIf->pDataTbl[3].len);
	ItemTbl.Line[iiElmts].AttrName[pFrameIf->pDataTbl[3].len] = '\0';

	/* �����f�[�^ */
	if (!(ItemTbl.Line[iiElmts].ConditionData=cl_tmp_const_malloc(pFrameIf->pDataTbl[4].len+1))) return rc;
	if (pFrameIf->pDataTbl[4].len > 0) {
		memcpy(ItemTbl.Line[iiElmts].ConditionData,
			pFrameIf->pDataTbl[4].pData,
			pFrameIf->pDataTbl[4].len);
		ViewTbl.Line[iFrmNumber].ObjFlag |= 1;
	}
	ItemTbl.Line[iiElmts].ConditionData[pFrameIf->pDataTbl[4].len]='\0';

	/* �\���� */
	ItemTbl.Line[iiElmts].DisplaySequence = 0;
	dummy = pFrameIf->pDataTbl[6].pData;
	w	 = pFrameIf->pDataTbl[6].len;
	sKind = 0;
	ssp.sp = 0;
	ssp.wd = buf;
	if (w>0) {
		lw = axtgwsp(dummy,&ssp);
		if (lw>0) {
/*
printf("slmktb.c:lw=%d wd=[%s]\n",lw,ssp.wd);
*/
			if (!stricmp(buf,"max")) sKind = 1;
			else if (!stricmp(buf,"min")) sKind = 2;
			else if (!stricmp(buf,"sum")) sKind = 3;
			else if (!stricmp(buf,"count")) sKind = 4;
			ItemTbl.Line[iiElmts].SummuryKind = sKind;
		}
		if (sKind) ItemTbl.Line[iiElmts].DisplaySequence = 1;
		else ssp.sp = 0;
	}
	for (j=ssp.sp;j<w;j++) {
		if (dummy[j] == '/') break;
	}
	rc=axccvn(10,dummy+ssp.sp,j-ssp.sp,&iDispSq);
/*
printf("slmktb.c:rc=%d\n",rc);
*/
	if (rc>0 || (rc < -1)) return -1;
	if (iDispSq) ItemTbl.Line[iiElmts].DisplaySequence = iDispSq;
	ItemTbl.Line[iiElmts].OrderType = ' ';
	ItemTbl.Line[iiElmts].OrderNumber = 0;
	for (++j;j<w;j++) {
/*
printf("slmktb.c:c=%c\n",dummy[j]);
*/
		if ((c=toupper(dummy[j])) == ' ' || c=='\t' || c=='n');
		else if (c == 'A' || c == 'D') {
			ItemTbl.Line[iiElmts].OrderType = c;
			j++;
			rc=axccvn(10,&dummy[j],w-j,&n);
			if (!rc) {
				if (n<1) return -1;
				ItemTbl.Line[iiElmts].OrderNumber = n;
			}
			else if (rc == -1) ItemTbl.Line[iiElmts].OrderNumber = 1;
			else return -1;
			break;
		}
		else {
			rc=axccvn(10,&dummy[j],w-j,&n);
			if (!rc) {
				if (n<1) return -1;
				ItemTbl.Line[iiElmts].OrderNumber = n;
				ItemTbl.Line[iiElmts].OrderType = 'A';
			}
			else if (rc>0 || (rc < -1)) return -1;
			break;
		}
	}
/*
printf("slmktb.c:Order = %c %d\n",ItemTbl.Line[iiElmts].OrderType,
ItemTbl.Line[iiElmts].OrderNumber);
*/
	iDispSq = ItemTbl.Line[iiElmts].DisplaySequence;
	if (iDispSq || ItemTbl.Line[iiElmts].OrderNumber > 0) {
   		ViewTbl.Line[iFrmNumber].ObjFlag |= 2;
	}

	/* �\������ */
	rc = axccvn(10,pFrameIf->pDataTbl[8].pData,pFrameIf->pDataTbl[8].len,&w);
	if (rc>0 || (rc < -1)) return -1;
	if (iDispSq && w<2) {
		w = pFrameIf->pDataTbl[0].len;
		if (sKind == 4) w = strlen(szSummury[sKind]); /* count */
		else if (sKind) w += strlen(szSummury[sKind]);
		if (w<2) w = 10;
	}
	ItemTbl.Line[iiElmts].DisplayDigit = w;

/*	if (pFrameIf->pDataTbl[4].len>0 || iDispSq>0) */
		iiElmts++;

	giItemSize = iiElmts;

	return 0;
}
/********************************************/
/* ��������									*/
/*	 �������ݒ�֐�							*/
/*------------------------------------------*/
/********************************************/
/* */
int   cl_sl_tbl_set_condition(pFrameIf)
	pFrameInfo  pFrameIf  ;
{
	int   iElmts, rc;
	ViewLine vw;

	memset(&vw,0,sizeof(ViewLine));
	memcpy(vw.ViewName,pFrameIf->pDataTbl[1].pData,pFrameIf->pDataTbl[1].len);

	for (iElmts=0;iElmts<ivElmts;iElmts++) {
		if (!strcmp(ViewTbl.Line[iElmts].ViewName,vw.ViewName)) {
			if (!(ViewTbl.Line[iElmts].ColSelCondition=cl_tmp_const_malloc(pFrameIf->pDataTbl[2].len+1)))return -1;
			if (pFrameIf->pDataTbl[2].len > 0) {
				memcpy(ViewTbl.Line[iElmts].ColSelCondition,
						pFrameIf->pDataTbl[2].pData,
						pFrameIf->pDataTbl[2].len);
				ViewTbl.Line[iElmts].ObjFlag |= 4;
			}
			ViewTbl.Line[iElmts].ColSelCondition[pFrameIf->pDataTbl[2].len] = '\0';
			return iElmts;
		}
	}
	ERROROUT("cl_sl_tbl_set_condition:not found view name");
	return -1;
}

/********************************************/
/* ��������									*/
/*	 �e�[�u���쐬�֐�						*/
/*------------------------------------------*/
/********************************************/
/* */
int cl_sl_mk_extr()
{
	int  i,j;
	void shellsort();
	int  iDisplay, nDisplay=0, nSummury=0;

	/* �\�[�g�Ώۃf�[�^�̕��� */
	for (i=j=0;i<giItemSize;i++) {
		if (iDisplay = ItemTbl.Line[i].DisplaySequence) nDisplay++;
		if (ItemTbl.Line[i].SummuryKind) nSummury++;
		if (iDisplay > 0 || ItemTbl.Line[i].OrderNumber > 0) {
			memcpy(&ExtTbl.Line[j],&ItemTbl.Line[i],sizeof(ItemLine));
			j++;
		}
	}
	ExtTbl.iItemNum = j;

	if (nDisplay==0) {
		ERROROUT("No Select Items");
		return -1;
	}
	if (nSummury>0 && nSummury!=nDisplay) {
		ERROROUT(FORMAT(523));	/* �W��ƍ��ڂ����݂��Ă��� */
		return -1;
	}

	/* �\�[�g */
	shellsort(&ExtTbl.Line[0],j);


	return 0;
}
/********************************************/
/* ��������									*/
/*	 �\�[�g�֐�								*/
/*------------------------------------------*/
/********************************************/
/* */
void shellsort(p, size)
ItemLine p[];
int  size;
{
	int i,j,gap;
	int	s1,s2;
	ItemLine tmp;

	for (gap=size/2;gap>0;gap/=2) {
		for (i=gap;i<size;i++) {
			for (j=i-gap;j>= 0;j-=gap) {
				s1 = p[j].DisplaySequence;
				s2 = p[j+gap].DisplaySequence;
				if (s1 <= s2) break;
				memcpy(&tmp,&p[j+gap],sizeof(ItemLine));
				memcpy(&p[j+gap],&p[j],sizeof(ItemLine));
				memcpy(&p[j],&tmp,sizeof(ItemLine));
			}
		}
	}
}
