static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************************************/
/*   input : input function                                              */
/*           this function enable you to get parameters from packets     */
/*************************************************************************/

#include "colmn.h"

extern CLPRTBL   *pCLprocTable;
extern GlobalCt  *pGlobTable;

int input()
{
	int parmlen;
	int rc,iSel;
	tdtFrameInfo	FrameTbl;
	ProcCT *pPrCT;
	char   *parmtop,*p,buf[3];
	tdtINFO_PARM InfoParm;
	ScrPrCT *pScCT;
	ONTBL   *pOntbl;
/*
puts("input:Hit any key!");
getchar();
*/
	rc = 0;
	pScCT = cl_search_src_ct();
	pPrCT = cl_search_proc_ct();
	if (pGlobTable->error != 0)	{
		cmn_set_stat(RET_PR,&pPrCT->ptype,L_ON);
		return (0);
	}
	parmtop = pPrCT->INPCB.curaddr;
	parmlen = pPrCT->INPCB.curlen;

	while(parmlen < pPrCT->INPCB.maxlen) {
		parmtop = pPrCT->INPCB.curaddr;
		parmlen = pPrCT->INPCB.curlen;
		if ((rc = cmn_read_field_frame(parmtop,&FrameTbl)) < 0) {
			ERROROUT("input Read Field Frame process error.");
			return (rc);
		}
/*
printf("input:parmlen=%d len=%d ",parmlen,rc);
*/
		parmlen += rc;
		p = FrameTbl.szFrameID;
		memcpy(buf,p,2);
		buf[2] = '\0';
/*
printf("frame id=[%s]\n",buf);
*/
		if(memcmp(p,"GR",2)) {
			pPrCT->INPCB.curaddr = (char *)pPrCT->INPCB.parmtop + parmlen;
			pPrCT->INPCB.curlen = parmlen;
		}
		if (!memcmp(p,"FM",2))
			;
		else if(!memcmp(p,"GR",2)) {
			rc = cl_input_gr(&FrameTbl,parmlen);
			cmn_read_fld_free( &FrameTbl );
			if (rc != NormalEnd) {
				ERROROUT("input GR process error.");
				return(rc);
			}
			if (cmn_chk_stat(RTN_PR,&pCLprocTable->PrSt) != L_OFF) return(rc);
		}
		else if(!memcmp(p,"DT",2)) {
			rc = cl_input_dt(&FrameTbl);
			cmn_read_fld_free( &FrameTbl );
			if (rc != NormalEnd) {
				ERROROUT("input DT process error.");
				return(rc);
			}
			if (cmn_chk_stat(RTN_PR,&pCLprocTable->PrSt) != L_OFF) return(rc);
		}
		else {
			memcpy(buf,p,2);
			buf[2] = '\0';
			ERROROUT1("input:invalid frame id=[%s]",buf);
akxaxdump("INPCB",pPrCT->INPCB.parmtop,pPrCT->INPCB.maxlen);
			return ECL_SYSTEM_ERROR;
		}
		if (cmn_chk_stat(RET_PR,&pPrCT->ptype)) return (rc);
		if (pGlobTable->error != 0) {
			cmn_set_stat(RET_PR,&pPrCT->ptype,L_ON);
			return (0);
		}
	}
	if (pScCT->OnSelect >= 0) {
		pOntbl = pScCT->ONCOND[pScCT->OnSelect];
		if (*(p=pOntbl->PrName[2])) {
			if (rc=cl_input_exec_proc(pOntbl->PrSel[2],p)) return rc;
			*p = '\0';
			if (rc || (cmn_chk_stat(RTN_PR,&pCLprocTable->PrSt) != L_OFF))
				return rc;
		}
	}
	cmn_set_stat(RET_PR,&pPrCT->ptype,L_ON);
	return(rc);
}

/***************************************************************************/
/* cl_input_prep.c                                                         */
/* this program is preprocessor for input process.                         */
/***************************************************************************/
int cl_input_prep(pInfoParm)
tdtINFO_PARM *pInfoParm;
{
	ProcCT *pPrCT;
	ScrPrCT *pScCT;

	if (pInfoParm == NULL) return(ECL_SYSTEM_ERROR);

	if (!(pScCT = cl_search_src_ct())) return ECL_SYS_SCCT_NULL;
	if (!(pPrCT = cl_search_proc_ct())) return ECL_SYS_PRCT_NULL;
	pScCT->OnSelect =  -1;
	if (!(pPrCT->INPCB.parmtop=Malloc(pInfoParm->pi_dlen+1)))
		return ECL_MALLOC_ERROR;
	memcpy(pPrCT->INPCB.parmtop,pInfoParm->pi_data,pInfoParm->pi_dlen);
	*(pPrCT->INPCB.parmtop+pInfoParm->pi_dlen) = '\0';
	pPrCT->INPCB.maxlen  = pInfoParm->pi_dlen;
	pPrCT->INPCB.curlen  = 0;
	pPrCT->INPCB.curaddr = pPrCT->INPCB.parmtop;
	pGlobTable->error = 0;	/* 11.5 add Koba */
	return( NORMAL );
}

/***************************************************************************/
/*	cl_input_exec_proc.c*/
/*	execute proc for input process.*/
/***************************************************************************/
int cl_input_exec_proc(iSel,pPrName)
int   iSel;
char *pPrName;
{
	int rc;

	if (iSel == D_PRSEL_IP) {
		rc = cl_exec_proc_name(pPrName);
	}
	else {
		/* Sel=%d �h�o�ȊO�́A���s�ł��܂���B */
		ERROROUT1(FORMAT(391),iSel);
		rc = ECL_EX_INPUT;
	}
	return rc;
}
