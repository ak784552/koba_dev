static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clprproc.c>                                                     */
/*      Proc process   �@�@�@                          */
/*                                            (1992/01/10 Ver 0.01) */
/********************************************************************/

#include "colmn.h"

/************************************/
/* _chk_var_name                    */
/************************************/
static int _chk_var_name(name,len)
char *name;
int len;
{
	return cl_def_chk_name(name,len,"cl_process_proc","�ϐ���");
}

/************************************/
/*  _ProcClearVar					*/
/************************************/
static int _proc_clear_var(proc)
ProcCT  *proc;
{
	int scope;
	ScrPrCT *scrct;
	Leaf *topleaf;

	if (!(scrct=cl_search_src_ct())) return 0;
/*
printf("_proc_clear_var: varnam=[%s]\n",varnam);
*/
	scope = D_AUX1_GLOBAL_VAR | D_AUX1_PRIVATE_VAR | D_AUX1_LOCAL_VAR;
	topleaf = proc->ProcTop->leftleaf;
	return cl_gx_clear_var_obj(topleaf,NULL,NULL,proc->Obj,scope);
}

/************************************/
/* cl_process_proc                    */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_proc(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	static char *_fn_="cl_process_proc";
	static char *sep=" \t,()";
	static char *attr_sep=" \t()[],'=";
	int   rc,nparm,len,atr0,atr,per_flg,ipa,ix,*pSize,max_pas,iMAIN,iParm[4];
	int   sp_save,is,kk_level,lenw,line_len,iSET,atr1;
	parmList *prmp[4],qprmp[4],**cmd_prmp,*parmp;
	char  buf[512],w[16],*name,wrk[256],c,*pp,*line,c0;
	Leaf  wleaf;
	GWPRM_S gwprm;
	SSPL_S ssp;
	tdtINFO_PARM	*pInfoParmC,*pInfoParmW,tInfoParm;
	tdtINFO_PARM   ***tbl_pas,***tbl_vnm;
	GXObject *pbxObj;
	XHASHB *pha_vnm;
	tdtArrayIndex *pIndex;
	int i,npr,npa,inpa,ida,iob,obj[100];
	char *da[20];
	CMDObject *cmdobj;

	if (!leaf || !proc) return ECL_SYSTEM_ERROR;

	if (proc->ProcTop != leaf) {
		proc->Nextleaf = leaf->rightleaf;
		return 0;
	}

#ifdef CMDOBJECT
	cmdobj = leaf->cmd.cmdobj;
	cmdobj->cid = leaf->cmd.cid;
#endif

	if (!(proc->Nextleaf=leaf->leftleaf)) {
		if (leaf->cmd.cid == C_PROC) name = "�葱��";
		else name = "�֐�";
		ERROROUT1(FORMAT(541),name);
		return ECL_SCRIPT_ERROR;
	}

	if (rc=cl_mk_pr_var_set(proc)) return rc;

	pha_vnm = proc->pha_vnam;
	tbl_vnm = proc->pTBL_vnam;

	nparm = leaf->cmd.prmnum;
	cmd_prmp = leaf->cmd.prmp;
	iMAIN = 0;
	if (leaf->cmd.cid == C_FUNCTION) {
		pInfoParmC = proc->Retval;
		if (pInfoParmC->pi_paux) {
			if ((ix=cl_gx_chk_vnam('s',pha_vnm,"My",2)) <= 0) {
				ERROROUT2(FORMAT(542),"My",ix);
				return ECL_SCRIPT_ERROR;
			}
			pInfoParmW = cl_get_var_ent(tbl_vnm,ix);
			if (cl_gx_rep_info_set(pInfoParmW,pInfoParmC->pi_paux,1)) return -1;
DEBUGOUT_InfoParm(194,"cl_process_proc: name=%s",pInfoParmW,"My",0);
		}
	}
	else if (!strcmp(proc->ProcNM,"main")) {
		if (rc=cl_prparmset(/*NULL,*/NULL,proc->ProcNM)) return rc;
		iMAIN = 1;
#ifdef CMDOBJECT
		cmdobj->opt = iMAIN;
#endif
	}
#ifdef CMDOBJECT
	cmdobj->opt |= 0x80000000;
#endif

	parmp = cmd_prmp[0];
	if (pbxObj=parmp->bxobj) {
		if (pbxObj->da) proc->ProcPath = pbxObj->da[0];
	}

	if (nparm <= 1) return 0;

	max_pas = proc->varnam_pasento;
	tbl_pas = proc->pTBL_pasento;
	pSize = (int *)tbl_pas[0];

#ifdef CMDOBJECT
	npr = npa = 0;
	da[0] = clstrdup(proc->ProcNM,0);
	obj[0] = 0;
	ida = 1;
	obj[1] = 0;
	iob = 2;
#endif
	line = cmd_prmp[1]->prp;
	line_len = cmd_prmp[1]->prmlen;
	memset(&ssp,0,sizeof(SSPL_S));
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	rc = 0;
	pInfoParmW = NULL;
	c = ',';
	per_flg = ipa = kk_level = is = atr1 = 0;
	while ((len=akxtgwnsl(line,line_len,&ssp,sep,0x1)) > 0) {
		c0 = c;
		atr = ssp.attr[0];
		c = *wrk;
/*
printf("cl_process_proc: c0=%c sp=%d atr=%d wrk=[%s]\n",c0,ssp.sp,atr,wrk);
printf("                 per_flg=%d kk_level=%d is=%d atr1=%d\n",per_flg,kk_level,is,atr1);
*/
		if (per_flg == 1) {
			if (c == '(') kk_level++;
			else if (c==',' || c == ')') {
				iSET = 0;
				if (c == ')') {
					if (--kk_level < 0) break;
					else if (!kk_level) {
						per_flg = 2;
						if (atr1) iSET = 1;
						else ipa++;
#ifdef CMDOBJECT
	if (npa) {
		obj[inpa] = npa;
		npr++;
	}
	else iob -= 2;
#endif
					}
				}
				else {	/* ',' */
					if (kk_level == 1) {
						if (atr1) iSET = 1;
						else {
							ipa++;
							is = ssp.sp;
						}
					}
				}
				if (iSET) {
					atr1 = 0;
					ipa++;
/*
printf("cl_process_proc: set parm. ipa=%d\n",ipa);
*/
					if (ipa<=max_pas || iMAIN) {
						sp_save = ssp.sp;
						lenw = ssp.sp -is - 1;
						pp = line + is;
						ssp.sp = 0;
						if (rc=cl_get_def_attr_SSP_opt(pp,lenw,&ssp,attr_sep,iParm,0x05)) return rc;
/*
printf("cl_process_proc:get_def_attr: sp=%d wrk=[%s]\n",ssp.sp,wrk);
*/
						if (!iParm[0]) ssp.sp = 0;
						if ((len=akxtgwnsl(pp,lenw,&ssp,sep,0x1)) <= 0) {
							ERROROUT1(FORMAT(543),_fn_);
							return ECL_SCRIPT_ERROR;
						}
/*
printf("cl_process_proc:akxtgwnsl: sp=%d wrk=[%s]\n",ssp.sp,wrk);
*/
#ifdef CMDOBJECT
						npa++;
						obj[iob++] = ipa;
						obj[iob++] = ida;
						da[ida++] = clstrdup(wrk,0);
#endif
						if (rc=_chk_var_name(wrk,len)) return rc;
						if ((ix=cl_gx_chk_vnam('s',pha_vnm,wrk,len)) <= 0) {
							ERROROUT2(FORMAT(544),
							          wrk,ix);
							return ECL_SCRIPT_ERROR;
						}
						if (akxtgwnsl(pp,lenw,&ssp,sep,0x1) > 0) {
							if (iParm[0] || stricmp(wrk,"AS")) {
								ERROROUT2(FORMAT(545),_fn_,wrk);
								return ECL_SCRIPT_ERROR;
							}
							if (rc=cl_get_def_attr_SSP_opt(pp,lenw,&ssp,attr_sep,iParm,0x09)) return rc;
							if (clpeeksl(pp,lenw,&ssp,sep,0x1) > 0) {
								ERROROUT2(FORMAT(546),_fn_,wrk);
								return ECL_SCRIPT_ERROR;
							}
						}
						pInfoParmW = cl_get_var_ent(tbl_vnm,ix);
						if (cl_is_undef_parm(pInfoParmW)) cl_null_data(pInfoParmW);
						if (iParm[0] && iParm[0]!=DEF_ZOK_VARI) {
							if (rc=cl_set_parm_init(pInfoParmW,iParm,0x01)) {
								/* %s: �ԋp�l�̑����w�肪�s���ł��B */
								ERROROUT1(FORMAT(499),_fn_);
								return ECL_SCRIPT_ERROR;
							}
						}
						pInfoParmC = cl_get_var_ent(tbl_pas,ipa);
DEBUGOUT_InfoParm(194,"cl_process_proc:C: ipa=%d",pInfoParmC,ipa,0);
						if (cl_gx_rep_info_set(pInfoParmW,pInfoParmC,1)) {
							return ECL_SCRIPT_ERROR;
						}
DEBUGOUT_InfoParm(194,"cl_process_proc:W: name=%s",pInfoParmW,wrk,0);
						ssp.sp = sp_save;
						is = ssp.sp;
#ifdef CMDOBJECT
						memcpy(&obj[iob],iParm,sizeof(int)*4);
						iob += 4;
#endif
					}
					else {
						ERROROUT1(FORMAT(547),_fn_);
						return ECL_SCRIPT_ERROR;
					}
				}
			}
			else {
				if (kk_level>1 && !stricmp(wrk,"AS")) {
					ERROROUT1(FORMAT(548),_fn_);
					return ECL_SCRIPT_ERROR;
				}
				atr1 = 1;
			}
		}
		else {
			if (!stricmp(wrk,"AS")) {
				if (leaf->cmd.cid == C_FUNCTION) {
					pInfoParmC = proc->Retval;
					if (rc=cl_get_def_attr_SSP_opt(line,line_len,&ssp,attr_sep,iParm,0x09)) return rc;
					if (iParm[0] != DEF_ZOK_VARI) {
						if (rc=cl_set_parm_init(pInfoParmC,iParm,D_GX_OPT_ALC_TMP | 0x01)) {
							/* %s: �ԋp�l�̑����w�肪�s���ł��B */
							ERROROUT1(FORMAT(499),_fn_);
							return ECL_SCRIPT_ERROR;
						}
					}
					per_flg = 3;
#ifdef CMDOBJECT
					npr++;
					obj[iob++] = 4;
					memcpy(&obj[iob],iParm,sizeof(int)*4);
					iob += 4;
#endif
				}
				else {
					ERROROUT1(FORMAT(549),_fn_);
					return ECL_SCRIPT_ERROR;
				}
			}
			else {
				if (per_flg == 2) {
					ERROROUT2(FORMAT(550),_fn_,wrk);
					return ECL_SCRIPT_ERROR;
				}
				else if (per_flg == 3) {
					ERROROUT2(FORMAT(551),_fn_,wrk);
					return ECL_SCRIPT_ERROR;
				}
				else if (atr <= 6) {
					ipa++;
					if (ipa <= 2) {
						if (rc=_chk_var_name(wrk,len)) return rc;
					}
					else {
						ERROROUT2(FORMAT(552),_fn_,wrk);
						return ECL_SCRIPT_ERROR;
					}
					if (ipa == 1) {
						sprintf(buf,"%s = %d",wrk,max_pas);
/*
printf("cl_process_proc: ipa=%d buf=[%s]\n",ipa,buf);
*/
						if (rc=cl_set_scalar_var_info(buf,NULL,
						        D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_CONST,&pInfoParmW)) break;
						pInfoParmC = cl_var_size_parm(pSize);
						*pInfoParmW = *pInfoParmC;
						pInfoParmW->pi_scale &= ~D_DATA_LPOSDATA;
						pInfoParmW->pi_aux[0] = pInfoParmW->pi_attr;
						pInfoParmW->pi_aux[1]|= D_AUX1_PROTECTED;
						pInfoParmW->pi_paux    = pInfoParmW->pi_data;
#ifdef CMDOBJECT
						npr++;
						obj[iob++] = 1;
						obj[iob++] = ida;
						da[ida++] = clstrdup(wrk,0);
#endif
					}
					else if (ipa == 2) {
						if (!(ix=max_pas) || iMAIN) ix = pSize[2];
					/*	sprintf(buf,"%%%s 1 %d",wrk,max_pas);	*/
						sprintf(buf,"%%%s 1 %d",wrk,ix);
						memset(&qprmp[0],0,sizeof(parmList)*2);
						qprmp[1].prmlen = strlen(buf);
						qprmp[1].prp = buf;
						qprmp[1].opt = D_GX_OPT_NO_USE_OBJ;
						prmp[1] = &qprmp[1];
/*
printf("cl_process_proc: ipa=%d buf=[%s]\n",ipa,buf);
*/
						if (rc=cl_pr_ex_def_map_ary(2,prmp,NULL,proc,D_GX_OPT_SET_LOCAL)) break;
						if (!max_pas && !iMAIN) {
							strcpy(buf+1,wrk);
							qprmp[1].prmlen = strlen(buf);
							if (rc=cl_conv_parm_opt(&qprmp[1],&tInfoParm,D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_ADDR)) break;
							if (tInfoParm.pi_id == D_DATA_ID_STOREVAR) {
								pInfoParmW = (tdtINFO_PARM *)tInfoParm.pi_pos;
								if (pInfoParmW->pi_id=='A' && pInfoParmW->pi_dlen==sizeof(tdtArrayIndex)) {
									pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
									pIndex->index[1] = 0;
								}
							}
						}
#ifdef CMDOBJECT
						npr++;
						obj[iob++] = 2;
						obj[iob++] = ida;
						da[ida++] = clstrdup(wrk,0);
#endif
					}
				}
				else {
					if (c=='(') {
						per_flg = kk_level = 1;
						ipa = 0;
						is = ssp.sp;
#ifdef CMDOBJECT
						obj[iob++] = 3;
						inpa = iob++;
#endif
					}
					else if (c==')') {
						if (--kk_level < 0) break;
					}
					else if (c==',' && c0==',') ipa++;
				}
			}
		}
		atr0 = atr;
	}
	if (!rc && kk_level) {
		ERROROUT2(FORMAT(553),_fn_,kk_level);
		rc = ECL_SCRIPT_ERROR;
	}
#ifdef CMDOBJECT
	obj[1] = npr;
	cmdobj->da = (char **)cl_opt_malloc(0,sizeof(int)*iob+sizeof(char *)*ida);
	cmdobj->exobj = (int *)(cmdobj->da + ida);
	memcpy(cmdobj->da,da,sizeof(char *)*ida);
	memcpy(cmdobj->exobj,obj,sizeof(int)*iob);
	for (i=0;i<iob;i++) printf("obj[%2d]=%d\n",i,obj[i]);
	for (i=0;i<ida;i++) printf("da[%2d]=[%s]\n",i,da[i]);
#endif
	return rc;
}

/************************************/
/* cl_process_end_proc              */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_end_proc(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	char *name;

	if (leaf == NULL) return(ECL_SYSTEM_ERROR);
	if (proc == NULL) return(ECL_SYSTEM_ERROR);

	if (leaf->cmd.cid == C_ENDPROC) name = "�d�m�c�o�q�n�b";
	else name = "�d�m�c�e�t�m�b";
	ERROROUT1(FORMAT(554),name);
	cmn_set_stat(RET_PR,&proc->ptype,L_ON);
	return 0;
}
