char version[] ="@(#) ***[V/R=7.4.1 (dev1)]***";

