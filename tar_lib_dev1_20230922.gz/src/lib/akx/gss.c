/*****************************************************************************
*
******************************************************************************/
int _gssset(file,block,pKeyInfos,opti)
char *file,*block;
tdtKEY_INFOS *pKeyInfos;
int opti;
{
	char buf[D_RECORD_BUFSIZE],*argv[D_RECORD_BUFSIZE/2],
	     parm[D_RECORD_BUFSIZE],**p;
	int  i,opt,n,pret[2],ret,nk;
	FILE *fp;
	tdtKEY_INFO **pKeyInfo;

	pKeyInfos->nkey = nk = 0;
	opt = opti | 0x01;
	fp = akxa_gs_fopen(file,block,argv,0,parm,0,
	                 opt | AKX_GSFOPEN_NO_CACHE,pret);
	if (!fp) {
		ERROROUT1("_gssset: akxa_gs_fopen: error=%d",pret[0]);
		return pret[0];
	}
	ret = 0;
	pKeyInfo = pKeyInfos->pkeyinfo;
	while (akxa_read_line_opt(buf,sizeof(buf),fp,0x02) && *buf!='[') {
		if (*buf == '#') continue;
		if ((n=akxtgetargv2(buf,argv,D_RECORD_BUFSIZE/2,
		                    parm,sizeof(parm),opt))<0) {
			ERROROUT2("akxtGSS:akxtgetargv error=%d line=[%s]",n,buf);
			ret = n;
			break;
		}
		else if (n > 0) {
			p = (char **)Malloc(sizeof(char *)*n);
			pKeyInfo[nk]->argc = n;
			pKeyInfo[nk]->argv = p;
			nk++;
			for (i=0;i<n;i++) {
				p[i] = Strdup(argv[i]);
			}
			if (nk >= pKeyInfos->maxkey) break;
		}
	}
	pKeyInfos->nkey = nk;
	fclose(fp);
	return ret;
}
