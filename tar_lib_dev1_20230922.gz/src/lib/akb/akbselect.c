static	char	sccsid[]="%Z% %M% %I% %E% %U%";
#include	"akbcommon.h"
/*
static qSelectCtl = {0,0,0,0};
*/
static int iNWselect = 0;
static int iWQsuspend = 0;
static int iRbWUsed = 0;

/************************************/
/*                                  */
/************************************/
int akb_set_nwselect(i)
int i;
{
	return iNWselect = i;
}

/************************************/
/*                                  */
/************************************/
int akb_get_nwselect()
{
	return iNWselect;
}

/************************************/
/*                                  */
/************************************/
int akb_set_wqsuspend(i)
int i;
{
	return iWQsuspend = i;
}

/************************************/
/*                                  */
/************************************/
int akb_get_wqsuspend()
{
	return iWQsuspend;
}

/************************************/
/*                                  */
/************************************/
int akb_set_rb_wused(i)
int i;
{
	return iRbWUsed = i;
}

/************************************/
/*                                  */
/************************************/
int akb_get_rb_wused(i)
int i;
{
	return iRbWUsed;
}

/************************************/
/*                                  */
/************************************/
int akb_nwselect_increment()
{
#if 1
	if (iNWselect <= 0) iNWselect = 1;
	else {
#if 0
		iNWselect *= 2;
#else
		if (iNWselect <= 1) iNWselect *= 2;
#if 1
		else iNWselect *= 4;
#else
		else if (iNWselect <= 2) iNWselect *= 4;
		else iNWselect *= 8;
#endif
#endif
	}
#else
	if (iNWselect <= 0) iNWselect = 1;
	else iNWselect++;
#endif
	return iNWselect;
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_nwselect_wait_time(ptval)
struct timeval *ptval;
{
	int msec;

	if ((msec=iNWselect*AKB_NWSELECT_WAIT) > AKB_NWSELECT_WAIT_MAX) {
		msec = AKB_NWSELECT_WAIT_MAX;
		iNWselect = AKB_NWSELECT_WAIT_MAX/AKB_NWSELECT_WAIT;
	}
	if (ptval) akxe_timer_set_msec(ptval,msec);
	return msec;
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_get_select_wait_time(iWaitTime,pRbRCtl,pRbWCtl,ptval)
int iWaitTime;
tdtRB_CTL *pRbRCtl,*pRbWCtl;
struct timeval *ptval;
{
	int i,msec;
	struct timeval tval;

	msec = 0;
	tval.tv_sec  = 0;
	tval.tv_usec = 0;
	if (iWaitTime) {
		if (akxs_rb_get(pRbRCtl)) {
			tval.tv_usec = 1000;
			if (iNWselect > 1) iNWselect /= 2;
		}
		else if (iNWselect) {
			if (iWQsuspend) i = 1;
			else if (iRbWUsed || akxs_rb_get(pRbWCtl)) i = 3;
			else tval.tv_sec = -1;
			if (tval.tv_sec >= 0) {
				msec = akb_nwselect_wait_time(&tval);
				tval.tv_usec += i;
			}
		}
		else {
			if (iWQsuspend) tval.tv_usec = 1001;
			else if (iRbWUsed || akxs_rb_get(pRbWCtl))
				tval.tv_usec = 1003;
			else tval.tv_sec = -1;
			if (tval.tv_sec >= 0) msec = tval.tv_usec/1000;
		}

if (msec >= 50) {
	DEBUGOUTL2(AKB_LOG_GROUP|255,
		"akb_get_select_wait_time: iNWselect=%d iWQsuspend=%d",
		iNWselect,iWQsuspend);
	DEBUGOUTL3(AKB_LOG_GROUP|255,
		"akb_get_select_wait_time: iWaitTime=%d tv_sec=%d tv_usec=%d",
		iWaitTime,tval.tv_sec,tval.tv_usec);
}

		if (iWaitTime < 0) {
			if (tval.tv_sec < 0) msec = -1;
		}
		else {
			if ((tval.tv_sec < 0) || (msec > iWaitTime)) {
				msec = akxe_timer_set_msec(&tval,iWaitTime);
			}
		}
	}
	ptval->tv_sec  = tval.tv_sec;
	ptval->tv_usec = tval.tv_usec;
	return msec;
}
