static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************************************************/
/*  �֐���                                                                   */
/*        pSD_PACKET_TABLE   akbs_make_xpacket()                                 */
/*                                                                           */
/*  ������                                                                   */
/*                                                                           */
/*                                                                           */
/*  �߂�l                                                                   */
/*        pSD_PACKET_TABLE     : ����I���@�@�@                                */
/*        -1/NULL            : �ُ�I���@�@�@                                */
/*                                                                           */
/*****************************************************************************/
#include "akbcommon.h"

#define D_XTOF(x)

static int _dump(msg,data,len)
char *msg,*data;
int  len;
{
	char *p;

	p = akb_log_set_file_name(0, NULL);
	if (!p) p = akb_log_set_file_name(0, ERROR_LOG_FILE);
	akbfixdmp(akb_log_file_path(0,0x01),msg,data,len);
	return 0;
}

static int _form_check(p,lLen,iFtoX,iparm)
char *p;
int lLen;
int  iparm[];
{
	int Xplen,dlen,flag,plen;
	INT4 wkl;
	int  invalid=0,same_host;
	char *fnp;
	uchar m;

	same_host = iparm[0];
	Xplen = 0;
	flag =  1;
	plen = lLen;
	while (plen>0) {
		switch (*p) {
		case 'P':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			Xplen += dlen+8;
/*
printf("_form_check(iFtoX=%d): P dlen=%d Xplen=%d\n",iFtoX,dlen,Xplen);
*/
			p    += dlen+8;
			plen -= dlen+8;
			break;
		case 'F':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			m = *(p+1);
			Xplen += m + 4;
			fnp = p + 8;
/*
printf("_form_check(iFtoX=%d): F m=%d dlen=%d Xplen=%d\n",iFtoX,m,dlen,Xplen);
*/
			p    += m + 4;
			plen -= m + 4;
			if (same_host>0 && *fnp=='/') break;
			if (iFtoX) {
				Xplen += dlen;
/*
printf("_form_check(iFtoX=%d): F Xplen=%d\n",iFtoX,Xplen);
*/
			}
			flag = 0;
			break;
		case 'X':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			m = *(p+1);
			p    += m + 4;
			plen -= dlen + m + 4;
			p    += dlen;
			Xplen += m + 4;
			if (iFtoX) Xplen += dlen;
/*
printf("_form_check(iFtoX=%d): X dlen=%d Xplen=%d\n",iFtoX,dlen,Xplen);
*/
			break;
		default:
/*
printf("_form_check(iFtoX=%d): default\n",iFtoX);
*/
			ERROROUT1("_form_check:invalid block id = %02x",*p);
			invalid = 1;
		/*	return -1;	*/
		}
		if (plen < 0) {
			ERROROUT1("_form_check:data len few plen=%d",plen);
			invalid = 1;
		}
		if (invalid) {
/*
			_dump("_form_check:invalid KAN_packet form",
			      pOld->pContent,pOld->iLen);
*/
			return -1;
		}
	}
	iparm[1] = flag;
	return Xplen;
}

pSD_PACKET_TABLE akbs_make_xpacket(pOld)
pSD_PACKET_TABLE     pOld;
{
	pSD_PACKET_TABLE pNew;
	int iRc;

	if ((iRc = akbi_make_xpacket(pOld,-1)) > 0) {
		if (!(pNew = akb_packet_tbl_new(0))) return NULL;
		memcpy(pNew,pOld,sizeof(tdtRCSD_PACKET_TABLE));
		Free(pOld);
		return pNew;
	}
	else if (iRc < 0) return NULL;
	else return pOld;
}

int akbi_make_xpacket(pOld,same_host)
pSD_PACKET_TABLE     pOld;
int same_host;
{
	pSD_PACKET_TABLE     pNew;
	tdtCOMM_PACK_HEAD     *pHead,*pH,tHead;
	pCOMM_PACK_HEADA     pHA;
	pCOMM_PACK_HEADB     pHB;
	char  *p,m,*pn,fname[128],*fnp,*cpPath,ver,*pOldCont,*pNewCont,c,cver;
	int   Xplen,dlen,flag,plen,lLen;
	FILE  *fp;
	INT4  wkl;
	int iHSize,invalid=0,iparm[2];

	pOldCont = pOld->sp_content;
	pHead = (pCOMM_PACK_HEAD)pOldCont;
	if (!((c=pHead->cph_prt.prt_send) & AKB_PFM_INDIRECT)) return 0;
	if (c & AKB_PFM_SYSINDIR) return 0;

	AKBGETHSIZEETC(pHead,ver,pHA,iHSize,lLen)
	if (same_host & AKB_WQUE_OPT_CHK_REPLY) {
		/* �ԐM�p�P�b�g��akb error�̂Ƃ��́A�t�@�C����]�����Ȃ� */
		if (ver == 'B') {
			pHB = (pCOMM_PACK_HEADB)pHead;
			if (pHB->phb_sind.inb_pkid && pHB->phb_dind.inb_pkid) return 0;
		}
		else {
			pH = pHead;
			if (pHA) {
				akb_get_head_from_a(&tHead,pH);
				pH = &tHead;
			}
			/* Rely Packet & akb error */
			if (!pH->cph_sinf.ind_thrd && pH->cph_sinf.ind_pano) return 0;
		}
	}
	
	if (same_host < 0) {
		same_host = 0;
		if (pHA) {
			if (pHA->pha_sinf.ina_hoid == pHA->pha_dinf.ina_hoid) same_host = 1;
		}
		else {
			if (pHead->cph_sinf.ind_hoid == pHead->cph_dinf.ind_hoid) same_host = 1;
		}
	}

	p  = pOldCont + iHSize;
	iparm[0] = same_host;
	if ((Xplen=_form_check(p,lLen,1,iparm)) < 0) {
		_dump("makeXpacket:invalid KAN_packet form",
		      pOld->sp_content,pOld->sp_len);
		return -1;
	}
	if (flag=iparm[1]) return 0;

	if (!(pNewCont=Malloc(Xplen + iHSize))) {
		ERROROUT1("makeXpacket: pNewCont malloc error len=%d",Xplen+iHSize);
		return -2;
	}
	pn = pNewCont + iHSize;
	plen = lLen;
	while (plen>0) {
		switch (*p) {
		case 'P':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			memcpy(pn,p,dlen+8);
			p    += dlen+8;
			pn   += dlen+8;
			plen -= dlen+8;
			break;
		case 'F':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			m = *(p+1);
			memcpy(pn,p,m+4);
			if (same_host && *(p+8)=='/') {
				pn   += m + 4;
				p    += m + 4;
				plen -= m + 4;
				break;
			}
			*pn = 'X';
			pn   += m + 4;
			memcpy(fname,p+8,m-4);
			fname[m-4] = '\0';
			fnp = &fname[0];
			while (*fnp && *fnp!=':') fnp++;
			if (*fnp == ':') fnp++;
			else fnp = &fname[0];
/*
printf("makeXpacket: F file name = %s\n",fnp);
*/
			if (*fnp == '/') cpPath = fnp;
			else cpPath = akb_akb_home_add(fnp);
			if (fp=fopen(cpPath,"rb")) {
				fread(pn,1,dlen,fp);
/*
printf("makeXpacket: X dlen=%d\n",dlen);
*/
				fclose(fp);
				pn += dlen;
			} else{
				ERROROUT1("makeXpacket:file[%s] open error!!",cpPath);
				Free(pNewCont);
				return -3;
			}
			p    += m + 4;
			plen -= m + 4;
			break;
		case 'X':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			m = *(p+1);
			memcpy(pn,p,m+4);
			pn   += m + 4;
			p    += m + 4;
			memcpy(pn,p,dlen);
			pn   += dlen;
			p    += dlen;
			plen -= dlen + m + 4;
			break;
		default:
			Free(pNewCont);
			return -1;
		}
	}

	pOld->sp_len = Xplen + iHSize;
	memcpy(pNewCont,pOldCont,iHSize);
	Free(pOldCont);
	pOld->sp_content = pNewCont;
	if (ver == 'A') {
		pHA = (tdtCOMM_PACK_HEADA *)pNewCont;
		pHA->pha_plen = htonl(Xplen);
	}
	else {
		pHead = (pCOMM_PACK_HEAD)pNewCont;
		pHead->cph_plen = htonl(Xplen);
	}
/*
printf("makeXpacket: Normal End\n");
*/
	return pOld->sp_len;
}

pSD_PACKET_TABLE akbs_xto_fpacket(pOld)
pSD_PACKET_TABLE pOld;
{
	if (akbi_xto_fpacket(pOld) >= 0) return pOld;
	else return NULL;
}

int akbi_xto_fpacket(pOld)
pSD_PACKET_TABLE     pOld;
{
	pCOMM_PACK_HEAD      pHead;
	pCOMM_PACK_HEADA     pHA;
	char  *p,m,*pn,fname[128],*fnp,*cpPath,ver,*pOldCont,*pNewCont,c;
	int   Xplen,dlen,plen,w,lLen;
	FILE  *fp;
	int   i,iHSize,invalid=0,iparm[2];
	INT4  wkl;

	pOldCont = pOld->sp_content;
	pHead = (pCOMM_PACK_HEAD)pOldCont;
	if (!((c=pHead->cph_prt.prt_send) & AKB_PFM_INDIRECT)) return 0;
	if (c & AKB_PFM_SYSINDIR) return 0;
	AKBGETHSIZEETC(pHead,ver,pHA,iHSize,lLen)

	p  = pOldCont + iHSize;
	iparm[0] = -1;
	if ((Xplen=_form_check(p,lLen,0,iparm)) < 0) {
		_dump("XtoFpacket: invalid KAN_packet form",
		      pOld->sp_content,pOld->sp_len);
		return -1;
	}

	if (!(pNewCont=Malloc(Xplen+1 + iHSize))) {
		ERROROUT1("XtoFpacket: pNewCont malloc error len=%d",Xplen+1+iHSize);
		return -2;
	}
	p  = pOldCont + iHSize;
	pn = pNewCont + iHSize;
	plen = lLen;
	while (plen>0) {
		switch (*p) {
		case 'P':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			memcpy(pn,p,dlen+8);
			pn   += dlen+8;
			p    += dlen+8;
			plen -= dlen+8;
			break;
		case 'F':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			m = *(p+1);
			memcpy(pn,p,m+4);
			pn   += m + 4;
			p    += m + 4;
			plen -= m + 4;
			break;
		case 'X':
			memcpy((char *)&wkl,p+4,4);
			dlen = ntohl(wkl);
			m = *(p+1);
			memcpy(pn,p,m+4);
			*pn = 'F';
			memcpy(fname,p+8,m-4);
			fname[m-4] = '\0';
			fnp = &fname[0];
			while (*fnp && *fnp!=':') fnp++;
			if (*fnp == ':') fnp++;
			else fnp = &fname[0];
/*
printf("XtoFpacket: X file name = %s\n",fnp);
*/
			i = akxtsrepc(fnp,'\\','/');
			if (fnp!=&fname[0] || i) {
				memcpy(pn+8,fnp,strlen(fnp));
				*(pn+1) = 4 + strlen(fnp);
			}
			if (*fnp == '/') cpPath = fnp;
			else cpPath = akb_akb_home_add(fnp);
			p    += m + 4;
			plen -= dlen + m + 4;
			if (fp=fopen(cpPath,"wb")) {
				fwrite(p,1,dlen,fp);
				fclose(fp);
			}
			else {
				ERROROUT1("XtoFpacket:file[%s] open error!!",cpPath);
				Free(pNewCont);
				return -3;
			}
			p    += dlen;
			pn   += m + 4;
/*
printf("XtoFpacket: X dlen=%d\n",dlen);
*/
			break;
		default:
/*
printf("XtoFpacket: default\n");
*/
			Free(pNewCont);
			return -1;
		}
	}

	pOld->sp_len = Xplen + iHSize;
	memcpy(pNewCont,pOldCont,iHSize);
	Free(pOldCont);
	pOld->sp_content = pNewCont;
	if (ver == 'A') {
		pHA = (tdtCOMM_PACK_HEADA *)pNewCont;
		pHA->pha_plen = htonl(Xplen);
	}
	else {
		pHead = (pCOMM_PACK_HEAD)pNewCont;
		pHead->cph_plen = htonl(Xplen);
	}
/*
printf("XtoFpacket: Normal End. Packet len = %d\n",Xplen);
*/
	return pOld->sp_len;
}
