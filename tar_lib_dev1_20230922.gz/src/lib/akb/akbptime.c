static  char    sccsid[]="%Z% %M% %I% %D% %T%";
#include "akbcommon.h"

#define MAXREG 100
#define MSO     73
#define KEYLEN  16

static int iInit=0;
static HASHB ht;
static int  Htnext[MAXREG];
static char Htreg [MAXREG*(KEYLEN+1)];
static char Htkey [KEYLEN];
static struct {
	int  usec;
	int  tusec;
	int  scount;
	int  ecount;
	int  uclock;
	int  tuclock;
} Htime[MAXREG];

static struct {
	char fname[32];
	int  st_sec;
	int  bf_sec;
	int  bf_usec;
} Stinf;

int akb_ptime(c,msg)
char c,*msg;
{
/*
	struct timeval {
		int  tv_sec;
		int  tv_usec;
	} tp;
	*/
	struct timeval tp;
	struct timezone {
		int a;
		int b;
	} tzp;
	FILE *fp;
	int  t,i,m,us,cnt,uc,tuc;

	if (!iInit && (c=='I' || c=='i')) {
		if (!msg) return -1;
		ht.ha_keylen = KEYLEN;
		ht.ha_maxreg = MAXREG;
		ht.ha_prereg = MSO;
		ht.ha_reg    = Htreg;
		ht.ha_next   = Htnext;
		ht.ha_key    = Htkey;
		ht.ha_aux    = 0;
		ht.ha_hix    = 0;
		i = akxshasx('I',&ht);
/*
printf("akb_ptime: init rc = %d\n", i);
*/
		if (i) return i*10;
		gettimeofday(&tp,NULL);
		Stinf.st_sec=tp.tv_sec;
		strcpy(Stinf.fname,msg);
#ifdef R_FILE
		if (fp=fopen(msg,"r")) {
			fclose(fp);
#endif
			if (fp=fopen(msg,"w")) {
/*
fprintf(fp,"ptime:s=%d us=%d\n",tp.tv_sec,tp.tv_usec);
*/
				fprintf(fp,"cmd      current     t     ut count     uc    tuc msg\n");
				fprintf(fp,"Init :%10d\n",tp.tv_sec);
				fclose(fp);
			}
			else return -2;
			if (c == 'I') iInit = 1;
			else iInit = 2;
			for (i=0;i<MAXREG;i++) {
				Htime[i].usec    = 0;
				Htime[i].tusec   = 0;
				Htime[i].scount  = 0;
				Htime[i].ecount  = 0;
				Htime[i].uclock  = 0;
				Htime[i].tuclock = 0;
			}
#ifdef R_FILE
		}
#endif
	}
	else if (iInit) {
		gettimeofday(&tp,NULL);
		uc = clock();
		if (msg) {
			m=strlen(msg);
			if (m>=KEYLEN) {
				memcpy(Htkey,msg,KEYLEN);
			}
			else {
				memset(Htkey,'\0',KEYLEN);
				memcpy(Htkey,msg,m);
			}
		}
		switch (c) {
		  case 'S':
		  case 's':
			if (!msg) return -1;
			Stinf.bf_sec =tp.tv_sec-Stinf.st_sec;
			Stinf.bf_usec=tp.tv_usec;
			i = akxshasx('S',&ht);
			i--;
			us = Stinf.bf_sec*1000000+Stinf.bf_usec;
			cnt = 0;
			if (i >= 0) {
				Htime[i].usec = us;
				cnt = ++Htime[i].scount;
				Htime[i].uclock = uc;
			}
#ifdef R_FILE
			if (fp=fopen(Stinf.fname,"r")) {
				fclose(fp);
#else
			if (iInit==1 && c=='S') {
#endif
				if (fp=fopen(Stinf.fname,"a")) {
/*
fprintf(fp,"ptime:i=%d s=%d us=%d tu=%d\n",i,tp.tv_sec,tp.tv_usec,us);
*/
					fprintf(fp,"Start:%10d %5d.%06d %5d %6d       :%s\n",
					tp.tv_sec,tp.tv_sec-Stinf.st_sec,tp.tv_usec,cnt,uc,msg);
					fclose(fp);
				}
				else return -2;
			}
			break;
		  case 'E':
		  case 'e':
			if (!msg) return -1;
			i=akxshasx('R',&ht);
			i--;
			if (i>=0) {
				t=(tp.tv_sec-Stinf.st_sec)*1000000+tp.tv_usec-Htime[i].usec;
				Htime[i].tusec += t;
				cnt = ++Htime[i].ecount;
				uc -= Htime[i].uclock;
				Htime[i].uclock = uc;
				Htime[i].tuclock += Htime[i].uclock;
				tuc = Htime[i].tuclock;
			}
			else {
				t=(tp.tv_sec-Stinf.st_sec-Stinf.bf_sec)*1000000 +
					tp.tv_usec-Stinf.bf_usec;
				cnt = tuc = 0;
			}
#ifdef R_FILE
			if (fp=fopen(Stinf.fname,"r")) {
				fclose(fp);
#else
			if (iInit==1 && c=='E') {
#endif
				if (fp=fopen(Stinf.fname,"a")) {
/*
fprintf(fp,"ptime:i=%d s=%d us=%d tu=%d t=%d\n",i,tp.tv_sec,tp.tv_usec,uc,t);
*/
					fprintf(fp,"End  :%10d %5d.%06d %5d %6d %6d:%s\n",
					tp.tv_sec,t/1000000,t%1000000,cnt,uc,tuc,msg);
					fclose(fp);
				}
				else return -2;
			}
			break;
		  case 'T':
		  case 't':
			if (fp=fopen(Stinf.fname,"a")) {
				fprintf(fp,"\nNo. BlockName        scount ecount     t     ut     uclock\n");
				for (i=0;i<MAXREG;i++) {
					ht.ha_hix = i + 1;
					if (akxshasx('K',&ht)) {
						fprintf(fp,"%3d %-16s %6d %6d%6d.%06d%11d\n",
						i,ht.ha_key,Htime[i].scount,Htime[i].ecount,
						Htime[i].tusec/1000000,Htime[i].tusec%1000000,
						Htime[i].tuclock);
					}
				}
				fclose(fp);
			}
			else return -2;
			break;
		  default:
#ifdef R_FILE
			if (fp=fopen(Stinf.fname,"r")) {
				fclose(fp);
#else
			if (iInit) {
#endif
				if (fp=fopen(Stinf.fname,"a")) {
					Stinf.bf_sec =tp.tv_sec-Stinf.st_sec;
					Stinf.bf_usec=tp.tv_usec;
					fprintf(fp,"Start:%5d %5d %6d:%s\n",tp.tv_sec,
						tp.tv_sec-Stinf.st_sec,tp.tv_usec,msg);
					fclose(fp);
				}
			}
		}
	}
	return 0;
}
