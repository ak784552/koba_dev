/*static    char    sccsid[]="%Z% %M% %I% %D% %T%";*/
/*********************************************************/
/*                                                       */
/*     akaprot.h                                         */
/*                                                       */
/*              coded by A.Kobayashi 2000.03.16          */
/*                                                       */
/*********************************************************/
#ifndef _AKAPROT_H
#define _AKAPROT_H

/* akalib1.c */
int aka_connect(/*cpHost,cpService*/);
int aka_shut_down(/*iSd*/);
int aka_shut_down2();
int aka_regist_host(/*iSd,iProcNumber,cpMsg,lMsgLen,lMyHid,iOption*/);
int aka_regist2(/*iSd,iProcNumber,cpMsg,lMsgLen*/);
int aka_regist(/*iSd,iProcNumber*/);
int aka_connect_regist(/*iSd,iProcId,cpMsg,lMsgLen*/);
int aka_cancel_msg(/*iSd,iProcNumber,cpMsg,lMsgLen*/);
int aka_cancel2(/*cpMsg,lMsgLen*/);
int aka_cancel_ret(/*iRet*/);
int aka_cancel(/*iSd,iProcNumber*/);
INT4 aka_get_pr_host_id();
INT4 aka_get_my_host_id();
void aka_set_shut_packet(/*tpHead*/);
int aka_get_regist_pid();
int aka_get_connect_port();
char aka_set_regist_ver(/*cVer*/);
char aka_get_regist_ver();
int aka_set_connect_sd(/*iSd*/);
int aka_get_connect_sd();
int aka_init_status(/*iStatus,iSet*/);
int aka_get_regist_dest_pid();
int aka_set_regist_dest_pid(/*iPid*/);
int aka_usage(/*cpProc*/);
int aka_set_regist_option(/*iOption*/);
int aka_get_regist_option();

/* akalib2.c */
int aka_initialize_p(/*nParm,iParm*/);
int aka_init_zero(/*iSd*/);
void  aka_terminate();
int aka_register_class(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName,cpUserArea*/);
int aka_register_class2(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName*/);
int aka_register_class3(/*pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName,cpUserArea*/);
int aka_instance_buf_free(/*tpIns*/);
void aka_wait_packet_free(/*tpWait*/);
int aka_expand_tables(/*iAdd*/);
int aka_instance_init(/*iOpt, tpIns, iInstanceDataSize*/);
int aka_conv_inst_hndl2(/*lInstanceHandle, tpInstHndl, iOpt*/);
int aka_conv_inst_hndl(/*lInstanceHandle, tpInstHndl*/);
int aka_initialize();
int aka_initialize2(/*iSd,iProcNumber,cpMsg,lMsgLen,iMaxThreadTotal,iMsgOpt*/);
void  aka_terminate_ret(/*iRet*/);
void  aka_terminate_all(/*iRet*/);
int aka_initialize_all(/*argc,argv,nparm,parm*/);
int aka_initialize3(/*nparm,parm*/);
int aka_register_method(/*iClassId,iMaxMethod,tpMethod,iMaxMethodParm,iOption*/);
int aka_set_nofree(/*iSet,level*/);

/* akalib3.c */
int aka_get_msg(/*iWaitTime*/);
int aka_dispatch_msg();
void aka_terminate();

/* akalib4.c */
int aka_send_msg_wait_time(/*lInstanceHandle,tpSendMsg,iWaitTime*/);
int aka_recv_msg(/*lInstanceHandle,tpComObject,iWaitTime,iOptions*/);
int aka_post_msg(/*lInstanceHandle,tpSendMsg*/);

/* akalib5.c */
tdtCHANNEL *aka_channel_new(/* int iMax*/);
int aka_channel_free(/*pCh,iMax*/);
int aka_channel_open(/*pCha*/);
int aka_channel_uioopen(/*iCh*/);
int aka_channel_shut(/*iCh,iOpt*/);
int aka_channel_close(/*iCh*/);
int aka_channel_uioclose(/*iCh*/);
int aka_channel_command(/*pCh,iClass,iDisp*/);
int aka_channel_resume(/*iCh,iOpt*/);
int aka_channel_clear(/*iCh*/);
int aka_read_que(/*pChannel, pReadQue, pRbRCtl*/);
int aka_channel_set_seq(/*iCh,iLen,pSeq*/);
int aka_channel_rep_seq(/*pCh,iLen,pSeq*/);
int aka_channel_inst_free_seq(/*lInstHandl*/);
int aka_write_que(/*pCh, pWriteQue*/);
int aka_channel_inst_free_seq(/*lInstHandl*/);
int aka_channel_move(/*iCh*/);
tdtCHANNEL *aka_channel_get();
int aka_channel_option(/*iCh,iOption,iSet,ipRet*/);
int aka_cuioselect_interval(/*iCh,iInterval,iSet,ipRet*/);
int aka_hyp_channel_get_one(/*iCh*/);
int aka_hyp_channel_add_ch(/*iHypCh,iCh*/);
int aka_hyp_channel_del_ch(/*iHypCh,iCh*/);
int aka_hyp_channel_close(/*iHypCh*/);

/* akacommon.c */
int aka_get_msec(/*ptval*/);
int aka_get_ver_date(/*cpVerDate,iVerDateLen*/);
int aka_set_msg_time_out(/*iTimeOut*/);
int aka_shut_control(/*iAttribute,cpValue*/);
int aka_set_ver_date(/*ver,date*/);

extern int          aka_new_com_object();
extern tdtCLASS_CTL *aka_srch_class();
extern tdtCLASS_CTL *aka_srch_class2();
extern char         aka_set_regist_ver();
extern char         aka_get_regist_ver();
extern tdtRWQ_TIME_OUT *aka_rwque_time_out_new();
extern char        *aka_channel_event_msg(/* int iEvent*/);

#endif	/* _AKAPROT_H */
