#include "akbcommon.h"
void main()
{
	int i;

	ERROROUT("ERROROUT");
	ERROROUT1("%s","ERROROUT1");
	ERROROUT2("%s = %d","ERROROUT2", 2);
	ERROROUT3("%s = %d, %c","ERROROUT3", 3, 'X');
	ERROROUT4("%s = %d, %c, %08x","ERROROUT4", 4, 'X', &i);
	ERROROUT5("%s = %d, %c, %08x, %s","ERROROUT5", 5, 'X', &i, "***");

	akb_log_flg(2,3);
	DEBUGOUT("DEBUGOUT");
	DEBUGOUT1("%s","DEBUGOUT1");
	DEBUGOUT2("%s = %d","DEBUGOUT2", 2);
	DEBUGOUT3("%s = %d, %c","DEBUGOUT3", 3, 'X');
	DEBUGOUT4("%s = %d, %c, %08x","DEBUGOUT4", 4, 'X', &i);
	DEBUGOUT5("%s = %d, %c, %08x, %s","DEBUGOUT5", 5, 'X', &i, "***");
}
