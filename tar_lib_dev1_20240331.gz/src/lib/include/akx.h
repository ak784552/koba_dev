/*static    char    sccsid[]="@(#) akx.h 1.1 97/08/28 11:51:38";*/
/*********************************************************/
/*                                                       */
/*     akx.h                                             */
/*                                                       */
/*              coded by A.Kobayashi 96.1.17             */
/*                                                       */
/*********************************************************/
#ifndef _AKX_H
#define _AKX_H

#include "akxmemtool.h"
#include "akxlib.h"
#include "akxlog.h"

#endif	/* _AKX_H */
