/*static	char	sccsid[]="%Z% %M% %I% %E% %U%";*/
/*****************************************/
/*                                       */
/*      akastruct.h                      */
/*---------------------------------------*/
/*                                       */
/*      ���ʃw�b�_�[�t�@�C���i�\���́j   */
/*---------------------------------------*/    
/*                                       */
/*              Ver   0.01  1996/01/30   */
/*              Ver   3.00  2000/02/18   */
/*****************************************/
#ifndef _AKASTRUCT_H
#define _AKASTRUCT_H

/*  */
#if 0	/* move to akbstruct.h, koba 2000.7.26 */
/*** Struct for Message Comunication ***/
typedef struct tdtMSG_COM {
	long    msg_hoid      ;	/* �z�X�g�A�h���X                           */
	ushort  msg_prid     ;	/* �v���Z�X�ԍ�                             */
	ushort  msg_clid    ;	/* �N���X���ʔԍ�                           */
	ushort  msg_disp;	/* �����h�c                                 */
	short   msg_pret     ;	/* ���ʃv���b�g�t�H�[������̃��^�[���R�[�h */
	char   *msg_pmsg        ;	/* �p�P�b�g�̃f�[�^��                       */
	long    msg_mlen      ;	/* ���b�Z�[�W���i�o�C�g�j                   */
	uchar   msg_resv       ;	/* �\��                                     */
	uchar   msg_aopt  ;	/* ���ʃv���b�g�t�H�[�������I�v�V����       */
	uchar   msg_form   ;	/* �p�P�b�g�`��                             */
	uchar   msg_filc      ;	/* �Ԑڃt�@�C���̐�                         */
	char  **msg_filv      ;	/* �Ԑڃt�@�C���̃t�@�C�����ւ̃|�C���^�z�� */
} tdtMSG_COM;
#endif

/* �n�C�p�[�`���l����` */
typedef struct tdtHYP_CHANNEL {
	short hyp_cha_used;
	short hyp_cha[256];
	short cha[256];
} tdtHYP_CHANNEL;

/* �`���l���h�n���[�U��` */
typedef struct {
	int    select_interval;	/* msec */
	char  *parm;
	int    (*open)();
	int    (*connect)();
	int    (*select)();
	int    (*read)();
	int    (*write)();
	int    (*write_end)();
	int    (*shutdown)();
	int    (*close)();
	int    (*accept)();
	struct timeval select_time;
} tdtCHANNEL_USER_IO;

/* �`���l���E�I�[�v����` */
typedef struct {
	char  *host_name;
	char  *service;
	int    sd;
	int    (*head_check)();
#if 0	/* 2001.12.10 Koba */
	int    head_len;
#else
	ushort opt;
	ushort head_len;
#endif
	int    (*exception)();
	tdtCHANNEL_USER_IO  *cuio;
	struct sockaddr_in *sa;
	char  *parm;
} tdtCHANNEL_OPEN;

/* �`���l����` */
typedef struct {
	uchar  status;	/* 0/1/2=unused/opened/to close */
	uchar  select;
	uchar  index;
	uchar  resv4;		/* Next Header Flag */
	int    sd;
	int    (*head_check)();
	ushort head_len;
	ushort woffset;
	tdtCOMM_PACK_HEAD *rpack_head;
	tdtCOMM_PACK_HEAD *wpack_head;
#ifndef NO_CHANNEL_QUE
	tdtQUE_CTL *wpack_que;
#endif
	int    (*exception)();
	tdtCHANNEL_USER_IO  *cuio;
	struct sockaddr_in *sa;
	int    from_len;
	char  *parm;
	int    rwlen_last;
	uchar  opt1;	/* UIO Lock Flag */
	uchar  opt2;
	uchar  opt3;
	uchar  opt;	/* used in HeaderCheck by user */
	int    sys_opt;
	int    linger;	/* when >=0 , set SO_LINGER on by linger(sec) */
	uchar  hyp_ch;
	uchar  resv6;
	uchar  resv7;
	uchar  resv8;
} tdtCHANNEL;

/* �`���l���o�͕ԐM�p��� for aka */
typedef struct tdtREP_HEAD {
	tdtCOMM_PACK_HEAD packet_head;
	long instance_handle;
	char sequence[AKA_CHANNEL_SEQMAX];
}tdtREP_HEAD ;

/* ���b�Z�[�W����\ for aka */
typedef struct tdtMSG_CTL {
	int     sd;
	INT4    host_id;
	int     proc;
#if 0	/* 2000.7.31 Koba */
	long    start_tv_sec;		/* �b */ 
	long    start_tv_usec;		/* �}�C�N���b */ 
#else
	tdtTIMER_CTL_HEAD *timer_ctl;
#endif
	int     send_msg_time_out;	/* �ԐM�҂����Ԃ̃f�t�H���g(�~���b) */ 
	int     send_msg_min_wait;	/* �~���b */ 
	int     get_msg_wait_time;	/* �~���b */ 
	struct timeval get_msg_time_out;
	short   wqsuspend;
	short   rqsuspend;
	uchar   shut_mode;
	uchar   shut_suspend;
	uchar   rsv1;				/* message read/write flag in GetMsg*/
	uchar   rsv2;				/* PRINTOUT LEVEL */
	char    *spool_dir;
	short   channel_max;
	short   channel_used;
#if 1	/* V6 */
	tdtRW_QUE  **read_que_pa;
	tdtRW_QUE  **write_que_pa;
	tdtCHANNEL **channel_pa;
#else	/* V5 */
	tdtRW_QUE  *read_que;
	tdtRW_QUE  *write_que;
	tdtCHANNEL *channel;
#endif
	tdtRB_CTL  *rb_rctl;
	tdtRB_CTL  *rb_wctl;
	tdtRB_CTL  *rb_wwctl;
	tdtQUE_CTL *que_rwctl;
	tdtRB_CTL  *rb_dwctl;	/* add 2000.3.28 Koba */
	INT4    my_host_id;	/* add 2000.10.17 Koba */
	ushort  apsys_id;
	ushort  us_resv;
	tdtRWQ_TIME_OUT *rwqtime_out;
	ushort  us_proc;
	ushort  regist_dest_pid;
	int     msg_opt;
	tdtRB_CTL  **rb_wctl_pa;	/* add 2005.6.18 Koba */
	tdtRB_CTL  **rb_pri_ctl_pa;	/* add 2005.6.18 Koba */
	tdtGENERAL_DATA *que_used_data;
	tdtHYP_CHANNEL *hyp_channel;
	short   channel_akb_used;
	short   resv;
} tdtMSG_CTL;

/* �v�������p�P�b�g�\���� */
typedef struct tdtWAIT_PACKET {
	struct tdtWAIT_PACKET *wait_next;
	char  *wait_packet;
	struct timeval time_out;	/* �^�C���A�E�g���鎞�� */
	int    status;
	int    ret_code;
} tdtWAIT_PACKET;

/* ���\�b�h for aka */
typedef struct tdtMETHOD {
	int    (*func_name)();
	char   *method_name;
	uchar  max_parm;
	uchar  resv;
	ushort option;
	char   *explain;
} tdtMETHOD;

/* �v���������\�b�h�\���� */
typedef struct tdtWAIT_METHOD {
	struct tdtWAIT_METHOD *wait_method;
	short  packet_no;
	short  rsv;
	tdtMETHOD *method;
} tdtWAIT_METHOD;

/* �C���X�^���X for aka */
typedef struct tdtINSTANCE {
	unsigned char used;
	unsigned char kind;
	unsigned char rsv3;
	unsigned char rsv4;
	char          *instance_data;
	int           inst_time_out;
	tdtWAIT_PACKET *wait_next;
	tdtMSG_COM     *recv_msg_com;
	tdtCOMM_PACK_HEAD *pack_head;
	char          *to_free;
	tdtRB_CTL        *rb_com_object;
	char          *comment;
	tdtMETHOD     *method;
	tdtWAIT_METHOD *wait_method;
	short         recv_packet_no;
	short         recv;
} tdtINSTANCE;

/* �N���X����\ for aka */
typedef struct tdtCLASS_CTL {
	int    (*func_name)();
	int    class_id;
	int    instance_data_size;
	int    max_thread;
	int    option;
	tdtINSTANCE *instance;
	struct tdtCLASS_CTL *class_next;
	int    packet_number;
	int    used_count;
	char   *class_name;
	int    (*func_name2)();
	char   *class_name2;
	int    instance_data_size2;
	ushort *recv_proc_id;
	int    max_method;
	tdtMETHOD *method;
	int    max_method_parm;
#ifdef TP_MON
	unsigned short max_exec_thread;
	unsigned short used_exec_count;
	tdtRB_CTL  *msg_que;
	int    msg_que_count;
#endif
} tdtCLASS_CTL;

/* �N���X�w�b�_ for aka */
typedef struct tdtCLASS_CTLHead {
	int max_thread_total;
	int used_thread_total;
	tdtCLASS_CTL *class;
} tdtCLASS_CTLHead;

/* �ʐM�p�I�u�W�F�N�g */
typedef struct tdtCOM_OBJECT {
	long        instance_handle;
	short       packet_no;
	short       rsv;
	long        recv_ins_hnd;
	int         options;
	tdtINSTANCE *recv_ins;
	char        *to_free;
} tdtCOM_OBJECT;

/* �C���X�^���X�E�n���h���\  */
typedef struct tdtINST_HNDL {
#if 0	/* 2000.9.13 Koba */
	long        instance_handle;
	int         thread;
	int         class_id;
#else
	uchar       rsv;
	uchar       thread;
	ushort      class_id;
#endif
	tdtCLASS_CTL *class;
	tdtINSTANCE *instance;
} tdtINST_HNDL;

typedef struct {
	int         instance_handle;
	tdtCLASS_CTL *class;
	tdtINSTANCE *instance;
} tdtINST_HNDL2;

/* ���v��� *//* 2004.1.22 Koba */

#define AKA_STAT_MAXMSGLEND	1000000

typedef struct tdtSTAT_UNIT {
	uint     msg_total;
	uint     msg_count_s;
	ulong    msg_count;
	double   msg_avg;
	double   msg_max;
	double   msg_len_total;
	uint     msg_len_s;
	uint     msg_len;
	uint     msg_len_avg;
	uint     msg_len_max;
	double   msg_max0;
	uint     msg_len_max0;
} tdtSTAT_UNIT;

typedef struct tdtSTATISTICS {
	uchar    opt[4];
	int      timer_id;
	int      interval;		/* sec */
	int      check_time;	/* sec */
	int      start_time;	/* sec */
	tdtSTAT_UNIT u[4];
} tdtSTATISTICS;

/* �o�^��� for aka */
typedef struct tdtREGIST_INFO {
	uchar status;
	uchar resv2;
	uchar resv3;
	char  akb_ver;
	int   regist_sd;
	int   regist_pid;
	INT4  pr_host_id;
	INT4  my_host_id;
	int   connect_port;
	tdtCOMM_PACK_HEAD  shut_head;
	tdtCOMM_PACK_HEAD *pshut_head;
} tdtREGIST_INFO;

/* Initialize�p�����[�^ */
/********************************************************/
/*	parm[ 0]:	iSd										*/
/*	parm[ 1]:	iProc									*/
/*	parm[ 2]:	iMaxThread								*/
/*	parm[ 3]:	iOpt									*/
/*	parm[ 4]:	cpMsg									*/
/*	parm[ 5]:	iMsgLen									*/
/*	parm[ 6]:	user init Func							*/
/*	parm[ 7]:	cpUserArea								*/
/*	parm[ 8]:	Meminit file name						*/
/*	parm[ 9]:	Connect host name						*/
/********************************************************/
typedef struct {
	long sd;
	long proc_id;
	long max_thread;
	long opt;
	char *msg;
	long msg_len;
	int  (*user_init_func)();
	char *user_area;
	char *mem_ctl;
	char *connect_host;
} tdtINITIALIZE_PARM;

#endif	/* _AKASTRUCT_H */
