static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testlike.c akxcom.a -o testlike
*/
#include <stdio.h>
#include <stdio.h>
main()
{
	char buf[256],wd[256];
	int n,opt,len,ret,pos[4];

	printf("Enter case opt==>");
	gets(buf);
	opt=atoi(buf);
	printf("Enter string==>");
	gets(buf);
	len = strlen(buf);
	for (;;) {
		printf("Enter patern==>");
		gets(wd);
		ret = akxs_xlike_pos(buf,len,wd,strlen(wd),opt,pos);
		printf("ret=%d pos=%d len=%d pos2=%d len2=%d\n",ret,pos[0],pos[1],pos[2],pos[3]);
	}
}
