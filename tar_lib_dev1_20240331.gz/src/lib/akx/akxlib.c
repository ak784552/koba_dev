static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*	  coded by A.Kobayashi 2010.05.10		*/
/*											*/
/********************************************/
#include "akxcommon.h"

static char *gsep=" \t,;()[]{}<>='\"!^*/";

/****************************************/
/*										*/
/****************************************/
int akxmemwork(len,pp1,pp0,work,w_len)
int  len;
char **pp0,**pp1,*work;
int  w_len;
{
	char *p,*mem;
	int im;

	if (!pp1 || len<0) return -1;
	im = 1;
	mem = work;
	if (work && len<w_len) im = 0;
	if (im) {
		if (pp0) {
			if (p=MRealloc(*pp0,len+1)) {
				mem = *pp0 = p;
			}
		}
		else p = NULL;
		if (!p) {
			if (work) len = w_len -1;
			else len = -1;
		}
	}
	*pp1 = mem;

	return len;
}

/****************************************/
/*										*/
/****************************************/
char *strmem(s,len)
char *s;
int  len;
{
	static char wrk[256],*p0=NULL;
	char *p;

	if ((len=akxmemwork(len,&p,&p0,wrk,sizeof(wrk))) >= 0) {
		memzcpy(p,s,len);
	}
	return p;
}

/****************************************/
/*										*/
/****************************************/
char *memaddv0(argc,argv,argl,pp0)
int   argc;
char *argv[];
int   argl[];
char **pp0;
{
	char *p,*p0,*pp,*pM;
	int  alen,blen;
	int i,len,same;

	if (!pp0) return NULL;
/*
printf("memadd0: alen=%d a=[%s] blen=%d b=[%s]\n",alen,a,blen,b);
*/
	p0 = *pp0;
	len = 1;
	same = 0;
	for (i=0;i<argc;i++) {
		len += argl[i];
		if (!argv[i]) same = 1;
	}
	if (!p0 || same) {
		if (!(pM=Malloc(len))) return NULL;
	}
	else {
		if (!(pM=Realloc(p0,len))) return NULL;
		p0 = NULL;
	}
	pp = pM;
	for (i=0;i<argc;i++) {
		if (p=argv[i]) {
			memcpy(pp,p,len=argl[i]);
			pp += len;
		}
	}
	*pp = '\0';
	if (p0) Free(p0);
/*
printf("memaddv0:%s\n",p);
*/
	*pp0 = pM;
	return pM;
}

/****************************************/
/*										*/
/****************************************/
char *memaddv(argc,argv,argl)
int   argc;
char *argv[];
int   argl[];
{
	static char *p0=NULL;

	return memaddv0(argc,argv,argl,&p0);
}
/****************************************/
/*										*/
/****************************************/
char *memadd0(a,alen,b,blen,pp0)
char *a,*b,**pp0;
int  alen,blen;
{
	char *argv[2];
	int   argl[2];

	argv[0] = a;
	argv[1] = b;
	argl[0] = alen;
	argl[1] = blen;
	return memaddv0(2,argv,argl,pp0);
}
/****************************************/
/*										*/
/****************************************/
char *memadd(a,alen,b,blen)
char *a,*b;
int  alen,blen;
{
	static char *p0=NULL;

	return memadd0(a,alen,b,blen,&p0);
}

/****************************************/
/*										*/
/****************************************/
char *straddv(argc,argv)
int   argc;
char *argv[];
{
	static int *argl=NULL;
	int i;
	char *p;

	if (argc<=0 || !argv) return NULL;
	if (!(argl=(int *)MRealloc(argl,argc*sizeof(int)))) return NULL;
	memset(argl,0,argc*sizeof(int));
	for (i=0;i<argc;i++) {
		if (p=argv[i]) argl[i] = strlen(p);
	}
	return memaddv(argc,argv,argl);
}

/****************************************/
/*										*/
/****************************************/
char *stradd5(a,b,c,d,e)
char *a,*b,*c,*d,*e;
{
	char *argv[5];

	argv[0] = a;
	argv[1] = b;
	argv[2] = c;
	argv[3] = d;
	argv[4] = e;
	return straddv(5,argv);
}

/****************************************/
/*										*/
/****************************************/
char *stradd(a,b)
char *a,*b;
{
	if (!a) return b;
	if (!*a) return b;
	if (!b) return a;
	if (!*b) return a;
	return stradd5(a,b,NULL,NULL,NULL);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstrnlen(s,len)
char *s;
int len;
{
	int i;
	char *p=s;

	for (i=0;i<len;i++) if (!*p++) break;

	return i;
}

/********************************************************/
/*														*/
/********************************************************/
char akxcupper(cc)
char cc;
{
	char c;

	if ((c=cc)>='a' && c<='z') c &= ~0x20;
	return c;
}

/********************************************************/
/*														*/
/********************************************************/
int akxqupper(cc)
char cc;
{
	char c;
	int ret;

	if ((c=cc)>='A' && c<='Z') ret = 1;
	else ret = 0;
	return ret;
}

/****************************************************************************/
/* ���� : akxtgwnsl															*/
/* �@�\ : �����񂩂�w�肳�ꂽ��؂蕶���ŋ�؂��ă��[�h�����o��    		*/
/*        �X�y�[�X�ƃ^�u�ȊO�̋�؂蕶�����I�v�V�����ɂ����o��    		*/
/*         --------------+----------------------*--------------------- 		*/
/*          " "�̈���    | opt & 0x200=0        | opt & 0x200<>0       		*/
/*         --------------+----------------------*--------------------- 		*/
/*          sep�� " ���� | "x" �����[�h�Ƃ���   | " �����[�h�Ƃ���     		*/
/*          sep�T�[�`��  | " �͋�؂�           | " �͋�؂�           		*/
/*         --------------+----------------------*--------------------- 		*/
/*          sep�� " �Ȃ� | "x" �����[�h�Ƃ��Ȃ� | " �����[�h�Ƃ��Ȃ�   		*/
/*          sep�T�[�`��  | "x" ���΂�         | " "���`�F�b�N���Ȃ�  		*/
/*         --------------+----------------------*--------------------- 		*/
/* ���� : buf	: ������ւ̃|�C���^�B										*/
/*				  �I�[�́ANULL�A'\n'�܂���'\r'���A�����񒷂܂�				*/
/*				  �I�v�V�����ɂ��A'\'�̌��͋�؂蕶���̑ΏۂɂȂ�Ȃ�	*/
/*		  len	: �����񒷁i�o�C�g�j�B										*/
/*		  sspl	: ���[�h���o���\���̂ւ̃|�C���^							*/
/*				  sp: �T�[�`�J�n�ʒu�A�擪�͂O�o�C�g�ځB					*/
/*				  wd: ���[�h�i�[�G���A�ւ̃|�C���^�B���[�h���i�[����		*/
/*					  �I�v�V�����ł��ANULL�̂Ƃ��́A�i�[���Ȃ��B			*/
/*				  wdmax: > 0 : ���[�h�i�[�ő咷(�o�C�g)						*/
/*						 = 0 : d�Ƀ��[�h�̐擪�A�h���X��Ԃ�				*/
/*						 < 0 : �������`�F�b�N�����Ɋi�[����					*/
/*				  attr[0]:���[�h���										*/
/*							=1 : ������ or ������							*/
/*							=5 : 'xxxx'										*/
/*							=6 : "xxxx"										*/
/*							=0x80 or asc : ��؂蕶��						*/
/*									 asc:��؂蕶���̔��p�R�[�h				*/
/*										 ���p�łȂ��Ƃ��́A0x7F				*/
/*				  attr[1]:�Q�o�C�g�����L��t���O�B1/0=����^�Ȃ�			*/
/*				  attr[2]:�s���S�k�Q�d�l���p���̂Ƃ��A0x01					*/
/*						  ���[�h�i�[���ɃI�[�o�[�t���[������A0x02��OR����	*/
/*				  attr[3]:[�Q�d]���p�����ɘA������[�Q�d]���p������̂Ƃ��A1 */
/*				  code: �����R�[�h = 0 : �V�X�e���̕����R�[�h				*/
/*		  sep	: ��؂蕶����BNULL�̂Ƃ��́Agsep���g����				*/
/*		  opt	: �I�v�V����												*/
/* 0x01 = 0/1 : ��s�X�y�[�X�ƃ^�u���X�L�b�v���Ȃ� / �X�L�b�v����			*/
/* 0x02 = 0/1 : �Q�d���p���A���p�����͂����Ȃ�(�s���S�G���[����) / �͂���	*/
/* 0x04 = 0/1 : �Q�d���p���A���p���̒��̘A������Q�̂������P�ɂ��Ȃ�	*/
/*              / �P�ɂ���												*/
/* 0x08 = 0/1 : �Q�d���p���A���p���̏��������� / ���������Ȃ�				*/
/* 0x10 = 0/1 : ��؂蕶���ȊO�������܂ŃX�L�b�v���Ȃ� / ��L����������	*/
/* 0x20 = 0/1 : ���g�p�Bsspl->wdmax���g�p����								*/
/*      wdmax= 0:ssp->wd�Ƀ��[�h���i�[�����A���[�h�̐擪�A�h���X������	*/
/*      wdmax<>0:ssp->wd�Ƀ��[�h���i�[���� (wdmax<0:�������`�F�b�N���Ȃ�)	*/
/* 0x40 = 0/1 : '\n'�܂���'\r'���I�[�Ƃ��� / �I�[�Ƃ��Ȃ�					*/
/*				(=1 �́A���p�����̂Ƃ��̂ݗL��)								*/
/* 0x80  = 1 : '\'���G�X�P�[�v�����Ƃ���B���p���̒��ȊO��'\'�͍폜����B	*/
/* 0x100 = 1 : ���p���̏��������Ȃ�											*/
/* 0x200 = 1 : �Q�d���p���̏��������Ȃ�										*/
/* 0x400 = 1 : ��؂蕶�������p�̏ꍇ�A�啶������������ʂ��Ȃ��B			*/
/* 0x800 = 1 : '`'�����p���Ƃ���											*/
/****************************************************************************/
int akxtgwnsl(buf, len, sspl, sep, opt)
char *buf, *sep;
SSPL_S *sspl;
int len, opt;
{
	int	opt_0,opt_1,opt_2,opt_3,opt_4,opt_5,opt_6,opt_8,opt_9,opt_80,opt_400,opt_800;
	int i, l, pos, nsep, lmax, m,splen,in_opt;
	char *s, ch, *w, quat, *psep, cs;
	uchar pattr[4],code_type;

	if (!buf || !sspl) return -2;
	if (!sep) sep = gsep;

	if (sspl->sp < 0) sspl->sp = 0;
	pos = sspl->sp;
/*
printf("akxtgwnsl:Enter len=%d pos=%d buf=[%s]\n",len,pos,strmem(buf,len));
*/
	w = sspl->wd;
	lmax = sspl->wdmax;
	pattr[1] = 0;
	sspl->attr[0] = 0;
	sspl->attr[1] = 0;
	sspl->attr[2] = 0;
	sspl->attr[3] = 0;
	opt_2 = opt & 0x04;
	if (lmax && w) opt_5 = 1;
	else {
		opt_2 = 0;
		opt_5 = 0;
	}
	if (opt_5) *w = '\0';
	else sspl->wd = "";

	if (pos > len) {
/*
printf("akxtgwnsl:Exit2 pos=%d w=[%s]\n",pos,sspl->wd);
*/
		return -1;
	}
	else if (pos == len) {
		sspl->sp++;
/*
printf("akxtgwnsl:Exit1 pos=%d w=[%s]\n",sspl->sp,sspl->wd);
*/
		return 0;
	}

	nsep = strlen(sep);
	s = buf + pos;
	pattr[1] = 0;
	opt_0 = opt & 0x01;
	opt_1 = opt & 0x02;
	opt_3 = !(opt & 0x08);
	opt_4 = opt & 0x10;
	opt_6 = !(opt & 0x40);
	opt_8 = !(opt & (0x100 | 0x08));
	opt_9 = !(opt & (0x200 | 0x08));
	opt_80 = opt & 0x80;
	if (opt_400 = opt & 0x400) in_opt = 1;
	else in_opt = 0;
	opt_800 = opt & 0x800;
	if (opt & 0x08) opt_800 = 0;
	l = 0;

	if ((code_type=sspl->code) == CD_TYPE_SYSTEM) code_type = akxt_get_code_type();

	/* ��؂蕶���ȊO�������܂ŃX�L�b�v���� */
	if (opt_4) {
#if 1	/* 2021.4.20 */
		while((pos<len)&&((ch=*s)!='\0')) {
			if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
			m = akxqmbsnlen(code_type,s,len-pos);
			if (akxs_in_mem_opt(sep,nsep,s,m,in_opt) <= 0) {
				l = m;
				break;
			}
			s += m;
			pos += m;
		}
/*
printf("akxtgwnsl:opt_4: pos=%d l=%d\n",pos,l);
*/
#else
		while((pos<len)&&((ch=*s++)!='\0')) {
			if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
			for (i=0,psep=sep;i<nsep;i++) {
				cs = *psep++;
				if (opt_400) {
					ch = akxcupper(ch);
					cs = akxcupper(cs);
				}
				if (ch == cs) break;
			}
			if (i>=nsep) {
				l = 1;
				break;
			}
			pos++;
		}
#endif
		if (!ch) pos = len;	/* add 2023.3.4 NULL���������ꂽ��len�ɒB�������Ƃɂ��� */
		sspl->sp = pos;
		if (opt_5) *w = '\0';
		else sspl->wd = s;
/*
printf("akxtgwnsl:Exit3 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
		return l;
	}
	/* ��s�X�y�[�X�ƃ^�u���X�L�b�v���� */
	if (opt_0) {
#if 1	/* 2020.3.9 */
		while (pos<len && (ch=*s)) {
			if ((m=akxqmbsnlen(code_type,s,len-pos)) > 1) break;
			else if ((ch=*s)=='\\' && opt_80) {
				pos++;
				s++;
				if (pos < len) {
					if (!(m=akxqmbsnlen(code_type,s,len-pos))) m = 1;
					pos += m;
					s += m;
				}
			}
			else if (((ch=*s)==' ')||(ch=='\t')||
			         (!opt_6 && ((ch=='\n')||(ch=='\r')))) {
				pos++;
				s++;
			}
			else break;
#else
		while((pos<len)&&(((ch=*s)==' ')||(ch=='\t')||
		                  (!opt_6 && ((ch=='\n')||(ch=='\r'))))) {
			pos++;
			s++;
#endif
/*
printf("akxtgwnsl:1 pos=%d c=[%c]\n",pos,*s);
*/
		}
/*
printf("akxtgwnsl:2 pos=%d c=[%c]\n",pos,*s);
*/
		if (!ch) pos = len;	/* add 2023.3.4 NULL���������ꂽ��len�ɒB�������Ƃɂ��� */
		if (pos >= len) {
			sspl->sp = pos;
			if (opt_5) *w = '\0';
			else sspl->wd = s;
/*
printf("akxtgwnsl:Exit4 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
			return 0;
		}
	}
	if (!opt_5) sspl->wd = s;
	ch = *s;
#if 1	/* 2023.3.4 */
	if (!ch) {
		pos = len;	/* add 2023.3.4 NULL���������ꂽ��len�ɒB�������Ƃɂ��� */
		sspl->sp = pos;
		if (opt_5) *w = '\0';
		return 0;
	}
#endif
	m = akxqmbsnlen(code_type,s,len-pos);

/*	if (opt_3 && (pos<len) && (ch=='"' || ch=='\'')) {	*/
#if 1	/* 2020.3.9 */
  if (m == 1) {
	if (pos<len && ch=='\\' && opt_80) {	/* �G�X�P�[�v�����̏��� */
/*
printf("akxtgwnsl:4 pos=%d ch=[%c]\n",pos,ch);
*/
		pos++;
		s++;
		if (pos < len) {
#if 1
			if (!(m=akxqismbs(code_type,s))) m = 1;
			l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
			pos += m;
			s += m;
#else
			ch = *s;
			l = akxwdmax_chk(&w,pattr,lmax,l,ch);
			pos++;
			s++;
#endif
			ch = *s;
		}
	}
	else
#endif
	if ((pos<len) && ((ch=='"' && opt_9) || (ch=='\'' && opt_8) || (ch=='`' && opt_800))) {	/* ���p������ */
/*
printf("akxtgwnsl:5 pos=%d c=[%c]\n",pos,ch);
*/
		if (opt_1 && !opt_5) sspl->wd++;
		if (ch=='"') sspl->attr[0] = 6;
		else if (ch=='\'') sspl->attr[0] = 5;
		else if (ch=='`') sspl->attr[0] = 7;
		quat=ch;
		pos++;
		s++;
		if (!opt_1) {
			l = akxwdmax_chk(&w,pattr,lmax,l,ch);
		}
		while((pos<len)&&((ch=*s)!='\0')) {
/*
printf("akxtgwnsl:3 pos=%d c=[%c]\n",pos,ch);
*/
			if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
			if (m=akxqismbs(code_type,s)) {
				l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
				pos += m;
				s += m;
				sspl->attr[1] = 1;
			}
#if 1	/* 2020.3.9 */
			else if (ch=='\\' && opt_80) {
/*
printf("akxtgwnsl:5 pos=%d ch=[%c]\n",pos,ch);
*/
#if 1	/* add 2020.10.10 */
				l = akxwdmax_chk(&w,pattr,lmax,l,ch);
#endif
				pos++;
				s++;
				ch = *s;
				if (pos < len) {
					if (!(m=akxqismbs(code_type,s))) m = 1;
					l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
					pos += m;
					s += m;
				}
			}
#endif
			else {
				pos++;
				s++;
				if (ch == quat) {
					if ((pos >= len) || (*s != quat)) {
						if (!opt_1) {
							l = akxwdmax_chk(&w,pattr,lmax,l,ch);
						}
						if (opt_5) *w = '\0';
						sspl->sp = pos;
						if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit5 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
						return l;
					}
					else {
						sspl->attr[3] = 1;
						if (!opt_2) {
							l = akxwdmax_chk(&w,pattr,lmax,l,ch);
						}
						l = akxwdmax_chk(&w,pattr,lmax,l,quat);
						pos++;
						s++;
					}
				}
				else {
					l = akxwdmax_chk(&w,pattr,lmax,l,ch);
				}
			}
		}
		if (opt_5) *w = '\0';
		sspl->sp = pos;
		if (!opt_1) sspl->attr[2] = 1;
		if (pattr[1]) sspl->attr[2] |= 0x02;
/*
printf("akxtgwnsl:Exit6 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
		return l;
	}
  }
	/* ��؂蕶���̏��� */
#if 1	/* 2021.4.20 */
	m = akxqmbsnlen(code_type,s,len-pos);
	if (akxs_in_mem_opt(sep,nsep,s,m,in_opt)>0 || (ch=='`' && opt_800)) {
		l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
		if (opt_5) *w = '\0';
		pos += m;
		sspl->sp = pos;
		if (m > 1) ch = 0x7f;
		sspl->attr[0] = ch | 0x80;
		if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit7 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
		return l;
	}
#else
	for (i=0,psep=sep;i<nsep;i++) {
		cs = *psep++;
		if (opt_400) {
			ch = akxcupper(ch);
			cs = akxcupper(cs);
		}
		if (ch==cs) {
			l = akxwdmax_chk(&w,pattr,lmax,l,ch);
			if (opt_5) *w = '\0';
			pos++;
			sspl->sp = pos;
			sspl->attr[0] = ch | 0x80;
			if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit7 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
			return l;
		}
	}
#endif
	while ((pos<len)&&((ch=*s)!='\0')) {
/*
printf("akxtgwnsl: pos=%d ch=[%c]\n",pos,ch);
*/
		if (opt_6 && ((ch=='\n')||(ch=='\r'))) break;
#if 0	/* 2021.4.20 */
		if ((pos+1<len) && (m=akxqismbs(code_type,s))) {
			l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
			pos += m;
			s += m;
			sspl->attr[1] = 1;
		}
		else {
#endif
			if ((pos+1==len) && akxqismbs1(code_type,*s)) {
				pos++;
				break;
			}
			if ((pos<len) && ch=='\\' && opt_80) {
/*
printf("akxtgwnsl:6 pos=%d ch=[%c]\n",pos,ch);
*/
				pos++;
				s++;
#if 1	/* 2021.4.20 */
				m = akxqmbsnlen(code_type,s,len-pos);
				if (pos < len) {
					l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
					pos += m;
					s += m;
				}
#else
				ch = *s;
				if (pos < len) {
					l = akxwdmax_chk(&w,pattr,lmax,l,ch);
					pos++;
					s++;
				}
#endif
			}
			else {
				/* ��؂蕶���̏��� */
#if 1	/* 2021.4.20 */
				m = akxqmbsnlen(code_type,s,len-pos);
				if (akxs_in_mem_opt(sep,nsep,s,m,in_opt)>0 || (ch=='`' && opt_800)) {
#if 1
					break;
#else
					if (opt_5) *w = '\0';
					sspl->sp = pos;
					sspl->attr[0] = 1;
					if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit8 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
					return l;
#endif
				}
				l = akxwdmax_chkm(&w,pattr,lmax,l,s,m);
				pos += m;
				s += m;
#else
				for (i=0,psep=sep;i<nsep;i++) {
					if (ch==*psep++) {
						if (opt_5) *w = '\0';
						sspl->sp = pos;
						sspl->attr[0] = 1;
						if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit8 pos=%d l=%d w=[%s]\n",pos,l,sspl->wd);
*/
						return l;
					}
				}
				l = akxwdmax_chk(&w,pattr,lmax,l,ch);
				pos++;
				s++;
#endif
			}
#if 0	/* 2021.4.20 */
		}
#endif
	}
	if (opt_5) *w = '\0';
	sspl->sp = pos;
	if (l>0) sspl->attr[0] = 1;
	if (pattr[1]) sspl->attr[2] = 0x02;
/*
printf("akxtgwnsl:Exit pos=%d i=%d w=[%s]\n",pos,l,sspl->wd);
*/
	return l;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtgwns(buf, len, ssp, sep, opt)
char *buf, *sep;
SSP_S *ssp;
int len, opt;
{
	SSPL_S sspl;
	int ret;

	memcpy(&sspl,ssp,sizeof(SSP_S));
	if (opt & 0x20) sspl.wdmax = 0;
	else sspl.wdmax = -1;
	sspl.code = 0;
	ret = akxtgwnsl(buf,len,&sspl, sep, opt);
	memcpy(ssp,&sspl,sizeof(SSP_S));
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtgwse(buf, ssp, sep, opt)
char *buf, *sep;
SSP_S *ssp;
int opt;
{
	return akxtgwns(buf,INT_MAX,ssp,sep,opt);
}

/********************************************************/
/*														*/
/********************************************************/
int akxtgwsp(buf, ssp)
char *buf;
SSP_S *ssp;
{
	return akxtgwse(buf,ssp,gsep,0x01);
}

/********************************************************/
/*														*/
/********************************************************/
int akxtpknsl(s, slen, ssp, sep, opt)
char *s, *sep;
SSPL_S *ssp;
int slen, opt;
{
	int pos,len;

	if (!ssp) return -1;
	pos = ssp->sp;
	len = akxtgwnsl(s,slen,ssp,sep,opt);
	ssp->sp = pos;
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtpkns(s, slen, ssp, sep, opt)
char *s, *sep;
SSP_S *ssp;
int slen, opt;
{
	int pos,len;

	if (!ssp) return -1;
	pos = ssp->sp;
	len = akxtgwns(s,slen,ssp,sep,opt);
	ssp->sp = pos;
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int akxcctox(puc,len,pux)
uchar *puc,*pux;
int len;
{
	int sw,m,n;
	uchar *pucw,*puxw,uc;

	if (!(pucw=puc) || !(puxw=pux)) return -1;
	n = len;
	m=sw=0;
	while (n--) {
		uc = *pucw++;
 		if   ((uc>='0') && (uc<='9')) uc -= '0';
		else if ((uc>='A') && (uc<='F')) uc -= 'A' - 10;
		else if ((uc>='a') && (uc<='f')) uc -= 'a' - 10;
		else uc = 0;
		if (sw) {
			*puxw |= uc;
			sw=0;
			puxw++;
		}
		else {
			*puxw = uc<<4;
			sw=1;
			m++;
		}
	}
	return m;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtsrepc(s,cs,cd)
char *s,cs,cd;
{
	int n=0;
	char c;

	while (c=*s) {
		if (c == cs) {
			n++;
			*s = cd;
		}
		s++;
	}
	return n;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxt_get_last_name(delm,path)
char *delm, *path;
{
	int len, i;
	char *name, *p;

	if (!path) return NULL;
	if (!delm) return path;
	if (!(*delm)) return path;

	len = strlen(name=path);
	i = akxnrskipto(name,len,delm);
	if (i >= 0) name += i;
	return name;
}

/********************************************************/
/*														*/
/********************************************************/
int akxcxtoc(s,len,d)
char *s, *d;
int len;
{
	int i;
	uchar ucH, ucL;

	for (i=0;i<len;i++) {
		ucH = *s >> 4 & 0x0F;
		ucL  = *s++ & 0x0F;
		if (ucH >= 10) *d++ = (ucH-10) + 'a';
		else *d++ = ucH + '0';
		if (ucL >= 10) *d++ = (ucL-10) + 'a';
		else *d++ = ucL + '0';
	}
	return len*2;
}

/********1*********2*********3*********4*********5*********6**********7**/
/* ���� : akxcxtocn														*/
/* �@�\ : �\�[�X�f�[�^���o�C�g�P�ʂ�16�i�\���ɕϊ�����B				*/
/*		  interval0<>0 �̂Ƃ��́A���̊Ԋu�ŃX�y�[�X������B���̂Ƃ��A */
/*		  �Ō�̃X�y�[�X�͏o�͂��Ȃ��B									*/
/* ���� : IN    s        : �\�[�X�f�[�^									*/
/*				len      : �\�[�X�f�[�^�̃o�C�g��						*/
/*				d        : �o�͈�										*/
/*				mlen     : �o�͈�̃o�C�g��(�I�[��null���܂�)			*/
/*				interval0: �X�y�[�X�o�͊Ԋu(�\�[�X�f�[�^�ł̃o�C�g��)	*/
/*							=0 : len�������							*/
/*							<0 : �o�͊Ԋu�����S�ă[���̂Ƃ��A'Z'���o��	*/
/* �ԋp : �ϊ��o�C�g��(�I�[��null���܂܂Ȃ�)							*/
/************************************************************************/
int akxcxtocn(s,len,d,mlen,interval0)
char *s, *d;
int len,mlen,interval0;
{
	int i,m,n,interval,interval1;
	char c,*p;

	n = 0;
	if ((interval1=interval0) < 0) interval1 = -interval1;
	interval = interval1;
	if (!interval) interval = len;
	if (interval > len) interval = len;
/*
printf("akxcxtocn:Enter: len=%d mlen=%d interval0=%d interva=%d\n",len,mlen,interval0,interval);
*/
	mlen--;
	while (len > 0) {
		if (mlen < 2) break;
		if (len < interval) interval = len;
		if (mlen/2 < interval) interval = mlen/2;
/*
printf("akxcxtocn: mlen=%d interval=%d\n",mlen,interval);
*/
		c = ' ';
		if (interval0<0 && interval==interval1) {
			c = '\0';
			p = s;
			for (i=0;i<interval;i++) c |= *p++;
		}
		if (!c && interval>1) {
		/*	*d = '0';
			*(d+1) = '*';
			m = 2;	*/
			*d = 'Z';
			m = 1;
		}
		else m = akxcxtoc(s,interval,d);
		len -= interval;
		s += interval;
		d += m;
		*d++ = ' ';
		m++;
		n += m;
		mlen -= m;
	}
	if (*(d-1) == ' ') {
		d--;
		n--;
	}
	*d = '\0';
	return n;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxt_add_dir2(cpDir,cpFile,cppPath)
char *cpDir,*cpFile,**cppPath;
{
	char *cpPath;
	char *p;
	int len;

	if (!cpDir) return cpFile;
	if (!(*cpDir)) return cpFile;
	if (!cpFile || !*cpFile) return cpDir;
	if (*cpFile == '/') return cpFile;
	if (!cppPath) return NULL;

	cpPath = *cppPath;
	len = strlen(cpDir) + strlen(cpFile) + 2 + 8;
	if (cpPath) {
		if (!(cpPath=Realloc(cpPath,len))) return NULL;
	}
	else {
		if (!(cpPath=Malloc(len))) return NULL;
	}
	strcpy(cpPath,cpDir);
	p = cpPath + strlen(cpPath);
	if (*(p-1) != '/') *p++ = '/';
	strcpy(p,cpFile);
	*cppPath = cpPath;
	return cpPath;
}

/********************************************************/
/*														*/
/********************************************************/
int akxt_set_bits(ipBits,iMask,iSet)
int *ipBits,iMask,iSet;
{
	int b,m,i;

	b = *ipBits;
	m = iMask;
	if (i=iSet) {
		if (i < 0) b &= ~m;
		else if (i == 1) b |= m;
		else b = m;
		*ipBits = b;
	}
	return b & m;
}
/****************************************/
/*	Get General-Purpose Data			*/
/*		coded by A.Kobayashi 2003.11.19	*/
/****************************************/
int akxt_get_gep_data(klen,p,kpp,plalen)
int  klen;
char *p,**kpp;
int  *plalen;
{
	int  lalen;
	INT4 lklen;

	if (!p) return -1;
	if (klen>0) lalen=lklen=klen;
	else if (klen<0) {
		memcpy(&lklen,p,sizeof(INT4));
		if (lklen<0) return -2;
		p += sizeof(INT4);
		lalen=lklen+sizeof(INT4);
	}
	else {
		lklen=strlen(p);
		lalen=lklen+1;
	}
	if (kpp) *kpp = p;
	if (plalen) *plalen = lalen;
	return lklen;
}

/****************************************/
/*	Cmp General-Purpose Data			*/
/*	klen  : >0 : �Œ蒷					*/
/*			=0 : string					*/
/*			<0 : len+key				*/
/*	kp    : ��r��L�[�A�h���X			*/
/*	lklen : ��r��L�[��				*/
/*	p     : ��r���L�[�A�h���X			*/
/*			�`����klen�ɂ��			*/
/*	opt   : 0x01 : ignore case			*/
/*		coded by A.Kobayashi 2003.11.25	*/
/****************************************/
int akxt_cmp_gep_data_opt(klen,kp,lklen,p,opt)
int  klen,lklen,opt;
char *kp,*p;
{
	INT4 ldlen;
	int  s,iCASE;

	if (!kp || !p) return -256;
	iCASE = opt & 0x01;
	if (klen>0) {
		if (iCASE) s = akxmemicmp(kp,p,lklen);
		else s = memcmp(kp,p,lklen);
	}
	else {
		if (klen<0) {
			memcpy(&ldlen,p,sizeof(INT4));
			if (ldlen<0) return -257;
			if (!(s=ldlen-lklen)) {
				if (iCASE) s = akxmemicmp(kp,p,lklen);
				else s = memcmp(kp,p+sizeof(INT4),lklen);
			}
		}
		else {
			if (iCASE) s = akxstricmp(kp,p);
			else s = strcmp(kp,p);
		}
	}
	return s;
}

/********************************************************/
/*														*/
/********************************************************/
int akxt_cmp_gep_data(klen,kp,lklen,p)
int  klen,lklen;
char *kp,*p;
{
	return akxt_cmp_gep_data_opt(klen,kp,lklen,p,0);
}

/********************************************************/
/*														*/
/********************************************************/
tdtCONV_MSG_HEAD *akxc_conv_msg_new(mesg)
tdtMESSAGES mesg[];
{
	tdtCONV_MSG_HEAD *p;

	if (p=(tdtCONV_MSG_HEAD *)Malloc(sizeof(tdtCONV_MSG_HEAD))) {
		p->cmh_try      = 1;
		p->cmh_langmax  = -1;
		p->cmh_no_max   = 0;
		p->cmh_messages = mesg;
		p->cmh_index    = NULL;
		p->cmh_xhp      = NULL;
		akxc_conv_msg(p,1,0);
	}
	return p;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxc_conv_msg(cmh,no,lang)
tdtCONV_MSG_HEAD *cmh;
int no,lang;
{
	tdtRB_CHAIN *xhp;
	tdtMESSAGES *mesg,*me,**index;
	int  langmax,no_max,i,k,ix,reg_max;
	char *p;

	if (!cmh) return NULL;
	if (!(mesg=cmh->cmh_messages)) return NULL;
	me = &mesg[0];
	if (no <= 0) return (char *)me->mm_msg;

	xhp   = cmh->cmh_xhp;
	index = cmh->cmh_index;
	p = "";
	if (cmh->cmh_try && !xhp && !index) {
		cmh->cmh_try = 0;
		for (k=0;k<3;k++) {
			if (!me->mm_msg[k] || !*me->mm_msg[k]) break;
		}
		cmh->cmh_langmax = k - 1;
		no_max = k = 0;
		reg_max = me->mm_msgno;
		me++;
		for (;(i=me->mm_msgno)>=0;me++) {
			k++;
			if (i > no_max) no_max = i;
		}
		cmh->cmh_no_max = no_max;
/*
printf("akxc_conv_msg: langmax=%d msg_count=%d no_max=%d\n",cmh->cmh_langmax,k,no_max);
*/
		if (k > no_max/2) {
			if (index = (tdtMESSAGES **)Malloc(sizeof(tdtMESSAGES *)*no_max)) {
				memset(index,0,sizeof(tdtMESSAGES *)*no_max);
				for (me=&mesg[1];(i=me->mm_msgno)>=0;me++) {
					index[i-1] = me;
				}
			}
		}
		if (!index && k>100) {
			if (reg_max <= 0) reg_max = k;
			if (xhp=akxs_xhasl_new(sizeof(int),reg_max,0,0)) {
				for (me=&mesg[1];(i=me->mm_msgno)>=0;me++) {
					if (akxs_xhasl(xhp,'S',i,&me) <= 0) {
						akxs_xhasl_free(xhp);
						xhp = NULL;
						break;
					}
				}
			}
		}
		cmh->cmh_xhp   = xhp;
		cmh->cmh_index = index;
/*
printf("akxc_conv_msg: xhp=%08x index=%08x\n",xhp,index);
*/
	}
	langmax = cmh->cmh_langmax;
	no_max  = cmh->cmh_no_max;
	ix = 0;
	if ((lang>=0 && lang<=langmax) && no<=no_max) {
		if (index) {
			if (me = index[no-1]) ix = no;
		}
		else if (xhp) {
			ix = akxs_xhasl(xhp,'R',no,&me);
		}
		else {
			for (me=&mesg[1];(i=me->mm_msgno)>=0;me++) {
				if (i == no) {
					ix = i;
					break;
				}
			}
		}
		if (ix > 0) {
			p = me->mm_msg[lang];
			if (!p || !*p) {
				for (k=lang+1;k<=langmax;k++) {
					if ((p=me->mm_msg[k]) && *p) break;
				}
			}
		}
	}
/*
printf("akxc_conv_msg: no=%d ix=%d\n",no,ix);
*/
	return p;
}

/********************************************************/
/*														*/
/********************************************************/
int akx_get_gen_int_data(p)
tdtGENERAL_DATA *p;
{
	int len,i=0;
	short s;
	char *pd;

	if (p && (pd=p->gd_data)) {
		if (len == 4) memcpy(&i,pd,sizeof(INT4));
		else if ((len=p->gd_dlen) == 2) {
			memcpy(&s,pd,sizeof(short));
			i = s;
		}
		else i = *(uchar *)pd;
	}
	return i;
}

/********************************************************/
/*														*/
/********************************************************/
void printtx(msg,p,len)
char *msg,*p;
int len;
{
	int i;

	printf("%s:",msg);
	printf(" len=%d text=[",len);
	for (i=0;i<len;i++) printf("%c",*p++);
	printf("]\n");
}

/********************************************************/
/*														*/
/********************************************************/
int mem_set_int(a0,val,n)
int *a0,n,val;
{
	int ret,*a;

	ret = n;
	if (a = a0) {
		while (n-- > 0) *a++ = val;
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_cpy_int(d0,s0,n)
int *d0,*s0,n;
{
	int ret,*d,*s;

	if (d = d0) {
		ret = n;
		if (n>0 && (s=s0)) {
			while (n-- > 0) *d++ = *s++;
		}
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_rcpy_int(d0,s0,n)
int *d0,*s0,n;
{
	int ret,*d,*s;

	if (!d0) ret = -1;
	else {
		ret = n;
		if (n>0 && s0) {
			d = d0 + n -1;
			s = s0 + n -1;
			while (n-- > 0) *d-- = *s--;
		}
	}
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_sum_byte(s,n)
uchar *s;
int n;
{
	int ret;

	ret = 0;
	if (s) {
		while (n-- > 0) ret += *s++;
	}
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_sum_int(s,n)
int *s,n;
{
	int ret,i;

	ret = 0;
	if (s) {
		while (n-- > 0) ret += *s++;
	}
	return ret;
}

#if defined(_LP64)
/********************************************************/
/*														*/
/********************************************************/
int mem_set_long(a0,val,n)
long *a0,val;
int n;
{
	int ret;
	long *a;

	ret = n;
	if (a = a0) {
		while (n-- > 0) *a++ = val;
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_cpy_long(d0,s0,n)
long *d0,*s0;
int n;
{
	int ret;
	long *d,*s;

	if (d = d0) {
		ret = n;
		if (n>0 && (s=s0)) {
			while (n-- > 0) *d++ = *s++;
		}
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_rcpy_long(d0,s0,n)
long *d0,*s0;
int n;
{
	int ret;
	long *d,*s;

	if (d0) {
		ret = n;
		if (n>0 && s0) {
			d = d0 + n -1;
			s = s0 + n -1;
			while (n-- > 0) *d-- = *s--;
		}
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_sum_long(s0,n)
long *s0;
int n;
{
	int ret;
	long *s;

	ret = 0;
	if (s = s0) {
		while (n-- > 0) ret += *s++;
	}
	return ret;
}
#else
/********************************************************/
/*														*/
/********************************************************/
int mem_set_long(a,val,n)
long *a,val;
int n;
{
	return mem_set_int(a,val,n);
}

/********************************************************/
/*														*/
/********************************************************/
int mem_cpy_long(d,s,n)
long *d,*s;
int n;
{
	return mem_cpy_int(d,s,n);
}

/********************************************************/
/*														*/
/********************************************************/
int mem_rcpy_long(d,s,n)
long *d,*s;
int n;
{
	return mem_rcpy_int(d,s,n);
}

/********************************************************/
/*														*/
/********************************************************/
int mem_sum_long(s,n)
long *s;
int n;
{
	return mem_sum_int(s,n);
}
#endif

/********************************************************/
/*														*/
/********************************************************/
int mem_set_addr(d0,val,n)
char *d0[],*val;
int n;
{
	int ret;
	char **d;

	if (d = d0) {
		ret = n;
		while (n-- > 0) *d++ = val;
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_cpy_addr(d0,s0,n)
char *d0[],*s0[];
int n;
{
	int ret;
	char **d,**s;

	if (d = d0) {
		ret = n;
		if (n>0 && (s=s0)) {
			while (n-- > 0) *d++ = *s++;
		}
	}
	else ret = -1;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_rcpy_addr(d0,s0,n)
char *d0[],*s0[];
int n;
{
	int ret;
	char **d,**s;

	if (!d0) ret = -1;
	else {
		ret = n;
		if (n>0 && s0) {
			d = d0 + n - 1;
			s = s0 + n - 1;
			while (n-- > 0) *d-- = *s--;
		}
	}
	return ret;
}

/********************************************************/
/*														*/
/*							0x01 : ����			*/
/*							0x02 : �p��			*/
/*							0x04 : �L��			*/
/*							0x08 : ���p�J�i			*/
/*							0x10 : ���p			*/
/*							0x20 : �S�p			*/
/*							0x40 : ���l(+-.0-9,EDF)			*/
/*							0x80 : ���O(�擪 A-Z,�S�p,���p�J�i)	*/
/*							0x100: - ����				*/
/*							0x200: . ����				*/
/********************************************************/
int akxq_char_kind(s,s_len,opt)
char *s;
int  s_len,opt;
{
	int i,opt4,ret,m,n;
	int x1,x2,x4,x8,x10,x20,x40,x80,x100,x200;
	char c,w[4];

	opt4 = opt & 0x04;
	x1=x2=x4=x8=x10=x20=x100=x200=0;
	x40=0x40;
	x80=0x80;
	i = 0;
	while (i < s_len) {
		m = n = akxqkanjilen2(s,s_len);
		if (m == 1) {
			x10 = 0x10;
		}
		else if (akxqis_hankaku_kana(s,m)) {
			x8 = 8;
		}
		else {
			x20 = 0x20;
			if (opt4) {
				m = akxctohan(m,s,w);
				if (m == 1) c = *w;
				else if (akxqis_hankaku_kana(w,m)) x8 = 8;
			}
			else x40 = 0;
		}
		if (m == 1) {
			c = akxcupper(c);
			if (c>='0' && c<='9') {
				x1 = 1;
				if (!i) x80 = 0;
			}
			else if (c>='A' && c<='Z') {
				x2 = 2;
				if (!(c=='D' || c=='E' || c=='F')) x40 = 0;
			}
			else if (c>=161 && c<=223) {
				x8 = 8;
			}
			else {
				x4 = 4;
				if (c == '.') {
					x200 = 0x200;
				}
				else if (c == '+') {
					x80 = 0;
				}
				else if (c == '-') {
					x100 = 0x100;
				}
				else if (c == '_') {
					x40 = 0;
				}
				else {
					x80 = x40 = 0;
				}
			}
		}
		i += n;
		s += n;
	}
	ret = x1 *+ x2 + x4 + x8 + x10 + x20 + x40 + x80;
	if (opt4) ret += x100 + x200;
	return ret;
}

/********************************************/
/*											*/
/********************************************/
char *nval1(p)
char *p;
{
	if (!p) p = "(null)";
	return p;
}

/********************************************/
/*											*/
/********************************************/
char *nval(p,p1)
char *p,*p1;
{
	if (!p) {
		p = p1;
		p = nval1(p);
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
char *nvalid(p,p1)
char *p,*p1;
{
	if (!akxm_addrchk(p)) {
		p = p1;
		if (!akxm_addrchk(p)) p = "(invalid)";
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
int mem_cmp_int(p1,p2,n)
int *p1,*p2;
int  n;
{
	int i,d;

	if (!p1 && !p2) d = 0;
	else if (!p1) d = -1;
	else if (!p2) d = 1;
	else {
		while (n-- > 0) {
			d = *p1++ - *p2++;
			if (d) break;
		}
	}
	return d;
}

/********************************************************/
/*														*/
/********************************************************/
int mem_cmp_int_n(p1,n1,p2,n2)
int *p1,*p2,n1,n2;
{
	int d;

	if (!p1 && !p2) d = 0;
	else if (!p1) d = -1;
	else if (!p2) d = 1;
	else {
		if (!n1 && !n2) d = 0;
		else if(n1 < n2) {
			if (!(d = mem_cmp_int(p1,p2,n1))) d = -1;
		}
		else if(n1 > n2) {
			if (!(d = mem_cmp_int(p1,p2,n2))) d = 1;
		}
		else
			d = mem_cmp_int(p1,p2,n1);
	}
	return d;
}

#if defined(_LP64)
/********************************************************/
/*														*/
/********************************************************/
long x_htonll(x)
long x;
{
	char w[8],*p,*ww,*pp;
	int i;

	pp = p = (char *)&x;
	ww = w + 7;
	for (i=0;i<8;i++) *ww-- = *pp++;
	memcpy(p,w,8);
	return x;
}
long x_ntohll(x)
long x;
{
	return x_htonll(x);
}
#endif

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/* 0x01 : ��؂蕶���̑啶������������ʂ��Ȃ��B						*/
/* 0x02 : �O��̃X�y�[�X�ƃ^�u���폜����B								*/
/* 0x04 : max_argv����؂�񐔂ƌ��Ȃ��Amax_argv+1�ɕ�������B		*/
/* 0x08 : ��؂蕶���̂ǂꂩ���A������Ƃ��́A1�̋�؂蕶���ƌ��Ȃ��B	*/
/* 0x10 : sep==NULL��sep_len<=0�̂Ƃ��ɁA�J���}����؂蕶���ɉ�����B	*/
/************************************************************************/
int akxtnsplit(buf,buf_len,argv,maxargv,parm,parm_len,sep,sep_len,opt)
char *buf,*argv[],*parm,*sep;
int buf_len,maxargv,parm_len,sep_len,opt;
{
	char *p,*pm,*pp,ssep[4];
	int len,pmlen,splen,m,n,pos,opt02,opt04,opt08,mlen,gw_opt,in_opt,code_type,iSETW;
	SSPL_S sspl;

	if (!(p=buf) || !argv || !(pm=parm)) return -1;
/*
printf("akxtnsplit: buf_len=%d buf=[%s] sep_len=%d sep=[%s]\n",buf_len,buf,sep_len,sep);
printf("akxtnsplit: parm_len=%d opt=%08x\n",parm_len,opt);
*/
	if ((len=buf_len)<=0 || maxargv<=0 || (pmlen=parm_len)<=0) return 0;
	opt02 = opt & 0x02;
	opt04 = opt & 0x04;
	opt08 = opt & 0x08;
	code_type = opt & 0x7f000000;
	in_opt = opt & 0x03;
	if (opt & 0x01) gw_opt = 0x400;
	else gw_opt = 0;
	gw_opt |= 0x06;	/* �O��̈��p��(2�d���p��)���O�� + �����̘A������2�̈��p��(2�d���p��)��1�ɂ��� */
	if (!sep || (splen=sep_len)<=0) {
		sep = ssep;
		memcpy(sep," \t",3);
		if (opt & 0x10) memcpy(sep+2,",",2);
		splen = strlen(sep);
	}
	memset(&sspl,0,sizeof(SSPL_S));
	in_opt |= code_type;
	code_type >>= 24;
	sspl.code = code_type;
	n = 0;
	len = buf_len;
	pp = pm;
	*pp = '\0';
	iSETW = 0;
	while (len > 0) {
		/*  */
		if (opt08)
			pos = akxn_skip_opt(p,len,sep,splen,in_opt);
		else if (len > 0) {
			pos = akxqmbsnlen(code_type,p,len);
			if (akxs_in_mem_opt(sep,splen,p,pos,in_opt) <= 0) pos = 0;
		}
		else pos = 0;
		if (pos > 0) {
			if (!iSETW) {
				*pm = '\0';
				argv[n++] = pm;
				pm++;
				pmlen--;
			}
			p += pos;
			len -= pos;
			iSETW = 0;
/*
printf("akxtnsplit:1: iSETW=%d pos=%d len=%d n=%d pmlen=%d\n",iSETW,pos,len,n,pmlen);
*/
			if (n >= maxargv) break;
		}
		else {
		/*  */
			sspl.sp = 0;
			sspl.wd = pm;
			sspl.wdmax = pmlen - 1;
			pos = akxtgwnsl(p,len,&sspl,sep,gw_opt);
			if (pmlen <= pos) break;
		/*	memzcpy(pm,p,pos);	*/
			mlen = pos;
			if (opt02 && sspl.attr[0]!=5 && sspl.attr[0]!=6) mlen = akxttrim(0,pm,pos);
			argv[n++] = pm;
			if (!opt04 && n>=maxargv) break;
			p += sspl.sp;
			len -= sspl.sp;
			mlen++;
			pm += mlen;
			pmlen -= mlen;
			iSETW = 1;
/*
printf("akxtnsplit:2: iSETW=%d pos=%d len=%d n=%d pmlen=%d\n",iSETW,pos,len,n,pmlen);
*/
		}
		pp = pm - 1;
	}
	if (opt04 && pmlen>0) {
		mlen = memnzcpy(pm,p,len,pmlen);
		if (opt02) akxttrim(0,pm,mlen);
		argv[n++] = pm;
	}
	m = n;
	while (n < maxargv) argv[n++] = pp;
	return m;
}

/********1*********2*********3*********4*********5*********6*********/
/* �@�\ : �Œ蒷�v�f��̔�r�֐�									*/
/* ���� : c_arg   : �t�����										*/
/*					c_arg[0] : opt									*/
/*						opt : 0x01 : = 0 / 1 : ���� / �~��			*/
/*							  0x02 : = 0 / 1 : ���� / �����L���l��	*/
/*												��r����			*/
/*									���l�̂Ƃ��́A�L�[���Ō^�����܂�*/
/*										<= 1   : char				*/
/*										 = 2   : short				*/
/*										<= 4   : int				*/
/*										���̑� : long				*/
/*					c_arg[1] : mlen �v�f�� (�o�C�g)					*/
/*					c_arg[2] : �L�[�̈ʒu (�擪��0)					*/
/*					c_arg[3] : �L�[�� (�o�C�g)						*/
/*		  a       : ��r�̍��ӗv�f�̐擪�A�h���X					*/
/*		  b       : ��r�̉E�ӗv�f�̐擪�A�h���X					*/
/* �ԋp : ��r����													*/
/*			> 0 : ���ӗv�f > �E�ӗv�f								*/
/*			= 0 : ���ӗv�f = �E�ӗv�f								*/
/*			< 0 : ���ӗv�f < �E�ӗv�f								*/
/********************************************************************/
static int _cmp_qsort_r(c_arg,a,b)
char *c_arg,*a,*b;
{
	int *arg,mlen,opt,dif,klen;
	short sa,sb;
	long la,lb;
	char ca,cb;
/*
printf("_cmp_qsort_r: a=%08x b=%08x c_arg=%08x\n",a,b,c_arg);
*/
	arg = (int *)c_arg;
	opt  = arg[0];
	mlen = arg[1];
	klen = arg[3];
	a += arg[2];
	b += arg[2];
/*
printf("_cmp_qsort_r: mlen=%d opt=%d\n",mlen,opt);
*/
	if (opt & 0x02) {
		if (klen <= sizeof(char))
			dif = *a - *b;
		else if (klen <= sizeof(short))
			dif = *(short *)a - *(short *)b;
		else if (klen <= sizeof(int))
			dif = *(int *)a - *(int *)b;
		else
			dif = *(long *)a - *(long *)b;
	}
	else {
		dif = memcmp(a,b,klen);
	}
	if (opt & 0x01) dif = -dif;
/*
printf("_cmp_qsort_r: dif=%d\n",dif);
*/
	return dif;
}

/********1*********2*********3*********4*********5*******/
/* �@�\ : �Œ蒷�v�f��������^�~���Ƀ\�[�g����			*/
/* ���� : sel_str : �\�[�g�Ώۗ̈�						*/
/*		  max_sel : �v�f��								*/
/*		  mlen    : �v�f�̒���(�o�C�g)					*/
/*		  posa    : �L�[�̈ʒu NULL�̂Ƃ��́A���ׂ�		*/
/*					posa[0] : �J�n�ʒu (�擪��0)		*/
/*					posa[1] : ����(�o�C�g)				*/
/*		  opt     : �I�v�V���� _cmp_qsort_r()���Q��		*/
/* �ԋp : = 0 : ����									*/
/*		  < 0 : �G���[									*/
/********************************************************/
int akxnmstrsort2(sel_str,max_sel,mlen,posa,opt)
char *sel_str;
int max_sel,mlen,posa[],opt;
{
	char max_c,c,*p,*p_max_c,*p_c,wrk[256],*p_i;
	char w1[256],w2[256];
	int i,j,max_i,dif,arg[4];
/*
printf("akxnstrsort_opt: sort : opt=%d max_sel=%d sel_str=[%s]\n",opt,max_sel,sel_str);
*/
	if (!(p=sel_str) || (mlen>sizeof(wrk))) return -1;
	if (max_sel<=0 || mlen<=0) return 0;
#if 1
	arg[0] = opt;
	arg[1] = mlen;
	if (posa) {
		arg[2] = posa[0];
		arg[3] = posa[1];
	}
	else {
		arg[2] = 0;
		arg[3] = mlen;
	}
/*	akxqsort_r(sel_str,max_sel,mlen,_cmp_qsort_r,arg);	*/
	qsort_r(sel_str,max_sel,mlen,arg,_cmp_qsort_r);
#else
	p = sel_str;
	p_i = p;
	for (i=0;i<max_sel-1;i++,p_i+=mlen) {
		p_max_c = p_i;
	/*	max_c = sel_str[i];	*/
		max_i = i;
		p_c = p_i + mlen;
		for (j=i+1;j<max_sel;j++,p_c+=mlen) {
		/*	c = sel_str[j];
			if ((!opt && c<max_c) || (opt && c>max_c)) {
				max_c = c;
				max_i = j;
			}*/
			dif = memcmp(p_c,p_max_c,mlen);
			memzcpy(w1,p_c,mlen);
			memzcpy(w2,p_max_c,mlen);
/*
printf("i=%d j=%d dif=%d p_c=[%s] p_max_c=[%s]\n",i,j,dif,w1,w2);
*/
			if (opt) dif = -dif;
			if (dif < 0) {
				p_max_c = p_c;
				max_i = j;
			}
		}
		if (max_i != i) {
		/*	c = sel_str[i];
			sel_str[i] = max_c;
			sel_str[max_i] = c;	*/
			memcpy(wrk,p_i,mlen);
			memcpy(p_i,p_max_c,mlen);
			memcpy(p_max_c,wrk,mlen);
		}
	}
/*
printf("akxnstrsort_opt: sort : sel_str=[%s]\n",sel_str);
*/
#endif
	return 0;
}

int akxnmstrsort_opt(sel_str,max_sel,mlen,opt)
char *sel_str;
int max_sel,mlen,opt;
{
	return akxnmstrsort2(sel_str,max_sel,mlen,NULL,opt);
}

/********************************************************/
/*	������������^�~���Ƀ\�[�g����						*/
/*		opt : =0 / <>1 : ���� / �~��					*/
/********************************************************/
int akxnstrsort_opt(sel_str,max_sel,opt)
char *sel_str;
int max_sel,opt;
{
	return  akxnmstrsort_opt(sel_str,max_sel,1,opt);
}

/********************************************************/
/*	����������ւ���֐�								*/
/********************************************************/
void akxtswap_mem(a,b,size)
char *a,*b;
int size;
{
	char tmp;

	while (size--) {
		tmp = *b;
		*b = *a;
		*a = tmp;
		a++;
		b++;
	}
}

/********************************************************/
/*														*/
/********************************************************/
static void _swap(a,b,size)
char *a,*b;
int size;
{
	akxtswap_mem(a,b,size);
}

/********************************************************/
/*	�N�C�b�N�\�[�g���s���֐�							*/
/********************************************************/
static void QuickSort_r(dat,iSta,iEnd,size,_compar,arg)
char *dat;
int iSta,iEnd,size;
int (*_compar)();
char *arg;
{
	int iBaseNum,iCnt,i,ii;
	char strBaseVal[256],*p_i,*p_cnt,*p_sta;
/*
printf("QuickSort_r: iSta=%d iEnd=%d size=%d\n",iSta,iEnd,size);
*/
	if (iSta >= iEnd) return;
	iBaseNum = (iSta + iEnd) / 2;
	memcpy(strBaseVal,dat+iBaseNum*size,size);
	memcpy(dat+iBaseNum*size,dat+iSta*size,size);
	iCnt = iSta;
	p_sta = p_cnt = dat + iSta*size;
	p_i = p_sta + size;
	for (i = iSta + 1;i<=iEnd;i++) {
/*
printf("QuickSort_r: i=%d\n",i);
*/
		if (_compar(p_i,strBaseVal,arg) < 0) {
			iCnt++;
			p_cnt += size;
			_swap(p_cnt,p_i,size);
		}
		p_i += size;
	}
	memcpy(p_sta,p_cnt,size);
	memcpy(p_cnt,strBaseVal,size);
	QuickSort_r(dat,iSta,iCnt-1,size,_compar,arg);
	QuickSort_r(dat,iCnt+1,iEnd,size,_compar,arg);
	return;
}

/********************************************************/
/*														*/
/********************************************************/
void akxqsort_r(a,nmenb,size,_compar,arg)
char *a;
int nmenb,size;
int (*_compar)();
char *arg;
{
	QuickSort_r(a,0,nmenb-1,size,_compar,arg);
	return;
}

/********************************************************/
/*														*/
/********************************************************/
static int _compar_inx_vdat(a,b,c_arg)
char *a,*b,*c_arg;
{
	char **ca,**cb,*aa,*bb;
	int  opt,dif,ia,ib,*arg;

	arg = (int *)c_arg;
	opt = arg[0];
	a += sizeof(int);
	b += sizeof(int);
	if (opt & 0x08) {
		ia = *(int *)a;
		ib = *(int *)b;
/*
printf("_compar_inx_vdat: ia=%d ib=%d\n",ia,ib);
*/
		dif = ia - ib;
	}
	else {
		aa = *(char **)a;
		bb = *(char **)b;
/*
printf("_compar_inx_vdat: aa=[%s] bb=[%s]\n",aa,bb);
*/
		dif = strcmp(aa,bb);
	}
	return dif;
}

/********************************************************/
/*														*/
/********************************************************/
static void _set_of_index(s,nDat,size,dat0,mlen)
char *s,*dat0;
int nDat,size,mlen;
{
	char *p,*pp,*dat;
	int i,index;

	p = s;
	dat = dat0;
	for (i=0;i<nDat;i++) {
		memcpy(&index,p,sizeof(int));
/*
printf("_set_of_index: index=%d\n",index);
*/
		pp = p + sizeof(int);
		memcpy(pp,dat+index*mlen,mlen);
		p += size;
	}
	p = s;
	dat = dat0;
	for (i=0;i<nDat;i++) {
		pp = p + sizeof(int);
		memcpy(dat,pp,mlen);
		p += size;
		dat += mlen;
	}
}

/********1*********2*********3*********4*********5*********6*********/
/*  ���� : str_sort_inx_vdat										*/
/*  �@�\ : ������z��\�[�g����(�C���f�b�N�X�A���̑��f�[�^�t��)		*/
/*  ���� : IN	  : dat0()    : string data array					*/
/*					nDat      : number of dat()						/*
/*					inx0()    : index array of data					/*
/*					vdat()    : variant data array					*/
/*					Opt       : �I�v�V����							*/
/*								0x01 = 0 : ����						*/
/*									 = 1 : �~��						*/
/*								0x02 = 1 : inx���\�[�g�ΏۂƂ���	*/
/*								0x04 = 1 : vdat���\�[�g�ΏۂƂ���	*/
/*								0x08 = 0 : dat()���\�[�g�L�[�Ƃ���	*/
/*									 = 1 : inx()���\�[�g�L�[�Ƃ���	*/
/*		   OUT	  : dat()											*/
/*					inx()											*/
/*					vdat()											*/
/*  �쐬 : 2016/04/06 Akito Kobayashi								*/
/*  �X�V : 2018/06/25 Akito Kobayashi Add opt=0x08					*/
/*	�X�V : 2023/04/04 Akito Kobayashi use akxqsort_r()				*/
/********************************************************************/
int akxstrsort_inx_vdat(dat0,nDat,inx0,vdat,iOpt)
char *dat0[],*vdat[];
int nDat,inx0[],iOpt;
{
#if 1
	char *s,*p,**dat,*pp;
	int i,size,arg[2],index,*inx;

	if (iOpt & 0x08) size = sizeof(int)*2;
	else size = sizeof(char *) + sizeof(int);
	if(!(s = Malloc(nDat*size))) return -1;
	p = s;
	index = 0;
	dat = dat0;
	inx = inx0;
	for (i=0;i<nDat;i++) {
		memcpy(p,&index,sizeof(int));
		p += sizeof(int);
		index++;
		if (iOpt & 0x08) {
			memcpy(p,inx,sizeof(int));
			p += sizeof(int);
			inx++;
		}
		else {
			memcpy(p,dat,sizeof(char *));
			p += sizeof(char *);
			dat++;
		}
	}

	arg[0] = iOpt;
	arg[1] = size;
	akxqsort_r(s,nDat,size,_compar_inx_vdat,arg);

	p = s;
	dat = dat0;
	inx = inx0;
	for (i=0;i<nDat;i++) {
		memcpy(&index,p,sizeof(int));
/*
printf("akxstrsort_inx_vdat: index=%d\n",index);
*/
		pp = p + sizeof(int);
		if (iOpt & 0x08) {
			memcpy(inx,pp,sizeof(int));
			inx++;
		}
		else {
			memcpy(dat,pp,sizeof(char *));
			dat++;
		}
		p += size;
	}
	if ((iOpt & 0x02) && !(iOpt & 0x08)) {
		_set_of_index(s,nDat,size,inx0,sizeof(int));
	}
	if (iOpt & 0x04) {
		_set_of_index(s,nDat,size,vdat,sizeof(char *));
	}
	if (iOpt & 0x08) {
		_set_of_index(s,nDat,size,dat0,sizeof(char *));
	}
	Free(s);
#else
	int opt1,opt2,opt4,opt8,k,i,j,max_dat,min_i,min_inx,inx_j;
	char *min_vdat,*dat_j,*min_dat;

	opt1 = iOpt & 0x1;
	opt2 = iOpt & 0x2;
	opt4 = iOpt & 0x4;
	opt8 = iOpt & 0x8;
	if (opt8) opt2 = 0x2;
	max_dat = nDat;
	for (i=0;i<max_dat-1;i++) {
		min_i = i;
		min_dat = dat[i];
		if (opt2) min_inx = inx[i];
		if (opt4) min_vdat = vdat[i];
		for (j=i+1;j<max_dat;j++) {
			k = 0;
			if (!opt8) {
				dat_j = dat[j];
				if ((!opt1 && dat_j<min_dat) || (opt1 && dat_j>min_dat)) k = 1;
			}
			else {
				inx_j = inx[j];
				if ((!opt1 && inx_j<min_inx) || (opt1 && inx_j>min_inx)) k = 1;
			}
			if (k) {
				min_i = j;
				min_dat = dat[j];
				if (opt2) min_inx = inx[j];
				if (opt4) min_vdat = vdat[j];
			}
		}
		if (min_i > i) {
			dat[min_i] = dat[i];
			dat[i] = min_dat;
			if (opt2) {
				inx[min_i] = inx[i];
				inx[i] = min_inx;
			}
			if (opt4) {
				vdat[min_i] = vdat[i];
				vdat[i] = min_vdat;
			}
		}
	}
#endif
	return 0;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : �T�[�`bit�z��̎w��͈͂ɂ���l�ƈ�v����ʒu��Ԃ�	*/
/* ���� : bits : �T�[�`bit�z��									*/
/*		  i1   : �����r�b�g�ʒu									*/
/*		  i2   : ����r�b�g�ʒu									*/
/*		  bit  : �����Ώ�(i1�`i2�r�b�g�ڂ̂ǂ�����ӏ��݂̂�ON)	*/
/*				 0x00000001 : 1�Ԗ�								*/
/* �ԋp : > 0 : �r�b�g�ʒu										*/
/*		  = 0 : ��v����r�b�g�Ȃ�(ON�̃r�b�g�̐���1�łȂ�)	*/
/****************************************************************/
static int _get_bit_num_hlf(bits,i1,i2,bit)
long bits[],bit;
int i1,i2;
{
	int i,im;
	long bitm;
/*
printf("_get_bit_num_hlf:Enter bit=%08x i1=%d i2=%d\n",bit,i1,i2);
*/
	i = 0;
	im = (i2 + i1)/2;
	if (im <= 0) {
		if (bits[i2] & bit) i = i2;
	}
	else {
		bitm = bits[im];
		if (bit & bitm) i = im;
		else if (bit < bitm)
			i = _get_bit_num_hlf(bits,i1,im-1,bit);
		else
			i = _get_bit_num_hlf(bits,im+1,i2,bit);
	}
/*
printf("_get_bit_num_hlf:Exit i=%d\n",i);
*/
	return i;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : bit32�z��̐擪�A�h���X��Ԃ�							*/
/* �ԋp : bit32�z��̐擪�A�h���X								*/
/****************************************************************/
long *get_bit32_array()
{
	static long bits[33]={0,1,2,4,8,0x10,0x20,0x40,0x80,0x100,0x200,0x400,0x800
	,0x1000,0x2000,0x4000,0x8000,0x10000,0x20000,0x40000,0x80000
	,0x100000,0x200000,0x400000,0x800000,0x1000000,0x2000000,0x4000000,0x8000000
	,0x10000000,0x20000000,0x40000000,0x80000000};

	return bits;
}

/********1*********2*********3*********4*********5*********6*****/
/* �@�\ : ���ʂ��琔���ĉ��Ԗڂ̃r�b�g��ON����Ԃ�				*/
/* ���� : bit : �����Ώ�(1�`32�r�b�g�ڂ̂ǂ�����ӏ��݂̂�ON)	*/
/*				0x00000001 : 1�Ԗ�								*/
/* �ԋp : > 0 : �r�b�g�ʒu										*/
/*		  = 0 : ��v����r�b�g�Ȃ�(ON�̃r�b�g�̐���1�łȂ�)	*/
/****************************************************************/
int get_bit_number(bit)
long bit;
{
	int i,im;
	long *bits,bitm;

	bits = get_bit32_array();
	if (!bit) i = 0;
	else if (bit == bits[32]) i = 32;
	else if (bit == bits[1]) i = 1;
	else {
		im = 16;
		bitm = bits[im];
		if (bit == bitm) i = im;
		else if (bit < bitm)
			i = _get_bit_num_hlf(bits,2,im-1,bit);
		else
			i = _get_bit_num_hlf(bits,im+1,31,bit);
	}
	return i;
}
