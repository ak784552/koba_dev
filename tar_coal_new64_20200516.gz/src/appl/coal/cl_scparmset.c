static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************
*                                                                   *
*      �����ړI�@�@�F  							                    *
*                                                                   *
*      �֐����@�@�@�F�@int cl_scparmset( pLeaf )			        *
*                                                                   *
*      ������      �F�@(I)Leaf          * pLeaf                     *
*                                                                   *
*                                                                   *
*      �߂�l�@�@�@�F�@ERROR                                        *
*                      NORMAL                                       *
*                                                                   *
*      �����T�v�@�@�F�@                                             *
*                                                                   *
********************************************************************/
#include <colmn.h>

#if 1	/* 2020.2.6 */
int cl_scparmset(pprmp,prmnum,proc)
parmList **pprmp;
int  prmnum;
#else
int cl_scparmset(pLeaf,proc)
Leaf *pLeaf ;
#endif
ProcCT  *proc;
{
	int         i,rc,k,j;
	ScrPrCT     *pScCT;
	ScrPrCT     *pPreScCT;
	int         parmpos; 
	int         parmnum,*pSize,varmax,varall;
	tdtInfoParm	prm_list,*pprmListW,*pprmListC,*pInfoParm;
	VarTBL      *VaryW,*VaryC;
	parmList    *parm;
	char        *pBuff,c;
#if 0	/* 2020.2.6 */
	parmList **pprmp;
#endif
	tdtInfoParm   ***pTBL;

#if 1	/* 2020.2.6 */
	if (!pprmp) {
#else
	if (!pLeaf) {
#endif
		ERROROUT1(FORMAT(28),"cl_scparmset");	/* cl_scparmset: �����N�G���[ */
		return ERROR;
	}
#if 1	/* 2020.2.6 */
	if (prmnum < 0) {
#else
	if (pLeaf->cmd.prmnum < 2) {
#endif
		ERROROUT(FORMAT(376));	/* �p�����[�^���Ɍ�肪����܂��B */
		return ERROR;
	}

#if 0	/* 2020.2.6 */
	pprmp = pLeaf->cmd.prmp;
#endif
	pScCT = cl_search_src_ct();
	pPreScCT = pScCT->preScCT;
DEBUGOUTL2(194,"cl_scparmset: pPreScCT=%08x pScCT=%08x",pPreScCT,pScCT);

	pSize = (int *)pScCT->Vary->pTBL_pasento[0];
	VaryW = pScCT->Vary;
	VaryC = pScCT->Vary = pPreScCT->Vary;

#if 1	/* 2020.2.6 */
	for (i=0, parmpos=0, j=0 ;i<prmnum; i++,parmpos++) {
		parm = pprmp[parmpos];
#else
	for (i=0, parmpos=2, j=0 ;i<pLeaf->cmd.prmnum-2; i++,parmpos++) {
		parm = pLeaf->cmd.prmp[parmpos];
#endif
#if 1
		varall = 0;
		if (!strcmp(parm->prp,"%*")) {
			varall = 1;
			varmax = VaryC->varnam_pasento;
			pTBL   = VaryC->pTBL_pasento;
		}
		else if (!strcmp(parm->prp,"#*")) {
			varall = 2;
			varmax = VaryC->varnam_igeta;
			pTBL   = VaryC->pTBL_igeta;
		}
		if (varall) {
			for (k=0;k<varmax;k++) {
#else
		if (parm->prmlen == 2 && !memcmp(parm->prp,"%*",2)) {
			for (k=0;k<VaryC->varnam_pasento;k++) {
#endif
			/*	if (j>=VAR_MAX_PAS) {	*/
				if (j>=pSize[2]) {
					pScCT->Vary = VaryW;
					pScCT->Vary->varnam_pasento = j;
					cl_set_parm_bin(cl_var_size_parm(pSize),j);
					return ECL_SCRIPT_ERROR;
				}
				pprmListW = cl_get_var_ent(VaryW->pTBL_pasento,++j);
				pprmListC = cl_get_var_ent(pTBL,k+1);
				if (cl_gx_rep_info_set(pprmListW,pprmListC,1)) return ECL_SCRIPT_ERROR;
				pprmListW->pi_aux[1] |= D_AUX1_PROTECTED;
			}
		}
		else {
			if ((rc=cl_gx_exp_obj(1,&pprmp[parmpos],proc->Obj,&prm_list))<0) {
				pScCT->Vary = VaryW;
				pScCT->Vary->varnam_pasento = j;
				cl_set_parm_bin(cl_var_size_parm(pSize),j);
				return ECL_SCRIPT_ERROR;
			}
			if (rc==100) cl_null_parm(&prm_list);
DEBUGOUT_InfoParm(194,"cl_scparmset: : i=%d pScCT=%08x",
&prm_list,i,&prm_list.pi_len);
			pprmListW = cl_get_var_ent(VaryW->pTBL_pasento,++j);
			if (cl_gx_rep_info_set(pprmListW,&prm_list,1)) return ECL_SCRIPT_ERROR;
			pprmListW->pi_aux[1] |= D_AUX1_PROTECTED;
			if ((c=pprmListW->pi_id)=='A' || c=='R' || c=='L' || c=='N') {
				pprmListW->pi_len = (long)pPreScCT;
				pprmListW->pi_scale &= ~0x20;
			}
DEBUGOUT_InfoParm(194,"cl_scparmset:W: i=%d pScCT=%08x",
pprmListW,i,pprmListW->pi_len);
		}
	}
	pScCT->Vary = VaryW;
	pScCT->Vary->varnam_pasento = j;
	cl_set_parm_bin(cl_var_size_parm(pSize),j);
DEBUGOUT_InfoParm(194,"cl_scparmset:j: j=%d",cl_var_size_parm(pSize),j,0);

	return NORMAL;
}
#if 1
/****************************************/
/*										*/
/****************************************/
int cl_prparmset(/*pLeaf,*/pProc,pExProcName)
/*Leaf *pLeaf ;*/
ProcCT  *pProc;
char *pExProcName;
{
	int         rc,j;
	ScrPrCT     *pScCT;
	int         *pSize; 
	tdtInfoParm	*pInfoParmW,*pInfoParm;
	VarTBL      *VaryC;
	char        c;
	ProcCT      *proc;
	tdtInfoParm **ppmstk;


	if (!(proc = cl_search_proc_ct())) return -2;
	if (proc->varnam_pasento > 0) return 0;
	if (rc=cl_mk_pr_var_set(proc)) return rc;
	if (pProc) ppmstk = pProc->ppExecParm;
	else ppmstk = NULL;
	if (!ppmstk || !strcmp(pExProcName,"main")) {
		pScCT = cl_search_src_ct();
		VaryC = pScCT->Vary;
		proc->varnam_pasento = VaryC->varnam_pasento;
		proc->pTBL_pasento = VaryC->pTBL_pasento;
		proc->pFlag |= D_PFLAG_PARM_COPY;
		return 0;
	}

	for (j=0 ;pInfoParm=ppmstk[j];) {
		pInfoParmW = cl_get_var_ent(proc->pTBL_pasento,++j);
		if (cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return ECL_SCRIPT_ERROR;
		pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;
		if ((c=pInfoParmW->pi_id)=='A' || c=='R' || c=='L' || c=='N') {
			pInfoParmW->pi_scale &= ~0x20;
		}
DEBUGOUT_InfoParm(194,"cl_prparmset:W: j=%d pScCT=%08x",
pInfoParmW,j,pInfoParmW->pi_len);
	}
	proc->varnam_pasento = j;
	pSize = (int *)proc->pTBL_pasento[0];
	cl_set_parm_bin(cl_var_size_parm(pSize),j);

	return NORMAL;
}
#else
/****************************************/
/*										*/
/****************************************/
int cl_prparmset(pLeaf,pProc,pExProcName)
Leaf *pLeaf ;
ProcCT  *pProc;
char *pExProcName;
{
	int         i,rc,k,j;
	ScrPrCT     *pScCT;
	int         *pSize; 
	int         parmpos; 
	int         parmnum,*pSize; 
	tdtInfoParm	tInfoParm,*pprmListW,*pprmListC,*pInfoParm;
	VarTBL      *VaryC;
	parmList    *parm;
	char        c;
	parmList    **pprmp;
	tdtInfoParm   **pObj;
	ProcCT      *proc;

/*	if (!pLeaf || !pProc) {	*/

	pScCT = cl_search_src_ct();
	VaryC = pScCT->Vary;

	if (!(proc = cl_search_proc_ct())) return -1;
	if (proc->varnam_pasento > 0) return 0;
	if (rc=cl_mk_pr_var_set(proc)) return rc;
	if (!strcmp(pExProcName,"main")) {
		proc->varnam_pasento = VaryC->varnam_pasento;
		proc->pTBL_pasento = VaryC->pTBL_pasento;
		proc->pFlag |= D_PFLAG_PARM_COPY;
		return 0;
	}

	if (!pLeaf) {
		ERROROUT1(FORMAT(28),"cl_prparmset");	/* cl_prparmset: �����N�G���[ */
		return ERROR;
	}
	if ((parmnum=pLeaf->cmd.prmnum) <= 2) return 0;
	if (pProc) pObj = pProc->Obj;
	else pObj = NULL;
	pprmp = pLeaf->cmd.prmp;
	pSize = (int *)proc->pTBL_pasento[0];

	for (i=0, parmpos=2, j=0 ;i<parmnum-2; i++,parmpos++)  {
		parm = pprmp[parmpos];
		if (parm->prmlen == 2 && !memcmp(parm->prp,"%*",2)) {
			for (k=0;k<VaryC->varnam_pasento;k++) {
				if (j>=pSize[2]) {
					return ECL_SCRIPT_ERROR;
				}
				pprmListW = cl_get_var_ent(proc->pTBL_pasento,++j);
				pprmListC = cl_get_var_ent(VaryC->pTBL_pasento,k+1);
				if (cl_gx_rep_info_set(pprmListW,pprmListC,1))
					return ECL_SCRIPT_ERROR;
			}
		}
		else {
		/*	if ((rc=cl_gx_exp_obj(1,&pprmp[parmpos],pProc->Obj,&tInfoParm))<0) {	*/
			if ((rc=cl_gx_exp_obj(1,&pprmp[parmpos],pObj,&tInfoParm))<0) {
				return ECL_SCRIPT_ERROR;
			}
			if (rc==100) cl_null_parm(&tInfoParm);
DEBUGOUT_InfoParm(194,"cl_prparmset: : i=%d pScCT=%08x",
&tInfoParm,i,&tInfoParm.pi_len);
			pprmListW = cl_get_var_ent(proc->pTBL_pasento,++j);
			if (cl_gx_rep_info_set(pprmListW,&tInfoParm,1)) return ECL_SCRIPT_ERROR;
		    pprmListW->pi_aux[1] |= D_AUX1_PROTECTED;
			if ((c=pprmListW->pi_id)=='A' || c=='R' || c=='L' || c=='N') {
			/*	pprmListW->pi_len = (long)pScCT;	*/
				pprmListW->pi_scale &= ~0x20;
			}
DEBUGOUT_InfoParm(194,"cl_prparmset:W: i=%d pScCT=%08x",
pprmListW,i,pprmListW->pi_len);
		}
	}
	proc->varnam_pasento = j;
	cl_set_parm_bin(cl_var_size_parm(pSize),j);

	return NORMAL;
}
#endif
/****************************************/
/*										*/
/****************************************/
#if 1	/* 2020.2.6 */
int cl_set_exec_parm(pprmp,parmnum,pProc)
parmList **pprmp;
int  parmnum;
#else
int cl_set_exec_parm(pLeaf,pProc)
Leaf *pLeaf ;
#endif
ProcCT  *pProc;
{
	int         i,rc,k,j,maxnum,n,numinc;
	ScrPrCT     *pScCT;
	int         parmpos;
/*	int         parmnum;	2020.2.6 */
	int         *pSize,varmax,varall;
	tdtInfoParm	tInfoParm,*pInfoParmW;
	VarTBL      *VaryC;
	parmList    *parm;
	char        *p;
#if 0	/* 2020.2.6 */
	parmList    **pprmp;
#endif
	tdtObjHead  *pObj;
	ProcCT      *proc;
	tdtInfoParm **ppmstk,***pTBL;

DEBUGOUTL3(120,"cl_set_exec_parm:Enter pprmp=%08x parmnum=%d pProc=%08x",pprmp,parmnum,pProc);

#if 1	/* 2020.2.6 */
	if (!pprmp || !pProc) {
#else
	if (!pLeaf || !pProc) {
#endif
		ERROROUT1(FORMAT(28),"cl_set_exec_parm");	/* cl_set_exec_parm: �����N�G���[ */
		return ERROR;
	}
	if (!(pScCT = cl_search_src_ct())) {
		ERROROUT("cl_set_exec_parm: ScCT not found.");
		return ERROR;
	}
	if (!(proc = cl_search_proc_ct())) {
		ERROROUT("cl_set_exec_parm: proc not found.");
		return -1;
	}
	VaryC = pScCT->Vary;
/*
	if ((parmnum=pLeaf->cmd.prmnum) <= 2) return 0;
*/
#if 1	/* 2020.2.6 */
	maxnum = parmnum;
#else
	parmnum = pLeaf->cmd.prmnum;
	maxnum = parmnum - 2;
#endif
	if (pProc) pObj = pProc->Obj;
/*	else pObj = NULL;	*/
#if 0	/* 2020.2.6 */
	pprmp = pLeaf->cmd.prmp;
#endif
	pSize = (int *)proc->pTBL_pasento[0];
	if (maxnum > 0) {
		numinc = VaryC->varnam_pasento;	/* '%*'�̐��������Ă��� */
	/*	maxnum = parmnum-2+numinc;	*/
		maxnum += numinc;
	}

DEBUGOUTL1(120,"cl_set_exec_parm:0: maxnum=%d",maxnum);

	if (!(p=cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(maxnum+1)))) {
		return ECL_MALLOC_ERROR;
	}
	ppmstk = (tdtInfoParm **)p;
#if 1	/* 2020.2.6 */
	for (i=0, parmpos=0, j=0 ;i<parmnum; i++,parmpos++)  {
#else
	for (i=0, parmpos=2, j=0 ;i<parmnum-2; i++,parmpos++)  {
#endif
		parm = pprmp[parmpos];
#if 1
DEBUGOUTL2(120,"cl_set_exec_parm: i=%d parm->prp=[%s]",i,parm->prp);
		varall = 0;
		if (!strcmp(parm->prp,"%*")) {
			varall = 1;
			varmax = VaryC->varnam_pasento;
			pTBL   = VaryC->pTBL_pasento;
		}
		else if (!strcmp(parm->prp,"#*")) {
			varall = 2;
			varmax = VaryC->varnam_igeta;
			pTBL   = VaryC->pTBL_igeta;
		}
		if (varall) {
			for (k=0;k<varmax;k++) {
#else
		if (parm->prmlen == 2 && !memcmp(parm->prp,"%*",2)) {
			for (k=0;k<VaryC->varnam_pasento;k++) {
#endif
				if (j>=pSize[2]) {
					return ECL_SCRIPT_ERROR;
				}
				if (j >= maxnum) {
					n = maxnum + numinc;
					if (!(p=cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(n+1)))) {
						return -1;
					}
					memcpy(p,ppmstk,sizeof(tdtInfoParm *)*maxnum);
					maxnum = n;

DEBUGOUTL1(120,"cl_set_exec_parm:1: maxnum=%d",maxnum);

					ppmstk = (tdtInfoParm **)p;
				}
				ppmstk[j++] = cl_get_var_ent(pTBL,k+1);
			}
		}
		else {
			if ((rc=cl_gx_exp_obj(1,&pprmp[parmpos],pObj,&tInfoParm))<0) {
				return ECL_SCRIPT_ERROR;
			}
			if (rc==100) cl_null_parm(&tInfoParm);
DEBUGOUT_InfoParm(194,"cl_set_exec_parm: : i=%d pScCT=%08x",
&tInfoParm,i,&tInfoParm.pi_len);
			if (!(pInfoParmW=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) {
				return ECL_MALLOC_ERROR;
			}
			cl_gx_copy_info(pInfoParmW,&tInfoParm);
DEBUGOUT_InfoParm(194,"cl_set_exec_parm:W: i=%d pScCT=%08x",
pInfoParmW,i,pInfoParmW->pi_len);
#if 0
			if (j >= maxnum) {
				n = maxnum + numinc;
				if (!(p=cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(n+1)))) {
					return ECL_MALLOC_ERROR;
				}
				memcpy(p,ppmstk,sizeof(tdtInfoParm *)*maxnum);
				maxnum = n;
/*
printf("cl_set_exec_parm:2: maxnum=%d\n",maxnum);
*/
				ppmstk = (tdtInfoParm **)p;
			}
#endif
			ppmstk[j++] = pInfoParmW;
		}
	}
	ppmstk[j] = NULL;
	pProc->ppExecParm = ppmstk;
/*
printf("cl_set_exec_parm:ret: j=%d\n",j);
*/
	return NORMAL;
}
