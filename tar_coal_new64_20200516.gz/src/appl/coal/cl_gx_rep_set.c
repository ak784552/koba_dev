static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �������                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_rep_set( pparmList , ppmList )               *
*                      (O)parmList  *pparmList                                *
*                      (I)prmList  *pprmList                                  *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern int giOptions[];
/* extern CLPRTBL CLprocTable;	*/
extern GlobalCt  *pGlobTable;

static int _list_info_set();
static int _array_hash_clr();
static int _list_array_set();

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_set(pparmList ,pInfoParm)
parmList  *pparmList;
tdtInfoParm *pInfoParm;
{
	int		rc;
	ScrPrCT *pSPCT;
	tdtInfoParm *pInfoParmW;

	pSPCT = cl_search_src_ct();

	if (rc= cl_gx_get_info_parm(pSPCT,'s',pparmList,&pInfoParmW)) {
		return rc;
	}

	return cl_gx_rep_info_set(pInfoParmW ,pInfoParm ,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_set_global( pparmList ,pInfoParm )
parmList  *pparmList;
tdtInfoParm *pInfoParm;
{
	/* %s: %s�ɂ͑���ł��܂���B */
	ERROROUT2(FORMAT(126),"cl_gx_rep_set_global",pparmList->prp);
	return ECL_SCRIPT_ERROR;
}

/****************************************/
/*										*/
/****************************************/
int _get_num_msg_no(pInfoParm,msg_no,opt,pix0)
tdtInfoParm *pInfoParm;
int msg_no,opt,*pix0;
{
	int iRc,ix0;

	iRc = -1;
	ix0 = 0;
	if (msg_no <= 0) msg_no = 577;	/* (%d)���s���ł��B */
	if (pInfoParm && pix0) {
		iRc = 0;
		if (pInfoParm->pi_dlen > 0) {
			if (iRc = cl_get_parm_bin(pInfoParm,&ix0,"_get_start_pos.ix0:")) return iRc;
			if (ix0 < 0) {
				ERROROUT1(FORMAT(msg_no),ix0);	/* �E�E�E(%d)���s���ł��B */
				iRc = -1;
			}
		}
		else if (opt & 0x01) iRc = C_NULL_PARM;
		*pix0 = ix0;
	}
/*
printf("_get_num_msg_no: ix0=%d iRc=%d\n",ix0,iRc);
*/
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info(nparm,ppParm,pIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	iRc = _get_array_info_ref(nparm,ppParm,&pIndexW,ppTBL,iParm,opt);
	if (!iRc || iRc==2000) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*******/
/*	�����F	ppIndex : *ppIndex �ɂ́A&tIndex ���A		*/
/*					    �ݒ肳��Ă��邱��				*/
/*					  *ppIndex �ɂ́AA or R �̂Ƃ��A	*/
/*						�z���pIndex���Ԃ����B		*/
/********************************************************/
int _get_array_info_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtInfoParm *pInfoParm;
	int iRc,ix0,*index;
	XHASHB *xhp;
	tdtArrayIndex *pIndex;

	pInfoParm = ppParm[0];
	if (opt & 0x02) {
		if (iRc = cl_check_use_mapped_array(pInfoParm)) return iRc;
	}
	pIndex = *ppIndex;
/*
printf("_get_array_info_ref:1 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	if (iRc = cl_get_array_info_ref(pInfoParm,ppIndex,ppTBL,iParm)) return iRc;
	pIndex = *ppIndex;
/*
printf("_get_array_info_ref:2 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	if ((opt & 0x01) && pIndex->xhp) {
		return 2000;
	}
	if (iRc = cl_check_use_hash_array(pInfoParm,pIndex)) return iRc;

	ix0 = 0;
	if (nparm >= 2) {
#if 1	/* 2019.08.03 */
		if (iRc = _get_num_msg_no(ppParm[1],222,0,&ix0)) return iRc;
#else
		pInfoParm = ppParm[1];
		if (pInfoParm->pi_dlen>0) {
			if (iRc = cl_get_parm_bin(pInfoParm,&ix0,"_get_array_info.ix0:")) return iRc;
			if (ix0 < 0) {
				ERROROUT1(FORMAT(222),ix0);	/* �J�n�ʒu(%d)���s���ł��B */
				return -1;
			}
		}
#endif
	}
	iParm[0] = ix0;
	iParm[1] -= ix0;
	iParm[2] += ix0;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info_used(nparm,ppParm,pIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtInfoParm ***pTBL,*pInfoParm;
	int iRc,*pSize;
	char c;

	if (iRc = _get_array_info(nparm,ppParm,pIndex,ppTBL,iParm,opt)) return iRc;
	pInfoParm = ppParm[0];
	c = pInfoParm->pi_id;
	if (c!='R' && c!='A') {
		if (ppTBL) {
			pTBL = *ppTBL;
			pSize = (int *)pTBL[0];
			iParm[1] = pSize[7] - (iParm[2] - 1);	/* 6-->7 2020.4.30 */
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _get_array_num(nparm,ppParm,nm1,pNum)
int  nparm;
tdtInfoParm *ppParm[];
int nm1,*pNum;
{
	tdtInfoParm *pInfoParm;
	int nm,iRc;

#if 1	/* 2019.08.03 */
	nm = nm1;
#else
	nm = *pNum;
#endif
/*
printf("_get_array_num: nparm=%d nm1=%d nm=%d\n",nparm,nm1,nm);
*/
	if (nparm >= 1) {
#if 1	/* 2019.08.03 */
		if ((iRc=_get_num_msg_no(ppParm[0],223,0x01,&nm)) == C_NULL_PARM) nm = nm1;
		else if (iRc) return iRc;
		else if (nm1>0 && nm>nm1) {
			/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
			ERROROUT2(FORMAT(224),nm,nm1);
			nm = nm1;
		}
#else
		pInfoParm = ppParm[0];
		if (pInfoParm->pi_dlen>0) {
			if (iRc = cl_get_parm_bin(pInfoParm,&nm,"_get_array_num:")) return iRc;
			if (nm < 0) {
				ERROROUT1(FORMAT(223),nm);	/* ��(%d)���s���ł��B */
				return -1;
			}
			else if (nm1>0 && nm>nm1) {
				/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
				ERROROUT2(FORMAT(224),nm,nm1);
				nm = nm1;
			}
		}
#endif
	}
	*pNum = nm;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_array(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm,*pInfoParmW;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix0,ix,nm,count,len;
	char c,*name,*p1;
	tdtArrayIndex *pIndex,tIndex;
	int *index,iParm[4];

	nm = 0;
	memcpy(pWork,&nm,sizeof(int));

	nm = nparm - 2;
	pIndex = &tIndex;
/*
printf("cl_set_array:1 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	iRc = _get_array_info_ref(nparm,ppParm,&pIndex,&pTBL,iParm,3);
	if (iRc == 2000) {
		if (iRc=_array_hash_clr(ppParm[0]->pi_data)) return iRc;
		for (i=count=0;i<nm;i+=2) {
			if ((len=parm_to_char_tmp(ppParm[i+2],&p1,0)) < 0) return len;
			else if (len > 0) {
				if (i+1<nm && !cl_is_null_parm(pInfoParm=ppParm[i+3])) {
					if (!(pInfoParmW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
					memset(pInfoParmW,0,sizeof(tdtInfoParm));
					if (iRc = cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
					ix = akxs_xhash2(pIndex->xhp,'s',p1,&pInfoParmW);
					if (ix <= 0) {
						if (ix == 0) ix = -12;
						return ix;
					}
					count++;
				}
			}
		}
		memcpy(pWork,&count,sizeof(int));
		return 0;
	}
	else if (iRc) return iRc;
/*
printf("cl_set_array: nm=%d iParm=%d %d %d\n",nm,iParm[0],iParm[2],iParm[2]);
*/
	ix0 = iParm[0];
	ix  = iParm[2];
	if (nm > iParm[1]) {
		/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
		ERROROUT2(FORMAT(224),nm,iParm[1]);
		nm = iParm[1];
	}
/*
printf("cl_set_array:2 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	for (i=count=0;i<nm;i++,ix++) {
		pInfoParm = ppParm[i+2];
		if (!cl_is_null_parm(pInfoParm)) {
			pInfoParmW = cl_get_array_and_var_ent(pIndex,pTBL,ix);
			if (pInfoParmW) {
				if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
			}
			else {
				return -1;
			}
			count++;
		}
	}
	memcpy(pWork,&count,sizeof(int));

	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _list_copy_info(pCt,pCtI)
tdtRbCtl *pCt,*pCtI;
{
	tdtInfoParm *p,*pInfoParm;
	int rc=0;

	if (!pCt || !pCtI) return -1;
	if (pCt == pCtI) return 0;
	akxs_rb_read(pCtI,0);
	while (p=(tdtInfoParm *)akxs_rb_read(pCtI,1)) {
DEBUGOUT_InfoParm(198,"_list_copy_info: ",p,0,0);
		if (!(pInfoParm=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
			return ECL_MALLOC_ERROR;
		rc = _list_info_set(pInfoParm,p);
		if (!cl_tmp_rbset_n(pCt,pInfoParm)) return ECL_MALLOC_ERROR;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _list_copy(pInfoParmO,pInfoParmI)
tdtInfoParm *pInfoParmO,*pInfoParmI;
{
	int rc;
	tdtRbCtl *pCt,*pCtI;

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) return 0;
	if (!(pCt = cl_tmp_rb_new(0,0))) return ECL_MALLOC_ERROR;
	pInfoParmO->pi_data = (char *)pCt;
	pCtI = (tdtRbCtl *)pInfoParmI->pi_data;
	rc = _list_copy_info(pCt,pCtI);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _list_info_set(pInfoParmO ,pInfoParmI)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
{
	int rc;
	char c;

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) return 0;
	*pInfoParmO = *pInfoParmI;
DEBUGOUT_InfoParm(198,"_list_info_set: pInfoParmI=",pInfoParmI,0,0);
	if ((c=pInfoParmO->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
		if ((rc=_list_copy(pInfoParmO,pInfoParmI)) < 0) return rc;
	}
	else {
#if 1
		if (rc=cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,1 | D_GX_OPT_ALC_TMP)) return rc;
		if (pInfoParmO->pi_id == ' ') pInfoParmO->pi_aux[1] |= D_AUX1_PROTECTED;
DEBUGOUT_InfoParm(198,"_list_info_set: pInfoParmO=",pInfoParmO,0,0);
#else
		if (pInfoParmO->pi_scale & D_DATA_LPOSDATA)
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
		else {
			pInfoParmO->pi_scale &= ~D_DATA_MALLOC;
			if (pInfoParmI->pi_dlen > 0) {
				if (!(pInfoParmO->pi_data=cl_tmp_const_malloc(pInfoParmI->pi_dlen+1))) {
					return ECL_MALLOC_ERROR;
				}
				memzcpy(pInfoParmO->pi_data,pInfoParmI->pi_data,pInfoParmI->pi_dlen);
			}
		}
#endif
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*pInfoParm2, *p;
	int i,rc,opt1;
	tdtRbCtl *pCt;

	opt1 = pGlobTable->options[4] & 0x01;
	cl_null_parm(pInfoParmW);
	if (nparm > 0 || opt1) {
		pInfoParmW->pi_id   = D_DATA_ID_LIST;
		pInfoParmW->pi_attr = DEF_ZOK_BULK;
		pInfoParmW->pi_dlen  = sizeof(tdtRbCtl);
		if (!(pCt = cl_tmp_rb_new(0,0))) return ECL_MALLOC_ERROR;
		pInfoParmW->pi_data = (char *)pCt;
	}
	for (i=0;i<nparm;i++) {
		p = ppParm[i];
DEBUGOUT_InfoParm(197,"cl_set_list:s: i=%d",p,i,0);
		if (p->pi_aux[0] & DEF_ZOK_DATA) {
			if ((rc=_list_array_set(pCt,p)) < 0) return rc;
		}
#if 1	/* 2019.5.16 */
		else {
#else
		else if (!cl_is_null_parm(p)) {
#endif
			if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
			if ((rc=_list_info_set(pInfoParm1,p)) < 0) return rc;
DEBUGOUT_InfoParm(198,"cl_set_list:d: i=%d",pInfoParm1,i,0);
			if (!cl_tmp_rbset_n(pCt,pInfoParm1)) return ECL_MALLOC_ERROR;
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
tdtRbCtl *cl_tmp_rb_new(lBS,lRM)
long lBS,lRM;
{
#if 1	/* 2019.12.13 */
	return akxs_rb_new2(lBS,lRM,cl_tmp_const_malloc);
#else
	tdtRbCtl *pCt;
	tdtRbChain *p1,*p2;

	if (!(pCt = (tdtRbCtl *)cl_tmp_const_malloc(sizeof(tdtRbCtl)))) return NULL;
	memset(pCt,0,sizeof(tdtRbCtl));
	pCt->rb_bfsz = lBS;
	pCt->rb_max = lRM;
	if (!(p1 = (tdtRbChain *)cl_tmp_const_malloc(sizeof(tdtRbChain)))) {
		return NULL;
	}
	pCt->rb_cur = pCt->rb_waddr = pCt->rb_raddr = p1;
	p1->rbc_buf = NULL;
	if (!(p2 = (tdtRbChain *)cl_tmp_const_malloc(sizeof(tdtRbChain)))) {
		return NULL;
	}
	pCt->rb_wpriv = p2;
	p2->rbc_buf = NULL;
	p1->rbc_next = p2;
	p2->rbc_next = p1;
	pCt->rb_num = 2;
	return pCt;
#endif
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_rbset_n(pCt, addr)
tdtRbCtl *pCt;
char *addr;
{
#if 1	/* 2019.12.13 */
	return akxs_rb_set_n(pCt, addr);
#else
	tdtRbChain *pw, *pn, *pp;

	if (!pCt || !addr) return NULL;
	
	pw = pCt->rb_waddr;
	if (pw->rbc_buf) {
		if (!(pn = (tdtRbChain *)cl_tmp_const_malloc(sizeof(tdtRbChain)))) return NULL;
		pp = pCt->rb_wpriv;
		pCt->rb_waddr = pp->rbc_next = pn;
		pn->rbc_next = pw;
		pw = pCt->rb_waddr;
		pCt->rb_num++;
	}
	pw->rbc_buf = addr;
	pCt->rb_waddr = pw->rbc_next;
	pCt->rb_wpriv = pw;
	pCt->rb_used++;
	return addr;
#endif
}

/****************************************/
/*										*/
/****************************************/
int cl_cons_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*pInfoParm2, *p;
	int i,rc,opt1;
	tdtRbCtl *pCt;
	char c;

	opt1 = pGlobTable->options[4] & 0x01;
	cl_null_data(pInfoParmW);
	if (nparm > 0 || opt1) {
		pInfoParmW->pi_id   = D_DATA_ID_LIST;
		pInfoParmW->pi_attr = DEF_ZOK_BULK;
		pInfoParmW->pi_dlen  = sizeof(tdtRbCtl);
		if (!(pCt = cl_tmp_rb_new(0,0))) return ECL_MALLOC_ERROR;
		pInfoParmW->pi_data = (char *)pCt;
		if (nparm > 0) {
			if (ppParm[0]->pi_id==D_DATA_ID_NARABI)
				pInfoParmW->pi_id = D_DATA_ID_NARABI;
		}
	}
	for (i=0;i<nparm;i++) {
		p = ppParm[i];
		if ((c=p->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
			if ((rc=_list_copy_info(pCt,p->pi_data)) < 0) return rc;
		}
		else if (p->pi_aux[0] & DEF_ZOK_DATA) {
			if ((rc=_list_array_set(pCt,p)) < 0) return rc;
		}
		else if (!cl_is_null_parm(p)) {
			if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
			if ((rc=_list_info_set(pInfoParm1,p)) < 0) return rc;
			if (!cl_tmp_rbset_n(pCt,pInfoParm1)) return ECL_MALLOC_ERROR;
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	int  ret,len;
	char w1[32],*p1;
	tdtInfoParm **pp;

	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	ret = 0;
	p1 = w1;
	if ((len = parm_to_char(ppParm[0],&p1,NULL)) < 0) {
		ERROROUT(FORMAT(225));	/* ����w�肪�s���ł��B */
		return len;
	}
	nparm--;
	pp = &ppParm[1];
	if (!stricmp(p1,"LIST")||!stricmp(p1,"APPEND"))
		ret = cl_set_list(pInfoParmW,nparm,pp);
	else if (!stricmp(p1,"FIRST")) ret = cl_ope_list(pInfoParmW,NULL,nparm,pp,D_FUC_FIRST,0);
	else if (!stricmp(p1,"REST")) ret = cl_ope_list(pInfoParmW,NULL,nparm,pp,D_FUC_REST,0);
	else if (!stricmp(p1,"CONS")) ret = cl_cons_list(pInfoParmW,nparm,pp);
	else if (!stricmp(p1,"LIST_REF")) ret = cl_ope_list(pInfoParmW,NULL,nparm,pp,D_FUC_LIST_REF,0);
	else {
		ERROROUT1(FORMAT(226),p1);	/* ����w��(%s)���s���ł��B */
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_ope_list(pInfoParmW,pdummy,nparm,ppParm,ope,dummy)
tdtInfoParm *pInfoParmW;
int  nparm,ope,dummy;
tdtInfoParm *ppParm[];
char *pdummy;
{
	tdtInfoParm *pInfoParm,*p,tInfoParm;
	int rc,n,opt1,i,m,iCONST;
	tdtRbCtl *pCt;
	char id;

	rc = 0;
	cl_null_data(pInfoParmW);
	pInfoParm = ppParm[0];
	if (cl_is_null_parm(pInfoParm) || cl_is_null_data(pInfoParm)) return 0;
	if ((id=pInfoParm->pi_id)!=D_DATA_ID_LIST && id!=D_DATA_ID_NARABI) {
		ERROROUT(FORMAT(227));	/* ���X�g�ł͂���܂���B */
		return ECL_SCRIPT_ERROR;
	}
	if (ope == D_FUC_FIRST) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		if (p = (tdtInfoParm *)akxs_rb_get(pCt)) {
			if ((id=p->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)
				rc = _list_info_set(pInfoParmW,p);
			else
				cl_gx_copy_info(pInfoParmW,p);
		}
	}
	else if (ope == D_FUC_REST) {
		rc = _list_info_set(pInfoParmW,pInfoParm);
		opt1 = pGlobTable->options[4] & 0x01;
		n = akxs_rb_used(pCt=(tdtRbCtl *)pInfoParmW->pi_data);
		if (n>1 || opt1) {
			if (nparm > 1) {
				if ((rc=cl_get_parm_bin(ppParm[1],&m,"cl_ope_list REST:"))<0) return rc;
				rc = 0;
				m = X_MIN(n,m);
				for (i=0;i<m;i++) if (!akxs_rb_get_n(pCt)) break;
			}
			else akxs_rb_get_n(pCt);
		}
		else cl_null_data(pInfoParmW);
	}
	else if (ope == D_FUC_LIST_REF) {
		iCONST = pInfoParm->pi_aux[1] & D_AUX1_PROTECTED;
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		if ((n=akxs_rb_used(pCt)) <= 0) return 0;
		if (nparm > 1) {
			if ((rc=cl_get_parm_bin(ppParm[1],&m,"cl_ope_list REF:"))<0) return rc;
		}
		else m = 0;
		rc = 0;
		if (m < 0) {
			ERROROUT1(FORMAT(228),m);	/* �Q�ƈʒu(%d)���s���ł��B */
			return ECL_SCRIPT_ERROR;
		}
		if (m < n) {
			akxs_rb_read(pCt,0);
			for (i=0;i<=m;i++) if (!(p=(tdtInfoParm *)akxs_rb_read(pCt,1))) break;
			if (p) {
				if (dummy & D_GX_OPT_GET_ADDR) {
					cl_set_parm_long(pInfoParmW,(long)p);
					pInfoParmW->pi_id = 'S';
				}
				else {
					if ((id=p->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)
						rc = _list_info_set(pInfoParmW,p);
					else
						cl_gx_copy_info(pInfoParmW,p);
				}
				pInfoParmW->pi_aux[1] |= iCONST;
DEBUGOUT_InfoParm(194,"cl_ope_list: p=",p,0,0);
DEBUGOUT_InfoParm(194,"cl_ope_list: ope=%d pInfoParmW=",pInfoParmW,ope,0);
			}
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_index(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	int i,n,ix;
	tdtInfoParm *ppm[MAX_ARRAY_DIM+1];

	ppm[0] = ppParm[0];
#if 1	/* 2019.8.2 */
	n = X_MIN(nparm,MAX_ARRAY_DIM);
#else
	n = X_MIN(nparm,4);
#endif
	for (i=1;i<n;i++) ppm[i+1] = ppParm[i];
	ix = cl_gx_array_bexp(NULL,nparm+1,ppm,0);
	if (ix >= 0) ix--;
	memcpy(pWork,&ix,sizeof(int));
	if (ix > 0) ix = 0;
	return ix;
}

/****************************************/
/*										*/
/****************************************/
static int _array_cpy(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm,*pInfoParmW,rInfoParm;
	tdtInfoParm ***pTBL1,***pTBL2;
	int iRc,n,i,ix1,ix2,nm,nm1,nm2,count;
	tdtArrayIndex tIndex1,tIndex2,*pIndex;
	int *index1,*index2,iParm[4];
	char c,*name,*cpKey,*cpDat;
	XHASHB *xhpI,*xhpO;

	nm = 0;
	memcpy(pWork,&nm,sizeof(int));

	if (iRc = _get_array_info_used(nparm,ppParm,&tIndex1,&pTBL1,iParm,3)) {
		if (iRc == 2000) xhpO = tIndex1.xhp;
		else return iRc;
	}
	else xhpO = NULL;
	nm1  = iParm[1];
	ix1  = iParm[2];

	if (iRc = _get_array_info_used(nparm-2,&ppParm[2],&tIndex2,&pTBL2,iParm,1)) {
		if (iRc == 2000) xhpI = tIndex2.xhp;
		else return iRc;
	}
	else xhpI = NULL;
	nm2  = iParm[1];
	ix2  = iParm[2];

	if (!((xhpO && xhpI)||(!xhpO && !xhpI))) {
		/* array_to ���A�z�z��ł͂���܂���B */
		if (!xhpO) ERROROUT1(FORMAT(229),"_array_cpy: array_to");
		/* array_from ���A�z�z��ł͂���܂���B */
		else if (!xhpI) ERROROUT1(FORMAT(229),"_array_cpy: array_from");
		return -1;
	}

	if (nm2 < nm1) nm1 = nm2;
	nm = nm1;
	if (iRc = _get_array_num(nparm-4,&ppParm[4],nm1,&nm)) return iRc;

	if (xhpO) {
		if (iRc=_array_hash_clr(pIndex=(tdtArrayIndex *)ppParm[0]->pi_data)) return iRc;
		xhpO = pIndex->xhp;
	}

	for (count=0,i=1;;i++) {
		if (xhpI) {
			if (i>nm1 || count>=nm) break;
			xhpI->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhpI,'P',&cpKey,&cpDat)) > 0) {
				memcpy(&pInfoParm,cpDat,sizeof(tdtInfoParm *));
				if (!(pInfoParmW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
				memset(pInfoParmW,0,sizeof(tdtInfoParm));
				ix1 = akxs_xhash2(xhpO,'s',cpKey,&pInfoParmW);
				if (ix1 <= 0) {
					if (ix1 == 0) ix1 = -12;
					return ix1;
				}
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			if (i > nm) break;
			pInfoParmW = cl_get_array_and_var_ent(&tIndex1,pTBL1,ix1);
			pInfoParm  = cl_get_array_and_var_ent(&tIndex2,pTBL2,ix2);
			ix1++;
			ix2++;
		}
		if (pInfoParmW && pInfoParm) {
			if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
		}
		else {
			return -1;
		}
		count++;
	}
	memcpy(pWork,&count,sizeof(int));

	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _array_hash_clr(pIndex)
tdtArrayIndex *pIndex;
{
	int iRc,lMaxReg,lDatLen;
	XHASHB *xhp;

	if ((iRc=akxs_xhash2(xhp=pIndex->xhp,'u',NULL,NULL)) > 0) {
		lMaxReg = xhp->xha_maxreg;
		lDatLen = xhp->xha_datlen;
		akxs_xhash_free(xhp);
		if (!(pIndex->xhp = akxs_xhash_new2(0,lMaxReg,0,lDatLen))) return -9;
		iRc = 0;
	}
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _array_clr(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm,*pInfoParmW,rInfoParm;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix,nm,nm1,count,iNULL,atr,*pSize;
	char c,*name;
	tdtArrayIndex tIndex,*pIndex;
	int *index,iParm[4];

	nm = 0;
	memcpy(pWork,&nm,sizeof(int));

	if (iRc = _get_array_info_used(nparm,ppParm,&tIndex,&pTBL,iParm,3)) {
		if (iRc == 2000) iRc = _array_hash_clr(ppParm[0]->pi_data);
		return iRc;
	}
	nm1 = iParm[1];
	ix  = iParm[2];
#if 1	/* 2020.5.3 */
	cl_get_array_index(ppParm[0],&pIndex);
	atr = pIndex->uAttr[0];
	index = pIndex->index;
#endif
	nm = nm1;
	if (iRc = _get_array_num(nparm-3,&ppParm[3],nm1,&nm)) return iRc;

#if 1	/* 2020.5.3 */
	iNULL = 0;
	if (nparm >= 3) {
		pInfoParm = ppParm[2];
		if (cl_is_null_parm(pInfoParm) && atr==DEF_ZOK_VARI) {
			cl_parm_set0(pInfoParm);
			iNULL = 1;
		}
	}
	else {
		pInfoParm = &rInfoParm;
		cl_null_parm(pInfoParm);
		if (atr == DEF_ZOK_VARI) {
			cl_parm_set0(pInfoParm);
			iNULL = 1;
		}
	}
#else
	if (nparm >= 3) {
		pInfoParm = ppParm[2];
	}
	else {
		pInfoParm = &rInfoParm;
		cl_null_parm(pInfoParm);
	}
#endif
	for (i=count=0;i<nm;i++,ix++) {
		pInfoParmW = cl_get_array_and_var_ent(&tIndex,pTBL,ix);
		if (pInfoParmW) {
			if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
		}
		else {
			return -1;
		}
		count++;
	}
#if 1	/* 2020.5.3 */
	if (iNULL) {
		if (pTBL) {
			pSize = (int *)pTBL[0];
			if (pSize[7] <= (index[2] + index[3] - 1))
				cl_set_max_var_ent(pSize,-1);		
		}
		if (index[2] <= nm) index[2] = 0;
	}
#endif
	memcpy(pWork,&count,sizeof(int));

	return 0;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*			cmp_opt		: ��r�I�v�V����								*/
/*							= 0x01 : ��r�Ώۂ̐����܂߂đS�Ă��A		*/
/*									 ��v�����Ƃ��A1��Ԃ�				*/
/*	�ԋp :  cmp_opt��0x01��												*/
/*			=0�̂Ƃ��A��v��											*/
/*			=1�̂Ƃ��A1/0=��v/�s��v									*/
/********1*********2*********3*********4*********5*********6*********7***/
static int _array_cmp(pWork,nparm,ppParm,cmp_opt)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
int cmp_opt;
{
	tdtInfoParm *pInfoParm1,*pInfoParm2,*pInfoParm3;
	tdtInfoParm ***pTBL1,***pTBL2;
	int iRc,n,i,ix1,ix2,nm,nm1,nm2,len,iAns,iParm[4],count,match,nu1,nu2,nm3;
	tdtArrayIndex tIndex1,tIndex2;
	char *p1;
	char *cpKey,*cpDat;
	char id1,id2;
	XHASHB *xhp1,*xhp2;

	iAns = 0;
	memcpy(pWork,&iAns,sizeof(int));
#if 1	/* 2019.8.4 */
	pInfoParm1 = ppParm[0];
	pInfoParm2 = ppParm[2];
	if ((id1=pInfoParm1->pi_id) != (id2=pInfoParm2->pi_id)) {
		/* �p�����[�^�̃f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B */
		ERROROUT2(FORMAT(241),id1,id2);
		return -1;
	}
#endif
#if 1	/* 2019.7.31 */
	p1 = "==";
	if (nparm >= 6) {
		pInfoParm3 = ppParm[5];
		if (iRc=cl_check_attr(pInfoParm3,DEF_ZOK_CHAR,"_array_cmp.cmp")) return iRc;
		if (pInfoParm3->pi_dlen > 0) p1 = pInfoParm3->pi_data;
	}
	if (id1=='L' || id1=='N') {
		ix1 = ix2 = nm = 0;
		if (iRc=_get_num_msg_no(ppParm[1],222,0,&ix1)) return iRc;
		if (nparm >= 4) {
			if (iRc=_get_num_msg_no(ppParm[3],222,0,&ix2)) return iRc;
		}
		if (iRc = _get_array_num(nparm-4,&ppParm[4],-1,&nm)) return iRc;
		iParm[0] = ix1;
		iParm[1] = ix2;
		iParm[2] = nm;
		if ((iAns=cl_comp_list(p1,pInfoParm1,pInfoParm2,iParm,0)) >= 0) {
			memcpy(pWork,&iAns,sizeof(int));
			iRc = 0;
		}
		else iRc = iAns;
		return iRc;
	}
#endif
	if (iRc = _get_array_info_used(nparm,ppParm,&tIndex1,&pTBL1,iParm,1)) {
		if (iRc == 2000) xhp1 = tIndex1.xhp;
		else return iRc;
	}
	else xhp1 = NULL;
	nm1  = iParm[1];
	ix1  = iParm[2];
/*
printf("_array_cmp: nm1=%d ix1=%d\n",nm1,ix1);
*/
	if (iRc = _get_array_info_used(nparm-2,&ppParm[2],&tIndex2,&pTBL2,iParm,1)) {
		if (iRc == 2000) xhp2 = tIndex2.xhp;
		else return iRc;
	}
	else xhp2 = NULL;
	nm2  = iParm[1];
	ix2  = iParm[2];
/*
printf("_array_cmp: nm2=%d ix2=%d\n",nm2,ix2);
*/
	if (!((xhp1 && xhp2)||(!xhp1 && !xhp2))) {
		/* array1 ���A�z�z��ł͂���܂���B */
		if (!xhp1) ERROROUT1(FORMAT(229),"_array_cmp: array1");
		/* array2 ���A�z�z��ł͂���܂���B */
		else if (!xhp2) ERROROUT1(FORMAT(229),"_array_cmp: array2");
		return -1;
	}

#if 1	/* 2019.7.31 */
	nm3 = X_MIN(nm1,nm2);
	nm = nm3;
	if (iRc = _get_array_num(nparm-4,&ppParm[4],nm3,&nm)) return iRc;
/*
printf("_array_cmp: nm3=%d nm=%d cmp_opt=%02x\n",nm3,nm,cmp_opt);
*/
	if (cmp_opt & 0x01) {
		if (xhp1) {
			nu1 = akxs_xhash2(xhp1,'U',&cpKey,&cpDat);
			nu2 = akxs_xhash2(xhp2,'U',&cpKey,&cpDat);
		}
		else {
			nu1 = nm1;
			nu2 = nm2;
		}
	/*
		if (nu1 > nm) nu1 = nm;
		if (nu2 > nm) nu2 = nm;
	*/
/*
printf("_array_cmp: nu1=%d nu2=%d\n",nu1,nu2);
*/
		if (nu1 != nu2) return 0;
	}
	nm1 = nm3;
#else
	if (nm2 < nm1) nm1 = nm2;
	nm = nm1;
	if (iRc = _get_array_num(nparm-4,&ppParm[4],nm1,&nm)) return iRc;
#endif
#if 0	/* 2019.7.31 */
	p1 = "==";
	if (nparm >= 6) {
		pInfoParm1 = ppParm[5];
		if (iRc=cl_check_attr(pInfoParm1,DEF_ZOK_CHAR,"_array_cmp.cmp")) return iRc;
		if (pInfoParm1->pi_dlen > 0) p1 = pInfoParm1->pi_data;
	}
#endif
/*
printf("_array_cmp: nm=%d\n",nm);
*/
	count=match=0;
	for (i=1;;i++) {
		if (xhp1) {
			if (i>nm1 || count>=nm) break;
			xhp1->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhp1,'P',&cpKey,&cpDat)) > 0) {
				memcpy(&pInfoParm1,cpDat,sizeof(tdtInfoParm *));
				if ((iRc=akxs_xhash2(xhp2,'R',cpKey,&cpDat)) > 0) {
					memcpy(&pInfoParm2,cpDat,sizeof(tdtInfoParm *));
				}
				else if (iRc < 0) return iRc;
				else continue;
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			if (i > nm) break;
			pInfoParm1 = cl_get_array_and_var_ent(&tIndex1,pTBL1,ix1);
			pInfoParm2 = cl_get_array_and_var_ent(&tIndex2,pTBL2,ix2);
			ix1++;
			ix2++;
		}
		if (pInfoParm1 && pInfoParm2) {
			count++;
			if ((iRc=cl_cmpt_comp(&iAns,p1,pInfoParm1,pInfoParm2,0,NULL)) < 0) iAns = 0;
			if (!iAns) break;
			match++;
		}
		else {
			return -1;
		}
	}
#if 1	/* 2019.7.31 */
	if ((cmp_opt & 0x01) && match) match = 1;
#endif
	memcpy(pWork,&match,sizeof(int));
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _array_bxp(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*pInfoParmW,*pInfoParm2,tInfoParm;
	tdtInfoParm ***pTBL1,***pTBL2,***pTBL3;
	int iRc,n,i,ix1,ix2,ix3,nm,nm1,nm2,nm3,len,count,iParm[4];
	tdtArrayIndex tIndex1,tIndex2,tIndex3,*pIndex;
	XHASHB *xhp1,*xhp2,*xhp3;
	char *p1,*cpKey,*cpDat;

	count = 0;
	memcpy(pWork,&count,sizeof(int));

	if (iRc = _get_array_info_used(nparm,ppParm,&tIndex1,&pTBL1,iParm,3)) {
		if (iRc == 2000) xhp1 = tIndex1.xhp;
		else return iRc;
	}
	else xhp1 = NULL;
	nm1  = iParm[1];
	ix1  = iParm[2];

	if (iRc = _get_array_info_used(nparm-2,&ppParm[2],&tIndex2,&pTBL2,iParm,1)) {
		if (iRc == 2000) xhp2 = tIndex2.xhp;
		else return iRc;
	}
	else xhp2 = NULL;
	nm2  = iParm[1];
	ix2  = iParm[2];

	if (iRc = _get_array_info_used(nparm-4,&ppParm[4],&tIndex3,&pTBL3,iParm,1)) {
		if (iRc == 2000) xhp3 = tIndex3.xhp;
		else return iRc;
	}
	else xhp3 = NULL;
	nm3  = iParm[1];
	ix3  = iParm[2];

	if (!((xhp1 && xhp2 && xhp3)||(!xhp1 && !xhp2 && !xhp3))) {
		/* array_to ���A�z�z��ł͂���܂���B */
		if (!xhp1) ERROROUT1(FORMAT(229),"_array_bxp: array_to");
		/* array_1 ���A�z�z��ł͂���܂���B */
		if (!xhp2) ERROROUT1(FORMAT(229),"_array_bxp: array_1");
		/* array_2 ���A�z�z��ł͂���܂���B */
		if (!xhp3) ERROROUT1(FORMAT(229),"_array_bxp: array_2");
		return -1;
	}

	if (nm2 < nm1) nm1 = nm2;
	if (nm3 < nm1) nm1 = nm3;
	nm = nm1;
	if (iRc = _get_array_num(nparm-6,&ppParm[6],nm1,&nm)) return iRc;

	p1 = "+";
	if (nparm >= 8) {
		pInfoParmW = ppParm[7];
		if (iRc=cl_check_attr(pInfoParmW,DEF_ZOK_CHAR,"_array_bxp.bxp")) return iRc;
		if (pInfoParmW->pi_dlen > 0) p1 = pInfoParmW->pi_data;
	}

	if (xhp1) {
		if (iRc=_array_hash_clr(pIndex=(tdtArrayIndex *)ppParm[0]->pi_data)) return iRc;
		xhp1 = pIndex->xhp;
	}

	for (count=0,i=1;;i++) {
		if (xhp2) {
			if (i>nm1 || count>=nm) break;
			xhp2->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhp2,'P',&cpKey,&cpDat)) > 0) {
				memcpy(&pInfoParm1,cpDat,sizeof(tdtInfoParm *));
				if ((iRc=akxs_xhash2(xhp3,'R',cpKey,&cpDat)) > 0) {
					memcpy(&pInfoParm2,cpDat,sizeof(tdtInfoParm *));
				}
				else if (iRc < 0) return iRc;
				else continue;
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			if (i > nm) break;
			pInfoParmW = cl_get_array_and_var_ent(&tIndex1,pTBL1,ix1);
			pInfoParm1 = cl_get_array_and_var_ent(&tIndex2,pTBL2,ix2);
			pInfoParm2 = cl_get_array_and_var_ent(&tIndex3,pTBL3,ix3);
			ix1++;
			ix2++;
			ix3++;
		}
		if (pInfoParm1 && pInfoParm2) {
			if (iRc=cl_gx_bexp(&tInfoParm,pInfoParm1,p1,pInfoParm2,0,0)) return iRc;
			if (xhp2) {
				if (!(pInfoParmW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
				memset(pInfoParmW,0,sizeof(tdtInfoParm));
				ix1 = akxs_xhash2(xhp1,'s',cpKey,&pInfoParmW);
				if (ix1 <= 0) {
					if (ix1 == 0) ix1 = -12;
					return ix1;
				}
			}
			else {
				if (!pInfoParmW) return -1;
				if (iRc=cl_gx_rep_info_set(pInfoParmW,&tInfoParm,1)) return iRc;
			}
			count++;
		}
		else {
			return -1;
		}
	}
	memcpy(pWork,&count,sizeof(int));
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_ope_opt(pWork,nparm,ppParm,ope,cmp_opt)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
int  ope;
int  cmp_opt;
{
	int ret,ok_opt;

DEBUGOUT_InfoParm(110,"cl_array_ope_opt:Enter ope=%d cmp_opt=%d ppParm[0]=",ppParm[0],ope,cmp_opt);
if (nparm > 2) {
DEBUGOUT_InfoParm(110,"                 ppParm[2]=",ppParm[2],0,0);
}
	ok_opt = 0x02 | 0x08 | 0x1000;
	if (cl_check_data_id(ppParm[0],~ok_opt)) return ECL_SCRIPT_ERROR;
	if (ope != D_FUC_ARRAY_CLR) {
		if (cl_check_data_id(ppParm[2],~ok_opt)) return ECL_SCRIPT_ERROR;
	}
	if (ope == D_FUC_ARRAY_BXP) {
		if (cl_check_data_id(ppParm[4],~ok_opt)) return ECL_SCRIPT_ERROR;
	}

	if      (ope == D_FUC_ARRAY_CPY) ret = _array_cpy(pWork,nparm,ppParm);
	else if (ope == D_FUC_ARRAY_CLR) ret = _array_clr(pWork,nparm,ppParm);
	else if (ope == D_FUC_ARRAY_CMP) ret = _array_cmp(pWork,nparm,ppParm,cmp_opt);
	else if (ope == D_FUC_ARRAY_BXP) ret = _array_bxp(pWork,nparm,ppParm);

	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_ope(pWork,pOperator,nparm,ppParm,ope,opt)
char *pWork,*pOperator;
int  nparm,ope,opt;
tdtInfoParm *ppParm[];
{
	return cl_array_ope_opt(pWork,nparm,ppParm,ope,0);
}

/****************************************/
/*										*/
/****************************************/
static int _list_array_set(pCt,pInfoParmI)
tdtRbCtl *pCt;
tdtInfoParm *pInfoParmI;
{
	tdtInfoParm *pInfoParm1,*pInfoParm;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix,nm,len,iAns,iParm[4],count,match;
	tdtArrayIndex tIndex;
	char *p1;
	char *cpKey,*cpDat;
	XHASHB *xhp;

	if (iRc = _get_array_info(1,&pInfoParmI,&tIndex,&pTBL,iParm,3)) {
		if (iRc == 2000) xhp = tIndex.xhp;
		return iRc;
	}
	else xhp = NULL;
	nm = iParm[1];
	ix = iParm[2];

	for (i=1;i<=nm;i++,ix++) {
		if (xhp) {
			xhp->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhp,'P',&cpKey,&cpDat)) > 0) {
				memcpy(&pInfoParm,cpDat,sizeof(tdtInfoParm *));
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			pInfoParm = cl_get_array_and_var_ent(&tIndex,pTBL,ix);
		}
		if (pInfoParm) {
			if (cl_is_undef_parm(pInfoParm) || cl_is_null_parm(pInfoParm)) continue;
			if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
			if ((iRc=_list_info_set(pInfoParm1,pInfoParm)) < 0) return iRc;
			if (!cl_tmp_rbset_n(pCt,pInfoParm1)) return ECL_MALLOC_ERROR;
		}
		else {
			return -1;
		}
	}

	return iRc;
}
