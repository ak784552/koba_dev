static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �z�񏈗�                                               *
*                                                                             *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
#if 1	/* 2020.5.1 */
int cl_get_array_index(pInfoParm,ppIndex)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
#else
int cl_get_array_index(pInfoParm,pIndex)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
#endif
{
	char c;
	int  rc;

#if 1	/* 2020.5.1 */
	if (!pInfoParm || !ppIndex) return -1;
	*ppIndex = NULL;
#else
	if (!pInfoParm) return -1;
#endif
	if (((c=pInfoParm->pi_id)=='A' || c=='R') &&
		pInfoParm->pi_dlen == sizeof(tdtArrayIndex)) {
#if 1	/* 2020.5.1 */
		*ppIndex = (tdtArrayIndex *)pInfoParm->pi_data;
#else
		memcpy(pIndex,pInfoParm->pi_data,sizeof(tdtArrayIndex));
#endif

DEBUGOUT_InfoParm(194,"cl_get_array_index: ",pInfoParm,0,0);

		rc = 0;
	}
	else rc = ECL_SYSTEM_ERROR;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_index_tbl(pInfoParm,pIndex,ppTBL,pMsg)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
char *pMsg;
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	if (!(iRc=cl_get_array_index_tbl_ref(pInfoParm,&pIndexW,ppTBL,pMsg))) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*******/
/*	�����F	ppIndex : *ppIndex �ɂ́A&tIndex ���A		*/
/*					    �ݒ肳��Ă��邱��				*/
/*					  *ppIndex �ɂ́AA or R �̂Ƃ��A	*/
/*						�z���pIndex���Ԃ����B		*/
/********************************************************/
int cl_get_array_index_tbl_ref(pInfoParm,ppIndex,ppTBL,pMsg)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
char *pMsg;
{
	ScrPrCT	*pScCT;
	ProcCT  *proc;
	int *index;
	tdtInfoParm ***pTBL,*pInfo;
	tdtArrayIndex *pIndex;
	int iRc,*pSize,m;
	char c,*name,cn;

DEBUGOUT_InfoParm(191,"cl_get_array_index_tbl_ref: pMsg=[%s] ",pInfoParm,pMsg,0);

	pTBL = NULL;
	if (ppTBL) *ppTBL = pTBL;
	if (!ppIndex) return -1;
	pIndex = *ppIndex;
	memset(pIndex,0,sizeof(tdtArrayIndex));
	if ((c=pInfoParm->pi_id) != 'R') {
		if (pScCT = cl_search_src_ct()) {
			pTBL = pScCT->Vary->pTBL_dolu;
			if (c == 'A') {
				name = (char *)pInfoParm->pi_pos;
/*
printf("cl_get_array_index_tbl: name=[%s]\n",name);
*/
				if ((cn=*name) == '#')
					pTBL = pScCT->Vary->pTBL_igeta;
				else if (cn == '%') {
					if (pInfoParm->pi_aux[1] & D_AUX1_LOCAL_VAR) {
						if (!(proc = cl_search_proc_ct())) return SysError;
						pTBL = proc->pTBL_pasento;
					}
					else
						pTBL = pScCT->Vary->pTBL_pasento;
				}
			}
			if (ppTBL) *ppTBL = pTBL;
			pSize = (int *)pTBL[0];
DEBUGOUTL4(191,"cl_get_array_index_tbl: pSize = %d %d %d [%s]",pSize[0],pSize[1],pSize[2],&pSize[3]);
DEBUGOUTL2(191,"                                %d %d",pSize[5],pSize[6]);
		}
		else return -1;
	}
	else if (c == 'R') {
		if (pInfo=(tdtInfoParm *)pInfoParm->pi_paux) {
			if (pInfo->pi_id != 'R') {
				if (!(name=(char *)pInfoParm->pi_pos)) name = AKX_NULL_PRINT;
				/* cl_get_array_index_tbl: �z��[%s]�������ł��B */
				ERROROUT1(FORMAT(231),name);
				return ECL_SCRIPT_ERROR;
			}
		}
	}
	index = pIndex->index;
/*
printf("cl_get_array_index_tbl:1 pIndex=%08x Index=%08x\n",pIndex,index);
*/
DEBUGOUTL5(191,"cl_get_array_index_tbl:1 index = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);

	if (c == 'A' || c == 'R') {
		if (iRc = cl_get_array_index(pInfoParm,&pIndex)) return iRc;
		if (ppIndex) *ppIndex = pIndex;
		index = pIndex->index;
/*
printf("cl_get_array_index_tbl:2 pIndex=%08x Index=%08x index[2]=%d\n",pIndex,index,index[2]);
*/
#if 0	/* 2017.07.23 koba */
		index[1] *= index[2]*index[3];
#endif
	}
	else {
#if 1	/* 2017.07.23 koba */
		if (iRc = cl_get_parm_bin(pInfoParm,index+3,pMsg)) return iRc;
		index[1] = pSize[2] - (index[3] - 1);
#else
		if (iRc = cl_get_parm_bin(pInfoParm,index,pMsg)) return iRc;
		index[1] = pSize[2] - (index[0] - 1);
#endif
	}

DEBUGOUTL5(191,"cl_get_array_index_tbl:2 index = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);

#if 1	/* 2017.07.23 koba */
	if ((c=='R' && index[3]<0) ||
	    (c!='R' && (index[3]<=0 || index[3]>pSize[2]))) {
		ERROROUT1(FORMAT(232),index[3]);	/* �C���f�b�N�X�̏����l(%d)���s���ł��B */
		return -1;
	}
#else
	if ((c=='R' && index[0]<0) ||
	    (c!='R' && (index[0]<=0 || index[0]>pSize[2]))) {
		ERROROUT1(FORMAT(232),index[0]);	/* �C���f�b�N�X�̏����l(%d)���s���ł��B */
		return -1;
	}
#endif
#if 0	/* 2020.5.3 ����́A�s�v�ɂȂ���(cl_reflect_size_of_number_array()��ǉ�����)�̂Œǉ����Ȃ� */
	/* mappedarray �̂Ƃ��́Amap ����pSize[7]���������傫�������甽�f����B*/
	if (c=='A' && pTBL) {
		pSize = (int *)pTBL[0];
		if ((m=pSize[7]-index[3]+1) > index[2]) index[2] = m;
	}
#endif
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_check_use_mapped_array(pInfoParm)
tdtInfoParm *pInfoParm;
{
	char *name,c;

	if (pInfoParm->pi_id == 'A') {
		name = (char *)pInfoParm->pi_pos;
/*
printf("cl_check_use_mapped_array: name=[%s]\n",name);
*/
		if ((c=*name)=='%' || c=='#') {
			ERROROUT1(FORMAT(233),name);	/* �w��ł��Ȃ��z��(%s)�ł��B */
			return -1;
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_check_use_hash_array(pInfoParmArray,pIndex)
tdtInfoParm *pInfoParmArray;
tdtArrayIndex *pIndex;
{
	if (pIndex->xhp ||
#if 1	/* 2017.07.23 koba */
/*	    (pInfoParmArray->pi_id=='R' && (pIndex->index[2] & 0x80))) {	2020.4.30 */
	    (pInfoParmArray->pi_id=='R' && (pIndex->index[2] < 0))) {
#else
	    (pInfoParmArray->pi_id=='R' && (pIndex->index[MAX_ARRAY_DIM+1] & 0x80))) {
#endif
		/* cl_check_use_hash_array: can't use hash array[%s]!! */
		ERROROUT1(FORMAT(234),(char *)pInfoParmArray->pi_pos);
		return -1;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,opt)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
int  ix;
char opt;
{
	int iRc,attr,attr0,iParm[4],*index;
	tdtInfoParm *pInfoParm,rInfoParm;

	pInfoParm = NULL;
	if (pTBL)
#if 1	/* 2020.4.30 koba */
		pInfoParm = cl_get_var_ent_opt(pTBL,ix,opt);
#else
		pInfoParm = cl_get_var_ent(pTBL,ix);
#endif
	else if (pIndex) {
		attr = pIndex->uAttr[0];
		if (attr) {
#if 1
			attr0 = 0;
			if ((attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) && !pIndex->size) {
				attr0 = attr;
				attr = DEF_ZOK_VARI;
/*
printf("cl_get_array_and_var_ent_opt: ix=%d opt=%c attr0=%d\n",ix,opt,attr0);
*/
			}
#endif
			if (attr == DEF_ZOK_VARI) {
				pInfoParm = cl_get_array_ent_opt(pIndex->pVarIndex,ix,opt);
#if 1
				if (pInfoParm) {
					if (attr0 && !pInfoParm->pi_aux[0]) {
						iParm[0] = attr0;
						iParm[1] = 0;
						cl_set_parm_init(pInfoParm,iParm,0x01);
					}
				}
#endif
			}
			else {
				if (!cl_get_array_val_opt(&rInfoParm,pIndex,ix,'s'))
					pInfoParm = (tdtInfoParm *)rInfoParm.pi_pos;
			}
#if 1	/* 2020.4.30 */
			if (pInfoParm && opt=='s') {
				index = pIndex->index;
printf("cl_get_array_val_opt: index=%08x ix=%d index[2]=%d\n",index,ix,index[2]);
				index[2] = X_MAX(index[2],ix);
			}
#endif
		}
	}

	return pInfoParm;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_and_var_ent(pIndex,pTBL,ix)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
int  ix;
{
	return cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'s');
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_conv_index(pInfoParm,pIndex)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
{
	tdtArrayIndex tIndex;
	int  attr,i,ji_1,mx,iSTART,iIXPOS,f,m1,m2;
	int  n,*index,*index_info,nn,iRANGE,ndim,nn1,nn2;
	char c,*varnam;

	if (!pInfoParm || !pIndex) return ECL_SYSTEM_ERROR;
	c = pInfoParm->pi_id;
	n = pInfoParm->pi_dlen;
/*
printf("cl_gx_conv_index: pInfoParm->pi_id=%c len=%d\n",c,n);
*/
    if ((n == sizeof(tdtArrayIndex)) && ((c == 'A') || (c == 'R'))) {
		if (!pInfoParm->pi_data) return ECL_SYSTEM_ERROR;
		memcpy(&tIndex,pInfoParm->pi_data,n);
		pIndex->pVarIndex = tIndex.pVarIndex;
		pIndex->size = tIndex.size;
		memcpy(pIndex->uAttr,tIndex.uAttr,sizeof(pIndex->uAttr));
		pIndex->xhp = tIndex.xhp;
	}
	else return ECL_SYSTEM_ERROR;

	index = tIndex.index;

DEBUGOUTL5(191,"cl_gx_conv_index: index = %d %d %d %d %d",
index[0],index[1],index[2],index[3],index[4]);
DEBUGOUTL5(191,"cl_gx_conv_index: index = %d %d %d %d %d",
index[5],index[6],index[7],index[8],index[9]);

	index_info = pIndex->index;

DEBUGOUTL5(191,"cl_gx_conv_index: index_info = %d %d %d %d %d",
index_info[0],index_info[1],index_info[2],index_info[3],index_info[4]);
DEBUGOUTL5(191,"cl_gx_conv_index: index_info = %d %d %d %d %d",
index_info[5],index_info[6],index_info[7],index_info[8],index_info[9]);

#if 1	/* 2017.07.23 koba */
	ndim = index[0];
	ji_1 = X_MIN(index_info[0],ndim);
	iSTART = pGlobTable->options[14] & 0x01;
	iIXPOS = pGlobTable->options[14] & 0x02;
/*	iRANGE = index[2];	*/
	mx = ji_1;
/*	f = 1;	*/
	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam = AKX_NULL_PRINT;
	for (i=1;i<=ndim;i++) {
		if (i <= ji_1) {
			n = index_info[i+3];
			nn = index[i+3];
			if (nn <= 0) {
				/* cl_gx_conv_index:[%s]�̃C���f�b�N�X�T�C�Y��0�ł��Bi=%d index=%d (def=None) */
				ERROROUT3(FORMAT(235),varnam,i,n);
				return ECL_SCRIPT_ERROR;
			}
			m1 = 0;
			m2 = nn - 1;
		/*	if (iRANGE & f) {	*/
				m1 = index[i+ndim+3];
				m2 += m1;
		/*	}
			else if (iSTART) {
				m1++;
				m2++;
			}	*/
			if (n<m1 || n>m2) {
				/* cl_gx_conv_index:[%s]�̃C���f�b�N�X���͈͊O�ł��Bi=%d index=%d (def=%d..%d) */
				ERROROUT5(FORMAT(236),varnam,i,n,m1,m2);
				return ECL_SCRIPT_ERROR;
			}
		}
		else if (index[i+3] > 1) mx = i;
	/*	f = f<<1;	*/
	}
/*
printf("cl_gx_conv_index: mx=%d ji_1=%d\n",mx,ji_1);
*/
	if (ji_1 > 0) {
		if (iIXPOS) {
		/*	f = 1<<(mx-1);	*/
			n = index_info[mx+3];
		/*	if (iRANGE & f) */n -= index[mx+ndim+3];
		/*	else if (iSTART) n--;
			f = f>>1;	*/
			for (i=1;i<mx;i++) {
				nn = index_info[mx-i+3];
			/*	if (iRANGE & f) */nn -= index[mx-i+ndim+3];
			/*	else if (iSTART) nn--;	*/
/*
printf("cl_gx_conv_index: i=%d n=%d nn=%d f=%x\n",i,n,nn,f);
*/
				n = n*index[mx-i+3] + nn;
			/*	f = f>>1;	*/
			}
		}
		else {
			n = index_info[4];
		/*	if (iRANGE & 0x01) */n -= index[1+ndim+3];
		/*	else if (iSTART) n--;
			f = 2;	*/
			for (i=2;i<=mx;i++) {
/*
printf("cl_gx_conv_index: i=%d n=%d\n",i,n);
*/
				nn = index_info[i+3];
			/*	if (iRANGE & f) */nn -= index[i+ndim+3];
			/*	else if (iSTART) nn--;	*/
				n = n*index[i+3] + nn;
			/*	f = f<<1;	*/
			}
		}
	}
/*
printf("cl_gx_conv_index: n=%d index[3]=%d\n",n,index[3]);
*/
	return n + index[3];
#else
#if 0
	ji_1 = index_info[0] + 1;
#else
	ji_1 = X_MIN(index_info[0],MAX_ARRAY_DIM);
/*	ji_1++;	*/
#endif
	iSTART = pGlobTable->options[14] & 0x01;
	iIXPOS = pGlobTable->options[14] & 0x02;
	iRANGE = index[2];
	mx = ji_1;
	f = 1;
	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam = AKX_NULL_PRINT;
/*	for (i=1;i<ji_1;i++) {	*/
	for (i=1;i<=MAX_ARRAY_DIM;i++) {
		if (i <= ji_1) {
			n = index_info[i];
			nn = index[i];
			if (nn <= 0) {
				/* cl_gx_conv_index:[%s]�̃C���f�b�N�X�T�C�Y��0�ł��Bi=%d index=%d (def=None) */
				ERROROUT3(FORMAT(235),varnam,i,n);
				return ECL_SCRIPT_ERROR;
			}
			m1 = 0;
			m2 = nn - 1;
			if (iRANGE & f) {
				m1 = index[i+MAX_ARRAY_DIM+1];
				m2 += m1;
			}
			else if (iSTART) {
				m1++;
				m2++;
			}
			if (n<m1 || n>m2) {
				/* cl_gx_conv_index:[%s]�̃C���f�b�N�X���͈͊O�ł��Bi=%d index=%d (def=%d..%d) */
				ERROROUT5(FORMAT(236),varnam,i,n,m1,m2);
				return ECL_SCRIPT_ERROR;
			}
		}
		else if (index[i] > 1) mx = i;
		f = f<<1;
	}
/*
printf("cl_gx_conv_index: mx=%d ji_1=%d\n",mx,ji_1);
*/
	if (ji_1 > 0) {
		if (iIXPOS) {
			f = 1<<(mx-1);
			n = index_info[mx];
			if (iRANGE & f) n -= index[mx+MAX_ARRAY_DIM+1];
			else if (iSTART) n--;
			f = f>>1;
			for (i=1;i<mx;i++) {
				nn = index_info[mx-i];
				if (iRANGE & f) nn -= index[mx-i+MAX_ARRAY_DIM+1];
				else if (iSTART) nn--;
/*
printf("cl_gx_conv_index: i=%d n=%d nn=%d f=%x\n",i,n,nn,f);
*/
				n = n*index[mx-i] + nn;
				f = f>>1;
			}
		}
		else {
			n = index_info[1];
			if (iRANGE & 0x01) n -= index[MAX_ARRAY_DIM+2];
			else if (iSTART) n--;
			f = 2;
		/*	for (i=2;i<ji_1;i++) {	*/
			for (i=2;i<=mx;i++) {
/*
printf("cl_gx_conv_index: i=%d n=%d\n",i,n);
*/
				nn = index_info[i];
				if (iRANGE & f) nn -= index[i+MAX_ARRAY_DIM+1];
				else if (iSTART) nn--;
				n = n*index[i] + nn;
				f = f<<1;
			}
		}
	}
/*
printf("cl_gx_conv_index: n=%d\n",n);
*/
	return n + index[0];
#endif
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_ent_opt(pVarIndex,iParmNo,opt)
tdtInfoParm *pVarIndex[];
int iParmNo;
char opt;
{
	tdtInfoParm *pDummy;

	if (!pVarIndex) return NULL;

	if (!(pDummy = pVarIndex[--iParmNo])) {
		if (opt == 's' || (pGlobTable->options[0] & 0x01)) {
			if (pDummy=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm))) {
				memset(pDummy,0,sizeof(tdtInfoParm));
				pVarIndex[iParmNo] = pDummy;
				if (pGlobTable->options[0] & 0x01) cl_null_data(pDummy);
			}
		}
	}
	return pDummy;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_array_ent(pVarIndex,iParmNo)
tdtInfoParm *pVarIndex[];
int iParmNo;
{
	return cl_get_array_ent_opt(pVarIndex,iParmNo,'s');
}

/****************************************/
/*										*/
/****************************************/
int cl_free_array_ent(pIndex)
tdtArrayIndex *pIndex;
{
	tdtInfoParm *cpDat,**pVarIndex,**p,*pDummy;
	int *index;
	int i,n,ix,k,maxreg,attr;
	XHASHB *xhp;

	if ((xhp=(XHASHB *)pIndex->xhp)) {
		maxreg = akxs_xhash(xhp,'m',NULL);
		for (k=1;k<=maxreg;k++) {
			xhp->xha_xhix = k;
			ix = akxs_xhash2(xhp,'k',NULL,&cpDat);
			if (ix > 0) {
				memcpy(&pDummy,cpDat,sizeof(tdtInfoParm *));
				if (pDummy) {
					cl_free_info_parm(pDummy);
					Free(pDummy);
				}
			}
		}
		akxs_xhash_free(xhp);
		pIndex->xhp = NULL;
		if (pVarIndex = pIndex->pVarIndex) {
			if (!(pIndex->uAttr[1] & D_ATR1_NO_MALLOC)) Free(pVarIndex);
			pIndex->pVarIndex = NULL;
		}
	}
	else if (pVarIndex = pIndex->pVarIndex) {
		if (((attr=pIndex->uAttr[0])==DEF_ZOK_VARI) ||
		    ((attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) && !pIndex->size)) {
			index = pIndex->index;
#if 1	/* 2017.07.23 koba */
			n = index[1];
#else
			n = index[1]*index[2]*index[3];
#endif
			for (i=0,p=pVarIndex;i<n;i++,p++) {
				if (pDummy = *p) {
					cl_free_info_parm(pDummy);
					Free(pDummy);
				}
			}
		}
		if (!(pIndex->uAttr[1] & D_ATR1_NO_MALLOC)) Free(pVarIndex);
		pIndex->pVarIndex = NULL;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_val_opt(pInfoParmW,pIndex,iParmNo,opt)
tdtInfoParm *pInfoParmW;
tdtArrayIndex *pIndex;
int iParmNo;
char opt;
{
	tdtInfoParm *pInfoParm, *pParm;
	char *p,*pp;
	int *pi,val,attr,len,size,*index;
	double *pd;

	if (!pIndex) return -1;
	attr = pIndex->uAttr[0];
	size = pIndex->size;
DEBUGOUTL2(194,"cl_get_array_val_opt: attr=%d size=%d",attr,size);
	if (!attr) {
		/* cl_get_array_val_opt: can't use hash arrray!! */
		ERROROUT(FORMAT(237));
		return ECL_SCRIPT_ERROR;
	}
	p = (char *)pIndex->pVarIndex;
	iParmNo--;
	if (opt == 's') {
		if (!(pInfoParm=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
			return ECL_SYSTEM_ERROR;
		pParm = pInfoParm;
	}
	else if (!(pParm = pInfoParmW)) return -1;

	if (attr == DEF_ZOK_BINA) {
		pp = (char *)&((int *)p)[iParmNo];
		cl_set_parm_bin(pParm,*(int *)pp);
	}
	else if (attr == DEF_ZOK_FLOA) {
		pp = (char *)&((double *)p)[iParmNo];
		cl_set_parm_double(pParm,*(double *)pp);
	}
	else if (attr == DEF_ZOK_DECI) {
		pp = (char *)&((MPA *)p)[iParmNo];
		cl_set_parm_mpa(pParm,(MPA *)pp);
		pParm->pi_hlen = pIndex->uAttr[2];	/* precision */
		pParm->pi_pos = pIndex->uAttr[3];	/* scale */
	}
	else if (attr == DEF_ZOK_CHAR) {
		pp = p + iParmNo*(size+1);
		*(pp+size) = '\0';
		cl_set_parm_char(pParm,pp,strlen(pp));
	}
	else if (attr == DEF_ZOK_DATE) {
		pp = (char *)&((MPA *)p)[iParmNo];
		cl_set_parm_date(pParm,(MPA *)pp);
	}
	else if (attr == DEF_ZOK_BULK) {
		pp = p + iParmNo*(size+sizeof(int));
		memcpy(&len,pp+size,sizeof(int));
		cl_set_parm_char(pParm,pp,len);
		pParm->pi_attr = attr;
	/*	pParm->pi_len = size;	*/
	}
DEBUGOUTL2(194,"cl_get_array_val_opt: p=%08x pp=%08x",p,pp);
DEBUGOUT_InfoParm(194,"cl_get_array_val_opt: iParm-1=%d opt=%c",pParm,iParmNo,opt);
/*
printf("cl_get_array_val_opt: opt=%c attr=%d pp=%08x\n",opt,attr,pp);
*/
	if (opt == 's') {
		pInfoParm->pi_aux[0] = attr;
		pInfoParm->pi_len = size;
		pInfoParm->pi_paux = pp;
		cl_set_parm_long(pInfoParmW,(long)pInfoParm);
		pInfoParmW->pi_id  = 'S';
DEBUGOUT_InfoParm(194,"cl_get_array_val_opt: ",pInfoParmW,0,0);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_get_info_parm(ppParmI,pIndex1,pTBL1,ix1,opt)
tdtInfoParm **ppParmI;
tdtArrayIndex *pIndex1;
tdtInfoParm ***pTBL1;
int ix1;
char opt;
{
	XHASHB *xhp1;
	tdtInfoParm *pParmI;
	int iRc;
	char *cpKey,*cpDat;

	iRc = 0;
	pParmI = NULL;
	xhp1 = pIndex1->xhp;
	if (xhp1) {
		xhp1->xha_xhix = ix1;
		if ((iRc=akxs_xhash2(xhp1,'P',&cpKey,&cpDat)) > 0) {
			memcpy(&pParmI,cpDat,sizeof(tdtInfoParm *));
			xhp1->xha_hashb->ha_key = cpKey;
/*
printf("cl_array_get_info_parm: ix1=%d key=[%s] pParm=%08x\n",ix1,cpKey,pParmI);
*/
		}
	}
	else {
		pParmI = cl_get_array_and_var_ent_opt(pIndex1,pTBL1,ix1,opt);
		iRc = 1;
	}
	*ppParmI = pParmI;
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_array_info(pInfoParm,pIndex,ppTBL,iParm)
tdtInfoParm *pInfoParm;
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[];
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	if (!(iRc=cl_get_array_info_ref(pInfoParm,&pIndexW,ppTBL,iParm))) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*******/
/*	�����F	ppIndex : *ppIndex �ɂ́A&tIndex ���A		*/
/*					    �ݒ肳��Ă��邱��				*/
/*					  *ppIndex �ɂ́AA or R �̂Ƃ��A	*/
/*						�z���pIndex���Ԃ����B		*/
/********************************************************/
int cl_get_array_info_ref(pInfoParm,ppIndex,ppTBL,iParm)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[];
{
	int iRc,ix0,*index;
	XHASHB *xhp;
	tdtArrayIndex *pIndex;

	mem_set_int(iParm,0,4);
	pIndex = *ppIndex;
/*
printf("cl_get_array_info_ref:1 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	memset(pIndex,0,sizeof(tdtArrayIndex));
	if (iRc=cl_get_array_index_tbl_ref(pInfoParm,ppIndex,ppTBL,"cl_get_array_info:")) return iRc;
	if (pIndex = *ppIndex) {
/*
printf("cl_get_array_info_ref:2 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
		if (pInfoParm->pi_id=='R' && (xhp=pIndex->xhp)) {
			iParm[1] = akxs_xhash2(xhp,'M',NULL,NULL);
			iParm[2] = 1;
		}
		else {
			index = pIndex->index;
			iParm[1] = index[1];
#if 1	/* 2017.07.23 koba */
			iParm[2] = index[3];
#else
			iParm[2] = index[0];
#endif
			iParm[3] = index[2];	/* 2020.4.30 */
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_mapped_array(pInfoParmW,pInfoParm1,pOperator,pInfoParm2)
char *pOperator;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParmW;
{
	static char *_fn_="cl_get_mapped_array";
	tdtInfoParm *pInfoParmA;
	tdtArrayIndex *pIndex;
	char c,id1,id2;
	int rc,ix,*index,n,i,m,nr;

	if ((c=*pOperator)!='+' && c!='-') {
		/* %s: ���Z(%s)�͎g�p�ł��܂���B */
		ERROROUT2(FORMAT(238),_fn_,pOperator);
		return ECL_SCRIPT_ERROR;
	}
	if ((id1=pInfoParm1->pi_id) == ' ') {
		if (rc=cl_get_parm_bin(pInfoParm1,&ix,FORMAT(163))) return rc;	/* ���� */
		pInfoParmA = pInfoParm2;
	}
	else if ((id2=pInfoParm2->pi_id) == ' ') {
		if (rc=cl_get_parm_bin(pInfoParm2,&ix,FORMAT(164))) return rc;	/* �E�� */
		pInfoParmA = pInfoParm1;
	}
	pIndex = (tdtArrayIndex *)pInfoParmA->pi_data;
	if (pIndex->xhp) {
		/* %s: �A�z�z��(%s)�͎w��ł��܂���B */
		ERROROUT2(FORMAT(239),_fn_,pInfoParmA->pi_pos);
		return ECL_SCRIPT_ERROR;
	}
	if (rc=cl_gx_rep_info_set(pInfoParmW,pInfoParmA,1)) return rc;
/*	if (!(pInfoParmW->pi_data=Memdup(pInfoParmA->pi_data,sizeof(tdtArrayIndex)))) return -1;	*/
	pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
	pIndex->uAttr[1] = D_ATR1_NO_MALLOC;
	index = pIndex->index;
#if 1	/* 2017.07.23 koba */
	n = index[1];
#else
	n = index[1]*index[2]*index[3];
#endif
/*
printf("cl_get_mapped_array: ix=%d n=%d index=%d %d %d %d %d %d\n",
ix,n,index[0],index[1],index[2],index[3],index[4],index[5]);
*/
#if 1	/* 2020.05.02 koba */
	i = ix;
#else
#if 1	/* 2017.07.23 koba */
	i = index[3] + ix;
#else
	i = index[0] + ix;
#endif
#endif
	if (i<=0 || i>n) {
		/* %s: map�ʒu(%d)���͈͊O�ł��B */
		ERROROUT2(FORMAT(240),_fn_,i);
		return ECL_SCRIPT_ERROR;
	}
#if 1	/* 2017.07.23 koba */
#if 1	/* 2020.05.02 koba */
	index[3] += i;
#else
	index[3] = i;
#endif
	nr = n - ix;
	index[0] = 1;
	index[1] = nr;
	index[2] -= ix;
	if (index[2] <0 ) index[2] = 0;
	index[4] = nr;
	index[5] = 0;
#else
	index[0] = i;
	nr = n - ix;
	index[3] = 1;
	index[2] = 1;
	index[1] = nr;
#endif
/*
printf("cl_get_mapped_array: ix=%d nr=%d index=%d %d %d %d %d %d\n",
ix,nr,index[0],index[1],index[2],index[3],index[4],index[5]);
*/
DEBUGOUT_InfoParm(170,"cl_get_mapped_array: ",pInfoParmW,0,0);

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_map(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int nparm;
tdtInfoParm *ppParm[];
{
	static char *_fn_="cl_array_map";
	tdtInfoParm *pInfoParmA;
	tdtArrayIndex *pIndex;
	char c,id1,id2;
	int rc,ix,*index,n,i,ind[MAX_ARRAY_DIM+1],f,iRANGE,iSTART,ndim,i1,i2,k;

	pInfoParmA = ppParm[0];
	if ((id1=pInfoParmA->pi_id)!='A' && id1!='R') {
		/* %s: ��P�������z��ł͂���܂���Bid=[%c] */
		ERROROUT2(FORMAT(246),_fn_,id1);
		return ECL_SCRIPT_ERROR;
	}
	pIndex = (tdtArrayIndex *)pInfoParmA->pi_data;
	if (pIndex->xhp) {
		/* %s: �A�z�z��(%s)�͎w��ł��܂���B */
		ERROROUT2(FORMAT(239),_fn_,pInfoParmA->pi_pos);
		return ECL_SCRIPT_ERROR;
	}
	if (rc=cl_func_index(&ix,nparm,ppParm)) return rc;
#if 1	/* 2017.07.23 koba */
	index = pIndex->index;
	ndim = index[0];
	nparm = X_MIN(nparm-1,ndim);
#else
	nparm = X_MIN(nparm-1,MAX_ARRAY_DIM);
#endif
	for (i=1;i<=nparm;i++) {
		if (rc=cl_get_parm_bin(ppParm[i],&ind[i],"index")) return rc;
/*
printf("cl_array_map: ind[%d]=%d\n",i,ind[i]);
*/
	}
	if (rc=cl_gx_rep_info_set(pInfoParmW,pInfoParmA,1)) return rc;
/*	if (!(pInfoParmW->pi_data=Memdup(pInfoParmA->pi_data,sizeof(tdtArrayIndex)))) return -1;	*/
	pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
	index = pIndex->index;
#if 1	/* 2017.07.23 koba */
	n = index[1];
#else
	n = index[1]*index[2]*index[3];
#endif
/*
printf("cl_array_map: index=");
for (i=0;i<ndim*2+4;i++) printf("%d ",index[i]);
printf("ix=%d\n",ix);
*/
#if 1	/* 2020.05.02 koba */
	i = ix;
#else
#if 1	/* 2017.07.23 koba */
	i = index[3] + ix;
#else
	i = index[0] + ix;
#endif
#endif
	if (i<=0 || i>n) {
		/* %s: map�ʒu(%d)���͈͊O�ł��B */
		ERROROUT2(FORMAT(240),_fn_,i);
		return ECL_SCRIPT_ERROR;
	}
#if 1	/* 2017.07.23 koba */
#if 1	/* 2020.05.02 koba */
	index[3] += i;
#else
	index[3] = i;
#endif
/*	f = 1;
	iRANGE = index[2];	*/
	if (pGlobTable->options[14] & 0x01) iSTART = 1;
	else iSTART = 0;
	i1 = 4;
	i2 = i1 + ndim;
	n = 1;
	for (i=1;i<=nparm;i++,i1++,i2++) {
	/*	if (iRANGE & f) {	*/
			index[i1] -= ind[i] - index[i2];
		/*	index[i2] = ind[i];	�����͂��̂܂� */
	/*	}
		else
			index[i1] -= ind[i] - iSTART;	*/
		if (index[i1] <= 0) {
			/* %s: map�ʒu(i=%d %d)���͈͊O�ł��B */
			ERROROUT3(FORMAT(247),_fn_,i,ind[i]);
			return ECL_SCRIPT_ERROR;
		}
		f <<= 1;
		n *= index[i1];
/*
printf("cl_array_map: index[%d]=%d n=%d\n",i1,index[i1],n);
*/
	}
	for (;i<=ndim;i++,i1++) {
		n *= index[i1];
/*
printf("              index[%d]=%d n=%d\n",i1,index[i1],n);
*/
	}
#if 1	/* 2020.05.02 koba */
	index[2] -= index[1] - n;
	if (index[2] < 0) index[2] = 0;
#endif
	index[1] = n;
#else
	index[0] = i;
	f = 1;
	iRANGE = index[4];
	if (pGlobTable->options[14] & 0x01) iSTART = 1;
	else iSTART = 0;

	for (i=1;i<=nparm;i++) {
		if (iRANGE & f)
			index[i] -= ind[i] - index[i+MAX_ARRAY_DIM+1];
		else
			index[i] -= ind[i] - iSTART;
		if (index[i] <= 0) {
			/* %s: map�ʒu(i=%d %d)���͈͊O�ł��B */
			ERROROUT3(FORMAT(247),_fn_,i,ind[i]);
			return ECL_SCRIPT_ERROR;
		}
		f <<= 1;
	}
#endif
/*
printf("cl_array_map: index=");
for (i=0;i<ndim*2+4;i++) printf("%d ",index[i]);
printf("\n");
*/
DEBUGOUT_InfoParm(170,"cl_get_mapped_array: ",pInfoParmW,0,0);

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _reflect_size_of_number_array(cn,iParmNo,xhp,pTBL)
char cn;
int  iParmNo;
XHASHB  *xhp;
tdtInfoParm ***pTBL;
{
	tdtInfoParm *pInfoParm;
	tdtArrayIndex *pIndex;
	int  i,m,ix,*index,rc;
	char c,*cpKey;
/*
printf("_reflect_size_of_number_array:Enter cn=[%c] iParmNo=%d\n",cn,iParmNo);
*/
	m = akxs_xhash2(xhp,'M',NULL,NULL);
	for (i=1;i<=m;i++) {
		xhp->xha_xhix = i;
		ix = akxs_xhash2(xhp,'P',&cpKey,NULL);
		if (ix > 0) {
/*
printf("_reflect_size_of_number_array: Key=[%s]\n",cpKey);
*/
			c = *cpKey;
			if (cn==c || (c!='%' && c!='#')) {
				pInfoParm = cl_get_var_ent_opt(pTBL,ix,'r');
				if (pInfoParm->pi_id == 'A') {
					rc = cl_get_array_index(pInfoParm,&pIndex);
					index = pIndex->index;
					iParmNo -= index[3] - 1;
					if (iParmNo > index[2]) {
printf("_reflect_size_of_number_array: name=[%s] iParmNo=%d index[2]=%d index[3]=%d\n",cpKey,iParmNo,index[2],index[3]);
						index[2] = iParmNo;
					}
				}
			}
		}
	}
	xhp->xha_xhix = 0;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_reflect_size_of_number_array(name,iParmNo)
char *name;
int  iParmNo;
{
	ScrPrCT	*pScCT;
	ProcCT  *proc;
	int  rc;
	char c;
/*
printf("cl_reflect_size_of_number_array:Enter name=[%s] iParmNo=%d\n",name,iParmNo);
*/
	if (!strcmp(name,"DOL")) c = '$';
/*	else if (!strcmp(name,"PAS")) c = '%';	*/
	else if (!strcmp(name,"IGE")) c = '#';
	else return 0;

	if (proc = cl_search_proc_ct()) {
		rc = _reflect_size_of_number_array(c,iParmNo,proc->pha_vnam,proc->pTBL_vnam);
	}
	if (pScCT = cl_search_src_ct()) {
		rc = _reflect_size_of_number_array(c,iParmNo,pScCT->Vary->pha_vnam,pScCT->Vary->pTBL_vnam);
	}
	rc = _reflect_size_of_number_array(c,iParmNo,pCLprocTable->pha_vnam,pCLprocTable->pTBL_vnam);

	rc = _reflect_size_of_number_array(c,iParmNo, pGLprocTable->pha_vnam,pGLprocTable->pTBL_vnam);

	return 0;
}
