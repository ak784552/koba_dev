static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int        cl_change_stcb               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         int   NestLevel              */
/*                  Leaf  leaf                   */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     CLNCB �̃l�X�g�|�C���^�̏��ւ����s���B    */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"

extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */

Leaf *AddressRoot;
/********************************************/
/*											*/
/********************************************/
int cl_change_stcb()
{
	switch( AddressRoot->cmd.type ) {
	case 1:
		CLSTCB.nestLev1 = AddressRoot;
		break;
	case 2:
		CLSTCB.nestLev2 = AddressRoot;
		break;
	default :
		return SysError;
	}
	return NormalEnd;
}
