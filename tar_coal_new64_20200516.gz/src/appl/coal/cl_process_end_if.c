static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �d�m�c�h�e�R�}���h���C��                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_end_if( pLeaf, pProc )                  *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                      (I)ProcCT        * pProc                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/

#include "colmn.h"

extern CLCOMMON  CLcommon;
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

int cl_process_end_if(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int irc,id;
	BlockCB *pIfCB;
	Leaf  *Dummy;

	if (!(pIfCB = pProc->pcrBlockCB)) return -1;
	id = pIfCB->cid;

DEBUGOUTL2(110,"cl_process_end_if: Enter cid=%08x %s",id,cl_gets_cmd_name(id));

	if (id==C_IF || id==C_SWITCH || id==C_TRY) ;
	else return -1;

	irc = 0;
	id = pLeaf->cmd.cid;
	if (id == C_ENDTRY) {
		pProc->ucExcept = 0;
		pGlobTable->try_level--;
		if (pIfCB->EndFlag) {	/* CATCH or FINALLY�̒��ŗ�O�����������Ƃ� */
			pGlobTable->exception = pIfCB->EndFlag;
			pIfCB->EndFlag = 0;
		}
		else if (pIfCB->TureFlag == L_OFF)	/* Catch����Ȃ������Ƃ� */
			pGlobTable->exception = pProc->exception;
		else {
			*pGlobTable->errmsg = '\0';
			pGlobTable->err_msg_len = 0;
		}
		pProc->exception = 0;
		/* �O��TRY��Ԃɖ߂� */
		pProc->pFlag = pIfCB->pFlag;
		pProc->ucExcept = pIfCB->ucExcept;
		/* break/continue���́A���̌�Apush���Ă���break/continue�����s����悤�ɂ��� */
		if (cmn_chk_stat(BRK_PR|RET_PR,&pProc->ptype)) pProc->Nextleaf = NULL;
	}
#if 1	/* 2017.03.18 */
	else if (id == C_ENDSW) {
		if (pIfCB->TureFlag != L_ON) {
			Dummy = pLeaf->preleaf;
			while(Dummy) {
				id = Dummy->cmd.cid;
				if (id == C_DEFAULT) {
					pIfCB->TureFlag = L_ON;
					pIfCB->iUsed = D_SWITCH_DEFAULT;	/* Add 2017.3.25 */
					pIfCB->Blockleaf = Dummy->rightleaf;	/* Add 2017.3.25 */

DEBUGOUTL2(110,"cl_process_end_if: found default pIfCB=%08x TureFlag=%08x",pIfCB,pIfCB->TureFlag);

					pProc->Nextleaf = Dummy->leftleaf;
					cl_ret_leaf_push(pProc,Dummy->rightleaf);
					return 0;
				}
				else if (id == C_SWITCH) break;
				Dummy = Dummy->preleaf;
			}
			if (!Dummy) return -1;
		}
	}
#endif
#if 1
	pIfCB->iUsed = 0;
	pProc->pcrBlockCB = pIfCB->preBlockCB;
#else
	cl_del_block_cb(pProc);
#endif

DEBUGOUTL1(110,"cl_process_end_if: Return pProc->pcrBlockCB=%08x",pProc->pcrBlockCB);

	return irc;
}
