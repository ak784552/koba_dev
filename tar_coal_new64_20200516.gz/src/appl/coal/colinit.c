static char sccsid[]="%Z% %M% %I% %E% %U%";
/**************************************************/
/*                                                */
/*                   col_mn_init                  */
/*------------------------------------------------*/
/*                                                */
/*                 CLPRTBL�̏�����                */
/*------------------------------------------------*/
/*                                                */
/**************************************************/
/*  */

#include "colmn.h"

extern tdtLruScrHead *tpLruScrHeadImp;
extern tdtLruScrHead *tpLruScrHead;

extern CLPRTBL GLprocTable,*pGLprocTable;
extern ScrPrCT GScript,*pGScript;
/* extern VarTBL  GVarTBL,*pGVarTbl;	*/

extern CLPRTBL CLprocTable,*pCLprocTable;
extern GlobalCt GlobTable,*pGlobTable;
extern CLCOMMON CLcommon;
extern condList CLcList;	/* ��񃊃X�g */
extern MCAT CLMcat[2];
extern int giOptions[];

int col_mn_init()
{
	int i,vlen,len,*pSize;
	tdtInfoParm ***pDummy;
	char *p;

	pGLprocTable = &GLprocTable;
	pGScript = &GScript;
/*	pGVarTbl = &GVarTBL;	*/
	memset(pGLprocTable,0,sizeof(CLPRTBL));
	memset(pGScript,0,sizeof(ScrPrCT));
/*	memset(pGVarTbl,0,sizeof(VarTBL));	*/
	GLprocTable.PrCTp = pGScript;
	GLprocTable.CurScr = GLprocTable.PrCTp;
	GScript.pId = "";
/*	GScript.Vary = pGVarTbl;	*/
#if 1
/*
	if (!(pGVarTbl->pha_vnam=akxs_xhash_new(0,MAX_VAR_IY,0))) return -1;

	pSize = (int *)Malloc(cl_var_size_len(0)*4);
	if (!pSize) goto Err;

	len = sizeof(tdtInfoParm **)*(MAX_VAR_IX+1);
	pDummy = (tdtInfoParm ***)Malloc(len);
	if (!pDummy) goto Err;
	memset(pDummy,0,len);
	pGVarTbl->pTBL_vnam = pDummy;
	pGVarTbl->pTBL_vnam[0] = (tdtInfoParm **)pSize;
	cl_var_set_size(pSize,MAX_VAR_IX,MAX_VAR_IY,"VNA");
*/
	if (!(pGLprocTable->pha_vnam=akxs_xhash_new(0,MAX_VAR_IY,0))) goto Err;
	len = sizeof(tdtInfoParm **)*(MAX_VAR_IX+1);
	if (!(pGLprocTable->pTBL_vnam=(tdtInfoParm ***)Malloc(len))) goto Err;
	memset(pGLprocTable->pTBL_vnam,0,len);
	if (!(pSize=(int *)Malloc(cl_var_size_len(0)))) goto Err;
	pGLprocTable->pTBL_vnam[0] = (tdtInfoParm **)pSize;
	cl_var_set_size(pSize,MAX_VAR_IX,MAX_VAR_IY,"GVN");
#endif

	pCLprocTable = &CLprocTable;
	pGlobTable   = &GlobTable;
	memset(pCLprocTable,0,sizeof(CLPRTBL));
	memset(pGlobTable,0,sizeof(GlobalCt));
	memset(&CLcommon,0,sizeof(CLCOMMON));
	memset(&CLcList,0,sizeof(condList));
	pCLprocTable->GlobCt = pGlobTable;
	if (!(CLcList.cmd.prmp=(parmList **)Malloc(sizeof(parmList *)*PM_MAX))) {
	 	ERROROUT("Malloc CLcList_prmp");
		goto Err;
	}
	CLcList.max_prmnum = PM_MAX;
	CLcList.mcat_obj = &CLMcat[0];
	CLcList.mcat_da  = &CLMcat[1];
	cl_im_init_expand(&CLMcat[0],"BJ",sizeof(int),MAX_CMD_OBJ,D_OPT_ALC_MALLOC);
	cl_im_init_expand(&CLMcat[1],"DA",sizeof(char *),MAX_CMD_DA,D_OPT_ALC_MALLOC);
	cl_im_expand(&CLMcat[0],0,NULL);
	cl_im_expand(&CLMcat[1],0,NULL);
#if 1
	cl_mod_option(1,1);
	cl_mod_option(9,1);
	cl_mod_option(3,1);
#else
	if (giOptions[8] & 0x04) {
		CLcommon.Quot[0] = M_QUOTE2;
		CLcommon.Quot[1] = M_QUOTE1;
	}
	else  {
		CLcommon.Quot[0] = M_QUOTE1;
		CLcommon.Quot[1] = M_QUOTE2;
	}
#endif
	return 0;
 Err:
 /*
 	if (p=(char *)pGVarTbl->pTBL_vnam[0]) Free(p);
	if (p=(char *)pGVarTbl->pTBL_vnam) Free(p);
	if (p=(char *)pGVarTbl->pha_vnam) akxs_xhash_free(p);
 */
	if (p=(char *)pGLprocTable->pTBL_vnam[0]) Free(p);
	if (p=(char *)pGLprocTable->pTBL_vnam) Free(p);
 	if (p=(char *)pGLprocTable->pha_vnam) akxs_xhash_free(p);
	return -1;
}
