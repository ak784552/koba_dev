static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int        cl_er_lk_proc_ct             */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/*                 -2   :�X�N���v�g�e�[�u����    */
/*                       �v���V�[�W�������݂�    */
/*                       �Ȃ�                    */
/* --------------------------------------------- */
/*  Function :                                   */
/*   �n���ꂽ�X�N���v�g�e�[�u���������P�[�W����  */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"

extern CLPRTBL *pCLprocTable;

int cl_er_lk_proc_ct()
{
	ScrPrCT  *Dummy;
	ProcCT   *Temp,*proc;
	char cFlag;
	int ret;

	Dummy = cl_search_src_ct();
	if (Dummy == NULL) return SysError;
#if 1	/* 2017.06.07 */
	if (!(proc = cl_search_proc_ct())) return SysError;

DEBUGOUTL3(102,"cl_er_lk_proc_ct: procct=%08x,name=[%s] pFlag=%02x",proc,proc->ProcNM,proc->pFlag);

	cFlag = proc->pFlag;
	if (!(Temp=proc->prePCT)) {
#if 0
		if (!(cFlag & D_PFLAG_NO_FREE)) {
			cl_prc_ct_clear(Dummy->ProCT);	/* add 2001.1.12 Koba */
			Free(Dummy->ProCT);
		}
#endif
		Dummy->ProCT = NULL;
		ret = -2;
	}
	else {
		Temp->nextPCT = NULL;
		pCLprocTable->CurProc = Temp;
		Dummy->CurProc = Temp;
		ret = 0;
	}

	if (!(cFlag & D_PFLAG_NO_FREE)) {
		akxs_xhasl(pCLprocTable->pha_gid,'D',proc->ProcGid,0);
		cl_prc_ct_clear(proc);	/* add 2001.1.12 Koba */
		Free(proc);
	}
/*	Free(proc);	*/

	return ret;
#else
	Temp = cl_search_proc_ct();
	if (Temp == NULL) return SysError;

DEBUGOUTL2(102,"cl_er_lk_proc_ct: procct=%08x,name=%s",Temp,Temp->ProcNM);

/*	if (!opt && !(Temp->pFlag & D_PFLAG_DEF_CLASS))	*/
	if (!(Temp->pFlag & D_PFLAG_DEF_CLASS))
		akxs_xhasl(pCLprocTable->pha_gid,'D',Temp->ProcGid,0);
/*
	if (Temp->ProcTop) cl_gx_clear_obj_addr(Temp->ProcTop->leftleaf,NULL,Temp->ProcTop->Obj);
	cl_tmp_const_ct_set(NULL);
*/
	cFlag = Temp->pFlag;
	if (Temp->prePCT == (ProcCT *)NULL) {
		if (!(cFlag & D_PFLAG_NO_FREE)) {
			cl_prc_ct_clear(Dummy->ProCT);	/* add 2001.1.12 Koba */
			Free(Dummy->ProCT);
		}
		Dummy->ProCT = (ProcCT *)NULL;
		return -2;
	}
	Temp = Temp->prePCT;
	if (!(cFlag & D_PFLAG_NO_FREE)) {
		cl_prc_ct_clear(Temp->nextPCT);	/* add 2001.1.12 Koba */
		Free(Temp->nextPCT);
	}
	Temp->nextPCT = (ProcCT *)NULL;
	pCLprocTable->CurProc = Temp;
	Dummy->CurProc = Temp;
/*
printf("cl_er_lk_proc_ct:procct=%08x,name=%s\n",Temp,Temp->ProcNM);
*/
	return NormalEnd;
#endif
}
