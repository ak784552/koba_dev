static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �_�����Z����                          �@�@�@           *
*                                                                             *
*      �֐����@    �F�@int cl_cmpt_logic(pAns,pOprtr,pInfoParm1,pInfoParm2)   *
*						(O)int		 *pAns									  *
*						(I)char		 *pOprtr								  *
*						(I)tdtInfoParm *pInfoParm1							  *
*						(I)tdtInfoParm *pInfoParm2 							  *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];

int cl_cmpt_logic( pAns , pOprtr , pInfoParm1 , pInfoParm2 )
	int			*pAns;
	char		*pOprtr;
	tdtInfoParm	*pInfoParm1;
	tdtInfoParm	*pInfoParm2;
{
	int rc=0, Result, atr[2], len[2], i, k;
	long Value[2];
	double dValue;
	char *dat[2];
	uchar *p;
	MPA *mpa;

	atr[0] = pInfoParm1->pi_attr;
	len[0] = pInfoParm1->pi_dlen;
	dat[0] = pInfoParm1->pi_data;
	atr[1] = pInfoParm2->pi_attr;
	len[1] = pInfoParm2->pi_dlen;
	dat[1] = pInfoParm2->pi_data;
	for (k=0;k<2;k++) {
		if (atr[k] == DEF_ZOK_BINA) {
			memcpy(&Value[k],dat[k],sizeof(long));
			if (Value[k]) Value[k] = 1;
		}
		else if (atr[k] == DEF_ZOK_FLOA) {
			memcpy(&dValue,dat[k],sizeof(double));
			if (dValue != 0.0) Value[k] = 1;
			else Value[k] = 1;
		}
		else if (atr[k] == DEF_ZOK_DECI) {
			mpa = (MPA *)dat[k];
			Value[k] = mpa->zero ? 0 : 1;
		}
		else {
			if (len[k]) Value[k] = 1;
			else Value[k] = 0;
		}
	}
/*
printf("cl_cmpt_logic: Value1=%d Value2=%d\n",Value[1],Value[1]);
*/
	sswitch( pOprtr )
		sicase( "AND" )
				Result = Value[0] & Value[1];
		sicase( "OR" )
				Result = Value[0] | Value[1];
		scase( "&&" )
				Result = Value[0] & Value[1];
		scase( "||" )
				Result = Value[0] | Value[1];
#if 1
		sicase( "NOT" )
				Result = ! Value[1];
		scase( "!" )
				Result = ! Value[1];
#endif
		sdefault
			/* cl_cmpt_logic: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_logic",pOprtr);
			Result = 0;
			rc = ECL_SCRIPT_ERROR;
	endssw;

	*pAns = Result;
	return rc;

}

/****************************************/
/*										*/
/****************************************/
int cl_cmpt_agg(pInfoParmW,pOprtr,pInfoParm1,pInfoParm2)
tdtInfoParm	*pInfoParmW;
char		*pOprtr;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
{
	int ret;
	char op,id1,id2;
	tdtRbCtl *pCt;

	op = *pOprtr;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;
	if (id1=='L' || id2=='L' || id1=='N' || id2=='N') {
		if (op=='+' || op=='|') {
			ret = cl_gx_list_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^') {
			ret = cl_gx_list_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
		if (ret>=0 && !(pGlobTable->options[4] & 0x01)) {
			if (pCt = (tdtRbCtl *)pInfoParmW->pi_data) {
				if (akxs_rb_used(pCt) <= 0) cl_null_data(pInfoParmW);
			}
		}
	}
	else {
		if (op=='+' || op=='|') {
			ret = cl_gx_array_add(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else if (op=='-' || op=='&' || op=='^') {
			ret = cl_gx_array_minus(pInfoParmW,op,pInfoParm1,pInfoParm2);
		}
		else {
			ERROROUT1(FORMAT(256),pOprtr);	/* cl_cmpt_agg: non suported operater(%s)!! */
			ret = -1;
		}
	}
	return ret;
}
