static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
 *                                                                          *
 *                                                                          *
 *                                                                          *
 ****************************************************************************/

#include	"colmn.h"

int giProgram[4]=
	{0	/* =0:coal, =1:ColMnMain */
	,0	/* iCmd */
	,0
	,0
	};

int giOptions[20]=
	{0	/*( 1)=0:NDEF, =1: null data */
	,0	/*( 2)*/
	,0	/*( 3)*/
	,0	/*( 4)*/
	,0	/*( 5)*/
	,0	/*( 6)*/
	,0	/*( 7)*/
	,0	/*( 8)=1: Search user func second */
	,0	/*( 9)*/
	,0	/*(10)*/
	,0	/*(11)=0x01: [0].1, 0x02: 1.[0] */
	,0	/*(12)*/
	,0	/*(13)*/
	,0	/*(14)=0:Japanese, =1:English, =2:Etc */
	,0	/*(15)*/
	,0	/*(16)*/
	,0	/*(17)=0:Decimal, =1:Double */
	,0	/*(18)*/
	,0	/*(19) DATE_FORMAT*/
	,0	/*(20) �P�O�i����(�Œ�)�����_�����w���\������ꍇ�̌��� */
	};

int		iGlSd = 0 ;
int		giHOST_ID_SIZE;

CLCOMMON	CLcommon;

condList	CLcList;		/* ��񃊃X�g */
tableRoot	CLtbl;			/* ��͂���^�O�y�ѕ������i�[�����̈�*/
CLNCB		CLSTCB;			/* �^�O�̍\����͂��s�����߂̗̈� */
CLPRTBL		CLprocTable;
CLPRTBL		*pCLprocTable=NULL;
GlobalCt	GlobTable;
GlobalCt	*pGlobTable=NULL;
ProcCT		*ProRoot;
ViewTBL		ViewTbl;
ItemTBL		ItemTbl;
ExtTBL		ExtTbl;
CatCondTBL	CatCondTbl;
char		*PwCnCB;
Leaf		*AddressRoot;	/* Add 01 20 */
XHASHB		*ProcIndex=NULL;
MCAT		CLMcat[2];
XHASHB		*xhp_main_def=NULL;
CLPRTBL		GLprocTable, *pGLprocTable;
ScrPrCT		GScript, *pGScript;
/* VarTBL		GVarTBL, *pGVarTbl;	*/
tdtLruScrHead *tpLruScrHeadImp=NULL;
tdtLruScrHead *tpLruScrHead=NULL;

/* Exter Val Name */
/*
typedef struct {
	char *name;
	short osize;
	short attr;
	int   id;
} tdtExtValName;
*/
tdtExtValName ExtValName[] =
	{"ERROR"	,0,DEF_ZOK_BINA,D_EXV_ERROR
	,"ERRMSG"	,0,DEF_ZOK_CHAR,D_EXV_ERRMSG
	,"ERRNO"	,0,DEF_ZOK_BINA,D_EXV_ERRNO
	,"STRERROR"	,0,DEF_ZOK_CHAR,D_EXV_STRERROR
	,"TUPLE"	,0,DEF_ZOK_BINA,D_EXV_TUPLE
	,"COLUMN"	,0,DEF_ZOK_BINA,D_EXV_COLUMN
	,"USERID"	,0,DEF_ZOK_CHAR,D_EXV_USERID
	,"DATE"		,0,DEF_ZOK_CHAR,D_EXV_DATE
	,"TIME"		,0,DEF_ZOK_CHAR,D_EXV_TIME
	,"DATETIME"	,0,DEF_ZOK_CHAR,D_EXV_DATETIME
	,"HID"		,0,DEF_ZOK_CHAR,D_EXV_HID
   ,"EXCEPTION"	,0,DEF_ZOK_BINA,D_EXV_EXCEPTION
	,"USERINF"	,0,DEF_ZOK_CHAR,D_EXV_USERINF
	,"VERSION"	,0,DEF_ZOK_CHAR,D_EXV_VERSION
	,"MAKEDATE"	,0,DEF_ZOK_CHAR,D_EXV_MAKEDATE
	,"STDIN"	,0,DEF_ZOK_BINA,D_EXV_STDIN
	,"STDOUT"	,0,DEF_ZOK_BINA,D_EXV_STDOUT
	,"STDERR"	,0,DEF_ZOK_BINA,D_EXV_STDERR
	,"SYSIN"	,0,DEF_ZOK_BINA,D_EXV_STDIN
	,"SYSOUT"	,0,DEF_ZOK_BINA,D_EXV_STDOUT
	,"SYSERR"	,0,DEF_ZOK_BINA,D_EXV_STDERR
   ,"SCRIPTNAME",0,DEF_ZOK_CHAR,D_EXV_SCRIPTNAME
	,"PROCNAME"	,0,DEF_ZOK_CHAR,D_EXV_PROCNAME
   ,"SCRIPTLINE",0,DEF_ZOK_BINA,D_EXV_SCRIPTLINE
	,"CLCHAR"	,5,DEF_ZOK_BINA,D_EXV_CHAR
	,"CLBINARY"	,5,DEF_ZOK_BINA,D_EXV_BINARY
	,"CLFLOAT"	,5,DEF_ZOK_BINA,D_EXV_FLOAT
	,"CLFLT"	,0,DEF_ZOK_BINA,D_EXV_FLOAT
	,"CLDECIMAL",5,DEF_ZOK_BINA,D_EXV_DECIMAL
	,"CLBULK"	,5,DEF_ZOK_BINA,D_EXV_BULK
	,"CLDATE"	,0,DEF_ZOK_BINA,D_EXV_DATETYPE
	,"CLVARIANT",6,DEF_ZOK_BINA,D_EXV_VARIANT
	,"CLSTRING"	,5,DEF_ZOK_BINA,D_EXV_CHAR
	,"CLINTEGER",5,DEF_ZOK_BINA,D_EXV_INTEGER
	,"CLDOUBLE"	,5,DEF_ZOK_BINA,D_EXV_DOUBLE
	,"CLDBL"	,0,DEF_ZOK_BINA,D_EXV_DOUBLE
	,"CLLONG"	,0,DEF_ZOK_BINA,D_EXV_LONG
	,"CLLNG"	,0,DEF_ZOK_BINA,D_EXV_LONG
   ,"CLSYSCODE"	,0,DEF_ZOK_BINA,D_EXV_SYSCODE
	,"CLEUC"	,0,DEF_ZOK_BINA,D_EXV_EUC
	,"CLSJIS"	,0,DEF_ZOK_BINA,D_EXV_SJIS
	,"CLJIS"	,0,DEF_ZOK_BINA,D_EXV_JIS
	,"CLEBCDIC"	,0,DEF_ZOK_BINA,D_EXV_EBCDIC
	,"CLUTF8"	,0,DEF_ZOK_BINA,D_EXV_UTF8
   ,"CLUNICODE"	,0,DEF_ZOK_BINA,D_EXV_UNICODE
	,"CLEBCDIK"	,0,DEF_ZOK_BINA,D_EXV_EBCDIK
	,"CLNARROW"	,0,DEF_ZOK_BINA,D_EXV_NARROW
	,"CLWIDE"	,0,DEF_ZOK_BINA,D_EXV_WIDE
	,"PI"		,0,DEF_ZOK_FLOA,D_EXV_PI
	,"M_E"		,0,DEF_ZOK_FLOA,D_EXV_M_E
	,"PI2"		,0,DEF_ZOK_DECI,D_EXV_PI2
	,"M_E2"		,0,DEF_ZOK_DECI,D_EXV_M_E2
	,"SYSDATE"	,0,DEF_ZOK_DATE,D_EXV_SYSDATE
	,"NULL"		,0,DEF_ZOK_CHAR,D_EXV_NULL
	,"CHAR_MIN"	,0,DEF_ZOK_BINA,D_EXV_CHAR_MIN
	,"CHAR_MAX"	,0,DEF_ZOK_BINA,D_EXV_CHAR_MAX
   ,"UCHAR_MAX"	,0,DEF_ZOK_BINA,D_EXV_UCHAR_MAX
   ,"SHORT_MIN"	,0,DEF_ZOK_BINA,D_EXV_SHORT_MIN
   ,"SHORT_MAX"	,0,DEF_ZOK_BINA,D_EXV_SHORT_MAX
  ,"USHORT_MAX"	,0,DEF_ZOK_BINA,D_EXV_USHORT_MAX
	,"INT_MIN"	,0,DEF_ZOK_BINA,D_EXV_INT_MIN
	,"INT_MAX"	,0,DEF_ZOK_BINA,D_EXV_INT_MAX
	,"UINT_MAX"	,0,DEF_ZOK_DECI,D_EXV_UINT_MAX
	,"LONG_MIN"	,0,DEF_ZOK_BINA,D_EXV_LONG_MIN
	,"LONG_MAX"	,0,DEF_ZOK_BINA,D_EXV_LONG_MAX
   ,"ULONG_MAX"	,0,DEF_ZOK_DECI,D_EXV_ULONG_MAX
	,NULL		,0,0,0
	};
/*
struct cl_inf_s {
	int time_out;
} Dm_Inf;
*/
/* �R�}���h���ŃT�[�`����Ƃ��́A�Ō�Ɉ�v�������̂��̗p���� */
/* �R�}���hid�ŃT�[�`����Ƃ��́A�ŏ��Ɉ�v�������̂��̗p���� */
cmdTable	CLcmdTable[]=	/* CLcmds ���������邽�߂̃e�[�u�� */
{
	 {C_PROC,		1,0,"PROC"		}
	,{C_ENDPROC,	0,0,"ENDPROC"	}
	,{C_FUNCTION,	1,0,"FUNCTION"	}
	,{C_FUNCTION,	1,0,"FUNC"		}
	,{C_ENDFUNC,	0,0,"ENDFUNC"	}
	,{C_ENDFUNC,	0,0,"ENDFUNCTION"}
	,{C_PROC,		1,0,"SUB"		}
	,{C_ENDPROC,	0,0,"ENDSUB"	}
	,{C_EXCEPTION,	1,0,"EXCEPTION"	}
	,{C_LABEL,		1,0,"LABEL"		}
	,{C_CLASS,		1,0,"CLASS"		}
	,{C_ENDCLASS,	0,0,"ENDCLASS"	}
	,{C_EXEC,		0,0,"EXEC"		}
	,{C_CALL,		0,0,"CALL"		}
	,{C_SQL,		0,0,"SQL"		}
	,{C_MSG,		0,0,"MESSAGE"	}
	,{C_LOOP,		2,0,"LOOP"		}
	,{C_BREAK,		0,0,"BREAK"		}
	,{C_CONTINUE,	0,0,"CONTINUE"	}
	,{C_ENDLOOP,	0,0,"ENDLOOP"	}
	,{C_DO,			2,0,"DO"		}
	,{C_ENDDO,		0,0,"ENDDO"		}
	,{C_READ,		0,0,"READ"		}
	,{C_OUTPUT,		0,0,"OUTPUT"	}
	,{C_IF,			2,0,"IF"		}
	,{C_ELSE,		2,0,"ELSE"		}
	,{C_ELSEL,		2,0,"ELSEL"		}
	,{C_ELSEIF,		2,0,"ELSEIF"	}
	,{C_ELSEIF,		2,0,"ELSIF"		}
/*	,{C_ELSELIF,	2,0,"ELSELIF"	}	*/
	,{C_ENDIF,		0,0,"ENDIF"		}
	,{C_SWITCH,		2,0,"SWITCH"	}
	,{C_SWITCH,		2,0,"SW"		}
	,{C_CASE,		2,0,"CASE"		}
	,{C_DEFAULT,	2,0,"DEFAULT"	}
	,{C_ENDSW,		0,0,"ENDSW"		}
	,{C_ENDSW,		0,0,"ENDSWITCH"	}
	,{C_BEXP,		0,0,"BEXP"		}
	,{C_LET,		0,0,"LET"		}
	,{C_LET,		0,0,"SET"		}
	,{C_RETURN,		0,0,"RETURN"	}
	,{C_ONN,		0,0,"ON"		}
	,{C_DEFINE,		0,0,"DEFINE"	}
	,{C_DEFINE,		0,0,"DEF"		}
	,{C_REDEFINE,	0,0,"REDEFINE"	}
	,{C_REDEFINE,	0,0,"REDEF"		}
	,{C_UNDEFINE,	0,0,"UNDEFINE"	}
	,{C_UNDEFINE,	0,0,"UNDEF"		}
	,{C_DIM,		0,0,"DIM"		}
	,{C_IMPORT,		0,0,"IMPORT"	}
	,{C_LEAVE,		0,0,"LEAVE"		}
	,{C_SLEEP,		0,0,"SLEEP"		}
	,{C_END,		0,0,"END"		}
	,{C_TRY,		2,0,"TRY"		}
	,{C_CATCH,		2,0,"CATCH"		}
	,{C_FINALLY,	2,0,"FINALLY" 	}
	,{C_ENDTRY,		0,0,"ENDTRY"	}
	,{C_THROW,		0,0,"THROW"		}
	,{C_THROW,		0,0,"RAISE"		}
	,{C_FOR,		2,0,"FOR"		}
	,{C_WHILE,		2,0,"WHILE"		}
	,{C_UNTIL,		2,0,"UNTIL"		}
	,{C_ENDFOR,		0,0,"ENDFOR"	}
	,{C_NEXT,		0,0,"NEXT"		}
	,{C_ENDWHILE,	0,0,"ENDWHILE"	}
	,{C_ENDUNTIL,	0,0,"ENDUNTIL"	}
	,{C_PRAGMA,		0,0,"PRAGMA"	}
/*
	,{C_INTERACTIVE,0,0,"INTER"		}
	,{C_INTERACTIVE,0,0,"INTERACTIVE"}
*/
	,{C_NODE_SCRIPT,0,0,"NODE_SCRIPT"}
	,{C_NODE_IMPORT,0,0,"NODE_IMPORT"}
	,{C_NODE_DEFINE,0,0,"NODE_DEFINE"}
	,{C_UNKNOWN,	0,0,"UNKNOWN"	}
	,{C_UNKNOWN,	0,0,"PRAGMA"	}
	,{0,0,0,NULL}	/* �R�}���h���ւ̃|�C���^��NULL���I�[ */
};
/*
GXObject bxobj[3]={{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};
*/

tdtException ExceptionName[] =
	{"ALL_EXCEPTION",					ALL_EXCEPTION
	,"IS_EXCEPTION",					IS_EXCEPTION
	,"TO_EXCEPTION",					TO_EXCEPTION
	,"CMPR_EXCEPTION",					CMPR_EXCEPTION
	,"MATH_EXCEPTION",					MATH_EXCEPTION
	,"MATH_COMP_EXCEPTION",				MATH_COMP_EXCEPTION
	,"MATH_COMP_ERROR_EXCEPTION",		MATH_COMP_ERROR_EXCEPTION
	,"MATH_COMP_DEVIDE_EXCEPTION",		MATH_COMP_DEVIDE_EXCEPTION
	,"MATH_ETC_EXCEPTION",				MATH_ETC_EXCEPTION
	,"MATH_ETC_ERROR_EXCEPTION",		MATH_ETC_ERROR_EXCEPTION
	,"STRING_EXCEPTION",				STRING_EXCEPTION
	,"FILE_EXCEPTION",					FILE_EXCEPTION
	,"FILE_OPEN_EXCEPTION",				FILE_OPEN_EXCEPTION
	,"FILE_OPEN_ERROR_EXCEPTION",		FILE_OPEN_ERROR_EXCEPTION
	,"FILE_OPEN_NOTFOUND_EXCEPTION",	FILE_OPEN_NOTFOUND_EXCEPTION
	,"FILE_CLOSE_EXCEPTION",			FILE_CLOSE_EXCEPTION
	,"FILE_CLOSE_ERROR_EXCEPTION",		FILE_CLOSE_ERROR_EXCEPTION
	,"FILE_READ_EXCEPTION",				FILE_READ_EXCEPTION
	,"FILE_READ_ERROR_EXCEPTION",		FILE_READ_ERROR_EXCEPTION
	,"FILE_READ_END_EXCEPTION",			FILE_READ_END_EXCEPTION
	,"FILE_WRITE_EXCEPTION",			FILE_WRITE_EXCEPTION
	,"FILE_WRITE_ERROR_EXCEPTION",		FILE_WRITE_ERROR_EXCEPTION
	,"FILE_ETC_EXCEPTION",				FILE_ETC_EXCEPTION
	,"FILE_ETC_ERROR_EXCEPTION",		FILE_ETC_ERROR_EXCEPTION
	,"LOG_EXCEPTION",					LOG_EXCEPTION
	,"SQL_EXCEPTION",					SQL_EXCEPTION
	,"COMM_EXCEPTION",					COMM_EXCEPTION
	,"USER_EXCEPTION",					USER_EXCEPTION
	,"SYSTEM_EXCEPTION",				SYSTEM_EXCEPTION
	,"ETC_EXCEPTION",					ETC_EXCEPTION
	,NULL,0
	};

char cmp_sep2[]={" \t'+-*/&|=^~!<>[](),.;?:{}"};
char cmp_sep3[]={" \t'+*/&|=^~!<>[](),.;?:{}"};

