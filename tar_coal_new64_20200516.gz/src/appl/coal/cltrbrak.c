static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_break               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/
/* */

#include "colmn.h"          /* �\���̒�` */

extern condList  CLcList;  /* ��񃊃X�g */

/*********************************************/
/*                                           */
/*********************************************/
static int _col_mn_tr(name,msg,errc)
char *name,*msg;
int  errc;
{
	int rc;
/*
	if ( CLcList.cmd.prmnum > 0 ) {
		ERROROUT1(FORMAT(41),name);
		return errc;
	}
*/
	if (cl_search_loop(0)) {
		/* %s: �k�n�n�o���Ȃ��̂�%s���ݒ肳��܂����B */
		ERROROUT2(FORMAT(56),name,msg);
		return errc;
	}

	if (!(rc = cl_make_leaf())) rc = cl_push();

	return rc;
}
/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_break()
{
	return _col_mn_tr("col_mn_tr_break",FORMAT(57),ECL_TR_BREAK);	/* �a�q�d�`�j */
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_continue()
{
	return _col_mn_tr("col_mn_tr_continue",FORMAT(58),ECL_TR_CONTINUE);	/* �b�n�m�s�h�m�t�d */
}
