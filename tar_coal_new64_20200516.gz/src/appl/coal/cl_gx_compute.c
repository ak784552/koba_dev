static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ���Z����                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_compute( pLeaf )                             *
*                      (I)Leaf     *pLeaf                                     *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
static int _gx_ppmm_val(atr,pInfoParm)
int atr;
tdtInfoParm *pInfoParm;
{
	static char *name="_gx_ppmm_val";
	char *p;
	int  *pi,rc,iValue;
	double *pd,dValue;
	int  attr,iAttr[3],Val[2];
	MPA *mpa;
	char work[64];

	p = pInfoParm->pi_paux;
/*
printf("_gx_ppmm_val: atr=%d p=%08x\n",atr,p);
*/
	if ((attr=(int)pInfoParm->pi_aux[0]) == DEF_ZOK_BINA) {
		pi = (int *)p;
		if (atr == 14) (*pi)++;
		else if (atr == 15) (*pi)--;
		else if (atr == 16) *pi = !(*pi);
		else *pi = ~(*pi);
		cl_set_parm_bin(pInfoParm,*pi);
	}
	else if (attr == DEF_ZOK_FLOA) {
		pd = (double *)p;
		if (atr == 14) (*pd)++;
		else if (atr == 15) (*pd)--;
		else {
			/* %s: ���������_�f�[�^(%e)�́A�r�b�g���Z�ł��܂���B */
			ERROROUT2(FORMAT(141),name,*pd);
			return ECL_SCRIPT_ERROR;
		}
		cl_set_parm_double(pInfoParm,*pd);
	}
	else if (attr == DEF_ZOK_DECI) {
		mpa = (MPA *)p;
		if (atr == 14) m_add1(mpa,m_get_i(1));
		else if (atr == 15) m_sub1(mpa,m_get_i(1));
		else {
			m_mpa2an(mpa,work,sizeof(work),pGlobTable->options[10]);
			/* %s: �P�O�i���������_�f�[�^(%s)�́A�r�b�g���Z�ł��܂���B */
			ERROROUT2(FORMAT(142),name,work);
			return ECL_SCRIPT_ERROR;
		}
		if (pInfoParm->pi_hlen) {
			if ((rc=cl_mpa_scale(p,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
		}
		memcpy(pInfoParm->pi_data,mpa,sizeof(MPA));
	}
	else if (attr == DEF_ZOK_CHAR) {
		/* %s: �����f�[�^(%s)�́A���Z�ł��܂���B */
		ERROROUT2(FORMAT(143),name,p);
		return ECL_SCRIPT_ERROR;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _gx_ppmm(atr,pInfoParm)
int atr;
tdtInfoParm *pInfoParm;
{
	static char *name="_gx_ppmm";
	long   lValue;
	int  rc,iValue,mc,lenW,len,alen;
	int  attr0,attr,iAttr[3],Val[NMPA_INT];
	double dValue;
	MPA *mpa;
	char work[64],*p;
	tdtInfoParm tInfoParmW,tInfoParm;

	if (!pInfoParm) return -1;
#if 1	/* 2017.8.19 koba */
	if ((pGlobTable->options[1] & 0x02) &&
	     pInfoParm->pi_attr==DEF_ZOK_CHAR && !cl_is_none_parm(pInfoParm)) {
		 if (atr==14 || atr==15) {
		 	mc = atr + 10;
			cl_set_parm_long(&tInfoParm,1);
			rc = cl_str_add(&tInfoParmW,mc,pInfoParm,&tInfoParm);
			if (!rc) {
				lenW = tInfoParmW.pi_dlen;
				len = pInfoParm->pi_dlen;
				alen = X_MAX(lenW,len);
				if (!(p=Strndup(tInfoParmW.pi_data,alen))) return ECL_MALLOC_ERROR;
				if (pInfoParm->pi_aux[0]) {
					if (len > lenW) memset(p+lenW,len-lenW,' ');
					memzcpy(pInfoParm->pi_paux,p,len);
					lenW = len;
				}
				cl_set_parm_char(pInfoParm,p,lenW);
		 	}
		 }
		 else {
			ERROROUT2(FORMAT(143),name,pInfoParm->pi_data);
			rc = ECL_SCRIPT_ERROR;
		 }
		 return rc;
	}
#endif
	if (rc=cl_check_data_id(pInfoParm,0)) return rc+ECL_CHK_VAR_ERROR;

	if (pInfoParm->pi_aux[0]) return _gx_ppmm_val(atr,pInfoParm);

	if ((attr0=pInfoParm->pi_attr)==DEF_ZOK_BINA && pInfoParm->pi_scale==0x40) {
		if (atr == 14) (pInfoParm->pi_pos)++;
		else if (atr == 15) (pInfoParm->pi_pos)--;
		else if (atr == 16) pInfoParm->pi_pos = !(pInfoParm->pi_pos);
		else pInfoParm->pi_pos = ~(pInfoParm->pi_pos);
/*
printf("_gx_ppmm: pInfoParm->pi_pos=%d\n",pInfoParm->pi_pos);
*/
	}
	else if (attr0 == DEF_ZOK_DECI) {
		mpa = (MPA *)pInfoParm->pi_data;
		if (atr == 14) m_add1(mpa,m_get_i(1));
		else if (atr == 15) m_sub1(mpa,m_get_i(1));
		else {
			m_mpa2an(mpa,work,sizeof(work),pGlobTable->options[10]);
			/* %s: �P�O�i���������_�f�[�^(%s)�́A�r�b�g���Z�ł��܂���B */
			ERROROUT2(FORMAT(142),name,work);
			return ECL_SCRIPT_ERROR;
		}
		if (pInfoParm->pi_hlen) {
			if ((rc=cl_mpa_scale(mpa,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
		}
	}
	else {
		if ((rc=cl_get_parm_mpa(pInfoParm,Val,"_gx_ppmm:",iAttr)) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParm->pi_scale & 0x80) Free(pInfoParm->pi_data);
		if ((attr=iAttr[0]) == DEF_ZOK_BINA) {
			lValue = CL_GET_VAL_BIN(Val);
			if (atr == 14) lValue++;
			else if (atr == 15) lValue--;
			else if (atr == 16) lValue = !lValue;
			else lValue = ~lValue;
/*
printf("_gx_ppmm: iValue=%d\n",lValue);
*/
			cl_set_parm_long(pInfoParm,lValue);
		}
		else if (attr == DEF_ZOK_FLOA) {
			memcpy(&dValue,Val,sizeof(double));
			if (atr == 14) dValue++;
			else if (atr == 15) dValue--;
			else {
				/* %s: ���������_�f�[�^(%e)�́A�r�b�g���Z�ł��܂���B */
				ERROROUT2(FORMAT(141),name,dValue);
				return ECL_SCRIPT_ERROR;
			}
/*
printf("_gx_ppmm: dValue=%f\n",dValue);
*/
			cl_set_parm_double(pInfoParm,dValue);
		}
		else if (attr == DEF_ZOK_DECI) {
			if (atr == 14) m_add1((MPA *)Val,m_get_i(1));
			else if (atr == 15) m_sub1((MPA *)Val,m_get_i(1));
			else {
				m_mpa2an((MPA *)Val,work,sizeof(work),pGlobTable->options[10]);
				/* %s: �P�O�i���������_�f�[�^(%s)�́A�r�b�g���Z�ł��܂���B */
				ERROROUT2(FORMAT(142),name,work);
				return ECL_SCRIPT_ERROR;
			}
/*
printf("_gx_ppmm: dValue=%f\n",dValue);
*/
			cl_set_parm_mpa(pInfoParm,Val);
		}
		else {
			/* %s: ���l�ȊO�́A���Z�ł��܂���B */
			ERROROUT1(FORMAT(144),name);
			return ECL_SCRIPT_ERROR;
		}
	}

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_compute(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
{
	static  char *fname="cl_gx_compute";
	int		rc, scale,len;
	char	*pOperator, *pWork, wk[33],c,*name,cPM;
	parmList  *pparmList1;
	parmList  *pparmList2;
	parmList  *pparmList3;
	tdtInfoParm InfoParm1,*pInfoParm1;
	tdtInfoParm InfoParm2,*pInfoParm2;
	tdtInfoParm InfoParm0,*pInfoParm0;
	tdtInfoParm InfoParmW,*pInfoParmW;
	tdtInfoParm *pInfoParm;
	ScrPrCT	  *pScCT;
	parmList  **parmp;
	char cM_QUOTE1 = pGlobTable->Quot[0];

	parmp = pLeaf->cmd.prmp;
	pInfoParm = NULL;
	pInfoParm0 = &InfoParm0;
	cPM = '\0';
#if 1
	name = parmp[0]->prp;
	if ((len=parmp[0]->prmlen) > 2) {
		if (akxnrskipin(name,len,"+-") == (len-2)) {
			cPM = name[len-2];
			len -=2;
		}
	}
	if (rc=cl_gx_expsn_obj_opt(name,len,parmp[0]->bxobj,proc->Obj,pInfoParm0,
#else
	if (rc=cl_gx_exp_obj_opt(1,&parmp[0],proc->Obj,pInfoParm0,
#endif
	                   D_GX_OPT_STORE|D_GX_OPT_GET_ADDR|D_GX_OPT_NOEROUT_NDEF)) return rc;
	if (pInfoParm0->pi_id == D_DATA_ID_STOREVAR) {
		if (pInfoParm = (tdtInfoParm *)pInfoParm0->pi_pos) {
			if (pInfoParm->pi_aux[1] & D_AUX1_PROTECTED) rc = ECL_CAN_NOT_STORE;
			else if (((c=pInfoParm->pi_id)=='A' || c=='R') &&
			    (pInfoParm->pi_scale & D_DATA_INDEX_FREE)) {
				rc = ECL_CAN_NOT_STORE;
			}
		}
		else rc = ECL_CAN_NOT_STORE;
	}
	else rc = ECL_CAN_NOT_STORE;
	if (rc == ECL_CAN_NOT_STORE) {
		/* %s: %s�ւ͑���͂ł��܂���B */
		ERROROUT2(FORMAT(126),fname,parmp[0]->prp);
		return rc;
	}
	pparmList2 = parmp[2]; 	/* �E�ӂP	*/
	if (pparmList2->prp[0] == cM_QUOTE1) {
		if (rc=cl_conv_const_c(pparmList2,&InfoParm1)) return rc;
	}
	else {
		if (rc=cl_gx_exp_obj_opt(1,&parmp[2],proc->Obj,&InfoParm1,0)) return rc;
	}
	if (pLeaf->cmd.prmnum >= 5)	{	/* �񍀉��Z�q����̏ꍇ		*/
		pparmList3 = parmp[4]; 	/* �E�ӂQ	*/
		if (pparmList3->prp[0] == cM_QUOTE1) {
			if (rc=cl_conv_const_c(pparmList3,&InfoParm2)) return rc;
		}
		else {
			if (rc=cl_gx_exp_obj_opt(1,&parmp[4],proc->Obj,&InfoParm2,0)) return rc;
		}
	}
	pInfoParmW = &InfoParmW;
	if (pLeaf->cmd.prmnum >= 5)	{	/* �񍀉��Z�q����̏ꍇ		*/
		pOperator = parmp[3]->prp;
		rc = cl_gx_bexp(pInfoParmW,&InfoParm1,pOperator,&InfoParm2,
		            pLeaf->cmd.prmnum-5, &parmp[5]);
		if (rc) {
			/* %s: �񍀉��Z���Ɍ�肪����܂��B */
			ERROROUT1(FORMAT(145),fname);
			return rc;
		}
	}
	else {
		cl_gx_copy_info(pInfoParmW,&InfoParm1);
	}
	len = parmp[1]->prmlen;
	if (len > 1) {
		if (pInfoParm0->pi_id=='\0') {
			/* %s: %s�̃f�[�^�����ݒ�ł��B */
			ERROROUT2(FORMAT(127),fname,parmp[0]->prp);
			return ECL_NDEFVAR_ERROR;
		}
		if (len > sizeof(wk)-1) {
			/* %s: ������Z�q(%)���������܂��B */
			ERROROUT2(FORMAT(146),fname,parmp[1]->prp);
			return ECL_SCRIPT_ERROR;
		}
		memzcpy(wk,parmp[1]->prp,len-1);
		if (!(pInfoParm1 = pInfoParm)) pInfoParm1 = pInfoParm0;
		pInfoParm2 = pInfoParmW;
		pInfoParmW = &InfoParm1;
		if (rc=cl_gx_bexp(pInfoParmW,pInfoParm1,wk,pInfoParm2,0,NULL))
			return rc;
	}

#if 1
	if (rc=cl_gx_rep_info_set(pInfoParm,pInfoParmW,1)) return rc;
	if (cPM) rc = _gx_ppmm(cPM=='+'?14:15,pInfoParm);
	return rc;
#else
	return cl_gx_rep_info_set(pInfoParm,pInfoParmW,1);
#endif
}

/****************************************/
/*										*/
/****************************************/
int let_compute_sub_opt(nparm,prmp,Obj,opt,ppInfoParm)
int nparm;
parmList *prmp[];
tdtInfoParm **Obj;
int opt;
tdtInfoParm **ppInfoParm;
{
	int rc;
	tdtInfoParm tInfoParm;

	if (ppInfoParm) opt |= D_GX_OPT_GET_ADDR;
	if ((rc=cl_gx_exp_obj_opt(nparm,prmp,Obj,&tInfoParm,opt)) < 0)	{
		/* %s: ��������Ă��܂�(rc=%d)�B */
		ERROROUT2(FORMAT(48),"let_compute",rc);
		rc = ECL_EX_LET;
	}
	else {
		rc = 0;
		if (ppInfoParm) {
			if (tInfoParm.pi_id == D_DATA_ID_STOREVAR)
				*ppInfoParm = (tdtInfoParm *)tInfoParm.pi_pos;
			else rc = ECL_CAN_NOT_STORE;
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int let_compute_sub(nparm,prmp,Obj)
int nparm;
parmList *prmp[];
tdtInfoParm **Obj;
{
	return let_compute_sub_opt(nparm,prmp,Obj,0,NULL);
}

/****************************************/
/*										*/
/****************************************/
int let_compute_info(pLeaf, proc, opt, ppInfoParm)
Leaf *pLeaf;
ProcCT  *proc;
int opt;
tdtInfoParm **ppInfoParm;
{
	tdtObjHead *pObj;

	if (proc) pObj = proc->Obj;
	else pObj = cl_gx_get_scr_obj();
	return let_compute_sub_opt(pLeaf->cmd.prmnum,pLeaf->cmd.prmp,pObj,opt,ppInfoParm);
}

/****************************************/
/*										*/
/****************************************/
int let_compute_opt(pLeaf, proc, opt)
Leaf *pLeaf;
ProcCT  *proc;
int opt;
{
	return let_compute_info(pLeaf, proc, opt, NULL);
}

/****************************************/
/*										*/
/****************************************/
int let_compute(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
{
	return let_compute_info(pLeaf, proc, 0, NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_bexp(pInfoParmW,pInfoParm1,pOperator,pInfoParm2,nparm,prmp)
char *pOperator;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParmW;
int nparm;
parmList  *prmp[];
{
	static char *name="cl_gx_bexp";
	static char J[5][5]={0,0,0,0,0, 0,1,1,1,0, 0,1,1,1,0, 0,1,1,0,2, 0,0,0,2,0};
	int rc,rc2,ope;
	int dtlen,dtatr,scale,iVal,iMPA[NMPA_INT*2+1],i1,i2,iParm[5];
	char *pWork,msg[7],id1,id2,c;
	uchar pi_aux1,pi_aux2;
	tdtInfoParm *ppParm[2],pParm[2];

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_bexp: pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_bexp: pOperator=[%s] pInfoParm2=",pInfoParm2,pOperator,0);

	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	mem_set_int(iParm,0,5);

/*	pWork = (char *)&(pInfoParmW->pi_pos);	*/
	pWork = (char *)iMPA;
	dtatr = DEF_ZOK_BINA;
	dtlen = 0;
	scale = 0x40;
	ope = cl_gx_chk_opt(pOperator,0);			/*���Z�q�`�F�b�N			*/
	if (ope == MATH) {
		if (pInfoParm1->pi_attr==DEF_ZOK_DATE || pInfoParm2->pi_attr==DEF_ZOK_DATE) {
			return cl_cmpt_date(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
		}
		else if (((c=*pOperator)=='&' || c=='|') &&
		    (pInfoParm1->pi_attr==DEF_ZOK_CHAR && pInfoParm2->pi_attr==DEF_ZOK_CHAR)) {
			if (rc=concat(&pWork,pInfoParm1,pInfoParm2,nparm,prmp,NULL)) return rc;
			cl_set_parm_char(pInfoParmW,pWork,strlen(pWork));
			return 0;
		}
#if 1	/* 2017.06.26 koba */
		else if ((pGlobTable->options[1] & 0x02) && ((c=*pOperator)=='*' || c=='+' || c=='-') &&
			     ((pInfoParm1->pi_attr==DEF_ZOK_CHAR && !cl_is_none_parm(pInfoParm1)) ||
				  (pInfoParm2->pi_attr==DEF_ZOK_CHAR && !cl_is_none_parm(pInfoParm2)))) {
			return cl_str_exp(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
		}
#endif
		id1 = pInfoParm1->pi_id;
		id2 = pInfoParm2->pi_id;
		pi_aux1 = (id1=='A'||id1=='R')&&(pInfoParm1->pi_aux[0] & DEF_ZOK_DATA);
		pi_aux2 = (id2=='A'||id2=='R')&&(pInfoParm2->pi_aux[0] & DEF_ZOK_DATA);
		i1 = i2 = 0;
		if (pi_aux1) i1 = 1;
		else if (id1=='L' || id1=='N') i1 = 2;
		else if (id1 == ' ') i1 = 3;
		else if (id1=='A'||id1=='R') i1 = 4;
		if (pi_aux2) i2 = 1;
		else if (id2=='L' || id2=='N') i2 = 2;
		else if (id2 == ' ') i2 = 3;
		else if (id2=='A'||id2=='R') i2 = 4;
/*
printf("cl_gx_bexp: pi_aux1=%02x pi_aux2=%02x id1=%c id2=%c i1=%d i2=%d j=%d\n",pi_aux1,pi_aux2,id1,id2,i1,i2,J[i1][i2]);
*/
		if ((c=J[i1][i2]) == 1) {
			ope = AGGREGATE;
			if (cl_is_undef_parm(pInfoParm1) || cl_is_none_parm(pInfoParm1)) {
					/* %s: ���Z�q=%s�A���̏W�����Z�͂ł��܂���B */
				ERROROUT2(FORMAT(165),name,pOperator);
				return ECL_SCRIPT_ERROR;
			}
		}
		else if (c == 2) {	/* �z��̐擪�ʒu�ړ� */
			return cl_get_mapped_array(pInfoParmW,pInfoParm1,pOperator,pInfoParm2);
		}
		else {
			*msg = '\0';
			if (rc=cl_check_data_id(pInfoParm1,0)) {
				strcpy(msg,"1");
			}
			if (rc2=cl_check_data_id(pInfoParm2,0)) {
				rc = rc2;
				if (*msg) strcat(msg,",");
				strcat(msg,"2");
			}
			if (rc) {
				/* %s: �Z�p���Z�̑�%s���Ɍ�肪����܂��B */
				ERROROUT2(FORMAT(147),name,msg);
				return rc+ECL_CHK_VAR_ERROR;
			}
		}
	}
	switch (ope) {
		case MATH:							/* �Z�p���Z					*/
			if ((dtatr=cl_cmpt_math(pWork,pOperator,pInfoParm1,pInfoParm2,iParm)) < 0)
				return ERROR;
			break;
		case COMP:							/* ��r���Z					*/
			if ((dtatr=cl_cmpt_comp(pWork,pOperator,
			            pInfoParm1,pInfoParm2,nparm,prmp)) < 0)
				return ERROR;
			break;
		case LOGICAL:						/* �_�����Z					*/
			if ( ( rc = cl_cmpt_logic( pWork , pOperator ,
			pInfoParm1 , pInfoParm2 ) ) != NORMAL )
				return( ERROR );
			break;
		case IS:							/* is  ���Z					*/
			ppParm[0] = pInfoParm1;
			ppParm[1] = pInfoParm2;
			if (rc=cl_cmpt_is(pWork,pOperator,2,ppParm,0,0)) return ERROR;
			break;
		case STRING:						/* moji���Z					*/
			if ((rc=cl_cmpt_string(&pWork,pOperator,
			            pInfoParm1,pInfoParm2,nparm,prmp)) != NORMAL )
				return( ERROR );
			dtatr = DEF_ZOK_CHAR;
			break;
		case TO:						/* to ���Z					*/
			ppParm[0] = pInfoParm1;
			ppParm[1] = pInfoParm2;
			if ((dtatr=cl_cmpt_to(&pWork,pOperator,2,ppParm,0,0)) < 0)
				return dtatr;
			if (!dtatr) dtatr = DEF_ZOK_CHAR;
			break;
		case AGGREGATE:						/* �W�����Z					*/
			if ((rc=cl_cmpt_agg(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)) < 0)
				return rc;
			return 0;
		case FUNCTION:						/* �֐�					*/
		case FUNCFILE:						/* �t�@�C���֐�			*/
		case FUNCMATH:						/* ���l���Z�֐�			*/
		case FUNCLOG:						/* ���O�֐�			*/
			if (nparm && nparm!=2) {
				/* %s: ���̐�(%d)���Q�ȊO�ł��B���Z�q=%s ope=%d */
				ERROROUT4(FORMAT(157),name,nparm,pOperator,ope);
				return ECL_SCRIPT_ERROR;
			}
			pParm[0] = *pInfoParm1;
			pParm[1] = *pInfoParm2;
			ppParm[0] =	&pParm[0];
			ppParm[1] =	&pParm[1];
			if ((rc=cl_gx_func_bexp(pInfoParmW,pOperator,2,ppParm,0,pParm)) < 0)
				return rc;
			return 0;
		default:
			/* %s: ���Z�q(%s)�Ɍ�肪����܂��Bope=%d */
			ERROROUT3(FORMAT(148),name,pOperator,ope);
			return ECL_SCRIPT_ERROR;
	}

	if (dtatr == DEF_ZOK_CHAR) {
		if (pWork) {
			dtlen = strlen(pWork);
			scale = 0;
		}
	}
	else if (dtatr == DEF_ZOK_BINA) {
		memcpy(&iVal,pWork,sizeof(int));
		dtlen = sizeof(long);
		pInfoParmW->pi_pos  = iVal;
		pWork = (char *)&(pInfoParmW->pi_pos);
	}
	else if (dtatr == DEF_ZOK_FLOA) {
		dtlen = sizeof(double);
		memcpy(&pInfoParmW->pi_pos,pWork,dtlen);
		pWork = (char *)&(pInfoParmW->pi_pos);
	}
	else if (dtatr == DEF_ZOK_DECI) {
		return cl_set_parm_mpa(pInfoParmW,pWork);
	}
	else if (dtatr == DEF_ZOK_DATE) {
		return cl_set_parm_date(pInfoParmW,pWork);
	}

	pInfoParmW->pi_id    = ' ';
	pInfoParmW->pi_attr  = dtatr;
	pInfoParmW->pi_scale = scale;
	pInfoParmW->pi_code  = CLcommon.cDataCode;
	pInfoParmW->pi_dlen  = dtlen;
	pInfoParmW->pi_data  = pWork;
#if 1	/* 2019.8.31 */
/*
printf("cl_gx_bexp: iParm=%d %d %d %d %d\n",iParm[0],iParm[1],iParm[2],iParm[3],iParm[4]);
*/
	pInfoParmW->pi_alen  = iParm[D_IPARM_OVER];
#endif

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int let_compute_return(leaf,proc)
Leaf *leaf;
ProcCT  *proc;
{
	return -1;
}

/****************************************/
/*										*/
/****************************************/
static struct {
	short ckid_opt;
	short ckid_no;
	short ckid_rc;
	char  ckid_id;
	char  ckid_np;
} *p,_chk_id[] = {
	 {0x01,115,-1,'F',0x01}
	,{0x02,149,-2,'A',0x02}
	,{0x02,150,-2,'R',0x02}
	,{0x04,151,-3,'U',0x11}
	,{0x04,152,-3,'\0',0x10}
	,{0x08,153,-4,D_DATA_ID_LIST,0}
	,{0x10,154,-5,'T',0}
	,{0x20,466,-6,'P',0x23}
	,{0x40,134,-7,'X',0}
	,{0x80,120,-8,'C',0x01}
	,{0x100,159,-9,'I',0x01}
	,{0x200,162,-10,'M',0x01}
	,{0x400,114,-11,'O',0x01}
	,{0x800,169,-12,D_DATA_ID_PNAME,0}
	,{0x1000,170,-13,D_DATA_ID_NARABI,0}
	,{0xa000,597,-14,' ',0}
	,{0,0,0,0,0}
};

int cl_check_data_id(pInfoParm,opt)
tdtInfoParm *pInfoParm;
int opt;
{
	return cl_check_data_id2(pInfoParm,opt,0);
}

int cl_check_data_id2(pInfoParm,opt,opt2)
tdtInfoParm *pInfoParm;
int opt,opt2;
{
	char c,*pn,*type,*fmt;
	int ch_opt,i,j,iCKECK_NORMAL;

	if (!pInfoParm) return 0;
	iCKECK_NORMAL = opt2 & 0x01;	/* OFF : 0x8000 ��������̂̓`�F�b�N���Ȃ� */
	if (!opt) opt = -1;
	c = pInfoParm->pi_id;
	p = &_chk_id[0];
	while (ch_opt=p->ckid_opt) {
		if (!iCKECK_NORMAL && (p->ckid_opt & 0x8000)) ;
		else if ((opt & p->ckid_opt) && c==p->ckid_id) {
			type = FORMAT(p->ckid_no);
			i = p->ckid_np;
			j = i & 0xf0;
			i &= 0x0f;
			if (i == 1) pn = pInfoParm->pi_data;
			else if (i == 2) pn = (char *)pInfoParm->pi_pos;
			else if (i == 3) {
				pn = (char *)pInfoParm->pi_pos;
				if (pInfoParm->pi_aux[0] == D_AUX0_TYPE_STRUCT) type = FORMAT(154);
				else if (pInfoParm->pi_aux[0] == D_AUX0_TYPE_ARRAY) type = FORMAT(150);
				else if (pInfoParm->pi_aux[0] == D_AUX0_TYPE_MAPPED) type = FORMAT(149);
			}
			if (!j) {
				if (i) ERROROUT2(FORMAT(155),type,pn);
				else ERROROUT1(FORMAT(158),type);
			}
			else if (j == 0x10) {
				fmt = FORMAT(p->ckid_no);
				if (i) ERROROUT1(fmt,pn);
				else ERROROUT(fmt);
			}
			else if (j == 0x20) {
				ERROROUT2(FORMAT(p->ckid_no),type,pn);
			}
			return p->ckid_rc;
		}
		p++;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_let_ppmm(atr,pInfoParm)
int atr;
tdtInfoParm *pInfoParm;
{
	if (atr < 0) atr = -atr;
	return _gx_ppmm(atr,pInfoParm);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_cast(pInfoParmW,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	int rc,iParm[5],len,attr;
	char *p,c;

	rc = 0;
	p = pInfoParm1->pi_data;
#if 1
	if (!stricmp(p,"FUNC")) {
		rc = cl_func_f(pInfoParmW,1,&pInfoParm2);
	}
	else {
		if ((attr=pInfoParm1->pi_aux[0]) == FUNCCAST) {
			len = pInfoParm1->pi_dlen;
			if ((c=*p)=='C' || c=='c') {
				if ((c=*(p+1))!='H' && c!='h') {
					p++;
					len--;
				}
			}
#else
	if ((c=*p)=='C' || c=='c') {
		p++;
		if ((attr=pInfoParm1->pi_aux[0]) == FUNCCAST) {
			len = pInfoParm1->pi_dlen;
#endif
			if (rc=cl_get_def_attr_opt(p,len,iParm,0x01,NULL,NULL)) return rc;
		}
		else {
			iParm[0] = attr;
			iParm[1] = pInfoParm1->pi_len;
			iParm[2] = pInfoParm1->pi_hlen;
			iParm[3] = pInfoParm1->pi_pos;
		}
/*
printf("cl_gx_cast: %s rc=%d iParm=%d %d %d %d\n",p,rc,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
		if (iParm[0] && iParm[0]!=DEF_ZOK_VARI)
			rc = cl_set_parm_init(pInfoParmW,iParm,0x01);
		else
			rc = cl_parm_set0(pInfoParmW);
		if (!rc) rc = cl_gx_rep_info_set(pInfoParmW,pInfoParm2,1);
	}
#if 0
	else if (!stricmp(p,"FUNC")) {
		rc = cl_func_f(pInfoParmW,1,&pInfoParm2);
	}
	else rc = -100;
#endif
	if (rc == -100) {
		/* cl_gx_cast: %s is not suported cast attr. */
		ERROROUT1(FORMAT(161),p);
		rc = ECL_SYSTEM_ERROR;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_check_attr(pInfoParm,attr0,msg)
tdtInfoParm *pInfoParm;
int attr0;
char *msg;
{
	int ret,attr;

	if (ret=cl_check_data_id(pInfoParm,0)) return ret+ECL_CHK_VAR_ERROR;
	else if ((attr=pInfoParm->pi_attr) != attr0) {
				/* %s: �f�[�^����(%d)���w�葮��(%d)�ƈقȂ��Ă��܂��B */
		if (msg) ERROROUT3(FORMAT(160),msg,attr,attr0);
		return ECL_SCRIPT_ERROR;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_mk_cast(pInfoParmW,pm,nparm,ppParm)
tdtInfoParm *pInfoParmW,*pm;
int nparm;
tdtInfoParm *ppParm[];
{
#if 1
	int rc,len,attr,size,iParm[4];
	qSubCommand *sc;
	char *p,c;

	rc = 0;
	p = pm->pi_data;
	len = pm->pi_dlen;
#if 1
	if ((c=*p)=='C' || c=='c') {
		if ((c=*(p+1))!='H' && c!='h') {
			p++;
			len--;
		}
	}
	if (nparm<=0 || nparm>2) {
#else
	len--;
	if (((c=*p)!='C' && c!='c') || nparm<=0 || nparm>2) {
#endif
		/* %s: �����A�܂��́A���x�A�ʎ��̎w�萔(%d)���s���ł��B */
		ERROROUT2(FORMAT(479),"cl_gx_mk_cast",nparm);
		return ECL_SCRIPT_ERROR;
	}

	if (sc=cl_get_name_attr(p,len,0x01,0x20)) {
		size = sc->size;
		attr = sc->attr;
		if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) size = 0;
		iParm[0] = attr;
		iParm[1] = size;
		iParm[2] = 0;
		iParm[3] = 0;
		if (nparm > 0) {
			if (!(rc=cl_get_def_attr_check(nparm,ppParm,iParm,0x01))) {
				*pInfoParmW = *pm;
				pInfoParmW->pi_aux[0] = iParm[0];
				pInfoParmW->pi_len    = iParm[1];
				pInfoParmW->pi_hlen   = iParm[2];	/* precision */
				pInfoParmW->pi_pos    = iParm[3];	/* scale */
			}
		}
	}
	else {
		ERROROUT2(FORMAT(480),"cl_gx_mk_cast",strmem(p,len));
		rc = ECL_NOT_CAST_NAME;
	}
	return rc;
#else
	int rc,i,val[2],len;
	char *p,*w,wrk[23];

	if (nparm<=0 || nparm>2) {
		ERROROUT2((FORMAT(479),"cl_gx_mk_cast",nparm);
		return ECL_SCRIPT_ERROR;
	}

	for (i=0;i<nparm;i++) {
		if (rc=cl_get_parm_bin(ppParm[i],&val[i],"cast:")) return ECL_SCRIPT_ERROR;
	}
	if (!(p=w=cl_tmp_const_malloc(pm->pi_dlen+30))) return ECL_MALLOC_ERROR;
	sprintf(p,"%s(%d",pm->pi_data,val[0]);
	p += strlen(p);
	if (nparm == 2) {
		sprintf(p,",%d",val[1]);
		p += strlen(p);
	}
	strcpy(p,")");
	cl_set_parm_char(pInfoParmW,w,strlen(w));
	pInfoParmW->pi_id = D_DATA_ID_FUNCTION;
printf("cl_gx_mk_cast: w=[%s]\n",w);
	return 0;
#endif
}

/****************************************/
/*										*/
/****************************************/
int cl_func_conv(pInfoParmW,ope,pOperator,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int ope;
char *pOperator;
int nparm;
tdtInfoParm *ppParm[];
{
	int rc;
	tdtInfoParm tInfoParm1,*pInfoParm1,tInfoParm;

	cl_set_parm_char(&tInfoParm,pOperator,strlen(pOperator));
	if (nparm >= 2) {
		pInfoParm1 = &tInfoParm1;
		rc = cl_gx_mk_cast(pInfoParm1,&tInfoParm,nparm-1,&ppParm[1]);
	}
	else {
		pInfoParm1 = &tInfoParm;
		pInfoParm1->pi_aux[0] = FUNCCAST;
		rc = 0;
	}
	if (!rc) rc = cl_gx_cast(pInfoParmW,pInfoParm1,ppParm[0]);
	return rc;
}
