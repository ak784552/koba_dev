static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ�                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_const_c( pparmList , pInfoParm )           *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtInfoParm	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;

int cl_conv_const_c( pparmList , pInfoParm )
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
{
	int i,rc,point,len,Headsize;
	char *pBuff, *p;
	char cM_QUOTE1 = pGlobTable->Quot[0];

	if (!pparmList || !(p=pparmList->prp)) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}

	len = pparmList->prmlen;
	if ((len>=2)&&(p[0]==cM_QUOTE1 && p[len-1]==cM_QUOTE1)) {
		point = len - 2;
		if (point>0) {
			if (!(pBuff=cl_tmp_const_malloc(point+1))) return -1;
			point = cl_conv_yen(p+1,point,pBuff);
		/*	pBuff[point] = '\0';	*/
		}
/*
		else {
printf("cl_conv_const_c: NULL data\n");
		}
*/
	}
	else {
		ERROROUT1(FORMAT(301),p);	/* �����萔�G���[[%s] */
		return ECL_SCRIPT_ERROR;
	}

	cl_set_parm_char(pInfoParm,pBuff,point);
	pInfoParm->pi_aux[1] = D_AUX1_PROTECTED;

	return NORMAL;
}

int cl_set_parm_char(pInfoParm,pBuff,point)
tdtInfoParm  *pInfoParm;
char *pBuff;
int  point;
{
	int Headsize;

	if (!pInfoParm) return -1;

	if (point < 256)
		Headsize = sizeof( FORM_S );
	else
		Headsize = sizeof( FORM_K );
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_CHAR;
	pInfoParm->pi_code = CLcommon.cDataCode;
	pInfoParm->pi_scale= 0;
	pInfoParm->pi_hlen  = 0;
	pInfoParm->pi_pos  = Headsize;
	pInfoParm->pi_dlen  = point;
/*	pInfoParm->pi_len  = Headsize + point;	*/
	pInfoParm->pi_len  = 0;
	if (pInfoParm->pi_dlen == 0) pInfoParm->pi_data = "";
	else pInfoParm->pi_data = pBuff;

	return 0;
}

int cl_conv_yen(buff,len,wkstr)
char *buff,*wkstr;
int  len;
{
	unsigned char c,uc;
	int i,h,n,max,rad,d,len1;

	len1=len-1;
	h=0;
	i=0;
	while (i<len) {
		if (n=akxqiskanji(buff+i)) {
			memcpy(wkstr+h,buff+i,n);
			h += n;
			i += n;
			continue;
		}
		c=buff[i];
/*
printf("cl_conv_yen:i=%d c=%c\n",i,c);
*/
		if (c!='\\' || i>=len1) {
			wkstr[h++] = c;
			i++;
		}
		else {
			if (++i >= len) break;
			c=buff[i];
/*
printf("cl_conv_yen:i=%d c=%c\n",i,c);
*/
#if 1
			if ((c>='0' && c<='9') || c=='x') {
				if (c == 'x') {
					max = 2;
					rad = 16;
					i++;
				}
				else {
					max = 3;
					rad = 8;
				}
				max = X_MIN(i+max,len);
				n=0;
				uc = '\0';
				for (;i<max;i++) {
#else
			if (c>='0' && c<='9') {
				max = 3;
				rad = 8;
				if (c=='0' && i+1<len) {
					if (buff[i+1]=='x') {
						max = 2;
						rad = 16;
						i += 2;
					}
				}
				n=0;
				uc = '\0';
				for (;i<len;i++) {
#endif
					c = buff[i];
					if (c>='0' && c<='7') d = c - '0';
					else d = -1;
					if (rad == 16) {
						if (c>='a' && c<='f') d = c - 'a' + 10;
						else if (c>='A' && c<='F') d = c - 'A' + 10;
					}
/*
printf("cl_conv_yen:i=%d c=%c d=%d h=%d\n",i,buff[i],d,h);
*/
					if (d>=0 && d<rad) {
						uc = uc*rad + d;
#if 1
						n++;
#else
						if (++n == max) {
							wkstr[h++] = uc;
							n = 0;
							uc = '\0';
						}
#endif
					}
					else {
						break;
					}
				}
				if (n) wkstr[h++] = uc;
			}
			else {
				switch (c) {
					case 'n': c = '\n'; break;
					case 'r': c = '\r'; break;
					case 't': c = '\t'; break;
					case 'b': c = '\b'; break;
					case 'f': c = '\f'; break;
				}
				wkstr[h++] = c;
				i++;
			}
		}
	}
	wkstr[h] = '\0';
	return h;
}
