static	char	sccsid[]="%Z% %M% %I% %E% %U%";
#define	AOYAGI
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  							                              *
*                                                                             *
*      �֐����@�@�@�F�@int cl_search_ontbl( pFrameTbl )					      *
*                      (I)pFrameInfo	*pFrameTbl						      *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

int cl_search_ontbl( pFrameTbl )
pFrameInfo	pFrameTbl;
{
	int		i;
	ScrPrCT	 *pScCT;
	long	grno;
	ONTBL   **ontbl;

	pScCT = cl_search_src_ct();

	if ((grno = pFrameTbl->field_1) == 99009) grno = 99003;
	if (pScCT->ONCOND) {
		ontbl = &pScCT->ONCOND[0];
		for (i=0;i<pScCT->on_num_max && ontbl[i];i++) {
			if (grno == ontbl[i]->FldNum) {
				pScCT->OnSelect = i ;
/*
printf("cl_search_ontbl: OnSelect = %d\n",i);
*/
				return NORMAL;
			}
		}
	}
	pScCT->OnSelect = -1;
	ERROROUT1("cl_search_ontbl: GR=%d not found.",grno);
	return ERROR;
}
