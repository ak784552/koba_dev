static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*		���l�f�[�^�̃`�F�b�N				*/
/*											*/
/********************************************/
#include "colmn.h"

int cl_chk_digit(rad, buf, len)
int  rad;
char *buf;
int  len;
{
	int i,n,rad1;
	char *p=buf;

	rad1 = rad - 1;
	for (i=0;i<len;i++) {
		n = *p++ - '0';
		if (n<0 || n>rad1) return -(i+1);
	}
	return 0;
}

int cl_chk_digit_x(buf, len)
char *buf;
int  len;
{
	int i;
	char c,*p=buf;

	for (i=0;i<len;i++) {
		if (!isdigit(c = *p++)) {
			if ((c>='a' && c<='f') ||
			    (c>= 'A' && c<='F'))
				continue;
			else
				return -1;
		}
	}
	return 0;
}

/********************************************/
/*	-1234									*/
/*	-1234.567								*/
/*	-1234.567F								*/
/*	-1234.567D								*/
/*	-1234.567E+10							*/
/*	-1234.567D-10							*/
/********************************************/
int cl_chk_digit_fopt(rad, buf, len, opt)
int  rad;
char *buf;
int  len,opt;
{
	int i,n,rad1,ret,opt2,m;
	char c,*p,cc;

	for (i=0,p=buf;i<len;i++,p++) {
		if ((c=*p)==' ' || c=='\t' || c=='+' || c=='-') ;
		else break;
	}
	if (i >= len) return 0;

	m = 0;
	ret = 0;
	opt2 = opt & AKX_CNVN_OPT_COMMA;
#if 1	/* 2018.5.27 */
	if (c == ',') {
		cc = *(p+1);
		if (opt2 && i<len && ((cc>='0' && cc<='9') || cc=='.')) {
			i++;
			c = *(++p);
			ret = 4;
		}
	}
#endif
	if (c == '.') {
		if (++i >= len) return 2;	/* DECIMAL */
		c = *(++p);
		ret |= 2;
	}
	rad1 = rad - 1;
	n = c - '0';
	if (n<0 || n>rad1) return -1;
	if (n>0) m++;
	i++;
	p++;
	if (opt & AKX_CNVN_OPT_DIGIT) {
		for (;i<len;i++,p++) {
			cc = *p;
			if ((c=toupper(cc))=='B' || c=='O' || c=='X') {
				if (ret) return -1;
				return 0;
			}
			else if (c=='.') {
				if (ret & 0x03) return -1;
				ret |= 2;
			}
			else if (c=='-' || c=='+') {
#if 1	/* 2018.5.27 */
				ret |= 2;
#else
				if (!ret) ret = 2;
#endif
			}
#if 1	/* 2018.6.25 */
			else if (cc=='E') return 2;	/* DECIMAL */
#endif
			else if (c=='E' || c=='F' || c=='D') return 1;	/* DOUBLE */
			else if (c==',') {
				if (opt2) ret |= 4;
			}
			else if (c!='0' || m>0) m++;
		}
	/* 2018.5.27
		if (ret == 4) ret = 2;
	*/
	}
	else {
		for (;i<len;i++,p++) {
			cc = *p;
			if ((c=toupper(cc))=='.') ret = 2;
#if 1	/* 2018.6.25 */
			else if (cc=='E') return 2;	/* DECIMAL */
#endif
			else if (c=='E' || c=='F' || c=='D') ret = 1;
			else if (c==' ') ;
			else if (c=='-' || c=='+') {
#if 1	/* 2018.5.27 */
				ret |= 2;
#else
				if (!ret) ret = 2;
#endif
			}
#if 1	/* 2018.5.27 */
			else if (c==',' && opt2) ret |= 4;
#endif
			else {
				n = c - '0';
				if (n<0 || n>rad1) return -1;
				if (n>0 || m>0) m++;
			}
		}
	}
#if 1	/* 2018.5.27 */
	if (ret) {
		if (ret & 0x01) ret = 1;
		else if (ret & 0x06) ret = 2;
		else ret = 0;
	}
#endif
	if (!ret) {
#if defined(_LP64)
		if (m >= 19)
#else
		if (m >= 10)
#endif
			 ret = 8;
	}
	return ret;
}

int cl_chk_digit_f(rad, buf, len)
int  rad;
char *buf;
int  len;
{
	return cl_chk_digit_fopt(rad,buf,len,0);
}
