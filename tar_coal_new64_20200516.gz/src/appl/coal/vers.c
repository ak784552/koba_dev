char version[] ="@(#) ***[V/R=6.4.0 (new)]***";

