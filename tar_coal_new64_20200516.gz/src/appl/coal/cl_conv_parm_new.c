static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�����[�^�ϊ�                                         *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_parm( pparmList , pInfoParm )              *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtInfoParm	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern int giOptions[];
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;

static long lnull = 0;

/****************************************/
/*										*/
/****************************************/
static int _set_nest_var_name(pparmList, pInfoParm)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
{
	int ret,vnlen;
	char *p,*vname;

	if (pInfoParm->pi_scale & D_DATA_ARRAY_INDEX) {	/* 0x10 */
		if (!(p=(char *)pInfoParm->pi_pos)) return ECL_SYSTEM_ERROR;
/*
printf("_set_nest_var_name: p=[%s] vnlen=%d vname=[%s]\n",
p,pparmList->prmlen,pparmList->prp);
*/
		if ((vnlen=pparmList->prmlen-strlen(p)-1) <= 0) return ECL_SYSTEM_ERROR;
		vname = pparmList->prp;
		if (!(p=cl_tmp_const_malloc(vnlen+Var_NM_MAX*2+1))) {
			ERROROUT("_set_nest_var_name: nest var name area malloc");
			return ECL_SYSTEM_ERROR;
		}
		strnzcpy(p,vname,vnlen);
		pInfoParm->pi_pos = (long)p;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_conv_parm(pparmList, pInfoParm)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
{
	return cl_conv_parm_opt(pparmList, pInfoParm, 0);
}

/****************************************/
/*										*/
/****************************************/
int cl_conv_parm_opt(pparmList, pInfoParm, opti)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
int opti;
{
	int	rc, alclen, opt, ret;
	int ParmNo;
	tdtInfoParm	*pInfoParmW;
	ScrPrCT     *pScCT;
	char op,c,*p;

	if (!pparmList) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return( ECL_SYSTEM_ERROR );
	}
	if (!pparmList->prp) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return( ECL_SYSTEM_ERROR );
	}
	if (!pInfoParm) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}

DEBUGOUTL2(250,"--->cl_conv_parm_op: pparmList->prp=[%s] opti=%08x",pparmList->prp,opti);

	memset(pInfoParm,0,sizeof(tdtInfoParm));
#if 1
	pScCT = cl_search_src_ct();
#else
	if (!(pScCT = cl_search_src_ct())) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}
#endif
	opt = opti & D_GX_OPT_STORE;
	if (opt) op = 's';
	else {
		if (opti & D_GX_OPT_NOEROUT_NDEF) op = 'R';
		else op = 'r';
	}
	rc = cl_gx_get_info_parm_opt(pScCT,op,pparmList,&pInfoParmW,opti);

DEBUGOUT_InfoParm(194,"cl_conv_parm_opt:<---cl_gx_get_info_parm_opt opt=%d rc=%d",
pInfoParmW,opt,rc);

	if (rc) {
		if (rc == ECL_DEFINED_ARRAY) {
			if (!pInfoParmW) return -1;
			if (ret=_set_nest_var_name(pparmList,pInfoParmW)) return ret;
		}
		else return rc;
	}
/*
	else if ((c=pInfoParmW->pi_id) == 'A' || c == 'R') {
		memcpy(pInfoParm,pInfoParmW,sizeof(tdtInfoParm));
		return ECL_DEFINED_ARRAY;
	}
*/
#if 0
	if ((*pparmList->prp=='$') &&
	    (opt || (opti & D_GX_OPT_SET_ADDR))) {
#else
	if (opt || (opti & D_GX_OPT_SET_ADDR)) {
#endif
		cl_set_parm_long(pInfoParm,(long)pInfoParmW);
		pInfoParm->pi_id = 'S';
		pInfoParm->pi_aux[1] = pInfoParmW->pi_aux[1];
	/*	if (*pparmList->prp!='$')	*/
		if ((c=*pparmList->prp)=='%' || c=='#')
			pInfoParm->pi_aux[1] = D_AUX1_PROTECTED;
		else if (pInfoParmW->pi_aux[1] & D_AUX1_PROTECTED)
			pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
	}
	else {
		memcpy(pInfoParm,pInfoParmW,sizeof(tdtInfoParm));
		if ((c=pInfoParmW->pi_id) == 'A' || c == 'R') rc = ECL_DEFINED_ARRAY;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_vnam(opt,pha,name,nl)
char opt,*name;
int nl;
XHASHB *pha;
{
	char hakey[Var_NM_MAX*4+4];
	int i;

	if (!pha) return 0;
#ifdef HASH_FIXED_KEYL  /* 2001.2.22 Koba */
	if (nl >= pha->xha_keylen) {
		memcpy(hakey,name,pha->xha_keylen);
	}
	else {
		memset(hakey,' ',pha->xha_keylen);
		memcpy(hakey,name,nl);
	}
	hakey[Var_NM_MAX] = '\0';
/*
ERROROUT3("opt=[%c] name=[%s] nl=%d",opt,name,nl);
*/
#else
	nl = memnzcpy(hakey,name,nl,sizeof(hakey));
#endif

DEBUGOUTL4(194,"cl_gx_chk_vnam: pha=%08x opt=%c nl=%d hakey=[%s]",pha,opt,nl,hakey);
/*
printf("cl_gx_chk_vnam: pha=%08x opt=%c nl=%d hakey=[%s]\n",pha,opt,nl,hakey);
*/
	pha->xha_xhix = 0;
	return akxs_xhash(pha,opt,hakey);
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_gx_setprm_list_g(name,len)
char *name;
int len;
{
	tdtInfoParm InfoParm,*pInfoParm;
	parmList pL;
	char buf[33],*p;

	*buf = '$';
	if (len>31) len = 31;
	memzcpy(buf+1,name,len);
	pL.prp = buf;
	pL.prmlen = len + 1;
	if (cl_conv_sysvar(&pL,&InfoParm)) return NULL;
	if (pInfoParm = (tdtInfoParm *)cl_const_malloc(sizeof(tdtInfoParm))) {
		memset(pInfoParm,0,sizeof(tdtInfoParm));
		if (cl_gx_rep_info_set(pInfoParm ,&InfoParm ,0)) {
		/*	Free(pInfoParm);	*/
			pInfoParm = NULL;
		}
	}
	return pInfoParm;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm_opt(pScCT,opt,pparmList,ppInfoParm,iOpt)
ScrPrCT	  *pScCT;
char opt;
parmList  *pparmList;
tdtInfoParm **ppInfoParm;
int iOpt;
{
	int  ParmNo, rc, vnlen, pLlen, iLOCAL, ix;
	char c, *vname, *pLprp, data_id, *p;
	tdtInfoParm *pInfoParm, ***pTBL_vnam;
	char varnam[Var_NM_MAX+1];
	tdtArrayIndex tIndex;
	ProcCT  *proc;
	uchar ucLGopt;

	if (!ppInfoParm) return -1;
	*ppInfoParm=NULL;
	pInfoParm=NULL;

	pLlen = pparmList->prmlen;
	pLprp = pparmList->prp;

DEBUGOUTL4(194,"--->cl_gx_get_info_parm_opt: pScCT=%08x opt=%c name=[%s]",
pScCT,opt,pLprp,0);

	LOGBUF(strlen(pLprp)+128);
	if ((ParmNo=cl_gx_get_index_array(pparmList,varnam,&pInfoParm,iOpt)) < 0) {
		if (ParmNo == ECL_DEFINED_ARRAY) *ppInfoParm = pInfoParm;
				/* cl_gx_get_info_parm_opt:%s�̓p�����[�^�Ɍ�肪����܂��B */
		else if (!(iOpt & D_GX_OPT_NOEROUT_NDEF)) ERROROUT1(FORMAT(311),pLprp);
		return ParmNo;
	}

	c = *pLprp;
	if (ParmNo==0 && *varnam &&		/* �ϐ������z�񖼂��ǂ����̃`�F�b�N */
#if 0
	    !(iOpt & D_GX_OPT_SET_LOCAL) &&
	    (c=='$' || c=='%' || c=='#')) {		/* �z�񖼂́A%,#�t���œo�^����Ă��� */
#else
	    (c=='%' || c=='#')) {		/* �z�񖼂́A%,#�t���œo�^����Ă��� */
#endif
		ucLGopt = 0;
		rc = 0;
		proc = NULL;
		if (pScCT) proc = cl_search_proc_ct();
		rc = cl_gx_get_parm_no(pScCT,proc,pLprp,pLlen,'r',0,&pTBL_vnam,&ucLGopt);
DEBUGOUTL4(194,"<---cl_gx_get_info_parm_opt.array: pScCT=%08x ParmNo=%d %s rc=%d",
pScCT,ParmNo,pLprp,rc);
		if (rc > 0){
			/* �z�񖼂Ƃ��ēo�^����Ă��� */
			if (pInfoParm = cl_get_var_ent(pTBL_vnam,rc)) {
#if 0	/* �����ł́A�z�񂪖����ɂȂ邱�Ƃ͂Ȃ� */
				if (ucLGopt!=D_AUX1_PUBLIC_VAR && pInfoParm->pi_hlen) {
					if ((ix=akxs_xhasl(pCLprocTable->pha_gid,'R',pInfoParm->pi_hlen,0)) <= 0) {
						ERROROUT3(FORMAT(322),"cl_gx_get_info_parm_opt",varnam,ix);
						return -1;
					}
				}
#endif

DEBUGOUT_InfoParm(194,"cl_gx_get_info_parm_opt.array: ",pInfoParm,0,0);

			/*	if (iLOCAL) pInfoParm->pi_aux[1] |= D_AUX1_LOCAL_VAR;	*/
				pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | ucLGopt;
				*ppInfoParm = pInfoParm;
				return 0;
			}
		}
	}
	rc = cl_gx_get_all_var_ent(pScCT,opt,pLprp,ppInfoParm,ParmNo,varnam,iOpt);
	if (!rc) {
		pInfoParm = *ppInfoParm;
#if 0
		if (pInfoParm->pi_id=='T') {
			ix = akxnskipto(pLprp,pLlen,".");
			if (++ix < pLlen) {
				if (rc=_ex_get_member(&pInfoParm,opt,pLprp+ix,pLlen-ix)) return rc;
				*ppInfoParm = pInfoParm;
			}
		}
#else
		ix = akxnskipto(pLprp,pLlen,".");
		if (++ix < pLlen) {
			if (pInfoParm->pi_id=='T') {
				if (rc=_ex_get_member(&pInfoParm,opt,pLprp+ix,pLlen-ix)) return rc;
				*ppInfoParm = pInfoParm;
			}
			else {
				/* cl_gx_get_info_parm_opt: [%s]�����o�[�͎w��ł��܂���B */
				ERROROUT2(FORMAT(166),"cl_gx_get_info_parm_opt",pLprp);
				rc = ECL_SCRIPT_ERROR;
			}
		}
#endif
#if 1
		if (pInfoParm->pi_id=='R' &&
		    (!pInfoParm->pi_pos || (pInfoParm->pi_pos && !*(char *)pInfoParm->pi_pos))) {
			vnlen = strlen(varnam);
			if (!(p=Malloc(vnlen+1))) {
				ERROROUT1("cl_gx_get_info_parm_opt: Array name[%s] area malloc",varnam);
				return -1;
			}
			strnzcpy(p,varnam,vnlen);
			pInfoParm->pi_pos = (long)p;
		}
#endif
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm(pScCT,opt,pparmList,ppInfoParm)
ScrPrCT	  *pScCT;
char opt;
parmList  *pparmList;
tdtInfoParm **ppInfoParm;
{
	return cl_gx_get_info_parm_opt(pScCT,opt,pparmList,ppInfoParm,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_parm_no_static(pScCT,proc,varnam,vnlen,opt,iOpt,argv)
ScrPrCT	*pScCT;
ProcCT  *proc;
char    *varnam;
int      vnlen;
char     opt;
int      iOpt;
char    *argv[];
{
	int  ParmNo,iLGopt,nl;
	XHASHB  *pha_vname;
	tdtInfoParm ***pTBL_vnam;
	ProcCT  *procW;
	char wrk[Var_NM_MAX*4+4],*p,*pSco,*pSta;

	p = NULL;
	iLGopt = (int)argv[1];
	if      (iLGopt == D_AUX1_LOCAL_VAR)   *pSco = "LOCAL"
	else if (iLGopt == D_AUX1_PRIVATE_VAR) *pSco = "SCRIPT"
	else if (iLGopt == D_AUX1_PUBLIC_VAR)  *pSco = "PUBLIC"
	else if (iLGopt == D_AUX1_GLOBAL_VAR)  *pSco = "GLOBAL"
	pSta = "";
	if (iOpt & D_GX_OPT_SET_STATIC) {
		pSta = " STATIC";
		p = wrk;
		strcpy(p,"S.");
		p += strlen(p);
		if (iLGopt==D_AUX1_LOCAL_VAR || iLGopt==D_AUX1_PRIVATE_VAR) {
			strcpy(p,pScCT->pId);
			p += strlen(p);
			strcpy(p,".");
			p++;
		}
		if (iLGopt == D_AUX1_LOCAL_VAR) {
			strcpy(p,proc->ProcNM);
			p += strlen(p);
			strcpy(p,".");
			p++;
		}
		memnzcpy(p,varnam,vnlen,sizeof(wrk)-strlen(wrk));
		nl = strlen(wrk);
		if (iLGopt == D_AUX1_GLOBAL_VAR) {
			pha_vname = pGLprocTable->pha_vnam;
			pTBL_vnam = pGLprocTable->pTBL_vnam;
		}
		else if (!(iOpt & D_GX_OPT_SET_IMPORT)) {
			pha_vname = pCLprocTable->pha_vnam;
			pTBL_vnam = pCLprocTable->pTBL_vnam;
		}
		ParmNo = cl_gx_chk_vnam(opt,pha_vnam,wrk,nl);
		p = clmemdup(wrk,nl,D_OPT_ALC_TMP);
	}
	else if (iLGopt == D_AUX1_LOCAL_VAR) {
		if ((ParmNo=cl_gx_chk_scope(opt,proc,varnam,vnlen,&procW)) > 0) {
			pTBL_vnam = procW->pTBL_vnam;
		}
	}
	else {
		if (iLGopt == D_AUX1_PRIVATE_VAR) {
			pha_vname = pScCT->Vary->pha_vnam;
			pTBL_vnam = pScCT->Vary->pTBL_vnam;
		}
		else if (iLGopt == D_AUX1_PUBLIC_VAR) {
			pha_vname = pCLprocTable->pha_vnam;
			pTBL_vnam = pCLprocTable->pTBL_vnam;
		}
		else if (iLGopt == D_AUX1_GLOBAL_VAR) {
			pha_vname = pGLprocTable->pha_vnam;
			pTBL_vnam = pGLprocTable->pTBL_vnam;
		}
		if ((ParmNo=cl_gx_chk_vnam(opt,pha_vname,varnam,vnlen)) > 0) {
	}
	if (ParmNo > 0) {
		iLGopt |= iOpt & D_GX_OPT_SET_STATIC;
DEBUGOUTL3(190,"cl_gx_get_parm_no_static: %% ParmNo=%d",pSco,pSta,ParmNo);
	}
	else {
		pTBL_vnam = NULL;
		iLGopt = 0;
	}
	argv[0] = (char *)pTBL_vnam;
	argv[1] = (char *)iLGopt;
	atgv[2] = p;

	return ParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_parm_no(pScCT,proc,varnam,vnlen,opt,iOpt,ppTBL_vnam,piLGopt)
ScrPrCT	*pScCT;
ProcCT  *proc;
char    *varnam;
int      vnlen;
char     opt;
int      iOpt;
tdtInfoParm ****ppTBL_vnam;
uchar   *piLGopt;
{
	int  ParmNo,iNEW_LEX,iSKIP,iCHECK,iLGopt,nl;
	tdtInfoParm ***pTBL_vnam;
	ProcCT  *procW;
	char wrk[Var_NM_MAX*4+4],*p,*argv[3];

DEBUGOUTL5(190,"--->cl_gx_get_parm_no: pScCT=%08x proc=%08x [%s] opt=%c iOpt=%08x",
pScCT,proc,varnam,opt,iOpt);
	if ((iOpt & D_GX_OPT_SET_PRIVATE) ||
   	    (opt=='s' && (giOptions[9] & 0x01))) iSKIP = 1;
	else iSKIP = 0;
	if (pScCT) iNEW_LEX = pScCT->pFlag & D_SCRPT_NEW_LEX;
	else iNEW_LEX = 0;
DEBUGOUTL2(190,"cl_gx_get_parm_no: iNEW_LEX=%08x iSKIP=%d",iNEW_LEX,iSKIP);
	vnlen = akxnskipto(varnam,vnlen,".");
	ParmNo = 0;
	pTBL_vnam = NULL;
	iLGopt= 0;
	argv[0] = (char *)pTBL_vnam;
	argv[1] = (char *)iLGopt;
	if (proc && proc->pha_vnam && iNEW_LEX && !iSKIP) {
#if 1
		iLGopt = D_AUX1_LOCAL_VAR;
		argv[1] = (char *)iLGopt;
		ParmNo = cl_gx_get_parm_no_static(pScCT,proc,varnam,vnlen,opt,iOpt,argv)
#else
#if 1
		if ((ParmNo=cl_gx_chk_scope(opt,proc,varnam,vnlen,&procW)) > 0) {
			pTBL_vnam = procW->pTBL_vnam;
#else
		if ((ParmNo=cl_gx_chk_vnam(opt,proc->pha_vnam,varnam,vnlen)) > 0) {
			pTBL_vnam = proc->pTBL_vnam;
#endif
			iLGopt = D_AUX1_LOCAL_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: LOCAL ParmNo=%d",ParmNo);
		}
#endif
	}
	if (ParmNo<=0 && pScCT) {
#if 1
		iLGopt = D_AUX1_PRIVATE_VAR;
		argv[1] = (char *)iLGopt;
		ParmNo = cl_gx_get_parm_no_static(pScCT,proc,varnam,vnlen,opt,iOpt,argv)
#else
		if ((ParmNo=cl_gx_chk_vnam(opt,pScCT->Vary->pha_vnam,varnam,vnlen)) > 0) {
			pTBL_vnam = pScCT->Vary->pTBL_vnam;
		/*	if (iCHECK) iLGopt = D_AUX1_PRIVATE_VAR;	*/
			iLGopt = D_AUX1_PRIVATE_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: SCRIPT ParmNo=%d",ParmNo);
		}
#endif
	}
	if (ParmNo<=0 && opt=='r') {
#if 1
		iLGopt = D_AUX1_PUBLIC_VAR;
		argv[1] = (char *)iLGopt;
		ParmNo = cl_gx_get_parm_no_static(pScCT,proc,varnam,vnlen,opt,iOpt,argv)
#else
		if ((ParmNo=cl_gx_chk_vnam(opt,pCLprocTable->pha_vnam,varnam,vnlen)) > 0) {
			pTBL_vnam = pCLprocTable->pTBL_vnam;
			iLGopt = D_AUX1_PUBLIC_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: PUBLIC ParmNo=%d",ParmNo);
		}
#endif
	}
	if (ParmNo<=0 && opt=='r') {
#if 1
		iLGopt = D_AUX1_GLOBAL_VAR;
		argv[1] = (char *)iLGopt;
		ParmNo = cl_gx_get_parm_no_static(pScCT,proc,varnam,vnlen,opt,iOpt,argv)
#else
		if ((ParmNo=cl_gx_chk_vnam(opt,pGLprocTable->pha_vnam,varnam,vnlen)) > 0) {
			pTBL_vnam = pGLprocTable->pTBL_vnam;
			iLGopt = D_AUX1_GLOBAL_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: GLOBAL ParmNo=%d",ParmNo);
		}
#endif
	}
#if 1
	if (ppTBL_vnam) *ppTBL_vnam = (tdtInfoParm ***)argv[0];
	*piLGopt= (int)argv[1];
#else
	if (ppTBL_vnam) *ppTBL_vnam = pTBL_vnam;
	*piLGopt= iLGopt;
#endif

	return ParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_all_var_ent(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
int  ParmNo;
char *varnam;
int  iOpt;
{
	static char *_fn_="cl_gx_get_all_var_ent";
	int rc, vnlen,*pSize,iEROUT_NDEF=1,iLOCAL,ix,iLGopt;
	char c,opt,optw;
	tdtInfoParm *pInfoParm, ***pTBL_vnam;
	ProcCT  *proc;
/*	uchar ucLGopt;	*/

	rc = 0;
	if (!ppInfoParm) return -1;
	*ppInfoParm = NULL;
	pInfoParm = NULL;
	if ((opt=opti) == 'R') {
		iEROUT_NDEF = 0;
		opt = 'r';
	}
	iLOCAL = iOpt & D_GX_OPT_SET_LOCAL;

DEBUGOUTL5(190,"--->cl_gx_get_all_var_ent: opt=%c pScCT=%08x ParmNo=%d %s(%s)",
opt,pScCT,ParmNo,name,varnam);
DEBUGOUTL1(190,"cl_gx_get_all_var_ent: iOpt=%08x",iOpt);


/*	if ((c=name[0]) == '$') {	*/
	if ((c=name[0])=='$' || (c!='%' && c!='#')) {
		if (ParmNo == 0 && *varnam) {	/* �z��łȂ��ϐ����̃`�F�b�N */
										/* $,%,#�Ȃ��œo�^����Ă��� */ 
			if (iOpt & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_PUBLIC | D_GX_OPT_SET_GLOBAL))
				return cl_gx_get_lg_var_ent(pScCT,opti,name,ppInfoParm,varnam,iOpt,iEROUT_NDEF);
		
			vnlen = strlen(varnam);
			if (cl_chk_sysvar_name(varnam,vnlen)) {
				pInfoParm = cl_gx_setprm_list_g(varnam,vnlen);
			}
			else {
				iLGopt = 0;
				proc = NULL;
				if (pScCT) proc = cl_search_proc_ct();
/*
printf("cl_gx_get_all_var_ent: proc=%08x\n",proc);
*/
				ParmNo = cl_gx_get_parm_no(pScCT,proc,varnam,vnlen,'r',0,&pTBL_vnam,&iLGopt);
				if (ParmNo<=0 && (opt=='s' || (giOptions[0] & 0x02))) {
					ParmNo = cl_gx_get_parm_no(pScCT,proc,varnam,vnlen,'s',iOpt,&pTBL_vnam,&iLGopt);
				}
				if (ParmNo <= 0) {
					if (optw == 's')
						/* cl_gx_get_all_var_ent: %s(%s)�̃G���g���p�̋󂫂�����܂���B */
						ERROROUT3(FORMAT(316),_fn_,name,varnam);
					else {
											/* cl_gx_get_all_var_ent: %s(%s)�͖���`�ł��B */
						if (iEROUT_NDEF) ERROROUT3(FORMAT(317),_fn_,name,varnam);
						return ECL_NDEFVAR_ERROR;
					}
					return ECL_SCRIPT_ERROR;
				}
				else {
					pInfoParm = cl_get_var_ent(pTBL_vnam,ParmNo);
					if (!pInfoParm) rc = -2;
					else {
						pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | iLGopt;
						if (opt == 's') pInfoParm->pi_aux[1] |= D_AUX1_OPT_STORE;
					}
				}
			}
		}
		else {
			if (!*varnam &&
			    (iOpt & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_PUBLIC))) {
				/* cl_gx_get_all_var_ent: %s�͎g�p�ł��܂���B */
				ERROROUT2(FORMAT(318),_fn_,name);
				return ECL_SCRIPT_ERROR;
			}
			pSize = (int *)pScCT->Vary->pTBL_dolu[0];
			if (pScCT && ParmNo>0 && ParmNo<=pSize[2]) {
				pInfoParm = cl_get_var_ent(pScCT->Vary->pTBL_dolu,ParmNo);
				if (!pInfoParm) rc = -2;
			}
			else rc = -1;
		}
	}
	else if (c=='%' || c=='#') {
		if (!ParmNo && *varnam) {
			/* cl_gx_get_all_var_ent: %s�͎g�p�ł��܂���B */
			ERROROUT2(FORMAT(318),_fn_,name);
			return (ECL_SCRIPT_ERROR);
		}
		else {
			if (!pScCT) return -1;
			if (c == '%') {
				if (iLOCAL) {
					if (!(proc = cl_search_proc_ct())) return SysError;
					if (pTBL_vnam=proc->pTBL_pasento) pSize = (int *)pTBL_vnam[0];
					else ParmNo = -1;
				}
				else {
					pTBL_vnam = pScCT->Vary->pTBL_pasento;
					pSize = (int *)pTBL_vnam[0];
				}
				if (ParmNo>0 && ParmNo<=pSize[2]) {
					pInfoParm = cl_get_var_ent(pTBL_vnam,ParmNo);
				}
				else if (ParmNo == 0) {
					pInfoParm = cl_var_size_parm(pSize);
				}
				else rc = -1;
				if (!rc && pInfoParm && pInfoParm->pi_id=='\0') {
					cl_null_parm(pInfoParm);
					pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
				}
			}
			else if (c=='#') {
				if (ParmNo>0 && ParmNo<=pScCT->Vary->varnam_igeta)
					pInfoParm = cl_get_var_ent(pScCT->Vary->pTBL_igeta,ParmNo);
				else if (ParmNo == 0) {
					pInfoParm = cl_var_size_parm(pScCT->Vary->pTBL_igeta[0]);
				}
				else rc = -1;
			}
		}
	}
	else {
		/* cl_gx_get_all_var_ent: %s�͕ϐ��ł͂���܂���B */
		ERROROUT2(FORMAT(319),_fn_,name);
		return (ECL_SCRIPT_ERROR);
	}

DEBUGOUT_InfoParm(194,"cl_gx_get_all_var_ent: rc=%d name=%s",pInfoParm,rc,name);

	if (rc) {
		if (rc == -1)
			/* cl_gx_get_all_var_ent: %s�̃C���f�b�N�X(%d)�͔͈͊O�ł��B */
			ERROROUT3(FORMAT(320),_fn_,name,ParmNo);
		else
			/* cl_gx_get_all_var_ent: %s�p��Malloc�G���[�B*/
			ERROROUT2(FORMAT(321),_fn_,name);
		return ECL_SCRIPT_ERROR;
	}
	if (pInfoParm == NULL) {
		return ECL_SCRIPT_ERROR;
	}
	else if (opt == 'r' && pInfoParm->pi_id == '\0') {
		if (giOptions[0] & 0x01) {
			cl_null_data(pInfoParm);
			return 0;
		}
	/*	if (iEROUT_NDEF) ERROROUT1("cl_gx_get_all_var_ent: %s�͖���`�ł��B",name);	*/
						/* cl_gx_get_all_var_ent: %s�̃f�[�^�����ݒ�ł��B */
		if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,name);
		return ECL_NDEFVAR_ERROR;
	}
	if (((c=pInfoParm->pi_id)=='A' || c=='R') && pInfoParm->pi_hlen) {
		if ((ix=akxs_xhasl(pCLprocTable->pha_gid,'R',pInfoParm->pi_hlen,0)) <= 0) {
			/* cl_gx_get_all_var_ent: �ϐ�(%s)�̔z��͖����ł�(gid hash ix=%d)�B */
			ERROROUT3(FORMAT(322),_fn_,name,ix);
#if 1
			cl_free_info_parm(pInfoParm);
		/*	cl_null_data(pInfoParm);	*/
#else
			pInfoParm->pi_data = NULL;
#endif
			return ECL_NDEFVAR_ERROR;
		}
	}
	*ppInfoParm = pInfoParm;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
#if 1
static int _get_lg_var_ent(scope,opti,pxha,varnam,vnlen,iEROUT_NDEF,
                           pScCT,proc,iOpt,ppTBL_vnam,piLGopt)
char *scope,opti;
XHASHB	*pxha;
char *varnam;
int vnlen,iEROUT_NDEF;
ScrPrCT	*pScCT;
ProcCT  *proc;
int      iOpt;
tdtInfoParm ****ppTBL_vnam;
uchar   *piLGopt;
#else
static int _get_lg_var_ent(scope,opti,pxha,varnam,vnlen,iEROUT_NDEF)
char *scope,opti;
XHASHB	*pxha;
char *varnam;
int vnlen,iEROUT_NDEF;
#endif
{
	static char *_fn_="_get_lg_var_ent";
	int iParmNo;
	char opt,name[Var_NM_MAX+1],*argv[3];

	if (giOptions[0] & 0x02) opt = 's';
	else opt = opti;
	memnzcpy(name,varnam,vnlen,sizeof(name)-1);
/*
printf("_get_lg_var_ent: opti=%c name=[%s]\n",opti,name);
*/
	if (iOpt & D_GX_OPT_SET_STATIC) {
		argv[0] = (char *)*ppTBL_vnam;
		argv[1] = (char *)*piLGopt;
		iParmNo = cl_gx_get_parm_no_static(pScCT,proc,varnam,vnlen,opt,iOpt,argv)
		*ppTBL_vnam = (tdtInfoParm ***)argv[0];
		*piLGopt = (int)argv[1];
	}
	else {
		iParmNo = cl_gx_chk_vnam(opt,pxha,varnam,vnlen);
	}
	if (iParmNo <= 0) {
		if (opt == 's') {
			/* _get_lg_var_ent: %s��%s�G���g���p�̋󂫂�����܂���B */
			ERROROUT3(FORMAT(323),_fn_,name,scope);
			iParmNo = ECL_SCRIPT_ERROR;
		}
		else {
							/* _get_lg_var_ent: %s�͖���`�ł��B */
			if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,name);
			iParmNo = ECL_NDEFVAR_ERROR;
		}
	}
	return iParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_lg_var_ent(pScCT,opti,name,ppInfoParm,varnam,iOpt,iEROUT_NDEF)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
char *varnam;
int  iOpt,iEROUT_NDEF;
{
	static char *_fn_="cl_gx_get_lg_var_ent";
	int rc,vnlen;
	tdtInfoParm *pInfoParm, ***pTBL_vname;
	ProcCT  *proc,*procW;
	int  iParmNo,iLGopt;
	XHASHB	*pxha;

DEBUGOUTL4(190,"--->%s: pScCT=%08x varnam=[%s] iOpt=%08x",_fn_,pScCT,varnam,iOpt);

	rc = 0;
	vnlen = strlen(varnam);
	vnlen = akxnskipto(varnam,vnlen,".");
	if (pScCT) proc = cl_search_proc_ct();
	if (iOpt & D_GX_OPT_SET_LOCAL) {
		proc = NULL;
		if (pScCT) proc = cl_search_proc_ct();
/*
printf("%s: proc=%08x\n",_fn_,proc);
*/
		if (proc && proc->pha_vnam) {
			if (opti=='r' && !(giOptions[0] & 0x02)) {
				if ((iParmNo=cl_gx_chk_scope(opti,proc,varnam,vnlen,&procW)) < 0) return iParmNo;
				else if (!iParmNo) {
								/* %s: %s�͖���`�ł��B */
					if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,strname(varnam,vnlen));
					return ECL_NDEFVAR_ERROR;
				}
				pTBL_vname = procW->pTBL_vnam;
			}
			else {
				pxha = proc->pha_vnam;
				iLGopt = D_AUX1_LOCAL_VAR;
				pTBL_vname = proc->pTBL_vnam;
				if ((iParmNo=_get_lg_var_ent("LOCAL",opti,pxha,varnam,vnlen,iEROUT_NDEF
				                            ,pScCT,proc,iOpt,&pTBL_vnam,&iLGopt)) < 0) return iParmNo;
			}
			iLGopt = D_AUX1_LOCAL_VAR;
		}
		else return -1;
	}
	else {
		if (iOpt & D_GX_OPT_SET_GLOBAL) {
			pxha = pGLprocTable->pha_vnam;
			pTBL_vname = pGLprocTable->pTBL_vnam;
			iLGopt = D_AUX1_GLOBAL_VAR;
			if ((iParmNo=_get_lg_var_ent("GLOBAL",opti,pxha,varnam,vnlen,iEROUT_NDEF)
				                        ,pScCT,proc,iOpt,&pTBL_vnam,&iLGopt)) < 0) return iParmNo;
		}
		else if (iOpt & D_GX_OPT_SET_PUBLIC) {
			pxha = pCLprocTable->pha_vnam;
			pTBL_vname = pCLprocTable->pTBL_vnam;
			iLGopt = D_AUX1_PUBLIC_VAR;
			if ((iParmNo=_get_lg_var_ent("PUBLIC",opti,pxha,varnam,vnlen,iEROUT_NDEF)
				                        ,pScCT,proc,iOpt,&pTBL_vnam,&iLGopt)) < 0) return iParmNo;
		}
		else if (pScCT) {
			pxha = pScCT->Vary->pha_vnam;
			pTBL_vname = pScCT->Vary->pTBL_vnam;
			iLGopt = D_AUX1_PRIVATE_VAR;
			if ((iParmNo=_get_lg_var_ent("SCRIPT",opti,pxha,varnam,vnlen,iEROUT_NDEF)
				                        ,pScCT,proc,iOpt,&pTBL_vnam,&iLGopt)) < 0) return iParmNo;
		}
		else {
			/* %s: SCRIPT�ϐ�[%s]�͒�`�ł��܂���B */
			ERROROUT2(FORMAT(324),_fn_,varnam);
			return ECL_SCRIPT_ERROR;
		}
	}

DEBUGOUTL2(190,"%s: iParmNo = %d",_fn_,iParmNo);

	pInfoParm = cl_get_var_ent(pTBL_vname,iParmNo);
	if (!pInfoParm) rc = -2;
	else pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | iLGopt;

	if (ppInfoParm) *ppInfoParm = pInfoParm;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent(pVarIndex,ParmNo)
tdtInfoParm **pVarIndex[];
int ParmNo;
{
	int ix,iy,i,*pSize,iMAX_VAR_IX,iMAX_VAR_IY;
	tdtInfoParm *pDummy, **TBL_var;

	if (!pVarIndex || ParmNo<=0) return NULL;
	pSize = (int *)pVarIndex[0];
	iMAX_VAR_IX = pSize[0];
	iMAX_VAR_IY = pSize[1];
	pVarIndex++;
/*
printf("cl_get_var_ent: id=%s iMAX_IX=%d iMAX_IY=%d MAX_XY=%d\n",
&pSize[3],iMAX_VAR_IX,iMAX_VAR_IY,pSize[2]);
*/
	ParmNo--;
	ix = ParmNo / iMAX_VAR_IY;
	iy = ParmNo % iMAX_VAR_IY;

DEBUGOUTL4(190,"--->cl_get_var_ent:pVarIndex=%08x ParmNo=%d ix=%d iy=%d",
pVarIndex,ParmNo,ix,iy);

	if (!(TBL_var = pVarIndex[ix])) {
		if (!(TBL_var=(tdtInfoParm **)Malloc(sizeof(tdtInfoParm *)*iMAX_VAR_IY)))
			return NULL;
/*
printf("cl_get_var_ent:Malloc TBL_var=%08x\n",TBL_var);
*/
		memset(TBL_var,0,sizeof(tdtInfoParm *)*iMAX_VAR_IY);
		pVarIndex[ix++] = TBL_var;
		pSize[5] = X_MAX(ix,pSize[5]);
		if (!(pDummy=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)*iMAX_VAR_IY)))
			return NULL;
/*
printf("cl_get_var_ent:Malloc pDummy=%08x\n",pDummy);
*/
		for(i=0;i<iMAX_VAR_IY;i++) {
			TBL_var[i] = (tdtInfoParm *)parm_set0(pDummy);
			pDummy++;
		}
	}
/*
printf("cl_get_var_ent:TBL_var[iy]=%08x\n",TBL_var[iy]);
*/
	pDummy = TBL_var[iy];
	if (!pDummy->pi_id && (giOptions[0] & 0x01)) cl_null_data(pDummy);
	return pDummy;
}

/****************************************/
/*										*/
/****************************************/
static int _free_info_array(pDummy)
tdtInfoParm *pDummy;
{
	tdtArrayIndex *pIndex;
	char *p;

	if (pIndex=(tdtArrayIndex *)pDummy->pi_data) {
		if (pDummy->pi_scale & D_DATA_INDEX_FREE) cl_free_array_ent(pIndex);
		Free(pIndex);
	}
	if (p=(char *)pDummy->pi_pos) {
		if (!(pDummy->pi_alen & D_AULN_NO_AL_LPOS)) Free(p);
		pDummy->pi_pos = 0;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_info_parm(pDummy)
tdtInfoParm *pDummy;
{
	tdtArrayIndex *pIndex;
	char c,*p;
	XHASHB *xhp;
	tdtInfoParm *pParm;
	tdtInfoParm *pInfoParm1,*pInfoS;
	tdtRbCtl *pCt;
	tdtDefType *pDeftype;
	int ix,type,i,len,n;
	ProcCT *proc;

DEBUGOUT_InfoParm(250,"--->cl_free_info_parm:",pDummy,0,0);

	if (pDummy && pDummy->pi_id) {
		if (pDummy->pi_scale & D_DATA_MALLOC) {
			if ((c=pDummy->pi_id)=='R' || c=='A') {
				_free_info_array(pDummy);
			}
			else if (c=='P' || c=='T') {
				if (c == 'P') {
					if (pDummy->pi_len > 0) {
						ix = akxs_xhasl(pCLprocTable->pha_gid,'D',pDummy->pi_len,0);
/*
printf("cl_free_info_parm: Delete gid=%ld ix=%d\n",pDummy->pi_len,ix);
*/
					}
				}
				if ((type=pDummy->pi_aux[0]) == D_AUX0_TYPE_STRUCT) {
					if (pDeftype=(tdtDefType *)pDummy->pi_data) {
						if (pDummy->pi_scale & D_DATA_INDEX_FREE)
							cl_free_deftype(c,pDeftype);
						Free(pDeftype);
					}
					if (p=(char *)pDummy->pi_pos) {
						Free(p);
						pDummy->pi_pos = 0;
					}
				}
				else _free_info_array(pDummy);
			}
#if 1
			else if (c==D_DATA_ID_LIST) {
				 if (pCt=(tdtRbCtl *)pDummy->pi_data) {
					while (pParm=(tdtInfoParm *)akxs_rb_get_n(pCt)) {
						cl_free_info_parm(pParm);
						Free(pParm);
					}
					akxs_rb_free(pCt);
				}
			}
#endif
#if 1
			else if (c==D_DATA_ID_INSTANCE || c==D_DATA_ID_CLASS || c==D_DATA_ID_CLMETHOD) {
DEBUGOUTL3(250,"cl_free_info_parm: pDummy=%08x pi_scale=%02x pi_data=[%s]"
,pDummy,pDummy->pi_scale,pDummy->pi_data);
				if (p=pDummy->pi_data) Free(p);
				if (!(pDummy->pi_scale & D_DATA_COPIED_PROC) && (proc=(ProcCT *)pDummy->pi_len)) {
					cl_prc_clear(proc);
				}
			}
#endif
			else if (p=pDummy->pi_data) Free(p);
			pDummy->pi_data = NULL;
		}
		else if (pDummy->pi_alen & D_AULN_PARMINFO2) {
			pInfoParm1 = pDummy + 1;
			if (pInfoParm1->pi_scale & D_DATA_MALLOC) {
				len = pInfoParm1->pi_dlen;
				pInfoS = (tdtInfoParm *)pInfoParm1->pi_data;
				n = len/sizeof(tdtInfoParm);
				for (i=0;i<n;i++,pInfoS++) {
					pInfoS->pi_alen &= ~D_AULN_PARMINFO2;
					cl_free_info_parm(pInfoS);
				}
				Free(pInfoParm1->pi_data);
			}
		}
#if 0
		if (pDummy->pi_id==D_DATA_ID_LIST && (pCt=(tdtRbCtl *)pDummy->pi_data)) {
			while (pParm=(tdtInfoParm *)akxs_rb_get_n(pCt)) {
				cl_free_info_parm(pParm);
				Free(pParm);
			}
			akxs_rb_free(pCt);
			pDummy->pi_data = NULL;
		}
#endif
	/*
		if ((pDummy->pi_aux[1] & D_AUX1_LIST_DATA) && pDummy->pi_len) {
			pParm = (tdtInfoParm *)pDummy->pi_len;
			cl_free_info_parm(pParm);
			Free(pParm);
			pDummy->pi_len = 0;
			pDummy->pi_aux[1] &= ~D_AUX1_LIST_DATA;
		}
	*/
#if 1
		cl_parm_set0(pDummy);
#else
		cl_null_data(pDummy);
#endif
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_var_ent(pVarIndex)
tdtInfoParm **pVarIndex[];
{
	int ix,iy;
	tdtInfoParm *pDummy, **TBL_var;
	int *pSize,iMAX_VAR_IX,iMAX_VAR_IY;

DEBUGOUTL1(190,"--->cl_free_var_ent:pVarIndex=%08x",pVarIndex);

	if (!pVarIndex) return -1;
	pSize = (int *)pVarIndex[0];
/*	iMAX_VAR_IX = pSize[0];	*/
	iMAX_VAR_IX = pSize[5];
	iMAX_VAR_IY = pSize[1];
	pVarIndex++;

DEBUGOUTL4(190,"cl_free_var_ent: id=%s iMAX_IX=%d iMAX_IY=%d MAX_XY=%d",
&pSize[3],iMAX_VAR_IX,iMAX_VAR_IY,pSize[2]);

	for (ix = 0; ix < iMAX_VAR_IX; ix++) {
		if (TBL_var = pVarIndex[ix]) {
			if (TBL_var[0]) {
				for (iy = 0; iy < iMAX_VAR_IY; iy++) {
					pDummy = TBL_var[iy];
					if (pDummy && pDummy->pi_id) cl_free_info_parm(pDummy);
				}
				Free(TBL_var[0]);
			}
			Free(TBL_var);
			pVarIndex[ix] = NULL;
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_scope(opt,proc,varnam,vnlen,pprocW)
char     opt;
ProcCT  *proc;
char    *varnam;
int      vnlen;
ProcCT  **pprocW;
{
	ProcCT	*procW;
	char *path0,*path;
	int ParmNo,len,len0;
/*
printf("cl_gx_chk_scope: *** opt=%c varnam=[%s]\n",opt,strname(varnam,vnlen));
printf("cl_gx_chk_scope: proc->pha_vnam=%08x\n",proc->pha_vnam);
*/
	if ((ParmNo=cl_gx_chk_vnam(opt,proc->pha_vnam,varnam,vnlen)) > 0) *pprocW = proc;
	else if (!ParmNo && (giOptions[7] & 0x02)) {
		path = proc->ProcPath;
/*
printf("cl_gx_chk_scope: path=[%s]\n",path);
*/
		if ((len=akxnrskipto(path,strlen(path),".")) <= 0) return 0;
		procW = proc;
		while (procW = procW->prePCT) {
			path0 = procW->ProcPath;
			if (path0 = procW->ProcPath) {
				len0 = strlen(path0);
/*
printf("cl_gx_chk_scope: path0=[%s] len0=%d\n",path0,len0);
*/
				if (len0 <= len) {
					if (!memcmp(path,path0,len0)) {
						if ((ParmNo=cl_gx_chk_vnam(opt,procW->pha_vnam,varnam,vnlen)) > 0) {
							*pprocW = procW;
/*
printf("cl_gx_chk_scope: found ParmNo=%d in path0=[%s]\n",ParmNo,path0);
*/
							break;
						}
						else if (ParmNo < 0) return ParmNo;
					}
				}
			}
			else {
				/* cl_gx_chk_scope:W: %s�̏�ʂ�ProcPath��NULL��proc������܂��B */
				ERROROUT1(FORMAT(325),path);
			}
		}
	}
	return ParmNo;
}
