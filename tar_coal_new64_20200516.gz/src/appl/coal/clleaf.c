static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       leaf      *cl_make_leaf                 */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out                                     */
/*              Normal                           */
/*                  leaf  *RootLeaf              */
/*              AbNormal   NULL                  */
/* --------------------------------------------- */
/*  Function :                                   */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

extern condList  CLcList;  /* ��񃊃X�g */
extern tableRoot CLtbl;   /* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */

Leaf      *AddressRoot;
/*********************************************/
/*                                           */
/*********************************************/
int cl_make_leaf()
{
	Leaf  *Dummy;
	char *p;
	int len,i;

	len = sizeof(Leaf) + sizeof(CMDObject) +
	     (sizeof(parmList *)/*+sizeof(GXObject *)*/)*(CLcList.cmd.prmnum+2);
	p = Malloc(len);
	if (p == NULL) return SysError;
	Dummy = (Leaf *)p;
	memset(p,0,sizeof(Leaf));
	p += sizeof(Leaf);
	Dummy->cmd.cmdobj = (CMDObject *)p;
	memset(p,0,sizeof(CMDObject));
	p += sizeof(CMDObject);
	Dummy->cmd.prmp = (parmList **)p;
/*	len = sizeof(parmList *)*(CLcList.cmd.prmnum+2);
	p += len;
	Dummy->cmd.bxobj = (GXObject **)p;
	memset(Dummy->cmd.bxobj,0,len);	*/
	cl_copy_cmd(&Dummy->cmd,&CLcList.cmd);
	memcpy(Dummy->cmd.prmp,
	       CLcList.cmd.prmp,sizeof(parmList *)*(CLcList.cmd.prmnum+1));
	Dummy->cmd.prmp[CLcList.cmd.prmnum+1] = NULL;
/*
for (i=0;i<CLcList.cmd.prmnum;i++) printf("leaf: prmp[%d]=[%s]\n",i,CLcList.cmd.prmp[i]->prp);
for (i=0;i<Dummy->cmd.prmnum;i++) printf("leaf: prmp[%d]=[%s]\n",i,Dummy->cmd.prmp[i]->prp);
*/
#if 1
	Dummy->cmd.parl = CLcList.cmd.parl;
	Dummy->cmd.parnum = CLcList.cmd.parnum;
/*	CLcList.cmd.parl = NULL;	*/
	CLcList.cmd.parnum = 0;
#ifdef SET_CMD_NAME
	CLcList.cmd.parl[2].par = NULL;
#endif
#endif
	Dummy->cmd.cmdobj->cid = Dummy->cmd.cid;
/*
printf("cl_make_leaf:Dummy->cmd.bxobj[0]=%08x\n",Dummy->cmd.bxobj[0]);
*/
/*
	Dummy->preleaf   = NULL;
	Dummy->rightleaf = NULL;
	Dummy->leftleaf  = NULL;
	Dummy->pFlag = 0;
	Dummy->cmdtag = 0;
	Dummy->pad[0] = 0;
	Dummy->pad[1] = 0;
	Dummy->type = 0;
*/
	AddressRoot = Dummy;
	return( NormalEnd );
}

/************************************/
/* _make_node_leaf					*/
/************************************/
static Leaf *_make_leaf(cno)
int cno;
{
	Leaf *Dummy;
	Leaf *leaf;
	char *p;
	int len,i;

	len = sizeof(Leaf) + sizeof(CMDObject) + sizeof(parmList *) + sizeof(ParList)*MAX_PARL;
	p = Malloc(len);
	if (p == NULL) return NULL;
	memset(p,0,len);
	Dummy = (Leaf *)p;
	Dummy->cmd.cid = cno;
	p += sizeof(Leaf);
	Dummy->cmd.cmdobj = (CMDObject *)p;
	p += sizeof(CMDObject);
	Dummy->cmd.prmp = (parmList **)p;
	Dummy->cmd.prmp[0] = NULL;
	p += sizeof(parmList *);
	Dummy->cmd.parl = (ParList *)p;
	Dummy->cmd.parnum = MAX_PARL;
	Dummy->cmd.cmdobj->cid = Dummy->cmd.cid;
/*
printf("_make_leaf: cid=%08x\n",Dummy->cmd.cid);
*/
	return Dummy;
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_push                      */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     �n���ꂽ���[�t���X�^�b�N�ɐς݁A          */
/*       �����P�[�W���쐬����B                  */
/*************************************************/
int cl_push()
{
	if (!AddressRoot) return -1;
	if (CLSTCB.TopStack) {
		CLSTCB.TopStack->rightleaf = AddressRoot;
		AddressRoot->preleaf = CLSTCB.TopStack;
	}
	else {
		CLSTCB.TopTree = AddressRoot;
		CLSTCB.DefTopStack = NULL;
	}
	CLSTCB.TopStack = AddressRoot;
	CLSTCB.StackCounter++;
	return 0;
}

int cl_pushd()
{
	Leaf *leaf,*Dummy;

	if (!AddressRoot) return -1;
	if (CLSTCB.TopStack) {
		if (CLSTCB.TopTree->cmd.cid != C_NODE_DEFINE) {
			leaf = _make_leaf(C_NODE_DEFINE);
			leaf->rightleaf = CLSTCB.TopTree;
			CLSTCB.TopTree->preleaf = leaf;
			CLSTCB.TopTree = leaf;
		/*	CLSTCB.TopStack = leaf;	*/
			leaf->leftleaf = AddressRoot;
			CLSTCB.DefTopStack = AddressRoot;
		}
		else {
			CLSTCB.DefTopStack->rightleaf = AddressRoot;
			AddressRoot->preleaf = CLSTCB.DefTopStack;
		}
	}
	else {
		leaf = _make_leaf(C_NODE_DEFINE);
		CLSTCB.TopTree = leaf;
		leaf->leftleaf = AddressRoot;
		CLSTCB.TopStack = leaf;
	}
	CLSTCB.DefTopStack = AddressRoot;
	return 0;
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_change_tree               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     �n���ꂽ���[�t�̃����P�[�W���č쐬����B  */
/* --------------------------------------------- */
/*************************************************/
int cl_change_tree( leaf )
Leaf  *leaf;
{
	int rc,LeafCount;

	rc = LeafCount = 0;
	CLSTCB.TopStack = leaf;
	leaf->cmd.type = 0;
	if (leaf->rightleaf == (Leaf *)NULL) goto End;
	else {
		leaf->leftleaf = leaf->rightleaf;
		leaf->rightleaf = (Leaf *)NULL;
		leaf = leaf->leftleaf;
		for(;;) {
			LeafCount++;
			if (leaf->rightleaf == (Leaf *)NULL) break;
			leaf = leaf->rightleaf;
		}
	}
	CLSTCB.StackCounter -= LeafCount;
	return 0;
 End:
	return -1;
}

/************************************/
/* cl_make_node_leaf				*/
/************************************/
Leaf *cl_make_node_leaf(pConstCt, cno, name)
ConstantCt *pConstCt;
int  cno;
char *name;
{
	int len;
	parmList *lp;
	Leaf     *leafw;

	leafw = (Leaf *)Malloc(len=sizeof(Leaf)+sizeof(parmList *));
	if (!leafw) return NULL;

	memset(leafw,0,len);
	lp = (parmList *)cl_const_ct_malloc(pConstCt,
	                                 sizeof(parmList)+strlen(name)+1);
	if (!lp) {
		Free(leafw);
		return NULL;
	}
	memset(lp,0,sizeof(parmList));
    lp->prmlen = len;
    lp->prp = (char *)(lp+1);
	strcpy(lp->prp,name);
	leafw->cmd.cid    = cno;
	leafw->cmd.prmp   = (parmList **)(leafw+1);
	leafw->cmd.prmp[0]= lp;
	leafw->cmd.prmnum = 1;
#if 1
	if (!(leafw->cmd.parl=(ParList *)cl_const_ct_malloc(pConstCt,sizeof(ParList)*MAX_PARL))) {
		Free(leafw);
		return NULL;
	}
	leafw->cmd.parnum = MAX_PARL;
	memset(leafw->cmd.parl,0,sizeof(ParList)*leafw->cmd.parnum);
#endif
	return leafw;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_make_push_leaf()
{
	int rc;

	if (!(rc=cl_make_leaf())) {
		cl_pre_nest();
		if (!(rc=cl_push())) rc= cl_change_stcb();
	}
	return rc;
}

/**************************************************************/
/* search_top_leaf                                            */
/* function; Search Top Leaf                                  */
/**************************************************************/
Leaf *search_top_leaf ()
{
	Leaf *Dummy;

	if (Dummy = CLSTCB.TopStack) {
#if 1
		Dummy = CLSTCB.TopTree;
#else
		for (;;) {
			if (!Dummy->preleaf) break;
			Dummy = Dummy->preleaf;
		}
#endif
	}
	return Dummy;
}
