static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************
*																		*
*	�����ړI�@�@�FIS  ���Z����											*
*																		*
*	�֐����@	�Fint cl_cmpt_is(pAns , pOprtr , nparm,ppParm)			*
*					(O)int		*pAns									*
*					(I)char  	*pOprtr									*
*					(I)int		nparm									*
*					(I)tdtInfoParm *pppParm[]							*
*																		*
*	�߂�l�@�@�@�FERROR									�@				*
*				  NORMAL												*
*																		*
*	�����T�v�@�@�F�@													*
*																		*
*************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable,*pCLprocTable;

int cl_cmpt_is(pAns,pOprtr,nparm,ppParm,ope,opt)
int  *pAns;
char *pOprtr;
int nparm,ope,opt;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1;
	tdtInfoParm *pInfoParm2;
	int  rc,len1,len2,i,attr;
	char *p1,*p2,c,w1[16],c2;

	*pAns = 0;
	rc = NORMAL;
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			pInfoParm2 = ppParm[2];
			if (nparm > 3) {
				if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
					pInfoParm2 = ppParm[3];
				}
			}
		}
	}
	len2 = pInfoParm2->pi_dlen;
	p2   = pInfoParm2->pi_data;
	if (pInfoParm2->pi_attr != DEF_ZOK_CHAR /*|| len2==0*/) {
		/* cl_cmpt_is:�p�����[�^�Q�̌^�������Ă��܂���B */
		ERROROUT1(FORMAT(251),"cl_cmpt_is");
		return ECL_SCRIPT_ERROR;
	}
	pInfoParm1 = ppParm[0];
	attr = pInfoParm1->pi_attr;
	c2 = toupper(*p2);
	if (c2=='N' || c2=='D' || c2=='F') {
		if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_FLOA || attr==DEF_ZOK_DECI) {
			if (attr == DEF_ZOK_BINA) *pAns = 1;
			else if (attr == DEF_ZOK_FLOA) *pAns = 2;
			else *pAns = 3;
			return 0;
		}
	}
	else if (c2=='X' && attr==DEF_ZOK_BULK) {
		*pAns = 1;
		return 0;
	}
	else if (c2=='T') {	/*** Type ***/
		*pAns = attr;
		return 0;
	}
	else if (c2=='I') {	/*** DataID ***/
		*pAns = (uchar)pInfoParm1->pi_id;
		return 0;
	}
	len1 = pInfoParm1->pi_dlen;
	p1   = pInfoParm1->pi_data;
/*
	p1 = w1;
	if ((len1 = parm_to_char(pInfoParm1,&p1,NULL))<0) {
		return ECL_SCRIPT_ERROR;
	}
*/
	if (nparm > 2) {
		if ((rc=cl_get_str_pos(nparm,ppParm,0,&p1,&len1,NULL,NULL,"")) < 0) return rc;
	}
	switch (c2) {
		case 'L':	/*** Length ***/
				if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
				else if (toupper(*(p2+1))!='B' && (pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX))
					len1 = akxqmlen(p1,len1);
				*pAns = len1;
				break;
		case 'N':	/*** Numeric || Number ***/
		case 'D':	/*** Decimal ***/
		case 'F':	/*** FLOAT ***/
				if (len1>0) {
					if ((i=akxnskipin(p1,len1," \t")) < len1) {
						p1 += i;
						len1 = akxnrskipin(p1,len1-i," \t");
						if ((c=*p1)=='+' || c=='-') {
							p1++;
							len1--;
						}
						if ((i=cl_chk_digit_n(p1,len1)) >= 0) *pAns = i+1;
					}
				}
				break;
		case 'B':	/*** Blank ***/
		case 'S':	/*** Space ***/
				if (len1>0) {
					if (akxnskipin(p1,len1," \t") >= len1) *pAns = 1;
				}
				break;
		case 'X':	/*** hex ***/
				if (len1>0) {
					*pAns = 1;
					for (i=0;i<len1;i++) {
						if (((c=*p1++)==' ')||(c=='+')||(c=='-')||(c=='.')||
						    (c>='0'&&c<='9')||
						    (c>='A'&&c<='F')||(c>='a'&&c<='f'))
							;
						else break;
					}
				}
				break;
		case 'Z':	/*** Zenkaku ***/
		case 'H':	/*** Hankaku ***/
				i = akxqiskanji(p1);
				if (c2 == 'H') i = i ? 0 : 1;
				*pAns = i;
				break;
		case 'A':	/*** Ank ***/
				*pAns = akxqisank(*p1);
				break;
		case 'M':	/*** Moji byte ***/
				i = akxqiskanji(p1);
				if (!i) i = 1;
				*pAns = i;
				break;
		default:
			/* cl_cmpt_is:�p�����[�^�Q�Ɍ�肪����܂��B */
			ERROROUT(FORMAT(252));
		 	rc = ECL_SCRIPT_ERROR;
	}

	return rc;
}

int cl_lenm(pAns,mflg,nparm,ppParm)
int  *pAns;
int  mflg,nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1;
	int len1,attr;

	pInfoParm1 = ppParm[0];
	if (pInfoParm1->pi_id == ' ') {
		len1 = pInfoParm1->pi_dlen;
		attr = pInfoParm1->pi_attr;
		if (attr==DEF_ZOK_CHAR && mflg) {
			len1 = akxqmlen(pInfoParm1->pi_data,len1);
		}
		else if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
	}
	else len1 = sizeof(tdtInfoParm);
	*pAns = len1;
	return 0;
}
