static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int        cl_er_lk_scr_pr_ct           */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*   �n���ꂽ�X�N���v�g�e�[�u���������P�[�W����  */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"          /* �萔��` */

extern CLPRTBL *pCLprocTable;

int cl_er_lk_scr_pr_ct()
{
	ScrPrCT  *Dummy;

	if (!pCLprocTable->PrCTp) return SysError;

	Dummy = pCLprocTable->PrCTp;
	if (Dummy == NULL) return -2;
	for(;;) {
	 	if (Dummy->nextScCT == NULL) {
			akxs_xhasl(pCLprocTable->pha_gid,'D',Dummy->ScrGid,0);
			if (Dummy->preScCT == NULL) {
/*			   Free(pCLprocTable->PrCTp);
			   pCLprocTable->PrCTp = NULL;
printf(" ******** PrCTp Clear ********\n");
printf("cl_er_lk_scr_pr_ct: return(-2)\n");
*/
				pCLprocTable->CurScr = NULL;
				return -2;
			}
			Dummy = Dummy->preScCT;
		/*	Free(Dummy->nextScCT); */
		/*	cl_lru_scr_era(Dummy->nextScCT->pId); */
			cl_scr_clear(Dummy->nextScCT);
/*
printf("cl_er_lk_scr_pr_ct: cl_scr_clear(%x)\n",Dummy->nextScCT);
*/
			Dummy->nextScCT = NULL;
			break;
		}
		Dummy = Dummy->nextScCT;
	}
	pCLprocTable->CurScr = Dummy;
	pCLprocTable->CurProc = Dummy->CurProc;

	return NormalEnd;
}
