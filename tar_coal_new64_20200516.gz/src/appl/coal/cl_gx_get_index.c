static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �ϐ���INDEX�����߂�                                    *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_get_index( pparmList )                       *
*                      parmList  *pparmList                                   *
*                                                                             *
*      �߂�l�@�@�@�F�@ <0 : ERROR                              �@            *
*                      >=0 : NORMAL                                           *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern GlobalCt  *pGlobTable;
extern int giOptions[];

static int _check_index(vname,vnlen,varnam)
char *vname,*varnam;
int  vnlen;
{
	char tmp[Var_NM_MAX*2+1],c,*p;
	int index=0;

DEBUGOUTL1(250,"--->_check_index: vname=[%s]",vname);

/*	if ((c=*vname)=='.' || c=='+' || c=='-' || (c>='0' && c<='9')) {	*/
	if ((c=*vname)=='+' || c=='-' || (c>='0' && c<='9')) {
		if (akxccvn(10,vname,vnlen,&index)) {
		/*	if (!(pGlobTable->options[1] & 0x02)) {	*/
				memnzcpy(tmp,vname,vnlen,sizeof(tmp)-1);
				ERROROUT2(FORMAT(216),tmp,"no digit");	/* Index(%s) %s */
				return ERROR;
		/*	}	*/
		}
		else return index;
	}
	index = 0;
	if (vnlen > Var_NM_MAX) {
		p = "name is longer";
		index = ERROR;
	}
	else if (cl_chk_name(vname,vnlen)) {
		p = "not name char";
		index = ERROR;
	}
	else {
		memnzcpy(varnam,vname,vnlen,Var_NM_MAX);
	}
	if (index < 0) {
		memnzcpy(tmp,vname,vnlen,sizeof(tmp)-1);
		ERROROUT2(FORMAT(216),tmp,p);	/* Index(%s) %s */
	}
	return index;
}

int cl_gx_get_index(pparmList, varnam)
parmList  *pparmList;
char *varnam;
{
	return cl_gx_get_index_array(pparmList,varnam,NULL,0);
}

int cl_gx_get_index_array(pparmList, varnam, ppArrayInfo,iOpt)
parmList  *pparmList;
char *varnam;
tdtInfoParm **ppArrayInfo;
int  iOpt;
{
	static char *_fn_="cl_gx_get_index_array: ";
	int		rc,index,vnlen,iParm[4];
	char	*vname,c;
	tdtInfoParm InfoParm,*pInfo;
	parmList  plw;

	if (ppArrayInfo) *ppArrayInfo = NULL;
#if 1
	vname = pparmList->prp;
	vnlen = pparmList->prmlen;

DEBUGOUTL3(250,"--->%spparmList->prp=[%s] ppArrayInfo=%08x",_fn_,vname,ppArrayInfo);

	if ((c=vname[0])=='$' || c=='%' || c=='#') ;
	else {
		memnzcpy(varnam,vname,vnlen,Var_NM_MAX);
		return 0;
	}
#endif
	vnlen = pparmList->prmlen-1;
	vname = pparmList->prp+1;
	if (vnlen>2 && vname[0]=='{' && vname[vnlen-1]=='}') {
		vnlen -= 2;
		vname++;
	}
	*varnam = '\0';
	if ((c=vname[0])=='$' || c=='%' || c=='#') {
		plw.prmlen = vnlen;
		plw.prp    = vname;
		rc=cl_conv_parm_opt(&plw,&InfoParm,iOpt & D_GX_OPT_NOEROUT_NDEF);

DEBUGOUT_InfoParm5(194,"%scl_conv_parm rc=%d ppArrayInfo=%08x",
&InfoParm,_fn_,rc,ppArrayInfo,0,0);

		if (rc) {
			if (ppArrayInfo && rc==ECL_DEFINED_ARRAY) {
				if (pInfo=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))) {
					memcpy(pInfo,&InfoParm,sizeof(tdtInfoParm));
					pInfo->pi_scale |= D_DATA_ARRAY_INDEX;	/* 0x10 */
					*ppArrayInfo = pInfo;
				}
				else {
					ERROROUT1(FORMAT(217),_fn_);	/* %sArrayInfo area malloc. */
					rc = ECL_SYSTEM_ERROR;
				}
			}
			return rc;
		}
		pInfo = &InfoParm;
		if (rc=cl_check_data_id(pInfo,0)) return rc+ECL_CHK_VAR_ERROR;
		if (pInfo->pi_id == D_DATA_ID_STOREVAR) {
			pInfo = (tdtInfoParm *)pInfo->pi_pos;
			if (rc=cl_check_data_id(pInfo,0)) return rc+ECL_CHK_VAR_ERROR;
		}
		if (pInfo->pi_attr == DEF_ZOK_CHAR) {
			index = _check_index(pInfo->pi_data,pInfo->pi_dlen,varnam);
		}
		else if (rc = cl_get_parm_bin(pInfo,&index,"cl_gx_get_index_array: ")) {
			iParm[0] = pInfo->pi_attr;
			iParm[1] = iParm[2] = iParm[3] = 0;
			ERROROUT2(FORMAT(218),_fn_,cl_get_attr_name(iParm));	/* %sINDEX�̌^[%s]�������Ă��܂���B */
			return ERROR;
		}
	/* 2001.1.4 Koba
	*	if (InfoParm.pi_scale & 0x80) Free(InfoParm.pi_data);
	*/
	}
	else {
		index = _check_index(vname,vnlen,varnam);
	}
	return index;
}
