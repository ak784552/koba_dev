static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ���Z�q�`�F�b�N����                    �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_chk_opt( pOperator )                         *
*                      (I)Char     *pOperator                                 *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;
extern char *cl_opt_malloc();

int cl_gx_chk_opt(pOperator,ex_opt)
char *pOperator;
int  ex_opt;
{
	int  rc,parm[5],len,opt;
	char c;

/*	rc = ERROR;	*/
	opt = 1;
	if (ex_opt & D_GX_OPT_PROC_NAME) opt |= 2;
	if      (rc = cl_gx_is_operator(pOperator,MATH)) ;
	else if (rc = cl_gx_is_operator(pOperator,COMP)) ;
	else if (rc = cl_gx_is_operator(pOperator,LOGICAL)) ;
	else if (cl_get_func_name(pOperator,parm)) rc = parm[2];
	else {
		len = strlen(pOperator);
		c = *pOperator;
#if 1	/* 2020.3.17 */
		if ((c>='A' && c<='Z') || (c>='a' && c<='z')) {
			if (cl_chk_sysvar_name(pOperator,len)) rc = SYSVAR;
		}
		if (!rc) {
			if (!cl_chk_name_opt(pOperator,len,opt)) rc = NAME_CONST /*VAR or FUNCTION*/;
		}
#else
		if ((c>='A' && c<='Z') || (c>='a' && c<='z') || (c=='_') ||
		    (len>=2 && akxqiskanji(pOperator))) {
			if (cl_chk_sysvar_name(pOperator,len)) rc = SYSVAR;
			else if (!cl_chk_name_opt(pOperator,len,opt)) rc = NAME_CONST /*VAR or FUNCTION*/;
		}
#endif
	}
/*
printf("cl_gx_chk_opt: pOperator=[%s] rc=%d\n",pOperator,rc);
*/
	return rc;
}

int cl_im_mman_init(mcat,id,extlen,maxcnt,im)
MCAT *mcat;
char *id;
int  extlen,maxcnt,im;
{
	if (!mcat) return -1;
	memset(mcat,0,sizeof(MCAT));
	mcat->mc_id[0] = *id;
	mcat->mc_extlen = extlen;
	mcat->mc_maxcnt = maxcnt;
	if (im<0 || im>4) return -2;
	mcat->mc_id[1] = im;
	return 0;
}

int cl_im_mcat(mcat,s,len)
MCAT *mcat;
char *s;
int len;
{
	return akxtmmanfunc(2,mcat,s,len,cl_opt_malloc);
}

int cl_im_mcatz(mcat,s,len)
MCAT *mcat;
char *s;
int len;
{
	akxtmmanfunc(2,mcat,s,len,cl_opt_malloc);
	akxtmmanfunc(2,mcat,"",1,cl_opt_malloc);
	return --mcat->mc_ipos;
}
