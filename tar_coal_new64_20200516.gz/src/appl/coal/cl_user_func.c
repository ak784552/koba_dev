static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	�@�\�@�F																*
*																			*
*	���́@�F�@int cl_user_func(pLeaf, name)									*
*	�����@�F�@(IN    ) Leaf	*pLeaf											*
*			�@(IN    ) char	*name											*
*																			*
*	�ߒl�@�F�@ERROR															*
*			�@NORMAL														*
*	�쐬�@�F																*
*	�X�V�@�F																*
*																			*
*****************************************************************************/
#include <colmn.h>

#define DEBUGP(x)

extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];

static int _print_info();
static int _print_info_data();
static void _print_list();

#define MAX_FLGS	MAX_PRINT_FLGS

#define PRN_OPT_QUOT	0x0001	/* "string" */
#define PRN_OPT_DCMA	0x0002	/* output ',' delimiter */
#define PRN_OPT_NAME	0x0004	/* output 'name=' */
#define PRN_OPT_HEXO	0x0008	/* %08x for int val */
#define PRN_OPT_ERRO	0x0010	/* use ERROROUT() to output */
#define PRN_OPT_DUMP	0x0020	/* dump mode */
#define PRN_OPT_MCMA	0x0040	/* output money ',' */
#define PRN_OPT_UMCA	0x0080	/* use PRN_OPT_MCMA */
#define PRN_OPT_INFO	0x0100	/* output info */
#define PRN_OPT_EXPF	0x0200	/* display exp format */
#define PRN_OPT_NEXF	0x0400	/* display not exp format */
#define PRN_OPT_EXPZ	0x0800	/* display exp zero suppress */
#define PRN_OPT_EXPN	0x1000	/* display exp zero not suppress */
#define PRN_OPT_TABS	0x2000	/* output delimiter Tab insted of ' ' */

#define q_flg	(flgs[0] & PRN_OPT_QUOT)	/* "string" */
#define c_flg	(flgs[0] & PRN_OPT_DCMA)	/* output ',' */
#define n_flg	(flgs[0] & PRN_OPT_NAME)	/* output 'name=' */
#define x_flg	(flgs[0] & PRN_OPT_HEXO)	/* %08x for int val */
#define e_flg	(flgs[0] & PRN_OPT_ERRO)	/* output ERROROUT() */
#define d_flg	(flgs[0] & PRN_OPT_DUMP)	/* dump mode */
/*		m_flg	*/							/* output money ',' */
#define i_flg	(flgs[0] & PRN_OPT_INFO)	/* output info */
#define p_flg	(flgs[0] & PRN_OPT_EXPF)	/* display exp */
#define np_flg	(flgs[0] & PRN_OPT_NEXF)	/* display not exp */
#define pz_flg	(flgs[0] & PRN_OPT_EXPZ)	/* display exp zero suppress */
#define pn_flg	(flgs[0] & PRN_OPT_EXPN)	/* display exp not zero suppress */
#define t_flg	(flgs[0] & PRN_OPT_TABS)	/* output delimiter Tab insted of ' ' */

#define exp_pre	flgs[1]
#define exp_inx	flgs[2]

/********************************************/
/*											*/
/********************************************/
int cl_user_func(pLeaf, proc, name )
Leaf *pLeaf;
ProcCT  *proc;
char *name;
{
	int rc;
	parmList  *pparmList;
	tdtInfoParm InfoParm;
	char dummy[256];
	ProcCT  *procct;

DEBUGOUTL1(190,"cl_user_func:start.[%s]",name);
	if (!stricmp(name,"UserFunc")) {
		if (pLeaf->cmd.prmnum > 3) {
			pparmList = pLeaf->cmd.prmp[2];
			if (rc=cl_arg_to_char(pparmList,proc->Obj,&InfoParm,"UserFunc proc")) return rc;
			strnzcpy(dummy,InfoParm.pi_data,sizeof(dummy)-1);
		}
		else {
			ERROROUT("cl_user_func:no proc name");
			return (ECL_EX_EXEC);
		}
	}
	else strnzcpy(dummy,name,sizeof(dummy)-1);

DEBUGOUTL1(190,"cl_user_func:dummy=[%s]",dummy);
	if (!stricmp(dummy,"print") || !stricmp(dummy,"DT")) {
		cl_print_text(&pLeaf->cmd.prmp[3],proc->Obj,
		              pLeaf->cmd.prmnum-3,"Print: ");
	}
	else {
		ERROROUT("cl_user_func:undeifinition proc.");
		return (ECL_EX_EXEC);
	}
	if (!strcmp(name,"UserFunc")) {
		if (!(procct = cl_search_proc_ct())) return (ECL_SYSTEM_ERROR);
		cmn_set_stat(RET_PR,&procct->ptype,L_ON);
	}
	return NORMAL;
}

/********************************************/
/*											*/
/********************************************/
static void _set_flag_sub(p,flgs)
char *p;
int flgs[];
{
	char c,c1,w[2];
	int i,print_opt,opt,iset;
/*
printf("\n_set_flag_sub: *p=[%s]\n",p);
*/
	p++;
	c = *p++;
	c1 = *p;
	print_opt = flgs[0];
	iset = 0;
	if (c == 'm') {
		if (c1 == '-') iset = -1;
		else if (c1 == '+') iset = 1;
		if (iset) {
			print_opt |= PRN_OPT_UMCA;
			if (iset > 0)
				print_opt |= PRN_OPT_MCMA;
			else
				print_opt &= ~PRN_OPT_MCMA;
		}
		else
			print_opt &= ~(PRN_OPT_UMCA | PRN_OPT_MCMA);
	}
	else {
		if (c1 == '-') iset = -1;
		else iset = 1;
		w[0] = c;
		w[1] = '\0';
		i = akxs_in_str_opt("qcnxedm,ip   t",w,0);
		if (i >0) {
			opt = 1;
			if (i > 1) opt = 1<<(i-1);
			if (iset > 0) print_opt |= opt;
			else print_opt &= ~opt;
		}
	}
/*
printf("_set_flag_sub: i=%d print_opt=%08x\n",i,print_opt);
*/
	flgs[0] = print_opt;
}

/********************************************/
/*	/p[+|-][pre][Z|N|R][,[inx[R]]]			*/
/********************************************/
static void _set_flag(p,len,flgs)
char *p;
int len,flgs[];
{
	char c,c1,*pp,w[4];
	int i,is,ie,n,pos,nlen;

	w[0] = '/';
	w[3] = '\0';
	p++;
	len--;
	n = 0;
	pp = p;
	while (len >= 0) {
/*
printf("_set_flag: len=%d p=[%s]\n",len,p);
*/
		c = *p++;
		len--;
/*
printf("_set_flag:1 len=%d c=[%c]\n",len,c);
*/
		if (c=='+' || c=='-' || !c) {
			w[2] = c;
			while (n-- > 0) {
				w[1] = *pp++;
				_set_flag_sub(w,flgs);
			}
			if (!c) break;
			n = 0;
			pp = p;
		}
		else if (c == 'p') {
/*
printf("_set_flag:2 len=%d c=[%c]\n",len,*p);
*/
			if ((c=*p)=='+' || c=='-') {
				p++;
				len--;
				if (c == '+') {
					flgs[0] |= PRN_OPT_EXPF;
					flgs[0] &= ~PRN_OPT_NEXF;
				}
				else {
					flgs[0] |= PRN_OPT_NEXF;
					flgs[0] &= ~PRN_OPT_EXPF;
				}
			}
/*
printf("_set_flag:3 len=%d c=[%c]\n",len,*p);
*/
			c = akxcupper(*p);
			if (c>='0' && c<='9') {
				pos = akxccvn2(10,p,len,&exp_pre,&nlen);
/*
printf("_set_flag:akxccvn2 1: pos=%d nlen=%d p=[%s]\n",pos,nlen,p);
*/
				if (pos < 0) break;
				if (exp_pre > NMPA10) exp_pre = NMPA10;
				p += nlen;
				len -= nlen;
				c = akxcupper(*p);
			}
			if (c=='Z' || c=='N' || c=='R') {
				if (c == 'Z') {
					flgs[0] |= PRN_OPT_EXPZ;
					flgs[0] &= ~PRN_OPT_EXPN;
				}
				else if (c == 'N') {
					flgs[0] |= PRN_OPT_EXPN;
					flgs[0] &= ~PRN_OPT_EXPZ;
				}
				else exp_pre = -1;
				p++;
				len--;
				c = *p;
			}
			if (c == ',') {
				p++;
				len--;
				c = akxcupper(*p);
				if (c>='0' && c<='9') {
					pos = akxccvn2(10,p,len,&exp_inx,&nlen);
/*
printf("_set_flag:akxccvn2 2: pos=%d nlen=%d p=[%s]\n",pos,nlen,p);
*/
					if (pos < 0) break;
					if (exp_inx > 5) exp_inx = 5;
					p += nlen;
					len -= nlen;
					c = akxcupper(*p);
				}
				if (c == 'R') {
					exp_inx = -1;
					p++;
					len--;
					c = *p;
				}
				if (c && c!=' ') break;
			}
/*
printf("_set_flag: flgs[0]=%08x exp_pre=%d  exp_inx=%d\n",flgs[0],exp_pre,exp_inx);
*/
			pp = p;
		}
		else n++;
	}
/*
printf("_set_flag: flgs=%08x %d %d\n",flgs[0],flgs[1],flgs[2]);
*/
}

/********************************************/
/*											*/
/********************************************/
static int _do_print_name(line,line_len)
char *line;
int  line_len;
{
	char buf[256],c;
	int ret,rc,n,iParm[3],n0;
	SSPL_S ssp;
/*
printf("_do_print_name:Enter line_len=%d line=[%s]\n",line_len,line);
*/
	ssp.sp = 0;
	ssp.wd = buf;
	ssp.wdmax = sizeof(buf);
	n0 = ret = 0;
	while (!ret) {
#if 1
		n = cmpgwnsl(line,line_len,&ssp);
/*
printf("_do_print_name: n0=%d n=%d wd=[%s]\n",n0,n,ssp.wd);
*/
		if (n <= 0) break;
		if (n <= 100) {		/* �L�� */
			if ((n0<=8 || n0==98) && (n==24 || n==25)) ;	/* �P�����Z�q(+-) */
#if 1
			else ret = 1;
#else
			else if (n>8 && n!=98) ret = 1;	/* ()[]{},�ȊO*/
#endif
		}
		else if (n>=5000 && n<6000) {	/* �萔 */
			if ((c=*ssp.wd)=='\'' || c=='"') ;
			else {
				rc = akxqnumber(ssp.wd,n,0,iParm);
/*
printf("_do_print_name: rc=%d\n",rc);
*/
				if (rc < 2) ret = 1;
			}
		}
		else ret = 1;
		n0 = n;
#else
		n = cmpgtwdx(line,line_len,&ssp);
		if (n <= 0) break;
		rc = ssp.attr[0];
/*
printf("_do_print_name: atr=%d n=%d wd=[%s]\n",rc,n,ssp.wd);
*/
		if (rc==5 || rc==6) ;
		else if (akxnskipin(ssp.wd,n,"()[]{},") < n) {
			rc = akxqnumber(ssp.wd,n,0,iParm);
/*
printf("_do_print_name: rc=%d\n",rc);
*/
			if (rc < 2) ret = 1;
		}
#endif
	}
/*
printf("_do_print_name:Exit ret=%d\n",ret);
*/
	return ret;
}

/********************************************/
/*	opt : 0x01 :=0 "," or " " or TAB		*/
/*				=1 "," + (" " or TAB)		*/
/*		  0x02 :=1 Ignore c_flg				*/
/*		  0x04 :=1 Ignore t_flg				*/
/********************************************/
static void _print_dlm(mcat,flgs,opt)
MCAT *mcat;
int flgs[],opt;
{
	char dlm[3],*p;
	int ic_flg,it_flg;

	ic_flg = c_flg;
	it_flg = t_flg;
	if (opt & 0x02) ic_flg = 0;
	if (opt & 0x04) it_flg = 0;
	p = dlm;
	if (ic_flg) *p++ = ',';
	if (!ic_flg || (opt & 0x01)) {
		if (!(opt & 0x01)) p = dlm;
		if (it_flg) *p = '\t';
		else *p = ' ';
		p++;
	}
	*p = '\0';
	akxtmcats(mcat,dlm);
}

/********************************************/
/*											*/
/********************************************/
char *cl_get_attr_name(iParm)
int  iParm[];
{
	static char *name[]={"variant","char","int","double","dec","bulk","date","variant",""};
	static char dummy[30];
	int attr,size,pre,sca;
	char *p;

	attr = iParm[0];
	size = iParm[1];
	pre  = iParm[2];
	sca  = iParm[3];
	if (attr>=0 && attr<=7) p = name[attr];
	else p = "other";
	switch (attr) {
	case DEF_ZOK_CHAR:
	case DEF_ZOK_BULK:
		if (size > 0) {
			sprintf(dummy,"%s(%d)",p,size);
			p = dummy;
		}
		break;
	case DEF_ZOK_DECI:
		if (pre > 0) {
			sprintf(dummy,"dec(%d,%d)",pre,sca);
			p = dummy;
		}
		break;
	}
	return p;
}

/********************************************/
/*											*/
/********************************************/
static int _print_attr(mcat,pInfoParm,iParm)
MCAT *mcat;
tdtInfoParm *pInfoParm;
int  iParm[];
{
	int attr,size,pre,sca,iPm[4],*ipParm;

	if (pInfoParm) {
		iPm[0] = pInfoParm->pi_attr;
		if (pInfoParm->pi_aux[0])
			size = pInfoParm->pi_len;
		else size = pInfoParm->pi_dlen;
		iPm[1] = size;
		iPm[2] = pInfoParm->pi_hlen;
		iPm[3] = pInfoParm->pi_pos;
		ipParm = iPm;
	}
	else if (iParm) ipParm = iParm;
	akxtmcats(mcat,cl_get_attr_name(ipParm));
	return 0;
}

/********************************************/
/*											*/
/********************************************/
static int _print_data(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtInfoParm *pInfoParm;
int flgs[];
{
	int rc,i,Value,len,opt,pre,m_opt;
	double dValue,dw;
	char dummy[512],*p,id,*fmt,wrk[10];
	MPA *mpa;
	tdtInfoParm tInfoParm;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_data:",pInfoParm,0,0);

	if (cl_is_null_parm(pInfoParm)) return 0;

	len = pInfoParm->pi_dlen;
	p = pInfoParm->pi_data;
	switch (pInfoParm->pi_attr) {
	case DEF_ZOK_CHAR:
		if (x_flg && pInfoParm->pi_id==' ') {
			len = X_MIN((sizeof(dummy)-1)/2,len);
			akxcxtoc(p,len,dummy);
			akxtmcatz(mcat,dummy,len*2);
		}
		else {
			if (q_flg) akxtmcats(mcat,"\"");
			if (p) {
				len = akxstrnlen(p,len);
				akxtmcatz(mcat,p,len);
				if ((id=pInfoParm->pi_id)==D_DATA_ID_FUNCTION || id==D_DATA_ID_CLMETHOD
				 || id==D_DATA_ID_PROC)
					akxtmcats(mcat,"()");
			}
			if (q_flg) akxtmcats(mcat,"\"");
		}
		break;
	case DEF_ZOK_BINA:
		if (len) {
			Value = cl_get_data_long(pInfoParm);
			if (x_flg) fmt = "0x%08x";
			else fmt = "%d";
			sprintf(dummy,fmt,Value);
			akxtmcats(mcat,dummy);
		}
		else akxtmcats(mcat,"null");
		break;
	case DEF_ZOK_FLOA:
		if (len) {
			memcpy((char *)&dValue,p,sizeof(double));
			if (x_flg) {
				akxcxtoc(&dValue,sizeof(double),dummy);
				dummy[len*2] = '\0';
			}
			else {
				cl_double_to_str(dummy,sizeof(dummy),dValue);
			}
			akxtmcats(mcat,dummy);
		}
		else akxtmcats(mcat,"null");
		break;
	case DEF_ZOK_DECI:
		if (len > 0) {
			mpa = (MPA *)p;
			if (x_flg) {
				akxcxtoc(mpa,len,dummy);
				dummy[len*2] = '\0';
			}
			else {
#if 1
/*
printf("_print_data: options[10],[19]=%08x %08x\n",pGlobTable->options[10],pGlobTable->options[19]);
*/
				if (flgs[0] & PRN_OPT_UMCA) {
					if (flgs[0] & PRN_OPT_MCMA) m_opt = 1;
					else m_opt = -1;
				}
				else
					m_opt = pGlobTable->options[12] & 0x20;
				cl_mpa2an(mpa,dummy,sizeof(dummy),m_opt,pInfoParm->pi_hlen,pInfoParm->pi_pos);
#else
				opt = pGlobTable->options[10];
				if (opt & 0x40) {
					opt = (opt & 0x0f) | ((pGlobTable->options[11]<<4) & 0xf0);
					m_mpa2an_exp(mpa,dummy,sizeof(dummy),0,0,opt);
				}
				else {
					if (m_flg > 0) opt |= 0x20;
					else if (m_flg < 0) opt &= ~0x20;
					m_mpa2an(mpa,dummy,sizeof(dummy),opt);
				}
#endif
			}
			akxtmcats(mcat,dummy);
		}
		else akxtmcats(mcat,"null");
		break;
	case DEF_ZOK_DATE:
		if (len > 0) {
			mpa = (MPA *)p;
			if (x_flg) {
				akxcxtoc(mpa,len,dummy);
				dummy[len*2] = '\0';
				p = dummy;
			}
			else {
				m_mpa2an(mpa,dummy,sizeof(dummy),0);
				p = dummy + strlen(dummy) + 1;
				strcpy(p,"YYYY/MM/DD HH:MM:SS");
				memcpy(p,dummy,4);
				memcpy(p+5,dummy+4,2);
				memcpy(p+8,dummy+6,2);
				memcpy(p+11,dummy+8,2);
				memcpy(p+14,dummy+10,2);
				memcpy(p+17,dummy+12,2);
			}
		}
		else p = "null";
		akxtmcats(mcat,p);
		break;
	case DEF_ZOK_VARI:
		akxtmcats(mcat,"**VARI**");
		break;
	case 0:
		akxtmcats(mcat,"**undef**");
		break;
	case DEF_ZOK_BULK:
		akxtmcats(mcat,"**BULK**");
		if (len > 0) {
			if (len > 512) {
				len = 512;
				PRINTOUTL1(0,"BULK data too long len=%d",pInfoParm->pi_dlen);
			}
			akxaxdump("BULK",p,len);
			printf("\n");
		}
		break;
	default:
		akxtmcats(mcat,"**INVALID**");
		if (len > 0) {
			if (len > 512) {
				len = 512;
			}
			akxaxdump("INVALID",p,len);
			printf("\n");
		}
	}
	if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) {
		akxtmcats(mcat,"..");
		cl_gx_copy_info(&tInfoParm,pInfoParm);
		tInfoParm.pi_aux[0] = tInfoParm.pi_alen = 0;
		if (tInfoParm.pi_attr == DEF_ZOK_BINA) tInfoParm.pi_pos = tInfoParm.pi_hlen;
		else tInfoParm.pi_data += tInfoParm.pi_dlen;
		_print_data(mcat,&tInfoParm,flgs);
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
static int _print_info_array(mcat,pInfoParm,flgs)
MCAT *mcat;
tdtInfoParm *pInfoParm;
int flgs[];
{
	int i,*index,f,k1,k2,iParm[4],ndim;
	char dummy[256],wrk[128],id,*varnam;
	tdtArrayIndex *pIndex;
	XHASHB *xhp;
	tdtInfoParm *pInfo;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info_array:",pInfoParm,0,0);

	id = pInfoParm->pi_id;
	/* ��`�� */
	if (!(varnam=(char *)pInfoParm->pi_pos)) varnam=AKX_NULL_PRINT;
	if (id=='R' && (pInfo=(tdtInfoParm *)pInfoParm->pi_paux) && pInfo->pi_id!='R') {
		ERROROUT1(FORMAT(388),varnam);		/* �z��[%s]�������ł��B */
		akxtmcats(mcat,"##ERROR##,");
	}
	else {
		if (pGlobTable->options[12] & 0x01) {
			/* ��`�� */
			akxtmcats(mcat,varnam);
			akxtmcats(mcat,"[]");
			cl_debug_array_info(dummy,0,pInfoParm);
		}
		else {
			pIndex = (tdtArrayIndex *)pInfoParm->pi_data;
			/* �f�[�^�^ */
			if (id=='A' || id=='R') {
				iParm[0] = pIndex->uAttr[0];
				iParm[2] = pIndex->uAttr[2];
				iParm[3] = pIndex->uAttr[3];
				iParm[1] = pIndex->size;
				_print_attr(mcat,NULL,iParm);
			}
			else
				_print_attr(mcat,pInfoParm,NULL);
			akxtmcats(mcat," ");

			/* ��`�� */
			akxtmcats(mcat,varnam);

			/* �z���` */
			index = pIndex->index;
#if 1	/* 2017.7.23 koba */
		/*	if ((xhp=pIndex->xhp) || (id=='R' && (index[2] & 0x80))) {	2020.4.30 */
			if ((xhp=pIndex->xhp) || (id=='R' && (index[2] < 0))) {
				sprintf(dummy," Hash(%d)",index[4]);
			}
			else {
				if (id=='A') sprintf(dummy,"[(%d),",index[3]);
				else strcpy(dummy,"[");
				ndim = index[0];
			/*	f = index[2];	2020.4.30 */
				for (i=0;i<ndim;i++) {
					if (i > 0) strcat(dummy,",");
					k1 = index[i+4];
				/*	if (f & 0x01) {	*/
						k2 = index[i+ndim+4];
					if (k2) {
#else
			if ((xhp=pIndex->xhp) || (id=='R' && (index[MAX_ARRAY_DIM+1] & 0x80))) {
				sprintf(dummy," Hash(%d)",index[1]);
			}
			else {
				if (id=='A') sprintf(dummy,"[(%d),",index[0]);
				else strcpy(dummy,"[");
				f = index[MAX_ARRAY_DIM+1];
				for (i=0;i<MAX_ARRAY_DIM;i++) {
					if (i > 0) strcat(dummy,",");
					k1 = index[i+1];
					if (f & 0x01) {
						k2 = index[i+MAX_ARRAY_DIM+2];
#endif
						sprintf(wrk,"%d..%d",k2,k2+k1-1);
					}
					else sprintf(wrk,"%d",k1);
					strcat(dummy,wrk);
					f >>= 1;
				}
				strcat(dummy,"]");
			}
		}
		akxtmcats(mcat,dummy);
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
static void _print_list(mcat,pInfoParm,_print_info,flgs)
MCAT *mcat;
tdtInfoParm *pInfoParm;
int (*_print_info)(),flgs[];
{
	tdtRbCtl *pCt;
	int i;
	char *p1,*p2;

	if (pInfoParm->pi_id == D_DATA_ID_LIST) {
		p1 = "{";
		p2 = "}";
	}
	else {	/* id====D_DATA_ID_NARABI */
		p1 = "[";
		p2 = "]";
	}

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_list: p1=[%s] p2=[%s]",pInfoParm,p1,p2);

	akxtmcats(mcat,p1);
	i = 0;
	if (pInfoParm->pi_attr==DEF_ZOK_BULK && pInfoParm->pi_dlen==sizeof(tdtRbCtl)) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		if (akxs_rb_used(pCt)) {
			akxs_rb_read(pCt,0);
			i = 0;
			while (pInfoParm=(tdtInfoParm *)akxs_rb_read(pCt,1)) {
				if (i > 0) {
#if 1
					_print_dlm(mcat,flgs,0);
#else
					if (c_flg) akxtmcats(mcat,",");
					else akxtmcats(mcat," ");
#endif
				}
				_print_info(mcat,pInfoParm,NULL,flgs);
				i++;
			}
		}
	}
	if (!i) akxtmcats(mcat,"**NIL**");
	akxtmcats(mcat,p2);
}

/********************************************/
/*											*/
/********************************************/
static int _print_info_data(mcat,pInfoParm,varnam0,flgs)
MCAT *mcat;
tdtInfoParm *pInfoParm;
char *varnam0;
int flgs[];
{
/*	tdtRbCtl *pCt;	*/
	int i,j,iParm[4],ix1,nm1,iRc,iAux1,*index,f,k1,k2,type,m1,ic;
	char dummy[256],wrk[128],id,*varnam,*scope,*p1;
	tdtArrayIndex *pIndex,tIndex1;
	XHASHB *xhp;
	parmList  **parmName;
	tdtDefType *pDeftype;
	tdtInfoParm *pParmI,***pTBL1,*pInfo,tInfoParm;
#if 0
	if (!(pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) return _print_info(mcat,pInfoParm,varnam0);
#endif

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info_data: varnam0=[%s]",pInfoParm,varnam0,0);

	if ((id=pInfoParm->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		_print_list(mcat,pInfoParm,_print_info_data,flgs);
	}
	else if (id=='P' || id=='T') {
	/*	c_flg = 1;	*/
		if (id == 'P') type = pInfoParm->pi_aux[0];
		else type = D_AUX0_TYPE_STRUCT;
		if (type == D_AUX0_TYPE_STRUCT) {
			akxtmcats(mcat,"{");
			pDeftype = (tdtDefType *)pInfoParm->pi_data;
			parmName = pDeftype->vname;
			for (j=0;j<pDeftype->ntype;j++) {
				if (j > 0) {
#if 1
					_print_dlm(mcat,flgs,0);
#else
					if (c_flg) akxtmcats(mcat,",");
					else akxtmcats(mcat," ");
#endif
				}
			/*	varnam = strtemp(parmName[j]->prp,parmName[j]->prmlen);	*/
				akxtmcat(mcat,parmName[j]->prp,parmName[j]->prmlen);
				akxtmcats(mcat,"=");
				_print_info_data(mcat,pDeftype->pType[j],NULL,flgs);
			}
			akxtmcats(mcat,"}");
		}
		else {
			if (type == D_AUX0_TYPE_ARRAY) id = 'R';
			else id = 'A';
			pInfoParm->pi_id = id;
			_print_info_data(mcat,pInfoParm,NULL,flgs);
		}
	/*	c_flg = q_flg;	*/
	}
	else if (id=='A' || id=='R') {
		if (iRc=cl_get_array_info(pInfoParm,&tIndex1,&pTBL1,iParm)) return iRc;

DEBUGOUTL1(120,"_print_info_data: tIndex1.xhp=%08x",tIndex1.xhp);

#if 1	/* 2020.5.1 */
		nm1  = iParm[3];
	/*	if (nm1 <= 0) nm1  = iParm[1];	*/
#else
		nm1  = iParm[1];
#endif
		ix1  = iParm[2];
		for (i=0;i<nm1;i++,ix1++) {
			if ((iRc=cl_array_get_info_parm(&pParmI,&tIndex1,pTBL1,ix1,'r')) < 0) return iRc;

DEBUGOUT_InfoParm(120,"_print_info_data: id=[%c] i=%d",pParmI,id,i);

			if (i > 0) {
#if 1
				_print_dlm(mcat,flgs,0);
#else
				if (c_flg) akxtmcats(mcat,",");
				else akxtmcats(mcat," ");
#endif
			}
			if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
				if (xhp=tIndex1.xhp) {
					*dummy = '[';
					strnzcpy(dummy+1,xhp->xha_hashb->ha_key,sizeof(dummy)-4);
					strcat(dummy,"]=");
					akxtmcats(mcat,dummy);
				}
				_print_info_data(mcat,pParmI,NULL,flgs);
			}
		}
	}
	else if (id==' ' && (pInfoParm->pi_alen & D_AULN_RANGE_DATA) &&
	                    (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)) {
		if (iRc = cl_func_count(&nm1,1,&pInfoParm,1)) return iRc;
		cl_gx_copy_info(&tInfoParm,pInfoParm);
		if (tInfoParm.pi_attr != DEF_ZOK_BINA) {
			if (!(tInfoParm.pi_data=cl_tmp_const_malloc(tInfoParm.pi_dlen))) return -1;
			memcpy(tInfoParm.pi_data,pInfoParm->pi_data,pInfoParm->pi_dlen);
#if 1	/* 2019.8.30 */
			m1 = akxqkanjilen(p1=pInfoParm->pi_data);
			ic  = akxcmb2ul(p1,m1);
#else
			if (tInfoParm.pi_attr==DEF_ZOK_CHAR) *(tInfoParm.pi_data+1) = '\0';
#endif
		}
		tInfoParm.pi_aux[0] = tInfoParm.pi_alen = 0;
		for (i=0;i<nm1;i++) {
			if (i > 0) {
#if 1
				_print_dlm(mcat,flgs,0);
#else
				if (c_flg) akxtmcats(mcat,",");
				else akxtmcats(mcat," ");
#endif
#if 0	/* 2019.8.30 */
				if (tInfoParm.pi_attr == DEF_ZOK_CHAR) {
					*(uchar *)(tInfoParm.pi_data) = *(uchar *)(tInfoParm.pi_data) + 1;
				}
				else if ((iRc=_gx_ppmm(14,&tInfoParm)) < 0) return iRc;
#endif
			}
#if 1	/* 2019.8.30 */
			if (tInfoParm.pi_attr == DEF_ZOK_CHAR) {
				m1 = akxcul2mb(wrk,ic);
				cl_set_parm_char(&tInfoParm,wrk,m1);
				ic++;
			}
#endif
			_print_data(mcat,&tInfoParm,flgs);
#if 1	/* 2019.8.30 */
			if (tInfoParm.pi_attr != DEF_ZOK_CHAR) {
				if ((iRc=_gx_ppmm(14,&tInfoParm)) < 0) return iRc;
			}
#endif
		}
	}
	else if (id==D_DATA_ID_PNAME) {
		_print_info(mcat,pInfoParm,varnam0,flgs);
	}
	else if (id==D_DATA_ID_UNDEFVAR) akxtmcats(mcat,"**undef**");
	else _print_data(mcat,pInfoParm,flgs);

	return 0;
}

/********************************************/
/*											*/
/********************************************/
static int _print_info(mcat,pInfoParm,varnam0,flgs)
MCAT *mcat;
tdtInfoParm *pInfoParm;
char *varnam0;
int flgs[];
{
/*	tdtRbCtl *pCt;	*/
	int i,j,iParm[4],ix1,nm1,iRc,iAux1,*index,f,k1,k2,type,len;
	char dummy[256],wrk[128],id,*varnam,*scope,*p;
	tdtArrayIndex *pIndex,tIndex1;
	XHASHB *xhp;
	ScrPrCT *pScCT;
	parmList  **parmName;
	tdtDefType *pDeftype;
	tdtInfoParm *pParmI,***pTBL1,*pInfo;
	Leaf *wkleaf;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_print_info: varnam0=[%s]",pInfoParm,varnam0,0);

	if ((id=pInfoParm->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		_print_list(mcat,pInfoParm,_print_info,flgs);
	}
	else if (id=='F')
		_print_data(mcat,pInfoParm,flgs);
	else if (id=='P' || id=='T' || id=='A' || id=='R' || varnam0 || id==' ') {
		/* �X�R�[�v */
		iAux1 = pInfoParm->pi_aux[1];
		scope = "";
		if (iAux1 & D_AUX1_LOCAL_VAR) scope = "local ";
		else if (iAux1 & D_AUX1_PRIVATE_VAR) scope = "private ";
		else if (iAux1 & D_AUX1_PUBLIC_VAR) scope = "public ";
		else if (iAux1 & D_AUX1_GLOBAL_VAR) scope = "global ";
		if (*scope) akxtmcats(mcat,scope);

		/* CONST */
		if (iAux1 & D_AUX1_PROTECTED) akxtmcats(mcat,"const ");

		if (id == 'P') {
			type = pInfoParm->pi_aux[0];
			/* �^��` */
			akxtmcats(mcat,"type ");
		}
		else if (id == 'T') type = D_AUX0_TYPE_STRUCT;
		else type = 0;
		if (type == D_AUX0_TYPE_STRUCT) {
					/* �\���� */
			flgs[0] |= PRN_OPT_DCMA;
			/* �^��` */
		/*	if (id=='P') akxtmcats(mcat,"type ");	*/

			/* ��`�� */
			if (!(varnam=(char *)pInfoParm->pi_pos)) varnam="NONA";
			akxtmcats(mcat,varnam);
			akxtmcats(mcat,"{");
			pDeftype = (tdtDefType *)pInfoParm->pi_data;
			parmName = pDeftype->vname;
			for (j=0;j<pDeftype->ntype;j++) {
				if (j > 0) akxtmcats(mcat,", ");
				/* �����o���擾 */
				varnam = strtemp(parmName[j]->prp,parmName[j]->prmlen);
/*
printf("_print_info: varnam=[%s]\n",varnam);
*/
				_print_info(mcat,pDeftype->pType[j],varnam,flgs);
			}
			akxtmcats(mcat,"}");
			if (q_flg) flgs[0] |= PRN_OPT_DCMA;
			else flgs[0] &= ~PRN_OPT_DCMA;
		}
		else {
			if (type == D_AUX0_TYPE_ARRAY) id = 'R';
			else if (type == D_AUX0_TYPE_MAPPED) id = 'A';
			pInfoParm->pi_id = id;
			/* �z�� */
			if (id=='A' || id=='R')
				_print_info_array(mcat,pInfoParm);
			else {
				/* �f�[�^�^ */
				_print_attr(mcat,pInfoParm,NULL);

				/* ��`�� */
				akxtmcats(mcat," ");
#if 1	/* 2017.4.18 */
				if (varnam0) akxtmcats(mcat,varnam0);
#else
				if (varnam0) varnam = varnam0;
				else varnam = "NONA";
				akxtmcats(mcat,varnam);
#endif
			}
		}
	}
	else if (id==D_DATA_ID_CLASS || id==D_DATA_ID_INSTANCE) {
		*dummy = '\0';
		if (q_flg) strcat(dummy,"\"");
		if (id == D_DATA_ID_CLASS) {
			strcat(dummy,"Class ");
			if (varnam=pInfoParm->pi_data)
				len = akxstrnlen(varnam,pInfoParm->pi_dlen);
		}
		else if (id == D_DATA_ID_INSTANCE) {
			strcat(dummy,"Instance as ");
			if (wkleaf = (Leaf *)pInfoParm->pi_paux) {
				if (varnam=wkleaf->cmd.prmp[0]->prp) len = strlen(varnam);
			}
			else varnam = NULL;
		}
		if (varnam) memcat(dummy,varnam,len);
		else strcat(dummy,AKX_NULL_PRINT);
		if (q_flg) strcat(dummy,"\"");
		akxtmcats(mcat,dummy);
	}
	else if (id==D_DATA_ID_PNAME) {
		if (pInfoParm->pi_attr==2) {
/*
DEBUGOUT_InfoParm(0,"_print_info:",pInfoParm,0,0);
*/
			 akxtmcats(mcat,pInfoParm->pi_paux);
			 akxtmcats(mcat,"==>");
			_print_data(mcat,pInfoParm->pi_pos,flgs);
		}
		else {
			_print_data(mcat,pInfoParm->pi_data,flgs);
			 akxtmcats(mcat,"==>");
		}
	}
	else if (id==D_DATA_ID_UNDEFVAR) akxtmcats(mcat,"**undef**");
	else _print_data(mcat,pInfoParm,flgs);
	return 0;
}

/********************************************/
/*											*/
/********************************************/
static int _mcat_text_infoparm(mcat,tInfoParm2,k,flgs)
MCAT *mcat;
tdtInfoParm tInfoParm2[];
int k,flgs[];
{
	int j,nparm,iPARMINFO2,opt,len,data_flg,opt10,opt19,optw,w_pre,w_inx;
	tdtInfoParm *pInfoParm,tInfoParm;
	char name[30],name2[30],*p,id;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text_infoparm: k=%d",tInfoParm2,k,0);

	if ((tInfoParm2[0].pi_alen & D_AULN_PARMINFO2) &&
	    (nparm=tInfoParm2[1].pi_pos)) {
		pInfoParm = (tdtInfoParm *)tInfoParm2[1].pi_data;
		if (d_flg) {
			sprintf(name,"DUMP%d",k+1);
			cl_dump_info(&tInfoParm2[0],"%s=",name);
			sprintf(name2,"#%s#->",name);
			akxtmcats(mcat,name2);
		}
		iPARMINFO2 = 1;
	}
	else {
		nparm = 1;
		pInfoParm = tInfoParm2;
		iPARMINFO2 = 0;
	}

DEBUGOUTL2(LVL_GXEXOBJ,"_mcat_text_infoparm: nparm=%d,iPARMINFO2=%d",nparm,iPARMINFO2);

	opt = cl_get_option(13,0);
	for (j=0;j<nparm;j++,pInfoParm++) {
/*
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text_infoparm: j=%d",pInfoParm,j,0);
*/
#if 1
/*
printf("\n_mcat_text_infoparm: c_flg=%d\n",c_flg);
*/
		if (opt & 0x02) {
			if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_CHAR && (len=pInfoParm->pi_dlen)>=2) {
				if (p = pInfoParm->pi_data) {
					if (*p == '/') {
						_set_flag(p,len,flgs);
						continue;
					}
					else if (!memcmp(p,"\\/",2)) {
						cl_set_parm_char(&tInfoParm,p+1,len-1);
						pInfoParm = &tInfoParm;
					}
				}
			}
		}
#endif
		if (j > 0) {
#if 1
			_print_dlm(mcat,flgs,1);
#else
			if (c_flg) akxtmcats(mcat,",");
			if (t_flg) akxtmcats(mcat,"\t");
			else akxtmcats(mcat," ");
#endif
		}
		if (d_flg) {
			if (iPARMINFO2) sprintf(name,"DUMP%d-%d",k+1,j+1);
			else sprintf(name,"DUMP%d",k+1);
			cl_dump_info(pInfoParm,"%s=",name);
			sprintf(name2,"#%s#",name);
			akxtmcats(mcat,name2);
		}
		else {
#if 1	/* 2018.7.7 */
			if (i_flg==0 &&
			    ((pInfoParm->pi_aux[0] & DEF_ZOK_DATA) ||
				 (id=pInfoParm->pi_id)==' ' || id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)) {
				opt10 = pGlobTable->options[10];
				opt19 = pGlobTable->options[19];
				optw = opt10;
				if (p_flg)  optw |= 0x40;
				if (np_flg) optw &= ~0x40;
				if (pz_flg) optw |= 0x0100;
				if (pn_flg) optw &= ~0x0100;
				pGlobTable->options[10] = optw;
				w_pre = opt19 & 0xff;
				w_inx = (opt19>>8) & 0xff;
				if (exp_pre >= 0) w_pre = exp_pre;
				if (exp_inx >= 0) w_inx = exp_inx;
				pGlobTable->options[19] = (w_inx<<8) + w_pre;
/*
printf("_mcat_text_infoparm:1 p_flg=%d options[10],[19]=%08x %08x\n",p_flg,pGlobTable->options[10],pGlobTable->options[19]);
*/
				_print_info_data(mcat,pInfoParm,NULL,flgs);
				pGlobTable->options[10] = opt10;
				pGlobTable->options[19] = opt19;
/*
printf("_mcat_text_infoparm:2 p_flg=%d options[10],[19]=%08x %08x\n",p_flg,pGlobTable->options[10],pGlobTable->options[19]);
*/
			}
			else
				_print_info(mcat,pInfoParm,NULL,flgs);
#else
			if (pInfoParm->pi_aux[0] & DEF_ZOK_DATA)
				_print_info_data(mcat,pInfoParm,NULL);
#if 1	/* 2017.4.18 */
			else if ((id=pInfoParm->pi_id)==' ' || id==D_DATA_ID_LIST)
				_print_info_data(mcat,pInfoParm,NULL,flgs);
#endif
			else
				_print_info(mcat,pInfoParm,NULL,flgs);
#endif
		}
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
static int _mcat_text(mcat,prmp,Obj,prmnum,flgs)
MCAT *mcat;
parmList *prmp[];
int      *Obj;
int      prmnum,flgs[];
{
	int rc,i,j,nparm,len,k,nn_opt,iPARMINFO2,optW;
	parmList  *pparmList;
	tdtInfoParm tInfoParm2[2],*pInfoParm;
	char *p,c,c1,name[30],name2[30];
	SSPL_S sspl;

	flgs[0] &= ~PRN_OPT_DUMP;
	exp_pre = -1;
	exp_inx = -1;
	for (i=0,k=0;i<prmnum;i++) {
		pparmList = prmp[i];
		len = pparmList->prmlen;
		len = akxtsapb(0,p=strtemp(pparmList->prp,len),len);	/* 1-->0 2017.11.03 */
		if (*p == '/') {
			_set_flag(p,len,flgs);
			continue;
		}
		if (k > 0) {
#if 1
			_print_dlm(mcat,flgs,1);
#else
			if (c_flg) akxtmcats(mcat,",");
			if (t_flg) akxtmcats(mcat,"\t");
			else akxtmcats(mcat," ");
#endif
		}
		nn_opt = n_flg;
		if (nn_opt && !d_flg && !x_flg) {
#if 1
			if (!_do_print_name(p,len)) nn_opt = 0;
#else
			rc = 0;
			if (akx_skip_opt(p,len," \t+-.",0)>=len) rc = -1;
			else if ((c=*p)=='-' || c=='+' || (c>='0' && c<='9')) {
				if (akx_skip_opt(p+1,len-1,"0123456789",0)>=len-1) rc = 1;
			}
			if (!rc) {
				sspl.sp = 0;
				sspl.wdmax = 0;
				j = akxtgwnsl(p,len,&sspl," \t'+-*/&|=^~!<>[](),;?:{}",0x41);
				atr = sspl.attr[0];
				if (j==len && (atr==5 || atr==6)) rc = 1;
			}
			if (!rc) rc = cl_chk_digit_f(10,p,len);
/*
printf("_mcat_text: rc=%d\n",rc);
*/
			if (rc > 0) nn_opt = 0;
#endif
		}
		if (nn_opt) {
			akxtmcat(mcat,p,len);
			akxtmcats(mcat,"=");
		}
		optW = D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE;
		if (i_flg) optW |= D_GX_OPT_NOERROR_NDEF | D_GX_OPT_NOEROUT_NDEF;
		rc=cl_gx_exp_obj_opt(1,&pparmList,Obj,tInfoParm2,optW);

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_mcat_text: i=%d rc=%d",tInfoParm2,i,rc);

		if (rc!=NORMAL/* || InfoParm.pi_data==NULL*/) {
			if (rc == 100) {
				if (q_flg) akxtmcats(mcat,"\"\"");
			}
			else akxtmcats(mcat,"##ERROR##");
		}
		else {
			_mcat_text_infoparm(mcat,tInfoParm2,k,flgs);
		}
		k++;
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
static void _option_to_flag(opt,flgs)
int opt,flgs[];
{
	if (opt & 0x04) flgs[0] |= PRN_OPT_DCMA;
	if (opt & 0x08) flgs[0] |= PRN_OPT_QUOT;
	if (opt & 0x10) flgs[0] |= PRN_OPT_NAME;
	if (opt & 0x20) flgs[0] |= PRN_OPT_MCMA;
}

/********************************************/
/*											*/
/********************************************/
static int _flag_to_option(flgs)
int flgs[];
{
	int opt;

	opt = 0;
	if (c_flg) opt |= 0x04;
	if (q_flg) opt |= 0x08;
	if (n_flg) opt |= 0x10;
	if (flgs[0] & PRN_OPT_MCMA) opt |= 0x20;
	return opt;
}

/********************************************/
/*											*/
/********************************************/
static void cl_print_echo_text_init(mcat,name,opt,flgs)
MCAT *mcat;
char *name;
int  opt,flgs[];
{
	int qcn_opt;

	memset(mcat,0,sizeof(MCAT));
	mcat->mc_extlen = 256;
	if (!name) name = "";
	akxtmcats(mcat,name);
	mem_set_int(flgs,0,MAX_FLGS);
	qcn_opt = PRN_OPT_QUOT | PRN_OPT_DCMA | PRN_OPT_NAME;
	if (opt & 0x01) flgs[0] |= qcn_opt;
/*	else flgs[0] &= ~qcn_opt;	*/
	_option_to_flag(pGlobTable->options[12],flgs);
}

/********************************************/
/*											*/
/********************************************/
static void cl_print_echo_text_out(mcat,opt,flgs)
MCAT *mcat;
int  opt,flgs[];
{
	char *p=mcat->mc_bufp;
	FILE *fp;

	if (opt & 0x02) {
		if (e_flg) ERROROUTL(0,p);
		else PRINTOUTL(0,p);
	}
	else {
		if (e_flg) fp = stderr;
		else fp = stdout;
		fprintf(fp,"%s",p);
		akxa_log_new_line(fp,pGlobTable->options[2]);
	}
	if (p) Free(p);
}

/************************************************/
/*	ECHO		opt = 0							*/
/*	PRINT		opt = 1							*/
/*	LPRINT		opt = 3							*/
/* 				0x01:c_flg=1,q_flg=1,n_flg=1	*/
/*				0x02:PRINTOUT					*/
/************************************************/
int cl_print_echo_text(prmp,Obj,prmnum,name,opt)
parmList *prmp[];
int      *Obj;
int      prmnum;
char     *name;
int      opt;
{
	MCAT mcat;
	FILE *fp;
	int flgs[MAX_FLGS];
/*
printf("cl_print_echo_text:Enter name=[%s] opt=%08x\n",name,opt);
*/
	if (!prmp) return 0;
	cl_print_echo_text_init(&mcat,name,opt,flgs);
	_mcat_text(&mcat,prmp,Obj,prmnum,flgs);
	cl_print_echo_text_out(&mcat,opt,flgs);
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int cl_print_text(prmp,Obj,prmnum,name)
parmList *prmp[];
int      *Obj;
int      prmnum;
char     *name;
{
	return cl_print_echo_text(prmp,Obj,prmnum,name,0x03);
}

/****************************************/
/*										*/
/****************************************/
int cl_echo_text(prmp,Obj,prmnum,opt)
parmList *prmp[];
int      *Obj;
int      prmnum;
int      opt;
{
	return cl_print_echo_text(prmp,Obj,prmnum,NULL,opt & 0x01);
}

/********************************************/
/*											*/
/********************************************/
int cl_dump_info(pInfoParm,fmt,name)
tdtInfoParm *pInfoParm;
char *fmt,*name;
{
	char *p;
	int f;

	if (!fmt) fmt = "";
	if (!name) name = "";
	f = LOGFLG(D_LOG_NO_DEBUG,D_LOG_FLG_CHECK);
	LOGFLG(D_LOG_NO_DEBUG,f | D_LOG_FLG_STDOUT);
	DEBUGOUT_InfoParm(0,fmt,pInfoParm,name,0);
	LOGFLG(D_LOG_NO_DEBUG,f);
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int cl_dump(prmp,prmnum,Obj,flgs)
parmList *prmp[];
int      prmnum,flgs[];
char     *Obj;
{
	int rc,i,len;
	parmList *pparmList;
	tdtInfoParm tInfoParm2[2];
	char *p,c;

	flgs[0] |= PRN_OPT_NAME;
	for (i=0;i<prmnum;i++) {
		pparmList = prmp[i];
		len = pparmList->prmlen;
		len = akxtsapb(0,p=strtemp(pparmList->prp,len),len);	/* 1-->0 2017.11.03 */
		rc = cl_gx_exp_obj_opt(1,&pparmList,Obj,tInfoParm2,D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE);
		if (rc) DEBUGOUT1("%s=##ERROR##",p);
		else cl_dump_info(tInfoParm2,"%s=",p);
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int cl_func_print(pAns,pOperator,nparm,ppParm,ope,gx_opt)
char *pAns,*pOperator;
int ope,nparm,gx_opt;
tdtInfoParm *ppParm[];
{
	MCAT mcat;
	int opt,k,rc,flgs[MAX_FLGS];
	tdtInfoParm tParm2[2];

	if (ope == D_FUC_LPRINT) opt = 3;
	else if (ope == D_FUC_PRINT) opt = 1;
	else opt = 0;
	cl_print_echo_text_init(&mcat,NULL,opt,flgs);

	for (k=0;k<nparm;k++) {
		if (k > 0) {
			if (c_flg) akxtmcats(&mcat,",");
			akxtmcats(&mcat," ");
		}
#if 1
		cl_gx_copy_info(tParm2,ppParm[k]);
		memset(&tParm2[1],0,sizeof(tdtInfoParm));
		_mcat_text_infoparm(&mcat,tParm2,k,flgs);
#else
		_mcat_text_infoparm(&mcat,ppParm[k],k,flgs);
#endif
	}
	cl_print_echo_text_out(&mcat,opt,flgs);
	rc = 0;
	memcpy(pAns,&rc,sizeof(int));
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int cl_str_print(ppAns,pParm,iOpt)
char **ppAns;
tdtInfoParm *pParm;
int iOpt[];
{
	static MCAT mcat={'M','C',512,0,0,0,NULL,0};
	tdtInfoParm tParm2[2];
	int flgs[MAX_FLGS];

	if (!ppAns || !pParm) return -1;
#if 1	/* 2019.12.27 */
	if (iOpt[0]) {
		_option_to_flag(iOpt[0],iOpt+1);
		iOpt[0] = 0;
	}
	mem_cpy_int(flgs,iOpt+1,MAX_FLGS);
#else
	mem_set_int(flgs,0,MAX_FLGS);
	_option_to_flag(iOpt[0],flgs);
#endif
	mcat.mc_ipos = 0;
	cl_gx_copy_info(tParm2,pParm);
	memset(&tParm2[1],0,sizeof(tdtInfoParm));
	_mcat_text_infoparm(&mcat,tParm2,0,flgs);
#if 1	/* 2019.12.27 */
	mem_cpy_int(iOpt+1,flgs,MAX_FLGS);
#else
	iOpt[0] = _flag_to_option(flgs);
#endif
	*ppAns = mcat.mc_bufp;
	return mcat.mc_ipos;
}
