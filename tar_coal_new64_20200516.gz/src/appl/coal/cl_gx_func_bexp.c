static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	  �����ړI�@�@�F  ���Z����												*
*																			*
*	  �֐����@�@�@�F�@int cl_gx_funcBexp(pInfoParmW,pOperator,nparm,pParm)	*
*						tdtInfoParm *pInfoParmW;							*
*						char *pOperator;									*
*						tdtInfoParm *pParm;									*
*						int nparm;											*
*																			*
*	  �߂�l�@�@�@�F�@ERROR									�@				*
*					  NORMAL												*
*																			*
*	  �����T�v�@�@�F�@														*
*																			*
*****************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];

int replace();
int condas();
int cl_func_conv_parm();
int cl_func_f();
int cl_func_list();
int cl_set_list();
int cl_ope_list();
int cl_cons_list();
int cl_set_array();
int cl_array_ope();
int cl_array_map();
int cl_func_count();
int cl_func_index();
int cl_cmpt_is();
int cl_cmpt_to_number();
int cl_cmpt_math();
int cl_cmpt_to_bulk();
int cl_cmpt_to_bulks();
int cl_func_to_char();
int cl_func_to_date();
int cl_func_date_add();
int cl_func_date_diff();
int cl_func_add_months();
int cl_func_last_day();
int cl_func_set_date_part();
int cl_cmpt_to();
int rep_condas();
int substrm();
int concat();
int cl_get_args();
int cl_get_word();
int cl_trim();
int cl_strings();
int cl_leftm();
int cl_rightm();
int cl_rlpad();
int cl_chr();
int cl_asc();
int cl_sbs();
int cl_rep_like();
int cl_in_like();
int cl_ex_shell();
int cl_ex_no_free();
int cl_ex_shut_ctl();
int cl_ex_exit();
int cl_edit();
int cl_lenm();
int cl_func_env();
int cl_func_get_time();
int cl_ex_eval();
int cl_ex_nval();
int cl_ex_nsval();
int cl_ex_ndef();
int cl_ex_decode();
int cl_ex_iif();
int cl_ex_sort();
int cl_ex_round();
int cl_ex_xhash();
int cl_ex_channel();
int cl_func_mem_used();
int cl_func_print();
int cl_func_new();
int cl_func_times();
int cl_func_getval();
int cl_func_str_add();
int cl_func_str_exp();
int cl_func_str_conv();
/*
typedef struct {
	char *name;
	short mpara;
	short ope;
	uchar kubun;
	uchar reta;
	uchar arg_kbn;
	uchar ret_kbn;
	int  (*func)();
} qOpeTable;
*/
/*	name		nparm ope					kubun		reta    arg_kbn ret_kbn */
static qOpeTable tOpeTbl[]=
	{"IS"			,2,D_FUC_IS				,IS			,DEF_ZOK_BINA,2,3,cl_cmpt_is	/* 2-->3*/
	,"MOD"			,2,D_FUC_MOD			,MATH		,DEF_ZOK_BINA,0,4,cl_cmpt_math
	,"TO_NUMBER"	,1,D_FUC_TO_NUMBER		,TO			,DEF_ZOK_BINA,0,4,cl_cmpt_to_number
	,"TO_BULK"		,1,D_FUC_TO_BULK		,TO			,DEF_ZOK_BULK,9,2,cl_cmpt_to_bulk
	,"TO_BULKS"		,1,D_FUC_TO_BULKS		,TO			,DEF_ZOK_BULK,9,2,cl_cmpt_to_bulks
	,"TO_CHAR"		,1,D_FUC_TO_CHAR		,TO			,DEF_ZOK_CHAR,0,1,cl_func_to_char
	,"TO_DATE"		,1,D_FUC_TO_DATE		,TO			,DEF_ZOK_DATE,0,1,cl_func_to_date
	,"DATE_ADD"		,3,D_FUC_DATE_ADD		,TO			,DEF_ZOK_DATE,0,1,cl_func_date_add
	,"DATE_DIFF"	,2,D_FUC_DATE_DIFF		,TO			,DEF_ZOK_DATE,0,1,cl_func_date_diff
	,"ADD_MONTHS"	,2,D_FUC_ADD_MONTHS		,TO			,DEF_ZOK_DATE,0,1,cl_func_add_months
	,"LAST_DAY"		,1,D_FUC_LAST_DAY		,TO			,DEF_ZOK_DATE,0,1,cl_func_last_day
	,"SET_DATE_PART",3,D_FUC_SET_DATE_PART	,TO			,DEF_ZOK_DATE,0,1,cl_func_set_date_part
	,"TO"			,2,D_FUC_TO				,TO			,DEF_ZOK_CHAR,2,6,cl_cmpt_to
	,"LIKE"			,2,D_FUC_LIKE			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iLIKE"		,2,D_FUC_ILIKE			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"REGEX"		,2,D_FUC_REGEX			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iREGEX"		,2,D_FUC_IREGEX			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"MAX"			,1,D_FUC_MAX			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"MIN"			,1,D_FUC_MIN			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"ABS"			,1,D_FUC_ABS			,MATH		,DEF_ZOK_BINA,0,5,cl_cmpt_math
	,"LENG"			,1,D_FUC_LEN			,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_lenm	/* 2-->3*/
	,"LENGTH"		,1,D_FUC_LEN			,FUNCTION	,DEF_ZOK_BINA,0x0d,3,cl_lenm	/* 2-->3*/
	,"LENB"			,1,D_FUC_LENB			,FUNCTION	,DEF_ZOK_BINA,0x8d,3,cl_lenm	/* 2-->3*/
	,"REP"			,2,D_FUC_REP			,STRING		,DEF_ZOK_CHAR,10,2,replace
	,"CONDAS"		,2,D_FUC_CONDAS			,STRING		,DEF_ZOK_CHAR,10,2,condas
	,"SUBSTR"		,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x0b,2,substrm
	,"SUBSTRB"		,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x8b,2,substrm
	,"MID"			,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x0b,2,substrm
	,"MIDB"			,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x8b,2,substrm
	,"CONCAT"		,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat
	,"&+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat
	,"|+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat
	,"GETARGS"		,2,D_FUC_GETARGS		,STRING		,DEF_ZOK_BINA,0,3,cl_get_args	/* 2-->3*/
	,"GETWORD"		,2,D_FUC_GETWORD		,STRING		,DEF_ZOK_BINA,0,3,cl_get_word	/* 2-->3*/
	,"IN"			,2,D_FUC_IN				,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"iIN"			,2,D_FUC_IIN			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INSTR"		,2,D_FUC_INSTR			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INiSTR"		,2,D_FUC_INISTR			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INrSTR"		,2,D_FUC_INRSTR			,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"INirSTR"		,2,D_FUC_INIRSTR		,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"SKIP_OPT"		,2,D_FUC_SKIP_OPT		,COMP		,DEF_ZOK_BINA,0,0,NULL
	,"TRIM"			,1,D_FUC_TRIM			,STRING		,DEF_ZOK_CHAR,1,2,cl_trim
	,"STRINGS"		,2,D_FUC_STRINGS		,STRING		,DEF_ZOK_CHAR,1,2,cl_strings
	,"LEFT"			,2,D_FUC_LEFT			,STRING		,DEF_ZOK_CHAR,0x0d,2,cl_leftm
	,"LEFTB"		,2,D_FUC_LEFTB			,STRING		,DEF_ZOK_CHAR,0x8d,2,cl_leftm
	,"RIGHT"		,2,D_FUC_RIGHT			,STRING		,DEF_ZOK_CHAR,0x0d,2,cl_rightm
	,"RIGHTB"		,2,D_FUC_RIGHTB			,STRING		,DEF_ZOK_CHAR,0x8d,2,cl_rightm
	,"RPAD"			,2,D_FUC_RPAD			,STRING		,DEF_ZOK_CHAR,0x0e,2,cl_rlpad
	,"LPAD"			,2,D_FUC_LPAD			,STRING		,DEF_ZOK_CHAR,0x0e,2,cl_rlpad
	,"RPADB"		,2,D_FUC_RPADB			,STRING		,DEF_ZOK_CHAR,0x8e,2,cl_rlpad
	,"LPADB"		,2,D_FUC_LPADB			,STRING		,DEF_ZOK_CHAR,0x8e,2,cl_rlpad
	,"CHR"			,1,D_FUC_CHR			,STRING		,DEF_ZOK_CHAR,1,2,cl_chr
	,"ASC"			,1,D_FUC_ASC			,STRING		,DEF_ZOK_BINA,0x0d,3,cl_asc	/* 2-->3*/
	,"ASCB"			,1,D_FUC_ASCB			,STRING		,DEF_ZOK_BINA,0x8d,3,cl_asc	/* 2-->3*/
	,"EDIT"			,2,D_FUC_EDIT			,STRING		,DEF_ZOK_CHAR,1,2,cl_edit
	,"SBS"			,3,D_FUC_SBS			,STRING		,DEF_ZOK_CHAR,1,2,cl_sbs
	,"REPLIKE"		,3,D_FUC_REPLIKE		,STRING		,DEF_ZOK_CHAR,1,2,cl_rep_like
	,"INLIKE"		,4,D_FUC_INLIKE			,STRING		,DEF_ZOK_BINA,0x0d,2,cl_in_like
	,"STR_ADD"		,2,D_FUC_STR_ADD		,STRING		,DEF_ZOK_CHAR,2,1,cl_func_str_add
	,"STR_EXP"		,3,D_FUC_STR_EXP		,STRING		,DEF_ZOK_CHAR,2,1,cl_func_str_exp
	,"STR_CONV"		,2,D_FUC_STR_CONV		,STRING		,DEF_ZOK_CHAR,1,2,cl_func_str_conv
	,"FOPEN"		,1,D_FUC_FOPEN			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FCLOSE"		,1,D_FUC_FCLOSE			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FGETLINE"		,1,D_FUC_FGETLINE		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"FPUTLINE"		,1,D_FUC_FPUTLINE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FELREAD1"		,2,D_FUC_FELREAD1		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"FELWRITE"		,2,D_FUC_FELWRITE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FELWRITE1"	,2,D_FUC_FELWRITE1		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"UNLINK"		,1,D_FUC_UNLINK			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"POPEN"		,1,D_FUC_POPEN			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"PCLOSE"		,1,D_FUC_PCLOSE			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"GETLINE"		,0,D_FUC_GETLINE		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"PUTLINE"		,0,D_FUC_PUTLINE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"ELREAD1"		,1,D_FUC_ELREAD1		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"ELWRITE"		,1,D_FUC_ELWRITE		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"ELWRITE1"		,1,D_FUC_ELWRITE1		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"OPENDIR"		,1,D_FUC_OPENDIR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"READDIR"		,1,D_FUC_READDIR		,FUNCFILE	,DEF_ZOK_CHAR,0,0,NULL
	,"CLOSEDIR"		,1,D_FUC_CLOSEDIR		,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"STAT"			,1,D_FUC_STAT			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"FPSTAT"		,1,D_FUC_FPSTAT			,FUNCFILE	,DEF_ZOK_BINA,0,0,NULL
	,"SYSLOG"		,2,D_FUC_SYSLOG			,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"LOGOUT"		,2,D_FUC_LOGOUT			,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"GETLOGPARM"	,2,D_FUC_GETLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"SETLOGPARM"	,2,D_FUC_SETLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"RESLOGPARM"	,1,D_FUC_RESLOGPARM		,FUNCLOG	,DEF_ZOK_BINA,0,0,NULL
	,"SHELL"		,1,D_FUC_SHELL			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_shell	/* 2-->3*/
	,"NOFREE"		,0,D_FUC_NOFREE			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_no_free	/* 2-->3*/
	,"SHUTCTL"		,0,D_FUC_SHUTCTL		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_shut_ctl	/* 2-->3*/
	,"EXIT"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_exit	/* 2-->3*/
	,"BYE"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_exit	/* 2-->3*/
	,"QUIT"			,0,D_FUC_EXIT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_exit	/* 2-->3*/
	,"SETENV"		,2,D_FUC_SETENV			,FUNCTION	,DEF_ZOK_BINA,2,2,cl_func_env
	,"UNSETENV"		,1,D_FUC_UNSETENV		,FUNCTION	,DEF_ZOK_BINA,2,2,cl_func_env
	,"PUTENV"		,1,D_FUC_PUTENV			,FUNCTION	,DEF_ZOK_BINA,2,2,cl_func_env
	,"GETENV"		,1,D_FUC_GETENV			,FUNCTION	,DEF_ZOK_CHAR,2,2,cl_func_env
	,"GETTIME"		,0,D_FUC_GETTIME		,FUNCTION	,DEF_ZOK_DECI,0,1,cl_func_get_time
	,"EVAL"			,1,D_FUC_EVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_eval
	,"NVAL"			,2,D_FUC_NVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nval
	,"NULLIF"		,2,D_FUC_NVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nval
	,"NSVAL"		,2,D_FUC_NSVAL			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_nsval
	,"NDEF"			,1,D_FUC_NDEF			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_ndef
	,"DECODE"		,3,D_FUC_DECODE			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_decode
	,"IIF"			,3,D_FUC_IIF			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_ex_iif
	,"XHASH"		,2,D_FUC_XHASH			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_xhash	/* 2-->3*/
	,"CHANNEL"		,2,D_FUC_CHANNEL		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_channel	/* 2-->3*/
	,"GETMEMUSED"	,0,D_FUC_GETMEMUSED		,FUNCTION	,DEF_ZOK_BINA,0,2,cl_func_mem_used
	,"LPRINT"		,0,D_FUC_LPRINT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"PRINT"		,0,D_FUC_PRINT			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"ECHO"			,0,D_FUC_ECHO			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/
	,"SAY"			,0,D_FUC_ECHO			,FUNCTION	,DEF_ZOK_BINA,2,3,cl_func_print	/* 2-->3*/

	,"$"			,0,D_FUC_DOL			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm
	,"#"			,0,D_FUC_IGE			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm
	,"%"			,0,D_FUC_PAS			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm
	,"FF"			,1,D_FUC_TO_FUNC		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_func_f
	,"SETARRAY"		,3,D_FUC_SET_ARRAY		,FUNCTION	,DEF_ZOK_BINA,0,3,cl_set_array	/* 2-->3*/
	,"ARRAYCLR"		,1,D_FUC_ARRAY_CLR		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYCPY"		,3,D_FUC_ARRAY_CPY		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYCMP"		,3,D_FUC_ARRAY_CMP		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYBXP"		,3,D_FUC_ARRAY_BXP		,FUNCTION	,DEF_ZOK_BINA,2,3,cl_array_ope	/* 2-->3*/
	,"ARRAYMAP"		,2,D_FUC_ARRAY_MAP		,FUNCTION	,DEF_ZOK_BULK,0,1,cl_array_map
	,"COUNTV"		,1,D_FUC_COUNT			,FUNCTION	,DEF_ZOK_BINA,7,3,cl_func_count
	,"FL"			,1,D_FUC_LIST			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_func_list
	,"LIST"			,1,D_FUC_SET_LIST		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_set_list
	,"APPEND"		,1,D_FUC_SET_LIST		,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_set_list
	,"FIRST"		,1,D_FUC_FIRST			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_ope_list
	,"REST"			,1,D_FUC_REST			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_ope_list
	,"CONS"			,1,D_FUC_CONS			,FUNCTION	,DEF_ZOK_CHAR,0,1,cl_cons_list
	,"LIST_REF"		,1,D_FUC_LIST_REF		,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_ope_list
	,"INDEXA"		,2,D_FUC_INDEX			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_func_index	/* 2-->3*/
	,"SORT"			,2,D_FUC_SORT			,FUNCTION	,DEF_ZOK_BINA,0,3,cl_ex_sort	/* 2-->3*/
	,"ROUND"		,1,D_FUC_ROUND			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_ex_round
	,"NEW"			,1,D_FUC_NEW			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_new
	,"TIMES"		,0,D_FUC_TIMES			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_times
	,"GETVAL"		,1,D_FUC_GETVAL			,FUNCTION	,DEF_ZOK_VARI,0,1,cl_func_getval

	,"SQRT"			,1,D_FUC_SQRT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SIN"			,1,D_FUC_SIN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"COS"			,1,D_FUC_COS			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"TAN"			,1,D_FUC_TAN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ATAN"			,1,D_FUC_ATAN			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"LN"			,1,D_FUC_LOG			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"LOG"			,1,D_FUC_LOG			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"LOG10"		,1,D_FUC_LOG10			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"EXP"			,1,D_FUC_EXP			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"POWER"		,2,D_FUC_POWER			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"RAND1"		,0,D_FUC_RAND1			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SRAND1"		,1,D_FUC_SRAND1			,FUNCMATH	,0			 ,0,0,NULL
	,"DRAND48"		,0,D_FUC_RAND1			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SRAND48"		,1,D_FUC_SRAND1			,FUNCMATH	,0			 ,0,0,NULL
	,"CBRT"			,1,D_FUC_CBRT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"SINH"			,1,D_FUC_SINH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"COSH"			,1,D_FUC_COSH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"TANH"			,1,D_FUC_TANH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"ATANH"		,1,D_FUC_ATANH			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"RINT"			,1,D_FUC_RINT			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"FLOOR"		,1,D_FUC_FLOOR			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL
	,"CEIL"			,1,D_FUC_CEIL			,FUNCMATH	,DEF_ZOK_FLOA,0,0,NULL

	,"CCHAR"		,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL
	,"CSTRING"		,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL
	,"CSTR"			,1,D_FUC_CCHAR			,FUNCCAST	,DEF_ZOK_CHAR,0,0,NULL
	,"CINT"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CBIN"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CLONG"		,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CLNG"			,1,D_FUC_CINT			,FUNCCAST	,DEF_ZOK_BINA,0,0,NULL
	,"CFLOAT"		,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CFLT"			,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CDOUBLE"		,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CDBL"			,1,D_FUC_CFLOAT			,FUNCCAST	,DEF_ZOK_FLOA,0,0,NULL
	,"CDEC"			,1,D_FUC_CDEC			,FUNCCAST	,DEF_ZOK_DECI,0,0,NULL
	,"CDECIMAL"		,1,D_FUC_CDEC			,FUNCCAST	,DEF_ZOK_DECI,0,0,NULL
	,"CBULK"		,1,D_FUC_CBULK			,FUNCCAST	,DEF_ZOK_BULK,0,0,NULL
	,"CDATE"		,1,D_FUC_CDATE			,FUNCCAST	,DEF_ZOK_DATE,0,0,NULL
	,"CVARI"		,1,D_FUC_CVARIANT		,FUNCCAST	,DEF_ZOK_VARI,0,0,NULL
	,"CVARIANT"		,1,D_FUC_CVARIANT		,FUNCCAST	,DEF_ZOK_VARI,0,0,NULL

	,NULL,0,0,0,0,0,0,NULL
	};

/****************************************/
/*										*/
/****************************************/
qOpeTable *cl_get_func_name(pName,parm)
char *pName;
int  parm[];
{
	static XHASHB *xhp=NULL;
	static int iTry=1;
	qOpeTable *pot,**ppot;
	char *p,w[2];
	int i,len,ii,*pii;

#if 1
	if (iTry && !xhp) {
		if (xhp=akxs_xhash_new2(0,200,199,sizeof(qOpeTable *))) {
			xhp->xha_id[0] = 'h';
#if 1	/* 2019.9.14 */
			for (ii=0,pot=&tOpeTbl[0];p=pot->name;ii++,pot++) {
				if ((i=akxs_xhash2(xhp,'S',p,&ii)) <= 0) {
#else
			for (pot=&tOpeTbl[0];p=pot->name;pot++) {
				if ((i=akxs_xhash2(xhp,'S',p,&pot)) <= 0) {
#endif
					akxs_xhash_free(xhp);
					xhp = NULL;
					break;
				}
			}
		}
		iTry = 0;
	}
	mem_set_int(parm,0,5);
	if (xhp) {
#if 1	/* 2019.9.14 */
		if ((i=akxs_xhash2(xhp,'R',pName,&pii)) > 0) {
			ii = *pii;
			pot = &tOpeTbl[ii];
#else
		if ((i=akxs_xhash2(xhp,'R',pName,&ppot)) > 0) {
			pot = *ppot;
#endif
			parm[0] = pot->mpara;
			parm[1] = pot->ope;
			parm[2] = pot->kubun;
			parm[3] = pot->reta;
#if 1	/* 2019.9.14 */
			parm[4] = ii;
#endif
/*
printf("cl_get_func_name: pName=[%s] i=%d\n",pName,i);
*/
			return pot;
		}
	/*	else if (i < 0) return i;	*/
	}
#else
	pot = &tOpeTbl[0];
	for (i=1;p=pot->name;i++,pot++) {
		if(!stricmp(pName,p)) {
		
			parm[0] = pot->mpara;
			parm[1] = pot->ope;
			parm[2] = pot->kubun;
			parm[3] = pot->reta;
		
			return pot;
		}
	}
#endif
	if ((len=strlen(pName)) > 1) {
		if (akxnskipin(pName,len,"$%#") >= len) {
			w[0] = *pName;
			w[1] = '\0';
			return cl_get_func_name(w,parm);
		}
	}

	return NULL;
}

/****************************************/
/*										*/
/****************************************/
/* ret_kbn
	0
	1	exfunc(pInfoParmW,nparm,ppParm);
	2	exfunc(&pWork,nparm,ppParm);
	3	exfunc(pWork,nparm,ppParm);
	4	cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
	5	ABS()
	6	if ((rc=cl_cmpt_to(&pWork,pOperator,nparm,ppParm,ope,opt)) > 0)
*/
/* arg_kbn
	0	exfunc(pInfoParmW,nparm,ppParm);
	1	exfunc(&pWork,nparm,ppParm);
	2	exfunc(&pWork,pOperator,nparm,ppParm,ope,opt);
	7	exfunc(pWork,nparm,ppParm,0);
	9	exfunc(&pWork,nparm,ppParm,iParm);
   10	rep_condas(&pWork,nparm,ppParm,exfunc);
   11	substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
   12	concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
   13	exfunc(&pWork,mflg,nparm,ppParm);
   14	exfunc(&pWork,mflg,nparm,ppParm,ope,pOperator);
   16	cl_gx_copy_info(pInfoParmW, pInfoParm1);
	9	cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
   18	cl_cmpt_math(iMPA,pOperator,pInfoParm1,pInfoParm2,iParm);
*/
int cl_gx_func_bexp(pInfoParmW,pOperator,nparm,ppParm,opt,pParm)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *pParm,*ppParm[];
int nparm,opt;
{
	tdtInfoParm *pInfoParm1;
	tdtInfoParm *pInfoParm2;
	tdtInfoParm *pInfoParm3;
	int rc,ope,kubun,mflg,arg_kbn,ret_kbn;
	int dtlen,dtatr,scale,len,iParm[5],iVal,iMPA[NMPA_INT];
	char *pWork,*p,c;
	qOpeTable *pot;
	ScrPrCT	  *pScCT;
	int  (*exfunc)();
/*
printf("cl_gx_func_bexp:func=[%s] nparm=%d\n",pOperator,nparm);
*/
#if 0	/* 2016.10.17 */
	p = pInfoParmW->pi_paux;
	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	pInfoParmW->pi_paux = p;
#endif
	ope = 0;
	if (!(pGlobTable->options[7] & 0x01)) {
		rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
		if (rc != ECL_NOT_FOUND_FUNC) return rc;
	}
#if 1	/* 2019.9.15 */
	if ((c=*pOperator)>='0' && c<='9') {
		if (pot = &tOpeTbl[atoi(pOperator)])
			pOperator = pot->name;
	}
	else pot = cl_get_func_name(pOperator,iParm);
	if (pot) {
#else
	if (pot=cl_get_func_name(pOperator,iParm)) {
#endif
		if (nparm < pot->mpara/*iParm[0]*/) {
			/* �֐�(%s)�̈���������܂���B */
			ERROROUT1(FORMAT(211),pOperator);
			return -1;
		}
		ope   = pot->ope;	/*iParm[1];*/
		kubun = pot->kubun;	/*iParm[2];*/
		dtatr = pot->reta;	/*iParm[3];*/
		arg_kbn = pot->arg_kbn;
		ret_kbn = pot->ret_kbn;
		exfunc = pot->func;
	}

DEBUGOUTL5(161,"cl_gx_func_bexp:func=[%s] nparm=%d ope=%d kubun=%d dtatr=%d",
pOperator,nparm,ope,kubun,dtatr);

	if (!ope) {
		if (pGlobTable->options[7] & 0x01) {
			rc = cl_exec_function(pOperator,pInfoParmW,nparm,ppParm);
			if (rc != ECL_NOT_FOUND_FUNC) return rc;
		}
		/* [%s]�͊֐��ł͂���܂���B */
		ERROROUT1(FORMAT(212),pOperator);
		return ECL_SCRIPT_ERROR;
	}

	pInfoParm1 = ppParm[0];
	if (nparm >= 2) pInfoParm2 = ppParm[1];
	else pInfoParm2 = NULL;
	scale = 0x40;
	pWork = (char *)&(pInfoParmW->pi_pos);
#if 1	/* 2019.8.31 */
	mem_set_int(iParm,0,5);
	dtlen = 0;
#else
	iParm[0] = iParm[1] = iParm[2] = dtlen = 0;
#endif
	mflg = pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX;
	if (arg_kbn & 0x80) mflg = 0;
	arg_kbn &= 0x7f;

if (exfunc == NULL) {
	if (kubun == FUNCFILE) {
		pGlobTable->err_no = 0;
		if ((rc = func_file(&pWork,pOperator,nparm,pParm,ope,iParm)) > 0)
			dtatr = rc;
		pInfoParmW->pi_alen = iParm[2];
	}
	else if (kubun == COMP) {
		if ((rc = cl_func_comp(&pWork,pOperator,nparm,ppParm,ope)) > 0)
			dtatr = rc;
	}
	else if (kubun == FUNCMATH) {
#if 1
		return func_math2(pInfoParmW,pOperator,nparm,ppParm,ope);
#else
		rc = func_math(pWork,pOperator,nparm,ppParm,ope);
#endif
	}
	else if (kubun == FUNCLOG) {
		pGlobTable->err_no = 0;
		if (ope == D_FUC_GETLOGPARM)
			rc = func_get_log_parm(pWork,nparm,ppParm);
		else if (ope == D_FUC_SETLOGPARM)
			rc = func_set_log_parm(pWork,nparm,ppParm);
		else if (ope == D_FUC_RESLOGPARM)
			rc = func_res_log_parm(pWork,nparm,ppParm);
		else
			rc = func_log(pWork,pOperator,nparm,ppParm,ope);
	}
	else if (kubun == FUNCCAST) {
		return cl_func_conv(pInfoParmW,ope,pOperator,nparm,ppParm);
	}
	else {
			/* [%s]�͎�������Ă��܂���B */
			ERROROUT1(FORMAT(213),pOperator);
			return ECL_SCRIPT_ERROR;
	}
}
else if (ret_kbn <= 2) {
	if (ret_kbn == 1) {
		if (arg_kbn <= 1)
			rc = exfunc(pInfoParmW,nparm,ppParm);
		else	/* arg_kbn == 2 */
			rc = exfunc(pInfoParmW,pOperator,nparm,ppParm,ope,opt);
		return rc;
	}
	else {	/* ret_kbn == 2 */
		if (arg_kbn <= 10) {
			if (arg_kbn <= 2) {
				if (arg_kbn <= 1)
					rc = exfunc(&pWork,nparm,ppParm);
				else	/* arg_kbn == 2 */
					rc = exfunc(&pWork,pOperator,nparm,ppParm,ope,opt);
				if (!pWork) dtatr = 0;
			}
			else if (arg_kbn <= 9)
				rc = exfunc(&pWork,nparm,ppParm,iParm);
			else	/* arg_kbn == 10 */
				rc = rep_condas(&pWork,nparm,ppParm,exfunc);
		}
		else if (arg_kbn <= 12) {
			if (arg_kbn == 11) {
				if (nparm >= 3) pInfoParm3 = &pParm[2];
				else pInfoParm3 = NULL;
				rc = substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
			}
			else	/* arg_kbn <= 12 */
				rc = concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
		}
		else if (arg_kbn == 13)
			rc = exfunc(&pWork,mflg,nparm,ppParm);
		else	/* arg_kbn == 14 */
			rc = exfunc(&pWork,mflg,nparm,ppParm,ope,pOperator);
	}
}
else if (ret_kbn <= 6) {
	if (ret_kbn == 3) {
			if (arg_kbn == 0)
				rc = exfunc(pWork,nparm,ppParm);
			else if (arg_kbn == 2)
				rc = exfunc(pWork,pOperator,nparm,ppParm,ope,opt);
			else if (arg_kbn == 7)
				rc = exfunc(pWork,nparm,ppParm,0);
			else	/*arg_kbn == 13 */
				rc = exfunc(pWork,mflg,nparm,ppParm);
	}
	else if (ret_kbn==4 || ret_kbn==5) {
		if (ret_kbn==5) {
	/*	case D_FUC_ABS:	*/
			if (pInfoParm1->pi_attr == DEF_ZOK_DATE) {
				cl_gx_copy_info(pInfoParmW, pInfoParm1);
				return 0;
			}
			else pInfoParm2 = pInfoParm1;
		}
/*	case D_FUC_MOD:
	case D_FUC_TO_NUMBER:	*/
			if (ope == D_FUC_TO_NUMBER)
				rc = cl_cmpt_to_number(iMPA,nparm,ppParm,iParm);
			else
				rc = cl_cmpt_math(iMPA,pOperator,pInfoParm1,pInfoParm2,iParm);
			if (rc > 0) {
				dtatr = iParm[0];
				dtlen = iParm[1];
				if (dtatr == DEF_ZOK_BINA) {
					if (dtlen == sizeof(int)) {
						pInfoParmW->pi_pos = iMPA[0];
						iParm[1] = dtlen = sizeof(long);
					}
					else
						memcpy(pWork,iMPA,dtlen);
				}
				else if (dtatr == DEF_ZOK_FLOA) {
					memcpy(pWork,iMPA,dtlen);
				}
				else if (dtatr == DEF_ZOK_DECI) {
					rc = cl_set_parm_mpa(pInfoParmW,iMPA);
					pInfoParmW->pi_hlen = iParm[2];
					pInfoParmW->pi_pos  = iParm[3];
#if 1	/* 2019.8.31 */
					pInfoParmW->pi_alen = iParm[D_IPARM_OVER];
#endif
					return rc;
				}
			}
	}
	else {	/* ret_kbn==6 */
		if (arg_kbn == 2) {
			if ((rc=exfunc(&pWork,pOperator,nparm,ppParm,ope,opt)) > 0) {
				dtatr = rc;
				iParm[0] = dtatr;
			}
		}
	}
}
else {
/*
	switch (ope) {
	case D_FUC_DOL:
	case D_FUC_IGE:
	case D_FUC_PAS:
			return cl_func_conv_parm(pInfoParmW,nparm,ppParm,0,pOperator,opt);

	case D_FUC_TO_FUNC:
			return cl_func_f(pInfoParmW,nparm,ppParm);

	case D_FUC_LIST:
			return cl_func_list(pInfoParmW,nparm,ppParm);

	case D_FUC_SET_LIST:
			return cl_set_list(pInfoParmW,nparm,ppParm);

	case D_FUC_FIRST:
	case D_FUC_REST:
	case D_FUC_LIST_REF:
			return cl_ope_list(pInfoParmW,nparm,ppParm,ope,NULL,0);

	case D_FUC_CONS:
			return cl_cons_list(pInfoParmW,nparm,ppParm);

	case D_FUC_SET_ARRAY:
			rc = cl_set_array(pWork,nparm,ppParm);
			break;
	case D_FUC_ARRAY_CPY:
	case D_FUC_ARRAY_CLR:
	case D_FUC_ARRAY_CMP:
	case D_FUC_ARRAY_BXP:
			rc = cl_array_ope(pWork,nparm,ppParm,ope);
			break;
	case D_FUC_ARRAY_MAP:
			return cl_array_map(pInfoParmW,nparm,ppParm);

	case D_FUC_INDEX:
			rc = cl_func_index(pWork,nparm,ppParm);
			break;
	case D_FUC_COUNT:
			rc = cl_func_count(pWork,nparm,ppParm,0);
			break;
	case D_FUC_IS:
			rc = cl_cmpt_is(pWork,pOperator,nparm,ppParm);
			break;
	case D_FUC_ABS:
			if (pInfoParm1->pi_attr == DEF_ZOK_DATE) {
				cl_gx_copy_info(pInfoParmW, pInfoParm1);
				return 0;
			}
			else pInfoParm2 = pInfoParm1;
	case D_FUC_MOD:
	case D_FUC_TO_NUMBER:
			if (ope == D_FUC_TO_NUMBER)
				rc = cl_cmpt_to_number(iMPA,nparm,pParm,iParm);
			else
				rc = cl_cmpt_math(iMPA,pOperator,pInfoParm1,pInfoParm2);
			if (rc > 0) {
				dtatr = rc;
				if (dtatr == DEF_ZOK_BINA) {
					pInfoParmW->pi_pos  = iMPA[0];
				}
				else if (dtatr == DEF_ZOK_FLOA) {
					dtlen = sizeof(double);
					memcpy(&pInfoParmW->pi_pos,iMPA,dtlen);
				}
				else if (dtatr == DEF_ZOK_DECI) {
					return cl_set_parm_mpa(pInfoParmW,iMPA);
				}
			}
			break;
	case D_FUC_TO_BULK:
			rc = cl_cmpt_to_bulk(&pWork,nparm,ppParm,iParm);
			break;
	case D_FUC_TO_BULKS:
			rc = cl_cmpt_to_bulks(&pWork,nparm,ppParm,iParm);
			break;
	case D_FUC_TO_CHAR:
			rc = cl_func_to_char(&pWork,nparm,ppParm);
			break;
	case D_FUC_TO_DATE:
			return cl_func_to_date(pInfoParmW,nparm,ppParm);

	case D_FUC_DATE_ADD:
			return cl_func_date_add(pInfoParmW,nparm,ppParm);

	case D_FUC_DATE_DIFF:
			return cl_func_date_diff(pInfoParmW,nparm,ppParm);

	case D_FUC_ADD_MONTHS:
			return cl_func_add_months(pInfoParmW,nparm,ppParm);

	case D_FUC_LAST_DAY:
			return cl_func_last_day(pInfoParmW,nparm,ppParm);

	case D_FUC_SET_DATE_PART:
			return cl_func_set_date_part(pInfoParmW,nparm,ppParm);

	case D_FUC_TO:
			if ((rc = cl_cmpt_to(&pWork,pOperator,nparm,ppParm)) > 0) {
				dtatr = rc;
				iParm[0] = dtatr;
			}
			break;
	case D_FUC_REP:
			rc = rep_condas(&pWork,nparm,ppParm,replace);
			break;
	case D_FUC_CONDAS:
			rc = rep_condas(&pWork,nparm,ppParm,condas);
			break;
	case D_FUC_SUBSTRB:
			mflg = 0;
	case D_FUC_SUBSTR:
			if (nparm >= 3) pInfoParm3 = &pParm[2];
			else pInfoParm3 = NULL;
			rc = substrm(&pWork,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
			break;
	case D_FUC_CONCAT:
			rc = concat(&pWork,pInfoParm1,pInfoParm2,nparm-2,NULL,pParm+2);
			break;
	case D_FUC_GETARGS:
			rc = cl_get_args(pWork,nparm,ppParm);
			break;
	case D_FUC_GETWORD:
			rc = cl_get_word(pWork,nparm,ppParm);
			break;
	case D_FUC_TRIM:
			rc = cl_trim(&pWork,nparm,ppParm);
			break;
	case D_FUC_STRINGS:
			rc = cl_strings(&pWork,nparm,ppParm);
			break;
	case D_FUC_LEFTB:
			mflg = 0;
	case D_FUC_LEFT:
			rc = cl_leftm(&pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_RIGHTB:
			mflg = 0;
	case D_FUC_RIGHT:
			rc = cl_rightm(&pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_RPADB:
	case D_FUC_LPADB:
			mflg = 0;
	case D_FUC_RPAD:
	case D_FUC_LPAD:
			rc = cl_rlpad(&pWork,mflg,nparm,ppParm,ope,pOperator);
			break;
	case D_FUC_CHR:
			rc = cl_chr(&pWork,nparm,ppParm);
			break;
	case D_FUC_ASCB:
			mflg = 0;
	case D_FUC_ASC:
			rc = cl_asc(pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_EDIT:
			rc = cl_edit(&pWork,nparm,ppParm);
			break;
	case D_FUC_REPLIKE:
			rc = cl_rep_like(&pWork,nparm,ppParm);
			break;
	case D_FUC_SBS:
			rc = cl_sbs(&pWork,nparm,ppParm);
			break;
	case D_FUC_INLIKE:
			rc = cl_in_like(pWork,mflg,nparm,ppParm);
			break;
	case D_FUC_LENB:
			mflg = 0;
	case D_FUC_LEN:
			rc = cl_lenm(pWork,mflg,1,ppParm);
			break;
	case D_FUC_SHELL:
			rc = cl_ex_shell(pWork,nparm,ppParm);
			break;
	case D_FUC_NOFREE:
			rc = cl_ex_no_free(pWork,nparm,ppParm);
			break;
	case D_FUC_SHUTCTL:
			rc = cl_ex_shut_ctl(pWork,nparm,ppParm);
			break;
	case D_FUC_EXIT:
			rc = cl_ex_exit(pWork,nparm,ppParm);
			break;
	case D_FUC_EVAL:
			return cl_ex_eval(pInfoParmW,nparm,ppParm);

	case D_FUC_NVAL:
			return cl_ex_nval(pInfoParmW,nparm,ppParm);

	case D_FUC_NDEF:
			return cl_ex_ndef(pInfoParmW,nparm,ppParm);

	case D_FUC_XHASH:
			rc = cl_ex_xhash(pWork,nparm,ppParm);
			break;
	case D_FUC_CHANNEL:
			rc = cl_ex_channel(pWork,nparm,ppParm);
			break;
	case D_FUC_SETENV:
	case D_FUC_UNSETENV:
	case D_FUC_PUTENV:
	case D_FUC_GETENV:
			rc = cl_func_env(&pWork,nparm,ppParm,ope,pOperator);
			if (!pWork) dtatr = 0;
			break;
	case D_FUC_SORT:
			rc = cl_ex_sort(pWork,nparm,ppParm);
			break;
	case D_FUC_GETTIME:
			return cl_func_get_time(pInfoParmW,nparm,ppParm);
	case D_FUC_ROUND:
			return cl_ex_round(pInfoParmW,nparm,ppParm);
	case D_FUC_DECODE:
			return cl_ex_decode(pInfoParmW,nparm,ppParm);

	case D_FUC_GETMEMUSED:
			rc = cl_func_mem_used(pWork,nparm,ppParm);
			break;
	case D_FUC_LPRINT:
	case D_FUC_PRINT:
	case D_FUC_ECHO:
			rc = cl_func_print(pWork,nparm,ppParm,ope);
			break;
	case D_FUC_NEW:
			return cl_func_new(pInfoParmW,nparm,ppParm);
	case D_FUC_TIMES:
			return cl_func_times(pInfoParmW,nparm,ppParm);
	case D_FUC_GETVAL:
			return cl_func_getval(pInfoParmW,nparm,ppParm);

	default:
*/
			/* [%s]�͎�������Ă��܂���B */
			ERROROUT1(FORMAT(213),pOperator);
			return ECL_SCRIPT_ERROR;
/*	}	*/

}
#if 1	/* 2018.11.10 */
	if (rc < 0) return rc;
#if 1
	if (pGlobTable->exception && pGlobTable->try_level>0) {
		if ((rc=pGlobTable->exception) > 0) rc = -rc;
		return rc;
	}
#endif
#endif

	if (iParm[0] > 0) {
		if (iParm[0] == DEF_ZOK_BINA) {
			if (iParm[1] != sizeof(long)) {
				memcpy(&iVal,pWork,sizeof(int));
				pInfoParmW->pi_pos = iVal;
			}
			dtlen = sizeof(long);
		}
		else if (iParm[0] == DEF_ZOK_DECI) {
			scale = 0;
			dtlen = sizeof(MPA);
			pInfoParmW->pi_hlen = iParm[2];
			pInfoParmW->pi_pos = iParm[3];
		}
		else if (iParm[0] == DEF_ZOK_FLOA) {
			dtlen = sizeof(double);
		}
		else {
			scale = 0;
			dtlen = iParm[1];
		}
	/*	scale = 0;	*/
	}
	else {
		if (dtatr == DEF_ZOK_BINA) {
			memcpy(&iVal,pWork,sizeof(int));
			pInfoParmW->pi_pos = iVal;
			dtlen = sizeof(long);
		}
		else if (dtatr == DEF_ZOK_FLOA) dtlen = sizeof(double);
		else {
			scale = 0;
			if (dtatr == DEF_ZOK_CHAR) {
				if (pWork) dtlen = strlen(pWork);
			}
			else if (dtatr==DEF_ZOK_DECI || dtatr==DEF_ZOK_DATE) dtlen = sizeof(MPA);
		}
	}

	if (dtatr) {
		pInfoParmW->pi_id = ' ';
		pInfoParmW->pi_attr = dtatr;
		pInfoParmW->pi_scale= scale;
		pInfoParmW->pi_code = CLcommon.cDataCode;
		pInfoParmW->pi_dlen = dtlen;
		pInfoParmW->pi_data = pWork;
#if 1	/* 2019.8.31 */
		pInfoParmW->pi_alen = iParm[D_IPARM_OVER];
#endif
	/*	if (dtatr == DEF_ZOK_BINA) pInfoParmW->pi_scale = 0x40;	*/
	}
	else cl_null_parm(pInfoParmW);
/*	else cl_null_data(pInfoParmW);	*/
DEBUGOUT_InfoParm(194,"cl_gx_func_bexp: dtatr=%d",pInfoParmW,dtatr,0);
#if 0	/* 2018.11.10 */
	if (rc >= 0) {
		rc = 0;
		if (pGlobTable->exception && pGlobTable->try_level>0) {
			if ((rc=pGlobTable->exception) > 0) rc = -rc;
		}
	}
	return rc;
#else
	return 0;
#endif
}

/****************************************/
/*										*/
/****************************************/
int cl_ex_method(pInfoParmW,pInfoParm1,optW,p2,len2)
tdtInfoParm *pInfoParmW,*pInfoParm1;
int optW;
char *p2;
int len2;
{
	tdtInfoParm *ppParm[2];

	ppParm[0] = pInfoParm1;
	return cl_gx_func_bexp(pInfoParmW,p2,1,ppParm,optW,pInfoParm1);
}

/****************************************/
/*										*/
/****************************************/
int cl_set_system_method(pInfoParmW,pInfoParm1,pInfoParm2,optW,p2,len2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
char *p2;
int len2;
{
	tdtInfoParm *pInfoParm;

#if 1
	cl_gx_copy_info(pInfoParmW,pInfoParm2);
#else
	cl_set_parm_char(pInfoParmW,p2,len2);
	pInfoParmW->pi_id = 'F';
#endif
	if (!(pInfoParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
	cl_parm_set0(pInfoParm);
	cl_gx_rep_info_set(pInfoParm,pInfoParm1,1);
	pInfoParmW->pi_hlen = (long)pInfoParm;

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_func_method(pInfoParmW,pInfoParmM,nparm,ppParm,opt,pParm)
tdtInfoParm *pInfoParmW,*pInfoParmM;
tdtInfoParm *pParm,*ppParm[];
int nparm,opt;
{
	tdtInfoParm *pParmW,**ppParmW;
	int i,len,rc;
	Leaf *wkleaf,*nodeleaf;
	char *name,*p;
	ProcCT *cur_procct;

DEBUGOUT_InfoParm(161,"cl_gx_func_methodc_f:pInfoParmM: nparm=%d opt=%08x",pInfoParmM,nparm,opt);

#if 1	/* 2016.10.17 */
	p = pInfoParmW->pi_paux;
	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	pInfoParmW->pi_paux = p;
#endif
	if (pInfoParmM->pi_hlen) {
		nparm++;
		len = nparm*sizeof(tdtInfoParm);
		if (!(pParmW=(tdtInfoParm *)cl_tmp_const_malloc(len))) return -1;
		memcpy(pParmW+1,pParm,len-sizeof(tdtInfoParm));
		cl_gx_copy_info(pParmW,pInfoParmM->pi_hlen);
		pParm = pParmW;
		len = nparm*sizeof(tdtInfoParm *);
		if (!(ppParmW=(tdtInfoParm **)cl_tmp_const_malloc(len))) return -1;
		for (i=0;i<nparm;i++) ppParmW[i] = pParmW++;
		ppParm = ppParmW;
	}
#if 1
	wkleaf = (Leaf *)pInfoParmM->pi_pos;
	nodeleaf = (Leaf *)pInfoParmM->pi_paux;
	name = pInfoParmM->pi_data;
/*
if (wkleaf) {
printf("cl_gx_func_method: name=[%s] wkleaf=%08x nodeleaf=%08x pi_alen=%04x\n",
name,wkleaf,nodeleaf,pInfoParmM->pi_alen);
}
*/
	if (wkleaf && pInfoParmM->pi_alen==D_AULN_SET_POS_LEAF) {
		cur_procct = cl_search_proc_ct();
		rc = cl_exec_func_setup_proc(name,pInfoParmW,nparm,ppParm,wkleaf,nodeleaf,0,NULL);
		if (!rc) {
			rc = cl_exec_func_execute(cur_procct);
		}
	}
	else {
		rc = cl_gx_func_bexp(pInfoParmW,pInfoParmM->pi_data,nparm,ppParm,opt,pParm);
	}
/*
printf("cl_gx_func_method: rc=%d\n",rc);
*/
	return rc;
#else
	return cl_gx_func_bexp(pInfoParmW,pInfoParmM->pi_data,nparm,ppParm,opt,pParm);
#endif
}

/****************************************/
/*										*/
/****************************************/
int rep_condas(pAns,nparm,ppParm,func)
char **pAns;
int nparm;
tdtInfoParm	*ppParm[];
int (*func)();
{
	tdtInfoParm *pInfoParm1,tInfoParm;
	tdtInfoParm *pInfoParm2;
	int  rc,len1;
	char *p1;

	pInfoParm1 = ppParm[0];
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			p1   = pInfoParm1->pi_data;
			len1 = pInfoParm1->pi_dlen;
			if ((rc=cl_get_str_pos(nparm,ppParm,0,&p1,&len1,NULL,NULL,"")) < 0) return rc;
			pInfoParm1 = &tInfoParm;
			cl_set_parm_char(pInfoParm1,p1,len1);
			pInfoParm2 = ppParm[rc];
		}
	}
	return func(pAns,pInfoParm1,pInfoParm2);
}
