static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  													      *
*                                                                             *
*      �֐����@�@�@�F�@int cl_ex_get_proc_name( pparmList , pBuff , plen )    *
*                      (I)prmList	*pparmList                                *
*                      (O)char		*pBuff		                              *
*                      (O)int		*plen		                              *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

int cl_trim_proc_name(p0,len0,pr_nam)
char *p0;
int  len0;
ParList *pr_nam;
{
	static char *PAT=" \t\n\r";
#if 1	/* 2020.3.31 */
	int len;

	len = akxtstrim2(0,p0,len0,pr_nam,PAT);
#else
	int  len,pos;
	char *p;

	len = len0;
	if ((p=p0) && len>0) {
		pos = akxnskipin(p,len,PAT);
		p   += pos;
		len -= pos;
		pos = akxnrskipin(p,len,PAT);
		if (pos < len) {
			len = pos;
			p[len] = '\0';
		}
	}
	pr_nam->par    = p;
	pr_nam->parlen = len;
#endif
	return len;
}

int cl_ex_get_proc_name(pparmList, Obj, pr_nam)
parmList *pparmList;
int  *Obj;
ParList *pr_nam;
{
	static char *_fn_="cl_ex_get_proc_name";
	int  rc,len,pos,n;
	char *p,*pn;
	tdtInfoParm InfoParm;

	p   = pparmList->prp;
	len = pparmList->prmlen;
DEBUGOUTL2(110,"cl_ex_get_proc_name:Enter len=%d p=[%s]",len,p);
	if (cl_trim_proc_name(p,len,pr_nam) < len) {
		p   = pr_nam->par;
		len = pr_nam->parlen;
	}
	if (*p=='{' && p[len-1]=='}') ;
	else if (!cl_is_proc_scr_name(p,len)) {
		pparmList->prp    = p;;
		pparmList->prmlen = len;
		if (rc=cl_arg_to_char_opt(pparmList,Obj,&InfoParm,FORMAT(326),D_GX_OPT_PROC_NAME)) return rc;	/* "�葱����" */
		p   = InfoParm.pi_data;
		len = InfoParm.pi_dlen;
		if (cl_trim_proc_name(p,len,pr_nam) < len) {
			p   = pr_nam->par;
			len = pr_nam->parlen;
		}
	}
DEBUGOUTL2(120,"cl_ex_get_proc_name: len=%d p=[%s]",len,p);
/*
	pr_nam->par = p;
	pr_nam->parlen = len;
*/
	n = len;
#if 0	/* 2020.3.26 */
	if (chklen > 0) {
		pn = FORMAT(114);
		while (len > 0) {
			n = akxnskipto(p,len,".");
			if (n > chklen) {
				/* �葱�������������܂�(len=%d)�B */
				ERROROUT5(FORMAT(112),_fn_,pn,strtemp(p,len),len,chklen);
				rc = ECL_SCRIPT_ERROR;
			}
			else if (n<=0 || n==len-1) {
				rc = ECL_SCRIPT_ERROR;
				n = 0;
			}
			else if (cl_chk_proc_name(p,n)) {
				/* �葱����[%s]���s���ł��B */
				ERROROUT3(FORMAT(113),_fn_,pn,strtemp(p,n));
				rc = ECL_SCRIPT_ERROR;
			}
			if (rc) break;
			len -= ++n;
			p += n;
		}
	}
#endif
	if (n <= 0) {
		ERROROUT(FORMAT(327));	/* �葱������NULL�ł��B */
		rc = ECL_SCRIPT_ERROR;
	}

DEBUGOUTL1(110,"cl_ex_get_proc_name:Exit rc=%d",rc);
	return rc;
}

int cl_exe_proc_name_check(pr_nam)
ParList *pr_nam;
{
	static char *_fn_="cl_exe_proc_name_check";
	int  rc,len,pos,n;
	char *p,*pn;

	rc = 0;
	p   = pr_nam->par;
	len = pr_nam->parlen;
DEBUGOUTL2(110,"cl_exe_proc_name_check:Enter len=%d p=[%s]",len,p);
	n = len;
	pn = FORMAT(114);
	while (len > 0) {
		n = akxnskipto(p,len,".");
DEBUGOUTL1(120,"cl_exe_proc_name_check: n=%d",n);
		if (n > PR_NM_DEF) {
			/* �葱�������������܂�(len=%d)�B */
			ERROROUT5(FORMAT(112),_fn_,pn,strtemp(p,len),len,PR_NM_DEF);
			rc = ECL_SCRIPT_ERROR;
		}
		else if (n<=0 || n==len-1) {
			rc = ECL_SCRIPT_ERROR;
			n = 0;
		}
		else if (cl_chk_proc_name(p,n)) {
			/* �葱����[%s]���s���ł��B */
			ERROROUT3(FORMAT(113),_fn_,pn,strtemp(p,n));
			rc = ECL_SCRIPT_ERROR;
		}
		if (rc) break;
		len -= ++n;
		p += n;
	}
	if (n <= 0) {
		ERROROUT(FORMAT(327));	/* �葱������NULL�ł��B */
		rc = ECL_SCRIPT_ERROR;
	}
DEBUGOUTL1(110,"cl_exe_proc_name_check:Exit rc=%d",rc);
	return rc;
}

int cl_ex_get_proc_scr_name(pparmList,Obj,pr_nam,sc_nam)
parmList *pparmList;
int  *Obj;
ParList *pr_nam,*sc_nam;
{
	static char *C_SEP=" \t@'";
	int  ret,len,n,i,pos;
	char *p,*da[2],na[2],*pp,c;
	SSPL_S ssp;
	int atr;
	char wrk[4096];
	parmList parm;
	ParList par[2];

	ret = 0;
	p   = pparmList->prp;
	len = pparmList->prmlen;
DEBUGOUTL2(110,"cl_ex_get_proc_scr_name:Enter len=%d p=[%s]",len,p);
	if (cl_trim_proc_name(p,len,pr_nam) < len) {
		p   = pr_nam->par;
		len = pr_nam->parlen;
	}
	if (*p=='{' && p[len-1]=='}') {
		sc_nam->par = p;
		sc_nam->parlen = len;
		pr_nam->par = NULL;
		pr_nam->parlen = 0;
		return 0;
	}
	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk)-1;
	i = 0;
	while ((n=akxtgwnsl(p,len,&ssp,C_SEP,0x43)) >= 0) {
DEBUGOUTL4(120,"cl_ex_get_proc_scr_name: n=%d atr=%d sp=%d wd=[%s]",n,ssp.attr[0],ssp.sp,ssp.wd);
		c = *ssp.wd;
		if (c == '@') {
			i = ssp.sp - 1;
DEBUGOUTL1(120,"cl_ex_get_proc_scr_name: i=%d\n",i);
			break;
		}
	}
	if (i > 0) {
		par[0].par = p;
		par[0].parlen = i;
		par[1].par = p + i + 1;
		par[1].parlen = len - (i+1);
		pp = wrk;
		len = 2;
		for (i=0;i<2;i++) {
			parm.prp    = pp;
			parm.prmlen = par[i].parlen;
			parm.opt    = 0;
			parm.bxobj  = NULL;
			memzcpy(parm.prp,par[i].par,parm.prmlen);
DEBUGOUTL3(120,"cl_ex_get_proc_scr_name: i=%d parm.prmlen=%d parm.prp=[%s]",i,parm.prmlen,parm.prp);
			if (ret = cl_ex_get_proc_name(&parm,Obj,&par[i])) return ret;
DEBUGOUTL2(120,"cl_ex_get_proc_scr_name: na=%d da=[%s]",par[i].parlen,par[i].par);
			pp += parm.prmlen+1;
			len += par[i].parlen;
		}
		i = 1;
	}
	else {
		sc_nam->par = NULL;
		sc_nam->parlen = 0;
		if (ret = cl_ex_get_proc_name(pparmList,Obj,pr_nam)) return ret;
		p = pr_nam->par;
		if ((i=instrchar(p,'@',0)) > 0) {
			len = pr_nam->parlen;
			par[0].par = p;
			par[0].parlen = i - 1;
			par[1].par = p + i;
			par[1].parlen = len - i;
			len++;
		}
		else {
		}
	}
	if (i > 0) {
		pp = cl_tmp_const_malloc(len);
		memzcpy(pp,par[0].par,par[0].parlen);
		pr_nam->par = pp;
		pr_nam->parlen = par[0].parlen;
		pp += par[0].parlen + 1;
		memzcpy(pp,par[1].par,par[1].parlen);
		sc_nam->par = pp;
		sc_nam->parlen = par[1].parlen;
	}
DEBUGOUTL1(110,"cl_ex_get_proc_scr_name:Exit ret=%d",ret);
	return 0;
}
