static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************************/
/* <clpron.c>                                        */
/*      On process   �@�@�@                          */
/*****************************************************/

#include "colmn.h"

extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */
extern CLPRTBL   CLprocTable;
extern int cl_process_define_exec();
int cl_pr_ex_on();

/************************************/
/* cl_process_on                    */
/************************************/
int cl_process_on(scrct)
ScrPrCT  *scrct;
{
	int cmd[1];
	int (*func[1])();

	cmd[0] = C_ONN;
	func[0] = cl_pr_ex_on;
/*	return cl_process_define_exec(scrct,C_ONN,cl_pr_ex_on);	*/
	return cl_process_top_exec(scrct,scrct->TreeTop,cl_process_define_exec,1,cmd,func);
}

/************************************/
/* cl_pr_ex_on                    */
/************************************/
int cl_pr_ex_on(leaf, scrct, dummy1,dummy2)
Leaf    *leaf;
ScrPrCT  *scrct;
int dummy1,dummy2;
{
	static char *_fn_="cl_pr_ex_on";
	int rc,iSel,num_max;
	int i,gr,offset,parmnum,err=0,k;
	ONTBL *ontbl;
	char *p;
	parmList *prp;

	if (!leaf || !scrct) return ECL_SYSTEM_ERROR;

	/* parameter check */
	parmnum = leaf->cmd.prmnum;
/*
printf("cl_pr_ex_on: parmnum = %d\n",parmnum);
*/
	for (i=0;i<parmnum;i++) {
		if (leaf->cmd.prmp[i]->prmlen == 0) {
			ERROROUT1(FORMAT(486),_fn_);	/* %s:�p�����[�^��NULL�ł��B */
			return(ECL_SCRIPT_ERROR);
		}
	}
	if (parmnum > 1) {
		if (!stricmp((p=leaf->cmd.prmp[0]->prp),"GR")) {
			offset = 0;
			if (parmnum < 6) err = 1;
			else if (parmnum > 8) err = 2;
		}
		else if (*p == '<') {
			offset = -1;
			p++;
			if (*p == '?') gr = 99001;
			else if (*p == '!') gr = 99002;
			else gr = 99003;
			if (gr == 99003) {
				if (parmnum < 5) err = 1;
				else if (parmnum > 7) err = 2;
			}
			else {
				if (parmnum < 3) err = 1;
				else if (parmnum > 3) err = 2;
			}
		}
		else {
			/* %s: ���p�����[�^�� 'GR'or '<'�ł͂���܂���B */
			ERROROUT1(FORMAT(491),_fn_);
			return ECL_SCRIPT_ERROR;
		}
	}
	else err = 1;

	if (err) {
		if (err == 1) ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂��� */
		else ERROROUT1(FORMAT(41),_fn_);	/* %s: �s�v�ȃp�����[�^������܂� */
		return ECL_EX_ON;
	}

	/* initialize */
	rc = 0;
	if (!scrct->ONCOND) {
		if (!(scrct->ONCOND=(ONTBL **)Malloc(sizeof(ONTBL *)*ON_NUM_MAX))) {
			ERROROUT("scrct->ONCOND allocate error ");
			return ECL_SYSTEM_ERROR;
		}
		memset(scrct->ONCOND,0,sizeof(ONTBL *)*ON_NUM_MAX);
		scrct->on_num_max = ON_NUM_MAX;
	}
	/* ONTBL entry search */
	num_max = scrct->on_num_max;
/*
printf("cl_pr_ex_on: num_max = %d\n",num_max);
*/
	for (i=0;i<num_max;i++) {
		if (!scrct->ONCOND[i]) break;
	}
	if (i >= num_max) {
		num_max += ON_NUM_MAX;
#if 1
		if (!(scrct->ONCOND=(ONTBL **)Realloc(scrct->ONCOND,sizeof(ONTBL *)*num_max))) {
			ERROROUT("scrct->ONCOND reallocate error ");
			return ECL_SYSTEM_ERROR;
		}
		memset(scrct->ONCOND+scrct->on_num_max,0,sizeof(ONTBL *)*ON_NUM_MAX);
		scrct->on_num_max = num_max;
printf("cl_pr_ex_on: num_max = %d\n",num_max);
#else
		ERROROUT("Too many ON-CONDITION.");
		return ECL_EX_ON;
#endif
	}
	/* ONTBL allocate */
	ontbl = (ONTBL *)Malloc(sizeof(ONTBL));
	if (!ontbl) {
		ERROROUT("ontbl allocate error ");
		return ECL_SYSTEM_ERROR;
	}
	memset((char *)ontbl,0,sizeof(ONTBL));
	/* ONTBL address set */
	scrct->ONCOND[i] = ontbl;

	/* parameter set */
	if (offset == 0) {
		if (axccvn(10,leaf->cmd.prmp[1]->prp,leaf->cmd.prmp[1]->prmlen,
		           &(ontbl->FldNum))) return ECL_SCRIPT_ERROR;
	}
	else {
		ontbl->FldNum = gr;
	}
/*
printf("cl_pr_ex_on: ontbl->FldNum = %d\n",ontbl->FldNum);
*/
	for (i=offset+2;i<parmnum;i++) {
		if (prp=leaf->cmd.prmp[i]) {
			switch (k=i-offset-2) {
			case 0:
			case 2:
			case 4:
				if ((iSel = cl_pr_ex_on_sel(prp)) < 0) rc = iSel;
				else ontbl->PrSel[k/2] = iSel;
				break;
			case 1:
			case 3:
			case 5:
				if (iSel == D_PRSEL_SC)
					rc=cl_pr_ex_on_sc_name(prp,&ontbl->PrName[k/2]);
				else
					rc=cl_pr_ex_on_pr_name(prp,&ontbl->PrName[k/2]);
				break;
			}
			if (rc) return rc;
		}
	}
	return(rc);
}

int cl_pr_ex_on_sel(prm)
parmList *prm;
{
	int rc;

	rc = ECL_SCRIPT_ERROR;
	if (prm->prmlen == 2) {
		if      (!memicmp(prm->prp,"IP",2)) rc = D_PRSEL_IP;
		else if (!memicmp(prm->prp,"EP",2)) rc = D_PRSEL_EP;
		else if (!memicmp(prm->prp,"SC",2)) rc = D_PRSEL_SC;
	}
	return rc;
}

int cl_pr_ex_on_pr_name(prm,ppPrName)
parmList *prm;
char **ppPrName;
{
	if (prm->prmlen > PR_NM_DEF) return ECL_SCRIPT_ERROR;
	if (cl_chk_proc_name(prm->prp,prm->prmlen)) return ECL_SCRIPT_ERROR;
	if (*ppPrName = Memdup(prm->prp,prm->prmlen)) return 0;
	else return -1;
}

int cl_pr_ex_on_sc_name(prm,ppPrName)
parmList *prm;
char **ppPrName;
{
	int len,rc;
	char *name;

	len  = prm->prmlen;
	name = prm->prp;
	if (rc=cl_exe_scr_name_check(name,len)) return rc;
	if (*ppPrName = Memdup(name,len)) return 0;
	else return -1;
}
