static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ� ( ���l )                                      *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_const_n( pparmList , pInfoParm )           *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtInfoParm	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];

int cl_conv_const_n(pparmList , pInfoParm)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
{
	int	rc,len,opt;
	char *prp;
	int  iAttr[2],iVal[NMPA_INT];
	double dValue;
	long   lValue;

	if (!pparmList) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ERROR;
	}
	if (!pparmList->prp) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ERROR;
	}
	prp = &(pparmList->prp[0]);
	len = pparmList->prmlen;
	return cl_conv_const_n_str(pInfoParm, prp, len);
}

int cl_conv_const_n_str(pInfoParm, prp, len)
tdtInfoParm  *pInfoParm;
char *prp;
int	len;
{
	int	rc,opt,iAttr[2],iVal[NMPA_INT];
	double dValue;
	long   lValue;

/*	opt = (pGlobTable->options[16] >> 4) & 0x0f;	*/
	opt = pGlobTable->options[16];
	iAttr[0] = 0;
	if ((rc=cl_conv_const_nsub(prp,len,iVal,"cl_conv_const_n_str: ",iAttr,opt)) < 0) return rc;
	else if (rc > 0) return ECL_SCRIPT_ERROR;
	if (iAttr[0] == DEF_ZOK_FLOA) {
		memcpy(&dValue,iVal,sizeof(double));
		cl_set_parm_double(pInfoParm,dValue);
	}
	else if (iAttr[0] == DEF_ZOK_DECI) {
		cl_set_parm_mpa(pInfoParm,iVal);
	}
	else {
		lValue = CL_GET_VAL_BIN(iVal);
		cl_set_parm_long(pInfoParm,lValue);
	}
	pInfoParm->pi_aux[1] = D_AUX1_PROTECTED;

	return NORMAL;
}

int cl_conv_const_nsub(p0,len0,pValue,pMsg,iAttr,opt)
char *p0;
int  len0;
int  *pValue;
char *pMsg;
int  iAttr[];
int  opt;
{
	int	i,rc,len;
	char *prp,*prp2,c,cValue[33];

	prp = p0;
	len = len0;
/*
printf("cl_conv_const_nsub: prp=[%s] len=%d opt=%d\n",prp,len,opt);
*/
	if (prp && len) {
		i = akxnskipin(prp,len," \t");
		prp += i;
		len = akxnrskipin(prp,len-i," \t");
/*
printf("cl_conv_const_nsub: i=%d len=%d\n",i,len);
*/
	}
#if 0
	if (len >= 3) {
		prp2 = prp;
		if ((c = *prp2)=='+' || c=='-') prp2++;
		if (*prp2=='0' && strchr("BOX",toupper(*(prp2+1)))) {
			iAttr[0] = DEF_ZOK_BINA;
			if (rc = cl_cvn10(prp,len,pValue)) {
				if ((pMsg=cl_conv_msg_check(pMsg,rc)) && rc>0) {
					strnzcpy(cValue,prp,X_MIN(len,sizeof(cValue)-1));
					/* %s�����ȊO�̕���[%s]������܂�(pos=%d)�B */
					ERROROUT3(FORMAT(306),pMsg,cValue,rc);
				}
			}
			return rc;
		}
	}
#endif
	rc = cl_conv_const_mpasub(prp,len,pValue,pMsg,iAttr,opt & ~AKX_CNVN_OPT_DOUBLE);
	return rc;
}

int cl_set_parm_bin(pInfoParm,iValue)
tdtInfoParm *pInfoParm;
int iValue;
{
	cl_set_parm_long(pInfoParm,(long)iValue);
	return 0;
}

/**************************************************************
 D_DATA_LPOSDATA(0x40)�𗧂Ă�Ƃ��́Api_pos��long�ŕێ�����B
**************************************************************/
int cl_set_parm_long(pInfoParm,lValue)
tdtInfoParm *pInfoParm;
long lValue;
{
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_BINA;
	pInfoParm->pi_scale= D_DATA_LPOSDATA;
	pInfoParm->pi_pos  = lValue;
	pInfoParm->pi_dlen = sizeof(long);
	pInfoParm->pi_data = (char *)&(pInfoParm->pi_pos);
	return 0;
}

int cl_set_parm_double(pInfoParm,dValue)
tdtInfoParm *pInfoParm;
double dValue;
{
/*
printf("cl_set_parm_double: dValue=%f\n",dValue);
*/
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_FLOA;
	pInfoParm->pi_scale= D_DATA_LPOSDATA;
	memcpy(&pInfoParm->pi_pos,&dValue,sizeof(double));
	pInfoParm->pi_dlen = sizeof(double);
	pInfoParm->pi_data = (char *)&(pInfoParm->pi_pos);
	return 0;
}

int cl_set_parm_mpa(pInfoParm,val)
tdtInfoParm *pInfoParm;
MPA *val;
{
	char *p;

	memset(pInfoParm,0,sizeof(tdtInfoParm));
	if (!(p=cl_tmp_const_malloc(sizeof(MPA)))) return -1;
	if (!val) val = m_get_i(0);
	memcpy(p,val,sizeof(MPA));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_DECI;
	pInfoParm->pi_scale= 0;
	pInfoParm->pi_dlen = sizeof(MPA);
	pInfoParm->pi_data = p;
	return 0;
}

int cl_conv_const_mpasub(p,len,pValue,pMsg,iAttr,opt)
char *p;
int  len;
int  *pValue;
char *pMsg;
int  iAttr[];
int  opt;	/* AKX_CNVN_OPT_DOUBLE = ON:double �Q�i���������_��, OFF:decimal �P�O�i���������_��  */
{
	int rc,attr,k,size,opt16;
	double dVal;
	char   buf[33];
/*
printf("cl_conv_const_mpasub: p=[%s] len=%d opt=%08x iAttr[0]=%d\n",p,len,opt,iAttr[0]);
*/
	rc = 0;
	k = cl_chk_digit_fopt(10,p,len,opt | AKX_CNVN_OPT_DIGIT);
	opt16 = pGlobTable->options[16];
/*
printf("cl_conv_const_mpasub: k=%d iAttr[0]=%d opt16=%04x\n",k,iAttr[0],opt16);
*/
	if (k==8) {
#if 0	/* 2018.5.28 */
		attr = iAttr[0];
		if ((attr & 0xffffff00)==D_GX_OPT_USE_ATTR) attr = attr & 0x0f;
		else attr = 0;
		if (attr==3) k = 1;
		else if (attr==4) k = 2;
		else k = 0;
#else
		if (iAttr[0]==3) k = 1;
		else if (iAttr[0]==4 || (opt16 & 0x80)) k = 2;
		else k = 0;
#endif
	}
	if (k==2 &&
	         ((opt & AKX_CNVN_OPT_DOUBLE) || (opt16 & 0x01))) k = 1;
/*
printf("cl_conv_const_mpasub: modified k=%d\n",k);
*/
	if (k == 2) {
		if (rc=m_set_an_opt((MPA *)pValue,p,len,opt)) {
#if 1	/* 2018.6.17 */
			rc = cl_chk_error_mpa(rc,pMsg,p,len);
#else
			if (pMsg=cl_conv_msg_check(pMsg,rc)) {
				memnzcpy(buf,p,len,sizeof(buf)-1);
				/* %s�P�O�i�����_��[%s]�̎w�肪����Ă��܂�(rc=%d)�B */
				ERROROUT3(FORMAT(308),pMsg,buf,rc);
			}
#endif
		}
		attr = DEF_ZOK_DECI;
		size = sizeof(MPA);
	}
	else if (k == 1) {
		if (rc=akxccvd(p,len,&dVal)) {
			if (pMsg=cl_conv_msg_check(pMsg,rc)) {
				memnzcpy(buf,p,len,sizeof(buf)-1);
				/* %s�Q�i���������_��[%s]�̎w�肪����Ă��܂�(rc=%d)�B */
				ERROROUT3(FORMAT(307),pMsg,buf,rc);
			}
			if (rc < -10) rc = -rc/10;
		}
		memcpy((char *)pValue,&dVal,sizeof(double));
		attr = DEF_ZOK_FLOA;
		size = sizeof(double);
	}
	else {
		rc = cl_cvn10(p,len,pValue);
		if ((pMsg=cl_conv_msg_check(pMsg,rc)) && rc>0) {
			memnzcpy(buf,p,len,sizeof(buf)-1);
			/* %s�����ȊO�̕���[%s]������܂�(pos=%d)�B */
			ERROROUT3(FORMAT(306),pMsg,buf,rc);
		}
		attr = DEF_ZOK_BINA;
		size = sizeof(long);
	}
	iAttr[0] = attr;
	iAttr[1] = size;
	return rc;
}

int cl_conv_const_double(p,len,pValue,pMsg,iAttr)
char *p;
int  len;
int  *pValue;
char *pMsg;
int  iAttr[];
{
	return cl_conv_const_mpasub(p,len,pValue,pMsg,iAttr,AKX_CNVN_OPT_DOUBLE);
}
/**********
int cl_conv_const_mpa(p,len,pValue,pMsg,iAttr,opt)
char *p;
int  len;
int  *pValue;
char *pMsg;
int  iAttr[];
{
	return cl_conv_const_mpasub(p,len,pValue,pMsg,iAttr,opt & ~AKX_CNVN_OPT_DOUBLE);
}
***********/
char *cl_conv_msg_check(pMsg,rc)
char *pMsg;
int rc;
{
	char c;

	if (pMsg) {
		if ((c=*pMsg)=='-') {
			if (rc >= 0) pMsg = NULL;
			else pMsg++;
		}
		else if (c=='+') {
			if (rc <= 0) pMsg = NULL;
			else pMsg++;
		}
	}
	return pMsg;
}

/****************************************/
/*										*/
/****************************************/
int cl_cvn10(p,len,pvalue)
char *p;
int  len, *pvalue;
{
	int rc;
	char buf[65];
	long lVal;

	if (len<0) {
		ERROROUT(FORMAT(262));	/* �����񒷂����ł��B */
		rc = ECL_SYSTEM_ERROR;
	}
	else if (len == 0) {
		*pvalue = 0;
		rc = 0;
	}
	else {
		rc = akxcgcvl(p,len,&lVal);
		if (rc) {
			memnzcpy(buf,p,len,sizeof(buf)-1);
				/* (%d)[%s]����������܂���B */
			if      (rc == -1) ERROROUT2(FORMAT(263),len,buf);
				/* (%d)[%s]�i�����s���ł��B */
			else if (rc == -2) ERROROUT2(FORMAT(264),len,buf);
			else if (rc == -3) {
				/* (W)(%d)[%s]�I�[�o�t���[���܂����B */
				ERROROUT2(FORMAT(265),len,buf);
				rc = 0;
			}
		}
#if defined(_LP64)
		memcpy(pvalue,&lVal,sizeof(long));
#else
		*pvalue = lVal;
#endif
	}
	return rc;
}
