/*static	char	sccsid[]="%Z% %M% %I% %E% %U%";*/
/******************************************/
/*                                        */
/*             cmmacro.h                  */
/*                                        */
/******************************************/
#ifndef _CMMACRO_H
#define _CMMACRO_H
typedef struct tm DATE;

#define axs_xhash     akxs_xhash
#define axccvn       akxccvn
#define axs_xhashFree akxs_xhashFree
#define axcetos      akxcetos
#define axcstoe      akxcstoe
#define axtmcats     akxtmcats
#define axtmcat      akxtmcat
#define axtgwsp      akxtgwsp
#define axaxdump     akxaxdump
#define axtgwse      akxtgwse
#define iskanji      akxqiskanji
#define axcstoj1     akxcstoj1
#define axcjtos1     akxcjtos1
#define axs_xhashInit akxs_xhashInit
#define akb_ptime    akbPtime

#define ConstantCt	tdtCONSTCT

#if defined(COAL) || defined(OLD_COAL)
#undef ERROROUT
#undef ERROROUT1
#undef ERROROUT2
#undef ERROROUT3
#undef ERROROUT4
#undef ERROROUT5
#undef ERROROUTRC
#undef ERROROUTS

#undef PRINTOUT
#undef PRINTOUT1
#undef PRINTOUT2
#undef PRINTOUT3
#undef PRINTOUT4
#undef PRINTOUT5
#undef LOGOUT

#define CMSGLVL	1
#define CERROROUTL5(l,fmt,a1,a2,a3,a4,a5) \
		cl_log_out_l5(D_LOG_NO_ERROR,l,__FILE__,__LINE__,fmt,a1,a2,a3,a4,a5)
#define ERROROUT1(fmt,a1) CERROROUTL5(CMSGLVL,fmt,a1,NULL,NULL,NULL,NULL)
#define ERROROUT2(fmt,a1,a2) CERROROUTL5(CMSGLVL,fmt,a1,a2,NULL,NULL,NULL)
#define ERROROUT3(fmt,a1,a2,a3) CERROROUTL5(CMSGLVL,fmt,a1,a2,a3,NULL,NULL)
#define ERROROUT4(fmt,a1,a2,a3,a4) CERROROUTL5(CMSGLVL,fmt,a1,a2,a3,a4,NULL)
#define ERROROUT5(fmt,a1,a2,a3,a4,a5) CERROROUTL5(CMSGLVL,fmt,a1,a2,a3,a4,a5)
#define ERROROUTRC(msg,rc) ERROROUT2("%s%d",msg,rc)
#define ERROROUTS(fmt,msg) ERROROUT1(fmt,msg)
#define ERROROUT(msg)  ERROROUT1("%s",msg)

#define PRINTOUT(msg)  PRINTOUTL(CMSGLVL,msg)
#define PRINTOUT1(fmt,a1) PRINTOUTL1(CMSGLVL,fmt,a1)
#define PRINTOUT2(fmt,a1,a2) PRINTOUTL2(CMSGLVL,fmt,a1,a2)
#define PRINTOUT3(fmt,a1,a2,a3) PRINTOUTL3(CMSGLVL,fmt,a1,a2,a3)
#define PRINTOUT4(fmt,a1,a2,a3,a4) PRINTOUTL4(CMSGLVL,fmt,a1,a2,a3,a4)
#define PRINTOUT5(fmt,a1,a2,a3,a4,a5) PRINTOUTL5(CMSGLVL,fmt,a1,a2,a3,a4,a5)
#define LOGOUT(msg) PRINTOUTL(CMSGLVL,msg)

#define DEBUGOUT_InfoParm(level,fmt,pInfo,a1,a2) \
		cl_debug_out_info_parm(level,__FILE__,__LINE__,fmt,pInfo,a1,a2)
#define DEBUGOUT_InfoParm5(level,fmt,pInfo,a1,a2,a3,a4,a5) \
		cl_debug_out_info_parm5(level,__FILE__,__LINE__,fmt,pInfo,a1,a2,a3,a4,a5)
#endif

#define RETURN(x) {return cl_debug_out_return(__FILE__,__LINE__,__FUNCTION__,x);}

#define ADDRCHK(p)	addrchk(__FILE__,__LINE__,p)
#define FORMAT(no)	cl_get_format(no)

#if defined(_LP64)
#define CL_GET_VAL_BIN(Val) cl_get_val_long(Val)
#else
#define CL_GET_VAL_BIN(Val) Val[0]
#define cl_get_parm_long(pInfoParm,pValue,pMsg) cl_get_parm_bin(pInfoParm,pValue,pMsg)
#endif

#endif	/* _CMMACRO_H */
