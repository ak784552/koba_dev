/******************************************/
/*                                        */
/*             cmprot.h                   */
/*                                        */
/******************************************/
#ifndef _CMPROT_H
#define _CMPROT_H

int   akb_ptime ();
int   akb_errorout();
int   akxtgwse();
int   akbmeminit();
char *akbmalloc();
char *akbrealloc();
void  akbfree();
int   akbnofree();

#endif	/* _CMPROT_H */
