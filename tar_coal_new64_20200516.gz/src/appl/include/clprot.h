/*static    char    sccsid[]="%Z% %M% %I% %E% %U%";*/
/********************************************************/
/*														*/
/*	clprot.h											*/
/*														*/
/*		coded by A.Kobayashi 2010.5.28					*/
/*														*/
/*********************************************************/
#ifndef _CLPROT_H
#define _CLPROT_H

int  cl_lex_syn();
FILE *cl_file_open();
FILE *cl_lex_file_open();

/* cllex.c */

int  cl_lex();
int  clparmset();
int  clparmclr();
int  cl_syn_main();
char *cl_lex_snln();

/* cllexfnc.c */

int  cl_get_str();
cmdTable *cl_cmd_chk();
void cl_cmd_init();
void cl_copy_cmd();

/* cltest.c */

int    cl_tree_main();

int    cl_change_stcb();
int    cl_make_leaf();
int    cl_push();
int    cl_change_tree();
Leaf  *cl_make_node_leaf();

int    cl_search_nest();
int    cl_nest_tag();
int    cl_pre_nest();
int    cl_check_nest();

int    col_mn_tr_bexp();
int    col_mn_tr_end_if();
int    col_mn_tr_end_loop();
int    col_mn_tr_else_if();
int    col_mn_tr_else();
int    col_mn_tr_exec();
int    col_mn_tr_if();
int    col_mn_tr_loop();
int    col_mn_tr_on();
int    col_mn_tr_output();
int    col_mn_tr_read();
int    col_mn_tr_return();
int    col_mn_tr_sql();
int    col_mn_tr_proc();
int    col_mn_tr_end_proc();
int    col_mn_tr_break();
qSubCommand *cl_tr_sc_set_scno(/*scno0,opt,select*/);

int    cl_if_close();
/* clcommon.c */
void   cmn_set_stat();
int    cmn_chk_stat();
    
/* cldumy.c */    
int  cl_process_sqlsnd();
int  cl_process_sqlrcv();
int  cl_process_break();
int  cl_process_read();
int  cl_process_output();
int  cl_process_if();

/* clnode.c */
int  cl_node_process();
char *cl_gets_cmd_name();

/* clexescr.c */

int  cl_execute_script();
int  cl_exe_scr_init();
ScrPrCT *cl_search_src_ct();
ProcCT  *cl_search_proc_ct();
Leaf    *cl_search_proc();
Leaf    *cl_search_proc_leaf();
Leaf    *cl_search_proc_leaf_inner();
Leaf    *cl_search_func();
Leaf    *cl_search_func_leaf();
Leaf    *cl_search_func_leaf_inner();
Leaf    *search_top_leaf();
ScrPrCT *cl_lru_scr_src();
ScrPrCT *cl_lru_scr_src_opt();
Leaf    *cl_set_func_body();
Leaf    *cl_search_leaf_and_inner();
Leaf    *cl_search_func_leaf_and_inner();
Leaf    *cl_search_proc_leaf_and_inner();
Leaf    *cl_search_class_leaf();
Leaf    *cl_search_class_leaf_and_inner();

/* clprexec */
int cl_set_proc_nm(/*proc,name*/);
int cl_pr_exec_ip(Leaf *leafleaf,ProcCT *proc,int nam_pos);
int cl_pr_exec_ep(/*leaf,proc*/);
int cl_pr_exec_sc(/*leaf,proc,nam_pos*/);
int cl_pr_exec_sc_sub(/*leaf,proc,sc_nam,pr_nam,nam_pos*/);
int cl_pr_exec_sm(/*leaf,proc*/);
int cl_process_exec(/*leaf,proc*/);
int cl_process_exec_return(/*leaf,proc*/);
int cl_process_call(/*leaf,proc*/);

/* clprproc */

int  cl_process_proc();

/* clmkproc */
ProcCT *cl_mk_lk_proc_ct();
ProcCT *cl_mk_pr_make();
int cl_mk_pr_push();
ProcCT *cl_mk_lk_class_method();

/* clmkscpt */
ScrPrCT *cl_mk_lk_scr_pr_ct();
ScrPrCT *cl_mk_lk_make();
ScrPrCT *cl_mk_scr_pr_ct();
ScrPrCT *cl_mk_scr_and_reg();
int  cl_mk_lk_push();
int *cl_var_set_size(/*pSize, iMAX_VAR_IX, iMAX_VAR_IY, name*/);
tdtInfoParm *cl_var_size_parm(/* int *pSize*/);

/* clerproc */
int  cl_er_lk_proc_ct();

/* clerscpt */
int  cl_er_lk_scr_pr_ct();

int    cl_loop_close();
int    col_mn_tr_file_end();
int    cl_process_end_proc();
int    cl_script_main();
int    cl_make_return_packet();

/*  */
VarTBL *ver_set();
tdtInfoParm *parm_set0();
tdtInfoParm *cl_get_var_ent();
tdtInfoParm *cl_get_var_ent_opt(/*pVarIndex,ParmNo,opt*/);
tdtInfoParm *cl_get_global_var();
tdtInfoParm *cl_get_array_ent();
tdtInfoParm *cl_get_array_ent_opt();
tdtInfoParm *cl_get_array_and_var_ent(/*pInfoParmArray,pIndex,pTBL,ix*/);
tdtInfoParm *cl_get_array_and_var_ent_opt(/*pInfoParmArray,pIndex,pTBL,ix,opt*/);
int  cl_parameter_set();

/* select process */
char *cl_sl_ext_select();
char *cl_sl_ext_from();
char *cl_sl_const_where();
int  cl_sl_make_select_command();

/* cllog.c */
int cl_log_out_l5(/*log_no,level,file,line,fmt,a1,a2,a3,a4,a5*/);
void cl_debug_out_info_parm(/*level,file,line,format,pInfo,a1,a2*/);
void cl_debug_out_info_parm5(/*level,file,line,format,pInfo,a1,a2,a3,a4,a5*/);
int cl_debug_array_info(/*fmt,len,pInfo*/);
int cl_debug_out_return(/*file,line,func,ret*/);
int func_log(/*pAns,pOperator,nparm,ppParm,ope*/);
int func_get_log_parm(/*pAns,nparm,ppParm*/);
int cl_set_log_parmi(/*pInfoParm,argv,iParm,ix*/);
int func_set_log_parm(/*pAns,nparm,ppParm*/);
int func_res_log_parm(/*pAns,nparm,ppParm*/);

/* common */
int  cl_const_ct_mem_get();
int  cl_const_mem_get();
char *cl_const_ct_malloc();
char *cl_const_malloc();
char *cl_tmp_const_malloc();
char *cl_scr_malloc();
char *cl_scr_const_malloc();
char *cl_leaf_malloc();
char *cl_opt_malloc();
char *cl_tmp_const_malloc(/*Len*/);
tdtExtValName *cl_get_sysvar_name(/*char *buf, int len*/);
char *cl_get_pcmd_line(/*Leaf *leaf*/);
Leaf *cl_ret_leaf_pop(/*ProcCT *proc*/);
Leaf *cl_ret_leaf_peek(/*ProcCT *proc*/);
Leaf *cl_ret_leaf_pop_search(/*proc,cida,nn*/);
tdtInfoParm *cl_gx_copy_info();
char *cl_set_script_name_extension(/* char *name, int len */);
tdtRbCtl *cl_tmp_rb_new(/*lBS,lRM*/);
char *cl_tmp_rbset_n(/*pCt, addr*/);
ConstantCt *cl_const_ct_new();
BlockCB *cl_search_block_cb(/*proc,cid,opt*/);
char *cl_conv_msg_check(/*pMsg,rc*/);
char *_to_bulk(/*pInfoParm,iParm,opt*/);
qSubCommand *cl_get_name_attr(/*name, name_len, opt,sel*/);
char *cl_get_format(/*no*/);
/*
char *cl_mem_add();
char *cl_str_add();
*/
tdtObjHead *cl_mk_add_obj0();
tdtObjHead *cl_mk_obj0();
tdtObjHead *cl_gx_get_scr_obj();
tdtObjHead *cl_gx_get_proc_obj();
char *clmemdup(/*s,slen,im*/);
char *clstrdup(/*s,im*/);
char *cl_get_attr_name(/*ipParm*/);
char *strname(/*s,len*/);
char *strtemp(/*s,len*/);
tdtException *cl_get_exception_name(/*name, name_len, opt*/);
char *cl_im_init_set_expand(/*mcat,id,size,extent,buf,im*/);
char *cl_gx_init_set_expand(/*mcat,id,size,extent,buf*/);

long cl_get_data_long(/*pInfoParm*/);
long cl_get_val_long(/*val*/);

long cl_chk_over_flow_long_add(/*Val3,Val1,Val2,name*/);
long cl_chk_over_flow_long_mult(/*Val3,Val1,Val2,name*/);

#endif	/* _CLPROT_H */
