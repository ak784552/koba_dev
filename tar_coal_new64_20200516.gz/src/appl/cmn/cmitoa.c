static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#include "akacommon.h"

int cmn_i_to_a(n, str)
int  n;
char *str;
{
	int i,sign;

	if ((sign = n) < 0) n = -n;

	i = 0;
	do {
		str[i++] = n % 10 + '0';
	} while ((n /= 10) > 0);

	if (sign < 0) str[i++] = '-';

	str[i] = '\0';

	return cmn_reverse(str);
}

int cmn_reverse(str)
char *str;
{
	int c,i,j,len;

	len = strlen(str);
	for (i=0,j=len-1;i<j;i++,j--) {
		c = str[i];
		str[i] = str[j];
		str[j] = c;
	}
	return len;
}

int cmn_mrzcpy(str1,str2,len)
char *str1,*str2;
int len;
{
	int len1,m,mlen;
	char *p1,*p2;

	if (!(p1=str1) || !(p2=str2)) return -1;
	mlen = 0;
	len1 = len;
	p1 += len1;
	*p1 = '\0';
	while (len1 > 0) {
		m = akxqkanjilen2(p2,len1);
		memcpy(p1-m,p2,m);
		len1 -=m;
		p1 -= m;
		p2 += m;
		mlen++;
	}
	return mlen;
}
