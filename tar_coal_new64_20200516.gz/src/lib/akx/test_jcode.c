/*
cc -finput-charset=CP932 -fexec-charset=CP932 test_jcode.c
*/
#include <stdio.h>
main()
{
	printf("�e�X�gý�\n");
	exit(0);
}
