/*
	cc -g test_iconv.c -o test_iconv -liconv
*/
#include <iconv.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
iconv_t iconv_open(const char *tocode, const char *fromcode);

size_t iconv(iconv_t cd,
			 char **inbuf, size_t *inbytesleft,
			 char **outbuf, size_t *outbytesleft);
*/
main ()
{
	char *inptr; 				/* Pointer used for input buffer  */
	char *outptr;				/* Pointer used for output buffer */
	char inbuf[20]="�`�a�b";	/* input buffer */
	char outbuf[80];			/* output buffer  */
	iconv_t cd;					/* conversion descriptor		  */
	size_t inleft;				/* number of bytes left in inbuf  */
	size_t outleft;				/* number of bytes left in outbuf */
	int rc,len;					/* return code of iconv()		 */


	if ((cd = iconv_open("UTF-8","SJIS")) == (iconv_t)(-1)) {
		fprintf(stderr,"Cannot open converter from %s to %s\n","SJIS", "UTF-8");
		exit(8);
	}

	inleft = strlen(inbuf)+1;
	outleft = sizeof(outbuf);
	inptr = inbuf;
	outptr = outbuf;

	rc = iconv(cd, &inptr, &inleft, &outptr, &outleft);
	if (rc == -1) {
		fprintf(stderr, "Error in converting characters. errno=%d\n",errno);
	}
	printf("rc=%d inleft=%d outleft=%d\n",rc,inleft,outleft);
	len=strlen(outbuf);
	outbuf[len]='\0';
	printf("%s\n",outbuf);
	iconv_close(cd);
}
