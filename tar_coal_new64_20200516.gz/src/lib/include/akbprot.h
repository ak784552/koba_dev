/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akbprot.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKBPROT_H
#define _AKBPROT_H

/************************************************
 �֐��錾
 *************************************************/
extern int akb_error_out_level();
extern int akb_print_out_level();
extern int akb_debug_out_level();

extern void akb_crt_err_packet();
extern void akb_crt_err_packet();
extern void akbLogPrint();
extern void akb_log_set_proc_name();
extern char *akb_log_get_proc_name();
extern char *akbMalloc();
extern char *akbRealloc();
extern void akbFree();
extern pSdPacketTable akbMakeXpacket();
extern pSdPacketTable akbXtoFpacket();
extern pSdPacketTable akbsMakeXpacket();
extern pSdPacketTable akbsXtoFpacket();
extern void sock_time();
extern void akbSockTimeOut();
extern void akbBrokenPipe();
extern int  akbSetComTimeOut();
extern int	akbGetTimeOut();
extern int	akbSetTimeOut();
extern char *akb_akb_home();
extern char *akb_akb_home_add();
extern char *akb_get_proc_name();
extern char *akb_log_buf();
extern char *akb_log_set_file_name();
extern char *akb_log_file_path();
extern char *akb_log_time();
extern int  akb_create_pk_data();
extern char *akb_akb_ini();
extern char *akbPrmnName();
extern char *akbNtmnName();
extern char *akb_log_set_dir();
char *akb_get_log_name(/*int log_no*/);
extern void akb_fd_set();
extern void akb_fd_clr();
extern int  akb_fd_isset();
extern void akb_fd_zero();
extern pSdPacketTable akb_packet_tbl_new();
extern int  akbDetach();
extern char *akb_str_error(/*int err_no*/);
extern char *akbLogSetLogName(/*int log_no, char *name*/);
extern tdtLogCtl *akb_log_get_ctl(/*int log_no*/);
extern char *akbPacketNew(/* int iLen*/);
extern char *akbGetStrAddr4(/*struct in_addr in*/);
extern char *akbAkbHelpDir(/* int iReSet*/);

#endif	/* _AKBPROT_H */
