/* static char sccsid[]="%Z% %M% %I% %E% %U%"; */
/********************************************************/
/*														*/
/*	clconst.h											*/
/*														*/
/*		coded by A.Kobayashi 2010.5.28					*/
/*														*/
/*********************************************************/
#ifndef _CLCONST_H
#define _CLCONST_H

/************************************/
/* �X�N���v�g�\����͂Ɏg�p����萔	*/
/************************************/

#define MAX_OPTIONS  30		/* ���s���I�v�V�����̍ő吔 */
#define PM_MAX      512		/* �R�}���h�̃p�����[�^�ő吔 */
#define ON_NUM_MAX   16		/* �n�m�����̍ő吔 */
#define Pr_NM_MAX    40		/* proc�\���̓���proc���p�G���A�� */
#define Var_NM_MAX  128		/* �ϐ����ő咷 */
#define BUFLEN      512		/*  */
#define PR_NM_DEF    32		/* proc���ő咷 */
#define MAX_MEMBER	(PM_MAX-2)/2	/* �\���̒�`�̃����o�[�ő吔 */
#define MAX_PARL      7		/* parl�p�����[�^�ő吔 */

#define MAX_VAR_IX	1024
#define MAX_VAR_IY	64		/* $�ϐ��̏����ő吔 */
#define MAX_VAR_XY	MAX_VAR_IX*MAX_VAR_IY

#define MAX_IGE_IX	16
#define MAX_IGE_IY	32
#define MAX_IGE_XY	MAX_IGE_IX*MAX_IGE_IY

#define MAX_PAS_IX	16
#define MAX_PAS_IY	32
#define MAX_PAS_XY	MAX_PAS_IX*MAX_PAS_IY

#define MAX_LVR_IX	8
#define MAX_LVR_IY	32
#define MAX_LVR_XY	MAX_LVR_IX*MAX_LVR_IY

#define D_USER_INF  68		/*  A.Koba 9.1 */

#define D_MAX_SYS_PUB_VAR	4

#define MAX_LOOP_WHILE			100000
#define D_NAM_MAX_LOOP_WHILE	"MAX_LOOP_WHILE"

#define RECURSION_LIMIT				1000
#define D_NAM_RECURSION_LIMIT		"RECURSION_LIMIT"
#define D_NAM_MAX_RECURSION_COUNT	"MAX_RECURSION_COUNT"
#define RECURSION_CHK_NAME_LEN		PR_NM_DEF*2+sizeof(int)

#define D_NAM_TRNSHID	"TRNSHID"

#define MAX_DO_STACK_DEPTH	1000

#if 1	/* 2017.7.16 Koba */
#define MAX_ARRAY_DIM	12
#else
#define MAX_ARRAY_DIM	3
#endif

#define MAX_STACK	64	/* ((( ...((())) ... )))  ==> 256byte/2 */
#define MAX_PMSTK	64	/* define array x 512 = (1,2,3,4,5,...) */
#define MAX_OBJECT	(MAX_STACK+MAX_PMSTK*3)

#define MAX_CONST_OBJ	5	/* 0:$LOOP_WHILE_MAX=100000 */
							/* 1:$TRNSHID='' */
							/* 2:$TRNSHID=$TRNSHID &+ hostid */
							/* 3:$TRNSHID=replike($TRNSHID,'%____*$','') */

#define MAX_CMD_DA	20
#define MAX_CMD_OBJ	MAX_CMD_DA*6
#define MAX_CMD_OBJ0	64

#define LRU_SCR_MAX	100
#define LRU_SCR_MIN	20

#define MAX_DEC_SCALE	CHAR_MAX
#define MIN_DEC_SCALE	CHAR_MIN
#define D_DEC_PRECISION	30
#define D_DEC_SCALE		15
#define MAX_DEC_PRE1	100
#define MAX_DEC_PRECISION	(USHRT_MAX-4)	/* MPA10W��len��MAX��USHRT_MAX�ł���A���x��MAX��NMPA2-1�̂��� */
#if defined(_LP64)	/* 2023.6.24 */
#define NMPA_LONG_PRE1	8
#else
#define NMPA_LONG_PRE1	16
#endif

#define MAX_PRINT_FLGS	5

#define D_GETCHAR_PRE_READ_LEN	128
#define D_GETCHAR_MIN_READ_LEN	4

#define MAX_ITERATE_LAYER	100

#define MAX_REGEX_MATCH	255

#define MAX_LEN_LABEL	63

/************************************/
/* �n�m�e�[�u���֘A					*/
/************************************/
#define D_PRSEL_NULL	0
#define D_PRSEL_IP		1
#define D_PRSEL_EP		2
#define D_PRSEL_SC		3

#define D_EPNM_INPUT	"input"
#define D_EPNM_INPUTXML	"inputXML"
#define D_EPNM_SELMAIN	"ClSelMain"
#define D_EPNM_USERFUNC	"UserFunc"

/************************************/
/* �t���O�̒l						*/
/************************************/

#define S_ON		(short)1
#define S_OFF		(short)0
#define L_ON		1
#define L_OFF		0
#define C_ON		'1'
#define C_OFF		'0'

/************************************/
/* �R�}���h��͌��ʂ̒萔��`		*/
/************************************/
#define M_COMMENT		'@'				/* �R�����g */
#define M_KUGIRI		';'				/* �R�}���h�I��� */
#define M_QUOTE1		'\''			/* �����萔 */
#define M_QUOTE2		'"'				/* �p�����[�^ */
#define M_QUOTE			M_QUOTE2		/*  */
#define M_QUOTE3		'`'				/* �����R�}���h */
#define M_SPACE			' '				/* ���ߕs�\ */
#define M_PRAGMA		"#*/+-=>.@!?"

#define DEF_OPTC_ICMP	'*'

#define C_CMD_FLAGS		0xff000000		/* �t���O */
#define C_LABEL			0x10000000		/* ���x�� */
#define C_PRAGMA		0x20000000		/* PRAGMA */
#define C_USE_MALTI2	0x00100000		/* cl_def_var_mult2()���g�� */
#define C_DEFINE_PROC	0x00200000		/* define�����ŌĂ΂ꂽ */

#define C_EXEC			0x00000100		/* �葱���ďo */
#define C_INTERACTIVE	0x00000110		/* ��b���[�h */
#define C_CALL			0x00000120		/* �葱���ďo */

#define C_PROC			0x00000200		/* �葱���J�n */
#define C_ENDPROC		0x0000020F		/* �葱���I�� */

#define C_FUNCTION		0x00000210		/* �֐��J�n */
#define C_ENDFUNC		0x0000021F		/* �֐��I�� */

#define C_CLASS			0x00000220		/* �N���X�J�n */
#define C_ENDCLASS		0x0000022F		/* �N���X�I�� */

#define C_EXCEPTION		0x00000230		/* ��O���� */

#define C_SQL			0x00000300		/* �r�p�k�����s */
#define C_MSG			0x00000310		/* Message */

#define C_LOOP			0x00000400		/* �k�n�n�o�̐��� */
#define C_FOR			0x00000401		/* �e�n�q�̐��� */
#define C_NEXT			0x00000411		/* �e�n�q�̏I�� */
#define C_ENDFOR		0x00000421		/* �e�n�q�̏I�� */
#define C_WHILE			0x00000402		/* �v�g�h�k�d�̐��� */
#define C_ENDWHILE		0x00000412		/* �v�g�h�k�d�̏I�� */
#define C_UNTIL			0x00000403		/* �t�m�s�h�k�̐��� */
#define C_ENDUNTIL		0x00000413		/* �t�m�s�h�k�̏I�� */
#define C_ENDLOOP		0x0000040F		/* �k�n�n�o�̐���I�� */
#define C_BREAK			0x0000041F		/* �k�n�n�o�̏I�� */
#define C_CONTINUE		0x00000408		/* �k�n�n�o�̌p�� */
#define C_DO			0x00000420		/* �c�n�̐��� */
#define C_ENDDO			0x0000042F		/* �c�n�̐���I�� */
#define C_LOOP_DO		0x01000000		/* �k�n�n�o�@�c�n�t���O */

#define C_READ			0x00000500		/* �f�[�^�̓ǂݍ��� */

#define C_OUTPUT		0x00000600		/* �p�P�b�g�ɏo�� */

#define C_ONN			0x00000700		/* �n�m�����̒�` */

#define C_IF			0x00000800		/* �����I���̐��� */
#define C_ELSE			0x00000810
#define C_ELSEL			0x00000811
#define C_ELSEIF		0x00000820
#define C_ENDIF			0x0000080F		/* �����I���̐���I�� */

#define C_SWITCH		0x00000850		/* �����I���̐��� */
#define C_CASE		 	0x00000860
#define C_DEFAULT		0x00000870
#define C_ENDSW			0x0000085F		/* �����I���̐���I�� */

#define C_BEXP			0x00000900		/* �Q�����Z�@��� */
#define C_LET			0x00000910		/* ��� */

#define C_RETURN		0x00000A00		/* �ďo���ɕ��A */

/* add chichii 1992/01/09 */

#define C_UNKNOWN		0x00000B00
#define C_END			0x00000B0F
#define C_ERROR			0x00000BF0
#define C_FEND			0x00000C00

/* 1993.9.20 tsuru V3003 */
#define C_LEAVE			0x00000D00		/* �R�}���h�]�� */

#define C_DEFINE		0x00000E00		/* ��` */
#define C_REDEFINE		0x00000E01		/* �Ē�` */
#define C_UNDEFINE		0x00000E02		/* ��`�̉�� */
#define C_DIM			0x00000E03		/* ��` */
/*#define C_TYPEDEF		0x00000E04	*/	/* �^��` */
#define C_IMPORT		0x00000E10		/* Import */
#define C_SLEEP			0x00000F00		/* sleep */

#define C_TRY			0x00001000		/* Try */
#define C_CATCH			0x00001010		/* Catch */
#define C_FINALLY		0x00001020		/* Finally */
#define C_ENDTRY		0x0000100F		/* End Try */
#define C_THROW			0x00001001		/* throw */

#define C_NODE_SCRIPT	0x0000FF00		/* Node Script */
#define C_NODE_IMPORT	0x0000FF01		/* Node Import */
#define C_NODE_DEFINE	0x0000FF02		/* Node Define */

/************************************/
/* �R�}���h�I�v�V����				*/
/************************************/
#define C_OPT_MAIN			0x00000001		/*  */
#define C_OPT_EX_DEF_SCALAR	0x00000002		/*  */

/************************************/
/* �R�}���hTAG�̒萔��`			*/
/************************************/
#define CTAG_PROC		0x01		/* �葱���J�n */
#define CTAG_FUNC		0x02		/* �֐��J�n */
#define CTAG_CLASS		0x04		/* �N���X�J�n */

/************************************/
/*	�T�u�R�}���h�̒萔��`			*/
/************************************/
/* LET */
#define CS_OPTIONS		1
#define CS_OPTION		2
#define CS_SHIFT		3
#define CS_CONTINUE		4
#define CS_PRINT		5
#define CS_EXIT			6
#define CS_INTERACTIVE	7
#define CS_LOGPARM		8
#define CS_GLOBAL		9
#define CS_LOCAL		10
#define CS_PRIVATE		11
#define CS_CONST		12
#define CS_MAPPEDARRAY	13
#define CS_ARRAY		14
#define CS_TRY_EXIT		15
#define CS_ATTR			16
#define CS_TYPE			17
#define CS_VAR			18
#define CS_ECHO			19
#define CS_AS			20
#define CS_IN			21
#define CS_EACH			22
#define CS_SHARED		23
#define CS_TO			24
#define CS_STEP			25
#define CS_LPRINT		26
#define CS_DUMP			27
#define CS_IP			28
#define CS_EP			29
#define CS_SC			30
#define CS_SM			31
#define CS_DO			32
#define CS_THEN			33
#define CS_STATIC		34
#define CS_PUBLIC		35
#define CS_PRINTF		36
#define CS_LPRINTF		37
#define CS_BREAK		38
#define CS_EXPORT		39
#define CS_REDIRECT		40
#define CS_SH			41
#if 1	/* 2023.2.25 */
#define CS_DEFINE		42
#define CS_SCALAR		43
#endif
#define CS_COMPLEX		44
#define CS_IMPLICIT		45
#define CS_GOTO			46
#define CS_EXTENDS		0x100

/****************************/
/*	LOOP KIND				*/
/****************************/
#define D_LOOP_NORMAL	1
#define D_LOOP_WHILE	2
#define D_LOOP_EACH		3
#define D_LOOP_FOR		4
#define D_LOOP_UNTIL	5

#define D_SWITCH_CASE		11
#define D_SWITCH_DEFAULT	12

#define D_TRY_WITH		21

/****************************/
/*	EXEC OPTION				*/
/****************************/
#define D_EX_OPT_TRYPASS		"TRYPASS"
#define D_EX_OPT_NOTRYPASS		"NOTRYPASS"

#define D_EX_OPT_N_NDEF			1
#define D_EX_OPT_N_EXP			2
#define D_EX_OPT_N_TEXT_IO_CRLF	3
#define D_EX_OPT_N_NO_EXP		4
#define D_EX_OPT_N_NO_ELM_LIST	5
#define D_EX_OPT_N_IMPORT_POS	6
#define D_EX_OPT_N_OCUR_ERROR	7
#define D_EX_OPT_N_SRCH_UFUNC	8
#define D_EX_OPT_N_SCRIPT_CODE	9
#define D_EX_OPT_N_VAR_SCOPE	10
#define D_EX_OPT_N_DISP_SCAL	11
#define D_EX_OPT_N_DEC_4SHA5	12
#define D_EX_OPT_N_PRINT_FORM	13
#define D_EX_OPT_N_MSG_LANG		14
#define D_EX_OPT_N_ARRAY_INDEX	15
#define D_EX_OPT_N_DEC_OVR_UNDR	16
#define D_EX_OPT_N_CONV_CONST_N	17
#define D_EX_OPT_N_SRCH_RET_POS	18
#define D_EX_OPT_N_DATE_FORMAT	19
#define D_EX_OPT_N_DISP_LEN_FLT	20
#define D_EX_OPT_N_IO_DATA_TYPE	21
#define D_EX_OPT_N_OPE_ARRAY	22
#define D_EX_OPT_N_ASSIGN_EXVAR	23
#define D_EX_OPT_N_OPTMZ_IF_EXP	24
#define D_EX_OPT_N_REDIRECT		25
#define D_EX_OPT_N_NOT_OPTIMIZE	26
#define D_EX_OPT_N_ROOP_OVER	27
#define D_EX_OPT_N_ROOP_ABALE	30

/********************************/
/* �X�N���v�g�e�[�u����`		*/
/********************************/

#define DEF_SCRPATH			"SCRIPTPATH"	/* Script File Search Path 94.1.4 Koba */
#define DEF_CMDSCRIPT		"DSCMDSCRIPT"	/* Command to Script file name */
#define DEF_HOME			"HOME"			/* User Home Directory */
#define DEF_SCREXTENSION	"SCREXTENSION"	/* Script File Extension */

#define SCR_EXTENSION		"cl"

/********************************/
/* �X�e�[�^�X��`				*/
/********************************/

#define COM_PR		0x80		/* �R�}���h������ */
#define UPD_PR		0x40		/* �X�V������ */
/*#define RTN_PR		0x20*/		/* ���^�[���҂��� */
#define SHT_PR		0x10		/* Shut flag */
#define RLL_BK		0x08		/* Rollback process */
#define NEW_SC		0x08		/* New Script */
/*#define SCR_PR		0x04*/		/* �X�N���v�g���� */
#define FST_PR		0x02		/* fshut flag */

#define SHT_CM		0x02		/* shut command */

#define SCR_RD		0x01		/* �X�N���v�g�ǂݍ��ݒ� */
#define SCR_RO		0x08		/* �X�N���v�g��݂��݂��イ  */
#define SCR_EX		0x02		/* �X�N���v�g���s�� */
#define SCR_ED		0x04		/* �X�N���v�g�I�� */
#define TRY_EXIT	0x10		/* TRY EXIT�� */

/* 1993.9.20 tsuru V3003 */
#define SCR_LV		0x40		/* �k�d�`�u�d���s�� */

#define SEL_ED		0x04		/* kensaku		*/

#define FNC_PR		0x01		/* proc.ptype */
#define LOP_PR		0x02		/* proc.ptype ���[�v������ */
#define SCR_PR		0x04		/* proc.ptype �X�N���v�g���� */
#define RET_PR		0x10		/* proc.ptype RETURN������ */
#define RTN_PR		0x20		/* proc.ptype ���^�[���҂��� */
#define FUN_PR		0x40		/* proc.ptype node_control�ɖ߂�֐����s�� */
								/* proc.pFlag2 ���݂̂̃R�}���h�̎����s */
#define BRK_PR		0x08		/* proc.ptype BREAK������ */
#define GR3_PR		0x80		/* proc.ptype ON��proc-3������ */
#define UFN_PR		0x80		/* proc.ptype ���[�U�֐����s��(set�̂�) */

#define D_PFLAG_EXCEPTION	0x02	/*  */
#define D_PFLAG_EXCEP_RUN	0x04	/*  */
#define D_PFLAG_CONSTRUCT	0x08	/*  */
#define D_PFLAG_NO_FREE		0x10	/* cl_er_lk_proc_ct()��proc��Free()���Ȃ� */
#define D_PFLAG_DEF_CLASS	0x20	/*  */
#define D_PFLAG_PARM_COPY	0x80	/* �p�����[�^�ϐ��́A�R�s�[���g���Ă���(main proc) */
#define D_PFLAG_STATIC		0x40	/*  */

#define D_PFLAG2_ALC_HDNM	0x01	/* alloc HereDoc_nm */
#define D_PFLAG2_SET_STDIN	0x01	/* set stdin  first */
#define D_PFLAG2_SET_STDOUT	0x02	/* set stdout first */
#define D_PFLAG2_SET_STDERR	0x04	/* set stderr first */
#define D_PFLAG2_NOT_CLOSE	0x10	/* not close when HereDoc EOF */
#define D_PFLAG2_DEL_TAB	AKX_TRIM_DEL_TAB	/* 0x20 '-' del tab   HereDoc */
#define D_PFLAG2_DEL_SPACE	AKX_TRIM_DEL_SPACE	/* 0x40 '=' del space HereDoc */
#define D_PFLAG2_STDOUT2MEM	D_LOG_FLG_STDOUT2MEM
#define D_PFLAG2_UNUSE_RED	0x80
#define D_RED_PFLAG2_FILE	0x800
#define D_PFLAG2_HEREDOC_OPT (D_PFLAG2_NOT_CLOSE | D_PFLAG2_DEL_TAB | D_PFLAG2_DEL_SPACE | D_RED_PFLAG2_FILE)

#if 1	/* 2024.3.3 */
#define D_SC_PFLAG2_LOCAL		0x10	/* define local */
#define D_SC_PFLAG2_PRIVATE		0x20	/* define private */
#define D_SC_PFLAG2_PUBLIC		0x01	/* define public */
#define D_SC_PFLAG2_GLOBAL		0x02	/* define global */
#define D_SC_PFLAG2_EXTERN		0x03	/* define global or public */
#define D_SC_PFLAG2_NO_LOCAL	0x23	/* define global or public or private */
#define D_SC_PFLAG2_IMPORTMODE	0x04	/* leaf import mode */
#endif

#define D_EXCEPT_TRY		1		/*  */
#define D_EXCEPT_CATCH		2		/*  */
#define D_EXCEPT_RUN		3		/*  */

#define D_NOT_CLOSE_CHAR_MARK	'!'	/* not close when HereDoc EOF */

#define D_ENV_NAM_SHELL				"SHELL"
#define D_ENV_VAL_SHELL_CSH			"csh"
#define D_ENV_NAM_TERM				"TERM"
#define D_ENV_VAL_TERM_CYGWIN		"cygwin"
#define D_ENV_NAM_MACHTYPE			"MACHTYPE"
#define D_ENV_VAL_MACHTYPE_X86_32	"i686"

#define D_CSH_STDERR2STDOUT1		">&"
#define D_CSH_STDERR2STDOUT2		">& /dev/tty"
#define D_BASH_STDERR2STDOUT1		"2>&1"
#define D_BASH_STDERR2STDOUT2		D_BASH_STDERR2STDOUT1

/********************************/
/*								*/
/********************************/
#define GRPFRMHEAD		17			/* �O���[�v�m�[�h�w�b�_�� */
#define DTFRMHEAD		12			/* �f�[�^�m�[�h�w�b�_��   */
#define FRFRMHEAD		2 			/* �f�[�^�m�[�h�w�b�_��   */
#define FIELDLEN		5
#define STD_MAX			256
#define STD_LEN			2
#define EXT_LEN			6
#if 0
#define D_ACC_EXT		0x00		/* �g���`��		*/
#define D_ACC_STD		0x01		/* �W���`��		*/
#define D_ACC_CHAR		0x01		/* ���x(u char)	*/
#define D_ACC_SHORT		0x02		/* ���x(short int)	*/
#define D_ACC_LONG 		0x03		/* ���x(long int)	*/
#endif
#define PARAMETER		1			/* �ϐ�			*/
#define CONSTANT_CHR	2			/* �����萔		*/
#define CONSTANT_NUM	3			/* �����萔 	*/
#define SYSVAR			4			/* �V�X�e���ϐ�	*/
#define NAME_CONST		5			/* ����			*/
#define SEPARATOR		6			/* ��؂蕶��	*/
#define CONSTANT_CMD	7			/* �����萔		*/
#define ETC_ALL			99			/* ���̑�	*/
#define NULL_PARM		100			/* �m�t�k�k�p�����[�^	*/
#define MATH			11			/* �Z�p���Z		*/
#define COMP			12			/* ��r���Z		*/
#define LOGICAL			13			/* �_�����Z		*/
#define STRING 			14			/* moji���Z		*/
#define IS 				15			/* is  ���Z		*/
#define TO 				16			/* to  ���Z		*/
#define FUNCTION		17			/* function���Z	*/
#define USER_PGM		18			/* user program���Z	*/
#define FUNCMATH		19			/* math function���Z*/
#define FUNCCAST		20			/* cast���Z	*/
#define FUNCFILE		21			/* file function���Z*/
#define FUNCLOG			22			/* log function���Z */
#define AGGREGATE		23			/* �W�����Z			*/
#define FUNC_OPE		24			/* ���Z�q�Ŏ��s��	*/

#define D_CNBD_SIZE  8192		/* CnCB BD size */
#define D_BULK_TYPE  2

#define D_GX_OPT_STORE			0x0001			/*   */
#define D_GX_OPT_STORE_CHK		0x0002			/*   */
#define D_GX_OPT_SET_LOCAL		0x0004			/*   */
#define D_GX_OPT_REDEFINE		0x0008			/*   */
#define D_GX_OPT_SET_ADDR		0x0010			/*   */
#define D_GX_OPT_GET_ADDR		0x0020			/*   */
#define D_GX_OPT_SET_PUBLIC		0x0040			/*   */
#define D_GX_OPT_SET_PRIVATE	0x0080			/*   */
#define D_GX_OPT_NOEROUT_NDEF	0x0100			/*   */
#if 1	/* 2021.8.28 */
#define D_GX_OPT_NOHOLD_NDEF	0x0200			/*   */
#else
#define D_GX_OPT_CHECK_DEFINE	0x0200			/*   */
#endif
#define D_GX_OPT_NOALLOC_INDX	0x0400			/*   */
#define D_GX_OPT_SET_ARRAY		0x0800			/*   */
#define D_GX_OPT_ALC_MASK		0x7000			/*   */
#define D_GX_OPT_ALC_LEAF		0x0000			/*   */
#define D_GX_OPT_ALC_CONST		0x1000			/*   */
#define D_GX_OPT_ALC_SCR		0x2000			/*   */
#define D_GX_OPT_ALC_TMP		0x3000			/*   */
#define D_GX_OPT_ALC_MALLOC		0x4000			/*   */
#define D_GX_OPT_ALC_INTRACT	0x5000			/*   */
#define D_GX_OPT_ALC_FUN_PR		0x7000			/*   */
#define D_GX_OPT_NO_USE_OBJ		0x8000			/*   */
#define D_GX_OPT_SET_PROC_OBJ	0x010000		/*   */
#define D_GX_OPT_PARMINFO2		0x020000		/*   */
#define D_GX_OPT_SET_CONST		0x040000		/*   */
#define D_GX_OPT_GET_RANGE		0x080000		/*   */
#define D_GX_OPT_NOERROR_NDEF	0x100000		/*   */
#define D_GX_OPT_SET_STATIC		0x200000		/*   */
#define D_GX_OPT_SET_GLOBAL		0x400000		/*   */
#define D_GX_OPT_SET_IMPORT		0x800000		/*   */
#define D_GX_OPT_GET_DEF_ATTR	0x01000000		/*   */
#define D_GX_OPT_SET_COMPLEX	0x02000000		/*   */
#define D_GX_OPT_MULTI_BYTE		0x02000000		/*   */
#define D_GX_OPT_SET_CLEAR		0x04000000		/*   */
#define D_GX_OPT_PROC_NAME		0x08000000		/*   */
#define D_GX_OPT_SET_RATIONAL	0x08000000		/*   */
#define D_GX_OPT_DEFINE			0x10000000		/*   */
#define D_GX_OPT_INFO_MODE		0x20000000		/*   */
#if 1	/* 2023.2.25 */
#define D_GX_OPT_SCALAR			0x20000000		/*   */
#endif
#define D_GX_OPT_SET_MAPPED		0x40000000		/*   */
#if 1	/* 2024.7.10 */
#define D_GX_OPT_NOERROR_NDAT	0x80000000		/*   */
#define D_GX_OPT_SET_EXPORT		0x00000000		/*   */
#else
#define D_GX_OPT_SET_EXPORT		0x80000000		/*   */
#endif
#define D_GX_OPT_SET_SCOPE		(D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_GLOBAL | D_GX_OPT_SET_PUBLIC | D_GX_OPT_SET_PRIVATE)
#define D_GX_OPT_USE_ATTR		0x5C5C5C00		/*   */

#define D_MAX_SCOPE				4
#define D_LEN_SCOPE_MARK		3
#define D_STR_MARK_GLOBAL		"<G>"
#define D_STR_MARK_PUBLIC		"<P>"
#define D_STR_MARK_PRIVATE		"<S>"
#define D_STR_MARK_LOCAL		"<L>"
#define D_STR_MARK_INSTANCE		"<I>"

#define D_STR_NAME_GLOBAL		"GLOBAL"
#define D_STR_NAME_PUBLIC		"PUBLIC"
#define D_STR_NAME_PRIVATE		"PRIVATE"
#define D_STR_NAME_LOCAL		"LOCAL"
#define D_STR_NAME_STATIC		"STATIC"
#define D_STR_NAME_NULL			AKX_NAME_UNULL

#define D_DATA_MALLOC		0x80		/* malloc data		*/
#define D_DATA_LPOSDATA		0x40		/* data to lPos   */
#define D_DATA_INDEX_FREE	0x20		/* able free �z��v�f,�\���̃����o */
#define D_DATA_ARRAY_INDEX	0x10		/* array index   */
/*#define D_DATA_COPIED_PROC	0x08*/		/* copied proc only class or instance */
#define D_DATA_CLEAR_PROC	0x08		/* can clear proc only class or instance */
#define D_DATA_INDEX_TMP	0x08		/* index tmp memory  */
#define D_DATA_DATA_FREE	0x04		/* able free data */
#define D_DATA_ORG_PROC		0x02		/* original instance proc */
#define D_DATA_UNSIGNED		0x02		/* unsigned */
/*#define D_DATA_NO_FREE_PROC	0x01*/		/* no free proc */
#define D_DATA_IMAGE		0x01		/* ���� */

#define D_DATA_ID_UNDEF		'\0'		/*   */
#define D_DATA_ID_DATA		' '			/* Normal Data   */
#define D_DATA_ID_MAPEDARY	'A'			/* Mapped Array  */
#define D_DATA_ID_ARRAY		'R'			/* Normal Array  */
#define D_DATA_ID_FUNCTION	'F'			/* Function  */
#define D_DATA_ID_STOREVAR	'S'			/*   */
#define D_DATA_ID_UNDEFVAR	'U'			/* Undefined Variable */
#define D_DATA_ID_LIST		'L'			/* List  */
#define D_DATA_ID_TYPE		'P'			/* Type  */
#define D_DATA_ID_STRUCT	'T'			/* Struct  */
#define D_DATA_ID_CLASS		'C'			/* Class */
#define D_DATA_ID_INSTANCE	'I'			/* Class Instance */
#define D_DATA_ID_CLMETHOD	'M'			/* Class Method */
#define D_DATA_ID_PROC		'O'			/* Proc */
#define D_DATA_ID_PNAME		'E'			/* Parameter Name */
#define D_DATA_ID_NARABI	'N'			/* Narabi shiki  */
#define D_DATA_ID_RANGE		'G'			/* RANGE only in iterate_info */

#define D_AUX0_ZOK_MASK		DEF_ZOK_MASK	/* DATA ATTR MASK 0x0f	*/
#define D_AUX0_ZOK_DTYP		DEF_ZOK_DTYP	/* DATA TYPE MASK 0x07	*/
#define D_AUX0_ZOK_DATA		DEF_ZOK_DATA	/* 0x80 �����E����		*/
#define D_AUX0_TYPE_ARRAY	AKX_TYPE_ARRAY	/* 0x15(21) TYPE ARRAY		*/
#define D_AUX0_TYPE_MAPPED	AKX_TYPE_MAPPED	/* 0x16(22) TYPE MAPPEDARRAY*/
#define D_AUX0_TYPE_STRUCT	AKX_TYPE_STRUCT	/* 0x17(23) TYPE STRUCT		*/
#define D_AUX0_VAR_EXPORT	0x40		/* 		*/

#define D_AUX1_VAR_SCOPE	0x0f		/* var scope mask		*/
#define D_AUX1_LOCAL_VAR	0x01		/* local var data		*/
#define D_AUX1_PRIVATE_VAR	0x02		/* private var data		*/
#define D_AUX1_PUBLIC_VAR	0x04		/* public var data		*/
#define D_AUX1_GLOBAL_VAR	0x08		/* global var data		*/
#define D_AUX1_HASHED_NAME	0x10		/* hashed name			*/
#define D_AUX1_FUNC_ARRY	0x20		/* function or array	*/
#define D_AUX1_POINTER		0x40		/* &					*/
#define D_AUX1_PROTECTED	0x80		/* cannot store data	*/

#define D_AULN_NO_AL_LPOS	0x0001		/* no malloc array name */
#define D_AULN_PARMINFO2	0x0002		/*   */
#define D_AULN_RANGE_DATA	0x0004		/*   */
#define D_AULN_IGN_CASE		0x0008		/*   */
#define D_AULN_RATIONAL		0x0008		/*   */
#define D_AULN_NULL_VALUE	0x0010		/* NULL */
#define D_AULN_FIND_METHOD	0x0020		/* used only id='M'  */
#define D_AULN_COMPLEX_DATA	0x0020		/* complex */
#define D_AULN_NAME_DATA	0x0040		/*   */
#define D_AULN_DATA_NARABI	0x0080		/*   */
#define D_AULN_UNDEF_ARRAY	0x0100		/*   */
#define D_AULN_NULL_PARM	0x0200		/* null parameter   */
#define D_AULN_NONE_PARM	D_AULN_NULL_PARM		/*   */
#define D_AULN_SET_POS_LEAF	0x0400		/* use function only */
#define D_AULN_RAT_YAKUBUN	0x0400		/* �L���� �񕪍ς� */
#define D_AULN_FILE_POINTER	0x0800		/*   */
#define D_AULN_OVERFLOW		0x1000		/*   */
#if 1	/* 2021.6.16 */
#define D_AULN_RANGE_INTVAL	0x2000		/* have range interval. D_AULN_RANGE_DATA�ƃy�A */
										/* ����݂̂̂Ƃ��́A�W�J�f�[�^�̊J�n�ƏI�� */
#else
#define D_AULN_UNDERFLOW	0x2000		/*   */
#endif
#define D_AULN_DOT_NAME		0x4000		/*   */
#define D_AULN_HOLD_ERROR	0x8000		/*   */

#define D_ATR1_NO_MALLOC	0x08		/* no malloc data	*/

#define D_LEAF_INEFFECTIVE	0x01		/*  */
#define D_LEAF_CACHED		0x02		/*  */
#define D_LEAF_IMPORTMODE	0x04		/*  */
#define D_LEAF_DEF_EXECUTED	0x08		/* 2021.7.1 */

#define D_SCRPT_NEW_LEX		0x10		/*  */
#define D_SCRPT_INTERACTIVE	0x20		/*  */
#define D_SCRPT_MEMORY		0x40		/*  */
#define D_SCRPT_FUNC		0x80		/*  */

#define D_CLST_OPT_COMMAND		0x000100	/*  */
#define D_CLST_OPT_USE_DTYPE	0x800000	/*  */
#define D_CLST_OPT_DTYPE		0x0f0000	/*  */

#define D_OPT_ALC_LEAF		0			/*   */
#define D_OPT_ALC_CONST		1			/*   */
#define D_OPT_ALC_SCR		2			/*   */
#define D_OPT_ALC_TMP		3			/*   */
#define D_OPT_ALC_MALLOC	4			/*   */
#define D_OPT_ALC_INTRACT	5			/*   */
#define D_OPT_ALC_FUN_PR	7			/*   */

#define D_CMND_PARM_LINE	0			/* �R�}���h�ƃ��x�������� */
#define D_SCR_FULLNAME		1			/*   */
#define D_CMND_NAME			2			/*   */
#define D_SCRP_OBJ0_USED	3			/*   */
#define D_PROC_OBJ0_USED	4			/*   */
#define D_DOWHILE_TOP_LEAF	5			/*   */
#define D_LEAF_LABEL		6			/*   */

#define D_MAX_IPARM		5			/*   */
#define D_IPARM_ATTR	0			/*   */
#define D_IPARM_SIZE	1			/*   */
#define D_IPARM_PRE		2			/* dtcode when char  */
#define D_IPARM_SCA		3			/*   */
#define D_IPARM_FLAG	4			/* iParm[4]==iAttr[2] */

#define D_MAX_IATTR		3			/*   */
#define D_IATTR_ATTR	0			/*   */
#define D_IATTR_SIZE	1			/*   */
#define D_IATTR_ULI		2			/*   */

#define D_PARM_FLAG_BMODE	0x000001			/*  */
#define D_PARM_FLAG_FILE	0x010000			/*  */
#define D_PARM_FLAG_GETCHAR	0x020000			/*  */

#define D_REP_ALC_MASK			D_GX_OPT_ALC_MASK	/* 0x7000 */
#define D_REP_IGN_OUT_DATA		0x0010		/* ignore data of pInfoParmO */
#define D_REP_CHK_UNDEF_IN		0x0020		/* check undef of pInfoParmI */
#define D_REP_OPT_CPY_MASK		0x0003		/*  */
#define D_REP_OPT_CPY_ONLY		0			/*  */
#define D_REP_OPT_CPY_MALC		1			/*  */
#define D_REP_OPT_CPY_M_F_OUT	2			/*  */
#define D_REP_OPT_SEL_MASK		0x0f00		/* �����I���}�X�N */
#define D_REP_OPT_SEL_CNVT		0x0100		/* �f�[�^�^�C�v�Œ莞�̕ϊ��̂� */
#define D_REP_OPT_SEL_RCSV		0x0200		/* �ċArep�̂� */
#define D_REP_OPT_SEL_DATA		0x0400		/* data rep�̂� */
/*#define D_REP_ALC_MASK		0x7000		*/
#define D_REP_OPT_DATA_MODE		0x080000	/* data mode	add 2022.9.18 */
#define D_REP_OPT_DEF_ONLY		0x010000	/* data mode�łȂ���΁A��`�̂݃R�s�[����	add 2022.9.19 */
#define D_REP_OPT_ASIGN			0x020000	/* �������	add 2022.9.22 */
#define D_REP_OPT_LN_DCOPY		0x040000	/* L,N�̂Ƃ��Api_data���R�s�[���� */
#define D_REP_OPT_AR_NCOPY		0x100000	/* A,R�̂Ƃ��Api_data���R�s�[���Ȃ� */

#define D_PRN_OPT_NGEN	0x4000	/* ��ʃf�[�^�ȊO���G���[�ɂ��Ȃ� */
#define D_PRN_OPT_LTGT	0x8000	/* enclosed in angle brackets */

#define D_COMP_OPT_IGN_CASE	0x01	/* Ignore case */
#define D_COMP_OPT_IGN_HZ	0x02	/* Ignore Hankaku/Zenkaku */
#define D_COMP_FUN_LIKE		0		/* LIKE */
#define D_COMP_FUN_IGNORE	0x01	/* Ignore case */
#define D_COMP_FUN_INSTR	0x00	/* INSTR */
#define D_COMP_FUN_IN		0x08	/* IN */
#define D_COMP_FUN_REVERCE	0x20	/* 0x02 -> 0x20 */
#define D_COMP_OPT_NEW_LEX	0x04
#define D_COMP_OPT_NOT_SET	0x8000

/* �Q�U ����֐����I�v�e�B�}�C�Y���Ȃ� */
#define D_NOPTIMIZE_IIF		0x01	/* IIF()	*/
#define D_NOPTIMIZE_NVAL	0x02	/* NVAL()	*/
#define D_NOPTIMIZE_NULLIF	0x04	/* NULLIF()	*/
#define D_NOPTIMIZE_NSVAL	0x08	/* NSVAL()	*/
#define D_NOPTIMIZE_NDEF	0x10	/* NDEF()	*/
#define D_NOPTIMIZE_AND		0x20	/* AND()	*/
#define D_NOPTIMIZE_OR		0x40	/* OR()		*/
#define D_NOPTIMIZE_ALL		0x7F

/****************************/
/*	for _get_line_pat()		*/
/****************************/
#define D_LINE_PAT_IGN_CASE	0x0100	/* ignore case */
#define D_LINE_PAT_IGN_HAZE	0x0200	/* ignore Hankaku/Zenkaku */
#define D_LINE_PAT_GLOBAL	0x0400	/* global */
#define D_LINE_PAT_ONLY		0x0800	/* only */
#define D_LINE_PAT_REVERSE	0x1000	/* reverse */
#define D_LINE_PAT_LNGMATCH	0x2000	/* longest match */

/************************/
/*	System Class Name	*/
/************************/
#define D_SYS_CLASS_SYSTEM	"System"
#define D_SYS_CLASS_FILE	"SysFile"
#define D_SYS_CLASS_MATH	"SysMath"

/************************/
/*		SQL				*/
/************************/

#define MAXSQLCMD		0x7fffffff		/* SQL�̃p�����[�^�n�� �ő咷 */
#define SQLFILE			"sqlcmd.doc"
#define RSLTFILE		"_@@_"			/* �������ʃt�@�C���ȗ����� */
#define D_DOCHOST_FILE	"mydchost"		/* my host ID for DOC_MNG DAEMON */
#define AREA_ID_SIZE	4				/* �f�[�^�i�[�G���AID�� */
#define HOST_ID_SIZE	4				/* HOST_ID�� */
/*** make cat(join) condition table ***/
#define SQL_PARMNUM			4			/* SQL �R�}���h�p�����[�^�� */ 
#define READ_PARMNUM		2			/* READ �R�}���h�p�����[�^�� */ 
#define JNT_TABLE_AREAID	"JOIN"		/* ���������i�[�u���p�������ʊi�[�G���AID */
#define ITEM_AREAID			"ITEM"		/* ���ڂ̌������ʊi�[�G���AID	*/

#define D_KOUMOKU_SIZE	7				/* kensaku koumoku size */
#define BUNKEN_GR		"DOCMbunkenGR"
#define BUNKEN_SQL		"DOCMbunkenSQL"
#define ESCAPE_CODE		'`'

/************************/
/*		DATE_TYPE		*/
/************************/
#define D_LEN_DATE	14
#define D_UNX_DATE_FORMAT	"%Y/%m/%d %H:%M:%S"
#define D_SQL_DATE_FORMAT	"YYYY/MM/DD HH24:MI:SS"
#define D_LOG_DATE_FORMAT	"(YYYY-MM-DD HH:MI:SS.U P DY DDD)"
#define D_NAM_UNX_DATE_FORMAT	"UNIX_DATE_FORMAT"
#define D_NAM_SQL_DATE_FORMAT	"SQL_DATE_FORMAT"

/************************************/
/*	FUNCTION NAME					*/
/************************************/
#define D_FUC_NO_CHK_NULL	0x8000
#define D_FUC_RET_CODE		0x4000
#define D_FUC_1st_CHK_NULL	0x2000	/* �ŏ��̈���+�����`�F�b�N���� */
#define D_FUC_RET_ZERO		0x1000
#define D_FUC_IS		10001
#define D_FUC_MOD		10002
#define D_FUC_TO_NUMBER	10003
#define D_FUC_LIKE		10004
#define D_FUC_MAX		10005
#define D_FUC_MIN		10006
#define D_FUC_ABS		10007
#define D_FUC_LEN		10008
#define D_FUC_LENB		10009
#define D_FUC_INSTR		10010
#define D_FUC_TO		10011
#define D_FUC_REP		10012
#define D_FUC_CONDAS	10013
#define D_FUC_SUBSTR	10014
#define D_FUC_CONCAT	10015
#define D_FUC_GETARGS	10016
#define D_FUC_TRIM		10017
#define D_FUC_STRINGS	10018
#define D_FUC_LEFT		10019
#define D_FUC_RIGHT		10020
#define D_FUC_FOPEN		10021
#define D_FUC_FCLOSE	10022
#define D_FUC_FGETLINE	10023
#define D_FUC_FPUTLINE	10024
#define D_FUC_FELREAD1	10025
#define D_FUC_FELWRITE	10026
#define D_FUC_UNLINK	10027
#define D_FUC_POPEN		10028
#define D_FUC_PCLOSE	10029
#define D_FUC_GETLINE	10030
#define D_FUC_PUTLINE	10031
#define D_FUC_ELREAD1	10032
#define D_FUC_ELWRITE	10033
#define D_FUC_EDIT		10034
#define D_FUC_ILIKE		10035
#define D_FUC_INISTR	10036
#define D_FUC_INRSTR	10037
#define D_FUC_INIRSTR	10038
#define D_FUC_CHR		10039
#define D_FUC_SKIP_OPT	10040
#define D_FUC_ASC		10041
#define D_FUC_TO_BULK	10042
#define D_FUC_TO_BULKS	10043
#define D_FUC_REPLIKE	10044
#define D_FUC_SHSBS		10045
#define D_FUC_OPENDIR	10046
#define D_FUC_READDIR	10047
#define D_FUC_CLOSEDIR	10048
#define D_FUC_STAT		10049
#define D_FUC_GETWORD	10050
#define D_FUC_EVAL		10051
#define D_FUC_NVAL		10052
#define D_FUC_NDEF		10053
#define D_FUC_DOL		10054
#define D_FUC_IGE		10055
#define D_FUC_PAS		10056
#define D_FUC_TO_FUNC	10057
#define D_FUC_SET_ARRAY	10058
#define D_FUC_COUNT		10059
#define D_FUC_LIST		10060	/* �R�}���h���ƂɃ`�F�b�N���� */
#define D_FUC_SET_LIST	10061
#define D_FUC_FIRST		10062
#define D_FUC_REST		10063
#define D_FUC_CONS		10064
#define D_FUC_LIST_REF	10065
#define D_FUC_INDEX		10066
#define D_FUC_ARRAY_CPY	10067
#define D_FUC_ARRAY_CLR	10068
#define D_FUC_ARRAY_CMP	10069
#define D_FUC_ARRAY_BXP	10070
#define D_FUC_SQRT		10071
#define D_FUC_SIN		10072
#define D_FUC_COS		10073
#define D_FUC_TAN		10074
#define D_FUC_ATAN		10075
#define D_FUC_LOG		10076
#define D_FUC_LOG10		10077
#define D_FUC_EXP		10078
#define D_FUC_POWER		10079
#define D_FUC_RAND1		10080
#define D_FUC_SRAND1	10081
#define D_FUC_CBRT		10082
#define D_FUC_SINH		10083
#define D_FUC_COSH		10084
#define D_FUC_TANH		10085
#define D_FUC_ATANH		10086
#define D_FUC_RINT		10087
#define D_FUC_FLOOR		10088
#define D_FUC_CEIL		10089
#define D_FUC_SUBSTRB	10091
#define D_FUC_LEFTB		10092
#define D_FUC_RIGHTB	10093
#define D_FUC_REGEX		10094
#define D_FUC_SORT		10095
#define D_FUC_IREGEX	10096
#define D_FUC_FPSTAT	10097
#define D_FUC_FELWRITE1	10098
#define D_FUC_ELWRITE1	10099
#define D_FUC_INLIKE	10100
#define D_FUC_SHELL		10101
#define D_FUC_SYSLOG	10102
#define D_FUC_LOGOUT	10103
#define D_FUC_NOFREE	10104
#define D_FUC_SHUTCTL	10105
#define D_FUC_EXIT		10106
#define D_FUC_SETENV	10107
#define D_FUC_UNSETENV	10108
#define D_FUC_PUTENV	10109
#define D_FUC_GETENV	10110
#define D_FUC_GETTIME	10111
#define D_FUC_GETLOGPARM	10112
#define D_FUC_SETLOGPARM	10113
#define D_FUC_RESLOGPARM	10114
#define D_FUC_GETMEMUSED	10115
#define D_FUC_LPRINT	10116
#define D_FUC_PRINT		10117
#define D_FUC_ECHO		10118
#define D_FUC_ARRAY_MAP	10119
#define D_FUC_TIMES		10120
#define D_FUC_XHASH		10121
#define D_FUC_ROUND		10122
#define D_FUC_NEW		10123
#define D_FUC_GETVAL	10124
#define D_FUC_ASCB		10125
#define D_FUC_IN		10126
#define D_FUC_IIN		10127
#define D_FUC_DECODE	10128
#define D_FUC_TO_DATE	10129
#define D_FUC_TO_CHAR	10130
#define D_FUC_CCHAR		10131
#define D_FUC_CINT		10132
#define D_FUC_CFLOAT	10133
#define D_FUC_CDEC		10134
#define D_FUC_CBULK		10135
#define D_FUC_CDATE		10136
#define D_FUC_CVARIANT	10137
#define D_FUC_CIMG		10138
#define D_FUC_DATE_ADD	10141	/* date �֘A */
#define D_FUC_ADD_MONTHS	10142
#define D_FUC_DATE_DIFF	10143
#define D_FUC_LAST_DAY	10144
#define D_FUC_SET_DATE_PART	10145
#define D_FUC_RPAD		10151
#define D_FUC_LPAD		10152
#define D_FUC_RPADB		10153
#define D_FUC_LPADB		10154
#define D_FUC_STR_ADD	10155
#define D_FUC_STR_EXP	10156
#define D_FUC_STR_CONV	10157
#define D_FUC_IIF		10158
#define D_FUC_NSVAL		10159
#define D_FUC_SET_STRUCT	10160
#define D_FUC_PRINTF	10161
#define D_FUC_FPRINTF	10162	/* 2cd���`�F�b�N���� */
#define D_FUC_EEDIT		10163
#define D_FUC_SPLIT		10164
#define D_FUC_ECMD		10165
#define D_FUC_ADD_TO_DATE	10166
#define D_FUC_RANGE		10167
#define D_FUC_LENW		10168
#define D_FUC_REDIRECT	10169
#define D_FUC_SUM		10170
#define D_FUC_AVG		10171
#define D_FUC_ASIN		10172
#define D_FUC_ACOS		10173
#define D_FUC_ATAN2		10174
#define D_FUC_DEC_PRE	10175
#define D_FUC_GETCHAR	10176
#define D_FUC_PUTCHAR	10177
#define D_FUC_FPRINT	10178
#define D_FUC_SPRINT	10179
#define D_FUC_GETC		10180
#define D_FUC_PUTC		10181
#define D_FUC_INREGEX	10182
#define D_FUC_REPREGEX	10183
#define D_FUC_EQ		10184
#define D_FUC_AND		10185
#define D_FUC_OR		10186
#define D_FUC_REPLACE	10187
#define D_FUC_REPCHAR	10188
#define D_FUC_REPSTRS	10189
#define D_FUC_COMPLEX	10190
#define D_FUC_GLIP		10191
#define D_FUC_FFCLOSE	10192
#define D_FUC_GREP		10193
#define D_FUC_HDOCOPEN	10194	/* heredoc open */
#define D_FUC_JISHO		10195
#define D_FUC_PRODUCT	10196
#define D_FUC_IS_NULL	10197
#define D_FUC_IS_UNDEF	10198
#define D_FUC_TO_DNARA	10199
#define D_FUC_RENAME	10200
#define D_FUC_MATRIX_BXP	10201
#define D_FUC_APPEND	10202
#define D_FUC_SSCANF	10203
#define D_FUC_RATIONAL	10204
#define D_FUC_BEEP		10501	/* WinAPI */
#define D_FUC_MSGBOX	10502
#define D_FUC_CHANNEL	11001	/* �ʐM�֘A */
#define D_FUC_MESSAGE	11002

/************************************/
/*	EXTERNAL VARIABLE NAME			*/
/************************************/
#define D_EXV_ERROR		1
#define D_EXV_ERRMSG	2
#define D_EXV_ERRNO		3
#define D_EXV_STRERROR	4
#define D_EXV_TUPLE		5
#define D_EXV_COLUMN	6
#define D_EXV_USERID	7
#define D_EXV_DATE		8
#define D_EXV_TIME		9
#define D_EXV_DATETIME	10
#define D_EXV_HID		11
#define D_EXV_EXCEPTION	12
#define D_EXV_USERINF	13
#define D_EXV_VERSION	14
#define D_EXV_MAKEDATE	15
#define D_EXV_STDIN		16
#define D_EXV_STDOUT	17
#define D_EXV_STDERR	18
#define D_EXV_SCRIPTNAME 19
#define D_EXV_CHAR		20
#define D_EXV_BINARY	21
#define D_EXV_FLOAT		22
#define D_EXV_DECIMAL	23
#define D_EXV_BULK		24
#define D_EXV_DATETYPE	25
#define D_EXV_VARIANT	26
#define D_EXV_INTEGER	27
#define D_EXV_LONG		27
#define D_EXV_DOUBLE	28
#define D_EXV_NULL		29
#define D_EXV_PI		30
#define D_EXV_PROCNAME	31
#define D_EXV_SCRIPTLINE 32
#define D_EXV_M_E		33
#define D_EXV_SYSDATE	34
#define D_EXV_PI2		35
#define D_EXV_M_E2		36
#define D_EXV_SYSCODE	37	/* 0 */
#define D_EXV_EUC		38	/* 1 */
#define D_EXV_SJIS		39	/* 2 */
#define D_EXV_JIS		40	/* 3 */
#define D_EXV_EBCDIC	41	/* 4 */
#define D_EXV_UTF8		42	/* 5 */
#define D_EXV_UNICODE	43	/* 6 */
#define D_EXV_EBCDIK	44	/* 8 */
#define D_EXV_WIDE		45	/* 0x104 �S�p */
#define D_EXV_NARROW	46	/* 0x108 ���p */
#define D_EXV_CHAR_MIN	47
#define D_EXV_CHAR_MAX	48
#define D_EXV_UCHAR_MAX	49
#define D_EXV_SHORT_MIN	50
#define D_EXV_SHORT_MAX	51
#define D_EXV_USHORT_MAX	52
#define D_EXV_INT_MIN	53
#define D_EXV_INT_MAX	54
#define D_EXV_UINT_MAX	55
#define D_EXV_LONG_MIN	56
#define D_EXV_LONG_MAX	57
#define D_EXV_ULONG_MAX	58
#define D_EXV_CODE_TYPE	59
#define D_EXV_UINT		60
#define D_EXV_ULONG		60
#define D_EXV_EOF		61
#define D_EXV_IN_ERROR	62
#define D_EXV_UPPER		63	/* 0x101 �啶�� */
#define D_EXV_LOWER		64	/* 0x102 ������ */
#define D_EXV_PROPER	65	/* 0x103 �擪�啶�����͏����� */
#define D_EXV_HEBON		66	/* 0x110 �S�p�J�i���w�{�������[�}�� */
#define D_EXV_MAX_RECURSION_COUNT	67

/********************************/
/*	IMEDIATE OPERATOR			*/
/********************************/
#define D_IMD_LPAR		1	/* ( */
#define D_IMD_RPAR		2	/* ) */
#define D_IMD_LARR		3	/* [ */
#define D_IMD_RARR		4	/* ] */
#define D_IMD_FUNNC		5	/* func( */
#define D_IMD_PP		14	/* ++ */
#define D_IMD_MM		15	/* -- */
#define D_IMD_NN		16	/* !! */
#define D_IMD_RR		17	/* ~~ */
#define D_IMD_NOT		18	/* ! */
#define D_IMD_REV		19	/* ~ */
#define D_IMD_CAST		20	/* (x) */
#define D_IMD_MUL		21	/* * */
#define D_IMD_DEV		22	/* / */
#define D_IMD_MOD		23	/* %,MOD */
#define D_IMD_PLUS		24	/* + */
#define D_IMD_MINUS		25	/* - */
#define D_IMD_LSHIFT	26	/* << */
#define D_IMD_RSHIFT	27	/* >> */
#define D_IMD_ABS		28	/* ABS */
#define D_IMD_DOT		29	/* . */
#define D_IMD_EXP		30	/* ** */
#define D_IMD_LT		31	/* < */
#define D_IMD_GT		32	/* > */
#define D_IMD_LE		33	/* <= */
#define D_IMD_GE		34	/* >= */
#define D_IMD_EQ		35	/* == */
#define D_IMD_NE		36	/* != */
#define D_IMD_LIKE		37	/* LIKE */
#define D_IMD_MAX		38	/* MAX */
#define D_IMD_MIN		39	/* MIN */
#define D_IMD_AND		41	/* & */
#define D_IMD_XOR		42	/* ^ */
#define D_IMD_RUSHIFT	48	/* >>> */
#define D_IMD_OR		43	/* | */
#define D_IMD_LAND		51	/* && */
#define D_IMD_LOR		52	/* || */
#define D_IMD_QUES		59	/* ? */
#define D_IMD_COLN		60	/* : */
#define D_IMD_STRING	61	/* String */
#define D_IMD_STR_MOD	61	/* MOD */
#define D_IMD_STR_IEQ	61	/* iEQ */
#define D_IMD_STR_INE	61	/* iNE */
#define D_IMD_AND_EQ	71	/* &= */
#define D_IMD_XOR_EQ	72	/* ^= */
#define D_IMD_OR_EQ		73	/* |= */
#define D_IMD_MUL_EQ	81	/* *= */
#define D_IMD_DEV_EQ	82	/* /= */
#define D_IMD_MOD_EQ	83	/* %=,MOD= */
#define D_IMD_PLS_EQ	84	/* += */
#define D_IMD_MNS_EQ	85	/* -= */
#define D_IMD_LSH_EQ	86	/* <<= */
#define D_IMD_RSH_EQ	87	/* >>= */
#define D_IMD_CAT_EQ	88	/* &+= */
#define D_IMD_ASIGN		90	/* = */
#define D_IMD_PUSH1		91	/* PUSH */
#define D_IMD_PUSH2		92	/* PUSH */
#define D_IMD_RANGE		95	/* .. */
#define D_IMD_PNAME		96	/* <== */
#define D_IMD_NAMED		97	/* ==> */
#define D_IMD_CAM		98	/* , */
#define D_IMD_END		99	/* ; */
#define D_IMD_CLASS		101	/* CLASS */
#define D_IMD_PROC		101	/* PROC */

#define LEX_LOG_GROUP	0x00000100

#define LVL_GXCOMPL	150
#define LVL_GXEXOBJ	160
#define LVL_XML	170

/* �X�N���v�g/����/�o�͂̓��{��R�[�h */
#define D_CODE_DFLT_SJIS	CD_DFLT_SJIS	/* S-JIS */
	/* �X�N���v�g */
#define D_CODE_SCRIPT_MASK	CD_SCRIPT_MASK	/* MASK */
#define D_CODE_SCRIPT_SJIS	CD_SCRIPT_SJIS	/* S-JIS */
#define D_CODE_SCRIPT_UTF8	CD_SCRIPT_UTF8	/* UTF-8 */
	/* ���̓f�[�^ */
#define D_CODE_INPUT_MASK	CD_INPUT_MASK	/* MASK */
#define D_CODE_INPUT_SJIS	CD_INPUT_SJIS	/* SJIS */
#define D_CODE_INPUT_UTF8	CD_INPUT_UTF8	/* UTF-8 */
	/* �o�̓f�[�^ */
#define D_CODE_OUTPUT_MASK	CD_OUTPUT_MASK	/* MASK */
#define D_CODE_OUTPUT_SJIS	CD_OUTPUT_SJIS	/* SJIS */
#define D_CODE_OUTPUT_UTF8	CD_OUTPUT_UTF8	/* UTF-8 */

#define FIL_MAX_OBJ		1000
#define FIL_MAX_DA		400
#define FIL_MAX_TREE	1000
#define FIL_MAX_NEST	400

#endif	/* _CLCONST_H */
