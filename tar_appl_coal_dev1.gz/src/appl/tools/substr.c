#include <stdio.h>
int main (argc,argv)
int   argc;
char *argv[];
{
	int c,i,is,ie;
	char *p,*fname;
	FILE *fp;

	is = 1;
	ie = 0x7fffffff;
	fp = NULL;
	fname = NULL;
	argc--;
	if (argc >= 3) ie = atoi(argv[3]);
	if (argc >= 2) is = atoi(argv[2]);
	if (argc >= 1) {
		p = argv[1];
		if ((c=*p) == '-') {
			if (!(c=*(p+1))) fp = stdin;
		}
		else fname = p;
	}

	if (!fp) {
		if (fname) {
			fp = fopen(fname,"rb");
			if (!fp){
				fprintf(stderr,"file[%s] open error!!\n",p);
				exit(2);
			}
		}
		else {
			fprintf(stderr,"usage : %s {-h | {file_name|-} [start[ len]}\n",
			        argv[0]);
			exit(1);
		}
	}

	for (i=1;i<is;i++) {
		if ((c=getc(fp)) == EOF) exit(0);
	}
	while (ie--) {
		if ((c=getc(fp)) == EOF) break;
		putchar(c);
	}
	exit(0);
}
