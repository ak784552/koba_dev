static  char    sccsid[]="@(#) cmcatpath.c 1.1 98/09/08 10:18:02";
#include "akacommon.h"
#include "cmconst.h"

/*************************************/
/*                                   */
/*   char *cmn_full_path( )            */
/*                                   */
/*************************************/
char *cmn_full_path( pszPath )
    char *pszPath;
{
    static char  szRetFullPath[ DEF_LEN_PATH + 1];
    char *pEnvPath = NULL;

    if( ( pEnvPath = getenv( DEF_PATH_AKBROOT ) ) == NULL )
        return pszPath;
    
	memset(szRetFullPath,0,DEF_LEN_PATH+1);

    strncpy( szRetFullPath, pEnvPath ,DEF_LEN_PATH);
    strncat( szRetFullPath, "/bin/spool/" ,DEF_LEN_PATH);
    strncat( szRetFullPath, pszPath , DEF_LEN_PATH);

    return szRetFullPath;
}
