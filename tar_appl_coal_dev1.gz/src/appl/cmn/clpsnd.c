static	char	sccsid[]="%Z% %M% %I% %D% %T%";
#include "colmn.h"

extern CLCOMMON CLcommon;

/*****************************************/
/*                                       */
/*****************************************/
static int _sqlchk( sql )
char *sql;
{
	char wd[10];
	int rc,pos;

	pos = 0;
	rc = 102;
	if (akxtgetw2(sql, &pos, wd, sizeof(wd)) > 0) {
		if (!stricmp(wd,"select")) rc = 101;
	}
	return rc;
}

/*****************************************/
/*                                       */
/*****************************************/
static int _make_para( arg, len, pprmList )
char    *arg;
int      len;
prmList *pprmList;
{
	int rc;
	tdtINFO_PARM  InfoParm;

	InfoParm.pi_attr = DEF_ZOK_CHAR;
	InfoParm.pi_code = CD_NLS_LANG;
	if (arg) {
		if (len < 0)
			InfoParm.pi_dlen  = strlen(arg);
		else
			InfoParm.pi_dlen  = len;
		InfoParm.pi_data    = arg;
	}
	else {
		InfoParm.pi_dlen  = 0;
		InfoParm.pi_data    = "";
	}
	rc = dmMakePacketForm( pprmList , &InfoParm );

	return rc;
}

/*****************************************/
/*                                       */
/* int cl_sqlsnd(lInsHndl, argv, iDisp )  */
/*                                       */
/* argv[0] �z�X�g�h�c                    */
/* argv[1] �����w��                      */
/* argv[2] �r�p�k������                  */
/* argv[3] �f�[�^�i�[�G���A���ʎq        */
/*                                       */
/*****************************************/
int cl_sqlsnd( pCLProcTable, lInsHndl, argv, iDisp )
CLPRTBL *pCLProcTable;
long lInsHndl;
char *argv[];
int  iDisp;
{
	prmList rPara[3];
	qDocToDb rPack;         /* ���M�p�P�b�g ���ʕ���   */
	int      rc, i, cmdno, procno;
	AKAMSGCOM tMsgCom;
	MCAT mcat;
	char buf[256];
	CLCOMMON *pCLcommon;
	char trns_id[12];
	INT4 hostid;
 
	pCLcommon = &CLcommon;

	/* �g�p�\���̂̏����� */
	memset(&rPack,0,sizeof(qDocToDb));
	memset(&tMsgCom,0,sizeof(AKAMSGCOM));
	memset(&mcat,0,sizeof(MCAT));

	if (argv[2]) {
		cmdno = atoi(argv[2]);
	}
	else {
		return -1;
	}
	if (cmdno > 0) {
		hostid = aka_get_pr_host_id();
		memcpy(trns_id,(char *)&hostid,4);
		procno = aka_get_regist_pid();
		memcpy(trns_id+4,(char *)&procno,4);
		memcpy(trns_id+8,(char *)&lInsHndl,4);
		rc = _make_para(trns_id, 12, &rPara[0]);
		if(rc) goto Err;

		/* ���M�p�P�b�g�쐬 */
		rPack.lMsgNo      = time(0);
		rPack.usCmdNo     = cmdno;
		rPack.usPrmNum    = 1;
		memcpy( rPack.cItfId, "DB", 2 );
		memcpy( rPack.cMsgId, "CM", 2 );
 
		mcat.mc_extlen = sizeof(qDocToDb)+rPara[0].VarLen;
		if (!(mcat.mc_bufp=Malloc(mcat.mc_extlen))) {
			rc = -1990101;
			goto Err;
		}
		akxtmcat(&mcat,&rPack,sizeof(qDocToDb));
		akxtmcat(&mcat,rPara[0].VarBD,rPara[0].VarLen);
	}
	else {
		for (i=1;i<3;i++) {
			rc = _make_para(argv[i], -1, &rPara[i-1]);
			if(rc) goto Err;
		}
		if (pCLcommon->cpSpoolDir) {
			strcpy(buf,pCLcommon->cpSpoolDir);
			if (*buf) {
				if (*(buf+strlen(buf)-1) != '/') {
					strcat(buf,"/");
				}
			}
		}
		else *buf = '\0';
		if (pCLcommon->cpHostId) strcat(buf,pCLcommon->cpHostId);
		if(argv[3])
			strcat(buf,argv[3]);
		else
			strcat(buf,"?__?");
		rc = _make_para(buf, -1, &rPara[2]);
		if(rc) goto Err;

		/* ���M�p�P�b�g�쐬 */
		rPack.lMsgNo      = time(0);
		rPack.usCmdNo     = _sqlchk(argv[2]);
		rPack.usPrmNum    = 3;
		memcpy( rPack.cItfId, "DB", 2 );
		memcpy( rPack.cMsgId, "CM", 2 );
 
		mcat.mc_extlen = sizeof(qDocToDb)+rPara[0].VarLen+rPara[1].VarLen+
		                rPara[2].VarLen;
		if (!(mcat.mc_bufp=Malloc(mcat.mc_extlen))) {
			rc = -1990101;
			goto Err;
		}
		akxtmcat(&mcat,&rPack,sizeof(qDocToDb));
		akxtmcat(&mcat,rPara[2].VarBD,rPara[2].VarLen);
		akxtmcat(&mcat,rPara[0].VarBD,rPara[0].VarLen);
		akxtmcat(&mcat,rPara[1].VarBD,rPara[1].VarLen);
	}
    
	tMsgCom.msg_hoid   = pCLcommon->dbHostAddr;
	tMsgCom.msg_prid  = pCLcommon->usDbProcId;
	tMsgCom.msg_clid = pCLcommon->usDbClass;
	tMsgCom.msg_disp = iDisp;
	tMsgCom.msg_mlen   = mcat.mc_ipos;
	tMsgCom.msg_pmsg     = mcat.mc_bufp;
	rc = aka_post_msg(lInsHndl,&tMsgCom);
 Err:
	if (rPara[0].VarBD) Free(rPara[0].VarBD);
	if (rPara[1].VarBD) Free(rPara[1].VarBD);
	if (rPara[2].VarBD) Free(rPara[2].VarBD);
	if (mcat.mc_bufp) Free(mcat.mc_bufp);
    
	return rc;
}
