static	char	sccsid[]="@(#) dmprcv.c 1.1 98/09/08 10:18:02";
#include "colmn.h"

/***********************************/
/*                                 */
/*                                 */
/*     95.9.6 Koba                 */
/*                                 */
/***********************************/
int cl_rcv_err_msg(pInd,errmsg,msglen)
char *pInd, *errmsg;
int  msglen;
{
	tdtINFO_PARM     rPrm,rPrmd;
	int rc,len;

	if (cmn_chk_data(pInd,&rPrm)) return SYSTEMERROR;
	if ((rc=cl_code_trans(&rPrm,&rPrmd))<0) return rc;
	else if (rc>0) {
		memcpy(&rPrm,&rPrmd,sizeof(tdtINFO_PARM));
	}
	msglen--;
	if((len=rPrm.pi_dlen) > msglen) len = msglen;
	memcpy(errmsg,rPrm.pi_data,len);
	errmsg[len] = '\0';
	if (rPrmd.pi_data) Free(rPrmd.pi_data);

	return rPrm.pi_len;
}

/*****************************************/
/*                                       */
/* searchResult *cl_process_rcv_chg_ptr(pNew)*/
/*                                       */
/*           1992/02/07 by �k���G�u      */
/*                                       */
/*****************************************/
searchResult *cl_process_rcv_chg_ptr( pDMprocTable, pNew )
DMPRTBL      *pDMprocTable;
searchResult *pNew;
{
	searchResult *pStart, *pCurr, *pPrev = NULL;
    
    /* �J�����g�������ʍ\���̂ɐV�\���̂��Z�b�g */
	pStart = pDMprocTable->searchRsltF;
    pDMprocTable->searchRsltC = pNew;
    
    if( pStart == NULL ){
        return pNew;
    }

	pCurr = pStart;
	pPrev = NULL;
    forever {
        if( pCurr == NULL )
            break;
        if( !memcmp( pCurr->sAreaId, pNew->sAreaId, AREA_ID_SIZE ) ){
            if( pPrev == NULL ){
                pStart = pCurr->Next;
				if ( pCurr->iIndex ) Free ( pCurr->iIndex - 2);
				if ( pCurr->RslBody ) Free ( pCurr->RslBody );
				if ( pCurr->pzFileName ) Free(pCurr->pzFileName);
                Free( pCurr );
                if( pStart == NULL )
                    return pNew;
                break;
            }
            else {
                pPrev->Next = pCurr->Next;
				if ( pCurr->iIndex ) Free ( pCurr->iIndex - 2);
				if ( pCurr->RslBody ) Free ( pCurr->RslBody );
				if ( pCurr->pzFileName ) Free(pCurr->pzFileName);
                Free( pCurr );
                break;
            }
        }
        pPrev = pCurr;
        pCurr = pCurr->Next;
    }
    
    pCurr = pStart;
    
    forever {
        if( pCurr->Next == NULL ){
            pCurr->Next = pNew;
            break;
            /* return pStart;  1992.03.06 by Y.Watanabe */
        }
        else
            pCurr = pCurr->Next;
    }
    return pStart;
}

/*****************************************/
/*                                       */
/* int dmProcessSQLrcv( )                */
/*                                       */
/*           1992/02/07 by �k���G�u      */
/*                                       */
/*****************************************/
int cl_sqlrcv( pDMprocTable, cpMsg, lMsgLen, cpArea )
DMPRTBL *pDMprocTable;
char *cpMsg,*cpArea;
INT4 lMsgLen;
{
    int           isw  = 0;
	char         *pInd;
    FILE         *fp   = NULL;
    searchResult *pSrc = NULL;
    int          *plIx = NULL;
    tdtINFO_PARM     rPrm, rPrmc;
    tdtCOMM_PACK_HEAD *pPrtcl = NULL;
	qDbToDoc      *pItfce;
	char c;
	int rc;
	tdtINFO_PARM     rInfoParm;   /* �p�����[�^���\����  */
	char *p;
	parmList *prmw;
	GlobalCt *pGlobTable;

	pGlobTable = pDMprocTable->GlobCt;
	pGlobTable->tuppl = 0;
	pGlobTable->column = 0;
	pGlobTable->errmsg[0] = '\0';
    
	pItfce = (qDbToDoc *)cpMsg;
	pInd   = cpMsg + sizeof(qDbToDoc);

	if( lMsgLen == 0 ) return EDM_SYSTEM_ERROR;

	pGlobTable->error = pItfce->lret;

	if( pItfce->usPrmNum == 1 || pItfce->usPrmNum == 3 ) {
		if ((rc=cl_rcv_err_msg(pInd,
			pGlobTable->errmsg,sizeof(pGlobTable->errmsg)))<0) return rc;
		pInd += rc;
		pItfce->usPrmNum--;
	}
    if( pItfce->lret != NormalEnd ) {
		if( pItfce->lret == SQLERROR ) ERROROUT("illegal SQL Command ");
        return NormalEnd;
	}

    if( pItfce->usPrmNum < 2 ) return NormalEnd;

    if (cmn_get_data( pInd, &rPrm )) return EDM_SYSTEM_ERROR;
    
	fp = NULL;
	pSrc = NULL;
	plIx = NULL;

	if(!(pSrc=(searchResult *)Malloc(sizeof(searchResult)))) goto Err;
	memset(pSrc, 0, sizeof(searchResult));
	memcpy(pSrc->sAreaId,cpArea,AREA_ID_SIZE);

    /* �������ʂ��O */
    if( rPrm.pi_dlen ==  0 ){
        if (rPrm.pi_data) Free (rPrm.pi_data);	/* K-00039 */
        strcpy( pSrc->szType, "B" );
        pSrc->iIndex    = 0;
        pSrc->iIndexLen = 0;
        pSrc->iTupleNum = 0;
        pSrc->iColmNum  = 0;
        pSrc->iCrTuple  = 0;
        pSrc->Next      = NULL;
 
        pGlobTable->error = 0;
        pGlobTable->tuppl = 0;
        pGlobTable->column = 0;
	/*
		printf("*** �������ʂ� %d ���ł�\n",pGlobTable->tuppl);
 	*/
        pDMprocTable->searchRsltF = cl_process_rcv_chg_ptr( pDMprocTable, pSrc );
        return NormalEnd;
	}

    if( rPrm.pi_id == 'F' ){
        
        if(!(fp = fopen( rPrm.pi_data, "r" ))) goto Err;

        strcpy( pSrc->szType, "B" );
        
        if(!(pSrc->RslBody = Malloc( rPrm.pi_dlen ))) goto Err;

        if (fread( pSrc->RslBody, 1, rPrm.pi_dlen, fp ) != rPrm.pi_dlen)
			goto Err;
        pSrc->pzFileName = rPrm.pi_data;
        pSrc->iDataLen   = rPrm.pi_dlen;
        
        pInd = (char *)( pInd+rPrm.pi_len );
        cmn_chk_data( pInd, &rPrmc );
        
        if(!(plIx = (int *)Malloc( rPrmc.pi_dlen ))) goto Err;

        if (fread( (char *)plIx, 1, rPrmc.pi_dlen, fp ) != rPrmc.pi_dlen)
			goto Err;
        pSrc->iIndex    = (int *)&plIx[2];
        pSrc->iIndexLen = rPrmc.pi_dlen;
        pSrc->iTupleNum = plIx[0];
        pSrc->iColmNum  = plIx[1];
        pSrc->iCrTuple  = 0;
        pSrc->Next      = NULL;
        pGlobTable->tuppl = pSrc->iTupleNum;
        pGlobTable->column = pSrc->iColmNum;
        
        fclose( fp );
    }
    else {
        strcpy( pSrc->szType, "B" );

        pSrc->pzFileName = NULL;
        pSrc->RslBody    = rPrm.pi_data;
        pSrc->iDataLen   = rPrm.pi_dlen;
        pSrc->Next       = NULL;
        
        pInd = pInd + rPrm.pi_len;
        cmn_chk_data( pInd, &rPrmc );

        plIx = (int *)rPrmc.pi_data;
        pSrc->iTupleNum = plIx[0];
        pSrc->iCrTuple  = 0;
        pSrc->iColmNum  = plIx[1];
        pSrc->iIndex    = (int *)&plIx[2];
        pSrc->iIndexLen = rPrmc.pi_dlen;
        pGlobTable->tuppl = pSrc->iTupleNum;
        pGlobTable->column = pSrc->iColmNum;
        
    }
	pDMprocTable->searchRsltF = cl_process_rcv_chg_ptr(pDMprocTable,pSrc);
/*
	printf("*** �������ʂ� %d ���ł�\n",pGlobTable->tuppl);
*/
	pGlobTable->error = 0;
	return NormalEnd;
Err:
	if (rPrm.pi_data) Free (rPrm.pi_data);
	if (fp) fclose(fp);
	if(pSrc) {
		if(pSrc->RslBody) Free(pSrc->RslBody);
		Free(pSrc);
	}
	if (plIx) Free (plIx) ;
	return EDM_SYSTEM_ERROR;
}
