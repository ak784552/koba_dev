static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ�                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cmpktform( pprmList , pInfoParm )                  *
*                      (I)prmList	*pprmList                                 *
*                      (O)tdtINFO_PARM	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include "colmn.h"

int cmpktform(pprmList, pInfoParm)
prmList   *pprmList;
tdtINFO_PARM  *pInfoParm;
{
	int  rc,len,lw,lww,dlen;
	char att,acc,*dat,*pBuff,*p;
	short sw,sww;

	att  = pInfoParm->pi_attr;
	dlen = pInfoParm->pi_dlen;
	dat  = pInfoParm->pi_data;
/*
printf("cmpktform: att=%d cod=%x\n",att,pInfoParm->pi_code);
*/
	switch (att) {
		case DEF_ZOK_CHAR:
			if (dlen > 255) acc = D_ACC_EXT;
			else acc = D_ACC_STD;
			break;
		case DEF_ZOK_BINA:
			if      (dlen == sizeof(char))  acc = D_ACC_CHAR;
			else if (dlen == sizeof(short)) acc = D_ACC_SHORT;
			else if (dlen == sizeof(INT4))  acc = D_ACC_LONG;
			else return -1990201;
			break;
		case DEF_ZOK_BULK:
			acc = D_ACC_EXT;
			break;
		case DEF_ZOK_KANS:
			acc = D_ACC_STD;
			break;
		defaults:
			return -1990202;
	}

	len = dlen;
	if (att == DEF_ZOK_BINA) {
		len += sizeof(FORM_S);
	}
	else {
		if (acc == D_ACC_EXT)
			len += sizeof(FORM_K);
		else
			len += sizeof(FORM_S);
	}
	if (!(pBuff=Malloc(len))) return -1990203;

	if (att == DEF_ZOK_BINA) {
		att = (att << 4) & 0xf0;
		pBuff[0] = att | acc;
		pBuff[1] = (char)dlen;
		p = pBuff + sizeof(FORM_S);
		if (dlen == sizeof(int)) {
			memcpy(&lw,dat,dlen);
			lww = ntohs(lw);
			memcpy(p,&lww,dlen);
		}
		else if (dlen == sizeof(short)) {
			memcpy(&sw,dat,dlen);
			sww = ntohl(sw);
			memcpy(p,&sww,dlen);
		}
		else *p = *dat;
	}
	else {
		pBuff[0] = ((att << 4) & 0xf0) | acc;
		if (att == DEF_ZOK_CHAR)
			pBuff[0] |= (pInfoParm->pi_code << 1) & 0x0e;
/*
printf("cmpktform: pBuff[0] = %x\n",*pBuff);
*/
		if (acc == D_ACC_EXT) {
			pBuff[1] = 0x00;
			lw = htonl(dlen);
			memcpy(pBuff+2,&lw,sizeof(int));
			memcpy(pBuff+sizeof(FORM_K),dat,dlen);
		}
		else {
			pBuff[1] = (char)dlen ,
			memcpy(pBuff+sizeof(FORM_S),dat,dlen);
		}
	}

	pprmList->VarLen  = len;
	pprmList->VarType = ' ';
	pprmList->VarBD   = pBuff;

	return NORMAL;
}

int cm_set_pkt_form(pInfoParm ,pBuff)
tdtINFO_PARM  *pInfoParm;
char       *pBuff;
{
	int  rc;
	char att;
	char acc;
	int  len;
	INT4  lw,lLen,lww;
	short sw,sww;
	unsigned char uw;
	char *cpDat, *p;

	att = pInfoParm->pi_attr;
	lLen = pInfoParm->pi_dlen;
	cpDat = pInfoParm->pi_data;

	switch( att )
		{
		case DEF_ZOK_CHAR :
			if ( lLen > 255 )
				acc = D_ACC_EXT;
			else
				acc = D_ACC_STD;
			break;
		case DEF_ZOK_BINA :
			if ( lLen == sizeof( char ) )
				acc = D_ACC_CHAR;
			else if ( lLen == sizeof( short int ) )
				acc = D_ACC_SHORT;
			else if ( lLen == sizeof( INT4 ) )
				acc = D_ACC_LONG;
			else
				return( -1990201 );
			break;
		case DEF_ZOK_BULK :
			acc = D_ACC_EXT;
			break;
		case DEF_ZOK_KANS :
			acc = D_ACC_STD;
			break;
		defaults:
			return( -1990202 );
		}

	len = lLen;
	if ( att == DEF_ZOK_BINA ) {
			len += sizeof( FORM_S );
	}
	else {
		if ( acc == D_ACC_EXT )
			len += sizeof( FORM_K );
		else
			len += sizeof( FORM_S );
	}

	if ( att == DEF_ZOK_BINA ) {
		att =  ( att << 4 ) & 0xf0 ;
		pBuff[0] = att | acc;
		pBuff[1] = ( char )lLen;
		p = pBuff+sizeof(FORM_S);
		if (lLen == 4) {
			memcpy(&lw, cpDat, lLen );
			lww = ntohs(lw);
			memcpy(p, &lww, lLen );
		}
		else if (lLen == 2) {
			memcpy(&sw, cpDat, lLen );
			sww = ntohl(sw);
			memcpy(p, &sww, lLen );
		}
		else memcpy(p, cpDat, lLen);
	}
	else {
		pBuff[0] = (( att << 4 ) & 0xf0 ) | acc;
		if ( att == DEF_ZOK_CHAR )
			pBuff[0] |= (pInfoParm->pi_code << 1) & 0x0e;
		if ( acc == D_ACC_EXT ) {
			pBuff[1] = 0x00;
			lw = htonl(lLen);
			memcpy(pBuff+2, (char *)&lw, sizeof(int) );
			 p = pBuff+sizeof(FORM_K);
		}
		else {
			pBuff[1] = ( char )lLen ,
			 p = pBuff+sizeof(FORM_S);
		}
		memcpy(p,cpDat,lLen);
	}

	return len;
}
