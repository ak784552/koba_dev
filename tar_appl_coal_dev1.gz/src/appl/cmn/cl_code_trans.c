static  char    sccsid[]="@(#) cl_code_trans.c 1.1 98/09/08 10:18:02";
/******************************************************************/
/*                                                                */
/*      Code Transration                                          */
/*                                                                */
/*         Coded by A.Kobayashi     1994.2.2                      */
/*                                                                */
/******************************************************************/
#include "colmn.h"

int    cl_cd_tr_to_packt_form( pParm ,ppVar )
tdtINFO_PARM     *pParm;   /* �p�����[�^���\����           */
char          **ppVar;
{
	tdtINFO_PARM rInfoParm;   /* �p�����[�^���\����           */
	prmList   varList;
	int rc;

	*ppVar = NULL;
	if ((rc=cl_code_trans(pParm,&rInfoParm))<=0) return rc;
	if (!(rc=dmMakePacketForm(&varList,&rInfoParm))) {
		*ppVar = varList.VarBD;
    	rc     = varList.VarLen;
	}
	if (rInfoParm.pi_data) Free(rInfoParm.pi_data);

    return( rc );
}

int    cl_code_trans( pParm ,pParmd )
tdtINFO_PARM     *pParm, *pParmd;   /* �p�����[�^���\����           */
{
	int rc;

	memset(pParmd,0,sizeof(tdtINFO_PARM));
	if ((pParm->pi_dlen == 0) ||
	    (pParm->pi_attr != DEF_ZOK_CHAR) ||
	    ((pParm->pi_attr == DEF_ZOK_CHAR) &&
	     (pParm->pi_code == CD_NLS_LANG)) ) {
		return 0;
	}
	memcpy(pParmd,pParm,sizeof(tdtINFO_PARM));
	pParmd->pi_code = CD_NLS_LANG;
	pParmd->pi_data    = NULL;
	pParmd->pi_dlen  = 0;
	if (CD_NLS_LANG == CD_TYPE_SJIS) {
		if (pParm->pi_code== CD_TYPE_EUC) {
			if (!(pParmd->pi_data=Malloc(pParm->pi_dlen+1))) return -1;
			pParmd->pi_scale = 0x80;
			pParmd->pi_dlen = akxcetos(pParm->pi_dlen,pParm->pi_data,
			                             pParmd->pi_data);
		}
		else {
			return -1;
		}
	}
	else if (CD_NLS_LANG == CD_TYPE_EUC) {
		if (pParm->pi_code== CD_TYPE_SJIS) {
			if (!(pParmd->pi_data=Malloc(pParm->pi_dlen*2+1))) return -1;
			pParmd->pi_scale = 0x80;
			pParmd->pi_dlen = akxcstoe(pParm->pi_dlen,pParm->pi_data,
			                             pParmd->pi_data);
		}
		else {
			return -1;
		}
	}
	else {
		return -1;
	}
	pParmd->pi_data[pParmd->pi_dlen] = '\0';
    return( pParmd->pi_dlen );
}
