static  char sccsid[]="@(#) cmn_msg_print.c 1.1 98/09/08 10:18:01";
#include "colmn.h"

#define LOGFILENAME   "log_file"
#define MSGFILENAME   "msg_file"

#define MSG_NUM  10
#define MSG_MAX 100

char *cmn_get_msg( iMsgNum )
unsigned int   iMsgNum;
{
	char sNum[MSG_NUM + 1];
	static char   sBuf[MSG_MAX + MSG_NUM + 1];

	FILE *fpMsgFile;

	if (!(fpMsgFile = fopen(MSGFILENAME, "r"))) {
		printf("%s(%d): MESSAGE file open error.\n", __FILE__, __LINE__);
		return NULL;
	}

	for (;;) {
		memset(sBuf,0,sizeof(sBuf));
		if (!akbreadline(sBuf,MSG_MAX+MSG_NUM,fpMsgFile)) return NULL;
		memset(sNum,0,sizeof(sNum));
		memcpy(sNum,sBuf,MSG_NUM);
		if( iMsgNum == atoi(sNum) ) return &sBuf[MSG_NUM + 1];
	}
}

void cmn_msg_print( iMsgNum )
	unsigned int   iMsgNum;
{
	char   *pMsg;
	FILE   *fpLogFile;

	if( ( pMsg = cmn_get_msg(iMsgNum) ) == NULL )
		return;

	printf("%s", pMsg);

	if( (fpLogFile = fopen(LOGFILENAME, "a")) == NULL )
		printf("%s(%d): LOG file open error.\n", __FILE__, __LINE__);
	else
		fprintf(fpLogFile, "%s", pMsg);

	fclose(fpLogFile);
}
