static  char    sccsid[]="@(#) cmaddhostid.c 1.1 98/09/08 10:18:01";
#include "colmn.h"
/*************************************************/
/*                                               */
/*  int cmn_add_host_id( pszResult, pszFileName )   */
/*                                               */
/*     char **pszResult                          */
/*     char  *pszFileName                        */
/*                                               */
/*************************************************/
int cmn_add_host_id( pszResult, pszFileName )
    char **pszResult;
    char  *pszFileName;
{
    int  iallocsize = 0;
    char hostname[HOST_NAME_LEN+1],
        *p = NULL;

    gethostname( hostname, HOST_NAME_LEN);

    iallocsize = strlen( hostname ) + strlen(":") + strlen( pszFileName );

    if(( p = Malloc( (iallocsize + 1) * sizeof(char))) == NULL )
        return SYSTEMERROR;

    sprintf( p, "%s:%s", hostname, pszFileName );
    p[ iallocsize ] = '\0';
    *pszResult = p;
    return strlen( p );
}

