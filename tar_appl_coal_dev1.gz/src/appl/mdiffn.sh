mdiff coal/cl_packet_check.c coal/cllexfnc.c coal/clfuncfile.c coal/cl_gx_func_bexp.c
