static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �h�e�R�}���h�O����                                     *
*                                                                             *
*      �֐����@�@�@�F�@int cl_if_pre_proc( pLeaf , pProc )                    *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                      (I)ProcCT		* pProc                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

int cl_if_pre_proc(pLeaf,pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int  	rc, id;
/*	IfCB	*pIfCB;	*/
	BlockCB *pBlockCB;

	if (!pLeaf || !pProc) return ERROR;
	if ((id=pLeaf->cmd.cid) != C_IF && id != C_SWITCH && id != C_TRY) return ERROR;

	/* BlockCB���� */
	if (rc = cl_add_block_cb(pProc)) return rc;
	pBlockCB = pProc->pcrBlockCB;
	pBlockCB->cid = id;

#if 0
	/* IfCB���� */
	if (!(pIfCB = (IfCB *)Malloc(sizeof(IfCB)))) return ERROR;
	memset(pIfCB,0,sizeof(IfCB));
	if (!pProc->pTopIfCB) {
		pProc->pTopIfCB = pIfCB;
		pIfCB->preIfCB  = NULL;
	}
	else {
		if (!pProc->pcrIfCB) {	/* 10.26 Add Koba */
			Free(pIfCB);
			Free(pBlockCB);
			return ERROR;
		}
		pProc->pcrIfCB->nextIfCB = pIfCB;
		pIfCB->preIfCB = pProc->pcrIfCB;
	}
	pProc->pcrIfCB  = pIfCB;
/*
	pIfCB->nextIfCB = NULL;
	pIfCB->TureFlag = L_OFF;
	pIfCB->ElseFlag = L_OFF;
	pIfCB->EndFlag  = L_OFF;
*/
#endif

	return NORMAL;
}

/********************************/
/*								*/
/********************************/
int cl_add_block_cb(pProc)
ProcCT  *pProc;
{
	BlockCB *pBlockCB;
	BlockCB *WpreBlockCB,*WnextBlockCB;
	tdtINFO_PARM *WpEachParm;

	if (!pProc) return ERROR;
#if 1
/*
printf("cl_add_block_cb:1: pTopBlockCB=%08x\n",pProc->pTopBlockCB);
*/
	if (pBlockCB=pProc->pTopBlockCB) {
/*
printf("cl_add_block_cb:2: pcrBlockCB=%08x\n",pProc->pcrBlockCB);
*/
		if (pProc->pcrBlockCB) {
			pBlockCB = pProc->pcrBlockCB->nextBlockCB;
/*
printf("cl_add_block_cb:3: pcrBlockCB->nextBlockCB=%08x\n",pBlockCB);
*/
		}
	}
	if (!pBlockCB) {
		/* BlockCB���� */
		if (!(pBlockCB = (BlockCB *)Malloc(sizeof(BlockCB)))) return ERROR;
		memset(pBlockCB,0,sizeof(BlockCB));
		if (!pProc->pTopBlockCB) {
			pProc->pTopBlockCB = pBlockCB;
		}
		else {
			pProc->pcrBlockCB->nextBlockCB = pBlockCB;
			pBlockCB->preBlockCB = pProc->pcrBlockCB;
		}
	}
	else {
		WpreBlockCB  = pBlockCB->preBlockCB;
		WnextBlockCB = pBlockCB->nextBlockCB;
		WpEachParm   = pBlockCB->pEachParm;
		memset(pBlockCB,0,sizeof(BlockCB));
		pBlockCB->preBlockCB  = WpreBlockCB;
		pBlockCB->nextBlockCB = WnextBlockCB;
		pBlockCB->pEachParm   = WpEachParm;
	}
	pBlockCB->iUsed = 1;
	pProc->pcrBlockCB = pBlockCB;
/*
printf("cl_add_block_cb:exit: pcrBlockCB=%08x\n",pProc->pcrBlockCB);
*/
#else
	if (pProc->pcrBlockCB && (pBlockCB=pProc->pcrBlockCB->nextBlockCB)) {
		WpreBlockCB  = pBlockCB->preBlockCB;
		WnextBlockCB = pBlockCB->nextBlockCB;
		WpEachParm   = pBlockCB->pEachParm;
		memset(pBlockCB,0,sizeof(BlockCB));
		pBlockCB->preBlockCB  = WpreBlockCB;
		pBlockCB->nextBlockCB = WnextBlockCB;
		pBlockCB->pEachParm   = WpEachParm;
	}
	else {
		/* BlockCB���� */
		if (!(pBlockCB = (BlockCB *)Malloc(sizeof(BlockCB)))) return ERROR;
		memset(pBlockCB,0,sizeof(BlockCB));
	}
	pBlockCB->iUsed = 1;

	if (!pProc->pTopBlockCB) {
		pProc->pTopBlockCB = pBlockCB;
	}
	else {
		if (!pProc->pcrBlockCB) {
			Free(pBlockCB);
			return ERROR;
		}
		pProc->pcrBlockCB->nextBlockCB = pBlockCB;
		pBlockCB->preBlockCB = pProc->pcrBlockCB;
	}
	pProc->pcrBlockCB  = pBlockCB;
#endif

	return NORMAL;
}

/********************************/
/*								*/
/********************************/
int cl_del_block_cb(pProc)
ProcCT  *pProc;
{
	BlockCB *pBlockCB;

	if (!pProc) return ERROR;

DEBUGOUTL1(161,"cl_del_block_cb:Enter pProc->pcrBlockCB=%08x",pProc->pcrBlockCB);

	if (!(pBlockCB=pProc->pcrBlockCB)) return -1;

	if (!pProc->pcrBlockCB->preBlockCB) {
		if (pBlockCB=pProc->pcrBlockCB) Free(pBlockCB);
		pProc->pTopBlockCB = NULL;
		pProc->pcrBlockCB  = NULL;
	}
	else {
		pProc->pcrBlockCB = pProc->pcrBlockCB->preBlockCB;
		if (pBlockCB=pProc->pcrBlockCB->nextBlockCB) Free(pBlockCB);
		pProc->pcrBlockCB->nextBlockCB = NULL;
	}

	return NORMAL;
}

/********************************/
/*								*/
/********************************/
BlockCB *cl_search_block_cb(proc,cid,opt)
ProcCT  *proc;
int cid,opt;	/* opt:0=from Top/1=from Cur to Top */
{
	BlockCB *pcrLCB;
	int opt2;

	if (!proc) return NULL;

DEBUGOUTL2(161,"cl_search_block_cb:Enter cid=%08x opt=%08x",cid,opt);
/*
printf("cl_search_block_cb:Enter cid=%08x opt=%08x\n",cid,opt);
*/
	if (opt) {
		opt2 = opt & 0x02;
		pcrLCB = proc->pcrBlockCB;
/*
printf("cl_search_block_cb: pcrLCB=%08x\n",pcrLCB);
*/
		while (pcrLCB) {

DEBUGOUTL1(161,"cl_search_block_cb: pcrLCB->cid=%08x",pcrLCB->cid);
/*
printf("cl_search_block_cb: pcrLCB->cid=%08x\n",pcrLCB->cid);
*/
			if (/*pcrLCB->iUsed && */pcrLCB->cid==cid) break;
			if (opt2) pcrLCB->iUsed = 0;
			pcrLCB = pcrLCB->preBlockCB;
		}
	}
	else {
		pcrLCB = proc->pTopBlockCB;
		while (pcrLCB) {
			if (pcrLCB->iUsed && pcrLCB->cid==cid) break;
			pcrLCB = pcrLCB->nextBlockCB;
		}
	}
	return pcrLCB;
}
