static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_sql                 */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*  Version                    1.00  2010/05/28  */
/*************************************************/
/* */
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_sql(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum < 3) {
		/* %s: �p�����[�^������܂���B */
		ERROROUT1(FORMAT(42),"col_mn_tr_sql");
		return ECL_TR_SQL;
	}

	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_msg(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum < 1) {
		/* %s: �p�����[�^������܂��� */
		ERROROUT1(FORMAT(42),"col_mn_tr_msg");
		return ECL_TR_MSG;
	}

	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}
