static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************************************/
/*   input : input function                                              */
/*           this function enable you to get parameters from packets     */
/*************************************************************************/

#include "colmn.h"

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;

static int _set_parm();
static int _set_data();

int input_xml(first)
int first;
{
	static char *sep=" \t<>!?/=[]";
	int parmlen;
	int rc,i,opt;
	tdtFrameInfo	FrameTbl;
	ProcCT *pPrCT,*proc;
	char   *parmtop,*p,buf[3],c;
	tdtINFO_PARM InfoParm;
	ScrPrCT *pScCT;
	SSPL_S ssp;
	tdtDataElm pDataTbl[256];
	int      iSel;
	char    *pSel,*pNam;
	ONTBL   *pOntbl;

	rc = 0;
	pScCT = cl_search_src_ct();
	pPrCT = cl_search_proc_ct();
	if (pGlobTable->error != 0)	{
		cmn_set_stat(RET_PR,&pPrCT->ptype,L_ON);
		return (0);
	}
	memset(&ssp,0,sizeof(SSPL_S));
	ssp.code = cl_code_type(0,0);
/*	parmtop = pPrCT->INPCB.curaddr;	*/
	parmtop = pPrCT->INPCB.parmtop;
	ssp.sp  = pPrCT->INPCB.curlen;
	parmlen = pPrCT->INPCB.maxlen;

DEBUGOUTL2(LVL_XML,"input_xml: parmtop=%08x parmlen=%d",parmtop,parmlen);

	p = parmtop;
	opt = 0x67;	/* 0b01100111 */
	for (;;) {
		while (((c=parmtop[ssp.sp])==' '||c=='\t'||c=='\n'||c=='\r') &&
		        ssp.sp<parmlen) ssp.sp++;

DEBUGOUTL2(LVL_XML+1,"input_xml: ssp.sp=%d c=%c",ssp.sp,c);

		if (ssp.sp >= parmlen) break;
		if (c == '<') {
			ssp.sp++;
		/*	pScCT->OnSelect = -1;	*/
			rc = _set_parm(parmtop,parmlen,&ssp,sep,opt,&FrameTbl,pDataTbl);
		}
		else {
			rc = _set_data(parmtop,parmlen,&ssp,&FrameTbl);
		}
DEBUGOUTL2(LVL_XML+1,"input_xml: FrameTbl.field_1=%d rc=%d",FrameTbl.field_1,rc);
		if (rc) {
			ERROROUT1("input_xml: Read Frame process error.rc=%d",rc);
			return rc;
		}
#if 1
		pPrCT->INPCB.curaddr = (char *)pPrCT->INPCB.parmtop + ssp.sp;
		pPrCT->INPCB.curlen = ssp.sp;
#endif
		if (FrameTbl.field_1 >= 99000) {
			rc = cl_input_xml_tag(&FrameTbl,ssp.sp);
			if (rc) {
				ERROROUT1("input_xml: TAG process error.rc=%d",rc);
				return rc;
			}
		}
		else {
#if 0
			pPrCT->INPCB.curaddr = (char *)pPrCT->INPCB.parmtop + ssp.sp;
			pPrCT->INPCB.curlen = ssp.sp;
#endif
			rc = cl_input_dt(&FrameTbl);
			if (rc) {
				ERROROUT1("input_xml: DATA process error.rc=%d",rc);
				return rc;
			}
		}
		if (cmn_chk_stat(NEW_SC,&pCLprocTable->ScrSt) != L_OFF) {
		    cmn_set_stat(NEW_SC,&pCLprocTable->ScrSt,L_OFF);
			return 0;
		}
		if (cmn_chk_stat(RTN_PR,&pCLprocTable->PrSt) != L_OFF) return 0;
		proc = cl_search_proc_ct();
		if (cmn_chk_stat(RET_PR|SCR_PR,&proc->ptype)) return 0;
		if (pGlobTable->error != 0) {
			cmn_set_stat(RET_PR,&proc->ptype,L_ON);
			return 0;
		}
	}

	if (pScCT->OnSelect>=0 && cmn_chk_stat(GR3_PR,&pScCT->ptype)!=L_OFF) {
		cmn_set_stat(GR3_PR,&pScCT->ptype,L_OFF);
		pOntbl = pScCT->ONCOND[pScCT->OnSelect];
		if (pNam=pOntbl->PrName[2]) {
			if (rc=cl_input_exec_proc(pOntbl->PrSel[2],pNam)) return rc;
			if (cmn_chk_stat(NEW_SC,&pCLprocTable->ScrSt) != L_OFF) {
				cmn_set_stat(NEW_SC,&pCLprocTable->ScrSt,L_OFF);
				return 0;
			}
			proc = cl_search_proc_ct();
			if (cmn_chk_stat(RTN_PR|SCR_PR,&proc->ptype) != L_OFF) return (0);
			if (pGlobTable->error != 0) {
				cmn_set_stat(RET_PR,&proc->ptype,L_ON);
				return (0);
			}
		}
	}
	cmn_set_stat(RET_PR,&pPrCT->ptype,L_ON);
	return rc;
}

static int _set_parm(parmtop, parmlen, ssp, sep, opt, pFrameTbl, pDataTbl)
char *parmtop,*sep;
int  parmlen,opt;
SSPL_S *ssp;
tdtFrameInfo *pFrameTbl;
tdtDataElm *pDataTbl;
{
	char c,*p1,*p,*pName,*pVal;
	int n,rc,spw,level,type,iCDATA;
	ScrPrCT *pScCT;

	memset(pFrameTbl,0,sizeof(tdtFrameInfo));
	if ((c=parmtop[ssp->sp]) == '?') {
		pFrameTbl->field_1 = 99001;
		ssp->sp++;
	}
	else if (c == '!') {
		pFrameTbl->field_1 = 99002;
		ssp->sp++;
	}
	else if (c == '/') {
		pFrameTbl->field_1 = 99009;
		ssp->sp++;
	}
	else
		pFrameTbl->field_1 = 99003;

DEBUGOUTL2(LVL_XML,"set_parm: sp=%d pFrameTbl->field_1 = %d",ssp->sp,pFrameTbl->field_1);

	/* get TAG name */
	pFrameTbl->iNode = 0;
	pDataTbl[0].attr = DEF_ZOK_CHAR;
#if 1
	rc = akxtgwnsl(parmtop,parmlen,ssp,sep,opt);
#else
	rc = akxtgwns(parmtop, parmlen, ssp, sep, opt);
#endif
	if (rc==0 && ssp->attr[0]==0) return -1;
	if ((c=*ssp->wd) == '>') return -2;
	p1 = Malloc(rc+1);
	pDataTbl[1].pData = p1;
	strnzcpy(p1,ssp->wd,rc);
	pDataTbl[1].len = rc;
	pDataTbl[1].attr = DEF_ZOK_CHAR;

DEBUGOUTL2(LVL_XML,"set_parm: get TAG name=[%s] sp=%d",p1,ssp->sp);

	if (p=strchr(p1,':')) {	/* name space */
		*p = '\0';
		pDataTbl[0].len   = strlen(p1);
		pDataTbl[0].pData = p1;
		pDataTbl[1].len   = strlen(p+1);
		pDataTbl[1].pData = Strdup(p+1);
	}
	else {
		pDataTbl[0].pData = Malloc(1);
		*pDataTbl[0].pData = '\0';
		pDataTbl[0].len = 0;
	}
	n = 2;
	if (pFrameTbl->field_1== 99001 || pFrameTbl->field_1== 99003 ||
	    pFrameTbl->field_1== 99009) {
		for (;;) {
			/* get ATTR name */
#if 1
			rc = akxtgwnsl(parmtop,parmlen,ssp,sep,opt);
#else
			rc = akxtgwns(parmtop, parmlen, ssp, sep, opt);
#endif
			if (rc==0 && ssp->attr[0]==0) return -3;

DEBUGOUTL3(LVL_XML+1,"set_parm: get ATTR name: sp=%d rc=%d wd=%c",ssp->sp,rc,*ssp->wd);

			if ((c=*ssp->wd) == '>') break;
			else if ((c=='?' || c=='/') && *(ssp->wd+1) == '>') {
				ssp->sp++;

DEBUGOUTL2(LVL_XML+1,"set_parm: sp=%d c=%c",ssp->sp,parmtop[ssp->sp]);

				if (c == '/') {
					pScCT = cl_search_src_ct();
					cmn_set_stat(GR3_PR,&pScCT->ptype,L_ON);
					if (pFrameTbl->field_1 != 99009) pScCT->OnSelect = -1;
				}
				break;
			}
			pName = Malloc(rc+1);
			strnzcpy(pName,ssp->wd,rc);
			pDataTbl[n].pData = pName;
			pDataTbl[n].len = rc;
			pDataTbl[n].attr = DEF_ZOK_CHAR;

DEBUGOUTL2(LVL_XML+1,"set_parm:                n=%d name=[%s]",n,pDataTbl[n].pData);

			n++;

			/* get '=' */
			spw = ssp->sp;
#if 1
			rc = akxtgwnsl(parmtop,parmlen,ssp,sep,opt);
#else
			rc = akxtgwns(parmtop, parmlen, ssp, sep, opt);
#endif
			if ((c=*ssp->wd) != '=') {
				if (ssp->attr[0] != 1) return -4;
				ssp->sp = spw;
				pDataTbl[n].pData = Malloc(1);
				*pDataTbl[n].pData = '\0';
				pDataTbl[n].len = 0;
				pDataTbl[n].attr = DEF_ZOK_CHAR;
				n++;
				continue;
			}

			/* get ATTR value */
#if 1
			rc = akxtgwnsl(parmtop,parmlen,ssp,sep,opt);
#else
			rc = akxtgwns(parmtop, parmlen, ssp, sep, opt);
#endif
			if (ssp->attr[0] != 6) return -5;
			pVal = Malloc(rc+1);
			strnzcpy(pVal,ssp->wd,rc);
			pDataTbl[n].pData = pVal;
			pDataTbl[n].len = rc;
			pDataTbl[n].attr = DEF_ZOK_CHAR;

DEBUGOUTL2(LVL_XML+1,"set_parm: get ATTR val : n=%d val=[%s]",n,pDataTbl[n].pData);

			n++;
			if (pFrameTbl->field_1== 99001 && !stricmp(pName,"encoding")) {
				if (type=akxt_chk_lang_type(pVal)) {
					cl_code_type(1,type);	/* reset code type */
					ssp->code = type;
				}
			}
		}
	}
	else if (pFrameTbl->field_1== 99002) {
		p = parmtop + ssp->sp;
		if (pDataTbl[1].len >= 2 && !memcmp(pDataTbl[1].pData,"--",2)) {
			for (;ssp->sp<parmlen-2;p++,ssp->sp++) {
				if (!memcmp(p,"-->",3)) {
					break;
				}
			}
			if (ssp->sp >= parmlen-2) return -6;
			ssp->sp += 3;
		}
		else {
			if (*pDataTbl[1].pData == '[') {
				iCDATA = 0;
				level = 1;
				if (parmlen-ssp->sp>=6 && !memcmp(p,"CDATA[",6)) {
					iCDATA = ssp->sp;
				}
			}
			else level = 0;

DEBUGOUTL2(LVL_XML,"set_parm: : sp=%d level=%d",ssp->sp,level);

			for (;ssp->sp<parmlen;p++,ssp->sp++) {
#if 1
				if ((rc=akxqmbslen(cl_code_type(0,0),p)) >= 2) {
					rc--;
					p += rc;
					ssp->sp += rc;
				}
#else
				if (akxqiskanji(p)) {
					p++;
					ssp->sp++;
				}
#endif
				else {
					if ((c=*p)=='>' && level==0) break;
					else if (c == ']') {
						if (level > 0) {
							if (iCDATA && level==2) {
								rc = ssp->sp - iCDATA;
								p1 = Realloc(pDataTbl[1].pData,rc+1);
								pDataTbl[1].pData = p1;
								strnzcpy(p1,parmtop+iCDATA,rc);
								pDataTbl[1].len = rc;
								iCDATA = 0;
							}
							level--;
						}
						else return -7;

DEBUGOUTL2(LVL_XML+1,"set_parm: ]: sp=%d level=%d",ssp->sp,level);

					}
					else if (c == '[') {
						level++;
						if (iCDATA && level==2) iCDATA = ssp->sp + 1;

DEBUGOUTL2(LVL_XML+1,"set_parm: [: sp=%d level=%d",ssp->sp,level);

					}
				}
			}
			if (ssp->sp >= parmlen) return -8;
			ssp->sp++;
		}
	}

DEBUGOUTL2(LVL_XML,"set_parm: ssp->sp=%d n=%d",ssp->sp,n);

	pFrameTbl->pDataTbl = (tdtDataElm *)Malloc(sizeof(tdtDataElm)*n);
	memcpy(pFrameTbl->pDataTbl,pDataTbl,sizeof(tdtDataElm)*n);
	pFrameTbl->iNode = n;
	return 0;
}

static int _set_data(parmtop, parmlen, ssp, pFrameTbl)
char *parmtop;
int  parmlen;
SSPL_S *ssp;
tdtFrameInfo *pFrameTbl;
{
	char c,*p;
	int rc,len,i;

	memset(pFrameTbl,0,sizeof(tdtFrameInfo));
	memcpy(pFrameTbl->szFrameID,"DT",2);
	p = parmtop+ssp->sp;
	for (i=ssp->sp;i<parmlen;i++) if (*p++ == '<') break;
	if (i >= parmlen) return -1;
	len = i - ssp->sp;
	p = parmtop+ssp->sp;
	len = akxtsapb(1,p,len);	/* 0-->1 2017.11.03 */

DEBUGOUTL3(LVL_XML,"_set_data: i=%d ssp->sp=%d len=%d",i,ssp->sp,len);

	pFrameTbl->pDataTbl = (tdtDataElm *)Malloc(sizeof(tdtDataElm));
	pFrameTbl->pDataTbl[0].pData = Malloc(len+1);
	strnzcpy(pFrameTbl->pDataTbl[0].pData,p,len);
	pFrameTbl->pDataTbl[0].len = len;
	pFrameTbl->pDataTbl[0].attr = DEF_ZOK_CHAR;
	pFrameTbl->iNode = 1;
	ssp->sp = i;
	return 0;
}
