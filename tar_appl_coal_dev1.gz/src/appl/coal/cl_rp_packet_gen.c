static char sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�P�b�g�����o������                                   *
*                                                                             *
*      �֐����@�@�@�F�@int cl_rp_packet_gen(pPKCB)                            *
*                                                                             *
*      ������      �F�@(I) PacketCB  *pPKCB                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

int cl_rp_packet_gen()
{
	int  point,fd, fdlen, dpos;
	int  BuffSize;
	int  RC;
	char *pBuff,*pKANfname;
	TrmToSrv	  *pTTS;
	MCAT *mcat;
	tdtINDIRECT_INFO *pKAN;
	AKAMSGCOM *tpMsgCom;

	if (pCLprocTable->ListPBody) {
		fdlen = pCLprocTable->ListPBody->AllFieldlen;
		mcat = &pCLprocTable->ListPBody->mCat;
		pKAN = &pCLprocTable->ListPBody->indInfo;
		dpos = pKAN->ini_dpos;
		pKANfname = pCLprocTable->ListPBody->fname;
	}
	else {
		fdlen = 0;
		mcat = NULL;
		pKAN = NULL;
		dpos = 0;
		pKANfname = NULL;
	}
	point = 0;
	BuffSize = fdlen + sizeof(TrmToSrv) + 24;
	if (!(pBuff=(char *)Malloc(BuffSize))) return ERROR;

	/* �p�P�b�g�w�b�_�[�쐬     */
	tpMsgCom = (AKAMSGCOM *)pCLprocTable->CmdPacketp;
	pTTS = (TrmToSrv *)tpMsgCom->msg_pmsg;

	/* Command header */
	if (pTTS) {
		memcpy(&(pBuff[point]),pTTS->userid ,sizeof(pTTS->userid));
		point += sizeof(pTTS->userid);

		memcpy(&(pBuff[point]),(char *)&pTTS->commandid,sizeof(int));
		point += sizeof(int);
	}

	RC = htonl(pGlobTable->Return);
	memcpy(&(pBuff[point]),&RC,sizeof(int));
	point += sizeof(int);

	/* �����f�[�^���쐬         */
	if (fdlen > 0) {
		memcpy(pBuff+point,mcat->mc_bufp,fdlen);
		point += fdlen;
	}

	tpMsgCom = (AKAMSGCOM *)pCLprocTable->WrPacketp;
	tpMsgCom->msg_mlen = point;
	tpMsgCom->msg_pmsg = pBuff;
	tpMsgCom->msg_form = AKA_PFM_INDIRECT;

	if (dpos > 0) {
		tpMsgCom->msg_filc = 1;
		strcpy(tpMsgCom->msg_filv[0],pKANfname);
	}
	return NORMAL;
}
