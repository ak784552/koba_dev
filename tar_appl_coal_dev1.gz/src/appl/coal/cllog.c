static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************
*																		*
*	�����ړI	�F ���O�o��												*
*																		*
*	�����T�v	�F 														*
*																		*
*************************************************************************/
#include <colmn.h>

extern CLCOMMON  CLcommon;
extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern int giOptions[];
extern M_FILE *m_stdin,*m_stdout,*m_stderr;

/****************************************/
/*										*/
/****************************************/
static int _log_addr_invalid(addr,name,fmt,file,line)
char *addr,*name,*fmt,*file;
int line;
{
	int ret,len;
	char *p;

	ret = 0;
	len = strlen(fmt);
	if (!akxm_addrchk(addr)) {
		sprintf(fmt+len," %s=%%08x%%s",name);
		if (addr) p = " invalid addr";
		else p = "";
		cl_debug_out_level(0,file,line,fmt,addr,p,0,0,0);
		ret = ECL_SYS_INVALID_ADDR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int _add_err_msg(err_hist,add_msg,add_len)
ParList *err_hist;
char *add_msg;
int add_len;
{
	char *err_msg;
	int err_msg_len,iADD;

	err_msg = err_hist->par;
	err_msg_len = err_hist->parlen;
	iADD = 1;
	if (err_msg && err_msg_len>0) {
		if (akxs_sseq_mline(add_msg,add_len,err_msg,err_msg_len) > 0) iADD = 0;
	}
	if (iADD) {
		if (err_msg = MRealloc(err_msg,err_msg_len+add_len+3)) {
			if (err_msg_len > 0) err_msg_len += akxa_log_new_line_str(err_msg+err_msg_len,pGlobTable->options[2]);
			memzcpy(err_msg+err_msg_len,add_msg,add_len);
			err_msg_len += add_len;
		}
		else err_msg_len = 0;
		err_hist->par = err_msg;
		err_hist->parlen = err_msg_len;
	}
	return err_msg_len;
}

/********1*********2*********3*********4*********5*********6*********/
/*  pGlobTable->Quot[2] : �G���[���O�o�͎��ɃG���[���b�Z�[�W������	*/
/*      �N���A�𐧌䂷��											*/
/*		pGlobTable->Quot[2]<>0 �̂Ƃ��A�������N���A����				*/
/*		�������ATRY���[�h���́ApGlobTable->Quot[2]=0�Ƃ��Ă���		*/
/*		cl_node_process_opt()�̐擪�ŁApGlobTable->Quot[2]=1�ƂȂ�	*/
/* ���� : 				opt = 0x01 : HOLD���[�h						*/
/* �X�V : 2020.04.29 TRY���ł��G���[�̓t�@�C���ɏo�͂��� 			*/
/********************************************************************/
int cl_log_out_opt_l5(log_no,level,opt,file,line,fmt,a1,a2,a3,a4,a5)
int log_no,level,opt,line;
char *file,*fmt,*a1,*a2,*a3,*a4,*a5;
{
	int max_len,iOUT,i,log_flg,len,ex_opt7,max_msg_out;
	char buf[600],*argv[5],*p,*pp;
	int  (*logout)();
	long lVala[3];
	ProcCT *proc;
	ScrPrCT *scrct;
	Leaf *leaf;
	tdtREDIRECT *red;
	M_FILE *fp,*fpstd;
	MCAT *mcat_save;
/*
if (!log_no) {
cl_printf10("cl_log_out_opt_l5:Enter log_no=%d level=%d opt=%08x file=[%s]\nline=%d fmt=[%s]\n",
log_no,level,opt,file,line,fmt,0,0,0,0);
}
*/
/*
printf("cl_log_out_opt_l5: err_msg_len =%d err_msg =%08x\n",pGlobTable->err_hist[0].parlen,pGlobTable->err_hist[0].par);
printf("cl_log_out_opt_l5: err_hpld_len=%d hold_msg=%08x\n",pGlobTable->err_hist[1].parlen,pGlobTable->err_hist[1].par);
*/
	if (!fmt) return -1;
	if (LOGLEVEL(log_no,-1) < level) return 0;	/* add 2023.5.21 */
	iOUT = 1;
	ex_opt7 = cl_get_option(7,0);
	if (!log_no) {
/*
printf("cl_log_out_l5: pGlobTable->try_level=%d opt=%d at %s(%d)\n",pGlobTable->try_level,opt,file,line);
*/
		if (pGlobTable->try_level > 0) {
			iOUT = -1;
			pGlobTable->Quot[2] = 0;	/* Quot[2]<>0 �̂Ƃ��A�G���[���b�Z�[�W�������N���A���� */
		}
#if 1	/* 2024.3.16 */
		if (ex_opt7 & 0x800) {
			iOUT = 0;
			pGlobTable->Quot[2] = 0;	/* Quot[2]<>0 �̂Ƃ��A�G���[���b�Z�[�W�������N���A���� */
		}
#endif
	/*	if (LOGLEVEL(log_no,-1) < level) iOUT = 0;	*/
	}
/*
printf("cl_log_out_l5: log_no=%d level=%d LOGLEVEL=%d\n",log_no,level,LOGLEVEL(log_no,-1));
*/
/*
printf("cl_log_out_l5: iOUT=%d\n",iOUT);
*/
	fpstd = fp = NULL;
	log_flg = LOGFLG(log_no,-1);
	if (scrct = cl_search_src_ct()) {
		proc = cl_search_proc_ct();
		if (proc) red = proc->redirect;
		else red = scrct->redirect;
		if (red) {
			if (log_flg & D_LOG_FLG_STDOUT) {
				fpstd = red->stdio[1];
			}
			else if (log_flg & D_LOG_FLG_STDERR) {
				fpstd = red->stdio[2];
			}
			if (iOUT && !(log_no==2 && !(cl_get_option(25,0) & 0x400))) {
				if (log_flg & D_LOG_FLG_STDOUT) {
					if (fpstd != m_stdout) fp = fpstd;
				}
				else if (log_flg & D_LOG_FLG_STDERR) {
					if (fpstd != m_stderr) fp = fpstd;
				}
			}
/*
printf("cl_log_out_l5: log_no=%d log_flg=%08x fp=%08x\n",log_no,log_flg,fp);
*/
		}
	}
	else proc = NULL;
	if (iOUT && !(opt & 0x01)) {
#if 1	/* 2022.10.30 */
		if (!log_no && scrct && !(ex_opt7 & 0x0200)) {
			lVala[0] = 0;
			if (proc) {
				if (leaf = proc->Curleaf) lVala[0] = leaf->cmd.rc;
			}
			lVala[1] = line;
			if ((max_msg_out=(ex_opt7 & 0xf000)>>12) <= 0) max_msg_out = 16;
			if (!(i=akxs_mseq_r(scrct->pErrmsgOnce,lVala))) {
				lVala[2] = 1;
				akxs_mseq_set(scrct->pErrmsgOnce,0,lVala);
			}
			else if (lVala[2] <= max_msg_out) {
				if (lVala[2] == max_msg_out) {
					fmt = FORMAT(660);	/* %s: �ȍ~�̓������b�Z�[�W��}�~���܂��B*/
				}
				lVala[2]++;
				akxs_mseq_set(scrct->pErrmsgOnce,i,lVala);
			}
			else {
				LOGFLG(log_no,log_flg);
				return 0;
			}
/*
printf("cl_log_out_l5: i=%d max_msg_out=%d lVala[2]=%d\n",i,max_msg_out,lVala[2]);
*/
		}
#endif
		if (iOUT<0 && !log_no) {
		/*	log_flg = LOGFLG(log_no,-1);	*/
			LOGFLG(log_no,(log_flg & ~(D_LOG_FLG_STDOUT | D_LOG_FLG_STDERR)) | D_LOG_FLG_FILE);
/*
printf("cl_log_out_l5: logflg=%08x\n",LOGFLG(log_no,-1));
*/
			akb_ferror_out_level(level,file,line,fp,fmt,a1,a2,a3,a4,a5);
		/*	LOGFLG(log_no,log_flg);	*/
		}
		else if (log_no>=0 && log_no<=2) {
#if 1	/* 2023.4.18 */
			if (fpstd) {
				mcat_save = fpstd->m_mcat;
				fpstd->m_mcat = NULL;
			}
#else
			if (fp) mcat_save = fp->m_mcat;
#endif
			if      (log_no == 0) logout = akb_ferror_out_level;
			else if (log_no == 1) logout = akb_fprint_out_level;
			else if (log_no == 2) {
				logout = akb_fdebug_out_level;
#if 0	/* 2023.4.18 */
				if (fp) fp->m_mcat = NULL;
#endif
			}
			logout(level,file,line,fp,fmt,a1,a2,a3,a4,a5);
#if 1	/* 2023.4.18 */
			if (fpstd) fpstd->m_mcat = mcat_save;
#else
			if (fp) fp->m_mcat = mcat_save;
#endif
		}
		else akb_flog_out_level_main(log_no,level,file,line,fp,fmt,a1,a2,a3,a4,a5);

		if (!log_no) {
/*
printf("cl_log_out_l5: pGlobTable->Quot[2]=%d\n",pGlobTable->Quot[2]);
*/
			if (pGlobTable->Quot[2]) {
				pGlobTable->err_hist[0].parlen = 0;
				pGlobTable->Quot[2] = 0;
			}
		}
	}
	LOGFLG(log_no,log_flg);
	if (!log_no && iOUT) {
		max_len = sizeof(pGlobTable->errmsg) - 1;
		argv[0] = a1;
		argv[1] = a2;
		argv[2] = a3;
		argv[3] = a4;
		argv[4] = a5;
		akxa_log_printf_len(buf,max_len,fmt,5,argv);
/*
printf("cl_log_out_l5: buf=[%s] max_len=%d\n",buf,max_len);
*/
		sprintf(pGlobTable->errmsg,buf,
		        argv[0],argv[1],argv[2],argv[3],argv[4]);
		p = pGlobTable->errmsg;
		len = strlen(p);
/*
cl_str_conv_put(&pp,p,len);
printf("cl_log_out_l5: len=%d errmsg=[%s]\n",len,pp);
*/
		if (opt & 0x01) {
			i = 1;
			iOUT = -1;
		}
		else i = 0;
		if (iOUT < 0) _add_err_msg(&pGlobTable->err_hist[i],p,len);
		if (opt & 0x01) *p = '\0';
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_log_out_l5(log_no,level,file,line,fmt,a1,a2,a3,a4,a5)
int log_no,level,line;
char *file,*fmt,*a1,*a2,*a3,*a4,*a5;
{
	return cl_log_out_opt_l5(log_no,level,0,file,line,fmt,a1,a2,a3,a4,a5);
}

/****************************************/
/*										*/
/****************************************/
static int _skip(buf,ptn,opt)
char *buf,*ptn;
int  opt;
{
	int i;
	char *p,c;

	p = buf;
	i = 0;
	while (c = *p++) {
		if (!strchr(ptn,c)) break;
		i++;
	}
	return i;
}

/****************************************/
/*										*/
/****************************************/
static int _per_check(buf,buf_len,fmt)
char *buf,*fmt;
int buf_len;
{
	int len,i,m,rem_len;
	char *pf,*pb,c,cc;
/*
printf("_per_chack: fmt=[%s]\n",fmt);
*/
	buf_len--;
	len = 0;
	pf = fmt;
	pb = buf;
	rem_len = strlen(fmt);
	while (c = *pf) {
		if (len >= buf_len) break;
		m = akxqkanjilen2(pf,rem_len);
		if (m > 1) {
			memcpy(pb,pf,m);
			pb += m;
			pf += m;
			len += m;
			rem_len -= m;
		}
		else {
			pf++;
			*pb++ = c;
			len++;
			rem_len--;
			if (c == '%') {
				if (len >= buf_len) {
					len--;
					pb--;
					break;
				}
				*pb++ = c;
				len++;
				rem_len--;
			}
		}
	}
	*pb++ = '\0';
/*
printf("_per_chack: len=%d buf=[%s]\n",len,buf);
*/
	return len;
}

/****************************************/
/*										*/
/****************************************/
static int _per_check_snprintf(buf,buf_size,fmt,argc,argv)
char *buf,*fmt,*argv[];
int buf_size,argc;
{
	int len,i,j,k,slen,bmax;
	char *pf,*pb,c,cc,wrk[256],*p;
/*
printf("_per_chack_snprintf: buf_size=%d fmt=[%s]\n",buf_size,fmt);
*/
	bmax = buf_size - 1;
	k=len = 0;
	pf = fmt;
	pb = buf;
	while ((c=*pf) && len<bmax) {
		if (c == '%') {
			if (k >= argc) break;
			if (*(pf+1) == c) {
				*pb++ = c;
				len++;
				if (len < bmax) {
					*pb++ = c;
					len++;
				}
				pf++;
			}
			else {
				i = _skip(pf+1,".+-0123456789",0);
				cc = *(pf+1+i);
				if (cc == 's') {
					p = argv[k++];
					slen = strlen(p);
					for (j=0;j<slen && len<bmax;j++) {
						cc = *p++;
						*pb++ = cc;
						len++;
						if (cc=='%' && len<bmax) {
							*pb++ = cc;
							len++;
						}
					}
				}
				else if (len+10<bmax) {
					memzcpy(wrk,pf,i+2);
					sprintf(pb,wrk,argv[k++]);
					pb += strlen(pb);
					len += strlen(pb);
				}
				pf += i+1;
			}
		}
		else {
			*pb++ = c;
			len++;
		}
		pf++;
	}
	strnzcpy(pb,pf,bmax-len);
/*
printf("_per_chack_snprintf: len=%d buf=[%s]\n",len,buf);
*/
	return len;
}

/****************************************/
/*										*/
/****************************************/
int  cl_debug_array_info(fmt,len,pInfo)
char *fmt;
int  len;
tdtINFO_PARM *pInfo;
{
	tdtArrayIndex *pIndex;
	ScrPrCT *pScCT;
	XHASHB *xhp;
	int i,ndim,*index;
	char *p;

	pIndex = (tdtArrayIndex *)pInfo->pi_data;
	pScCT = (ScrPrCT *)pInfo->pi_len;
	sprintf(&fmt[len]," pInfo=%08x id=%c attr=%d scale=0x%02x dlen=%d len(pScCT)=%08x hlen(gid)=%d aux=0x%02x 0x%02x auxlen=%04x %08x data=%08x",
	        pInfo,pInfo->pi_id,pInfo->pi_attr,pInfo->pi_scale,
	        pInfo->pi_dlen,pScCT,pInfo->pi_hlen,pInfo->pi_aux[0],pInfo->pi_aux[1],
	        pInfo->pi_alen,pInfo->pi_paux,pInfo->pi_data);
	len = strlen(fmt);
	if (pIndex) {
		sprintf(&fmt[len],
			"(VarIndex=%08x Attr=%d %d %d %d size=%d xhp=%08x  pInfoType=%08x uaux1=%04x uaux2=%04x index=[",
			pIndex->pVarIndex,
			pIndex->uAttr[0],pIndex->uAttr[1],
			pIndex->uAttr[2],pIndex->uAttr[3],
			pIndex->size,
			pIndex->xhp,
			pIndex->pInfoType,
			pIndex->uaux1,
			pIndex->uaux2);
			len = strlen(fmt);
		index = pIndex->index;
		ndim = index[0]*2 + 4;
		if (ndim > MAX_ARRAY_DIM) ndim = MAX_ARRAY_DIM;
		p = &fmt[len];
		for (i=0;i<ndim;i++) {
			if (i > 0 ) *p++ = ',';
			sprintf(p,"%d",index[i]);
			p += strlen(p);
		}
		strcpy(p,"]");
		if (xhp = pIndex->xhp) {
			len = strlen(fmt);
			if (!_log_addr_invalid(xhp,"xhp",&fmt[len],"",0)) {
				sprintf(&fmt[len],"(_xhash Id=%c%c keylen=%d max=%d pre=%d ha=%08x next=%08x datlen=%d dreg=%08x)",
			        xhp->xha_id[0],xhp->xha_id[1],xhp->xha_keylen,
			        xhp->xha_maxreg,xhp->xha_prereg,
			        xhp->xha_hashb,xhp->xha_xhnext,
			        xhp->xha_datlen,xhp->xha_datreg);
			}
		}
		len = strlen(fmt);
		strcpy(&fmt[len],")");
	}
	else strcpy(&fmt[len]," Index=NULL");
	len = strlen(fmt);
	return len;
}

/****************************************/
/*										*/
/****************************************/
void cl_debug_out_info_parm5(level,file,line,format,pInfo,a1,a2,a3,a4,a5)
int  level,line;
char *file,*format,*a1,*a2,*a3,*a4,*a5;
tdtINFO_PARM *pInfo;
{
	char   c,c0,*p,buf[256*2+256/4+1],fmt[600],*argv[5],*varnam,*pdat,*fm,*pb,*dfmt;
	char   wrk[300];
	int    len,ix,attr,iRANGE,i,pb_len,iINTVAL,rc,wlen;
	long   lVal,lVal2,lVal3,dlen;
	double dVal,dVal2,dVal3;
	tdtArrayIndex *pIndex;
	ScrPrCT *pScCT;
	tdtINFO_PARM *pInfoParm;
	XHASHB *xhp;
	parmList  **parmName;
	tdtDefType *pDeftype;
	int ntype,ihx,nlen;
	tdtRB_CTL *pRb;
	MPA *ma;

	if (!format) return;
	if (akb_log_out_check(D_LOG_NO_DEBUG,level,file,line) > 0) {
		argv[0] = a1;
		argv[1] = a2;
		argv[2] = a3;
		argv[3] = a4;
		argv[4] = a5;
		len = akxa_log_printf_len(buf,sizeof(wrk)-1,format,5,argv);
		snprintf(wrk,sizeof(wrk),buf,argv[0],argv[1],argv[2],argv[3],argv[4]);
		_per_check(fmt,sizeof(fmt),wrk);
		len = strlen(fmt);
/*
printf("cl_debug_out_info_parm:Enter len=%d fmt=[%s] buf=[%s]\n",len,fmt,buf);
*/
		if (_log_addr_invalid(pInfo,"pInfo",fmt,file,line)) return;
		else if ((c=pInfo->pi_id) == 'A' || c == 'R') {
			len = cl_debug_array_info(fmt,len,pInfo);
			varnam = (char *)pInfo->pi_pos;
			cl_debug_out_level(level,file,line,"%s varnam=[%s]",fmt,varnam,0,0,0);
		}
		else if (c=='S' || (c==D_DATA_ID_PNAME && pInfo->pi_attr==2)) {
			memcpy(&pInfoParm,pInfo->pi_data,pInfo->pi_dlen);
			sprintf(&fmt[len]," pInfo=%08x id=0x%02x[%c] attr=%d scale=0x%02x dlen=%d len(gid)=%d hlen=%08x aux=0x%02x 0x%02x auxlen=%04x %08x data=%08x",
			        pInfo,pInfo->pi_id,c,pInfo->pi_attr,pInfo->pi_scale,
			        pInfo->pi_dlen,pInfo->pi_len,pInfo->pi_hlen,pInfo->pi_aux[0],pInfo->pi_aux[1],
			        pInfo->pi_alen,pInfo->pi_paux,pInfoParm);
			cl_debug_out_level(0,file,line,"%s",fmt,0,0,0,0);
			if (pInfo == pInfoParm) cl_debug_out_level(0,file,line,"pInfoParm==pInfoParm->pi_data",0,0,0,0,0);
			else {
				if (c==D_DATA_ID_PNAME && (p=pInfo->pi_paux)) {
					fm = "pi_paux=[%s]";
				}
				else fm = "";
				cl_debug_out_info_parm(level,file,line,fm,pInfoParm,p,0);
			}
		}
		else {
			if (!(c0=c=pInfo->pi_id)) c = ' ';

			if (!instrchar(" ARFSULPTCIMOENG2",c0)) {
				ix = 0;
				if (c0) {
					p = "invalid id";
					ix = 1;
				}
				else {
					p = "unset data";
					if (mem_sum_byte(pInfo,sizeof(tdtINFO_PARM))) ix = 1;
				}
				if (ix) akxm_mem_sdump(pInfo,sizeof(tdtINFO_PARM),buf);
				else *buf = '\0';
				strcpy(&fmt[len]," pInfo=%08x id=0x%02x[%c] %s %s");
				cl_debug_out_level(0,file,line,fmt,pInfo,c0,c,p,buf);
				return;
			}
			attr = pInfo->pi_attr;
			dlen = pInfo->pi_dlen;
			pdat = pInfo->pi_data;
			if (pdat) {
				if (_log_addr_invalid(pdat,"pdat",&fmt[len],file,line)) return;
			}
			iRANGE = pInfo->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
			iINTVAL = pInfo->pi_alen & D_AULN_RANGE_INTVAL;
			sprintf(&fmt[len]," pInfo=%08x id=0x%02x[%c] attr=%d scale=0x%02x code=%d dlen=%d len(gid)=%d hlen=%d pos=%d(%08x) aux=0x%02x 0x%02x auxlen=%04x %08x data=%08x ",
			        pInfo,pInfo->pi_id,c,attr,pInfo->pi_scale,
			        pInfo->pi_code,dlen,pInfo->pi_len,pInfo->pi_hlen,pInfo->pi_pos,pInfo->pi_pos,
			        pInfo->pi_aux[0],pInfo->pi_aux[1],pInfo->pi_alen,pInfo->pi_paux,pdat);
			len = strlen(fmt);
/*
printf("cl_debug_out_info_parm: len=%d fmt=[%s]\n",len,fmt);
*/
			if (c == 'P' || c == 'T') {
				varnam = (char *)pInfo->pi_pos;
				pDeftype = (tdtDefType *)pdat;
				sprintf(&fmt[len]," size=%d data=0x%08x ntype=%d vname=0x%08x pType=0x%08x",
				        pDeftype->size,pDeftype->data,pDeftype->ntype,pDeftype->vname,pDeftype->pType);
				cl_debug_out_level(0,file,line,"%s varnam=[%s]",fmt,varnam,0,0,0);
				if (c == 'T') {
					ihx = akxs_xhasl(pGLprocTable->pha_gid,'R',pInfo->pi_len,0);
/*
printf("cl_debug_out_info_parm: R gid=%ld ihx=%d\n",pInfo->pi_len,ihx);
*/
				}
				else ihx = 1;
				if (ihx) {
					parmName = pDeftype->vname;
					if (_log_addr_invalid(parmName,"parmName",&fmt[len],file,line)) return;
				}
				else {
					nlen = 0;
					p = "***";
				}
				if (_log_addr_invalid(pDeftype->pType,"pDeftype->pType",&fmt[len],file,line)) return;
				for (ix=0;ix<pDeftype->ntype;ix++) {
					if (ihx) {
						nlen = parmName[ix]->prmlen;
						p = parmName[ix]->prp;
					}
					cl_debug_out_info_parm(level,file,line," vnlen=%d %s:",pDeftype->pType[ix],nlen,p);
				}
			}
			else if (c=='L' || c=='N') {
				pRb = (tdtRB_CTL *)pdat;
				sprintf(&fmt[len],"\n rb_bfsize=%d rb_max=%d rb_num=%d rb_used=%d rb_pos=%d rb_raddr=0x%08x rb_waddr=0x%08x rb_wpriv=0x%08x rb_cur=0x%08x",
				        pRb->rb_bfsz,pRb->rb_max,pRb->rb_num,pRb->rb_used,pRb->rb_pos,
						pRb->rb_raddr,pRb->rb_waddr,pRb->rb_wpriv,pRb->rb_cur);
				cl_debug_out_level(0,file,line,"%s",fmt,0,0,0,0);
			}
			else {
				if (!pdat) {
					cl_debug_out_level(0,file,line,"%sNULL",fmt,0,0,0,0);
				}
				else if (attr!=DEF_ZOK_BULK && iRANGE) {
					cl_log_range_str(pInfo,&p);
					if (!p) p = "";
					fm = "%s%s";
					cl_debug_out_level(0,file,line,fm,fmt,p,0,0,0);
				}
				else if (attr == DEF_ZOK_CHAR) {
/*
printf("cl_debug_out_info_parm:CHAR fmt=[%s]\n",fmt);
*/
					fm = "%s[%s]";
					cl_debug_out_level(0,file,line,fm,fmt,pdat,0,0,0);
				}
				else if (attr == DEF_ZOK_BINA) {
					lVal = cl_get_data_long(pInfo);
					fm = "%s%d";
					cl_debug_out_level(0,file,line,fm,fmt,lVal,0,0,0);
				}
				else if (attr == DEF_ZOK_FLOA) {
					fm = "%s%e";
					cl_debug_out_level(0,file,line,fm,fmt,pdat,0,0,0);
				}
				else if (attr == DEF_ZOK_DECI) {
					ma = (MPA *)pdat;
/*
m_print_debug("ma",ma,0);
*/
					pb_len = sizeof(buf)-140;
					rc = m_mpa2an(ma,buf,pb_len,pGlobTable->options[10]);
/*
printf("cl_debug_out_info_parm:DEC rc=%d buf=[%s]\n",rc,buf);
*/
					if (rc < 0) {
						strcpy(buf,"##ERROR##");
						ix = strlen(buf);
					}
					else {
						ix = strlen(buf) + 1;
						p = buf + ix;
						pb_len -= ix;
						fm = "%s%s%s";
						ma = (MPA *)pdat;
						dlen = ma->len;
						sprintf(p," e/z/l=%d/%d/%d num=",ma->exp,ma->zero,dlen);
						wlen = strlen(p);
						pb_len -= wlen;
						p += wlen;
						if(ma->sign) *p = '-';
						else *p = '+';
						p++;
						strcpy(p,"0");
						pdat = ma->num;
						for (i=0;i<dlen;i++) {
							if (pb_len < 12) break;
							sprintf(p,"%d ",*pdat++);
							wlen = strlen(p);
							pb_len -= wlen;
							p += wlen;
						}
					}
/*
printf("cl_debug_out_info_parm:DEC fm=[%s] fmt=[%s] buf=[%s] buf+ix=[%s]\n",fm,fmt,buf,buf+ix);
*/
					cl_debug_out_level(0,file,line,fm,fmt,buf,buf+ix,0,0);
				}
				else if (attr == DEF_ZOK_DATE) {
					dfmt = D_LOG_DATE_FORMAT;
					ma = (MPA *)pdat;
					pb_len = sizeof(buf)-140;
					akxc_date2str(buf,--pb_len,dfmt,strlen(dfmt),ma);
					ix = strlen(buf)+1;
					p = buf + ix;
					pb_len -= ix;
					fm = "%s%s%s";
					ma = (MPA *)pdat;
					*p++ = ' ';
					dlen = 7;
					pdat = ma->num;
					for (i=0;i<dlen;i++) {
						if (pb_len < 12) break;
						sprintf(p,"%d ",*pdat++);
						wlen = strlen(p);
						pb_len -= wlen;
						p += wlen;
					}
					sprintf(p,"%d ",akxcmb2ul(pdat,3));
					p += strlen(p);
					pdat += 3;
					sprintf(p,"%d %d ",*pdat,*(pdat+1));
					p += strlen(p);
					pdat += 2;
					sprintf(p,"%d ",akxcmb2ul(pdat,2));
					cl_debug_out_level(0,file,line,fm,fmt,buf,buf+ix,0,0);
				}
				else if (attr==DEF_ZOK_BULK || c=='2') {
					if ((len=dlen) > 256) len = 256;
					len = akxcxtocn(pdat,len,buf,sizeof(buf),-4);
					cl_debug_out_level(0,file,line,"%s%s",fmt,buf,0,0,0);
				}
				else {
					cl_debug_out_level(0,file,line,"%s%s",fmt,"**INVALID**",0,0,0);
				}
			}
			if (pInfo->pi_alen & D_AULN_PARMINFO2)
				cl_debug_out_info_parm(level,file,line,"PARMINFO2:",pInfo+1,0,0);
		}
	}
}

/****************************************/
/*										*/
/****************************************/
void cl_debug_out_info_parm(level,file,line,format,pInfo,a1,a2)
int  level,line;
char *file,*format,*a1,*a2;
tdtINFO_PARM *pInfo;
{
	cl_debug_out_info_parm5(level,file,line,format,pInfo,a1,a2,0,0,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_debug_out_level(level,file,line,fmt,a1,a2,a3,a4,a5)
int  level,line;
char *file,*fmt,*a1,*a2,*a3,*a4,*a5;
{
	return cl_log_out_opt_l5(D_LOG_NO_DEBUG,level,0,file,line,fmt,a1,a2,a3,a4,a5);
}

/****************************************/
/*										*/
/****************************************/
int cl_debug_out_return(file,line,func,ret)
char *file,*func;
int  line,ret;
{
	if (((CLcommon.dbgopt[2] & 0x10) && ret<0) ||
	    ((CLcommon.dbgopt[2] & 0x20) && ret!=0))
		cl_log_out_l5(D_LOG_NO_DEBUG,0,file,line,"<---%s: return %d",func,ret,0,0,0);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int func_log(pAns,pOperator,nparm,ppParm,ope)
char *pAns;
char *pOperator;
tdtINFO_PARM **ppParm;
int nparm,ope;
{
	tdtINFO_PARM *pInfoParm;
	ScrPrCT *scrprct;
	int  line,logno,level,pri,syspri,iRc,len_f;
	char buf[256],*pWork,*format,*file,*p;

	if (iRc=cl_get_parm_bin(ppParm[0],&logno,"func_log:log_no/syspri:")) return -1;

	if (scrprct = cl_search_src_ct()) file = scrprct->pId;
	else file = AKX_NULL_PRINT;
	line = pGlobTable->script_line;

	pInfoParm = ppParm[1];
	len_f = pInfoParm->pi_dlen;
	if (len_f > 0) {
		if (pInfoParm->pi_attr != DEF_ZOK_CHAR) return -2;
		format = pInfoParm->pi_data;
		if ((iRc=cl_edit_sub(&pWork,format,nparm-2,&ppParm[2])) < 0) return iRc;
	}
	else pWork = "";

	if (ope==D_FUC_LOGOUT) {
		level = 0;
		pri = 0;
		akb_log_out_level_pri_main(logno,level,file,line,pri,pWork,0,0,0,0,0);
	}
	else if (ope==D_FUC_SYSLOG) {
		p = akb_log_get_proc_name();
		if (strlen(p)+strlen(file)+16 <= sizeof(buf)) {
			sprintf(buf,"%s/%s(%d): ",p,file,line);
		}
		else buf[0] = '\0';
		syspri = logno;
		syslog(syspri,"%s%s",buf,pWork);
	}
	iRc = 0;
	memcpy(pAns,&iRc,sizeof(int));
	return 0;
}

#define MAXLOGPARM	7

/****************************************/
/*										*/
/****************************************/
int func_get_log_parm(pAns,nparm,ppParm)
char *pAns;
int nparm;
tdtINFO_PARM **ppParm;
{
	int rc,iRc,i,maxargs,ix,*index;
	tdtINFO_PARM *pInfoParm,rInfoParm;
	tdtINFO_PARM ***pTBL;
	char *fn;
	tdtArrayIndex tIndex,*pIndex;
	long iParm[MAXLOGPARM];

	if (rc=cl_set_log_parmi(ppParm[0],NULL,iParm,0)) return rc;
	else if (iParm[0] < 0) iParm[0] = 0;

	pIndex = &tIndex;
	if (iRc=cl_get_ITBL_maxargs_ref(nparm-1,&ppParm[1],&pIndex,&pTBL,1,MAXLOGPARM,&maxargs,NULL)) return iRc;

	akb_log_set_parm2(1,NULL,maxargs,iParm);

	index = pIndex->index;
	ix = index[3];
	for (i=0;i<maxargs;i++,ix++) {
		pInfoParm = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'s');
		if (pInfoParm) {
			if (i == 6) {
				if (!(fn=(char *)iParm[i])) fn = AKX_NULL_PRINT;
				cl_set_parm_char(&rInfoParm,fn,strlen(fn));
			}
			else {
				cl_set_parm_long(&rInfoParm,iParm[i]);
			}
			if (iRc=cl_gx_rep_info_set_ign(pInfoParm,&rInfoParm,1)) return iRc;
		}
		else {
			return -1;
		}
	}
	memcpy(pAns,&maxargs,sizeof(int));
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_log_parmi(pInfoParm,argv,iParm,ix)
tdtINFO_PARM *pInfoParm;
char *argv[];
long iParm[];
int ix;
{
	int i,rc;
	long logno;
	char c;

	i = ix;
	iParm[i] = -1;
	if (!pInfoParm) return -1;
	if (pInfoParm->pi_dlen > 0) {
		if (rc=cl_check_data_id(pInfoParm,0)) return rc+ECL_CHK_VAR_ERROR;
		c = pInfoParm->pi_attr;
		if (i==0 || i==6) {
			if (i == 0) {
				if (c == DEF_ZOK_CHAR) {
					if ((logno=akb_get_log_no(strname(pInfoParm->pi_data,pInfoParm->pi_dlen))) >= 0) {
						iParm[i] = logno;
						goto L_ix0;
					}
				}
			}
			else if (c == DEF_ZOK_CHAR) {
				if (argv) argv[i] = pInfoParm->pi_data;
				else iParm[i] = (long)pInfoParm->pi_data;
				return 0;
			}
			else {
				/* cl_set_logparmi: ���O�t�@�C�����̌^(%d)�������Ă��܂���B */
				ERROROUT1(FORMAT(414),c);
 				return ECL_SCRIPT_ERROR;
			}
		}
		if (i>0 && c==DEF_ZOK_CHAR && argv) argv[ix] = pInfoParm->pi_data;
		else {
			if (rc=cl_get_parm_long(pInfoParm,&iParm[i],"cl_set_logparmi: ")) return rc;
			if (i == 0) goto L_ix0;
			if (argv) argv[i] = ".";
		}
	}
	else if (argv) argv[i] = ".";
	return 0;
L_ix0:
	if (!akb_get_log_name(iParm[i])) {
		/* cl_set_logparmi: ���O�ԍ�(%d)���s���ł��B */
		ERROROUT1(FORMAT(415),logno);
		return -1;
	}
	if (argv) argv[i] = ".";
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int func_set_log_parm(pAns,nparm,ppParm)
char *pAns;
int nparm;
tdtINFO_PARM **ppParm;
{
	int i,rc,nm;
	long iParm[MAXLOGPARM];
	char *argv[MAXLOGPARM];

	nm = X_MIN(nparm,MAXLOGPARM);
	for (i=0;i<nm;i++) {
		if (rc=cl_set_log_parmi(ppParm[i],argv,iParm,i)) return rc;
/*
printf("func_set_log_parm: i=%d argv=[%s] iParm=%08x\n",i,argv[i],iParm[i]);
*/
	}
	akb_log_set_parm2(-nm,argv,nm,iParm);
	memcpy(pAns,&nm,sizeof(int));
	_set_log_flg_cd_opt(-1,0x02);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int func_res_log_parm(pAns,nparm,ppParm)
char *pAns;
int nparm;
tdtINFO_PARM **ppParm;
{
	int rc,i,maxargs,ix,*index;
	tdtINFO_PARM *pInfoParm;
	tdtINFO_PARM ***pTBL;
	char c;
	tdtArrayIndex tIndex,*pIndex;
	long iParm[MAXLOGPARM];

	pIndex = &tIndex;
	if (rc=cl_get_ITBL_maxargs_ref(nparm,ppParm,&pIndex,&pTBL,1,MAXLOGPARM,&maxargs,NULL)) return rc;
	index = pIndex->index;
	ix = index[3];
	for (i=0;i<maxargs;i++,ix++) {
		pInfoParm = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'s');
		if (pInfoParm) {
			c = pInfoParm->pi_attr;
			if ((i==6 && c!=DEF_ZOK_CHAR) || (i!=6 && c!=DEF_ZOK_BINA)) {
				/* let_log_parm: �p�����[�^�̌^(%d)�������Ă��܂���B */
				ERROROUT2(FORMAT(285),"cl_res_logparm:",c);
				return -1;
			}
			if (i == 6) iParm[i] = (long)pInfoParm->pi_data;
			else iParm[i] = cl_get_data_long(pInfoParm);
		}
		else return -1;
	}
	akb_log_set_parm2(maxargs,NULL,maxargs,iParm);
	memcpy(pAns,&maxargs,sizeof(int));
	_set_log_flg_cd_opt(-1,0x02);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_range_str_opt(pInfo,ppStr,opt)
tdtINFO_PARM *pInfo;
char **ppStr;
int opt;	/* 0:general, 1:for log */
{
	char   c,c0,*p,*pdat,*fm,wrk[100],buf[200],ww[2],*pp,*p0,*dfmt,dform[30];
	int    len,attr,iRANGE,dlen,iINTVAL,i,ix,pb_len,iCOMPLEX;
	long   lVal,lVal2,lVal3;
	double dVal,dVal2,dVal3;
	MPA *ma;

	if(!(iRANGE = pInfo->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA))) {
		pp = "no range data";
		len = strlen(pp);
		*ppStr = pp;
		return len;
	}
	iCOMPLEX = pInfo->pi_alen & D_AULN_COMPLEX_DATA;
	pp = NULL;
	attr = pInfo->pi_attr;
	dlen = pInfo->pi_dlen;
	pdat = pInfo->pi_data;
	iINTVAL = pInfo->pi_alen & D_AULN_RANGE_INTVAL;
	if (!pdat) {
		p = "(NULL)";
	}
	else if (attr == DEF_ZOK_CHAR) {
		if (iINTVAL) {
			fm = "[%s]..[%s]..%d";
			lVal3 = pInfo->pi_hlen;
		}
		else fm = "[%s]..[%s]";
		sprintf(wrk,fm,pdat,pdat+dlen,lVal3);
	}
	else if (attr == DEF_ZOK_BINA) {
		lVal = cl_get_data_long(pInfo);
		if (iINTVAL) {
			fm = "%d..%d..%d";
			memcpy(&lVal2,pInfo->pi_data+dlen,dlen);
			lVal3 = pInfo->pi_hlen;
		}
		else {
			if (iCOMPLEX) fm = "%d+%di";
			else fm = "%d..%d";
			lVal2 = pInfo->pi_hlen;
		}
		sprintf(wrk,fm,lVal,lVal2,lVal3);
	}
	else if (attr == DEF_ZOK_FLOA) {
		memcpy(&dVal,pdat,sizeof(double));
		memcpy(&dVal2,pdat+dlen,sizeof(double));
		if (iINTVAL) {
			fm = "%e..%e..%e";
			memcpy(&dVal3,pdat+dlen+dlen,sizeof(double));
		}
		else {
			if (iCOMPLEX) fm = "%e+%ei";
			else fm = "%e..%e";
		}
		sprintf(wrk,fm,dVal,dVal2,dVal3);
	}
	else if (attr == DEF_ZOK_DECI) {
		ma = (MPA *)pdat;
		pb_len = sizeof(buf);
		m_mpa2an(ma,buf,pb_len,pGlobTable->options[10]);
		ix = strlen(buf) + 1;
		p = buf + ix;
		pb_len -= ix;
		if (pInfo->pi_alen & D_AULN_RATIONAL) fm = "%s/%s";
		else if (iCOMPLEX) fm = "%s+%si";
		else fm = "%s..%s";
		ma = (MPA *)(pdat+dlen);
		m_mpa2an(ma,p,pb_len,pGlobTable->options[10]);
		p += strlen(p);
		if (iINTVAL) {
			strcpy(p,"..");
			p += 2;
			ma = (MPA *)(pdat+dlen+dlen);
			m_mpa2an(ma,p,pb_len,pGlobTable->options[10]);
			p += strlen(p);
		}
		ma = (MPA *)pdat;
		dlen = ma->len;
		sprintf(wrk,fm,buf,buf+ix);
	}
	else if (attr == DEF_ZOK_DATE) {
		if (opt) dfmt = D_LOG_DATE_FORMAT;
		else {
			dform[0] = '(';
			strcpy(dform+1,D_SQL_DATE_FORMAT);
			strcat(dform,")");
			dfmt = dform;
		}
		ma = (MPA *)pdat;
		pb_len = sizeof(buf);
		akxc_date2str(buf,--pb_len,dfmt,strlen(dfmt),ma);
		ix = strlen(buf)+1;
		p0 = buf + ix;
		p = p0;
		pb_len -= ix;
		fm = "%s..%s";
		ma = (MPA *)(pdat+dlen);
		akxc_date2str(p,--pb_len,dfmt,strlen(dfmt),ma);
		p += strlen(p);
		if (iINTVAL) {
			strcpy(p,"..");
			p += 2;
			ww[0] = akxc_get_term_char(pInfo->pi_hlen);
			ww[1] = '\0';
			sprintf(p,"'%s %d'",ww,pInfo->pi_pos);
			p += strlen(p);
		}
		if (opt) {
			ma = (MPA *)pdat;
			*p++ = ' ';
			dlen = 7;
			pdat = ma->num;
			for (i=0;i<dlen;i++) {
				sprintf(p,"%d ",*pdat++);
				p += strlen(p);
			}
			sprintf(p,"%d ",akxcmb2ul(pdat,3));
			p += strlen(p);
			pdat += 3;
			sprintf(p,"%d %d ",*pdat,*(pdat+1));
			p += strlen(p);
			pdat += 2;
			sprintf(p,"%d ",akxcmb2ul(pdat,2));
		}
		sprintf(wrk,fm,buf,buf+ix);
	}
	else {
		pp = "**INVALID**";
		len = strlen(pp);
	}
	if (!pp) {
		len = strlen(wrk);
		if (pp = TEMPMalloc(len+1)) memzcpy(pp,wrk,len);
		else len = ECL_MALLOC_ERROR;
	}
	*ppStr = pp;
	return len;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_range_str(pInfo,ppStr)
tdtINFO_PARM *pInfo;
char **ppStr;
{
	return cl_get_range_str_opt(pInfo,ppStr,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_log_range_str(pInfo,ppStr)
tdtINFO_PARM *pInfo;
char **ppStr;
{
	return cl_get_range_str_opt(pInfo,ppStr,1);
}

/****************************************/
/*										*/
/****************************************/
void cl_log_debug_leaf(level,file,line,msg,leaf)
char *file,*msg;
int level,line;
Leaf *leaf;
{
	char buf[200],*p;
	int i,len,k;
	cmdInfo *cmd;
	parmList **prm;

	if (akb_log_out_check(D_LOG_NO_DEBUG,level,file,line) > 0) {
		*buf = '\0';
		if (_log_addr_invalid(leaf,"leaf",buf,file,line)) return;
		sprintf(buf,"%s(%08x): preleaf=%08x rightleaf=%08x leftleaf=%08x pFlag=%02x cmdtag=%02x type=%d",
				msg,leaf,leaf->preleaf,leaf->rightleaf,leaf->leftleaf,leaf->pFlag,leaf->cmdtag,leaf->type);
		cl_debug_out_level(level,file,line,"%s",buf,0,0,0,0);
		cmd = &leaf->cmd;
		sprintf(buf,"rc=%d cid=%08x sub_cid=%d type=%d pos=%d prmnum=%d prmp=%08x parl=%08x parnum=%d cmdobj=%08x",
				cmd->rc,cmd->cid,cmd->sub_cid,cmd->type,cmd->pos,cmd->prmnum,cmd->prmp,cmd->parl,cmd->parnum,cmd->cmdobj);
		cl_debug_out_level(level,file,line,"%s->%s: %s",msg,"cmd",buf,0,0);
		cl_debug_out_level(level,file,line,"%s: [%s]",msg,cl_get_pcmd_line(leaf),0,0,0);
	}
	return;
}
