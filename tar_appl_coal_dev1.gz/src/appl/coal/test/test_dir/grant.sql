grant select on T1 to kobay;
grant select on T2 to kobay;
