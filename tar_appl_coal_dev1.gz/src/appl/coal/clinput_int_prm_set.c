static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  							                              *
*                                                                             *
*      �֐����@�@�@�F�@int cl_input_int_prm_set( pprmList , iprm )			      *
*                      (O)prmList	*pprmList							      *	
*                      (I)int		iprm								      *	
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;

int cl_input_int_prm_set(pInfoParm,iprm)
tdtINFO_PARM	*pInfoParm;
int			iprm;
{
	int rc;

	info_parm_clear(pInfoParm);
	cl_set_parm_long(pInfoParm,(long)iprm);

	return NORMAL;
}
