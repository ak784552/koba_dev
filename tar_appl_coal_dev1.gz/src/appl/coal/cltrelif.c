static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_elseif              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else_if(y)
condList *y;
{
	static int able[]={C_IF,C_ELSEIF};
	static int deny[]={C_ELSE};

	return col_mn_tr_else_ifNode(y,deny,1,able,2);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_case(y)
condList *y;
{
	static char *_fn_="col_mn_tr_case";
/*	static int able[]={C_SWITCH,C_CASE};	*/
	static int able[]={C_SWITCH,C_CASE,C_DEFAULT};
	static int deny[]={C_DEFAULT};
	int  rc ,tree;
	Leaf *leaf;

#if 1	/* 2017.03.18 */
	if (rc=cl_tr_end_node_check(y,deny,0,able,3)) return rc;
#else
	if (rc=cl_tr_end_node_check(y,deny,1,able,2)) return rc;
#endif

	tree = cl_nest_tag(y,2);
	if (tree != -1) {
		leaf = y->clstcb->nestLev2;
		if (leaf->cmd.cid==C_SWITCH && leaf->rightleaf) {
			/* %s: SWITCH��CASE�̊Ԃɕ�������܂��B */
			ERROROUT1(FORMAT(541),_fn_);
			return ECL_TR_ELSEIF;
		}
		else if (!y->cmd->prmnum) {
			ERROROUT1(FORMAT(92),_fn_);	/* %s: �����K�v�ł� */
			return ECL_TR_ELSEIF;
		}
		rc=cl_change_tree(y,leaf);
/*
printf("col_mn_tr_else_if:cl_change_tree(y->CLSTCB.nestLev2) rc=%d\n",rc);
*/
		cl_search_nest(y,2);
	}
	else {
/*
printf("col_mn_tr_else_if:cl_nest_tag(2) tree=%d\n",tree);
*/
		return ECL_TR_ELSEIF;
	}

	if ((rc = cl_tr_gather(y,0)) >= 0) rc = cl_make_push_leaf(y);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_catch(y)
condList *y;
{
	static int able[]={C_TRY,C_CATCH};
	static int deny[]={C_FINALLY};
	int rc;

	if (!(rc=cl_tr_end_node_check(y,deny,1,able,2))) {
		if ((rc = cl_tr_gather(y,0)) >= 0) rc = cl_tr_else_nest_check(y);
	}
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else_ifNode(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_node_check(y,deny,1,able,2))) {
		if (!y->cmd->prmnum) {
			ERROROUT1(FORMAT(92),"col_mn_tr_else_if");	/* %s: �����K�v�ł� */
			rc =ECL_TR_ELSEIF;
		}
		else rc = cl_tr_else_nest_check(y);
	}
	return rc;
}
