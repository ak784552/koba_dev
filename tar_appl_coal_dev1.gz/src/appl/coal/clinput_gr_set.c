static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  							                              *
*                                                                             *
*      �֐����@�@�@�F�@int cl_input_grSet( pFrameTbl )					      *
*                      (I)pFrameInfo	*pFrameTbl						      *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;
extern CLCOMMON CLcommon;

int cl_input_gr_set(pFrameTbl)
pFrameInfo pFrameTbl;
{
	int i,j,rc,len;
	int Framenum,headlen,inumW;
	char cnumW[6];
	ScrPrCT *pScCT;
	tdtINFO_PARM *pprmList,*pInfoParm,rInfoParm;
	tdtINFO_PARM ***pTBL;
	tdtDataElm  *pDTbl;
	int *pSize;

	pScCT = cl_search_src_ct();
	pTBL = pScCT->Vary->pTBL_pasento;
#if 1	/* 2020.4.28 */
	cl_free_var_ent(pTBL);
	pScCT->Vary->varnam_pasento = 0;
#endif
	pSize = (int *)pTBL[0];
	for (i=1;i<=3;i++) {
		if (i == 1) inumW = pFrameTbl->field_1;
		else if (i == 2) inumW = pFrameTbl->iTuple;
		else inumW = pFrameTbl->iNode;
		if (!(pprmList = cl_get_var_ent(pTBL,i))) return -1;

DEBUGOUT_InfoParm(198,"cl_input_gr_set: pprmList: i=%d num=%d",pprmList,i,inumW);

		if (rc=cl_input_int_prm_set(pprmList,inumW)) return rc;
	}
/*
	for (;i<=pScCT->Vary->varnam_pasento;i++) {
		if (!(pprmList = cl_get_var_ent(pTBL,i))) return -1;
		memset(pprmList,0,sizeof(tdtINFO_PARM));
	}
*/
	Framenum = pFrameTbl->iNode;
	for (i=0,j=3;i<Framenum;i++,j++) {
		pInfoParm = cl_get_var_ent(pTBL,j+1);
		if (pFrameTbl->field_1 < 99000) {
			memcpy(&inumW,pFrameTbl->pDataTbl[i].pData,sizeof(int));
			if (rc=cl_input_int_prm_set(pInfoParm,inumW)) return rc;
		}
		else {
			pDTbl = &pFrameTbl->pDataTbl[i];
		/*	info_parm_clear(pInfoParm);	*/
			memset(pInfoParm,0,sizeof(tdtINFO_PARM));
			pInfoParm->pi_id   = ' ';
			pInfoParm->pi_attr = pDTbl->attr;
			if ((len=pDTbl->len) < 256)
				headlen = sizeof( FORM_S );
			else
				headlen = sizeof( FORM_K );
			pInfoParm->pi_hlen = 0;
			pInfoParm->pi_pos  = headlen;
			pInfoParm->pi_dlen = len;
			pInfoParm->pi_len  = headlen + len;
			pInfoParm->pi_data = pDTbl->pData;
			pInfoParm->pi_code = cl_code_type(0,0);
			if (pInfoParm->pi_attr == DEF_ZOK_CHAR) {
DEBUGOUT_InfoParm(198,"cl_input_gr: pInfoParm i=%d j+1=%d",pInfoParm,i,j+1);
				if ((rc=cl_code_trans(pInfoParm,&rInfoParm)) > 0) {
					cl_gx_copy_info(pInfoParm,&rInfoParm);
DEBUGOUT_InfoParm(198,"cl_input_gr: cl_code_trans pInfoParm rc=%d",pInfoParm,rc,0);
				}
			}
		}
	}
	pScCT->Vary->varnam_pasento = Framenum + 3;
	cl_set_parm_bin(cl_var_size_parm(pSize),Framenum+3);
	return NORMAL;
}

int cl_input_int_prm_set(pInfoParm,iprm)
tdtINFO_PARM	*pInfoParm;
int			iprm;
{
	int rc;

	info_parm_clear(pInfoParm);
	cl_set_parm_bin(pInfoParm,iprm);

	return NORMAL;
}
