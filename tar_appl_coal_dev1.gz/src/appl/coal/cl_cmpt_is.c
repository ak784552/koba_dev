static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************
*																		*
*	�����ړI�@�@�FIS  ���Z����											*
*																		*
*	�֐����@	�Fint cl_cmpt_is(pAns , pOprtr , nparm,ppParm)			*
*					(O)int		*pAns									*
*					(I)char  	*pOprtr									*
*					(I)int		nparm									*
*					(I)tdtINFO_PARM *pppParm[]							*
*																		*
*	�߂�l�@�@�@�FERROR									�@				*
*				  NORMAL												*
*																		*
*	�����T�v�@�@�F�@													*
*																		*
*************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable,*pCLprocTable;

int cl_str_width(p,len,code_type)
char *p;
int len,code_type;
{
	char *p1;
	int len1,m,n,w;

	p1 = p;
	len1 = len;
	n = 0;
	while (len1 > 0) {
		m = akxqmbsnelen(code_type,p1,len1);
		w = akxqmbsnwidth(code_type,p1,m);
		n += w;
		p1 += m;
		len1 -= m;
	}
	return n;
}
#if 1	/* 2024.12.17 */
int cl_cmpt_is(pAns,nparm,ppParm)
long *pAns;
int nparm;
tdtINFO_PARM *ppParm[];
#else
int cl_cmpt_is(pAns,pOprtr,nparm,ppParm,ope,opt)
long *pAns;
char *pOprtr;
int nparm,ope,opt;
tdtINFO_PARM *ppParm[];
#endif
{
	tdtINFO_PARM *pInfoParm1;
	tdtINFO_PARM *pInfoParm2;
	int  rc,len1,len2,i,attr,code_type,n;
	long lVal;
	char *p1,*p2,c,w1[16],c2;
	ParList3 par3;

	*pAns = 0;
	rc = NORMAL;
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			pInfoParm2 = ppParm[2];
			if (nparm > 3) {
				if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
					pInfoParm2 = ppParm[3];
				}
			}
		}
	}
	len2 = pInfoParm2->pi_dlen;
	p2   = pInfoParm2->pi_data;
	if (pInfoParm2->pi_attr != DEF_ZOK_CHAR /*|| len2==0*/) {
		/* cl_cmpt_is:�p�����[�^�Q�̌^�������Ă��܂���B */
		ERROROUT1(FORMAT(251),"cl_cmpt_is");
		return ECL_SCRIPT_ERROR;
	}
	pInfoParm1 = ppParm[0];
	attr = pInfoParm1->pi_attr;
	len1 = pInfoParm1->pi_dlen;
	p1   = pInfoParm1->pi_data;
	code_type = pInfoParm1->pi_code;
	c2 = toupper(*p2);
	n = strlen(D_STR_NAME_NULL);
	if (len2==n && !memicmp(p2,D_STR_NAME_NULL,n)) {
		*pAns = cl_is_null_value(pInfoParm1);
		return 0;
	}
	else if (cl_is_null_value(pInfoParm1) || cl_is_null_value(pInfoParm2)) {
#if 1	/* 2024.4.6 */
		return 0;
#else
		return -101;
#endif
	}
	if (c2=='N' || c2=='D' || c2=='F') {
		if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_FLOA || attr==DEF_ZOK_DECI) {
			if (attr == DEF_ZOK_BINA) lVal = 1;
			else if (attr == DEF_ZOK_FLOA) lVal = 2;
			else lVal = 3;
			*pAns = lVal;
			return 0;
		}
	}
	else if (c2=='X' && attr==DEF_ZOK_BULK) {
		*pAns = 1;
		return 0;
	}
	else if (c2=='T') {	/*** Type ***/
		if (pInfoParm1->pi_scale & D_DATA_UNSIGNED) attr |= DEF_ZOK_USMASK;
		*pAns = attr;
		return 0;
	}
	else if (c2=='I') {	/*** DataID ***/
		*pAns = (uchar)pInfoParm1->pi_id;
		return 0;
	}
/*
	p1 = w1;
	if ((len1 = parm_to_char(pInfoParm1,&p1,NULL))<0) {
		return ECL_SCRIPT_ERROR;
	}
*/
	if (nparm > 2) {
		if ((rc=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"")) < 0) return rc;
		p1 = par3.par;
		len1 = par3.parlen;
	}
	switch (c2) {
		case 'L':	/*** Length ***/
				if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
#if 1	/* 2021.7.12 */
				else if (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) {
					c2 = toupper(*(p2+1));
					if (c2 == 'W') len1 = cl_str_width(p1,len1,code_type);
					else if (c2 != 'B') len1 = akxqmlen_type(p1,len1,code_type);
				}
#else
				else if (toupper(*(p2+1))!='B' && (pCLprocTable->CurScr->pFlag & D_SCRPT_NEW_LEX))
					len1 = akxqmlen(p1,len1);
#endif
				*pAns = len1;
				break;
		case 'N':	/*** Numeric || Number ***/
		case 'D':	/*** Decimal ***/
		case 'F':	/*** FLOAT ***/
				if (len1>0) {
					if ((i=akxnskipin(p1,len1," \t")) < len1) {
						p1 += i;
						len1 = akxnrskipin(p1,len1-i," \t");
						if ((c=*p1)=='+' || c=='-') {
							p1++;
							len1--;
						}
						if ((i=cl_chk_digit_n(p1,len1)) >= 0) *pAns = i+1;
					}
				}
				break;
		case 'B':	/*** Blank ***/
		case 'S':	/*** Space ***/
				if (len1>0) {
					if (akxnskipin(p1,len1," \t") >= len1) *pAns = 1;
				}
				break;
		case 'X':	/*** hex ***/
				if (len1>0) {
					*pAns = 1;
					for (i=0;i<len1;i++) {
						if (((c=*p1++)==' ')||(c=='+')||(c=='-')||(c=='.')||
						    (c>='0'&&c<='9')||
						    (c>='A'&&c<='F')||(c>='a'&&c<='f'))
							;
						else {
							*pAns = 0;
							break;
						}
					}
				}
				break;
		case 'Z':	/*** Zenkaku ***/
		case 'H':	/*** Hankaku ***/
				i = akxqiskanji(p1);
				if (c2 == 'H') i = i ? 0 : 1;
				*pAns = i;
				break;
		case 'A':	/*** Ank ***/
				*pAns = akxqisank(*p1);
				break;
		case 'M':	/*** Moji byte ***/
#if 1	/* 2021.7.12 */
				i = akxqkanjilen2(p1,len1);
#else
				i = akxqiskanji(p1);
				if (!i) i = 1;
#endif
				*pAns = i;
				break;
		case 'W':	/*** Moji Display byte ***/
				*pAns = akxqkanjiw2(p1,len1);
				break;
		default:
			/* cl_cmpt_is:�p�����[�^�Q�Ɍ�肪����܂��B */
			ERROROUT(FORMAT(252));
			rc = ECL_SCRIPT_ERROR;
	}

	return rc;
}

/*	opt = 0 : lenm
 *	opt <>0 : lenw
 */
int cl_lenmw(pAns,mflg,nparm,ppParm,opt)
long *pAns;
int  mflg,nparm,opt;
tdtINFO_PARM *ppParm[];
{
	tdtINFO_PARM *pInfoParm1;
	int len1,attr,ret,code_type;
	char *p;

	pInfoParm1 = ppParm[0];
	if (pInfoParm1->pi_id == ' ') {
		len1 = pInfoParm1->pi_dlen;
		attr = pInfoParm1->pi_attr;
		code_type = pInfoParm1->pi_code;
		if (attr == DEF_ZOK_CHAR) {
			if (mflg && nparm>=2) {
				if ((ret=cl_get_code_type(ppParm[1],&code_type,NULL)) < 0) return ret;
			}
			if (opt)
				len1 = cl_str_width(pInfoParm1->pi_data,len1,code_type);
			else if (mflg)
				len1 = akxqmlen_type(pInfoParm1->pi_data,len1,code_type);
		}
		else if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
	}
	else len1 = sizeof(tdtINFO_PARM);
	*pAns = len1;
	return 0;
}

int cl_lenm(pAns,mflg,nparm,ppParm)
long *pAns;
int  mflg,nparm;
tdtINFO_PARM *ppParm[];
{
	return cl_lenmw(pAns,mflg,nparm,ppParm,0);
}
int cl_lenw(pAns,mflg,nparm,ppParm)
long *pAns;
int  mflg,nparm;
tdtINFO_PARM *ppParm[];
{
	return cl_lenmw(pAns,mflg,nparm,ppParm,1);
}
#if 0
int cl_lenm(pAns,mflg,nparm,ppParm)
long *pAns;
int  mflg,nparm;
tdtINFO_PARM *ppParm[];
{
	tdtINFO_PARM *pInfoParm1;
	int len1,attr;

	pInfoParm1 = ppParm[0];
	if (pInfoParm1->pi_id == ' ') {
		len1 = pInfoParm1->pi_dlen;
		attr = pInfoParm1->pi_attr;
		if (attr==DEF_ZOK_CHAR && mflg) {
			len1 = akxqmlen(pInfoParm1->pi_data,len1);
		}
		else if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
	}
	else len1 = sizeof(tdtINFO_PARM);
	*pAns = len1;
	return 0;
}

int cl_lenw(pAns,mflg,nparm,ppParm)
long *pAns;
int  mflg,nparm;
tdtINFO_PARM *ppParm[];
{
	tdtINFO_PARM *pInfoParm1;
	int len1,attr;

	pInfoParm1 = ppParm[0];
	if (pInfoParm1->pi_id == ' ') {
		len1 = pInfoParm1->pi_dlen;
		attr = pInfoParm1->pi_attr;
		if (attr == DEF_ZOK_CHAR) {
			len1 = cl_str_width(pInfoParm1->pi_data,len1);
		}
		else if (attr == DEF_ZOK_DATE) len1 = D_LEN_DATE;
	}
	else len1 = sizeof(tdtINFO_PARM);
	*pAns = len1;
	return 0;
}
#endif
