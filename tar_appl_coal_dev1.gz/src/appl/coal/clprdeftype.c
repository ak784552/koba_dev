static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clprdeftype.c>                                                  */
/*      Define process   �@                          */
/*                                            (2009/05/17 Ver 0.01) */
/********************************************************************/

#include "colmn.h"

extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
extern char cmp_sep2[];
extern MCAT2 *pGImplicit;
extern GXObjectExpand CLobjExp;	/* add 20231203 */

#if 1	/* 2020.10.25 */
static char *gsep=" \t(){}[],'=+-*/&|";
#else
static char *gsep=" \t(){}[],'=";
#endif

/************************************/
/*	cl_complex_attr_check			*/
/************************************/
int cl_complex_attr_check(iParm)
int iParm[];
{
	int i,rc;

	rc = 0;
	i = iParm[0] & DEF_ZOK_DTYP;
	if (i==DEF_ZOK_VARI || i==1 || i>DEF_ZOK_DECI) {
				/* %s: %s��'%s'�͎w��ł��܂���B*//*635 ���f��*/
		ERROROUT3(FORMAT(140),"cl_complex_attr_check",FORMAT(635),cl_get_attr_name_opt(iParm,1));
		rc = ECL_SCRIPT_ERROR;
	}
	else if (!i) {
		iParm[0] = DEF_ZOK_FLOA;
		iParm[1] = sizeof(double);
	}
	return rc;
}

/************************************/
/*	cl_get_def_attr_check			*/
/************************************/
int cl_get_def_attr_check(nparm,ppParm,iParm,opt)
int nparm;
tdtINFO_PARM *ppParm[];
int iParm[];
int opt;
{
	static char *name="cl_get_def_attr_check";
	int rc,n,attr,size,opt2;
	int dec_pre,dec_sca;
	char *p0;

	dec_pre = dec_sca = 0;
	attr = iParm[0];
	size = iParm[1];
	if (attr == DEF_ZOK_DECI) {
		rc = cl_get_parm_bin(ppParm[0],&dec_pre,"cl_get_def_attr_check: ");
		if (rc) {
			p0 = NULL;
			if ((rc=parm_to_char(ppParm[0],&p0,NULL)) < 0) return rc;
			/* %s: ���x(%s)������Ă��܂��Brc=%d */
			ERROROUT3(FORMAT(463),name,p0,rc);
			return ECL_SCRIPT_ERROR;
		}
		if (dec_pre<=0 || dec_pre>m_get_nmpa10()) {
			/* %s: ���x(%d)������Ă��܂��B */
			ERROROUT2(FORMAT(464),name,dec_pre);
			return ECL_SCRIPT_ERROR;
		}
		if (nparm >= 2) {
			rc = cl_get_parm_bin(ppParm[1],&dec_sca,"cl_get_def_attr_check: ");
			if (rc) {
				p0 = NULL;
				if ((rc=parm_to_char(ppParm[1],&p0,NULL)) < 0) return rc;
				/* %s: �ʎ��(%s)������Ă��܂��Brc=%d */
				ERROROUT3(FORMAT(475),name,p0,rc);
				return ECL_SCRIPT_ERROR;
			}
			if (X_ABS(dec_sca) > dec_pre) {
				/* %s: �ʎ��(%d)������Ă��܂��B */
				ERROROUT2(FORMAT(476),name,dec_sca);
				return ECL_SCRIPT_ERROR;
			}
		}
	}
	else {
		opt2 = opt & 0x02;
		if (opt2 || (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK)) {
			rc = cl_get_parm_bin(ppParm[0],&size,"cl_get_def_attr_check: ");
			if (rc) {
				p0 = NULL;
				if ((rc=parm_to_char(ppParm[0],&p0,NULL)) < 0) return rc;
				/* %s: �T�C�Y(%s)������Ă��܂��Brc=%d */
				ERROROUT3(FORMAT(461),name,p0,rc);
				return ECL_SCRIPT_ERROR;
			}
			if (size <= 0) {
				/* %s: �T�C�Y(%d)������Ă��܂��B */
				ERROROUT2(FORMAT(462),name,size);
				return ECL_SCRIPT_ERROR;
			}
		}
	}
	iParm[1] = size;
	iParm[2] = dec_pre;
	iParm[3] = dec_sca;
/*
printf("%s: attr=%d size=%d dec_pre=%d dec_sca=%d\n",name,attr,size, dec_pre,dec_sca);
*/
	return 0;
}

/************************************/
/*	_get_def_attr					*/
/************************************/
static int _get_def_attr(line0,llen,iParm,opt,bxobj,Obj)
char *line0;
int   llen;
int   iParm[];
int   opt;
GXObject *bxobj[];
tdtRB_CHAIN *Obj;
{
	int rc,nparm,attr,opt1;
	char *line;
	tdtINFO_PARM *ppParm[2],tInfoParm2[2],*pInfoParm;

	line = line0;
/*
printf("_get_def_attr: llen=%d line=[%s]\n",llen,line);
*/
	if (*line == '(') {
		line++;
		llen -=2 ;
	}
	nparm = rc = 0;
	attr = iParm[0];
/*
	iParm[2] = 0;
	iParm[3] = 0;
*/
	if ((opt & 0x02) || attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK || attr==DEF_ZOK_DECI) {
		iParm[2] = 0;
		iParm[3] = 0;
		opt1 = (opt & D_GX_OPT_GET_DEF_ATTR) | D_GX_OPT_PARMINFO2;
		rc = cl_gx_expsn_obj_opt(line,llen,bxobj,Obj,tInfoParm2,opt1);
		if (rc) {
			/* %s: �����A�܂��́A���x�A�ʎ��̎w��(%s)������Ă��܂��Brc=%d */
			ERROROUT3(FORMAT(478),"_get_def_attr",strtemp(line,llen),rc);
			return ECL_SCRIPT_ERROR;
		}
		else {
			if (nparm=tInfoParm2[1].pi_pos) {
				if (!(rc=tInfoParm2[1].pi_hlen)) {
					pInfoParm = (tdtINFO_PARM *)tInfoParm2[1].pi_data;
					ppParm[0] = pInfoParm;
					if (nparm >= 2) {
						ppParm[1] = pInfoParm + 1;
						nparm = 2;
					}
				}
			}
			else {
				ppParm[0] = tInfoParm2;
				nparm = 1;
			}
			if (!rc) rc = cl_get_def_attr_check(nparm,ppParm,iParm,opt);
		}
	}
	return rc;
}

/************************************/
/*	cl_get_def_attr_opt				*/
/************************************/
int cl_get_def_attr_opt(varnam,vnlen,iParm,opt,bxobj,Obj)
char *varnam;
int   vnlen;
int   iParm[];
int   opt;
GXObject *bxobj[];
tdtRB_CHAIN *Obj;
{
	int rc,len,attr,size,line_len,iGET;
	tdtSubCommand *sc;
	char *line;
/*
printf("cl_get_def_attr_opt: vnlen=%d varnam=[%s]\n",vnlen,varnam);
if (bxobj) printf("cl_get_def_attr_opt: *bxobj=%08x\n",*bxobj);
*/
	iGET = 0;
	if (varnam && vnlen>0) {
		attr = 0;
		size = sizeof(tdtINFO_PARM *);
		len = akxnskipto(varnam,vnlen,"(");
		if (sc=cl_get_name_attr2(varnam,len,0x01,0x20)) {
			size = sc->size;
			attr = sc->attr;
			if ((opt & 0x01) && (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK)) size = 0;
		}
		iParm[0] = attr & DEF_ZOK_MASK;	/* add & DEF_ZOK_MASK 2021.11.4 */
		iParm[0] |= attr & DEF_ZOK_IMGE;	/* add 2023.7.17 */
		iParm[1] = size;
		iParm[2] = 0;
		iParm[3] = attr & DEF_ZOK_USMASK;	/* add 2021.11.4 */
		if (iParm[0]==DEF_ZOK_BINA && (cl_get_option(17,0) & 0x100))
			iParm[3] |= DEF_ZOK_USMASK;
		line     = varnam + len;
		line_len = vnlen - len;
		if (vnlen > len) iGET = 1;
	}
	else {
		line     = "";
		line_len = 0;
		if (bxobj && bxobj[0]) iGET = 1;
	}
	rc = 0;
	if (iGET) {
	/*	rc = _get_def_attr(varnam+len,vnlen-len,iParm,opt,bxobj,Obj);	*/
		rc = _get_def_attr(line,line_len,iParm,opt,bxobj,Obj);
	}
/*
if (bxobj) printf("cl_get_def_attr_opt: iGET=%d *bxobj=%08x\n",iGET,*bxobj);
*/
	return rc;
}

/************************************/
/*	cl_set_parm_init				*/
/************************************/
int cl_set_parm_init(pInfoParm,iParm,opt)
tdtINFO_PARM *pInfoParm;
int iParm[],opt;
{
	int rc,attr,size,im,iRANGE;
	char *p;

	size = iParm[1];
	/* iParm[0]�ɂ́A21,22,23 �������ČĂ΂�邱�Ƃ�����̂ŁADEF_ZOK_MASK�Ń}�X�N�ł��Ȃ� */
	switch (attr=iParm[0]) {
		case 0:					/* add 2021.12.31 */
		case DEF_ZOK_VARI:
			rc = cl_parm_set0(pInfoParm);
			break;
		case DEF_ZOK_CHAR:
			rc = cl_set_parm_char(pInfoParm,NULL,0);
			break;
		case DEF_ZOK_BINA:
			rc = cl_set_parm_bin(pInfoParm,0);
			pInfoParm->pi_dlen = size;	/* add 2023.5.5 */
			if (iParm[3] == DEF_ZOK_USMASK) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
			break;
		case DEF_ZOK_FLOA:
			rc = cl_set_parm_double(pInfoParm,0.0);
			break;
		case DEF_ZOK_DECI:
		case DEF_ZOK_DATE:
			if (!(rc=cl_set_parm_mpa(pInfoParm,NULL))) {
				pInfoParm->pi_attr = attr;
				pInfoParm->pi_hlen = iParm[2];	/* precision */
				pInfoParm->pi_pos  = iParm[3];	/* scale */
			}
			break;
		case DEF_ZOK_BULK:
			rc = cl_set_parm_char(pInfoParm,NULL,0);
			pInfoParm->pi_attr = attr;
			break;
		default:
			rc = -100;
	}
/*
printf("cl_set_parm_init: attr=%d size=%d\n",attr,size);
*/
	if ((opt & 0x01) && attr && (attr!=DEF_ZOK_VARI) && !rc) {
		pInfoParm->pi_len = size;
		pInfoParm->pi_aux[0] = attr;
		iRANGE = opt & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		if ((attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) ||
		    (attr==DEF_ZOK_FLOA && iRANGE)) {
			if (attr == DEF_ZOK_CHAR) size++;
			else if (attr == DEF_ZOK_BULK) size += sizeof(int);
			im = (opt & D_GX_OPT_ALC_MASK)>>12;
			if (!im) im = D_OPT_ALC_MALLOC;
			if (im & (D_OPT_ALC_TMP | D_OPT_ALC_MALLOC)) {
				if (iRANGE) size += size;
				if (p = cl_opt_malloc(im,size)) {
					if ((attr==DEF_ZOK_DECI || attr==DEF_ZOK_DATE) && pInfoParm->pi_data)
						memcpy(p,pInfoParm->pi_data,size);
					else memset(p,0,size);
					if (im == D_OPT_ALC_MALLOC) pInfoParm->pi_scale |= D_DATA_MALLOC;
				}
				else rc = -1;
				pInfoParm->pi_data = p;
				pInfoParm->pi_scale &= ~D_DATA_LPOSDATA;
			}
			else rc = -1;
		}
		pInfoParm->pi_paux = pInfoParm->pi_data;
	}
DEBUGOUT_InfoParm(151,"cl_set_parm_init: attr=%d rc=%d",pInfoParm,attr,rc);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_skip_to_delm(s,slen,delms,ssp,sep,level)
char *s,*delms,*sep;
int  slen;
SSPL_S *ssp;
int  level;
{
	char c,delm1,delm2,*wd;
	int len,wd_max;
	int kk_level;	/* ()�̃l�X�g���x�� */

	kk_level = level;
	delm1 = delms[0];
	delm2 = delms[1];
	wd = ssp->wd;
	wd_max = ssp->wdmax;
	ssp->wdmax = 0;
	while ((len=akxtgwnsl(s,slen,ssp,sep,0x41)) > 0) {
		if (ssp->attr[0] > 10) {
			c = *ssp->wd;
/*
printf("cl_skip_to_delm: sp=%d c=[%c]\n",ssp->sp,c);
*/
			if (c == delm1) kk_level++;
			else if (c == delm2) {
				if (kk_level > 0) {
					kk_level--;
					if (!kk_level) break;
				}
				else return -2;
			}
		}
	}
	if (len < 0) kk_level = len;
/*
printf("cl_skip_to_delm: sp=%d kk_level=%d\n",ssp->sp,kk_level);
*/
	ssp->wd = wd;
	ssp->wdmax = wd_max;
	return kk_level;
}

/****************************************/
/*										*/
/****************************************/
int clpeeksl(s,slen,ssp,sep,opt)
char *s,*sep;
int  slen,opt;
SSPL_S  *ssp;
{
	int sp,len;

	if (!ssp) return -1;

	sp = ssp->sp;
	len = akxtgwnsl(s,slen,ssp,sep,opt);
	ssp->sp = sp;
	return len;
}

/************************************/
/*	cl_get_def_attr_SSP_opt_sub		*/
/*  OUT : ssp->sp : int,dec(p,q)���A�܂��́A����ȊO��1���[�h��ǂݍ��񂾈ʒu */
/************************************/
int cl_get_def_attr_SSP_opt_sub(s,slen,ssp,sep,iParm,opt,bxobj,Obj)
char *s;
int   slen;
SSPL_S *ssp;
char  *sep;
int   iParm[];
int   opt;	/* 0x01:size=0, 0x02:int(n), 0x04:only error when (, 0x08: error when no attr */
GXObject *bxobj[];
tdtRB_CHAIN *Obj;
{
	static char *_fn_="cl_get_def_attr_SSP_opt";
	int rc,len,pos,wdmax_save;
	int attr,size,dec_pre,dec_sca;
	tdtSubCommand *sc;
	char *line,*attr_name,*wrk,c,*wd_save;
/*
printf("cl_get_def_attr_SSP_opt_sub:Enter ssp->sp=%d\n",ssp->sp);
*/
	if ((!s || slen<=0) && (bxobj && bxobj[0])) {
		return _get_def_attr("",0,iParm,opt,bxobj,Obj);
	}
	rc = 0;
	attr = dec_pre = dec_sca = 0;
	size = sizeof(tdtINFO_PARM *);
	iParm[0] = 0;
	iParm[1] = size;
	iParm[2] = 0;
	iParm[3] = 0;
	wd_save = ssp->wd;
	wdmax_save = ssp->wdmax;
	ssp->wdmax = 0;
	len = akxtgwnsl(s,slen,ssp,sep,0x1);
	attr_name = ssp->wd;
/*
printf("cl_get_def_attr_SSP_opt_sub:1 ssp->sp=%d attr_name=[%s]\n",ssp->sp,attr_name);
*/
	if (len>0 && (((c=*attr_name)>='A' && c<='Z') || (c>='a' && c<='z') || (opt & 0x08))) {
		if (sc=cl_get_name_attr2(attr_name,len,0x01,0x20)) {
			size = sc->size;
			attr = sc->attr;
			if ((opt & 0x01) && (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK)) size = 0;
			iParm[0] = attr & DEF_ZOK_MASK;	/* add & DEF_ZOK_MASK 2021.11.4 */
			iParm[1] = size;
			iParm[3] = attr & DEF_ZOK_USMASK;	/* add 2021.11.4 */
/*
printf("cl_get_def_attr_SSP_opt_sub: iParm=%d %d %d %d\n",iParm[0],iParm[1],iParm[2],iParm[3]);
*/
		}
		if ((opt & 0x08) && !sc) goto AttrErr;
		else if (sc || ((opt & 0x04) && !sc)) {
			clpeeksl(s,slen,ssp,sep,0x41);
/*
printf("cl_get_def_attr_SSP_opt_sub:2 ssp->sp=%d\n",ssp->sp);
*/
			if (*ssp->wd == '(') {
				if (!sc) goto AttrErr;
				if ((opt & 0x02) ||
				    (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_DECI || attr==DEF_ZOK_BULK)) {
					pos = ssp->sp;
					line = s + pos;
					if (rc=cl_skip_to_delm(s,slen,"()",ssp,sep,0)) {
						/* %s: �J�b�R�����Ă��܂���B */
						ERROROUT1(FORMAT(433),_fn_);
						rc = ECL_SCRIPT_ERROR;
					}
					else {
						rc = _get_def_attr(line,ssp->sp-pos,iParm,opt|D_GX_OPT_GET_DEF_ATTR,bxobj,Obj);
					}
				}
			}
		}
	}
	else if (opt & 0x08) {
		/* %s: �����w�肪����܂���B */
		ERROROUT1(FORMAT(498),_fn_);
		rc = ECL_SCRIPT_ERROR;
	}
	goto End;
 AttrErr:
	wrk = strname(attr_name,len);
	/* %s: ����������Ă��܂��Battr=[%s] */
	ERROROUT2(FORMAT(477),_fn_,wrk);
	rc = ECL_SCRIPT_ERROR;
 End:
	ssp->wd = wd_save;
	ssp->wdmax = wdmax_save;
	return rc;
}

/************************************/
/*	cl_get_def_attr_SSP_opt			*/
/************************************/
int cl_get_def_attr_SSP_opt(s,slen,ssp,sep,iParm,opt,bxobj,Obj)
char *s;
int   slen;
SSPL_S *ssp;
char  *sep;
int   iParm[];
int   opt;	/* 0x01:size=0, 0x02:int(n), 0x04:only error when (, 0x08: error when no attr */
GXObject *bxobj[];
tdtRB_CHAIN *Obj;
{
	int rc,spw,iParm2[8];

	rc = cl_get_def_attr_SSP_opt_sub(s,slen,ssp,sep,iParm,opt,bxobj,Obj);
	if (!rc && iParm[0]>0) {
		spw = ssp->sp;
		if (rc=cl_get_def_attr_SSP_opt_sub(s,slen,ssp,sep,iParm2,0,NULL,Obj)) return rc;
		else if (iParm2[0] > 0) {
			ERROROUT1(FORMAT(365),FORMAT(588));	/* �f�[�^�^�w�肪�d�����Ă��܂��B */
			rc = ECL_DUPLICATE;
		}
		else ssp->sp = spw;
	}
	return rc;
}

/************************************/
/*	cl_get_def_attr_SSP				*/
/************************************/
int cl_get_def_attr_SSP(s,slen,ssp,sep,iParm,bxobj,Obj)
char *s;
int   slen;
SSPL_S *ssp;
char  *sep;
int   iParm[];
GXObject *bxobj[];
tdtRB_CHAIN *Obj;
{
	return cl_get_def_attr_SSP_opt(s,slen,ssp,sep,iParm,0x01,bxobj,Obj);
}

/************************************/
/*	cl_im_parmset					*/
/************************************/
int cl_im_parmset(im,qprmp,pp,len)
int  im;
parmList *qprmp[];
char *pp;
int  len;
{
	parmList *prmp;
	char *p;
	int rc;

	if (!(p=cl_opt_malloc(im,sizeof(parmList)+len+1))) return ECL_MALLOC_ERROR;
	prmp = (parmList *)p;
	memset(prmp,0,sizeof(parmList));
	p += sizeof(parmList);
	memzcpy(p,pp,len);
/*
printf("cl_im_parmset: n=%d len=%d wd=[%s]\n",n,len,p);
*/
	prmp->prp = p;
	prmp->prmlen = len;
	qprmp[0] = prmp;
	return 0;
}

/************************************/
/*	cl_im_parmcpy					*/
/************************************/
int cl_im_parmcpy(im,qprmp,prmp0)
int  im;
parmList *qprmp[],*prmp0;
{
	int rc;
	parmList *prmp;

	if (rc=cl_im_parmset(im,qprmp,prmp0->prp,prmp0->prmlen)) return rc;
	prmp = qprmp[0];
	prmp->opt = prmp0->opt;
	prmp->bxobj = prmp0->bxobj;
/*
printf("cl_im_parmcpy: bxobj=%08x\n",prmp->bxobj);
*/
	return 0;
}

/************************************/
/*	_parmset						*/
/************************************/
static int _parmset(qprmp,nmax,n,pp,len)
parmList *qprmp[];
int   nmax,n;
char *pp;
int  len;
{
	int rc;

	if ((rc=cl_im_parmset(D_OPT_ALC_TMP,&qprmp[n],pp,len)) >= 0) rc = n + 1;
	return rc;
}

/********1*********2*********3*********4*********5*********6*********/
/*	cl_get_array_def_parm											*/
/*	(nmax<=0 || !qprmp)�̂Ƃ��́A�z���`��ǂݔ�΂��B				*/
/*	���A����Ƃ��Assp.sp�́A�z���`�̎��̃��[�h��ǂ񂾌�̈ʒu�A	*/
/*	�z���`���Ȃ��Ƃ��́A�ŏ��Ƀ��[�h��ǂ񂾌�̈ʒu�A			*/
/*  �܂��́Aslen���w���B											*/
/********************************************************************/
int cl_get_array_def_parm(s,slen,dlm,ssp,sep,nmax,qprmp,iEQU)
char *s;
int   slen;
char  *dlm;
SSPL_S  *ssp;
char  *sep;
int   nmax;
parmList *qprmp[];
int  *iEQU;
{
	static char *name="cl_get_array_def_parm";
	int len,kk,n,iSET,iRANGE,is,atr0,kk_level,i,atr_gw;
	char c,c1,*p,*pp,wrk[128],k1,k2,wsep[37],*pat;
	parmList *prmp;
	SSPL_S  sspl;
	uchar uc;
/*
printf("%s:Enter: nmax=%d dlm=[%s] sep=[%s]\n",name,nmax,dlm,sep);
printf("%s:Enter: sp=%d slen=%d s=[%s]\n",name,ssp->sp,slen,s);
*/
	/*sep = cmp_sep2;*/	/* 2020.10.25 */
	len = clpeeksl(s,slen,ssp,sep,0x41);
/*
printf("%s: len=%d sp=%d wd=[%s]\n",name,len,ssp->sp,ssp->wd);
*/
	n = 0;
/*	if (len==4 && !memicmp(pp=ssp->wd,"HASH",4)) {	*/
	if (len > 0) {
		pp = strmem(ssp->wd,len);
/*
printf("%s: wd=[%s]\n",name,pp);
*/
		if (!stricmp(pp,"HASH")) {
			len = akxtgwnsl(s,slen,ssp,sep,0x41);
			if (n<nmax && qprmp) {
				if ((n=_parmset(qprmp,nmax,n,pp,len)) < 0) {
					return n;
				}
			}
			len = clpeeksl(s,slen,ssp,sep,0x41);
		}
#if 0	/* 2021.5.7 */
		else if (ssp->attr[0] == 1) {
			if (cl_is_yoyakugo(pp)) {
				ERROROUT2(FORMAT(121),name,pp);	/* %s: [%s]�͗\���ł��B */
				return ECL_EX_DEFINE;
			}
		}
#endif
	}
	if (len <= 0) {
/*
printf("%s:Exit: n=%d sp=%d wd=[%s]\n",name,n,ssp->sp,strmem(ssp->wd,len));
*/
		return n;
	}
	strcpy(p=wsep," \t'+-*/&|");
	p += strlen(p);
	pp = dlm;
	for (i=0;i<30 && (uc=*pp++);i++) {
		if (uc == '`');
		else if ((uc>=' ' && uc<'0') || (uc>'9' && uc <'A') ||
		    (uc>'Z' && uc<'a') || (uc>'z' && uc <0x7f)) *p++ = uc;
	}
	*p = '\0';
	if ((k1=*ssp->wd)=='[' || k1=='(') {
		kk = 1;
		akxtgwnsl(s,slen,ssp,sep,0x41);
		is = ssp->sp;
		if (k1 == '[') k2 = ']';
		else k2 = ')';
		*p++ = k1;
		*p++ = k2;
		strcpy(p,",");
		kk_level = 1;
	}
	else {
		is = ssp->sp;
		kk = 0;
	}
/*
printf("%s: kk=%d wsep=[%s]\n",name,kk,wsep);
*/
	iSET = iRANGE = 0;
	while ((len=akxtgwnsl(s,slen,ssp,wsep,0x41)) > 0) {
/*
printf("%s: n=%d sp=%d wd=[%s]\n",name,n,ssp->sp,strtemp(ssp->wd,len));
*/
		c = *ssp->wd;
		if (kk) {
			if (c == k2) {
				if (kk_level > 0) kk_level--;
				else {
					ERROROUT2("%s: '%c' unmatched.\n",name,c);
						return ECL_EX_DEFINE;
				}
				if (kk_level > 0) continue;
				iSET = ssp->sp;
/*
printf("%s: sp=%d\n",name,ssp->sp);
*/
				if ((len=akxtgwnsl(s,slen,ssp,wsep,0x41)) > 0) {
/*
printf("%s: len=%d sp=%d wd=[%s]\n",name,len,ssp->sp,strmem(ssp->wd,len));
*/
					if (*dlm == '`')
						pat = strname3("`",1,ssp->wd,len,"`",1);
					else
						pat = strname(ssp->wd,len);
/*
printf("%s: pat=[%s]\n",name,pat);
*/
					if (!inistr(dlm,pat)) {
#if 1	/* 2021.5.7 */
						ERROROUT2(FORMAT(567),name,pat);	/* %%s: �]���ȕ���(%s)������܂��B */
#else
						ERROROUT1(FORMAT(171),name);	/* %s: SYNTAX�G���[�B */
#endif
						return ECL_EX_DEFINE;
					}
					if (iEQU) *iEQU = ssp->sp;
				}
/*
printf("%s: len=%d sp=%d wd=[%s]\n",name,len,ssp->sp,strmem(ssp->wd,len));
*/
			}
			else if (c == ',') {
				iSET = ssp->sp;
			}
			else {
				if (c == k1) kk_level++;
				continue;
			}
		}
		else {
			if (instrchar("+-*/&|",c) > 0) {
				c1 = *(s+ssp->sp);
/*
printf("%s: c1=[%c]\n",name,c1);
*/
				if (c1 == '=') {
					ERROROUT1(FORMAT(171),name);	/* %s: SYNTAX�G���[�B */
					return ECL_EX_DEFINE;
				}
				else if (c1!=' ' && c1!='\t') continue;
				c1 = *(s+ssp->sp-2);
				if (c1!=' ' && c1!='\t') continue;
			}
			if (*dlm == '`')
				pat = strname3("`",1,ssp->wd,len,"`",1);
			else
				pat = strname(ssp->wd,len);
/*
printf("%s: pat=[%s]\n",name,pat);
*/
			if (inistr(dlm,pat)) {
/*
printf("%s: c=[%c]\n",name,c);
*/
				if (c=='=' && n>0) {
					sspl.sp = 0;
					sspl.wd = wrk;
					sspl.wdmax = sizeof(wrk);
					p = stradd(qprmp[n-1]->prp,"=");
					atr0 = cmpgwnsl(p,qprmp[n-1]->prmlen+1,&sspl);
/*
printf("%s: atr0=%d p=[%s]\n",name,atr0,p);
*/
					if (atr0>=71 && atr0<=90) n--;
				}
				if (c == '=') {
					if (iEQU) *iEQU = ssp->sp;
				}
				break;
			}
			pp = s + ssp->sp;
			for (i=ssp->sp;i<slen;i++) {
/*
printf("%s: i=%d c=[%c]\n",name,i,*pp);
*/
				if (instrchar(" \t\n\r,]=",*pp) > 0) break;
				pp++;
			}
			ssp->sp = i;
			iSET = ssp->sp + 1;
		}
		if (n<nmax && qprmp) {
		/*	if (kk) {	*/
				len = iSET - is - 1;
				pp = s + is;
		/*	}
			else pp = ssp->wd;	*/
#if 1	/* 2021.5.7 */
			pp = strmem(pp,len);
			if (!stricmp(pp,"HASH")) {
				ERROROUT2(FORMAT(469),name,pp);	/* %s: \"%s\"�̈ʒu���s���ł��B*/
				return ECL_EX_DEFINE;
			}
			else if (cl_is_yoyakugo(pp)) {
				ERROROUT2(FORMAT(121),name,pp);	/* %s: [%s]�͗\���ł��B */
				return ECL_EX_DEFINE;
			}
#endif
/*
printf("%s: n=%d sp=%d pp=[%s]\n",name,n,ssp->sp,strmem(pp,len));
*/
			if ((n=_parmset(qprmp,nmax,n,pp,len)) < 0) break;
		}
/*
printf("%s: c=[%c]\n",name,c);
*/
		if (c == k2) break;
		is = iSET;
	}
/*
printf("%s:Exit: n=%d sp=%d\n",name,n,ssp->sp);
*/
	return n;
}

/************************************/
/*	_def_type_mappedarray			*/
/************************************/
static int _def_type_mappedarray(nparm,qprmp,pIndex)
int nparm;
parmList *qprmp[];
tdtArrayIndex *pIndex;
{
	static char *_name_="_def_type_mappedarray";
	int *index,i,rc;

	memset(pIndex,0,sizeof(tdtArrayIndex));
	pIndex->uAttr[0] = DEF_ZOK_VARI;
	pIndex->size = sizeof(tdtINFO_PARM *);
	index = pIndex->index;
	index[0] = 1;
	index[2] = 0;
	for (i=0;i<=index[0];i++) index[i+3] = 1;
	index[4] = 10;
	index[1] = index[4];
	if (rc = _set_index(0,nparm,qprmp,0,index,_name_)) return rc;
	if (index[3]+index[1]-1 < 0) {
		/* %s: �͈͎w��([%d,%d,%d])���z��̍ő��(%d)�𒴂��Ă��܂��B */
		ERROROUT5(FORMAT(448),_name_,index[1],index[2],index[3],INT_MAX);
		return ECL_SCRIPT_ERROR;
	}
	return 0;
}

/****************************************/
/*	_get_def_member						*/
/*  type = array:						*/
/*		[�f�[�^�^] �z��^�� �z��̒�`	*/
/*  type = mappedarray:					*/
/*				   �z��^�� �z��̒�`	*/
/*  type = struct:						*/
/*		[�f�[�^�^] �ϐ���   �z��̒�`	*/
/****************************************/
static int _get_def_member(s,slen,ssp,varlen,pTypeInfo,parmName,type,opt,pos,bxobj,Obj)
char *s;
int  slen;
SSPL_S *ssp;
int  varlen;
tdtINFO_PARM *pTypeInfo[];
parmList  *parmName[];
int  type,opt,pos;
GXObject *bxobj[];
tdtRB_CHAIN *Obj;
{
	static char *_func="_get_def_member";
	int  i,iParmNo,rc,vnlen,attr,len,nparm,n,attr_set,kk,nset,is;
	int  size,iCOMPLEX,attr_set1;
	char c,*varnam,*pp,*p,*argv[6],*name,id;
	tdtINFO_PARM *pInfoParm,tInfoParm,tInfoParm2[2],tInfoType,*pInfoDef;
	tdtArrayIndex tIndex,*pIndex;
	int *index;
	int dec_pre,dec_sca,iParm[6];
	parmList *pL,**ppPrm,*prmpi,prmW;
	parmList *qprmp[4];
	ProcCT *proc;

	id = 'R';
	if (type == D_AUX0_TYPE_STRUCT) {
		name = FORMAT(465);	/* �����o�� */
		nset = 3;
	}
	else {
		name = FORMAT(466);	/* �^��`�� */
		if (type == D_AUX0_TYPE_ARRAY) nset = 3;
		else {
			nset = 4;
			id = 'A';
		}
	}

	varnam = ssp->wd;
	vnlen  = varlen;

	/* ���ڗL���`�F�b�N */
	vnlen = akxtpknsl(s,slen,ssp,gsep,0x41);
	if (vnlen<=0 || *varnam==',') {
		ERROROUT2(FORMAT(76),_func,name);	/* %s: %s������܂���B */
		return ECL_EX_DEFINE;
	}

	/* �ϐ��pInfoParm�̎擾 */
	if (!(pInfoParm=(tdtINFO_PARM *)Malloc(sizeof(tdtINFO_PARM)))) return ECL_MALLOC_ERROR;
	cl_parm_set0(pInfoParm);	/* add 2021.12.31 */
	pTypeInfo[0] = pInfoParm;

	/* �����̎擾 */
	iCOMPLEX = 0;
	if (id == 'R') {	/* MAPPEDARRAY�̂Ƃ��́A�����͎w��ł��Ȃ� */
#if 1	/* 2023.5.15 */
		if ((rc=clpeeksl(s,slen,ssp,gsep,0x41)) > 0) {
/*
printf("%s: rc=%d wd=[%s]\n",_func,rc,strname(ssp->wd,rc));
*/
			p = "COMPLEX";
			if (!memrngcmp_opt(ssp->wd,rc,p,0,strlen(p),1)) {
				iCOMPLEX = D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA;
				akxtgwnsl(s,slen,ssp,gsep,0x41);
/*
printf("%s: iCOMPLEX=%08x ssp->sp=%d\n",_func,iCOMPLEX,ssp->sp);
*/
			}
		}
		if ((rc=clpeeksl(s,slen,ssp,gsep,0x41)) > 0) {
			varnam = ssp->wd;
			vnlen  = rc;
/*
printf("%s: vnlen=%d varnam=[%s]\n",_func,vnlen,strname(varnam,vnlen));
*/
		}
#endif
		is = ssp->sp;
		if (rc=cl_get_def_attr_SSP(s,slen,ssp,gsep,iParm,NULL,NULL)) return rc;
		/* ���̎��_�Ńf�[�^�^�̎w�肪�Ȃ������Ƃ��́Assp->wd�ɂ͕ϐ���������A*/
		/* ssp->sp�͕ϐ����̌��Ɉړ����Ă��� */
		/* �f�[�^�^�̎w�肪�������Ƃ��́A���̌��̕ϐ�����ǂݍ��ޕK�v������ */
#if 1	/* 2023.5.15 */
		attr_set = iParm[0];
		if (iCOMPLEX) {
/*
printf("%s: iParm[0]=%d\n",_func,iParm[0]);
*/
			if ((rc=cl_complex_attr_check(iParm)) < 0) return rc;
		}
		if (!iParm[0]) {
#else
		attr_set = iParm[0];	/* >0 �̂Ƃ��A�f�[�^�^�̎w�肠�� */
		/* 2021.11.20 */
		if (!attr_set) {
#endif
		/*	iParm[0] = DEF_ZOK_VARI;	*/
			proc = cl_search_proc_ct();
			if ((rc=cl_get_def_type(s,slen,ssp,is,proc,NULL,0,iParm,&tInfoType)) < 0) return rc;
			/* ���̎��_�Ńf�[�^�^�̎w�肪�Ȃ������Ƃ��́Assp->sp�͌��̈ʒu�ɖ߂��Ă��� */
			attr_set = 1;
			if (!iParm[0]) {
#if defined(_LP64)	/* 2021.2.13 */
				memcpy(&pInfoDef,iParm+2,sizeof(char *));
				if (pInfoDef) {
#else
				if (pInfoDef = (tdtINFO_PARM *)iParm[2]) {
#endif
					iParm[0] = pInfoDef->pi_aux[0];
					cl_gx_rep_info_set_ign(pInfoParm,pInfoDef,1);
				}
				else iParm[0] = DEF_ZOK_VARI;
			}
		}
		else {
			attr = iParm[0];
			size = iParm[1];
			cl_set_parm_init(pInfoParm,iParm,0);
			if (attr != DEF_ZOK_VARI) {
				pInfoParm->pi_aux[0] = attr;
				pInfoParm->pi_len = size;
			}
			pInfoParm->pi_alen |= iCOMPLEX;
		}
	}
	else {
		attr_set = 1;	/* ssp->sp�͕ϐ����̑O�ɂ���̂ŁA�ϐ�����ǂݍ���ŁA
							�ϐ����̌�Ɉړ������邽�� */
		iParm[0] = attr = DEF_ZOK_VARI;
		cl_set_parm_init(pInfoParm,iParm,0);
	}
/*
printf("%s: id=[%c] iParm[0]=%d attr_set=%d sp=%d\n",_func,id,iParm[0],attr_set,ssp->sp);
*/
	/* �ϐ����̎擾 */
	if (attr_set) {
		vnlen = akxtgwnsl(s,slen,ssp,gsep,0x41);
		if (vnlen <= 0) {
			ERROROUT2(FORMAT(76),_func,name);	/* %s: %s������܂���B */
			return ECL_EX_DEFINE;
		}
		varnam = ssp->wd;
	}
#if 1
/*
printf("%s: vnlen=%d varnam=[%s]\n",_func,vnlen,strname(varnam,vnlen));
*/
	if ((c=*varnam)=='%' || c=='#') {
		ERROROUT2(FORMAT(125),_func,strname(varnam,vnlen));	/* %s: [%s]������Ă��܂��B*/
		return ECL_EX_DEFINE;
	}
	if (rc=cl_def_chk_name(varnam,vnlen,_func,name)) return rc;
	if (c == '$') {
		varnam++;
		vnlen--;
	}
#endif
	if (!(pL=(parmList *)Malloc(sizeof(parmList)))) return ECL_MALLOC_ERROR;
	parmName[0] = pL;
	pL->prp = Memdup(varnam,vnlen);
	pL->prmlen = vnlen;
	pL->opt = pos;
	if (attr == DEF_ZOK_BULK) size += sizeof(int);
	if (pInfoParm->pi_aux[0])
		pos += ((size+sizeof(int)-1)/sizeof(int))*sizeof(int);
#if 0
/*
printf("varnam=[%s] vnlen=%d\n",pL->prp,vnlen);
*/
	if (rc=cl_def_chk_name(varnam,vnlen,_func,name)) return rc;
#endif

	/* �z���`�̎擾 */
	n = cl_get_array_def_parm(s,slen,",",ssp,gsep,nset,qprmp,NULL);
	if (n < 0) return n;
	else if (n>0 || (type==D_AUX0_TYPE_ARRAY || type==D_AUX0_TYPE_MAPPED)) {
		if (id == 'R') {
			if (rc=_def_array(n,qprmp,opt|D_GX_OPT_NOALLOC_INDX,iParm,&tIndex,0,0)) return rc;
		}
		else {
			if (rc=_def_type_mappedarray(n,qprmp,&tIndex)) return rc;
		}
		attr = iParm[0];
		pInfoParm->pi_id   = id;
		pInfoParm->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
		pInfoParm->pi_attr = DEF_ZOK_BULK;	/* attr;	*/
		pInfoParm->pi_dlen  = sizeof(tdtArrayIndex);
		if (!(pInfoParm->pi_data = Malloc(sizeof(tdtArrayIndex)))) return ECL_MALLOC_ERROR;
		memcpy(pInfoParm->pi_data,&tIndex,sizeof(tdtArrayIndex));
		if (!(p=Malloc(vnlen+1))) {
			ERROROUT1("%s: Array name area malloc",_func);
			rc = ECL_MALLOC_ERROR;
			goto Error;
		}
		strnzcpy(p,varnam,vnlen);
		pInfoParm->pi_pos = (long)p;
		index = tIndex.index;
		size = tIndex.size;
		if (attr=tIndex.uAttr[0]) {
			if (attr == DEF_ZOK_CHAR) size++;
			else if (attr == DEF_ZOK_BULK) size += sizeof(int);
			len = index[1]*size;
			pos = pL->opt + ((len+sizeof(int)-1)/sizeof(int))*sizeof(int);
		}
		else pos = pL->opt;

DEBUGOUT_InfoParm(194,"cl_pr_ex_def_type: attr=%d size=%d",pInfoParm,attr,size);

/*
len = akxtgwnsl(s,slen,ssp,gsep,0x41);
printf("cl_pr_ex_def_type: len=%d *wd=[%c]\n",len,*ssp->wd);
*/
	}
	return pos;
 Error:
	return rc;
}

/************************************/
/*	cl_pr_ex_def_type				*/
/************************************/
int cl_pr_ex_def_type(prmnum, pprmp, scrct, proc, opt)
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	static char *sep=" \t(){}[],'";
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	XHASHB *pha_vname,*xhp;
	tdtINFO_PARM ***pTBL_vname;
	int  i,iParmNo,rc,vnlen,attr,len,nparm,n,attr_set,type,is;
	int  size,pos,slen;
	char c,*varnam,*pp,*p,*argv[7],*s;
	tdtINFO_PARM *pInfoParm,tInfoParm,tInfoParm2[2];
	tdtArrayIndex tIndex,*pIndex;
	int *index;
	int dec_pre,dec_sca,iParm[6];
	parmList  *parmName[MAX_MEMBER],*pL,**ppPrm,*prmpi,prmW;
	tdtINFO_PARM *pTypeInfo[MAX_MEMBER];
	tdtDefType *pDeftype;
	int ntype;
	SSPL_S ssp;
	parmList *qprmp[3];

	argv[0] = "cl_pr_ex_def_type";
	/* parameter check */
	/* DEFINE TYPE STRUCT name
	      var_type var_name,
	      var_type var_name;
	   DEFINE TYPE ARRAY var_type var_name;
	   DEFINE TYPE MAPPEDARRAY var_type var_name;	*/
	nparm = 3;
	if (prmnum >= 2) {
		p = pprmp[1]->prp;
		if (!stricmp(p,"ARRAY")) type = D_AUX0_TYPE_ARRAY;
		else if (!stricmp(p,"MAPPEDARRAY")) type = D_AUX0_TYPE_MAPPED;
		else if (!stricmp(p,"STRUCT")) {
			type = D_AUX0_TYPE_STRUCT;
			nparm++;
		}
		else type = -1;
	}
	if (prmnum < nparm) {
		/* %s: �p�����[�^������܂���Bprmnum=%d */
		ERROROUT2(FORMAT(467),argv[0],prmnum);
		return ECL_EX_DEFINE;
	}

	is = 2;
	pha_vname = NULL;
	if (type == D_AUX0_TYPE_STRUCT) {
		varnam = pprmp[2]->prp;
		vnlen  = pprmp[2]->prmlen;
		if ((c=*varnam)=='%' || c=='#') {
			ERROROUT2(FORMAT(125),argv[0],strname(varnam,vnlen));	/* %s: [%s]������Ă��܂��B*/
			return ECL_EX_DEFINE;
		}
		if (rc=cl_def_chk_name(varnam,vnlen,argv[0],FORMAT(466))) return rc;	/* �^��`�� */
		is = 3;
	}
	else if (type!=D_AUX0_TYPE_ARRAY && type!=D_AUX0_TYPE_MAPPED) {
		/* %s: �^�w�肪����Ă��܂��Btype=[%s] */
		ERROROUT2(FORMAT(468),argv[0],p);
		return ECL_EX_DEFINE;
	}

	ntype = pos = 0;
	s = pprmp[is]->prp;
	slen = pprmp[is]->prmlen;
/*
printf("cl_pr_ex_def_type: type=%d slen=%d s=[%s]\n",type,slen,s);
*/
	memset(&ssp,0,sizeof(SSPL_S));
	if (type==D_AUX0_TYPE_ARRAY || type==D_AUX0_TYPE_MAPPED) {
		if ((vnlen=clpeeksl(s,slen,&ssp,gsep,0x41)) > 0) {
			if ((pos=_get_def_member(s,slen,&ssp,vnlen,&pTypeInfo[0],&parmName[0],type,opt,pos,0,0)) < 0) {
				rc = pos;
				goto Error;
			}
			varnam = parmName[0]->prp;
			vnlen  = parmName[0]->prmlen;
		}
	}
	else {
		while ((vnlen=clpeeksl(s,slen,&ssp,sep,0x41)) > 0) {
			if ((pos=_get_def_member(s,slen,&ssp,vnlen,&pTypeInfo[ntype],&parmName[ntype],type,opt,pos,0,0)) < 0) {
				rc = pos;
				goto Error;
			}
			ntype++;
		}
		varnam = pprmp[2]->prp;
		vnlen  = pprmp[2]->prmlen;
	}
 	if (!(opt & D_GX_OPT_SET_SCOPE)) {
		if (proc) {
			if (!(pGlobTable->options[9] & 0x01) && (scrct->pFlag & D_SCRPT_NEW_LEX))
				opt |= D_GX_OPT_SET_LOCAL;
			else opt |= D_GX_OPT_SET_PRIVATE;
		}
		else opt |= D_GX_OPT_SET_PRIVATE;
	}
	attr = DEF_ZOK_BULK;
	if ((c=*varnam) == '$') {
		varnam++;
		vnlen--;
	}
	if ((rc=_chk_define(scrct,proc,varnam,vnlen,opt,argv)) < 0) return rc;
	pha_vname  = (XHASHB *)argv[4];
	pTBL_vname = (tdtINFO_PARM ***)argv[5];

	if ((iParmNo=cl_gx_chk_vnam_info('s',pha_vname,varnam,vnlen,&pInfoParm)) < 1) {
		/* %s: %s��%s�G���g���p�̋󂫂�����܂���B */
		ERROROUT3(FORMAT(323),argv[0],varnam,argv[3]);
		rc = ECL_SCRIPT_ERROR;
		goto Error;
	}
/*	pInfoParm = cl_get_var_ent(pTBL_vname,iParmNo);	*/
	if (!pInfoParm) return ECL_SCRIPT_ERROR;

	info_parm_clear(pInfoParm);
	if (type==D_AUX0_TYPE_STRUCT) {
		pInfoParm->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
		pInfoParm->pi_attr = attr;
		pInfoParm->pi_dlen = sizeof(tdtDefType);
		pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
		if (!(pDeftype=(tdtDefType *)Malloc(sizeof(tdtDefType)))) return ECL_MALLOC_ERROR;
		memset(pDeftype,0,sizeof(tdtDefType));
		pDeftype->size = pos;
		pDeftype->ntype = ntype;
		pInfoParm->pi_data = (char *)pDeftype;
		if (!(pDeftype->vname=(parmList **)Malloc(ntype*sizeof(parmList *)))) return ECL_MALLOC_ERROR;
		memcpy(pDeftype->vname,parmName,ntype*sizeof(parmList *));
		if (!(pDeftype->pType=(tdtINFO_PARM **)Malloc(ntype*sizeof(tdtINFO_PARM *)))) return ECL_MALLOC_ERROR;
		memcpy(pDeftype->pType,pTypeInfo,ntype*sizeof(tdtINFO_PARM *));
		if (!(p=Malloc(vnlen+1))) {
			ERROROUT1("%s: Type def name area malloc",argv[0]);
			rc = ECL_MALLOC_ERROR;
			goto Error;
		}
		strnzcpy(p,varnam,vnlen);
		pInfoParm->pi_pos = (long)p;
	}
	else {
		*pInfoParm = *pTypeInfo[0];
		pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
	}
	pInfoParm->pi_id     = 'P';
	pInfoParm->pi_aux[0] = type;
	pInfoParm->pi_len    = ++pGLprocTable->gid;
	i = akxs_xhasl(pGLprocTable->pha_gid,'S',pInfoParm->pi_len,0);
/*
printf("cl_pr_ex_def_type: Store gid=%ld ix=%d\n",pInfoParm->pi_len,i);
*/
#if 1	/* 2021.3.30 */
	pInfoParm->pi_hlen = _get_gid(scrct,proc,opt);
#else
	if (opt & D_GX_OPT_SET_LOCAL) pInfoParm->pi_hlen = proc->ProcGid;
	else if (opt & D_GX_OPT_SET_PRIVATE) pInfoParm->pi_hlen = scrct->ScrGid;
#endif

DEBUGOUT_InfoParm(194,"cl_pr_ex_def_type: attr=%d",pInfoParm,attr,0);

	rc =  0;

 Error:
	return rc;
}

/************************************/
/*	_def_var_array_member			*/
/************************************/
int _def_var_array_member(pParm)
tdtINFO_PARM *pParm;
{
	tdtArrayIndex *pIndex;
	int *index,attr,size,len,n,iParmW[4],rc,iRANGE;
	char *p,*p0;

DEBUGOUT_InfoParm(170,"_def_var_array_member:Enter:",pParm,0,0);

	if (!(pIndex = (tdtArrayIndex *)Malloc(sizeof(tdtArrayIndex)))) return -1;
	memcpy(pIndex,pParm->pi_data,sizeof(tdtArrayIndex));
	pParm->pi_data = (char *)pIndex;
#if 1	/* 2021.3.1 */
	if (p0=(char *)pParm->pi_pos) {
		if (!(p=Malloc((len=strlen(p0))+1))) {
			ERROROUT("_def_var_array_member: array name area malloc");
			return ECL_MALLOC_ERROR;
		}
		strnzcpy(p,p0,len);
		pParm->pi_pos = (long)p;
	}
#endif
	index = pIndex->index;
	if (index[2] < 0) {	/* HASH */
		if (!(pIndex->xhp = akxs_xhash_new2(0,index[4],0,pIndex->size))) return -9;
	}
	else {
		iParmW[0] = pIndex->uAttr[0];
		iParmW[1] = pIndex->size;
		iParmW[2] = 0;
		iRANGE = pParm->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		if ((size=cl_get_def_alsize(iParmW,iRANGE)) < 0) return size;
		n = index[1];
		if (rc=_def_array_set_init_by_attr(iParmW[0],n,size,pIndex,iParmW)) return rc;
	}
	pParm->pi_hlen = _get_gid(NULL,NULL,0);
	pParm->pi_paux = (char *)pParm;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
	return 0;
}

/************************************/
/*	_def_var_struct					*/
/*  �쐬 : 2020.10.12				*/
/************************************/
int _def_var_struct(pInfoParm,pDeftypeP,pDefname,opt)
tdtINFO_PARM *pInfoParm;
tdtDefType *pDeftypeP;
char *pDefname;
int opt;
{
	tdtINFO_PARM *pParm,*pInfoP,**pTypeD,**pTypeS;
	tdtDefType *pDeftype,*pDef;
	parmList  **parmName;
	int  j,rc,ntype,attr,size,type,iRANGE;
	char id,*p,*p1,*p0;
	uchar uAux0;

DEBUGOUT_InfoParm(170,"_def_var_struct:Enter: pDefname=[%s] opt=%08x",pInfoParm,nval(pDefname),opt);
DEBUGOUTL1(170,"_def_var_struct: pDeftypeP=%08x",pDeftypeP);
/*
printf("_def_var_struct:Enter: pDefname=[%s]\n",nval(pDefname));
*/
	pInfoParm->pi_id = 'T';
	pDeftype = (tdtDefType *)pInfoParm->pi_data;
	ntype = pDeftype->ntype;
	parmName = pDeftype->vname;
	pTypeS = pDeftypeP->pType;
	if (!(pDeftype->pType=(tdtINFO_PARM **)Malloc(ntype*sizeof(tdtINFO_PARM *)))) return -1;
/*	if (!(pTypeD=(tdtINFO_PARM **)Malloc(ntype*sizeof(tdtINFO_PARM *)))) return -1;*/
	rc = 0;
	for (j=0;j<ntype;j++) {
		if (!(pParm=(tdtINFO_PARM *)Malloc(sizeof(tdtINFO_PARM)))) return -1;
		pDeftype->pType[j] = pParm;
	/*	pInfoP = pDeftypeP->pType[j];	*/
		pInfoP = pTypeS[j];
DEBUGOUT_InfoParm(170,"_def_var_struct: pInfoP=",pInfoP,0,0);
#if 1	/* 2021.11.23 */
		uAux0 = pInfoP->pi_aux[0];
		if (rc=cl_gx_rep_info_set_ign(pParm,pInfoP,1)) return rc;
		pParm->pi_aux[0] = uAux0;
#else
		cl_gx_copy_info(pParm,pInfoP);
#endif
DEBUGOUT_InfoParm(170,"_def_var_struct: pParm=",pParm,0,0);
		if ((id=pParm->pi_id)=='A' || id=='R') {
			if (rc=_def_var_array_member(pParm)) return rc;
		}
		else if (id == 'P') {
			type = pParm->pi_aux[0];
			pDef = (tdtDefType *)pInfoP->pi_data;
			if (type == D_AUX0_TYPE_STRUCT) {
DEBUGOUTL1(170,"_def_var_struct: pDef=%08x",pDef);
				if (rc=_def_var_struct(pParm,pDef,(char *)pInfoP->pi_pos,opt)) return rc;
			}
			else {
				if (type == D_AUX0_TYPE_ARRAY) {
					pParm->pi_id = 'R';
					if (rc=_def_var_array_member(pParm)) return rc;
				}
				else pParm->pi_id = 'A';
			}
		}
		else if (attr=pParm->pi_aux[0]) {
			iRANGE = pInfoP->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
			if ((attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) ||
			    (attr==DEF_ZOK_FLOA && iRANGE)) {
		/*	if (attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) {	*/
				size = pParm->pi_len;
				if (attr == DEF_ZOK_CHAR) size++;
				else if (attr == DEF_ZOK_BULK)
					size += sizeof(int);
				if (iRANGE) size += size;
				if (p = Malloc(size)) {
					if (attr==DEF_ZOK_DECI || attr==DEF_ZOK_DATE)
						memcpy(p,pParm->pi_data,size);
					else strcpy(p,pParm->pi_data);
					pParm->pi_scale |= D_DATA_MALLOC;
				}
				else rc = -1;
				pParm->pi_data = p;
				pParm->pi_scale &= ~D_DATA_LPOSDATA;
			}
			pParm->pi_paux = pParm->pi_data;
			pParm->pi_aux[1] &= ~D_AUX1_PROTECTED;
			pParm->pi_alen |= iRANGE;
		}
	}
	rc = cl_set_struct_name(pInfoParm,pDefname);
	pInfoParm->pi_hlen = _get_gid(NULL,NULL,opt);
/*
printf("_def_var_struct: rc=%d\n",rc);
*/
	return rc;
}

/************************************/
/*	cl_set_struct_name_len			*/
/************************************/
int cl_get_struct_name_len(pDefname)
char *pDefname;
{
	int pos;

	if (pDefname) {
		if ((pos=instrchar(pDefname,':')) < 0) return pos;
		else if (pos > 0) {
			pos--;
		}
		else pos = strlen(pDefname);
	}
	else pos = -1;
/*
printf("cl_get_struct_name_len:Exit: pos=%d\n",pos);
*/
	return pos;
}

/************************************/
/*	cl_set_struct_name				*/
/************************************/
int cl_set_struct_name(pInfoParm,pDefname)
tdtINFO_PARM *pInfoParm;
char *pDefname;
{
	int pos;
	char *p,*p0,*p1;

	if ((pos=cl_get_struct_name_len(pDefname)) >= 0) {
		if (!(p=Malloc(strlen(p1=(char *)pInfoParm->pi_pos)+pos+2))) return ECL_MALLOC_ERROR;
		p0 = p;
		memzcpy(p,pDefname,pos);
		p += pos;
		*p++ = ':';
		strcpy(p,p1);
		pInfoParm->pi_pos = (long)p0;
/*
printf("cl_set_struct_name:Exit: name=[%s]\n",p0);
*/
		pos = 0;
	}
	return pos;
}

/************************************/
/*	_get_word_mult					*/
/************************************/
static int _get_word_mult(line,line_len,ssp,patr)
char *line;
int line_len,*patr;
SSPL_S *ssp;
{
	int len,atr,pos;
	char c,c1;

	if ((len=akxtgwnsl(line,line_len,ssp,gsep,0x41)) > 0) {
		atr = ssp->attr[0];
		c = *ssp->wd;
		if (atr > 10) {
			pos = instrchar("()[]([{}*/%+-<>&^|",c);
			if (pos > 0) {
				if (pos >= 9) {
					if ((c1=*(line+ssp->sp)) == '=') {
						atr = 90;
						len++;
						ssp->sp++;
					}
					else if (pos <= 13) {
						if (pos>=12 || pos<=15) {
							if (c1 == c) {
								atr = pos - 12 + 14;
								len++;
/*
printf("_get_word_mult: pos=%d atr=%d\n",pos,atr);
*/
								ssp->sp++;
								if (c=='>' && *(line+ssp->sp)=='>') {
									atr = 48;
									len++;
									ssp->sp++;
								}
								if ((c1=*(line+ssp->sp)) == '=') {
									atr = 90;
									len++;
									ssp->sp++;
								}
							}
							else atr = pos - 9 + 21;
						}
						else atr = pos - 9 + 21;
					}
					else atr = pos -13 + 41;
				}
				else atr = pos;
			}
			else if (c == '=') atr = 90;
			else if (c == ',') atr = 98;
			else if (c == ';') atr = 99;
			else atr = 11;
		}
		else if (atr == 1) {
			if (c>='0' && c<='9') atr = 5000;
			else atr = 10000;
		}
		else atr = 5000;
	}
	else atr = 0;
	*patr = atr;
	return len;
}

/* 2023.3.2 */
/************************************/
/*	_pr3_pr2_pr4					*/
/************************************/
static int _pr3_pr2_pr4(line,line_len,ssp,varnam,proc,opt,iParm,iParm2)
char *line,*varnam;
int line_len,opt,iParm[],iParm2[];
SSPL_S *ssp;
ProcCT *proc;
{
	static char *_fn_="_pr3_pr2_pr4";
	int *obj,iob,ida,type,is,pos_var_end,npr,ipr_pos,nvar,iob_ary,ida_nam,pos,n,i,rc;
	int iARRAY0,iARRAY,iCLEAR,iCONST;
	char **da,c;
	parmList *qprmp[MAX_ARRAY_DIM+1];

	iob  = iParm2[0];
	ida  = iParm2[1];
	is   = iParm2[2];
	type        = iParm[0];
	pos_var_end = iParm[7];
	npr         = iParm[8];
	ipr_pos     = iParm[9];
/*	nvar        = iParm[10];	*/
	iARRAY      = iParm[11];

#if 1	/* 20231203 */
		cl_im_expand(CLobjExp.ms_obj,iob+13,&obj);
		cl_im_expand(CLobjExp.ms_da,ida+2,&da);
#else
		cl_im_expand(CLcList.mcat_obj,iob+13,&obj);
		cl_im_expand(CLcList.mcat_da,ida+2,&da);
#endif

		/* �ϐ����̎擾 */
		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 3;	/* �����h�c���ϐ����擾�̏��� */
		ipr_pos = iob++;
		c = *varnam;
		obj[iob++] = ida;
		ida_nam = ida;
		da[ida++] = NULL;	/*clstrdup(varnam,0);*/
		/* �z�񖼂ɕϐ����w��\�Ƃ��� */
		obj[iob] = ida;	/*-1; 2020.10.28 */
		da[ida] = NULL;
		da[ida_nam] = clstrdup(varnam,0);
/*
printf("%s 2: type=%d ida_nam=%d varnam=[%s] ssp.sp=%d\n",_fn_,type,ida_nam,varnam,ssp->sp);
*/
	/*	nvar++;	*/
		ida++;
		iob++;

		pos = ssp->sp;
	/*	iARRAY = iARRAY0;	*/
		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 2;	/* �����h�c���z���`�擾�̏��� */
		ipr_pos = iob++;

		ssp->sp = is;
		if (!(opt & D_GX_OPT_REDEFINE) && proc && !iARRAY && !type) {
			clpeeksl(line,line_len,ssp,gsep,0x41);
			if (*ssp->wd == '[') iARRAY = -1;	/* �z��v�f�ƌ��Ȃ� */
		}
/*
printf("%s 2: iARRAY=%d is=%d\n",_fn_,iARRAY,is);
*/
		iob_ary = iob;
		obj[iob++] = iARRAY;	/* �z���`������ */
		n = 0;
		if (iARRAY >= 0) {
			/* �z���`�̎擾 */
			n = cl_get_array_def_parm(line,pos_var_end,",=",ssp,gsep,MAX_ARRAY_DIM,qprmp,NULL);
/*
printf("%s: n=%d\n",_fn_,n);
*/
			if (n < 0) return n;
			else if (n) {
#if 1	/* 2023.2.25 */
				if (opt & D_GX_OPT_SCALAR) {
							/* %s��`(%s)�͎w��ł��܂���B*/ /* �z�� */
					ERROROUT2(FORMAT(156),FORMAT(150),varnam);
					return ECL_EX_DEFINE;
				}
#endif
				iARRAY = 1;	/* �z���`���� */
			}
			else {
				if (iARRAY) {
					if (proc) iARRAY = 2;	/* define�ł͂Ȃ��āAarray������ */
				}
				else iARRAY = -1;	/* array���z���`���Ȃ�==>�ϐ��̒�`�܂��͎� */
			}
/*
printf("%s: n=%d iARRAY=%d\n",_fn_,n,iARRAY);
*/
			iCONST = opt & D_GX_OPT_SET_CONST;
			iCLEAR = opt & D_GX_OPT_SET_CLEAR;
			if (iARRAY==2 && (iCLEAR || iCONST || type)) iARRAY = 1;
			/* define�ł͂Ȃ��āAarray������Aclear��const���������w�肳��Ă��� */
			/* ARRAY=1: �z��ϐ��̒�` */
			/* ARRAY=2: �z��ϐ��ւ̃f�[�^�ݒ� */
/*
printf("%s: iARRAY=%d\n",_fn_,iARRAY);
*/
#if 0	/* 2021.8.28 */
			if (iARRAY==1 && (type & 0x10) && type!=D_AUX0_TYPE_STRUCT) {
						/* %s: �ϐ�[%s]�̔z���`���ł��Ȃ�����(%d)�ł��B */
				ERROROUT3(FORMAT(473),argv[0],varnam,type);
				return ECL_EX_DEFINE;
			}
#endif
			obj[iob++] = ida;	/* �z���` */
			obj[iob++] = n;
			iob_ary = iob;
		/*	if (iARRAY > 0) iARRAY |= iMAPPED;	*/
			obj[iob++] = iARRAY;

#if 1	/* 20231203 */
			cl_im_expand(CLobjExp.ms_da,ida+n,&da);
#else
			cl_im_expand(CLcList.mcat_da,ida+n,&da);
#endif

			for (i=0;i<n;i++) {
				cl_im_parmcpy(D_OPT_ALC_LEAF,&da[ida++],qprmp[i]);
			}
			memcpy(qprmp,&da[ida-n],sizeof(parmList *)*n);
			if (!n) ssp->sp = pos;
		}
		else {
			/* �z���`��ǂݔ�΂� */
			rc = cl_get_array_def_parm(line,pos_var_end,",=",ssp,gsep,0,NULL,NULL);
			if (rc < 0) return n;
		}
/*
printf("%s: n=%d iARRAY=%d\n",_fn_,n,iARRAY);
*/
DEBUGOUTL3(170,"%s: n=%d iARRAY=%d",_fn_,n,iARRAY);

		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 4;	/* �����h�c���ϐ���`/�Ē�`���� */
		ipr_pos = iob++;

	iParm2[0] = iob;
	iParm2[1] = ida;
	iParm[8]  = npr;
	iParm[9]  = ipr_pos;
/*	iParm[10] = nvar;	*/
	iParm[11] = iARRAY;
	iParm[12] = iob_ary;

	return 0;
}

/************************************/
/*	_pr5_pr6_pr7					*/
/************************************/
int cl_def_pr5_pr6_pr7(iParm,iParm2)
int iParm[],iParm2[];
{
	static char *_fn_="_pr5_pr6_pr7";
	int *obj,iob,ida,npr,ipr_pos,iEQU;
	char **da;

	iob     = iParm2[0];
	ida     = iParm2[1];
	iEQU    = iParm2[3];
	npr     = iParm[8];
	ipr_pos = iParm[9];

#if 1	/* 20231203 */
		cl_im_expand(CLobjExp.ms_obj,iob+4,&obj);
		cl_im_expand(CLobjExp.ms_da,ida+1,&da);
#else
		cl_im_expand(CLcList.mcat_obj,iob+4,&obj);
		cl_im_expand(CLcList.mcat_da,ida+1,&da);
#endif

		if (iEQU) {
			npr++;
			obj[ipr_pos] = iob;
			obj[iob++] = 5;	/* �����h�c��������� */
			ipr_pos = iob++;
		}
		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 6;	/* �����h�c��CONST���� */
		ipr_pos = iob++;

		npr++;
		obj[ipr_pos] = iob;
		obj[iob++] = 7;	/* �����h�c��pInfoParm��Ԃ����� */
		ipr_pos = iob++;
/*
printf("%s: iob=%d ida=%d da=%08x npr=%d\n",argv[0],iob,ida,da,npr);
*/
		obj[iob++] = ida++;

	iParm2[0] = iob;
	iParm2[1] = ida;
	iParm[8]  = npr;
	iParm[9]  = ipr_pos;

	return 0;
}

/************************************/
/*	_def_var_mult1					*/
/************************************/
static int _def_var_mult1(line,line_len,ssp,pvarnam,wrk,wrk_len,iParm,iParm2)
char *line,**pvarnam,*wrk;
int line_len,wrk_len,iParm[],iParm2[];
SSPL_S *ssp;
{
	static char *_fn_ = "_def_var_mult1";
	int rc,vnlen,is,pos_var_end,sp_save,type,len;
	int iCOM,iSKIP,iEQU;
	char c,*varnam;

	varnam = *pvarnam;
	is   = iParm2[2];
	iCOM = iParm2[5];
	pos_var_end = iParm[7];
	rc = 1;
	iEQU = 0;
	for (;;) {
		if ((vnlen=akxtgwnsl(line,pos_var_end,ssp,gsep,0x41)) <= 0) break;
		is = ssp->sp - vnlen;
		memnzcpy(wrk,ssp->wd,vnlen,wrk_len);
		varnam = wrk;
/*
printf("%s 0: is=%d ssp.sp=%d vnlen=%d varnam=[%s]\n",_fn_,is,ssp->sp,vnlen,varnam);
*/
DEBUGOUTL5(170,"%s 0: is=%d ssp.sp=%d vnlen=%d varnam=[%s]",_fn_,is,ssp->sp,vnlen,varnam);
DEBUGOUTL3(170,"%s 0: ssp.attr[0]=%d iCOM=%d",_fn_,ssp->attr[0],iCOM);

		iSKIP = 0;
		c = *varnam;
		if (instrchar("+-*/&|",c) > 0) {
			if (*(line+ssp->sp) == '=') break;
			iSKIP = 2;
		}
		else if (!stricmp(varnam,"AS") || c=='=') break;
		else if (c == ',') {
			if (iCOM) {
				ERROROUT1(FORMAT(458),_fn_);	/* %s: �ϐ����͏ȗ��ł��܂���B */
				return ECL_EX_DEFINE;
			}
			iCOM = 1;
			continue;
		}
#if 0	/* ���ꂪ�Ȃ��Ă� cl_get_array_def_parm()�̒��ŃG���[�Ȃ邪�A�O�̂��ߎc�� */
		/* 2021.5.24 ���ꂪ����ƁA�J���}�̌�̔z�񖼂��u�`������܂���v�̃G���[�ɂȂ�̂ŁA
		   �܂��A�����ł́Acl_chk_name()���ł��Ȃ�(�z�񖼂��ϐ��̂Ƃ�������)�̂ŁA�폜����B*/
		else if (!iCOM) {
			p = varnam;
			if (c=='$' || c=='%' || c=='#') {
				p++;
				vnlen--;
			}
			if (cl_chk_name(p, vnlen))
				ERROROUT2(FORMAT(125),_fn_,varnam);	/* %s: [%s]������Ă��܂��B*/
			else
				ERROROUT3(FORMAT(540),_fn_,FORMAT(474),varnam);	/* %s: %s������܂���B(at %s) �J���} */
			return ECL_EX_DEFINE;
		}
#endif
/*
printf("%s 1: pos=%d vnlen=%d varnam=[%s]\n",_fn_,pos,vnlen,varnam);
*/
DEBUGOUTL3(170,"%s 1: vnlen=%d varnam=[%s]",_fn_,vnlen,varnam);
		iCOM = 0;
		if (c == '(') iSKIP = 1;
	/*	else if (c == '\'') iSKIP = 3;	*/
		else if (!instrchar("()[] \t,",*(line+ssp->sp))) iSKIP = 2;
		else {
			clpeeksl(line,pos_var_end,ssp,gsep,0x41);
			if (*ssp->wd == '(') {
				len = akxnskipin(varnam,vnlen,"$%#");
				if (len >= vnlen) iSKIP = 1;
			}
		}
/*
printf("%s 2: iSKIP=%d\n",_fn_,iSKIP);
*/
		if (iSKIP) {
			if (iSKIP == 1) {
				ssp->sp = is;
				if (len=cl_skip_to_delm(line,pos_var_end,"()",ssp,gsep,0)) {
					ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
					return ECL_SCRIPT_ERROR;
				}
			}
			else { /*if (iSKIP == 2) {*/
				len = akxnskipto(line+ssp->sp,pos_var_end-ssp->sp," \t");
				ssp->sp += len;
			}
			memnzcpy(wrk,line+is,ssp->sp-is,wrk_len);
			varnam = wrk;
			vnlen = strlen(varnam);
/*
printf("%s SKIP: vnlen=%d varnam=[%s] ssp.sp=%d\n",_fn_,vnlen,varnam,ssp->sp);
*/
		}
		is = ssp->sp;
/*
printf("%s 3: is=%d\n",_fn_,is);
*/
		iParm[10]++;
		rc = 0;
		break;
	}
/*
printf("%s 2: is=%d vnlen=%d varnam=[%s]\n",_fn_,is,vnlen,varnam);
*/
	*pvarnam = varnam;
	iParm2[2] = is;
	iParm2[4] = sp_save;
	iParm2[5] = iCOM;
	iParm[7] = pos_var_end;
	return rc;
}

/************************************/
/*	_def_var_mult2					*/
/************************************/
static int _def_var_mult2(line,line_len,ssp,pvarnam,wrk,wrk_len,iParm,iParm2)
char *line,**pvarnam,*wrk;
int line_len,wrk_len,iParm[],iParm2[];
SSPL_S *ssp;
{
	static char *_fn_ = "_def_var_mult2";
	int vnlen,is,nvar,pos,pos_var_end,i_var,sp_save,type,atr,len;
	int iEQU,iEQU2,iSTA;
	char c,*varnam,*p;

	varnam = *pvarnam;
	is   = iParm2[2];
	iEQU = iParm2[3];
	pos_var_end = iParm[7];
	iSTA = 0;
	cl_chk_act(-1);
	for (;;) {
		vnlen = _get_word_mult(line,line_len,ssp,&atr);
/*
printf("%s 0: vnlen=%d atr=%d\n",_fn_,vnlen,atr);
*/
		if (atr < 0) return atr;
		if (!iSTA) iSTA = ssp->sp - vnlen;
		c = *ssp->wd;
/*
printf("%s 0: is=%d ssp.sp=%d iCOM=%d vnlen=%d wd=[%s]\n",_fn_,is,ssp->sp,iCOM,vnlen,ssp.wd);
*/
DEBUGOUTL5(170,"%s 0: is=%d ssp.sp=%d vnlen=%d varnam=[%s]",_fn_,is,ssp->sp,vnlen,varnam);
DEBUGOUTL2(170,"%s 0: ssp.attr[0]=%d",_fn_,ssp->attr[0]);

		if (!varnam && atr==1) {
			i_var = ssp->sp;
			if (len=cl_skip_to_delm(line,line_len,"()",ssp,gsep,1)) {
				ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
				return ECL_SCRIPT_ERROR;
			}
			memnzcpy(wrk,line+i_var,ssp->sp-i_var-1,wrk_len);
			varnam = wrk;
			if (!is) is = ssp->sp;
/*
printf("%s 0: is=%d vnlen=%d varnam=[%s]\n",_fn_,is,vnlen,varnam);
*/
			continue;
		}
		if (atr <= 10) {
			if (cl_chk_act(c) < 0) {
				ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
				return ECL_SCRIPT_ERROR;
			}
		}
		if (cl_chk_act(0)) continue;
		if (!varnam && atr!=62 && atr!=14 && atr!=15) {
/*
printf("%s 0: atr=%d\n",_fn_,atr);
*/
			if (atr<2000 || atr==5000) {
				memnzcpy(wrk,ssp->wd,vnlen,wrk_len);
				if (atr>=14 && atr<=48)
					ERROROUT2(FORMAT(318),_fn_,wrk);	/* %s: %s�͎g�p�ł��܂���B */
				else ERROROUT1(FORMAT(458),_fn_);	/* %s: �ϐ����͏ȗ��ł��܂���B */
				return ECL_EX_DEFINE;
			}
		}
		if (atr!=62 && atr<100) {
			if (!atr || atr==99 || atr == 98) {
				if (iEQU) pos_var_end = iEQU2;
				else pos_var_end = ssp->sp - 1;
/*
printf("%s 0: pos_var_end=%d\n",_fn_,pos_var_end);
*/
				sp_save = ssp->sp;
			}
			else {
				if (atr>=71 && atr<=90) {
					iEQU = ssp->sp;
					iEQU2 = iEQU - vnlen;
/*
printf("%s 0: iEQU=%d iEQU2=%d\n",_fn_,iEQU,iEQU2);
*/
				}
				continue;
			}
		}
		else {
			if (!varnam) {
				p = ssp->wd;
				memnzcpy(wrk,p,vnlen,wrk_len);
				len = akxnskipin(wrk,vnlen,"$%#");
				if (len >= vnlen) {
					atr = cmppeekwnsl(line,line_len,ssp,0);
					if (atr == 1) {
						i_var = ssp->sp - 1;
						if (len=cl_skip_to_delm(line,line_len,"()",ssp,gsep,0)) {
							ERROROUT1(FORMAT(433),_fn_);	/* %s: �J�b�R�����Ă��܂���B */
							return ECL_SCRIPT_ERROR;
						}
						p = line+i_var;
						vnlen = ssp->sp-i_var;
					}
				}
#if 1	/* 2023.3.26 */
				vnlen = ssp->sp - iSTA;
				memnzcpy(wrk,line+iSTA,vnlen,wrk_len);
#else
				memnzcpy(wrk,p,vnlen,wrk_len);
#endif
				varnam = wrk;
				if (atr==2000 || (atr>=4000 && atr<10000)) {
					ERROROUT2(FORMAT(436),_fn_,varnam);	/* %s: �ϐ���[%s]������Ă��܂��B*/
					return ECL_EX_DEFINE;
				}
				if (!is) is = ssp->sp;
/*
printf("%s 1: is=%d vnlen=%d varnam=[%s]\n",_fn_,is,vnlen,varnam);
*/
			}
			continue;
		}
/*
printf("%s 1: is=%d ssp.sp=%d vnlen=%d varnam=[%s]\n",_fn_,is,ssp.sp,vnlen,varnam);
*/
/*
printf("%s 1: pos=%d vnlen=%d varnam=[%s]\n",_fn_,pos,vnlen,varnam);
*/
DEBUGOUTL3(170,"%s 1: vnlen=%d varnam=[%s]",_fn_,vnlen,varnam);

		break;
	}
	*pvarnam = varnam;
	iParm2[2] = is;
	iParm2[3] = iEQU;
	iParm2[4] = sp_save;	/* , or ; �̈ʒu */
	iParm[7] = pos_var_end;
	if (varnam) iParm[10]++;
	return atr;
}

/************************************/
/*	cl_def_var_mult					*/
/************************************/
int cl_def_var_mult(cmdobj,prmnum,pprmp,scrct,proc,opt,iParm)
CMDObject *cmdobj;
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt,iParm[];
{
	static char *_fn_ = "cl_def_var_mult";
	int rc,vnlen,is,nvar,pos,pos_var_end,i_var,line_len,sp_save,type,atr,len,len_vals;
	int *obj,npr,iob,ida,ipr_pos,iob_ary,iParm2[10];
	int iARRAY,iEQU,iCONST,iARRAY0,iMAPPED,iSCALAR,iEQU2,iEQU0;
	int iCOM,iSKIP,iSTA,iMALTI2,iDEFPROC,iEX_DEF_SCALAR;
	char c,*varnam,*p,*argv[6],*line,wrk[256],**da;
	tdtINFO_PARM *pInfoDef;
	tdtDefType *pDeftypeP;
	SSPL_S ssp;
/*
printf("%s: Enter opt=%08x iParm=%d %d %08x %08x %08x %08x\n",
_fn_,opt,iParm[0],iParm[1],iParm[2],iParm[3],iParm[4],iParm[5]);
*/
	type = iParm[0];
	pDeftypeP = NULL;
#if defined(_LP64)	/* 2021.2.13 */
	memcpy(&p,iParm+2,sizeof(char *));
	if (!type && p) {
		if (pInfoDef = (tdtINFO_PARM *)p) {
#else
	if (!type && iParm[2]) {
		if (pInfoDef = (tdtINFO_PARM *)iParm[2]) {
#endif
			pDeftypeP = (tdtDefType *)pInfoDef->pi_data;
			type = pInfoDef->pi_aux[0];
		}
	}

	line = pprmp[0]->prp;
	line_len = pprmp[0]->prmlen;
	memset(&ssp,0,sizeof(SSPL_S));

	iob = cmdobj->nobj;
	ida = cmdobj->nda;
	obj = cmdobj->exobj;
	da  = cmdobj->da;
	pos         = iParm[6];
	pos_var_end = iParm[7];
	npr         = iParm[8];
	ipr_pos     = iParm[9];
/*
printf("%s: pos=%d pos_var_end=%d npr=%d ipr_pos=%d iob=%d ida=%d\n",
_fn_,pos,pos_var_end,npr,ipr_pos,iob,ida);
*/
	ssp.sp = pos;
	obj[iob++] = pos;
	iMAPPED = iARRAY = iCONST = iSCALAR = iEQU = iEQU2 = iEX_DEF_SCALAR = 0;
	iSKIP = 0;
	if (opt & D_GX_OPT_SET_ARRAY) iARRAY = 1;
	if (opt & D_GX_OPT_SET_MAPPED) {
		iARRAY = iMAPPED = 1;
	}
	if (opt & D_GX_OPT_SET_CONST) iCONST = D_AUX1_PROTECTED;
#if 1	/* 2023.2.25 */
	if (opt & D_GX_OPT_SCALAR) iSCALAR = 1;
#endif
/*
printf("%s: iARRAY=%d iMAPPED=%d iCONST=%d iSCALAR=%d\n",_fn_,iARRAY,iMAPPED,iCONST,iSCALAR);
*/
	iARRAY0 = iARRAY;
	cl_chk_act(-1);
	is = 0;
	nvar = 0;
	iCOM = 1;
	varnam = NULL;
	iParm[10] = nvar;
	iParm[16] = 0;
	sp_save = line_len;
/*
printf("cl_def_var_mult: cmdobj->cid=%08x\n",cmdobj->cid);
*/
	iMALTI2 = cmdobj->cid & C_USE_MALTI2;
	iMALTI2 = iMALTI2 && !(cl_get_option(24,0) & 0x10);
	iDEFPROC = cmdobj->cid & C_DEFINE_PROC;	/* scalar�ł͏������Ȃ� */
/*
printf("%s: iMALTI2=%08x iDEFPROC=%08x iParm[17]=%08x\n",_fn_,iMALTI2,iDEFPROC,iParm[17]);
*/
	if (!iMALTI2) iEQU = iParm[18];
	iEQU0 = iEQU;

	for (;;) {
		len_vals = 0;
		if (iMALTI2) {
			iParm2[2] = is;
			iParm2[3] = iEQU;
			iParm[7] = pos_var_end;
			iSTA = ssp.sp;
			if ((atr=_def_var_mult2(line,line_len,&ssp,&varnam,wrk,sizeof(wrk),iParm,iParm2)) < 0) return atr;
			is      = iParm2[2];
			iEQU    = iParm2[3];
			sp_save = iParm2[4];
			pos_var_end = iParm[7];
			if (iEQU) len_vals = ssp.sp - iEQU - 1;	/* �����l���̒��� */
		}
		else {
			iParm2[2] = is;
			iParm2[5] = iCOM;
			iParm[7] = pos_var_end;
			if ((rc=_def_var_mult1(line,line_len,&ssp,&varnam,wrk,sizeof(wrk),iParm,iParm2)) < 0) return rc;
			is      = iParm2[2];
			sp_save = iParm2[4];
			iCOM    = iParm2[5];
			pos_var_end = iParm[7];
/*
printf("%s: rc=%d is=%d ssp.sp=%d varnam=[%s]\n",_fn_,rc,is,ssp.sp,varnam);
*/
			if (rc == 1) break;
			if (iEQU) len_vals = line_len - iEQU;	/* �����l���̒��� */
		}
		/* �����l���̐ݒ� */
		if (iEQU) {
#if 1	/* 20231203 */
			cl_im_expand(CLobjExp.ms_obj,iob+3,&obj);
#else
			cl_im_expand(CLcList.mcat_obj,iob+3,&obj);
#endif
			npr++;
			obj[ipr_pos] = iob;
			obj[iob++] = 8;	/* �����h�c�������l���̏��� */
			ipr_pos = iob++;
			obj[iob++] = iEQU;
			obj[iob++] = len_vals;
			iParm[16] = 1;
		}
		/* 2023.3.2 */
		iParm2[0] = iob;
		iParm2[1] = ida;
		iParm2[2] = is;
		iParm[7] = pos_var_end;
		iParm[8] = npr;
		iParm[9] = ipr_pos;
		iParm[11] = iARRAY0;
		if ((rc=_pr3_pr2_pr4(line,line_len,&ssp,varnam,proc,opt,iParm,iParm2)) < 0) return rc;
		iob = iParm2[0];
		ida = iParm2[1];
		npr = iParm[8];
		ipr_pos = iParm[9];
/*
printf("%s: npr=%d\n",_fn_,npr);
*/
		iParm[13] = iParm[8];	/*npr;*/
		iParm[14] = iParm2[0];	/*iob;*/
		iParm[15] = iParm[9];	/*ipr_pos;*/
		if (iMALTI2) {
			/* 2023.3.2 */
			iParm2[3] = iEQU;
			cl_def_pr5_pr6_pr7(iParm,iParm2);
			iob = iParm2[0];
			ida = iParm2[1];
			npr = iParm[8];
			ipr_pos = iParm[9];
/*
printf("%s: sp=%d\n",_fn_,ssp.sp);
*/
			if (!atr || atr==99) break;
			iEQU = is = 0;
			varnam = NULL;
			ssp.sp = sp_save;
		}
		else {
			iob = iParm2[0];
			ida = iParm2[1];
			npr = iParm[8];
			ipr_pos = iParm[9];
			iEQU = 0;
		}
	}
	nvar = iParm[10];
/*
printf("%s: nvar=%d iARRAY=%d\n",_fn_,nvar,iParm[11]);
*/
	if (!nvar) {
		ERROROUT2(FORMAT(111),_fn_,FORMAT(329));	/* %s: %s�����K�v�ł��B*/ /* �ϐ� */
		return ECL_EX_DEFINE;
	}
#if 0
/*
printf("%s: iMALTI2=%d iDEFPROC=%08x nvar=%d iARRAY=%d attr|type=%d\n",
_fn_,iMALTI2,iDEFPROC,iParm[10],iParm[11],iParm[17]);
*/
	if (proc && !iDEFPROC && iParm[10]==1 && iParm[11]<0 && !iParm[17]) {
		iEX_DEF_SCALAR = 1;	/* _pr_ex_def_scalar()�ŏ�������� */
	}
#endif
#if 1	/* 2023.3.29 */
	if (!iMALTI2 && !iEX_DEF_SCALAR) {
		iParm2[3] = iEQU0;
		cl_def_pr5_pr6_pr7(iParm,iParm2);
		iob = iParm2[0];
		ida = iParm2[1];
		npr = iParm[8];
		ipr_pos = iParm[9];
	}
#endif
#if 1	/* 20231203 */
	cl_im_expand(CLobjExp.ms_obj,0,&obj);
	cl_im_expand(CLobjExp.ms_da,0,&da);
#else
#if 1	/* 2023.3.2 */
	cl_im_expand(CLcList.mcat_obj,0,&obj);
	cl_im_expand(CLcList.mcat_da,0,&da);
#endif
#endif
/*
printf("%s: npr=%d ipr_pos=%d iob=%d ida=%d obj=%08x da=%08x\n",_fn_,npr,ipr_pos,iob,ida,obj,da);
*/

	cmdobj->nobj  = iob;
	cmdobj->nda   = ida;
	cmdobj->exobj = obj;
	cmdobj->da    = da;
	iParm[8] = npr;
	iParm[9] = ipr_pos;
	return 0;
}

/************************************/
/*	cl_get_def_type					*/
/*  sp_save : �f�[�^�^���J�n�ʒu	*/
/*  �G���[�܂��̓f�[�^�^�łȂ��Ƃ��́Assp.sp=sp_save */
/************************************/
int cl_get_def_type(line,line_len,ssp,sp_save,proc,pbxobj,iERROROUT,iParm,pInfoParm)
char *line;
int line_len,sp_save,iERROROUT,iParm[];
SSPL_S *ssp;
ProcCT   *proc;
GXObject **pbxobj;
tdtINFO_PARM *pInfoParm;
{
	static char *_fn_="cl_get_def_type";
	int type,len,vnlen,rc,opt;
	char c,*varnam,*pp,cc;
	parmList qprmp;
	tdtINFO_PARM tInfoParmW,*pInfoParmW;

DEBUGOUTL4(170,"cl_get_def_type:Enter: sp_save=%d iERROROUT=%d line_len=%d line=[%s]",sp_save,iERROROUT,line_len,line);
/*
printf("cl_get_def_type:Enter: sp_save=%d line_len=%d line=[%s]\n",sp_save,line_len,line+sp_save);
*/
	rc = type = 0;
	ssp->sp = sp_save;
	if ((vnlen=akxtgwnsl(line,line_len,ssp,gsep,0x841)) <= 0) {
		if (iERROROUT) {
			ERROROUT1(FORMAT(457),_fn_);	/* %s: �^�w�肪����܂���B */
			rc = ECL_EX_DEFINE;
		}
		goto NotType;
	}
#if 1	/* 2022.12.07 */
	if (ssp->attr[0] > 100) goto NotType;
#endif
	varnam = clmemdup(ssp->wd,vnlen,3);
	/* �^��`���ɕϐ����w��\�Ƃ��� */
	c = *varnam;
	if (c=='(' || c=='$') {
		ssp->sp = sp_save;
		if ((len=_get_varname(line,line_len,ssp,proc,pbxobj,&pp)) < 0) {
			rc = len;
			goto NotType;
		}
		else if (len > 0) {
			varnam = pp;
			vnlen = len;
		}
	}
	if (iERROROUT) {
		if (rc=cl_def_chk_name(varnam,vnlen,_fn_,FORMAT(466))) goto NotType;	/* �^��`�� */
	}
	qprmp.prp = varnam;
	qprmp.prmlen = vnlen;

	if (iERROROUT) opt = 0;
	else opt = D_GX_OPT_NOERROR_NDEF | D_GX_OPT_NOEROUT_NDEF | D_GX_OPT_NOHOLD_NDEF;

#if 1	/* 2021.2.6 */
	rc = cl_conv_parm_opt(&qprmp,pInfoParm,opt|D_GX_OPT_SET_ADDR);
	if (pInfoParm->pi_id == 'S') pInfoParmW = (tdtINFO_PARM *)pInfoParm->pi_pos;
	else pInfoParmW = pInfoParm;
#else
	pInfoParmW = &tInfoParmW;
	rc = cl_conv_parm_opt(&qprmp,pInfoParmW,opt|D_GX_OPT_SET_ADDR);
	if (pInfoParmW->pi_id == 'S') pInfoParmW = (tdtINFO_PARM *)pInfoParmW->pi_pos;
	cl_gx_copy_info(pInfoParm,pInfoParmW);
#endif
	if (!rc || rc==ECL_DEFINED_ARRAY) {
		if (pInfoParmW->pi_id == 'P') {
			type = pInfoParmW->pi_aux[0];
			if (pInfoParm->pi_id != 'S') {	/* ���̃P�[�X�́A�L���Ȃ����O�̂��� */
				if (!(pInfoParmW = (tdtINFO_PARM *)cl_opt_malloc(0,sizeof(tdtINFO_PARM)))) return ECL_MALLOC_ERROR;
				cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1);
			}
			pp = Memdup(line+sp_save,ssp->sp-sp_save);
/*
printf("%s: sp_save=%d ssp.sp=%d pp=[%s]\n",_fn_,sp_save,ssp->sp,pp);
*/
#if defined(_LP64)	/* 2021.2.13 */
			memcpy(iParm+2,&pInfoParmW,sizeof(char *));
			memcpy(iParm+4,&pp,sizeof(char *));
#else
			iParm[2] = (int)pInfoParmW;
			iParm[4] = (int)pp;
#endif
		}
		else {
			if (iERROROUT) {
				/* %s: �^�w�肪����Ă��܂��Btype=[%s] */
				ERROROUT2(FORMAT(468),_fn_,varnam);
				rc = ECL_EX_DEFINE;
			}
			goto NotType;
		}
	}
	else {
		if (iERROROUT) {
			if ((rc==ECL_NDEFVAR_ERROR || rc==ECL_NO_DATA_ERROR) && (opt & D_GX_OPT_NOERROR_NDEF)) rc = 0;
		}
		else rc = 0;
		goto NotType;
	}
/*
printf("%s: type=%d\n",_fn_,type);
*/
	return type;
NotType:
	ssp->sp = sp_save;
	return rc;
}

/************************************/
/*	cl_pr_ex_def_var				*/
/************************************/
int cl_pr_ex_def_var(cmdobj, prmnum, pprmp, scrct, proc, opt)
CMDObject *cmdobj;
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	XHASHB *pha_vname;
	tdtINFO_PARM ***pTBL_vname;
	int i,j,k,iParmNo,rc,vnlen,is,ias,ntype,datalen,iCONST,nvar,posa[4],kind;
	int iParm[20],check[4],*obj,npr,iob,exec_flg,ipr,ida,ipr_pos,ida_nam,iob_ary,iParm2[5];
	int iEQU,line_len,sp_save,pos,iCOM,type,vlen,iARRAY,n,pos_var_end;
	char c,*varnam,*p,id,*argv[6],*line,wrk[128],*pp,*vnam,**da;
	tdtINFO_PARM *pInfoParm,tInfoParm,*pParm,*pParmIO[2];
	tdtDefType *pDeftype,*pDeftypeP;
	parmList  **parmName;
	tdtArrayIndex *pIndex;
	int *index,attr,size,len;
	SSPL_S ssp;
	parmList qprmp,*pPrmp;
	parmList *qprmp3[4];
	tdtObjHead *pObj;
	GXObject *bxobj[2];
	uchar ucLOCAL;

	argv[0] = "cl_pr_ex_def_var";

DEBUGOUTL5(101,"%s:Enter prmnum=%d scrct=%08x proc=%08x opt=%08x",argv[0],prmnum,scrct,proc,opt);

	/* parameter check */
	/* DEFINE VAR [GLOBAL|PUBLIC|PRIVATE|LOCAL] var_name AS type; */
	if (prmnum < 1) {
		/* %s: �p�����[�^������܂���Bprmnum=%d */
		ERROROUT2(FORMAT(467),argv[0],prmnum);
		return ECL_EX_DEFINE;
	}

	bxobj[0] = bxobj[1] = NULL;
	pha_vname = NULL;
	iCONST = iEQU = 0;
	line = pprmp[0]->prp;
	line_len = pprmp[0]->prmlen;
/*
printf("%s: prmnum=%d line_len=%d line=[%s]\n",argv[0],prmnum,line_len,line);
*/
DEBUGOUTL3(120,"%s: line_len=%d line=[%s]",argv[0],line_len,line);

	if (proc) pObj = proc->Obj;
	else pObj = scrct->Obj;
/*
printf("%s: proc=%08x scrct=%08x pObj=%08x\n",argv[0],proc,scrct,pObj);
*/
	memset(&ssp,0,sizeof(SSPL_S));

	if (cmdobj->nobj) goto Exobj;	/* 2020.12.4 �b��Ή� */

#if 1	/* 20231203 */
	if (!(obj=cmdobj->exobj)) cl_im_expand(CLobjExp.ms_obj,50,&obj);
	if (!(da=cmdobj->da)) cl_im_expand(CLobjExp.ms_da,10,&da);
#else
	if (!(obj=cmdobj->exobj)) cl_im_expand(CLcList.mcat_obj,50,&obj);
	if (!(da=cmdobj->da)) cl_im_expand(CLcList.mcat_da,10,&da);
#endif
	npr = ida = 0;
	obj[0] = 0;	/* sub_id */
	obj[1] = 0;	/* npr */
	obj[2] = 3;	/* ipr_pos */
	iob = obj[2];

	/* �A�N�Z�X�����̎擾 */
	exec_flg = 1;
	npr++;
	obj[iob++] = 1;	/* �����h�c�������̎擾 */
	ipr_pos = iob++;
	obj[iob++] = ida;	/* �����w�莮���� */
	da[ida] = NULL;
	check[1] = 0x03;	/* only const,scope */
	if ((rc=cl_get_def_modifier_SSP(line,line_len,&ssp,gsep,check,iParm,NULL,NULL)) < 0) return rc;
	else if (rc > 0) {
		if (check[2] & 0x01) opt &= ~D_GX_OPT_SET_SCOPE;
		opt |= check[3];
		if (!proc && (opt & D_GX_OPT_SET_LOCAL)) {
			ERROROUT1(FORMAT(443),argv[0]);	/* %s: LOCAL�͎w��ł��܂���B */
			return ECL_SCRIPT_ERROR;
		}
		if (opt & D_GX_OPT_SET_CONST) iCONST = D_AUX1_PROTECTED;
		if (iParm[0] > 0) {
			/* %s: \"%s\"�̈ʒu���s���ł��B */
			ERROROUT2(FORMAT(469),argv[0],cl_get_attr_name(iParm));
			return ECL_SCRIPT_ERROR;
		}
	}
/*
printf("%s: ssp.sp=%d\n",argv[0],ssp.sp);
*/
	/* ������̃T�[�` */
	pos = ssp.sp;
	if ((len=_define_srch_equ(line,line_len,&ssp,posa)) < 0) return len;
	iEQU = posa[0];
	pos_var_end = posa[1];
	kind = posa[2];
	if (len < 0) {
		if (kind &  8)
			ERROROUT3(FORMAT(657),argv[0],"=",iEQU+4);/* %s: \"%s\"�̈ʒu(pos=%d)���s���ł��B*/
		else if (kind & 16)
			ERROROUT2(FORMAT(567),argv[0],"AS");	/* %s: �]���ȕ���(%s)������܂��B*/
		else
			ERROROUT1(FORMAT(171),argv[0]);			/* %s: SYNTAX�G���[�B */
		return ECL_EX_DEFINE;
	}
	iARRAY = 0;
	if (kind & 4) {	/* AS */
		/* �f�[�^�^�܂��͌^��`���̎擾 */
		sp_save = ssp.sp;
		if (rc=cl_get_def_attr_SSP(line,line_len,&ssp,gsep,iParm,&da[ida],pObj)) return rc;
		type = 0;
		cl_parm_set0(&tInfoParm);
		if (!iParm[0]) {
			if ((type=cl_get_def_type(line,line_len,&ssp,sp_save,proc,&pprmp[0]->bxobj,1,iParm,&tInfoParm)) < 0) return type;
			else if (!type) {
				ERROROUT2(FORMAT(125),argv[0],FORMAT(588));	/* %s: [%s]������Ă��܂��B*//* �f�[�^�^�w�� */
				return ECL_EX_DEFINE;
			}
		}
	}
	else {
		iParm[0] = 0;	/*DEF_ZOK_VARI; 2023.9.6 for implicit */
		type = 0;
		if (!len) ssp.sp--;
	}
	if (!(opt & D_GX_OPT_SET_SCOPE)) {
		if (proc) {
			if (!(pGlobTable->options[9] & 0x01) && (scrct->pFlag & D_SCRPT_NEW_LEX))
				opt |= D_GX_OPT_SET_LOCAL;
			else opt |= D_GX_OPT_SET_PRIVATE;
		}
		else opt |= D_GX_OPT_SET_PRIVATE;
	}

	ida++;
	memcpy(&obj[iob],iParm,sizeof(int)*6);
	iob += 6;
	obj[iob++] = opt;
	obj[iob++] = iEQU;	/* add 2020.11.3 */
	obj[iob++] = iCONST;

	if ((len=akxtgwnsl(line,line_len,&ssp,gsep,0x41)) < 0) return len;
	else if (*ssp.wd == '=') iEQU = ssp.sp;

	/* �ϐ��̒�` */
	iParm[6] = pos;
	iParm[7] = pos_var_end;
	iParm[8] = npr;
	iParm[9] = ipr_pos;
	iParm[17] = iParm[0] | type;
/*
printf("%s: iEQU=%d\n",argv[0],iEQU);
*/
	iParm[18] = iEQU;
	cmdobj->nobj  = iob;
	cmdobj->nda   = ida;
	cmdobj->exobj = obj;
	cmdobj->da    = da;
	rc = cl_def_var_mult(cmdobj,prmnum,pprmp,scrct,proc,opt,iParm);
	if (rc < 0) return rc;
	npr     = iParm[8];
	ipr_pos = iParm[9];
	iob = cmdobj->nobj;
	ida = cmdobj->nda;
	obj = cmdobj->exobj;
	da  = cmdobj->da;
	obj[1] = npr;

if (DEBUGOUTCHECK(250)) {
for (i=0;i<iob;i++)
DEBUGOUTL2(250,"ARRY: obj[%d]=%d",i,obj[i]);
for (i=0;i<ida;i++)
DEBUGOUTL3(250,"ARRY: da[%d]=0x%08x[%s]",i,da[i],da[i]);
}
	cmdobj->nobj  = iob;
	cmdobj->nda   = ida;
	cmdobj->exobj = (int *)clmemdup(obj,iob*sizeof(int),0);
	cmdobj->da    = (char **)clmemdup(da,ida*sizeof(char *),0);

	if (iEQU && (kind & 2)) {
		memzcpy(wrk,line+posa[3],iEQU-posa[3]);
				/* %s:(W)���Z�q[%s]�́A�w��ł��܂���B'='�ƌ��Ȃ��܂��B */
		ERROROUT2(FORMAT(608),argv[0],wrk);
	}

Exobj:

	rc = cl_pr_ex_def_array_engine(cmdobj,prmnum,pprmp,scrct,proc,opt);
/*
printf("%s: return cl_pr_ex_def_array_engine() rc=%d\n",argv[0],rc);
*/
	if (rc == C_EX_DEF_SCALAR) rc = 0;

DEBUGOUTL2(102,"%s:Exit rc=%d",argv[0],rc);

	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_deftype(id,pDeftype)
char id;
tdtDefType *pDeftype;
{
	int i,ntype;
	parmList *pL,**pparmL;
	tdtINFO_PARM **ppParm,*pInfoParm;

	ntype = pDeftype->ntype;
	if (id == 'P') {
		pparmL = pDeftype->vname;
		for (i=0;i<ntype;i++) {
			pL = *pparmL++;
			Free(pL->prp);
			Free(pL);
		}
		Free(pDeftype->vname);
	}
	ppParm = pDeftype->pType;
	for (i=0;i<ntype;i++) {
		cl_free_info_parm(pInfoParm=*ppParm);
		Free(pInfoParm);
		ppParm++;
	}
	Free(pDeftype->pType);
	return 0;
}

/****************************/
/* _chk_kakko				*/
/****************************/
static int _chk_kakko(stack,j)
SSPL_S *stack;
int j;
{
	int rc;
	long i,jj;
/*
printf("_chk_kakko:Enter: j=%d\n",j);
*/
	if (j<1 || j>6) return -12;
/*
printf("_chk_kakko:Enter: max=%d sp=%d\n",stack->wdmax,stack->sp);
*/
	rc = 0;
	if (j <= 3) {
		jj = j;
		rc = akxs_stack_push(stack,(char *)jj);
	}
	else {
		rc = akxs_stack_peek(stack,(char **)&i);
/*
printf("_chk_kakko:peek i=%d\n",i);
*/
		if (i<1 || i>3) rc = -13;
		else if (i == j-3) rc = akxs_stack_pop(stack,(char **)&i);
		else rc = -11;
	}
	if (rc > 0) rc = 0;
/*
printf("_chk_kakko:Exit: rc=%d\n",rc);
*/
	return rc;
}

/********************************************/
/*		posa[0] : '=','+='����'='�̈ʒu		*/
/*		posa[1] : �ϐ���������Ō�̈ʒu	*/
/*		posa[2] : �Ō�ɓǂ񂾂���			*/
/*					1 : '='					*/
/*					2 : '+='��				*/
/*					4 : AS					*/
/*					8 : AS �̑O��'=','+='������	*/
/*				   16 : AS ��2����		*/
/*		posa[3] : '+='���̊J�n�ʒu			*/
/*  �ԋp : �Ō�ɓǂ�word��(�o�C�g)		*/
/********************************************/
int _define_srch_equ(line,line_len,ssp,posa)
char *line;
int line_len,posa[];
SSPL_S *ssp;
{
	static char *_fn_="_define_srch_equ";
	SSPL_S stack,sspl;
	long w[50],j;
	int len,rc,iEQU,pos_var_end,kind,atr0,sp,pos_enzan;
	char c,c2,wrk[128],buf[256];
/*
printf("%s:Enter ssp->sp=%d line_len=%d line=[%s]\n",_fn_,ssp->sp,line_len,line);
*/
	stack.wd = (char *)w;
	akxs_stack_init(&stack,50);
	rc = iEQU = kind = pos_enzan = 0;
	pos_var_end = line_len;
	posa[0] = iEQU;
	posa[1] = pos_var_end;
	posa[2] = 0;
	while ((len=akxtgwnsl(line,line_len,ssp,gsep,0x41)) > 0) {
/*
printf("%s: sp=%d len=%d wd=[%s]\n",_fn_,ssp->sp,len,strtemp(ssp->wd,len));
*/
		if (len == 1) {
			c = *ssp->wd;
			if (j=instrchar("({[)}]",c)) {
				if ((rc=_chk_kakko(&stack,j)) < 0) return rc;
				continue;	/* add 2022.10.1 */
			}
			else if (!stack.sp && c=='=') {
				if (!iEQU) {
					iEQU = ssp->sp;
					pos_enzan = iEQU - 1;
					if (!kind) pos_var_end = iEQU - 1;
					kind |= 1;
				}
				if (kind & 4) break;
			/*	break;	*/
			}
		}
		if (!stack.sp) {
			if ((c2=*(line+ssp->sp))=='=') {
				if (!iEQU) {
					sspl.sp = 0;
					sspl.wd = wrk;
					sspl.wdmax = sizeof(wrk);
					memcpy(buf,ssp->wd,len);
					memcpy(buf+len,"=",2);
					atr0 = cmpgwnsl(buf,len+1,&sspl,0);
/*
printf("%s: atr0=%d buf=[%s]\n",_fn_,atr0,buf);
*/
					if (atr0>=71 && atr0<=90) {
						iEQU = ssp->sp + 1;
						pos_enzan = ssp->sp - len;
						if (!kind) pos_var_end = ssp->sp - len;
						kind |= 2;
						if (kind & 4) break;
					/*	break;	*/
					}
				}
			}
			else if (!stricmp(strtemp(ssp->wd,len),"AS")) {
				if (kind & (3+4)) {
					if (kind & 4) kind |= 16;
					else kind |= 8;
					posa[0] = iEQU;
					posa[2] = kind;
					return ECL_SYNTAX_ERROR;
				}
				pos_var_end = ssp->sp - (len+1);
				kind |= 4;
				sp = ssp->sp;
			/*	break;	*/
			}
		}
	}
	if (kind & 4) ssp->sp = sp;
	posa[0] = iEQU;
	posa[1] = pos_var_end;
	posa[2] = kind;
	posa[3] = pos_enzan;
/*
printf("%s: iEQU=%d pos_var_end=%d kind=%d ssp->sp=%d\n",_fn_,iEQU,pos_var_end,kind,ssp->sp);
*/
	return len;
}

/************************************/
/*	_chk_implicit_char				*/
/************************************/
static int _chk_implicit_char(scope_str,pImp)
char scope_str;
tdtImplicit *pImp;
{
	int rc;
	char c;

	/* MAX_LOOP_WHILE���O���ϐ����e�����󂯂�̂ŁA�X�R�[�v�ƕ����𐧌����� */
	rc = 0;
	if (scope_str == 'P') {
		if (((c=*pImp->imp_from)>='A' && c<='Z') || ((c=*pImp->imp_to)>='A' && c<='Z')) {
					/* %s: %s��'%s'�͎w��ł��܂���B*/
			ERROROUT3(FORMAT(140),"_chk_implicit_char",cl_get_scope_name_from_opt(D_GX_OPT_SET_PUBLIC),"A�`Z");
			rc = ECL_SCRIPT_ERROR;
		}
	}
	return rc;
}

/************************************/
/*	cl_pr_ex_def_implicit			*/
/************************************/
/*
	char imp_scope;		 G,P,S,L 
	char imp_from[4];
	char imp_to[4];
	char imp_attr[3];
*/
int cl_pr_ex_def_implicit(prmnum,pprmp,scrct,proc,opt)
int      prmnum;
parmList **pprmp;
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	static char *_fn_="cl_pr_ex_def_implicit";
	int line_len,iParm[20],check[4],n,len,disp,ret,rc,posa[2],scope;
	char *line,wrk[256],c,scope_str;
	SSPL_S ssp;
	tdtImplicit tImp;
	MCAT2 *pImplicit;
/*
printf("cl_pr_ex_def_implicit: prmnum=%d pprmp[0]->prp=[%s]\n",prmnum,pprmp[0]->prp);
*/
	line = pprmp[0]->prp;
	line_len = pprmp[0]->prmlen;
	memset(&ssp,0,sizeof(SSPL_S));
	mem_set_int(iParm,0,4);
	check[1] = 1;	/* scope */
	scope = 0;
	if ((n=cl_get_def_modifier_SSP(line,line_len,&ssp,gsep,check,iParm,NULL,NULL)) < 0) return n;
	else if (n > 0) {
/*
printf("cl_pr_ex_def_implicit: opt=%08x attr=%d %d %d %d\n",check[3],iParm[0],iParm[1],iParm[2],iParm[3]);
printf("cl_pr_ex_def_implicit: ssp.sp=%d ssp.wd=[%s]\n",ssp.sp,ssp.wd);
*/
		scope = check[3];
	}
	pImplicit = NULL;
	if (proc && (!scope || (scope & D_GX_OPT_SET_LOCAL))) {
		if (!(pImplicit=proc->pImplicit)) {
			pImplicit = akxs_mseq2_new(sizeof(tdtImplicit),0,11,NULL,NULL);
			proc->pImplicit = pImplicit;
		}
		scope_str = 'L';
		scope = D_GX_OPT_SET_LOCAL;
	}
	else if (scrct && (!scope || (scope & D_GX_OPT_SET_PRIVATE))) {
		if (!(pImplicit=scrct->pImplicit)) {
			pImplicit = akxs_mseq2_new(sizeof(tdtImplicit),0,11,NULL,NULL);
			scrct->pImplicit = pImplicit;
		}
		scope_str = 'S';
		scope = D_GX_OPT_SET_PRIVATE;
	}
	else if (scope & D_GX_OPT_SET_PUBLIC) {
		pImplicit = pGImplicit;
		scope_str = 'P';
	}
	else if (scope & D_GX_OPT_SET_GLOBAL) {
		/* ���Z�b�V�����O�Œ�`���ꂽ�O���ϐ����e�����󂯂�̂ŁA�X�R�[�v�𐧌����� */
		ERROROUT2(FORMAT(636),_fn_,cl_get_scope_name_from_opt(scope));	/* %s: %s�͎w��ł��܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	if (!pImplicit) return ECL_MALLOC_ERROR;

	tImp.imp_attr[0] = iParm[0];
	tImp.imp_attr[1] = iParm[1];
	tImp.imp_attr[2] = iParm[2];
	tImp.imp_attr[3] = iParm[3];
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	ret = disp = 0;
	while ((len=akxtgwnsl(line,line_len,&ssp," \t()-,",0x41)) > 0) {
/*
printf("cl_pr_ex_def_implicit: len=%d wd=[%s]\n",len,ssp.wd);
*/
		c = *ssp.wd;
		if (disp == 0) {	/* ( */
			if (c != '(') {
				ret = -1;
				break;
			}
			disp = 1;
		}
		else if (disp==1 || disp==3) {	/* A or B */
			if (ssp.attr[0]>10 || (c>='0' && c<='9')) {
				ret = -2;
				break;
			}
			else {
				if (disp == 1) {
					tImp.imp_scope = scope_str;
					/* from�Z�b�g, to ��0���Z�b�g */
					strnzcpy(tImp.imp_from,ssp.wd,3);
					tImp.imp_to[0] = '\0';
					tImp.imp_flen = len;
				}
				else {
					/* to �ɃZ�b�g */
					strnzcpy(tImp.imp_to,ssp.wd,3);
				}
				disp++;
			}
		}
		else if (disp == 2) {	/* - or , */
			if (c == '-') {
				disp = 3;
			}
			else if (c==',' || c==')') {
				/* from,to��o�^ */
/*
printf("cl_pr_ex_def_implicit: scope=[%c] from=[%s] to=[%s]\n",tImp.imp_scope,tImp.imp_from,tImp.imp_to);
*/
				if ((rc=_chk_implicit_char(scope_str,&tImp)) < 0) return rc;
				if ((rc=akxs_mseq_s(pImplicit,&tImp)) < 0) return rc;
				if (c == ')') {
					disp = 5;
					break;
				}
				disp = 1;
			}
			else {
				ret = -3;
				break;
			}
		}
		else if (disp == 4) {	/* , or ) */
			if (c==',' || c==')') {
				/* from,to��o�^ */
/*
printf("cl_pr_ex_def_implicit: scope=[%c] from=[%s] to=[%s]\n",tImp.imp_scope,tImp.imp_from,tImp.imp_to);
*/
				if ((rc=_chk_implicit_char(scope_str,&tImp)) < 0) return rc;
				if ((rc=akxs_mseq_s(pImplicit,&tImp)) < 0) return rc;
				if (c == ')') {
					disp = 5;
					break;
				}
				disp = 1;
			}
			else {
				return -4;
			}
		}
	}
	if (!ret) {
		if ((len=akxtgwnsl(line,line_len,&ssp," \t()-,",0x41)) > 0) ret = -5;
		else if (disp < 5) ret = -6;
	}
	if (ret < 0) {
/*
printf("cl_pr_ex_def_implicit: ret=%d\n",ret);
*/
		return ECL_SYNTAX_ERROR;
	}
/*
printf("cl_pr_ex_def_implicit: pImplicit->mc_ipos=%d\n",pImplicit->mc_ipos);
*/
	posa[0] = 13;
	posa[1] = 1;
	ret = akxnmstrsort2(pImplicit->mc_bufp,pImplicit->mc_ipos,sizeof(tdtImplicit),posa,1);
	/* 2023.8.25 */
	if (!ret) set_attr_scalar_var(scrct,proc,scope);
/*
printf("cl_pr_ex_def_implicit: ret=%d\n",ret);
*/
	return ret;
}

/************************************/
/*	cl_get_implicit					*/
/************************************/
int cl_get_implicit(varnam,varlen,iParm,scrct,proc,scope)
char *varnam;
int varlen,iParm[];
ScrPrCT *scrct;
ProcCT *proc;
int scope;
{
	static char *_fn_="cl_get_implicit";
	int i,atr,ret;
	char c,c1,c2;
	tdtImplicit tImp;
	MCAT2 *pImplicit;

	if (!varnam || varlen<=0 || !iParm) return -1;

DEBUGOUTL5(120,"cl_get_implicit: scrct=%08x proc=%08x scope=%08x varlen=%d varnam=[%s]",scrct,proc,scope,varlen,varnam);

	pImplicit = NULL;
	if (!scope) {
		if (scrct) {
			if (proc) pImplicit = proc->pImplicit;
			else  pImplicit = scrct->pImplicit;
/*
printf("cl_get_implicit: pImplicit=%08x\n",pImplicit);
*/
		}
	}
	else if (scope & D_GX_OPT_SET_LOCAL) {
		if (proc) pImplicit = proc->pImplicit;
	}
	else if (scope & D_GX_OPT_SET_PRIVATE) {
		if (scrct) pImplicit = scrct->pImplicit;
	}
	else if (scope & D_GX_OPT_SET_PUBLIC) {
		pImplicit = pGImplicit;
	}
#if 0	/* def global xxx; �̂Ƃ��Ă΂��̂ŃG���[�ɂł��Ȃ� */
	else if (scope & D_GX_OPT_SET_GLOBAL) {
		ERROROUT2(FORMAT(636),_fn_,cl_get_scope_name_from_opt(scope));	/* %s: %s�͎w��ł��܂���B*/
		return ECL_SCRIPT_ERROR;
	}
#endif
	if (!pImplicit) return 0;

	mem_set_int(iParm,0,4);
	i = 1;
	c = *varnam;
	ret = 0;
	while (!akxs_mseq_get(pImplicit,i,&tImp)) {
/*
printf("cl_get_implicit: from=[%s] to=[%s]\n",tImp.imp_from,tImp.imp_to);
*/
		if (c2=*tImp.imp_to) {
			c1 = *tImp.imp_from;
			if (c>=c1 && c<=c2) {
				ret = 1;
				break;
			}
		}
		else {
			if (varlen >= tImp.imp_flen) {
				if (!memcmp(varnam,tImp.imp_from,tImp.imp_flen)) {
					ret = 2;
					break;
				}
			}
		}
		i++;
	}
	if (ret) {
		iParm[0] = tImp.imp_attr[0];
		iParm[1] = tImp.imp_attr[1];
		iParm[2] = tImp.imp_attr[2];
		iParm[3] = tImp.imp_attr[3];
DEBUGOUTL5(120,"%s: iParm=%d %d %d %d",_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);
	}
	return ret;
}
/* 2023.8.25 */
/************************************/
/*	set_attr_scalar_var				*/
/************************************/
int set_attr_scalar_var(scrct,proc,scope)
ScrPrCT *scrct;
ProcCT *proc;
int scope;
{
	XHASHB *xha;
	tdtINFO_PARM *pInfo,tInfoParm;
	int i,m,ih,rc,iParm[4];
	char *cpKey,id;
/*
printf("set_attr_scalar_var:Enter scrct=%08x proc=%08x scope=%08x\n",scrct,proc,scope);
*/
	rc = 0;
	xha = NULL;
	if (scope & D_GX_OPT_SET_LOCAL) {
		if (proc) xha = proc->pha_vnam;
	}
	else if (scope & D_GX_OPT_SET_PRIVATE) {
		if (scrct) xha = scrct->Vary->pha_vnam;
	}
	else if (scope & D_GX_OPT_SET_PUBLIC) xha = pCLprocTable->pha_vnam;
	else if (scope & D_GX_OPT_SET_GLOBAL) {
		return ECL_SCRIPT_ERROR;
	}
	if (xha) {
		m = akxs_xhashn2(xha,'M',NULL,0,NULL);
		for (i=1;i<=m;i++) {
			xha->xha_xhix = i;
			if ((ih = akxs_xhashn2(xha,'P',&cpKey,0,&pInfo)) < 0) break;
			else if (ih > 0) {

DEBUGOUTL3(120,"set_attr_scalar_var: cpKey=[%s] pi_id=[%c] pi_aux[0]=%02x",cpKey,pInfo->pi_id,pInfo->pi_aux[0]);

				if ((id=pInfo->pi_id)==' ' || id=='\0') {
					if (!(pInfo->pi_aux[0] & D_AUX0_ZOK_DTYP)) {
						rc = cl_get_implicit(cpKey,strlen(cpKey),iParm,scrct,proc,scope);
/*
printf("set_attr_scalar_var: rc=%d\n",rc);
*/
						if (rc > 0) {
/*
printf("set_attr_scalar_var: cpKey=[%s] iParm=%d %d %d %d\n",cpKey,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
							if (id) cl_gx_copy_info(&tInfoParm,pInfo);
							rc = cl_set_parm_init(pInfo,iParm,1);
							if (id && !rc) rc = cl_gx_rep_val_set(pInfo,&tInfoParm,0);
						}
					}
				}
			}
		}
	}
	return rc;
}
