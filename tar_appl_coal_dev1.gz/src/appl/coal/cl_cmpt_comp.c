static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************************
*																				*
*	�����ړI	�F	��r���Z����												*
*																				*
*	�֐���		�F	int cl_cmpt_comp(pAns , pOprtr , pInfoParm1 , pInfoParm2)	*
*						(O)int	*pAns											*
*						(I)char	*pOprtr											*
*						(I)tdtINFO_PARM *pInfoParm1								*
*						(I)tdtINFO_PARM *pInfoParm2								*
*																				*
*	�߂�l		�F	ERROR														*
*					NORMAL														*
*																				*
*	�����T�v	�F																*
*																				*
*********************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];

static char *Enzan[]={
	"EQ","iEQ","==","",
	"NE","iNE","!=","<>","><","",
	"GT","iGT",">","",
	"LT","iLT","<","",
	"GE","iGE",">=","=>","",
	"LE","iLE","<=","=<","",
	"LIKE","iLIKE","",
	"IN","iIN","",
	"INSTR","INiSTR","INrSTR","INirSTR","",
	"REGEX","iREGEX","",
	"SKIP_OPT","",
	NULL};
static unsigned char jg[6][3]={
	{0,1,0},
	{1,0,1},
	{0,0,1},
	{1,0,0},
	{0,1,1},
	{1,1,0}};

/********************************************/
/*											*/
/********************************************/
int cl_get_comp_judge(opr,result)
int opr,result;
{
	int i;

	if (result < 0) i = 0;
	else if (result > 0) i = 2;
	else i = 1;
	return jg[opr][i];
}

/********************************************/
/* opt : 0x01 : �G���[���b�Z�[�W���o�͂���B*/
/*       0x10 : LIKE�ȍ~�����Z�q�Ƃ���B	*/
/* �ԋp : >=0 : ���Z�q����					*/
/*        < 0 : ���Z�q�Ȃ�					*/
/********************************************/
int _get_comp_no(pOprtr,opt)
char *pOprtr;
int opt;
{
	int i,opr;
	opr = akxs_seqr_str(Enzan,-1,pOprtr,0x11);
	if (!(opt & 0x10) && opr>=7) opr = 0;
	if (!opr) {
#if 1
		if (opt & 0x01) {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
		}
#endif
		opr = -1;
	}
	else opr--;
	return opr;
}

/****************************************/
/*	opt : 0x0001 : ignore case			*/
/*	      0x4000 : comp string			*/
/****************************************/
int _memcmplen(p1,len1,p2,len2,opt)
char *p1,*p2;
int  len1,len2,opt;
{
#if 1	/* 2024.7.7 */
	return akxmemcmplen(p1,len1,p2,len2,opt);
#else
	int result;

	if (opt & 0x4000)
		return akxmbncmp_opt(p1,len1,p2,len2,opt & ~0x4000);
	else if (!len1 && !len2) result = 0;
	else if(len1 < len2) {
		if (!(result = memcmp(p1,p2,len1)))
			result = -1;
	}
	else if(len1 > len2) {
		if (!(result = memcmp(p1,p2,len2)))
			result = 1;
	}
	else
		result = memcmp(p1,p2,len1);
	return result;
#endif
}

/****************************************/
/*										*/
/****************************************/
static int _comp_array(pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)
long *pAns;
char *pOprtr;
tdtINFO_PARM	*pInfoParm1;
tdtINFO_PARM	*pInfoParm2;
int cmp_opt;
{
	tdtINFO_PARM *ppParm[6],Info,Info1;

	cl_set_parm_char(&Info1,pOprtr,strlen(pOprtr));
	cl_null_parm(&Info);
	ppParm[0] = pInfoParm1;
#if 1	/* 2023.12.17 */
	ppParm[1] = pInfoParm2;
	ppParm[2] = &Info;
	ppParm[3] = &Info1;
	return cl_array_ope_opt(pAns,4,ppParm,D_FUC_ARRAY_CMP,cmp_opt);
#else
	ppParm[1] = &Info;
	ppParm[2] = pInfoParm2;
	ppParm[3] = &Info;
	ppParm[4] = &Info;
	ppParm[5] = &Info1;
	return cl_array_ope_opt(pAns,6,ppParm,D_FUC_ARRAY_CMP,cmp_opt);
#endif
}

/****************************************/
/*										*/
/****************************************/
static int _comp_range(ppAns,pOprtr,opr,nr,ppParm1,ppParm2)
char **ppAns,*pOprtr;
int opr,nr;
tdtINFO_PARM *ppParm1[],*ppParm2[];
{
	int ret,i,lVal;
	tdtINFO_PARM *pInfoParm1,*pInfoParm2;

	ret = 0;
	for (i=0;i<nr;i++) {
		pInfoParm1 = ppParm1[i];
		pInfoParm2 = ppParm2[i];
		pInfoParm1->pi_alen &= ~(D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		pInfoParm2->pi_alen &= ~(D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		pInfoParm1->pi_scale &= ~D_DATA_IMAGE;
		pInfoParm2->pi_scale &= ~D_DATA_IMAGE;
		if ((ret=cl_cmpt_comp(ppAns,pOprtr,pInfoParm1,pInfoParm2,0,NULL)) < 0) break;
		if (nr > 1) {
			memcpy(&lVal,*ppAns,sizeof(long));
/*
printf("_comp_range: i=%d lVal=%d\n",i,lVal);
*/
			if ((!opr && !lVal) || (opr && lVal)) break;
		}
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _comp_range_complex(ppAns,pOprtr,opr,pInfoParm1,pInfoParm2)
char **ppAns,*pOprtr;
int opr;
tdtINFO_PARM *pInfoParm1,*pInfoParm2;
{
	tdtINFO_PARM *ppParm1[3],tInfo1[3],*ppParm2[3],tInfo2[3],tComplex1,tComplex2;
	int ret,rc,iCMPLX1,iCMPLX2,iIMAGE1,iIMAGE2,iRANGE1,iRANGE2,iVal[2],nr1,nr2,i,result;
	char *dat1,*dat2,*pStr;
	long *pAns;

	iCMPLX1 = pInfoParm1->pi_alen & D_AULN_COMPLEX_DATA;
	iCMPLX2 = pInfoParm2->pi_alen & D_AULN_COMPLEX_DATA;
	iIMAGE1 = pInfoParm1->pi_scale & D_DATA_IMAGE;
	iIMAGE2 = pInfoParm2->pi_scale & D_DATA_IMAGE;
	iRANGE1 = pInfoParm1->pi_alen & D_AULN_RANGE_DATA;
	iRANGE2 = pInfoParm2->pi_alen & D_AULN_RANGE_DATA;
/*
printf("_comp_range_complex: iCMPLX1=%d iCMPLX2=%d iIMAGE1=%d iIMAGE2=%d\n",
iCMPLX1,iCMPLX2,iIMAGE1,iIMAGE2);
printf("_comp_range_complex: iRANGE1=%d iRANGE2=%d\n",iRANGE1,iRANGE2);
*/
	if (iCMPLX1 || iCMPLX2 || iIMAGE1 || iIMAGE2) {
		if (!iCMPLX1) {
			_set_complex(&tComplex1,pInfoParm1);
			pInfoParm1 = &tComplex1;
			iCMPLX1 = 1;
		}
		if (!iCMPLX2) {
			_set_complex(&tComplex2,pInfoParm2);
			pInfoParm2 = &tComplex2;
			iCMPLX2 = 1;
		}
	}
	ret = 0;
	if ((iCMPLX1 && iCMPLX2) || (iRANGE1 && iRANGE2)) {
		ppParm1[0] = &tInfo1[0];
		ppParm1[1] = &tInfo1[1];
		ppParm1[2] = &tInfo1[2];
		if ((nr1=cl_get_range_info(pInfoParm1,ppParm1,iVal,0)) < 0) return nr1;
		ppParm2[0] = &tInfo2[0];
		ppParm2[1] = &tInfo2[1];
		ppParm2[2] = &tInfo2[2];
		if ((nr2=cl_get_range_info(pInfoParm2,ppParm2,iVal,0)) < 0) return nr2;
	}
	if (iCMPLX1 || iCMPLX2 || iIMAGE1 || iIMAGE2) {
		if ((iCMPLX1 && iCMPLX2) || (iIMAGE1 && iIMAGE2)) {
			if (opr==0 || opr==1) {
				ret = DEF_ZOK_BINA;
				if (!(result = nr1 - nr2)) {
					if (iCMPLX1)
						rc = _comp_range(ppAns,pOprtr,opr,nr1,ppParm1,ppParm2);
					else {
						ppParm1[0] = &tInfo1[0];
						ppParm2[0] = &tInfo2[0];
						cl_gx_copy_info(ppParm1[0],pInfoParm1);
						cl_gx_copy_info(ppParm2[0],pInfoParm2);
						rc = _comp_range(ppAns,pOprtr,opr,1,ppParm1,ppParm2);
					}
					return rc;
				}
			}
			else ret = -1;
		}
		else {
#if 1
			result = 1;
			ret = DEF_ZOK_BINA;
#else
			if (iCMPLX1) dat1 = FORMAT(635);
			else if (iIMAGE1) dat1 = FORMAT(639);
			else dat1 = FORMAT(638);
			if (iCMPLX2) dat2 = FORMAT(635);
			else if (iIMAGE2) dat2 = FORMAT(639);
			else dat2 = FORMAT(638);
			ret = -2;
#endif
		}
	}
	else if (iRANGE1 || iRANGE2) {
		if (iRANGE1 && iRANGE2) {
			if (opr==0 || opr==1) {
				ret = DEF_ZOK_BINA;
				if (nr1==3 && _is_1(ppParm1[2])) nr1 = 2;
				if (nr2==3 && _is_1(ppParm2[2])) nr2 = 2;
				if (!(result = nr1 - nr2))
					return _comp_range(ppAns,pOprtr,opr,nr1,ppParm1,ppParm2);
			}
			else ret = -1;
		}
		else {
			dat1 = FORMAT(597);	/* ��ʕϐ��܂��͒萔 */
			dat2 = FORMAT(134);	/* �͈͎w�� */
			if (iRANGE1) {
				pStr = dat1;
				dat1 =dat2;
				dat2 = pStr;
			}
			ret = -2;
		}
	}
	if (ret == DEF_ZOK_BINA) {
		if (result<0) i = 0;
		else if (result>0) i = 2;
		else i = 1;
		pStr = *ppAns;
		pAns = (long *)pStr;
		*pAns = jg[opr][i];
/*
printf("_comp_range_complex: opr=%d, result=%d\n",opr,result);
*/
	}
	else if (ret < 0) {
		if (ret == -1) {
				/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"_comp_range_complex",pOprtr);
		}
		else {
				/* %s: �f�[�^���(����=%s �E��=%s)�������Ă��܂���B*/
			ERROROUT3(FORMAT(637),"_comp_range_complex",dat1,dat2);
		}
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_cmpt_comp(ppAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp)
char		**ppAns;
char		*pOprtr;
tdtINFO_PARM	*pInfoParm1;
tdtINFO_PARM	*pInfoParm2;
int			narg;
parmList    *prmp[];
{
	return cl_cmpt_comp_opt(ppAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp,0);
}

/****************************************************/
/* cmp_opt : DEF_ZOK_DATA : �f�[�^���[�h�ɂ���B	*/
/****************************************************/
int cl_cmpt_comp_opt(ppAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp,cmp_opt)
char **ppAns,*pOprtr;
tdtINFO_PARM *pInfoParm1,*pInfoParm2;
int narg,cmp_opt;
parmList *prmp[];
{
	int    rc,atr1,atr2,result,len1,len2,like,opt,mflg,flags[2];
	long   Val1z[NMPA_LONG],Val2z[NMPA_LONG],*Val1,*Val2;
	long   Value1,Value2,*pAns;
	ulong  uValue1,uValue2;
	int    ope,parm[6],nparm,iDATA1,iDATA2,iUNSIGNED1,iUNSIGNED2;
	double dVal1,dVal2;
	char   *dat1,*dat2,id1,id2,*pStr;
	char   errbuf[256];
	MPA *mpa1,*mpa2,*mpa,ma1z,ma2z,*ma1,*ma2;
	tdtINFO_PARM **ppParm,*pParm,InfoParmW,*ppParm0[PM_MAX];

	int opr,i;
/*
printf("cl_cmpt_comp: pOprtr=[%s] cmp_opt=%08x\n",pOprtr,cmp_opt);
*/
DEBUGOUT_InfoParm(110,"cl_cmpt_comp:1: pOprtr=[%s] narg=%d",pInfoParm1,pOprtr,narg);
DEBUGOUT_InfoParm(110,"cl_cmpt_comp:2:",pInfoParm2,0,0);

#if 0
	if (cl_check_data_id(pInfoParm1,0x04)<0 ||
	    cl_check_data_id(pInfoParm2,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
#endif
	pStr = *ppAns;
	pAns = (long *)pStr;
	*pAns = 0;
	rc = NORMAL;
	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;

	if (!id1 || !id2) {
		if ((opr=_get_comp_no(pOprtr,1)) < 0) return ECL_SCRIPT_ERROR;
		result = id1 - id2;
		if (result<0) i = 0;
		else if (result>0) i = 2;
		else i = 1;
		*pAns = jg[opr][i];
		return DEF_ZOK_BINA;
	}

	opr = _get_comp_no(pOprtr,0);
/*
printf("cl_cmpt_comp: opr=%d id1=[%c] id2=[%c]\n",opr,id1,id2);
*/
	len1 = pInfoParm1->pi_dlen;
	len2 = pInfoParm2->pi_dlen;
	if (opr<0 && id1==' ' && strchr(" RALN",id2)) ;
#if 1	/* 2021.11.24 */
	else if ((id1==' ' && len1==0) || (id2==' ' && len2==0)) ;
#endif
	else if (id1 != id2) {
		/* %s: �p�����[�^�̃f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B */
		ERROROUT3(FORMAT(241),"cl_cmpt_comp_opt",id1,id2);
		return ECL_SCRIPT_ERROR;
	}
	if (cmp_opt & DEF_ZOK_DATA) {
		iDATA1 = 1;
		iDATA2 = 1;
	}
	else {
		iDATA1 = pInfoParm1->pi_aux[0] & DEF_ZOK_DATA;
		iDATA2 = pInfoParm2->pi_aux[0] & DEF_ZOK_DATA;
	}
	atr1 = pInfoParm1->pi_attr;
	atr2 = pInfoParm2->pi_attr;
	dat1 = pInfoParm1->pi_data;
	dat2 = pInfoParm2->pi_data;
  if (id1 == ' ') {
#if 1	/* 2025.4.2 */
	if ((pInfoParm1->pi_alen & D_AULN_RATIONAL) || (pInfoParm2->pi_alen & D_AULN_RATIONAL)) {
		if (rc=cl_rational_comp(ppAns,pOprtr,opr,pInfoParm1,pInfoParm2)) return rc;
	}
#endif
	if (rc=_comp_range_complex(ppAns,pOprtr,opr,pInfoParm1,pInfoParm2)) return rc;
	iUNSIGNED1 = iUNSIGNED2 = 0;
	if (atr1 == DEF_ZOK_BINA) iUNSIGNED1 = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
	if (atr2 == DEF_ZOK_BINA) iUNSIGNED2 = pInfoParm2->pi_scale & D_DATA_UNSIGNED;
	if (opr >= 0) {
		if ((atr1==DEF_ZOK_CHAR && !len1) || (atr2==DEF_ZOK_CHAR && !len2) ||
		    (atr1==atr2) ||
		    ((atr1==DEF_ZOK_BINA || atr1==DEF_ZOK_FLOA || atr1==DEF_ZOK_DECI || atr1==DEF_ZOK_DATE) &&
		     (atr2==DEF_ZOK_BINA || atr2==DEF_ZOK_FLOA || atr2==DEF_ZOK_DECI || atr2==DEF_ZOK_DATE))) {
			;
		}
		else if (!(pGlobTable->options[1] & 0x01) && atr1!=DEF_ZOK_BULK && atr2!=DEF_ZOK_BULK) {
			if (atr1 == 1) {
				pInfoParm1 = &InfoParmW;
				if ((rc=cl_conv_const_n_str(pInfoParm1, dat1, len1)) < 0) return rc;
				atr1 = pInfoParm1->pi_attr;
				len1 = pInfoParm1->pi_dlen;
				dat1 = pInfoParm1->pi_data;
				if (atr1 == DEF_ZOK_BINA) iUNSIGNED1 = pInfoParm1->pi_scale & D_DATA_UNSIGNED;
			}
			else if (atr2 == 1) {
				pInfoParm2 = &InfoParmW;
				if ((rc=cl_conv_const_n_str(pInfoParm2, dat2, len2)) < 0) return rc;
				atr2 = pInfoParm2->pi_attr;
				len2 = pInfoParm2->pi_dlen;
				dat2 = pInfoParm2->pi_data;
				if (atr2 == DEF_ZOK_BINA) iUNSIGNED2 = pInfoParm2->pi_scale & D_DATA_UNSIGNED;
			}
		}
		else {
/*
printf("cl_cmpt_comp: attr1 = %d, attr2 = %d\n",atr1,atr2);
*/
			/* �p�����[�^�̌^(attr1=%d attr2=%d)�������Ă��܂���B */
			ERROROUT2(FORMAT(242),atr1,atr2);
			return ECL_SCRIPT_ERROR;
		}
/*
printf("cl_cmpt_comp: attr1=%d, len1=%d\n",atr1,len1);
printf("cl_cmpt_comp: attr2=%d, len2=%d\n",atr2,len2);
*/
		if ((atr1 == DEF_ZOK_BINA || atr1 == DEF_ZOK_FLOA || atr1==DEF_ZOK_DECI) &&
		    (atr2 == DEF_ZOK_BINA || atr2 == DEF_ZOK_FLOA || atr2==DEF_ZOK_DECI)) {
			if (len1==0 || dat1==NULL) {
				ERROROUT1(FORMAT(243),FORMAT(248));	/* ���p�����[�^���k���ł��B */
			 	return ECL_SCRIPT_ERROR;
			}
			if (len2==0 || dat2==NULL) {
				ERROROUT1(FORMAT(243),FORMAT(249));	/* ���p�����[�^���k���ł��B */
			 	return ECL_SCRIPT_ERROR;
			}
			mpa1 = (MPA *)dat1;
			mpa2 = (MPA *)dat2;
			if (atr1 == DEF_ZOK_BINA) {
				Value1 = cl_get_data_long(pInfoParm1);
				uValue1 = Value1;
			}
			else if (atr1 == DEF_ZOK_FLOA)
				memcpy(&dVal1, dat1, sizeof(double));
			if (atr2 == DEF_ZOK_BINA) {
				Value2 = cl_get_data_long(pInfoParm2);
				uValue2 = Value2;
			}
			else if (atr2 == DEF_ZOK_FLOA)
				memcpy(&dVal2, dat2, sizeof(double));
			if (atr1 == DEF_ZOK_FLOA || atr2 == DEF_ZOK_FLOA) {
				if (atr1 == DEF_ZOK_BINA) {
					if (iUNSIGNED1) dVal1 = uValue1;
					else dVal1 = Value1;
				}
				else if (atr1 == DEF_ZOK_DECI) m_dset(&dVal1,mpa1);
				if (atr2 == DEF_ZOK_BINA) {
					if (iUNSIGNED2) dVal2 = uValue2;
					else dVal2 = Value2;
				}
				else if (atr2 == DEF_ZOK_DECI) m_dset(&dVal2,mpa2);
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) dVal1 = X_MAX(dVal1,dVal2);
					else if (!stricmp(pOprtr,"MIN")) dVal1 = X_MIN(dVal1,dVal2);
					else return -1;
					memcpy(pAns,&dVal1,sizeof(double));
					return DEF_ZOK_FLOA;
				}
				else {
					if (dVal1 == dVal2)
						result = 0;
					else if (dVal1 > dVal2)
						result = 1 ;
					else
						result = -1;
				}
			}
#if 1	/* 2023.6.27 */
			else if (atr1==DEF_ZOK_DECI || atr2==DEF_ZOK_DECI ||
			         (atr1==DEF_ZOK_BINA && iUNSIGNED1) || (atr2==DEF_ZOK_BINA && iUNSIGNED2)) {
#else
			else if (atr1==DEF_ZOK_DECI || atr2==DEF_ZOK_DECI ||
			         atr1==DEF_ZOK_BINA || atr2==DEF_ZOK_BINA/*) {
			         (atr1==DEF_ZOK_DATE && atr2==DEF_ZOK_DATE)*/) {
#endif
				Val1 = cl_get_tmpMPA(Val1z);
				Val2 = cl_get_tmpMPA(Val2z);
				if (atr1 == DEF_ZOK_BINA) {
					mpa1 = (MPA *)Val1;
					m_l2mpau(Value1,mpa1,iUNSIGNED1);
				}
				if (atr2 == DEF_ZOK_BINA) {
					mpa2 = (MPA *)Val2;
					m_l2mpau(Value2,mpa2,iUNSIGNED2);
				}
				result = m_cmp(mpa1,mpa2);
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) mpa = result>0 ? mpa1: mpa2;
					else if (!stricmp(pOprtr,"MIN")) mpa = result<0 ? mpa1: mpa2;
					else return -1;
					memcpy(pAns,mpa,sizeofMPA());
					return DEF_ZOK_DECI;
				}
			}
#if 1	/* 2023.6.27 */
			else {
				if (toupper(*pOprtr) == 'M') {
					if (!stricmp(pOprtr,"MAX")) Value1 = X_MAX(Value1,Value2);
					else if (!stricmp(pOprtr,"MIN")) Value1 = X_MIN(Value1,Value2);
					else return -1;
					*pAns = Value1;
					return DEF_ZOK_BINA;
				}
				else {
					if (Value1 == Value2)
						result = 0;
					else if (Value1 > Value2)
						result = 1;
					else
						result = -1;
				}
			}
#else
		/*	else {
				if (toupper(*pOprtr) == 'M') {
					if (iUNSIGNED1 | iUNSIGNED2) {
						if (!stricmp(pOprtr,"MAX")) Value1 = X_MAX(uValue1,uValue2);
						else if (!stricmp(pOprtr,"MIN")) Value1 = X_MIN(uValue1,uValue2);
						else return -1;
					}
					else {
						if (!stricmp(pOprtr,"MAX")) Value1 = X_MAX(Value1,Value2);
						else if (!stricmp(pOprtr,"MIN")) Value1 = X_MIN(Value1,Value2);
						else return -1;
					}
					*pAns = Value1;
					return DEF_ZOK_BINA;
				}
				else {
					if (iUNSIGNED1 | iUNSIGNED2) {
						if (uValue1 == uValue2)
							result = 0;
						else if (uValue1 > uValue2)
							result = 1;
						else
							result = -1;
					}
					else {
						if (Value1 == Value2)
							result = 0;
						else if (Value1 > Value2)
							result = 1;
						else
							result = -1;
					}
				}
			}	*/
#endif
		}
		else if (atr1==DEF_ZOK_DATE || atr2==DEF_ZOK_DATE) {
			ma1 = (MPA *)cl_get_tmpMPA(&ma1z);
			ma2 = (MPA *)cl_get_tmpMPA(&ma2z);
			if ((rc=cl_get_parm_date(pInfoParm1,ma1,"CMP DATE1")) < 0) return rc;
			if ((rc=cl_get_parm_date(pInfoParm2,ma2,"CMP DATE2")) < 0) return rc;
#if 1	/* 2023.4.16 */
			len1 = X_MIN(ma1->len,10);
			len2 = X_MIN(ma2->len,10);
			result = _memcmplen(ma1->num,len1,ma2->num,len2,0);
#else
			result = _memcmplen(ma1->num,ma1->len,ma2->num,ma2->len,0);
#endif
			if (toupper(*pOprtr) == 'M') {
				if (!stricmp(pOprtr,"MAX")) mpa = result>0 ? ma1: ma2;
				else if (!stricmp(pOprtr,"MIN")) mpa = result<0 ? ma1: ma2;
				else return -1;
				memcpy(pAns,mpa,sizeofMPA());
				return DEF_ZOK_DATE;
			}
		}
		else {	/* CHAR */
#if 1	/* 2022.6.4 */
			if (*pOprtr=='i' || *pOprtr=='I') opt = 1;
#else
			if (!stricmp(pOprtr,"iEQ") || !stricmp(pOprtr,"iNE")) opt = 1;
#endif
			else opt = 0;
/*
printf("cl_cmpt_comp: opt=%d\n",opt);
*/
			result = _memcmplen(dat1,len1,dat2,len2,opt | 0x4000);
		}
	}
	else {
/*
printf("op=[%s] len1=%d s1=[%.*s] len2=%d s2=[%.*s]\n",pOprtr,
pInfoParm1->pi_dlen,pInfoParm1->pi_dlen,pInfoParm1->pi_data,
pInfoParm2->pi_dlen,pInfoParm2->pi_dlen,pInfoParm2->pi_data);
*/
#if 1	/* 2021.8.4 */
		if (stricmp(pOprtr,"IN") && stricmp(pOprtr,"iIN")) {
			if (atr1 != 1) {
				if ((len1=parm_to_char_tmp(pInfoParm1,&dat1,0)) < 0) return len1;
			}
			if (atr2 != 1) {
				if ((len2=parm_to_char_tmp(pInfoParm2,&dat2,0)) < 0) return len2;
			}
		}
#endif
#if 1	/* 2021.4.23 �֐����Ă΂��悤�ɕύX in cl_gx_bexp() *//* 2021.4.25 ���ɖ߂� */
		mflg = (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? 0x10 : 0;	/* 0x04 -> 0x10 */
		opt = 0;
		if (!stricmp(pOprtr,"LIKE")||(opt=!stricmp(pOprtr,"iLIKE"))) {
			rc = akxs_xlike(dat1,len1,dat2,len2,opt);
			if (rc < 0) return rc;
			else if (rc > 0) result = 0;	/* unmatch */
			else result = 1;	/* match */
			*pAns = result;
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"IN")||(opt=!stricmp(pOprtr,"iIN"))) {
			if (cl_get_func_info(pOprtr,parm)) {
				ope = parm[1];
				if ((rc=cl_gx_parm_conv_arg(NULL,2,narg,prmp,NULL,0,&ppParm,NULL)) < 0) return rc;
				ppParm[0] = pInfoParm1;
				ppParm[1] = pInfoParm2;
				nparm = narg + 2;
				atr1 = cl_func_comp(ppAns,pOprtr,nparm,ppParm,ope);
			}
			else atr1 = ECL_SCRIPT_ERROR;
		}
		else if (!stricmp(pOprtr,"INSTR")||(opt=!stricmp(pOprtr,"INiSTR"))) {
/*
printf("cl_cmpt_comp: opt=%d\n",opt);
*/
			*pAns = akxs_in_mem_opt(dat1,len1,dat2,len2,opt+mflg);
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"INrSTR")||(opt=!stricmp(pOprtr,"INirSTR"))) {
/*
printf("cl_cmpt_comp: R opt=%d\n",opt);
*/
			*pAns = akxs_in_mem_opt(dat1,len1,dat2,len2,opt+0x10+mflg);	/* 2 -> 0x10 */
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"REGEX")||(opt=!stricmp(pOprtr,"iREGEX"))) {
			flags[0] = REG_EXTENDED;
			if (opt) flags[0] |= REG_ICASE;
			flags[1] = 0;
			if (*dat1 || !*dat2) {
				rc = akxs_regex(dat2,dat1,0,NULL,flags,sizeof(errbuf),errbuf);
/*
printf("cl_cmpt_comp: regex rc=%d\n",rc);
*/
				if (rc && rc!=REG_NOMATCH) {
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					return ECL_SCRIPT_ERROR;
				}
				else rc = rc ? 0 : 1;
			}
			else if (!strcmp(dat2,"()")) rc = 1;
			else rc = 0;
			*pAns = rc;
			atr1 = DEF_ZOK_BINA;
		}
		else if (!stricmp(pOprtr,"SKIP_OPT")) {
			opt = (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? 0x10 : 0;	/* 0x04 -> 0x10 */
			rc = akx_skip_opt(dat1,len1,dat2,opt|0x08);
			len1 = akxqmlen(dat1,len1);
			if (rc >= len1) rc = 0;
			else rc++;
			*pAns = rc;
			atr1 = DEF_ZOK_BINA;
		}
		else {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
			atr1 = ECL_SCRIPT_ERROR;
		}
		return atr1;
#endif
#if 0
		if (!stricmp(pOprtr,"iEQ") || !stricmp(pOprtr,"iNE")) opt = 1;
		else opt = 0;
/*
printf("cl_cmpt_comp: opt=%d\n",opt);
*/
		result = _memcmplen(dat1,len1,dat2,len2,opt | 0x4000);
#endif
	}
  }
  else if (id1=='L' || id1=='N') {
		parm[0] = parm[1] = 0;
		parm[2] = -1;
		if ((rc=cl_comp_list(pOprtr,pInfoParm1,pInfoParm2,parm,cmp_opt)) >= 0) {
			*pAns = rc;
			rc = DEF_ZOK_BINA;
		}
		return rc;
  }
  else if ((id1=='A' || id1=='R') && (id2=='A' || id2=='R') && iDATA1 && iDATA2) {
		if ((rc=_comp_array(pAns,pOprtr,pInfoParm1,pInfoParm2,cmp_opt)) >= 0)
			 rc = DEF_ZOK_BINA;
		return rc;
  }
  else {
		if (opr < 0) {
			/* cl_cmpt_comp: ���Z�q(%s)�Ɍ�肪����܂��B */
			ERROROUT2(FORMAT(245),"cl_cmpt_comp",pOprtr);
			*pAns = 0;
			return ECL_SCRIPT_ERROR;
		}
		opt = 0;
		result = _memcmplen(dat1,len1,dat2,len2,opt);
  }
	if (result<0) i = 0;
	else if (result>0) i = 2;
	else i = 1;
	*pAns = jg[opr][i];
/*
printf("cl_cmpt_comp: opr=%d, result=%d\n",opr,result);
*/

	return DEF_ZOK_BINA;
}

/****************************************/
/*										*/
/****************************************/
int _get_nparm_opt(nparm,ppParm,popt)
tdtINFO_PARM **ppParm;
int nparm,*popt;
{
	tdtINFO_PARM *pInfoParm,tInfoParm;
	int opt;

	opt = 0;
	pInfoParm = ppParm[nparm-1];
	if (pInfoParm->pi_attr == DEF_ZOK_BINA) {
		opt = cl_get_data_int(pInfoParm);
		nparm--;
/*
printf("_get_nparm_opt: nparm=%d opt=%d\n",nparm,opt);
*/
	}
	*popt = opt;
	return nparm;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_comp(ppWork,pOperator,nparm,ppParm,ope)
char **ppWork;
char *pOperator;
tdtINFO_PARM **ppParm;
int nparm,ope;
{
	tdtINFO_PARM *pInfoParm,tInfoParm;
	int  i,len1,len2,iRc,pos[2],attr,opt,pos_min,pos_max,lenm,i1,optw;
	char *pWork;
	char ww[64],*pp[2],*pp0,*p,c;
	int  rc,atr1,atr2,iAttr[3],result,iVal,Val1[2];
	long lVal1z[NMPA_LONG],lVal2z[NMPA_LONG],*lVal1,*lVal2;
	long Value1,Value2;
	double  dValue1,dValue2,dVal;
	char    op;
	char    errbuf[256];
	MPA     *mpa1,*mpa2,*mpa,ma1z,ma2z,*ma1,*ma2;
	parmList pList;
	tdtLIKE *plike;
	ParList3 par3;
/*
printf("cl_func_comp: pOperator=[%s] ope=%d nparm=%d\n",pOperator,ope,nparm);
*/
/*	pGlobTable->error = 0;	del 2023.8.27 �����ł̓N���A���Ȃ� */
	pWork = *ppWork;
	iRc = attr = opt = 0;
	pInfoParm = ppParm[0];
	if (cl_check_data_id(pInfoParm,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
	if (ope==D_FUC_IN && pInfoParm->pi_id==' ' && ((atr1=pInfoParm->pi_attr)>=2 && atr1<=4)) {
		iRc = cl_in_number(ppWork,pInfoParm,nparm-1,ppParm+1,0);
		return iRc;
	}
	lVal1 = cl_get_tmpMPA(lVal1z);
	lVal2 = cl_get_tmpMPA(lVal2z);
	switch (ope) {
	case D_FUC_ILIKE:
		opt++;
	case D_FUC_LIKE:
/*
printf("cl_func_comp: opt=%d nparm=%d\n",opt,nparm);
*/
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"LIKEs")) < 0) return i1;
		pp[0] = par3.par;
		len1 = par3.parlen;
		if (i1 < nparm-1) {
			nparm = _get_nparm_opt(nparm,ppParm,&optw);
			opt |= optw & 0xff;
		}
#if 1	/* 2022.3.29 */
		if (!(plike = akxs_xlike_new(0,opt))) return -1;
		if ((iRc=akxs_xlike_set_line(plike,pp[0],len1)) < 0) i1 = nparm;
		for (i=i1;i<nparm;i++) {
			pp[1] = NULL;
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) break;
			len2 = iRc;
/*
printf("cl_func_comp: i=%d len2=%d pp[1]=[%s]\n",i,len2,pp[1]);
*/
			if ((iRc=akxs_xlike_set_pat(plike,pp[1],len2)) < 0) break;
			iRc = akxs_pxlike(plike,NULL);
/*
printf("cl_func_comp: i=%d iRc=%d\n",i,iRc);
*/
			if (!iRc) break;
		}
		akxs_xlike_free(plike);
		if (iRc < 0) return iRc;
#else
		for (i=i1;i<nparm;i++) {
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) goto Err;
			len2 = iRc;
			if ((iRc=akxs_xlike(pp[0],len1,pp[1],len2,opt))<0) goto Err;
/*
printf("cl_func_comp: i=%d iRc=%d\n",i,iRc);
*/
			if (!iRc) break;
		}
#endif
		iRc = iRc ? 0 : i-i1+1;
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	case D_FUC_INIRSTR:
		opt |= D_COMP_FUN_IGNORE;	/* opt++;*/
	case D_FUC_INRSTR:
		opt |= D_COMP_FUN_REVERCE;	/* opt++;*/
	case D_FUC_INISTR:
	case D_FUC_IIN:
		opt |= D_COMP_FUN_IGNORE;	/* opt++;*/
	case D_FUC_INSTR:
	case D_FUC_IN:
		opt += (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? D_COMP_OPT_NEW_LEX : 0;
		if (ope==D_FUC_IIN || ope==D_FUC_IN) opt += D_COMP_FUN_IN;
		/* 2021.5.29 */
		iRc = cl_in_string(ppWork,nparm,ppParm,opt);
		break;
	case D_FUC_MAX:
	case D_FUC_MIN:
	case D_FUC_SUM:
	case D_FUC_AVG:
	case D_FUC_PRODUCT:
		/* 2021.7.27 */
		if ((iRc = cl_func_agg(&tInfoParm,nparm,ppParm,ope)) > 0) {
			if (iRc==DEF_ZOK_CHAR || iRc==DEF_ZOK_BULK || iRc==DEF_ZOK_DATE || iRc==DEF_ZOK_DECI)
				*ppWork = tInfoParm.pi_data;
			else memcpy(pWork,tInfoParm.pi_data,tInfoParm.pi_dlen);
		}
		else if (!iRc) iRc = ECL_SYSTEM_ERROR;
		break;
	case D_FUC_IREGEX:
		opt++;
	case D_FUC_REGEX:
		Val1[0] = REG_EXTENDED;
		if (opt) Val1[0] |= REG_ICASE;
		Val1[1] = 0;
		pp[1] = &ww[32];
		if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"REGEXs")) < 0) return i1;
		pp[0] = par3.par;
		len1 = par3.parlen;
#if 1
		if (i1 < nparm-1) {
			nparm = _get_nparm_opt(nparm,ppParm,&optw);
			opt |= optw & 0x01;
		}
#endif
		pp0 = strmemk(pp[0],len1,"cl_func_comp");
	/*	pp0 = strmem(pp[0],len1);	*/
/*
printf("cl_func_comp: opt=%1d Val1[0]=%02x pp0=[%s] len1=%d\n",opt,Val1[0],pp0,len1);
*/
		for (i=i1;i<nparm;i++) {
			if ((iRc=parm_to_char(ppParm[i],&pp[1],NULL)) < 0) goto Err;
/*
printf("cl_func_comp:                  pp[%d]=[%s]\n",i,pp[1]);
*/
			if (*pp[0] || !*pp[1]) {
				iRc = akxs_regex(pp[1],pp0,0,NULL,Val1,sizeof(errbuf),errbuf);
/*
printf("cl_func_comp: regex iRc=%d\n",iRc);
*/
				if (iRc && iRc!=REG_NOMATCH) {
					ERROROUT1(FORMAT(244),errbuf);	/* REGEX: %s */
					iRc = -1;
					goto Err;
				}
			}
			else if (!strcmp(pp[1],"()")) iRc = 0;
			else iRc = 1;
			if (!iRc) break;
		}
		iRc = iRc ? 0 : i-i1+1;
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	case D_FUC_SKIP_OPT:
		opt = (pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX) ? 0x04 : 0;
		opt |= 0x08;
		pp[1] = ww + 32;
		if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,pos,"SKIP_OPT")) < 0) return i1;
		pp[0] = par3.par;
		Val1[0] = par3.parlen;
		lenm = par3.parlen2;
		if (nparm <= i1) {
			ERROROUT1(FORMAT(42),"cl_func_comp");	/* %s: �p�����[�^������܂���B*/
			iRc = ECL_SCRIPT_ERROR;
			goto Err;
		}
		if ((iRc=parm_to_char(ppParm[i1],&pp[1],NULL)) < 0) goto Err;
		Val1[1] = iRc;
/*
printf("cl_func_comp: skip_opt: pp[0]=[%s] Val1[0]=%d i1=%d pp[1]=[%s] Val1[1]=%d lenm=%d pos=%d\n",
pp[0],Val1[0],i1,pp[1],Val1[1],lenm,pos[0]);
*/
		i1++;
		if (nparm > i1) {
			pInfoParm = ppParm[i1];
			if (pInfoParm->pi_attr==DEF_ZOK_CHAR) {
				p = pInfoParm->pi_data;
				len1 = pInfoParm->pi_dlen;
				for (i=0;i<len1;i++) {
					c = toupper(*p++);
					if (c=='I') opt |= 0x01;
					else if (c=='R') opt |= 0x02;
					else if (c=='M') opt |= 0x04;
					else if (c=='B') opt &= ~0x04;
					else if (c=='T') opt |= 0x08;
					else if (c=='N') opt &= ~0x08;
				}
			}
			else {
				opt &= 0x04;
				if (iRc=cl_get_parm_bin(pInfoParm,&iVal,"skip_opt")) goto Err;
				opt |= iVal;
			}
/*
printf("cl_func_comp: skip_opt: opt=%08x\n",opt);
*/
		}
		iRc = akx_skip_opt(pp[0],Val1[0],pp[1],opt);
/*
printf("cl_func_comp: skip_opt: iRc=%d lenm=%d pos=%d\n",iRc,lenm,pos[0]);
*/
		pos[0]--;
		if (!(pGlobTable->options[17] & 0x08)) {
			iRc += pos[0];
			lenm += pos[0];
		}
		if (!(opt & 0x02)) {
			if ((opt & 0x08) && (iRc>=lenm)) iRc = 0;
			else iRc++;
		}
		memcpy(pWork,&iRc,sizeof(int));
		iRc = DEF_ZOK_BINA;
		break;
	default:
		/* 2022.6.4 EQ���́A���Z�q�Ƃ��ď������� */
		if (i=_get_comp_no(pOperator,0) >= 0) {
			iRc = cl_cmpt_comp_opt(ppWork,pOperator,pInfoParm,ppParm[1],0,NULL,0);
		}
		else {
			ERROROUT2("pOperator(%s)��ope(%d)���s���ł��B",pOperator,ope);
			iRc = ECL_SCRIPT_ERROR;
		}
/*
printf("cl_func_comp: i=%d\n",i);
*/
	}
 Err:
	return iRc;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			p0		 : line�̃A�h���X							*/
/*			len0	 : line�̒��� (�o�C�g)						*/
/*			posa[]	 : posa[0] : start (�o�C�g/����)(�擪��1)	*/
/*					   posa[1] : len   (�o�C�g/����)			*/
/*		  OUT													*/
/*			posa1[]	 : len0�𔽉f�����l							*/
/*					 : posa1[0] : start��1�O(�o�C�g)(�擪��0)	*/
/*					   posa1[1] : len  (�o�C�g)					*/
/*					   posa1[2] : start��1�O(����)  (�擪��0)	*/
/*					   posa1[3] : len  (����)					*/
/****************************************************************/
int _get_str_pos_posb(p0,len0,posa,posa1)
char *p0;
int len0,posa[],posa1[];
{
	char *pp0;
	int mflg,sta;

	if (!p0 || !posa || !posa1) return -1;

	if (pCLprocTable->CurScr)
		mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
	else mflg = 1;

	sta = posa[0];
	if (sta > 0) sta--;
	posa1[0] = akxqm2len(p0,len0,sta);
	if (posa[1] > 0) 
		posa1[1] = akxqm2len(p0+posa1[0],len0-posa1[0],posa[1]);
	else
		posa1[1] = len0 - posa1[0];
	posa1[2] = akxqmlen(p0,posa1[0]);
	posa1[3] = akxqmlen(p0+posa1[0],posa1[1]);

	return 0;
}

/********1*********2********3*********4*********5*********6******/
/* ���� : IN													*/
/*			pos[] : pos[0] : start (�o�C�g/����)				*/
/*					pos[1] : len   (�o�C�g/����)				*/
/*			par3  : ������J�n�ʒu���\���̂ւ̃|�C���^		*/
/*					par3->par      : ������J�n�ʒu�̃|�C���^	*/
/*					par3->parlen   : ����(�o�C�g)				*/
/*									<0 : strlen(par3->par)�ƂȂ�*/
/*					par3->parlaen2 : ���ݒ�	 					*/
/*		  OUT													*/
/*			par3  : ������J�n�ʒu���\���̂ւ̃|�C���^		*/
/*					par3->par      : ������J�n�ʒu+start		*/
/*					par3->parlen   : len(�o�C�g)				*/
/*					par3->parlaen2 : lenm(����) 				*/
/* �X�V : 2022.12.11 Akito Konayashi par3�g�p					*/
/****************************************************************/
int _get_str_pos(pos,par3)
int pos[];
ParList3 *par3;
{
	static char null_str[2]={'\0','\0'};	/* 2021.7.28 add */
	ParList2 par2;
	char *pp0;
	int mflg,rc,len1,lenm;
/*
printf("_get_str_pos: pos=%d ppp0=%08x plen1=%08x plenm=%08x\n",
pos,ppp0,plen1,plenm);
*/
/*	if (!ppp0) return -1;	*/
	if (!(pp0 = par3->par)) return -1;
/*
printf("_get_str_pos:1: pp0=[%s]\n",pp0);
*/
	if (pCLprocTable->CurScr)
		mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
	else mflg = 1;

	if ((len1=par3->parlen) < 0) len1 = strlen(par3->par);
	lenm = len1;
	if (lenm>0 && mflg) lenm = akxqmlen(pp0,len1);
	if (lenm > 0) {
		if (pos[0] <= 0) ;
		else if (pos[0] <= lenm) {
			if (pos[1] < 0) lenm -= pos[0] - 1;
			else lenm = pos[1];
			if (mflg) {
				par2.option = 0;
				len1 = substr_mlen(&par2,pp0,len1,pos[0],lenm);
				pp0 = par2.par;
			/*	if (plen1) *plen1 = len1;	*/
			}
			else {
				len1 = pos[1];
				pp0 += pos[0] - 1;
			}
		/*	*ppp0 = pp0;	*/
		}
		else {
		/*	*ppp0 = null_str;	*//* 2021.7.28 ""-->null_str */
			pp0 = null_str;
			lenm = len1 = 0;
		/*	if (plen1) *plen1 = len1;	*/
		}
	}
	par3->parlen = len1;
	par3->parlen2 = lenm;
	par3->par = pp0;
/*
printf("_get_str_pos: mflg=%08x len1=%d lenm=%d pos=%d\n",mflg,len1,lenm,pos[0]);
printf("_get_str_pos:2: pp0=%08x pp0=[%s]\n",pp0,pp0);
*/
	return 0;
}

/********1*********2*********3*********4*********5********6*********7/
/* �@�\ : �J�n�ʒu�ƒ��������߂�									*/
/* ���� : i         : �l��Ԃ�pos�̈ʒu								*/
/*		              pInfoParm���͈͎w��̂Ƃ��́A0 �Œ�			*/
/*		  pInfoParm : �p�����[�^�̃|�C���^							*/
/*		  pos       : pos[i] : �ݒ�l 								*/
/*		              �͈͎w��̂Ƃ���								*/
/*		            : pos[0] : �J�n�ʒu (�ݒ�l)					*/
/*		            : pos[1] : ����		(�ݒ�l)					*/
/* �ԋp : ���^�[���R�[�h											*/
/*		  = 1 : ���� i=0�Ŕ͈͎w�肠��								*/
/*		  = 0 : ����												*/
/*		  < 0 : �G���[												*/
/* �쐬 : 20XX.XX.XX Akito Konayashi								*/
/* �X�V :															*/
/********************************************************************/
int _get_pos_len(i,pInfoParm,pos)
int i;
tdtINFO_PARM *pInfoParm;
int pos[];
{
	int rc;
	tdtINFO_PARM tInfoParm;

	rc = 0;
	if (pInfoParm->pi_id != ' ') return ECL_SYNTAX_ERROR;
	else if (pInfoParm->pi_alen & D_AULN_RANGE_DATA) {
		if (i) {
			/* _get_pos: �͈͎w�肪�擪�ȊO�ɂ���܂��Bi=%d */
			ERROROUT1(FORMAT(250),i);
			rc = ECL_SCRIPT_ERROR;
		}
		else if ((rc=cl_get_parm_bin(pInfoParm,pos,"str_pos1")) >= 0) {
			cl_gx_copy_info(&tInfoParm,pInfoParm);
			if (tInfoParm.pi_attr == DEF_ZOK_BINA) tInfoParm.pi_pos = tInfoParm.pi_hlen;
			else tInfoParm.pi_data += tInfoParm.pi_dlen;
			if ((rc=cl_get_parm_bin(&tInfoParm,&pos[1],"str_pos2")) >= 0) {;
				pos[1] -= pos[0] - 1;
				rc = 1;
			}
		}
	}
	else {
		if ((rc=cl_get_parm_bin(pInfoParm,&pos[i],"str_posi")) > 0) rc = 0;
	}
	return rc;
}

/********1*********2*********3*********4*********5********6*********7/
/* �@�\ : �u������[,�J�n�ʒu[,����]]�v�`������͂���				*/
/* ���� : IN:														*/
/*		  nparm	 : �p�����[�^��										*/
/*		  ppParm : �p�����[�^�̃|�C���^�z��							*/
/*		  i1     : ������̃p�����[�^�ʒu(�擪��0)					*/
/*		  par3   : ������J�n�ʒu����Ԃ��\���̂ւ̃|�C���^		*/
/*				   ���e�͖��ݒ�ŗǂ�(�Q�Ƃ��Ȃ�)					*/
/*		  ppos   : (nparm=1(������̂�)�̂Ƃ��́A����)				*/
/*		           ppos[0] : �J�n�ʒu(����)							*/
/*		         : ppos[1] : ����(����)								*/
/*		  msg    : �Ăяo�����̃R�����g								*/
/*		  OUT:														*/
/*		  par3   : ������J�n�ʒu����Ԃ��\���̂ւ̃|�C���^		*/
/*				   ���e�͖��ݒ�ŗǂ�(�Q�Ƃ��Ȃ�)					*/
/*				   par3->par      : ������J�n�ʒu�̃|�C���^		*/
/*				   par3->parlen   : ����(�o�C�g)					*/
/*				   par3->parlaen2 : ����(����) 						*/
/*		  ppos   : 													*/
/*		           ppos[0] : �J�n�ʒu(����)							*/
/*		         : ppos[1] : ����(����)								*/
/* �ԋp : >0 : �u������,�J�n�ʒu[,������]�v�̎��̃p�����[�^�ʒu		*/
/*		  <0 : �G���[												*/
/* �쐬 : 20XX.XX.XX Akito Konayashi								*/
/* �X�V : 2022.12.11 Akito Konayashi par3�g�p						*/
/********************************************************************/
int cl_get_str_pos(nparm,ppParm,i1,par3,ppos,msg)
int nparm;
tdtINFO_PARM *ppParm[];
int i1;
ParList3 *par3;
int ppos[];
char *msg;
{
	tdtINFO_PARM *pInfoParm;
	int len1,lenm,rc,iGET,pos[3],mflg,ii,code_type;
	char *pp0;

	if (nparm < i1+1) return -1;
#if 0	/* 2022.10.20 *//* 1-->0 2022.10.21 */
	if ((ii=_get_pos_text(nparm-i1,&ppParm[i1])) < 0) return ii;
	else if (!ii) {
		ERROROUT2(FORMAT(76),"cl_get_str_pos","text");		/* %s: %s������܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	i1 += ii - 1;
#endif
	pp0 = NULL;
	if ((rc=parm_to_char(pInfoParm=ppParm[i1],&pp0,NULL)) < 0) return rc;
	lenm = len1 = rc;
	i1++;
	pos[1] = -1;
/*
printf("cl_get_str_pos: nparm=%d i1=%d len1=%d\n",nparm,i1,len1);
*/
	code_type = pInfoParm->pi_code;
	if (nparm >= i1+1) {
		if (!(pInfoParm = ppParm[i1])) return -2;
#if 1	/* 2022.10.20 */
		if ((rc=_get_parm_str_pos(nparm-i1+1,&ppParm[i1-1],pos)) < 0) return rc;
		else if (rc) {
			iGET = 1;
			i1 = pos[2];
/*
printf("cl_get_str_pos: rc=%d pos=%d %d %d\n",rc,pos[0],pos[1],pos[2]);
*/
		}
#else
		if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_BINA) {
			if ((rc=_get_pos_len(0,pInfoParm,pos)) < 0) return rc;
			i1++;
			iGET = 1;
			if (nparm >= i1+1) {
				if (!(pInfoParm = ppParm[i1])) return -111;
				if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_BINA) {
					if ((rc=_get_pos_len(1,pInfoParm,pos)) < 0) return rc;
					i1++;
				}
			}
		}
#endif
		else {
			iGET = 0;
			pos[0] = 1;
		}
		if (ppos) {
			ppos[0] = pos[0];
			ppos[1] = pos[1];
		}
	}
	else {
		if (ppos) {
			pos[0] = ppos[0];
			pos[1] = ppos[1];
		}
		else  return -11;
		iGET = 1;
	}
	par3->parlen = len1;
	par3->parlen2 = lenm;
	par3->par = pp0;
	if (iGET) {
		if (rc=_get_str_pos(pos,par3)) return rc;
	}
	else {
		mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
		if (len1>0 && mflg) lenm = akxqmlen_type(pp0,len1,code_type);
		par3->parlen2 = lenm;
	}
/*
printf("cl_get_str_pos:Exit len1=%d lenm=%d\n",par3->parlen,par3->parlen2);
*/
/*	if (plen1) *plen1 = len1;
	if (plenm) *plenm = lenm;	*/
	return i1;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_str_pos2(nparm,pParm,i1,par3,ppos,msg)
int nparm;
tdtINFO_PARM *pParm;
int i1;
ParList3 *par3;
int *ppos;
char *msg;
{
	tdtINFO_PARM *ppParm[3];
	int rc,pos[2];

	ppParm[0] = &pParm[0];
	ppParm[1] = &pParm[1];
	if (nparm > 2) ppParm[2] = &pParm[2];
	if (ppos) pos[0] = *ppos;
	pos[1] = -1;
	rc = cl_get_str_pos(nparm,ppParm,i1,par3,pos,msg);
	if (ppos) *ppos = pos[0];
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_str_pos(pInfoParmW,pInfoParm1,optW,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
{
	parmList pList;
	ParList3 par3;
	tdtINFO_PARM  tInfoParm,tInfoParm2[2],*pInfoParm;
	int pos[2],len1,rc,nparm,i,j;
	char *pp0,*p,c;

DEBUGOUTL1(161,"--->cl_gx_str_pos: optW=%08x",optW);
DEBUGOUT_InfoParm(161,"pInfoParm1:",pInfoParm1,0,0);
DEBUGOUT_InfoParm(161,"pInfoParm2:",pInfoParm2,0,0);

	if (pInfoParm1->pi_id != ' ') return ECL_SYNTAX_ERROR;

	len1 = pInfoParm2->pi_dlen;
	p = pInfoParm2->pi_data;
	if (pInfoParm2->pi_attr==DEF_ZOK_CHAR && len1>0) {
		if (pInfoParm2->pi_alen & D_AULN_NAME_DATA) {
			memset(&pList,0,sizeof(parmList));
			pList.prp = p;
			pList.prmlen = len1;
			pList.opt = SET_TYPE_OPT(cl_get_char_code_type(pInfoParm2,1));
			if ((rc=cl_conv_arg(&pList,&tInfoParm)) < 0) {
				if (rc != ECL_DEFINED_ARRAY) return rc;
			}
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos:1: rc=%d",&tInfoParm,rc,0);
*/
			if (rc==NAME_CONST && tInfoParm.pi_dlen>0) {
				pList.prp = tInfoParm.pi_data;
				pList.prmlen = tInfoParm.pi_dlen;
				pList.opt = SET_TYPE_OPT(tInfoParm.pi_code);
				if (rc = cl_conv_parm(&pList,&tInfoParm)) {
					if (rc != ECL_DEFINED_ARRAY) return rc;
				}
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos:2: rc=%d",&tInfoParm,rc,0);
*/
			}
			if (tInfoParm.pi_id != ' ') return ECL_SYNTAX_ERROR;
			p = tInfoParm.pi_data;
			len1 = tInfoParm.pi_dlen;
			pInfoParm2 = &tInfoParm;
		}
	}
	if (pInfoParm2->pi_attr == DEF_ZOK_CHAR) {	/*	move to. 2022.11.28 */
		if (len1 > 0) {
			len1 = akxtstrim(0,p,len1,AKX_TRIM_SPACE2);
		}
		if (len1 <= 0) {
			ERROROUT1(FORMAT(627),"cl_gx_str_rep");	/* %s: �؂�o���w��܂��͕ҏW�w�肪��ł��B*/
			return ECL_SCRIPT_ERROR;	/*ECL_SYNTAX_ERROR;*/
		}
/*	if (pInfoParm2->pi_attr == DEF_ZOK_CHAR) {	move from. 2022.11.28 */
		if ((c=*p)=='%' || c=='#' || c=='/') {
/*
printf("cl_gx_str_pos: p=[%s]\n",p);
*/
			return cl_gx_str_edit(pInfoParmW,pInfoParm1,p,len1);
		}
	}
	pos[1] = -1;
	if (pInfoParm2->pi_attr==DEF_ZOK_CHAR && !(pInfoParm2->pi_alen & D_AULN_RANGE_DATA)) {
		if (rc= cl_gx_exps_obj_opt(pInfoParm2->pi_data,NULL,NULL,tInfoParm2,D_GX_OPT_PARMINFO2|D_GX_OPT_GET_RANGE)) return rc;
		nparm = cl_get_InfoParm2(tInfoParm2,&pInfoParm,NULL);
		if (nparm > 2) nparm = 2;
		for (i=0;i<nparm;i++,pInfoParm++) {
/*
DEBUGOUT_InfoParm(0,"cl_gx_str_pos: i=%d",pInfoParm,i,0);
*/
			if ((rc=_get_pos_len(i,pInfoParm,pos)) < 0) return rc;
			else if (rc==1 && nparm>1) {
			/*	parm_to_char_tmp(pInfoParm,&p,0);
				ERROROUT2(FORMAT(649),"cl_gx_str_rep",p);	*//* %s: �؂�o���w��[%s]������Ă��܂��B*/
				return ECL_SYNTAX_ERROR;
			}
			if (pos[1] >= 0) break;
		}
	}
	else if ((rc=_get_pos_len(0,pInfoParm2,pos)) < 0) return rc;

	if ((rc=cl_get_str_pos(1,&pInfoParm1,0,&par3,pos,"str_pos")) < 0) return rc;
/*
printf("cl_gx_str_pos: len1=%d pos[0]=%d pp0=%08x\n",par3.parlen,pos[0],par3.par);
*/
	if (!(pp0 = cl_tmp_const_malloc(par3.parlen+1))) {
		ERROROUT("cl_gx_str_pos: malloc error");
	 	return ECL_MALLOC_ERROR;
	}
	memzcpy(pp0,par3.par,par3.parlen);
	cl_set_parm_char2(pInfoParmW,pp0,par3.parlen,pInfoParm1->pi_code);
DEBUGOUTL1(161,"<---cl_gx_str_pos: len1=%d",par3.parlen);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _rep_wildcard(pat,pat0,patlen,cmd,code_type)
char *pat,*pat0,cmd;
int patlen,code_type;
{
	int i,len,m,rem;
	char c,*p,*p0,c1;
/*
printf("_rep_wildcard:Enter patlen=%d pat0=[%s]\n",patlen,pat0);
*/
	p = pat;
	p0 = pat0;
	len = rem = patlen;
	if (cmd == 's') c1 = '.';
	else c1 = '?';
	while (rem > 0) {
/*
printf("_rep_wildcard: rem=%d\n",rem);
getchar();
*/
		m = akxqmbsnlen(code_type,p0,rem);
		if (m == 1) {
			if ((c=*p0) == '*') c = '%';
			else if (c == c1) c = '_';
			else if (c=='%' || c=='_') {
				*p++ = '\\';
				len++;
			}
			else if (c == '\\') {
				*p++ = c;
				p0++;
				c = *p0;
				rem--;
				m = akxqmbsnlen(code_type,p0,rem);
			}
		}
		if (m == 1) {
			*p++ = c;
			p0++;
			rem--;
		}
		else {
			memcpy(p,p0,m);
			p += m;
			p0 += m;
			rem -= m;
		}
	}
	*p = '\0';
/*
printf("_rep_wildcard: len=%d pat=[%s]\n",len,pat);
*/
	return len;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_str_edit_like(ptext,len1,pat0,patlen0,c1,c2,code_type)
char **ptext,*pat0,c1,c2;
int len1,patlen0,code_type;
{
	tdtINFO_PARM pParm[2],*ppParm[2];
	tdtLIKE *plike;
	int iRc,patlen,iOpt[6],mpn,mpn0,iRVS,iLCMP,lenL,lenR;
	int pos[6],len[9],mflg,pos1;
	char *text,*p1[9],w1[128],*pat,*p,*ps,c;

	text = *ptext;
/*
printf("_gx_str_edit_like:Enter len1=%d text=[%s] patlen0=%d pat0=[%s] c2=[%c]\n",len1,text,patlen0,pat0,c2);
*/
	iRVS = iLCMP = 0;
	if (c1 == '%') iRVS = D_LINE_PAT_REVERSE;
	if (c2) iLCMP = D_LINE_PAT_LNGMATCH;

	mpn = 0;
	pat = pat0 + 1;
	patlen = patlen0;
	if ((c=*pat) == '*') {
		mpn = 2;
		pat0++;
	}
	else if (c == '^') {
		pat0++;
	}
	else {
		*pat0 = '*';
		patlen++;
	}
	if ((c=*(pat+patlen0-1)) == '*') mpn += 1;
	else if (c != '$') {
		strcat(pat0,"*");
		patlen++;
	}

	if (!(pat=cl_tmp_const_malloc(patlen*2+3))) return ECL_MALLOC_ERROR;
	patlen = _rep_wildcard(pat,pat0,patlen,'\0',code_type);
/*
printf("_gx_str_edit_like: patlen=%d pat=[%s] mpn=%d\n",patlen,pat,mpn);
*/
	mflg = 0;
	cl_set_parm_char(&pParm[0],text,len1);
	cl_set_parm_char(&pParm[1],pat,patlen);
	ppParm[0] = &pParm[0];
	ppParm[1] = &pParm[1];
	p1[0] = w1;
	plike = NULL;
	if (iRc=_get_line_pat(2,ppParm,p1,len,iOpt,&plike,3|iRVS|iLCMP)) return iRc;
/*
printf("_gx_str_edit_like: len=%d %d %d %d %d %d %d\n",len[0],len[1],len[2],len[3],len[4],len[5],len[6]);
*/
	patlen = len[4];
	pat = p1[4];
/*
printf("_gx_str_edit_like: patlen=%d pat=[%s] c2=[%c]\n",patlen,pat,c2);
*/
	c2 = '\0';
	memset(pos,0,sizeof(int)*4);
	if (patlen > 0) {
#if 1	/* 2022.3.28 */
		if ((iRc=akxs_xlike_set_pat(plike,pat,patlen)) < 0) goto Err;
#endif
		while (len1 > 0) {
/*
printf("_gx_str_edit_like: p1[0]=[%s] len[0]=%d\n",p1[0],len[0]);
*/
			if (!(iRc=akxs_pxlike(plike,pos))) {
/*
printf("_gx_str_edit_like: pos=%d %d %d %d\n",pos[0],pos[1],pos[2],pos[3]);
*/
				if (!c2 || !mpn) break;
			}
			else {
				if (iRc > 0) iRc = 0;
				break;
			}
		}
		if (!iRc) {
			if (mflg) {
				pos[0] = pos[2];
				pos[1] = pos[3];
			}
			ps = p1[0];
			mpn0 = mpn;
			if (c1=='%' && mpn) {
				mpn = 3 - mpn;
			}
			if (mpn == 2) {
				pos1 = pos[0] + pos[1];
				len1 -= pos1;
				ps += pos1;
			}
			else if (mpn == 1) {
				len1 = pos[0];
				if (c1=='%' && mpn0==1) len1--;
			}
/*
printf("_gx_str_edit_like: mpn=%d ps=%d len1=%d\n",mpn,ps,len1);
*/
			if (p=cl_tmp_const_malloc(len1+1)) {
				if (mpn) {
					if (iRVS) cmn_mrzcpy(p,ps,len1);
					else memzcpy(p,ps,len1);
				}
				else {
					pos1 = pos[0] + pos[1];
					lenL = pos[0];
					lenR = len1 - pos1;
					len1 = lenL + lenR;
/*
printf("_gx_str_edit_like: pos1=%d lenL=%d lenR=%d len1=%d\n",pos1,lenL,lenR,len1);
*/
					if (iRVS) {
						memzcpy(ps+lenL,ps+pos1,lenR);
						cmn_mrzcpy(p,ps,len1);
					}
					else {
						memzcpy(p,ps,lenL);
						memzcpy(p+lenL,ps+pos1,lenR);
					}
				}
				*ptext = p;
				iRc = len1;
			}
			else iRc = ECL_MALLOC_ERROR;
		}
	}
 Err:
	akxs_xlike_free(plike);
	return iRc;
}

/********************************************/
/*	c2   : cmd == 's'|'S'�̂Ƃ��́A���g�p	*/
/*	cmd  : cmd != 's'|'S'�̂Ƃ��́Ac2���g�p	*/
/********************************************/
static int _gx_str_rep(pp1,len1,pat0,patlen,c2,cmd,code_type)
char **pp1,*pat0,c2,cmd;
int len1,patlen,code_type;
{
	char c,*p1,*pat,*p,sep,*sch,*rep,*opt,ucmd;
	int ret,i,pos1,pos2,schlen,replen,optlen,m,rem;
	tdtINFO_PARM pParm[5],*ppParm[5];

	p1 = *pp1;
/*
printf("_gx_str_rep:Enter len1=%d p1=[%s] patlen=%d pat0=[%s] c2=[%c] cmd=[%c]\n",
len1,p1,patlen,pat0,c2,cmd);
*/
	ret = 0;
	if (!(p = cl_tmp_const_malloc(patlen+1))) return ECL_MALLOC_ERROR;
	memzcpy(p,pat0,patlen);
	pat = p;
	rem = patlen;
	ucmd = toupper(cmd);
	i = 0;
	if (ucmd == 'S') {
		sep = *p++;
		rem--;
		i++;
	}
	else sep = '/';
	pos1 = pos2 = 0;
	sch = p;
	schlen = rem;
	while (rem > 0) {
		m = akxqkanjilen2(p,rem);
		if (m == 1) {
			if ((c=*p++) == '\\') {
				m = akxqkanjilen2(p,rem);
				p += m;
				i += m;
				rem -= m;
			}
			else if (c == sep) {
				*(p-1) = '\0';
				if (!pos1) {
					rep = p;
					pos1 = i;
					schlen = pos1 - 1;
					if (ucmd != 'S') break;
				}
				else if (!pos2) {
					opt = p;
					pos2 = i;
					replen = pos2 - pos1 - 1;
				}
				else {
					ret = ECL_SYNTAX_ERROR;
					break;
				}
			}
			i++;
			rem--;
		}
		else {
			p += m;
			i += m;
			rem -= m;
		}
	}
	if (!ret) {
		if (ucmd == 'S') {
			if (!pos2) ret = ECL_SYNTAX_ERROR;
			else {
				optlen = patlen - pos2 - 1;
				if (cmd == 'S') {
					if (!(p=cl_tmp_const_malloc(schlen*2+3))) return ECL_MALLOC_ERROR;
					schlen = _rep_wildcard(p,sch,schlen,cmd,code_type);
					sch = p;
				}
			}
		}
		else {
			if (!pos1) ret = ECL_SYNTAX_ERROR;
			else {
				rep = p;
				replen = patlen-i-1;
				if (c2) {
					opt = "g";
					optlen = 1;
				}
				else {
					opt = "";
					optlen = 0;
				}
			}
		}
	}

	if (ret < 0) {
		ERROROUT2(FORMAT(628),"_gx_str_rep",pat0);	/* %s:  �ҏW�w��[%s]������Ă��܂��B*/
	}
	else {
/*
printf("_gx_str_rep: schlen=%d sch=[%s] replen=%d rep=[%s] optlen=%d opt=[%s]\n",
schlen,sch,replen,rep,optlen,opt);
*/
		/* REPLIKE(line,pat,rep,opt,escape)	*/
		cl_set_parm_char(&pParm[0],p1,len1);
		cl_set_parm_char(&pParm[1],sch,schlen);
		cl_set_parm_char(&pParm[2],rep,replen);
		cl_set_parm_char(&pParm[3],opt,optlen);
		cl_set_parm_char(&pParm[4],"\\",1);
		for (i=0;i<5;i++) ppParm[i] = &pParm[i];
		if (cmd == 's')
			ret = cl_rep_regex(pp1,5,ppParm);
		else
			ret = cl_rep_like(pp1,5,ppParm);
		if (!ret) ret = strlen(*pp1);
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_str_edit(pInfoParmW,pInfoParm1,pat0,patlen)
tdtINFO_PARM *pInfoParmW,*pInfoParm1;
char *pat0;
int patlen;
{
	char *p1,c,c2,*pat,*p,cmd;
	int rc,len1,i,len,posa[6],lena[7],code_type;
	tdtINFO_PARM pParm[5],*ppParm[5];
/*
printf("cl_gx_str_edit:Enter patlen=%d pat0=[%s]\n",patlen,pat0);
*/
	if (patlen >= 2) {
		p1 = NULL;
		if ((len1=parm_to_char(pInfoParm1,&p1,NULL)) < 0) return len1;
		code_type = pInfoParm1->pi_code;
		c2 = c = '\0';
		patlen--;
		c = *pat0++;
		if (c=='s' || c=='S') {
			cmd = c;
		}
		else {
			cmd = '\0';
			c2 = *pat0;
			if (c == c2) {
				if (patlen < 2) {
					return ECL_SYNTAX_ERROR;
				}
				pat0++;
				patlen--;
			}
			else c2 = '\0';
		}
		if (c=='%' || c=='#') {
			if (!(pat=cl_tmp_const_malloc(patlen+3))) return ECL_MALLOC_ERROR;
			memzcpy(pat+1,pat0,patlen);
			len1 = _gx_str_edit_like(&p1,len1,pat,patlen,c,c2,code_type);
/*
printf("cl_gx_str_edit: len1=%d p1=[%s]\n",len1,p1);
*/
		}
		else if (c=='/' || cmd) {
			if (c == '/') {
				if (!(pat=cl_tmp_const_malloc(patlen*2+3))) return ECL_MALLOC_ERROR;
				patlen = _rep_wildcard(pat,pat0,patlen,cmd,code_type);
			}
			else pat = pat0;
			if ((len1=_gx_str_rep(&p1,len1,pat,patlen,c2,cmd,code_type)) < 0) return len1;
		}
	}
	else {
		p1 = NULL;
		len1 = 0;
	}
	cl_set_parm_char2(pInfoParmW,p1,len1,code_type);
	return 0;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/*	���� :  iParm		: iParm[0] : �Ώ�1�̔�r�J�n�ʒu				*/
/*						  iParm[1] : �Ώ�2�̔�r�J�n�ʒu				*/
/*						  iParm[2] : ��r��							*/
/*									   < 0 : �Ώۂ̍ő���܂Ŕ�r���� */
/*			cmp_opt		: ��r�I�v�V����								*/
/*							= 0x01 : ��r�Ώۂ̐����܂߂đS�Ă��A		*/
/*									 ��v�����Ƃ��A1��Ԃ�				*/
/*	�ԋp :  cmp_opt��0x01��												*/
/*			=0�̂Ƃ��A��v��											*/
/*			=1�̂Ƃ��A1/0=��v/�s��v									*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_comp_list(pOprtr,pInfoParm1,pInfoParm2,iParm,cmp_opt)
char *pOprtr;
tdtINFO_PARM	*pInfoParm1;
tdtINFO_PARM	*pInfoParm2;
int iParm[],cmp_opt;
{
	tdtINFO_PARM *p1,*p2;
	int i1,i2,ix1,ix2,nm,Ans,rc,nu1,nu2,match,*pAns,ret;
	tdtRB_CTL *pCt1,*pCt2;
	char *nam;
/*
printf("cl_comp_list:Enter pOprtr=[%s] iParm=%d %d %d cmp_opt=%08x\n",
pOprtr,iParm[0],iParm[1],iParm[2],cmp_opt);
*/
	if ((ix1=iParm[0]) < 0) ix1 = 0;
	if ((ix2=iParm[1]) < 0) ix2 = 0;
	nm  = iParm[2];
	Ans = 0;
	pCt1 = (tdtRB_CTL *)pInfoParm1->pi_data;
	pCt2 = (tdtRB_CTL *)pInfoParm2->pi_data;
/*
printf("cl_comp_list: pCt1=%08x pCt2=%08x\n",pCt1,pCt2);
*/
	/* �z�Q�Ə������`�F�b�N */
/*
printf("cl_comp_list: itc_circ_ref=%08x\n",gtIter_ctl[0].itc_circ_ref);
*/
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
		if (!(gtIter_ctl[1].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}
	/* �z�Q�Ƃ��`�F�b�N */
	nam = cl_gx_get_name_from_id(pInfoParm1->pi_id);
	if ((ret=_iterate_circ_ref(&gtIter_ctl[0],pCt1,nam)) == 1) return 0;
	else if (ret < 0) return ret;
	nam = cl_gx_get_name_from_id(pInfoParm2->pi_id);
	if ((ret=_iterate_circ_ref(&gtIter_ctl[1],pCt2,nam)) == 1) return 0;
	else if (ret < 0) return ret;

	match = 0;
	nu1 = pCt1->rb_used - ix1;
	nu2 = pCt2->rb_used - ix2;
	if (nm >= 0) {
		if (nu1 > nm) nu1 = nm;
		if (nu2 > nm) nu2 = nm;
	}
/*
printf("cl_comp_list:nu1=%d nu2=%d\n",nu1,nu2);
*/
	if (nu1>0 && nu2>0 && (!(cmp_opt & 0x01) || nu1==nu2)) {
		akxs_rb_read(pCt1,0);
		akxs_rb_read(pCt2,0);
		while (ix1-- > 0) {
			if (!(p1=(tdtINFO_PARM *)akxs_rb_read(pCt1,1))) break;
		}
		while (ix2-- > 0) {
			if (!(p2=(tdtINFO_PARM *)akxs_rb_read(pCt2,1))) break;
		}
		while (p1=(tdtINFO_PARM *)akxs_rb_read(pCt1,1)) {
			if (!(p2 = (tdtINFO_PARM *)akxs_rb_read(pCt2,1))) break;
			pAns = &Ans;
			if ((rc=cl_cmpt_comp_opt(&pAns,pOprtr,p1,p2,0,NULL,cmp_opt | DEF_ZOK_DATA)) < 0) {
/*
printf("cl_comp_list:rc=%d\n",rc);
*/
				Ans = rc;
				break;
			}
			else if (!Ans) {
/*
printf("cl_comp_list:Ans=%d\n",Ans);
*/
				break;
			}
			match++;
/*
printf("cl_comp_list:rc=%d Ans=%d match=%d\n",rc,Ans,match);
*/
			if (nm>0 && match>=nm) break;
		}
	}
	if (Ans && (!(cmp_opt & 0x01))) Ans = match;
	return Ans;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
static int _mk_comp_ans(ppWork,i1,pLay,attr)
char **ppWork;
int i1,attr;
MCAT *pLay;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int iRc,n,i,ix,ilay;
	long *layer;
	char wrk[30],*p,*pAns,*fmt;

	layer = (long *)pLay->mc_bufp;
	ilay = pLay->mc_ipos - 1;
	ix = layer[ilay];
	if (!ix && !ilay) {
		if (!(pAns=cl_tmp_const_malloc(sizeof(int)))) return ECL_MALLOC_ERROR;
		memcpy(pAns,&i1,sizeof(int));
		iRc = DEF_ZOK_BINA;
/*
printf("_mk_comp_ans: Exit iRc=%d i=%d\n",iRc,i);
*/
	}
	else {
		mcat.mc_ipos = 0;
		sprintf(wrk,"%d",i1);
		akxtmcats(&mcat,wrk);
		for (i=0;i<ilay;i++) {
			sprintf(wrk," %d",layer[i]);
			akxtmcats(&mcat,wrk);
		}
		sprintf(wrk," %d",layer[ilay]-1);
		akxtmcats(&mcat,wrk);
		pAns = mcat.mc_bufp;
		iRc = DEF_ZOK_CHAR;
	}
	*ppWork = pAns;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string1(pInfoParm0,pInfoParm,opt)
tdtINFO_PARM *pInfoParm0,*pInfoParm;
int opt;
{
	int iRc,len2,opt_type;
	char *pp,wrk[12];

	if (pInfoParm->pi_id==' ') {
		pp = wrk;
		if ((iRc=parm_to_char(pInfoParm,&pp,NULL)) >= 0) {
			len2 = iRc;
			opt_type = SET_TYPE_OPT(pInfoParm0->pi_code);
			iRc = akxs_in_mem_opt(pInfoParm0->pi_data,pInfoParm0->pi_dlen,pp,len2,opt|opt_type);
/*
printf("cl_in_string1: iRc=%d\n",iRc);
*/
			if (iRc > 0) {
				if (opt & D_COMP_FUN_IN) {
					/*pInfoParm0->pi_pos = pInfoParm0->pi_len + 1*/;
				}
				else {
					if (iRc < pInfoParm0->pi_hlen) pInfoParm0->pi_hlen = iRc;
					if (iRc > pInfoParm0->pi_pos)  pInfoParm0->pi_pos  = iRc;
				}
			}
		}
	}
	else iRc = ECL_SCRIPT_ERROR;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_string(ppWork,nparm,ppParm,opt)
char **ppWork;
tdtINFO_PARM **ppParm;
int nparm,opt;
{
	tdtINFO_PARM tInfoParm,*pInfoParm;
	int  i,len1,len2,iRc,pos[2],attr,pos_min,pos_max,lenm,i1,optw;
	char *pWork;
	char ww[64],*pp[2],*pp0,*p,c;
	int  rc,atr1,atr2,iAttr[3],result;
	ParList3 par3;

	pp[1] = ww + 32;
	if ((i1=cl_get_str_pos(nparm,ppParm,0,&par3,pos,"INSTRs")) < 0) return i1;
	pp[0] = par3.par;
	len1 = par3.parlen;
	lenm = par3.parlen2;
	if (i1 < nparm-1) {
		nparm = _get_nparm_opt(nparm,ppParm,&optw);
		opt |= (optw & D_COMP_OPT_IGN_CASE) | ((optw & D_COMP_OPT_IGN_HZ)<<4);
/*
printf("cl_in_string: i1=%d opt=%d nparm=%d\n",i1,opt,nparm);
*/
	}
/*
printf("cl_in_string: nparm=%d i1=%d opt=%08x pos=%d lenm=%d\n",nparm,i1,opt,pos[0],lenm);
*/
	pp0 = pp[0];
#if 0	/* 2020.12.29 */ /* pp0�������Ƃ��́A�r���ň�v�����ꍇ�A�S�ϊ������ʂɂȂ� */
	if (opt & 0x20) {
		if (!(p=cl_tmp_const_malloc(len1*4+1))) return ECL_MALLOC_ERROR;
		if ((len1=akxctozen(len1,pp0,p)) < 0) return -1;
		pp0 = p;
	}
	if (opt & 0x01) {
		if (!(p=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
		if ((len1=akxcuppern(p,pp0,len1)) < 0) return -1;
		pp0 = p;
	}
#endif
	pos_min = lenm + 1;
	pos_max = 0;
	memset(*ppWork,0,sizeof(int));
	cl_set_parm_char2(&tInfoParm,pp0,len1,ppParm[0]->pi_code);
	tInfoParm.pi_hlen = pos_min;
	tInfoParm.pi_pos  = pos_max;
/*	tInfoParm.pi_len = i1;	*/
	tInfoParm.pi_paux = (char *)cl_in_string1;
	iRc = cl_in_number_sub(ppWork,&tInfoParm,nparm-i1,ppParm+i1,opt);
/*
printf("cl_in_string: iRc=%d\n",iRc);
*/
	if (iRc>0 && iRc != 1) {
		pos_min = tInfoParm.pi_hlen;
		pos_max = tInfoParm.pi_pos;
/*
printf("cl_in_string: pos_min=%d pos_max=%d\n",pos_min,pos_max);
*/
		if (opt & D_COMP_FUN_IN) {
			pos_min = pos_max;
		}
		else {
			if (opt & D_COMP_FUN_REVERCE) pos_min = pos_max;
			else if (pos_min == lenm+1) pos_min = 0;
			if (!(pGlobTable->options[17] & 0x01) && pos_min) pos_min += pos[0] - 1;
		}
/*
printf("cl_in_string: pos_min=%d\n",pos_min);
*/
		pWork = *ppWork;
		memcpy(pWork,&pos_min,sizeof(int));
		iRc = DEF_ZOK_BINA;
	}
	else if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*	iRc > 0 : ��v�����ԍ�												*/
/*	    = 0 : ��v���Ȃ�����											*/
/*	    < 0 : �G���[													*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number1(pInfoParm0,pInfoParm,opt)
tdtINFO_PARM *pInfoParm0,*pInfoParm;
int opt;
{
	static char *msg="cl_in_number1:";
	int iRc,atr0,atr;
	long lValue0,lValue;
	double dValue0,dValue;
	MPA *ma0,maz,*ma;
	char id;

	iRc = 0;
	if (pInfoParm0->pi_id==' ' && pInfoParm->pi_id==' ') {
		if ((atr0=pInfoParm0->pi_attr) == DEF_ZOK_BINA) {
			memcpy((char *)&lValue0,pInfoParm0->pi_data,sizeof(long));
			if ((iRc=cl_get_parm_bin(pInfoParm,&lValue,msg)) >= 0) {
				if (lValue0 == lValue) iRc = 1;
			}
		}
		else if (atr0 == DEF_ZOK_FLOA) {
			memcpy((char *)&dValue0,pInfoParm0->pi_data,sizeof(double));
			if ((iRc=cl_get_parm_double(pInfoParm,&dValue,msg)) >= 0) {
				if (dValue0 == dValue) iRc = 1;
			}
		}
		else if (atr0 == DEF_ZOK_DECI) {
			ma0 = (MPA *)pInfoParm0->pi_data;
			ma = (MPA *)cl_get_tmpMPA(&maz);
			if ((iRc=cl_get_parm_dec(pInfoParm,ma,msg)) >= 0) {
				if (!m_cmp(ma0,ma)) iRc = 1;
			}
		}
		else iRc = ECL_SCRIPT_ERROR;
	/*	if (iRc > 0) pInfoParm0->pi_pos = pInfoParm0->pi_len + 1;	*/
	}
	else iRc = ECL_SCRIPT_ERROR;
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*																		*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number_sub(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtINFO_PARM *pInfoParm0,**ppParm;
int nparm,opt;
{
	int iRc,i,i1;
	int rc,max_layer;
	char id,**ppWork;
	tdtINFO_PARM *pInfoParm;
	int (*exfunc)();
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter;
	MCAT2 *layer;

	max_layer = -1;
	layer = akxs_layer_new(100,cl_tmp_const_malloc,NULL);
/*
printf("cl_in_number: Enter opt=%d pAns=[%s]\n",opt,*ppAns);
*/
	iRc = 0;
	exfunc = (int(*)())pInfoParm0->pi_paux;
	ppWork = ppAns;
	for (i=0;i<nparm;i++) {
		if (pInfoParm = ppParm[i]) {
#if 1
		  if ((rc=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm,max_layer)) < 0) {
		      iRc = rc;
		      break;
		  }
		  for (;;) {
			if ((rc=cl_iterate_info(&tIter_ctl)) < 0) {
				iRc = rc;
				break;
			}
			pIter = tIter_ctl.itc_pIter;
			if (!(pInfoParm=pIter->it_pInfo)) break;
			akxs_layer_set(layer,tIter_ctl.itc_layer,pIter->it_ix);
/*
printf("cl_in_number: layer=%d ix=%d\n",tIter_ctl.itc_layer,pIter->it_ix);
*/
#endif
			if (cl_check_data_id(pInfoParm,0x04) < 0) return ECL_SCRIPT_ERROR;	/* 'U'/'\0'*/
			if (!cl_is_null_parm(pInfoParm)) {
				i1 = i + 1;
				if ((id=pInfoParm->pi_id) == ' '){
				/*	pInfoParm0->pi_len = i;	*/
					iRc = exfunc(pInfoParm0,pInfoParm,opt);
/*
printf("cl_in_number: i1=%d iRc=%d\n",i1,iRc);
*/
					ppWork = NULL;
					if (iRc > 0) {
						iRc = DEF_ZOK_BINA;
						if (opt & D_COMP_FUN_IN) pInfoParm0->pi_pos = i1;
					}
				}
#if 0
				else if (id=='A' || id=='R')
					iRc = cl_in_number_array(ppAns,pInfoParm0,pInfoParm,opt);
				else if (id=='L' || id=='N')
					iRc = cl_in_number_list(ppAns,pInfoParm0,pInfoParm,opt);
#endif
				else 
					iRc = ECL_SCRIPT_ERROR;
				if (iRc) {
					if (iRc>0 && (opt & D_COMP_FUN_IN) && !(opt & D_COMP_OPT_NOT_SET)) {
#if 1
						iRc = _mk_comp_ans(ppAns,i1,layer,iRc);
#else
						iRc = _mk_comp_ans(ppAns,i1,ppWork,iRc);
#endif
/*
printf("cl_in_number: opt=%d i1=%d pAns=[%s]\n",opt,i1,*ppAns);
*/
					}
					if (opt & D_COMP_FUN_IN) break;
				}
			}
#if 1
		  }
/*
printf("cl_in_number: id=[%c](%02x) iRc=%d\n",id,id,iRc);
*/
		  if (iRc) break;
#endif
		}
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*	iRc > 0 : ��v�����ԍ�												*/
/*	    = 0 : ��v���Ȃ�����											*/
/*	    < 0 : �G���[													*/
/********1*********2*********3*********4*********5*********6*********7***/
int cl_in_number(ppAns,pInfoParm0,nparm,ppParm,opt)
char **ppAns;
tdtINFO_PARM *pInfoParm0,**ppParm;
int nparm,opt;
{
	tdtINFO_PARM tInfoParm;
	int iRc;

	memset(*ppAns,0,sizeof(int));
	tInfoParm = *pInfoParm0;
/*	tInfoParm.pi_len = 0;	*/
	tInfoParm.pi_paux = (char *)cl_in_number1;
	iRc = cl_in_number_sub(ppAns,&tInfoParm,nparm,ppParm,D_COMP_FUN_IN);
	if (!iRc) iRc = DEF_ZOK_BINA;
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _comp_rational(pInfoParm,pInfoParm1,pInfoParm2,ope)
tdtINFO_PARM *pInfoParm,*pInfoParm1,*pInfoParm2;
int ope;
{
	tdtINFO_PARM tInfoW,tInfo,*pInfo1,*pInfo2,*pInfo;
	char cOperator[2];
	int ret,sig;
	MPA *ma;

	if ((ope==D_FUC_MAX) || (ope==D_FUC_MIN)) strcpy(cOperator,"-");
	else if (ope == D_FUC_SUM) strcpy(cOperator,"+");
	else if (ope == D_FUC_PRODUCT) strcpy(cOperator,"*");
	else return -1;
	if ((ret=cl_cmpt_math_rational(&tInfoW,cOperator,pInfoParm1,pInfoParm2)) >= 0) {
		if ((ope==D_FUC_MAX) || (ope==D_FUC_MIN)) {
			if ((ret=cl_rational_to_real(&tInfo,&tInfoW)) < 0) return ret;
			ma = (MPA *)tInfo.pi_data;
			sig = ma->sign;
/*
printf("_comp_rational:1 sig=%d\n",sig);
*/
			if (ope == D_FUC_MIN) sig = 1 - sig;
/*
printf("_comp_rational:2 sig=%d\n",sig);
*/
			if (sig) pInfo = pInfoParm2;
			else pInfo = pInfoParm1;
			cl_gx_copy_info2(pInfoParm,pInfo);
		}
		else cl_gx_copy_info2(pInfoParm,&tInfoW);
	}
/*
printf("_comp_rational:Exit ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)
tdtINFO_PARM *pInfoParm,*pInfoParm1,*pInfoParm2;
int ope;
{
	int ret,rc,attr1,attr2,opt,len1,len2,attr,iUNSIG1,iUNSIG2,over_or_under;
	char *p1,*p2,copt;
	MPA *mpa1,*mpa2,ma1z,ma2z,*ma1,*ma2,*mpaW;
	double dVal1,dVal2;
	long lVal1,lVal2,lVal3,lma1z[NMPA_LONG_PRE1],lma2z[NMPA_LONG_PRE1],*Val1,*Val2;
	ulong ulVal1,ulVal2,ulVal3;
	tdtINFO_PARM tInfoParm1,tInfoParm2,*pInfoParm3;

DEBUGOUT_InfoParm(198,"cl_comp_info:1 ope=%d",pInfoParm1,ope,0);
DEBUGOUT_InfoParm(198,"cl_comp_info:2 ope=%d",pInfoParm2,ope,0);
/*
printf("cl_comp_info: pi_data=%08x ope=%d\n",pInfoParm->pi_data,ope);
*/
#if 1	/* 2025.3.26 */
	if ((pInfoParm1->pi_alen & D_AULN_RATIONAL) || (pInfoParm2->pi_alen & D_AULN_RATIONAL))
		return _comp_rational(pInfoParm,pInfoParm1,pInfoParm2,ope);
#endif
	iUNSIG1 = iUNSIG2 = ret = 0;
	attr1 = pInfoParm1->pi_attr;
	attr2 = pInfoParm2->pi_attr;
/*
printf("cl_comp_info:Enter attr1=%d attr2=%d\n",attr1,attr2);
*/
	if ((((attr1==DEF_ZOK_DATE && attr2==DEF_ZOK_DATE) ||
	      (attr1==DEF_ZOK_BULK && attr2==DEF_ZOK_BULK) ||
	      (attr1==DEF_ZOK_CHAR && attr2==DEF_ZOK_DATE) ||
	      (attr1==DEF_ZOK_DATE && attr2==DEF_ZOK_CHAR)) && (ope==D_FUC_MAX || ope==D_FUC_MIN)) ||
	    (attr1==DEF_ZOK_CHAR && attr2==DEF_ZOK_CHAR)) {
		opt = 0;
		if (attr1==DEF_ZOK_DATE || attr2==DEF_ZOK_DATE) {
			if (attr1==DEF_ZOK_CHAR || attr2==DEF_ZOK_CHAR) {
				if (attr1 == DEF_ZOK_CHAR) pInfoParm3 = pInfoParm1;
				else pInfoParm3 = pInfoParm2;
				if ((ret=cl_func_to_date(&tInfoParm1,1,&pInfoParm3)) < 0) {
							/*%s: ���t������[%s]������Ă��܂��Bret=%d */
					ERROROUT3(FORMAT(622),"cl_comp_info",pInfoParm3->pi_data,ret);
					return ECL_SCRIPT_ERROR;
				}
				if (attr1 == DEF_ZOK_CHAR) {
					pInfoParm1 = &tInfoParm1;
					attr1 = pInfoParm1->pi_attr;
				}
				else {
					pInfoParm2 = &tInfoParm1;
					attr2 = pInfoParm2->pi_attr;
				}
			}
			if (attr1 == DEF_ZOK_DATE) {
				mpa1 = (MPA *)pInfoParm1->pi_data;
				p1   = mpa1->num;
				len1 = mpa1->len;
			}
			if (attr2 == DEF_ZOK_DATE) {
				mpa2 = (MPA *)pInfoParm2->pi_data;
				p2   = mpa2->num;
				len2 = mpa2->len;
			}
		}
		else {
			p1   = pInfoParm1->pi_data;
			len1 = pInfoParm1->pi_dlen;
			p2   = pInfoParm2->pi_data;
			len2 = pInfoParm2->pi_dlen;
			if (attr1 == DEF_ZOK_CHAR) {
				if (ope==D_FUC_SUM || ope==D_FUC_PRODUCT) {
/*
printf("cl_comp_info: ope=%d\n",ope);
*/
					rc = cl_conv_const_n_str(&tInfoParm1,p1,len1);
					if (!rc) rc = cl_conv_const_n_str(&tInfoParm2,p2,len2);
					if (!rc) rc = cl_comp_info(pInfoParm,&tInfoParm1,&tInfoParm2,ope);
					return rc;
				}
				else opt = 0x4000;
			}
		}
/*
printf("cl_comp_info: len1=%d p1=%08x\n",len1,p1);
*/
		rc = _memcmplen(p1,len1,p2,len2,opt);
		if (((ope==D_FUC_MAX) && (rc<0)) || ((ope==D_FUC_MIN) && (rc>0)))
			pInfoParm1 = pInfoParm2;
		*pInfoParm = *pInfoParm1;
	}
	else if (attr1>=1 && attr1<=4 && attr2>=1 && attr2<=4) {
	/*	rc = 0;	*/
		/* 2023.6.24 */
		Val1 = cl_get_tmpMPA_pre1(lma1z);
		Val2 = cl_get_tmpMPA_pre1(lma2z);
		if ((attr1=cl_conv_upper2(NULL,NULL,Val1,Val2,pInfoParm1,pInfoParm2,0)) < 0) return attr1;
		attr2 = attr1;
		mpa1 = (MPA *)Val1;
		mpa2 = (MPA *)Val2;
	/*	if ((ret=rc) > 0) ret = ECL_SCRIPT_ERROR;
		else if (!ret) {	*/
			if (attr1 == DEF_ZOK_BINA) {
				/* 2023.6.24 */
				ulVal1 = lVal1 = Val1[0];
				ulVal2 = lVal2 = Val2[0];
				iUNSIG1 = Val1[1];
				iUNSIG2 = Val2[1];
				over_or_under = 0;
				if (iUNSIG1 | iUNSIG2) {
					if (ope==D_FUC_SUM || ope==D_FUC_PRODUCT) {
						if (ope == D_FUC_SUM) {
							ulVal3 = ulVal1 + ulVal2;
							ulVal1 = cl_chk_over_flow_ulong_add(ulVal3,ulVal1,ulVal2,"Add",&over_or_under,mpa1);
						}
						else {
							ulVal3 = ulVal1 * ulVal2;
							ulVal1 = cl_chk_over_flow_ulong_mult(ulVal3,ulVal1,ulVal2,"Mult",&over_or_under,mpa1);
						}
						if (over_or_under) {
							/* 2023.6.11 */
							cl_set_parm_mpa2(pInfoParm,mpa1,'V');
							return 0;
						}
					}
					else if (ope == D_FUC_MAX)
						ulVal1 = X_MAX(ulVal1,ulVal2);
					else
						ulVal1 = X_MIN(ulVal1,ulVal2);
					lVal1 = ulVal1;
				}
				else {
					if (ope==D_FUC_SUM || ope==D_FUC_PRODUCT) {
						if (ope == D_FUC_SUM) {
							lVal3 = lVal1 + lVal2;
							lVal1 = cl_chk_over_flow_long_add(lVal3,lVal1,lVal2,"Add",&over_or_under,mpa1);
						}
						else if (ope == D_FUC_PRODUCT) {
							lVal3 = lVal1 * lVal2;
							lVal1 = cl_chk_over_flow_long_mult(lVal3,lVal1,lVal2,"Mult",&over_or_under,mpa1);
						}
						if (over_or_under) {
/*
printf("cl_comp_info: over_or_under=%d\n",over_or_under);
*/
							cl_set_parm_mpa2(pInfoParm,mpa1,'P');
DEBUGOUT_InfoParm(198,"cl_comp_info:",pInfoParm,0,0);
							return 0;
						}
					}
					else {
						rc = lVal1 - lVal2;
						if (ope == D_FUC_MIN) rc = -rc;
						if (rc < 0) lVal1 = lVal2;
					}
				}
				cl_set_parm_long(pInfoParm,lVal1);
				if (iUNSIG1 | iUNSIG2) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
			}
			else if (attr1 == DEF_ZOK_FLOA) {
#if 1	/* 2023.6.24 */
				memcpy(&dVal1,Val1,sizeof(double));
				memcpy(&dVal2,Val2,sizeof(double));
#endif
				if (ope == D_FUC_SUM) dVal1 += dVal2;
				else if (ope == D_FUC_PRODUCT) dVal1 *= dVal2;
				else {
					if (dVal1 < dVal2) rc = -1;
					else rc = 1;
					if (ope == D_FUC_MIN) rc = -rc;
					if (rc < 0) dVal1 = dVal2;
				}
				cl_set_parm_double(pInfoParm,dVal1);
			}
			else if (attr1 == DEF_ZOK_DECI) {
				if (ope == D_FUC_SUM) rc = m_add1(mpa1,mpa2);
				else if (ope == D_FUC_PRODUCT) rc = m_mul1(mpa1,mpa2);
				else {
					rc = m_cmp(mpa1,mpa2);
					if (ope == D_FUC_MIN) rc = -rc;
					if (rc < 0) mpa1 = mpa2;
				}
#if 1	/* 2025.2.28 */
/*
printf("cl_comp_info: pInfoParm->pi_attr=%d\n",pInfoParm->pi_attr);
*/
				if (pInfoParm->pi_attr == DEF_ZOK_DECI) copt = 'V';
				else copt = ' ';
				cl_set_parm_mpa2(pInfoParm,mpa1,copt);
#else
				/* 2023.6.11 */
				cl_set_parm_mpa2(pInfoParm,mpa1,'V');
#endif
			}
	/*	}	*/
	}
	else {
	/*	if (attr1<1 || attr1>6) attr = attr1;
		if (attr2<1 || attr2>6) attr = attr2;	*/
				/* �p�����[�^�̌^(attr1=%d attr2=%d)�������Ă��܂���B*/
		ERROROUT3(FORMAT(242),"cl_comp_info",attr1,attr2);
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_agg_sub(pInfoParmW,nparm,ppParm,ope,pInfoParm0)
tdtINFO_PARM *pInfoParmW,**ppParm,*pInfoParm0;
int nparm,ope;
{
	tdtINFO_PARM *pInfoParm,*pInfoParm1,*pInfoParm2,tInfoParm,tInfoParm1,***pTBL1;
	tdtArrayIndex tIndex1;
	char id,wk[2],*pWork;
	int  i,k,ret,iParm[4],ix1,nm1,len1,attr,attr1,sizeofnmp,nrat;
	long lSum,lma1z[NMPA_LONG_PRE1*2],lma2z[NMPA_LONG_PRE1*2];
	tdtRB_CTL *pCt;
	int max_layer;
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter;
	MPA *mpa1,*mpa2;

	max_layer = -1;

/*	pGlobTable->error = 0;	del 2023.8.27 �����ł̓N���A���Ȃ� */
	ret = 0;
	lSum = pInfoParmW->pi_len;
/*
printf("cl_func_agg_sub:Enter ope=%d nparm=%d lSum=%d\n",ope,nparm,lSum);
*/
	nrat = 1;
	pInfoParm = &tInfoParm;
#if 1	/* 2023.6.11 */
	sizeofnmp = sizeofMPA();
#if 1	/* 2025.3.27 */
	mpa1 = (MPA *)cl_get_tmpMPA3(lma1z,NMPA_LONG_PRE1,2);
	mpa2 = (MPA *)cl_get_tmpMPA3(lma2z,NMPA_LONG_PRE1,2);
#else
	mpa1 = (MPA *)cl_get_tmpMPA_pre1(lma1z);
	mpa2 = (MPA *)cl_get_tmpMPA_pre1(lma2z);
#endif
	cl_set_parm_mpa2(pInfoParm,mpa1,'P');
#endif
/*
	if (pInfoParm0) pInfoParm1 = pInfoParm0;
	else {	*/
		pInfoParm1 = &tInfoParm1;
		cl_parm_set0(pInfoParm1);
/*	}	*/
	for (i=0;i<nparm;i++) {
		pInfoParm2 = ppParm[i];
		if (cl_is_undef_parm(pInfoParm2) || cl_is_null_parm(pInfoParm2)) continue;

		if ((ret=cl_iterate_info_init(&tIter_ctl,NULL,pInfoParm2,max_layer)) < 0) break;
		for (;;) {
			if ((ret=cl_iterate_info(&tIter_ctl)) < 0) break;
			pIter = tIter_ctl.itc_pIter;
			if (!(pInfoParm2=pIter->it_pInfo)) break;
/*
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:pInfoParm1",pInfoParm1,0,0);
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:pInfoParm2",pInfoParm2,0,0);
*/
			if (cl_is_undef_parm(pInfoParm1) || cl_is_null_parm(pInfoParm1)) {
				cl_gx_copy_info2(pInfoParm1,pInfoParm2);
				lSum++;
			}
			else if (!cl_is_undef_parm(pInfoParm2) && !cl_is_null_parm(pInfoParm2)) {
				attr1 = pInfoParm1->pi_attr;
				if ((ret=cl_comp_info(pInfoParm,pInfoParm1,pInfoParm2,ope)) < 0) break;
#if 1	/* 2023.6.11 */
/*
printf("cl_func_agg_sub: pInfoParm->pi_attr=%d attr1=%d\n",pInfoParm->pi_attr,attr1);
*/
				if (pInfoParm->pi_attr==DEF_ZOK_DECI) {
					if (pInfoParm->pi_alen & D_AULN_RATIONAL) nrat = 2;
					if (attr1 == DEF_ZOK_BINA) {
						memcpy(mpa2,pInfoParm->pi_data,sizeofnmp*nrat);
						cl_set_parm_mpa2(pInfoParm1,mpa2,'P');
						cl_set_parm_mpa2(pInfoParm,mpa1,'P');
					}
					else {
						memcpy(mpa2,mpa1,sizeofnmp*nrat);
						pInfoParm1->pi_data = (char *)mpa2;
					}
				}
				else cl_gx_copy_info2(pInfoParm1,pInfoParm);
#else
				cl_gx_copy_info2(pInfoParm1,pInfoParm);
#endif
				lSum++;
			}
		}
		if (ret < 0) break;
	}
/*
printf("cl_func_agg_sub: lSum=%d ret=%d\n",lSum,ret);
*/
	if (ret >= 0) {
		cl_gx_copy_info(pInfoParmW, pInfoParm1);
		pInfoParmW->pi_scale &= ~D_DATA_MALLOC;
		pInfoParmW->pi_len = lSum;
		attr = pInfoParmW->pi_attr;
		len1 = pInfoParmW->pi_dlen;
/*
printf("cl_func_agg_sub: attr=%d len1=%d\n",attr,len1);
*/
		if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK || attr==DEF_ZOK_DATE || attr==DEF_ZOK_DECI) {
			if (attr == DEF_ZOK_DECI) len1 *= nrat;
			if (!(pWork=cl_tmp_const_malloc(len1+1))) return ECL_MALLOC_ERROR;
/*
printf("cl_func_agg_sub: pWork=%08x\n",pWork);
*/
			memcpy(pWork,pInfoParm1->pi_data,len1);
			if (attr == DEF_ZOK_CHAR) *(pWork+len1) = '\0';
			pInfoParmW->pi_data = pWork;
		}
		ret = 0;
	}
/*
printf("cl_func_agg_sub:Exit lSum=%d ret=%d\n",lSum,ret);
*/
DEBUGOUT_InfoParm(198,"cl_func_agg_sub:Exit ret=%d",pInfoParmW,ret,0);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_agg(pInfoParmW0,nparm,ppParm,ope0)
tdtINFO_PARM *pInfoParmW0,**ppParm;
int nparm,ope0;
{
	int ret,ope,attr;
	long lSum,lVal1,lVal2;
	double dVal1,dVal2;
	MPA ma1z,ma2z,*mpa1,*ma1,*ma2;
	tdtINFO_PARM *pInfoParmW,tInfo,tInfoW;
/*
printf("cl_func_agg:Enter pInfoParmW=%08x nparm=%d ope0=%08x\n",pInfoParmW,nparm,ope0);
*/
	ret = 0;
	pInfoParmW = pInfoParmW0;
	if ((ope=ope0) == D_FUC_AVG) ope = D_FUC_SUM;
	cl_null_data(pInfoParmW);
	pInfoParmW->pi_len = 0;
	ret = cl_func_agg_sub(pInfoParmW,nparm,ppParm,ope,NULL);
	if (!ret) {
DEBUGOUT_InfoParm(198,"cl_func_agg: ret=%d",pInfoParmW,ret,0);
		if (cl_is_undef_parm(pInfoParmW0) || cl_is_null_parm(pInfoParmW0)) {
			ERROROUT1(FORMAT(372),"cl_func_agg");	/* %s: �f�[�^����0�ł��B*/
		/*	if (ope0 == D_FUC_SUM) cl_set_parm_long(pInfoParmW,0);
			else */cl_null_data(pInfoParmW);
		}
		else if (ope0 == D_FUC_AVG) {
			lSum = pInfoParmW->pi_len;
			attr = pInfoParmW->pi_attr;
#if 1	/* 2025.3.26 */
			if (pInfoParmW->pi_alen & D_AULN_RATIONAL) {
				cl_set_parm_long(&tInfo,lSum);
				if ((ret=cl_cmpt_math_rational(&tInfoW,"/",pInfoParmW,&tInfo)) >= 0) {
					cl_gx_copy_info2(pInfoParmW,&tInfoW);
					ret = pInfoParmW0->pi_attr;
				}
				return ret;
			}
#endif
			if (attr == DEF_ZOK_FLOA) {
				cl_get_parm_double(pInfoParmW,&dVal1,"1");
				cl_set_parm_double(pInfoParmW,dVal1/lSum);
			}
			else if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_DECI) {
				mpa1 = (MPA *)cl_get_tmpMPA(&ma1z);
				if (!(ret=cl_get_parm_dec(pInfoParmW,mpa1,"1"))) {
					ma2 = (MPA *)cl_get_tmpMPA(&ma2z);
					m_l2mpa(lSum,ma2);
					m_div1(mpa1,ma2);
					cl_set_parm_mpa(pInfoParmW,mpa1);
				}
				else if (ret > 0) ret = ECL_SCRIPT_ERROR;
			}
			else ret = -1;
		}
	}
	if (!ret) ret = pInfoParmW0->pi_attr;
	return ret;
}
