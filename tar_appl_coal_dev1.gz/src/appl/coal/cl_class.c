static char sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	�����ړI	�F	�N���X����												*
*																			*
*	�����T�v	�F															*
*																			*
*****************************************************************************/
#include "colmn.h"

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
int cl_gx_new(pInfoParmW,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm2;
{
	ScrPrCT *pScCT;
	ProcCT  *cur_procct;
	Leaf    *leaf;
	char *name,id;

	pGlobTable->options[7] |= 0x02;
	if (cl_check_data_id(pInfoParm2,~0x80)) return ECL_SCRIPT_ERROR;
	leaf = NULL;
	id = pInfoParm2->pi_id;
	name = pInfoParm2->pi_data;

DEBUGOUTL2(120,"cl_gx_new: id=[%c] name=[%s]",id,name);

	if (id == 'C') {
		if (!(leaf=(Leaf *)pInfoParm2->pi_pos)) {
			/* %s: �N���X[%s]�ւ̃p�X������܂��� */
			ERROROUT2(FORMAT(546),"cl_gx_new",name);
			return ECL_SCRIPT_ERROR;
		 }
	}
	else if (id == ' ') {
		if (pScCT = cl_search_src_ct()) {
			cur_procct = cl_search_proc_ct();
			if (!(leaf=cl_search_class_leaf_and_inner(pScCT,cur_procct,name,NULL))) {
				/* %s: �N���X[%s]�͖���`�ł��B */
				ERROROUT2(FORMAT(548),"cl_gx_new",name);
				return ECL_SCRIPT_ERROR;
			}
		}
	}
	else {
		ERROROUT1("cl_gx_new: [%s]��CLASS�ł͂���܂���B",name);
		return ECL_SCRIPT_ERROR;
	}

DEBUGOUTL2(120,"cl_gx_new: name=[%s] leaf=%08x",name,leaf);

	if (leaf) {
		*pInfoParmW = *pInfoParm2;
		pInfoParmW->pi_id = D_DATA_ID_INSTANCE;
		pInfoParmW->pi_pos = (long)leaf;
		pInfoParmW->pi_data = clmemdup(name,pInfoParm2->pi_dlen,D_OPT_ALC_TMP);
		pInfoParmW->pi_paux = (char *)leaf;
		pInfoParmW->pi_scale = D_DATA_ORG_PROC;
	}
	else return -1;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _count_parm(buf,buf_len)
char *buf;
int buf_len;
{
	SSPL_S ssp;
	char c;
	int nm_flg,n,k_level,len;

	if (!buf) return -1;
/*
printf("_count_parm: buf=[%s] buf_len=%d\n",buf,buf_len);
*/
	n = k_level = nm_flg = 0;
	memset(&ssp,0,sizeof(SSPL_S));
	while ((len=akxtgwnsl(buf,buf_len,&ssp,"(),",0x01)) > 0) {
		if (ssp.attr[0] < 10) {
			if (k_level > 0) nm_flg = 1;
		}
		else {
			c = *ssp.wd;
/*
printf("_count_parm: sp=%d c=%c\n",ssp.sp,c);
*/
			if (c == ',') {
				if (k_level == 1) {
					n++;
					nm_flg = 0;
				}
			}
			else if (c == '(') k_level++;
			else {
				if (k_level > 0) {
					k_level--;
					if (!k_level && nm_flg) n++;
				}
				else return -3;
			}
		}
	}
	if (n>=0 && k_level) return -2;
/*
printf("_count_parm: n=%d\n",n);
*/
	return n;
}

/****************************************/
/*										*/
/****************************************/
static int _count_parm_attr(buf,buf_len,nparm,ppParm)
char *buf;
int buf_len,nparm;
tdtINFO_PARM *ppParm[];
{
	static char *sep=" \t,()='";
	static char *attr_sep=" \t()[],'=";
	tdtINFO_PARM *pParm;
	SSPL_S ssp;
	char c,cb,wrk[40];
	int len,ret,rc,disp,i,iParm[8],k;

	if (!buf) return -1;
/*
printf("_count_parm_attr:Enter nparm=%d buf_len=%d buf=[%s]\n",nparm,buf_len,buf);
*/
	i = ret = disp = k = 0;
	memset(&ssp,0,sizeof(SSPL_S));
	cb = '\0';
	for (;;) {
/*
printf("_count_parm_attr: disp=%d i=%d k=%d cb=[%c]\n",disp,i,k,cb);
*/
		if (disp==1 || disp==4)
			len = akxtpknsl(buf,buf_len,&ssp,sep,0x01);
		else
			len = akxtgwnsl(buf,buf_len,&ssp,sep,0x01);
/*
memnzcpy(wrk,ssp.wd,len,sizeof(wrk));
printf("_count_parm_attr: len=%d ssp.wd=[%s]\n",len,wrk);
*/
		if (len <= 0) break;
		c = *ssp.wd;
		if (!disp) {
			if (c == '(') disp = 1;
		}
		else if (disp == 1) {
			if (c == ')') {
				if (cb == ',') return -1;
				i += k;
				break;
			}
			else if (c == ',') return -1;
			else {
				if (rc=cl_get_def_attr_SSP_opt(buf,buf_len,&ssp,attr_sep,iParm,0x05,NULL,NULL)) return rc;
/*
printf("_count_parm_attr: iParm[0]=%d\n",iParm[0]);
*/
				if (iParm[0]) {
					if (i < nparm) {
						pParm = ppParm[i];
						if (pParm->pi_id!=' ' || iParm[0]!=pParm->pi_attr) break;
					}
					disp = 2;
				}
				else {
					disp = 3;
					k = 1;
				}
			}
		}
		else if (disp == 2) {
			disp = 3;
			k = 1;
		}
		else if (disp == 3) {
			memnzcpy(wrk,ssp.wd,len,sizeof(wrk));
			if (!stricmp(wrk,"AS")) disp = 4;
			else if (c == ',') {
				if (cb == ',') return -1;
				disp = 1;
				i++;
				k = 1;
			}
			else if (c == ')') {
				if (cb == ',') return -1;
				i += k;
				break;
			}
		}
		else if (disp == 4) {
			if (rc=cl_get_def_attr_SSP_opt(buf,buf_len,&ssp,attr_sep,iParm,0x09,NULL,NULL)) return rc;
/*
printf("_count_parm_attr: iParm[0]=%d\n",iParm[0]);
*/
			if (iParm[0]) {
				if (i < nparm) {
					pParm = ppParm[i];
					if (pParm->pi_id!=' ' || iParm[0]!=pParm->pi_attr) break;
				}
				disp = 5;
			}
			else return -4;
		}
		else if (disp == 5) {
			if (c == ',') {
				if (cb == ',') return -1;
				disp = 1;
				i++;
				k = 1;
			}
			else if (c == ')') {
				if (cb == ',') return -1;
				i += k;
				break;
			}
		}
		if (i > nparm) break;
		cb = c;
/*
printf("_count_parm_attr: ssp.sp=%d\n",ssp.sp);
*/
	}
/*
printf("_count_parm_attr:Exit i=%d\n",i);
*/
	return i;
}

/****************************************/
/*										*/
/****************************************/
static Leaf *_find_method(topleaf,name,nparm,ppParm)
Leaf *topleaf;
char *name;
int  nparm;
tdtINFO_PARM *ppParm[];
{
	int rc,cno,len1,len2,len,ix,opt;
	Leaf *wkleaf;
	cmdInfo *cmd;
	parmList **prmp;

DEBUGOUTL3(120,"_find_method: topleaf=%08x name=[%s] nparm=%d",topleaf,name,nparm);

	if (!topleaf || !name) return NULL;
	opt = 0;
	if (pGlobTable->options[7] & 0x04) opt = AKX_ARGV_USE_ICMP;
	wkleaf = topleaf->leftleaf;
	while (wkleaf) {
		cmd = &wkleaf->cmd;
		cno = cmd->cid;
		prmp = cmd->prmp;

DEBUGOUTL2(120,"_find_method: prp=[%s] prmnum=%d",prmp[0]->prp,cmd->prmnum);

		if ((cno==C_FUNCTION || cno==C_CLASS) && !akxs_opt_strcmp(prmp[0]->prp,name,opt)) {
			if (nparm < 0) break;
			else if (cmd->prmnum >= 2) {
				if (_count_parm_attr(prmp[1]->prp,prmp[1]->prmlen,nparm,ppParm)==nparm) break;
			}
			else if (!nparm) break;
		}
		wkleaf = wkleaf->rightleaf;
	}
	return wkleaf;
}

/****************************************/
/*										*/
/****************************************/
static Leaf *_find_method_and_super(topleaf,name,nparm,ppParm,is_const,ppname)
Leaf *topleaf;
char *name;
int  nparm;
tdtINFO_PARM *ppParm[];
int is_const;
char **ppname;
{
	cmdInfo *cmd;
	tdtRB_CHAIN *pRb;
	Leaf *wkleaf;
	char *pcnam,**ppcnam;

	if (ppname) *ppname = NULL;
	cmd = &(topleaf->cmd);
	wkleaf = _find_method(topleaf,name,nparm,ppParm);

DEBUGOUTL2(120,"_find_method_and_super: wkleaf=%08x cmd->sub_cid=%08x",wkleaf,cmd->sub_cid);

	if (!wkleaf && (cmd->sub_cid & CS_EXTENDS)) {
		pRb = (tdtRB_CHAIN *)cmd->prmp[1]->bxobj;

DEBUGOUTL1(120,"_find_method_and_super: pRb=%08x",pRb);

		while (pRb) {
			if (is_const) {
				ppcnam = (char **)(pRb+1);
				pcnam = *ppcnam;
			}
			else {
				pcnam = name;
			}
			if (ppname) *ppname = pcnam;

DEBUGOUTL1(120,"_find_method_and_super: cnam=[%s]",pcnam);

			if (pRb->rbc_buf) {
				if(wkleaf = _find_method(pRb->rbc_buf,pcnam,nparm,ppParm)) break;
				pRb = pRb->rbc_next;
			}
			else break;
		}
	}
	return wkleaf;
}

/****************************************/
/*										*/
/****************************************/
static char *mk_method_path(class_nam,method_nam)
char *class_nam,*method_nam;
{
	char *p,*pp;
	int lenc,lenm;

DEBUGOUTL2(120,"mk_method_path:Enter: class_nam=[%s] method_nam=[%s]",nval1(class_nam),nval1(method_nam));

	if (!class_nam || !method_nam) return NULL;
	lenc = strlen(class_nam);
	lenm = strlen(method_nam);
	if (pp = p = Malloc(lenc+lenm+7)) {
		strcpy(p,"*C:");
		p += 3;
		memcpy(p,class_nam,lenc);
		p += lenc;
		*p++ = '.';
		strcpy(p,"F:");
		p += 2;
		memzcpy(p,method_nam,lenm);
	}
	return pp;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_new(pInfoParmW,nparm,ppParm)
tdtINFO_PARM *pInfoParmW;
int  nparm;
tdtINFO_PARM **ppParm;
{
	int rc,cno,len1,len2,len,ix,iEXTENDS;
	Leaf *topleaf,*leaf,*wkleaf;
	char *name,*p,*p0,id,*pd,*pmethod_nam;
	ScrPrCT *scrprct;
	ProcCT  *cur_procct,*procct,*wkproc;
	tdtINFO_PARM tInfoParmW,*pInfoParm,*pInfo;
	parmList **prmp;
	cmdInfo *cmd;
	tdtRB_CHAIN *pRb;
/*
printf("cl_func_new:Enter nparm=%d\n",nparm);
*/
	if (rc=cl_gx_new(pInfoParmW,ppParm[0])) return rc;
	/* �N���X�ϐ��̒�`�����s���� */
	topleaf = (Leaf *)pInfoParmW->pi_pos;
	name = pInfoParmW->pi_data;
	cur_procct = cl_search_proc_ct();

DEBUGOUTL3(120,"cl_func_new: name=[%s]�N���X�ϐ��̒�`�����s���� cur_procct=%08x topleaf=%08x",name,cur_procct,topleaf);

	memset(&tInfoParmW,0,sizeof(tdtINFO_PARM));
	/* �����Ő�������procct�́Aproc���s��Ƀ����N����͊O�����AFree()���Ȃ��悤�ɂ��� */
	if (rc=cl_exec_func_setup_proc(name,&tInfoParmW,0,NULL,topleaf,NULL,D_PFLAG_NO_FREE,NULL)) return rc;
	procct = cl_search_proc_ct();
	procct->pr_pFlag |= D_PFLAG_DEF_CLASS;

DEBUGOUTL2(120,"cl_func_new: procct=%08x procct->pha_vnam=%08x",procct,procct->pha_vnam);

	iEXTENDS = 0;
	cmd = &(topleaf->cmd);
	if (cmd->sub_cid & CS_EXTENDS) {
		iEXTENDS = 1;

DEBUGOUTL(120,"cl_func_new: �p������");

		if (!(pRb=(tdtRB_CHAIN *)cmd->prmp[1]->bxobj)) {
			if (!(pRb=(tdtRB_CHAIN *)cl_leaf_malloc(sizeof(tdtRB_CHAIN)+sizeof(char *)))) return ECL_MALLOC_ERROR;
			memset(pRb,0,sizeof(tdtRB_CHAIN)+sizeof(char *));
			cmd->prmp[1]->bxobj = (GXObject *)pRb;
		}
		if (rc=cl_exec_super_class(cur_procct,procct,pRb,cmd->parl->par,cmd->parl->parlen)) return rc;
		procct = cl_search_proc_ct();
	}
	if (rc=cl_exec_func_execute(cur_procct)) return rc;
	else {
/*
printf("cl_func_new: <--cl_exec_func_execute pGlobTable->error=%d\n",pGlobTable->error);
*/
		if (pGlobTable->error < 0) return pGlobTable->error;
	}
DEBUGOUTL2(160,"cl_func_new: instance procct=%08x procct->pha_vnam=%08x",procct,procct->pha_vnam);
	pInfoParmW->pi_len = (long)procct;
	/* �������g��"My"�Ƃ��ēo�^���� */
	if ((ix=cl_gx_chk_vnam_info('s',procct->pha_vnam,"My",2,&pInfoParm)) <= 0) {
		/* %s: %s�̃G���g���p�̋󂫂�����܂���Brc=%d */
		ERROROUT3(FORMAT(502),"cl_func_new","My",ix);
		return ECL_SCRIPT_ERROR;
	}
/*	pInfoParm = cl_get_var_ent(procct->pTBL_vnam,ix);	*/
	if (cl_gx_rep_info_set_ign(pInfoParm,pInfoParmW,1)) return -1;
	if (p=pInfoParm->pi_data) Free(p);
	pInfoParm->pi_data = Strdup("My");
	pInfoParm->pi_dlen = 2;
	pInfoParm->pi_scale &= ~(D_DATA_ORG_PROC | D_DATA_CLEAR_PROC);
	pInfoParm->pi_scale |= D_DATA_MALLOC/* | D_DATA_COPIED_PROC*/;

	/* �����̐��Ƒ����������R���X�g���N�^���T�[�`���� */
	nparm--;

DEBUGOUTL2(120,"cl_func_new: name=[%s] npamr=%d �����̐��Ƒ����������R���X�g���N�^���T�[�`����",name,nparm);

	wkleaf = _find_method_and_super(topleaf,name,nparm,&ppParm[1],1,&pmethod_nam);
	if (wkleaf) {
		/* �R���X�g���N�^�����s���邽�߂ɁA�c���Ă������N���X�ϐ��pprocct�𕜌����� */

DEBUGOUTL2(120,"cl_func_new: �R���X�g���N�^�����s���邽�߂ɁA�c���Ă������N���X[%s]�ϐ��pprocct(%08x)�𕜌�����",name,procct);

		if (rc=cl_exec_func_setup_proc(name,NULL,0,NULL,NULL,NULL,0,procct)) return rc;
		procct = cl_search_proc_ct();
DEBUGOUTL1(160,"cl_func_new: restored procct=%08x",procct);
		len1 = pInfoParmW->pi_dlen;
		if (!(p0 = p = cl_tmp_const_malloc(len1*2+2))) return ECL_MALLOC_ERROR;
		memcpy(p,name,len1);
		p += len1;
		*p++ = '.';
		memzcpy(p,name,len1);
		/* �R���X�g���N�^�����s���� */

DEBUGOUTL1(120,"cl_func_new: p0=[%s]�R���X�g���N�^�pproc�𐶐�����",p0);

		if (rc=cl_exec_func_setup_proc(p0,&tInfoParmW,nparm,&ppParm[1],wkleaf,NULL,0,NULL)) return rc;

DEBUGOUTL1(120,"cl_func_new: �R���X�g���N�^�����s���� procct=%08x",procct);

		wkproc = cl_search_proc_ct();
		wkproc->pr_pFlag |= D_PFLAG_CONSTRUCT;	/* �R���X�g���N�^��return���Ȃ��Ă�end_proc��
												���[�j���O���o���Ȃ��悤�ɂ��邽�� */
/*
printf("cl_func_new: wkproc=%08x name[%s]\n",wkproc,wkproc->ProcNM);
*/
		if (iEXTENDS && pmethod_nam) {
			wkproc->ProcPath = mk_method_path(name,pmethod_nam);
/*
printf("cl_func_new: wkproc->ProcPath=[%s]\n",wkproc->ProcPath);
*/
		}
		rc = cl_exec_func_execute(procct);
/*
printf("cl_func_new:cl_exec_func_execute rc=%d\n",rc);
*/
		if (!rc && ((id=tInfoParmW.pi_id)=='F' || id=='M') && tInfoParmW.pi_pos) {	/* �R���X�g���N�^�̃��^�[���l */
			pInfoParmW->pi_id = 'M';
			pInfoParmW->pi_pos = tInfoParmW.pi_pos;
			len2 = tInfoParmW.pi_dlen;
			if (!strncmp(pd=tInfoParmW.pi_data,"My.",3)) {
				pd += 3;
				len2 -= 3;
			}
			len = len1 + len2 + 1;
			if (!(pInfoParmW->pi_data=p= cl_tmp_const_malloc(len+1))) return ECL_MALLOC_ERROR;
			memcpy(p,name,len1);
			p += len1;
			*p++ = '.';
			memzcpy(p,pd,len2);
			pInfoParmW->pi_dlen = len;
/*
printf("cl_func_new: pInfoParmW->pi_data=[%s] len=%d\n",pInfoParmW->pi_data,len);
*/
DEBUGOUT_InfoParm(120,"cl_func_new:�R���X�g���N�^�̃��^�[���l:",pInfoParmW,0,0);
		}
		cl_er_lk_proc_ct();
		Free(procct->ProcNM);
		Free(procct);
	}
/*
printf("cl_func_new: pInfoParmW=%08x pi_scale=%02x\n",pInfoParmW,pInfoParmW->pi_scale);
*/
	/* 2020.12.2 �R���X�g���N�^�́A�Ȃ��Ă��悢 */
/*
printf("cl_func_new:Exit rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_instance_method(pInfoParmW,pInfoParm1,pInfoParm2,optW,name,len2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
char *name;
int len2;
{
	int rc,cno,len1,iParmNo,len,iFIND_METHOD;
	Leaf *topleaf,*leaf,*wkleaf;
	ScrPrCT *scrprct;
	ProcCT  *cur_procct,*procct,*nodeleaf;
	tdtINFO_PARM tInfoParmW,*pInfoParm;
	parmList **prmp;
	cmdInfo *cmd;
	char *p,*p1,buf[16],id,*pmethod_nam;

DEBUGOUTL2(160,"cl_set_instance_method: Enter len2=%d name=[%s]",len2,name);
DEBUGOUT_InfoParm(160,"cl_set_instance_method: pInfoParm1=",pInfoParm1,0,0);

	if (!(procct=(ProcCT *)pInfoParm1->pi_len)) return -1;
DEBUGOUTL1(160,"cl_set_instance_method: procct=%08x",procct);
	iFIND_METHOD = 0;
	wkleaf = NULL;
	if (*name == '$') {
		name++;
		len2--;
	}
	if ((iParmNo=cl_gx_chk_vnam_info('r',procct->pha_vnam,name,len2,&pInfoParm)) > 0) {
	/*	if (pInfoParm=cl_get_var_ent(procct->pTBL_vnam,iParmNo)) {	*/
		if (pInfoParm) {

DEBUGOUT_InfoParm(160,"cl_set_instance_method: name=[%s] iParmNo=%d",pInfoParm,name,iParmNo);

			if (pInfoParm->pi_id == 'F') {
				name = pInfoParm->pi_data;
				len2 = pInfoParm->pi_dlen;
				if (len2>=2 && *name=='{') {
					scrprct = cl_search_src_ct();
					cur_procct = cl_search_proc_ct();
					wkleaf = cl_set_func_body(scrprct,cur_procct,name,&nodeleaf,procct->ProcPath);
					if (wkleaf) {
						cmd = &wkleaf->cmd;
						prmp = cmd->prmp;
						name = prmp[0]->prp;
						len2 = strlen(name);
						cno = C_FUNCTION;
					}
				}
			}
			else {
/*
printf("cl_set_instance_method: ,name=[%s] pha_vnam=%08x pTBL_vnam=%08x\n",name,procct->pha_vnam,procct->pTBL_vnam);
DEBUGOUT_InfoParm(0,"cl_set_instance_method: procct=%08x iParmNo=%d",pInfoParm,procct,iParmNo);
*/
				pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | D_AUX1_LOCAL_VAR;
				if (cl_is_undef_parm(pInfoParm) && (pGlobTable->options[0] & 0x01))
					cl_null_data(pInfoParm);
				cl_set_parm_long(pInfoParmW,(long)pInfoParm);
				pInfoParmW->pi_id = D_DATA_ID_STOREVAR;
				return 0;
			}
		}
		else return -1;
	}

DEBUGOUTL3(160,"cl_set_instance_method: wkleaf=%08x iParmNo=%d name=[%s]",wkleaf,iParmNo,name);

	if (!wkleaf) {
		topleaf = (Leaf *)pInfoParm1->pi_pos;
/*
printf("cl_set_instance_method: ,topleaf=%08x\n",topleaf);
*/
		if (wkleaf = _find_method_and_super(topleaf,name,-1,NULL,0,&pmethod_nam)) {
			cno = wkleaf->cmd.cid;
			iFIND_METHOD = D_AULN_FIND_METHOD;
		}
	}
	if (wkleaf) {
		*pInfoParmW = *pInfoParm1;
		if (cno == C_FUNCTION) {
			id = 'M';
			pInfoParmW->pi_alen |= iFIND_METHOD;
		}
		else id = 'I';
		pInfoParmW->pi_id = id;
		pInfoParmW->pi_pos = (long)wkleaf;
		len1 = pInfoParm1->pi_dlen;
		len = len1 + len2 + 1;
		pInfoParmW->pi_data = p = cl_tmp_const_malloc(len+1);
		memcpy(p,pInfoParm1->pi_data,len1);
		p += len1;
		*p++ = '.';
		memzcpy(p,name,len2);
		pInfoParmW->pi_dlen = len;

DEBUGOUTL1(160,"cl_set_instance_method: pInfoParmW->pi_data=[%s]",pInfoParmW->pi_data);

		rc = 0;
	}
	else {
		/* %s: ���\�b�h[%s]�͖���`�ł��B */
		ERROROUT2(FORMAT(333),"cl_set_instance_method",name);
		rc = ECL_SCRIPT_ERROR;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_ex_class_method(pInfoParmW,pInfoParmM,nparm,ppParm,opt)
tdtINFO_PARM *pInfoParmW,*pInfoParmM;
tdtINFO_PARM *ppParm[];
int nparm,opt;
{
	int rc,i;
	Leaf *leaf,*wkleaf;
	char *p,*name,*method,*class_name,*pmethod_nam;
	ProcCT *cur_procct,*procct,*proc,*wkproc;
	cmdInfo *cmd;

	p = pInfoParmW->pi_paux;
	memset(pInfoParmW,0,sizeof(tdtINFO_PARM));
	pInfoParmW->pi_paux = p;

	name = pInfoParmM->pi_data;
	if (pInfoParmM->pi_alen & D_AULN_FIND_METHOD) {
		i = akxnrskipto(name,pInfoParmM->pi_dlen,".");
		if (i >= 0) method = name + i;
		else method = name;
		leaf = _find_method_and_super(pInfoParmM->pi_paux,method,nparm,ppParm,0,&pmethod_nam);
		if (!leaf) {
			/* %s: ���\�b�h[%s]�͖���`�ł��B */
			ERROROUT2(FORMAT(333),"cl_ex_class_method",method);
			return ECL_SCRIPT_ERROR;
		}
		pInfoParmM->pi_alen &= ~D_AULN_FIND_METHOD;
	}
	else leaf = (Leaf *)pInfoParmM->pi_pos;
	proc = (ProcCT *)pInfoParmM->pi_len;
/*
printf("cl_ex_class_method: name=[%s] proc=%08x\n",name,proc);
*/
	/* ���\�b�h�����s���邽�߂ɁA�c���Ă������N���X�ϐ��pprocct�𕜌����� */
	wkleaf = (Leaf *)pInfoParmM->pi_paux;
	cmd = &(wkleaf->cmd);
	class_name = cmd->prmp[0]->prp;

DEBUGOUTL2(120,"cl_ex_class_method: �l���������������s���邽�߂ɁA�c���Ă������N���X[%s]�ϐ��pprocct(%08x)�𕜌�����",class_name,proc);

	if (rc=cl_exec_func_setup_proc(class_name,NULL,0,NULL,NULL,NULL,0,proc)) return rc;
	proc = cl_search_proc_ct();
	/* ���\�b�h�����s���� */

DEBUGOUTL1(120,"cl_ex_class_method: name=[%s] �l�����������pproc�𐶐�����",name);

	if (rc=cl_exec_func_setup_proc(name,pInfoParmW,nparm,ppParm,leaf,NULL,0,NULL)) return rc;

DEBUGOUTL1(120,"cl_ex_class_method: �l���������������s���� procct=%08x",proc);

	if ((cmd->sub_cid & CS_EXTENDS) && pmethod_nam) {
		wkproc = cl_search_proc_ct();
		wkproc->ProcPath = mk_method_path(class_name,pmethod_nam);
/*
printf("cl_func_new: wkproc->ProcPath=[%s]\n",wkproc->ProcPath);
*/
	}
	rc = cl_exec_func_execute(proc);
	cl_er_lk_proc_ct();
	Free(proc->ProcNM);
	Free(proc);

	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_class_method(pInfoParmW,pInfoParm1,pInfoParm2,optW,name,len2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
int optW;
char *name;
int len2;
{
	static char *_fn_="cl_set_class_method";
	int rc,len,varlen,iParmNo;
	tdtINFO_PARM tInfoParmW,*pInfoParm,*pParm[1];
	Leaf *leaf;
	char *class_name,varnam[Var_NM_MAX+5];
	ScrPrCT *scrct;
	XHASHB *pha_Vnam;
	tdtINFO_PARM ***pTBL_Vnam;

	/* STATIC�N���X�̃`�F�b�N */
	class_name = pInfoParm1->pi_data;
	if (!stricmp(class_name,D_SYS_CLASS_SYSTEM) ||
	    !stricmp(class_name,D_SYS_CLASS_FILE) ||
	    !stricmp(class_name,D_SYS_CLASS_MATH)) {
		cl_gx_copy_info(pInfoParmW,pInfoParm2);
		return 0;
	}
	if (leaf=(Leaf *)pInfoParm1->pi_pos) {
		if ((leaf->cmd.sub_cid & 0xff) != CS_STATIC) {
			/* %s: [%s]�́ASTATIC�ł͂���܂���Bsub_cid=%08x */
			ERROROUT3(FORMAT(547),_fn_,pInfoParm1->pi_data,leaf->cmd.sub_cid);
			return ECL_SCRIPT_ERROR;
		}
	}
	else {
		/* %s: [%s]��leaf��񂪂���܂���B */
		ERROROUT2(FORMAT(549),_fn_,class_name);
		return -1;
	}

	/* �V�X�e���̃C���X�^���X�Ƃ��ēo�^�ς݂��̃`�F�b�N */
#if 1	/* 2023.2.24 */
	if (!(scrct=cl_search_scr_ct())) return -1;
	pha_Vnam  = scrct->Vary->pha_vnam;
/*	pTBL_Vnam = scrct->Vary->pTBL_vnam;	*/
#endif
	len = pInfoParm1->pi_dlen;
	strcpy(varnam,"<I>");
	varlen = len + 3;
	memnzcpy(varnam+3,class_name,len,sizeof(varnam)-3);
	if (pGlobTable->options[7] & 0x04) akxcuppern(varnam,NULL,varlen);
#if 1	/* 2023.2.24 */
	if ((iParmNo=cl_gx_chk_vnam_info('r',pha_Vnam,varnam,varlen,&pInfoParm)) > 0) {
	/*	pInfoParm = cl_get_var_ent(pTBL_Vnam,iParmNo);	*/
#else
	if ((iParmNo=cl_gx_chk_vnam('r',pCLprocTable->pha_vnam,varnam,varlen)) > 0) {
/*
printf("cl_set_class_method:R: iParmNo=%d varlen=%d varnam=[%s]\n",iParmNo,varlen,varnam);
*/
		pInfoParm = cl_get_var_ent(pCLprocTable->pTBL_vnam,iParmNo);
#endif
		if (rc=cl_set_instance_method(pInfoParmW,pInfoParm,NULL,optW,name,len2)) return rc;
		return 0;
	}
	else if (iParmNo < 0) return iParmNo;

	/* �C���X�^���X�𐶐����� */
	pParm[0] = pInfoParm1;
	if (rc=cl_func_new(&tInfoParmW,1,pParm)) return rc;
	if (tInfoParmW.pi_id == 'M') {
		/* %s: �R���X�g���N�^����\x83\\�b�h[%s]��Ԃ��܂����B */
		ERROROUT2(FORMAT(550),_fn_,tInfoParmW.pi_data);
		return ECL_SCRIPT_ERROR;
	}

	/* ���\�b�h�܂��͕ϐ������߂� */
	if (rc=cl_set_instance_method(pInfoParmW,&tInfoParmW,NULL,optW,name,len2)) return rc;

DEBUGOUT_InfoParm(161,"cl_set_class_method: rc=%d",cl_set_class_method,rc,0);

	/* �V�X�e���̃C���X�^���X�Ƃ��ēo�^���� */
#if 1	/* 2023.2.24 */
	if ((iParmNo=cl_gx_chk_vnam_info('s',pha_Vnam,varnam,varlen,&pInfoParm)) > 0) {
	/*	pInfoParm = cl_get_var_ent(pTBL_Vnam,iParmNo);	*/
#else
	if ((iParmNo=cl_gx_chk_vnam('s',pCLprocTable->pha_vnam,varnam,varlen)) > 0) {
/*
printf("cl_set_class_method:S: iParmNo=%d varlen=%d varnam=[%s]\n",iParmNo,varlen,varnam);
*/
		pInfoParm = cl_get_var_ent(pCLprocTable->pTBL_vnam,iParmNo);
#endif
		cl_gx_rep_info_set_ign(pInfoParm,&tInfoParmW,1);
	}
	else if (iParmNo < 0) return iParmNo;
	else {
		/* %s: %s��%s�G���g���p�̋󂫂�����܂���B */
		ERROROUT3(FORMAT(323),_fn_,class_name,"PUBLIC");
		return -1;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_exec_super_class(cur_procct,procct,pRb,super_nam,super_nam_len)
ProcCT *cur_procct,*procct;
tdtRB_CHAIN *pRb;
char *super_nam;
int  super_nam_len;
{
	int rc;
	Leaf *topleaf,*save_leaf;
	char *p,*pnam,**ppcnam;
	tdtINFO_PARM tInfoParmW,tInfoParm2;
	tdtRB_CHAIN *pRbn;
	cmdInfo *cmd;
	ProcCT	*procW;

DEBUGOUTL4(120,"cl_exec_super_class: cur_procct=%08x procct= %08x pRb=%08x super_nam=[%s]",
cur_procct,procct,pRb,super_nam);

	if (!cur_procct || !procct || !pRb) return -1;
	if (!super_nam || super_nam_len<=0) return 0;

DEBUGOUTL1(120,"cl_exec_super_class: pRb->rbc_buf=%08x",pRb->rbc_buf);

	if (!(topleaf=(Leaf *)pRb->rbc_buf)) {
		cl_set_parm_char(&tInfoParm2,super_nam,super_nam_len);
		if (rc=cl_gx_new(&tInfoParmW,&tInfoParm2)) return rc;
		topleaf = (Leaf *)tInfoParmW.pi_pos;
		pRb->rbc_buf = (char *)topleaf;
		ppcnam = (char **)(pRb+1);
		if (!(p=cl_leaf_malloc(super_nam_len+1))) return ECL_MALLOC_ERROR;
		*ppcnam = p;
		memzcpy(p,super_nam,super_nam_len);
	}

DEBUGOUTL1(120,"cl_exec_super_class: topleaf=%08x",topleaf);

	cmd = &(topleaf->cmd);

DEBUGOUTL1(120,"cl_exec_super_class: cmd->sub_cid=%08x",cmd->sub_cid);

	if (cmd->sub_cid & CS_EXTENDS) {
		if (!(pRbn=pRb->rbc_next)) {
			if (!(pRbn=(tdtRB_CHAIN *)cl_leaf_malloc(sizeof(tdtRB_CHAIN)+sizeof(char *)))) return ECL_MALLOC_ERROR;
			memset(pRbn,0,sizeof(tdtRB_CHAIN)+sizeof(char *));
			pRb->rbc_next = pRbn;
		}

DEBUGOUTL(120,"cl_exec_super_class: �p������");

		rc = cl_exec_super_class(cur_procct,procct,pRbn,cmd->parl->par,cmd->parl->parlen);
		procct = cl_search_proc_ct();
	}
	else  {
DEBUGOUTL(120,"cl_exec_super_class: �p���Ȃ�");
	}

	/* �N���X�ϐ��̒�`�����s���� */
	save_leaf = procct->ProcTop;
	pnam = procct->ProcNM;
	procct->ProcTop = topleaf;
	procct->Curleaf = topleaf;
	procct->Nextleaf = topleaf;
	procct->ProcNM = Strdup(super_nam);

DEBUGOUTL2(120,"cl_exec_super_class: �N���X�ϐ��̒�`�����s���� super_nam=[%s] topleaf=%08x",super_nam,topleaf);

	rc = cl_exec_func_execute(cur_procct);
	if (!rc) {
		if (pGlobTable->error < 0)
			rc = pGlobTable->error;
		else {

DEBUGOUTL2(120,"cl_exec_super_class: proc�𕜌����� save_leaf=%08x procct=%08x",save_leaf,procct);

			rc = cl_exec_func_setup_proc(pnam,&tInfoParmW,0,NULL,save_leaf,NULL,D_PFLAG_NO_FREE,procct);
		}
	}
	return rc;
}
