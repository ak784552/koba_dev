static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       ColMnTrEndloop                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
static int _tr_loop_node_check(y,able,na,loop_name)
condList *y;
int  *able[],na;
char *loop_name;
{
	Leaf *leaf;
	char *p;
	int rc=0;

	rc = cl_tr_node_check_leaf(y,NULL,0,able,na,&leaf);
	if (rc) rc = ECL_TR_ENDLOOP;
	else if (leaf->cmd.cid==C_LOOP && stricmp(p=leaf->cmd.prmp[0]->prp,loop_name)) {
		/* col_mn_tr_end_loop: ���[�v�̊J�n��[LOOP ]%s�ɂȂ��Ă��܂��Bline=%d */
		ERROROUT2(FORMAT(71),p,leaf->cmd.rc);
		rc = ECL_TR_ENDLOOP;
	}
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_loop(y)
condList *y;
{
	static int able[]={C_FOR,C_LOOP};
	static int ablewh[]={C_WHILE,C_LOOP};
	static int ableun[]={C_UNTIL,C_LOOP};
	static int abledo[]={C_DO,
		C_LOOP|C_LOOP_DO,C_FOR|C_LOOP_DO,C_WHILE|C_LOOP_DO,C_UNTIL|C_LOOP_DO};
	static int abledl[]={C_DO,C_LOOP};
	int  rc;
	Leaf *leaf;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum > 0) {
		if (cmd->cid==C_ENDWHILE || cmd->cid==C_ENDUNTIL) {
			rc = cl_tr_node_check_leaf(y,NULL,0,abledl,2,&leaf);
			if (leaf->cmd.prmnum > 0) {
				/* col_mn_tr_end_loop: ���[�v�̊J�n��DO;�܂���LOOP;�ł͂���܂���Bline=%d */
				ERROROUT1(FORMAT(74),leaf->cmd.rc);
				return ECL_TR_ENDLOOP;
			}
			leaf->cmd.sub_cid = cmd->cid;
			cmd->parl[D_DOWHILE_TOP_LEAF].par = (char *)leaf;
			if (!(rc = cl_make_leaf(y))) rc = cl_push(y);
			if (rc) return rc;
		}
		else {
			ERROROUT1(FORMAT(41),"col_mn_tr_end_loop");
			return ECL_TR_ENDLOOP;
		}
	}
	else {
		if (cmd->cid==C_ENDLOOP) {
			rc = cl_tr_node_check(y,NULL,0,able,2);
			if (rc) return ECL_TR_ENDLOOP;
		}
		else if (cmd->cid==C_NEXT || cmd->cid==C_ENDFOR) {
			rc = _tr_loop_node_check(y,able,2,"FOR");
			if (rc) return ECL_TR_ENDLOOP;
		}
		else if (cmd->cid==C_ENDWHILE) {
			rc = _tr_loop_node_check(y,ablewh,2,"WHILE");
			if (rc) return ECL_TR_ENDLOOP;
		}
		else if (cmd->cid==C_ENDUNTIL) {
			rc = _tr_loop_node_check(y,ableun,2,"UNTIL");
		}
		else {
			rc = cl_tr_node_check_leaf_check(y,NULL,0,abledo,5,NULL,C_LOOP_DO);
			if (rc) return ECL_TR_ENDLOOP;
		}
#if 0
		rc = cl_loop_close(y,cmd->cid);
		if (rc == 10000) {
			/* col_mn_tr_end_loop: ENDIF �܂��� ENDSW ������܂���B */
			ERROROUT(FORMAT(72));
			return ECL_TR_ENDLOOP;
		}
#endif
	}
	rc = cl_nest_tag(y,2);
	if (rc != -1) {
		rc=cl_change_tree(y,y->clstcb->nestLev2 );
	/*	if (rc) return (rc);	*/
		cl_search_nest(y,2);
	}
	else return ECL_TR_ENDLOOP;
/*  else clError(30); */
	return NormalEnd;
}

/************************************************/
/*                                              */
/*     cl_loop_close                            */
/*----------------------------------------------*/
/*                                              */
/*                                              */
/************************************************/
/* */
int cl_loop_close(y,cid)
condList *y;
int cid;
{
	int rc,cmdid;
	Leaf *leaf;

	rc = 0;
	for (;;) {
		if (!(leaf=y->clstcb->nestLev2)) break;
		cmdid = leaf->cmd.cid;
		if ((cid==C_LOOP && cmdid!=C_LOOP) && (cid==C_DO && cmdid!=C_DO)) {
			rc = cl_nest_tag(y,2);
			if (rc != -1) {
				cl_change_tree(y,y->clstcb->nestLev2);
				cl_search_nest(y,2);
			/*	ERROROUT(FORMAT(73));	*/
				rc = 10000;
			}
		}
		else {
			break;
		}
	}
	return rc;
}

/************************************************/
/*                                              */
/*     cl_search_loop                           */
/*----------------------------------------------*/
/*                                              */
/*                                              */
/************************************************/
/* */
int cl_search_loop(y,cid)
condList *y;
int cid;
{
	Leaf  *Dummy;
	int cmdid;
	CLNCB *p;

	p = y->clstcb;
	Dummy = p->nestLev2;
	for(;;) {
		if (Dummy==p->nestLev1 || !Dummy) {
			return ECL_SCRIPT_ERROR;
		}

		cmdid = Dummy->cmd.cid;
		if (cid) {
			if (cmdid==cid) return 0;
		}
		else {
			if (cmdid==C_LOOP || cmdid==C_FOR || cmdid==C_DO
#if 1
			 || cmdid==C_SWITCH
#endif
			) return 0;
		}

		Dummy = Dummy->preleaf;
	}
}
