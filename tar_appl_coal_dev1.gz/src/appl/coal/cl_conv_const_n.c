static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ� ( ���l )                                      *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_const_n( pparmList , pInfoParm )           *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtINFO_PARM	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
/*	  error code : -215130101 �` -215139999	*/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];

/****************************************/
/*	01									*/
/****************************************/
int cl_conv_const_n(pparmList,pInfoParm)
parmList   *pparmList;
tdtINFO_PARM  *pInfoParm;
{
	int	len;
	char *prp;

	if (!pparmList) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return D_ERROR;
	}
	if (!pparmList->prp) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return D_ERROR;
	}
	prp = &(pparmList->prp[0]);
	len = pparmList->prmlen;
	return cl_conv_const_n_str(pInfoParm,prp,len);
}

/****************************************/
/*	02									*/
/****************************************/
int cl_conv_const_n_str(pInfoParm,prp,len)
tdtINFO_PARM *pInfoParm;
char *prp;
int	len;
{
	int	rc,opt,iAttr[4],iVal;
	double dValue;
	long   lValue,lValz[NMPA_LONG],*lVal;

	opt = pGlobTable->options[16];
	iAttr[0] = 0;
	lVal = cl_get_tmpMPA(lValz);
	if ((rc=cl_conv_const_nsub(prp,len,lVal,"cl_conv_const_n_str: ",iAttr,opt)) < 0) return rc;
	else if (rc > 0) return ECL_SCRIPT_ERROR;
	if (iAttr[0] == DEF_ZOK_FLOA) {
		memcpy(&dValue,lVal,sizeof(double));
		cl_set_parm_double(pInfoParm,dValue);
	}
	else if (iAttr[0] == DEF_ZOK_DECI) {
		cl_set_parm_mpa(pInfoParm,lVal);
		if (iAttr[1] < 0) pInfoParm->pi_alen = D_AULN_OVERFLOW;
		if (iAttr[2] & AKX_NUM_U) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
		/* D_AULN_OVERFLOW�����̂͑��ł́Along�̂Ƃ��̂݁B
		   mpa�ł̃I�[�o�[�t���[�̓G���[���AMAX�l�ő��s�ƂȂ�AD_AULN_OVERFLOW�������Ƃ͂Ȃ��B
		   ���������āADECI��D_AULN_OVERFLOW�����̂́A>=2147483648�̂Ƃ��̂݁B */
	}
	else {
#if defined(_LP64)
		if (iAttr[1] == sizeof(long))
			cl_set_parm_long(pInfoParm,lVal[0]);
		else {
			iVal = lVal[0];
			cl_set_parm_int(pInfoParm,iVal);
		}
#else
		cl_set_parm_long(pInfoParm,lVal[0]);
#endif
		if (iAttr[2] & AKX_NUM_U) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
	}
	pInfoParm->pi_aux[1] = D_AUX1_PROTECTED;
	if (iAttr[2] & AKX_NUM_I) pInfoParm->pi_scale |= D_DATA_IMAGE;
#if 1	/* 2025.3.25 */
	if (iAttr[2] & AKX_NUM_R) {
		if ((rc=_set_rational(pInfoParm,pInfoParm)) < 0) return rc;
	}
#endif
DEBUGOUT_InfoParm(151,"cl_conv_const_n_str: iAttr[2]=%08x pInfoParm=",pInfoParm,iAttr[2],0);
	return NORMAL;
}

/****************************************/
/*	03									*/
/****************************************/
int cl_conv_const_nsub(p0,len0,pValue,pMsg,iAttr,opt)
char *p0;
int  len0;
long *pValue;
char *pMsg;
int  iAttr[];
int  opt;
{
	int	i,rc,len;
	char *prp,*prp2,c,cValue[33];

	prp = p0;
	len = len0;
/*
printf("cl_conv_const_nsub: prp=[%s] len=%d opt=%d\n",prp,len,opt);
*/
	if (prp && len) {
		i = akxnskipin(prp,len," \t");
		prp += i;
		len = akxnrskipin(prp,len-i," \t");
/*
printf("cl_conv_const_nsub: i=%d len=%d\n",i,len);
*/
	}
	rc = cl_conv_const_mpasub(prp,len,pValue,pMsg,iAttr,opt & ~AKX_CNVN_OPT_DOUBLE);
	return rc;
}

/****************************************/
/*	04									*/
/****************************************/
int cl_set_parm_bin(pInfoParm,iValue)
tdtINFO_PARM *pInfoParm;
int iValue;
{
	cl_set_parm_long(pInfoParm,(long)iValue);
	return 0;
}

/****************************************/
/*	05									*/
/****************************************/
int cl_set_parm_int(pInfoParm,iValue)
tdtINFO_PARM *pInfoParm;
int iValue;
{
#if defined(_LP64)
	long lVal;

	lVal = iValue;
	cl_set_parm_long(pInfoParm,lVal);
	pInfoParm->pi_dlen = sizeof(int);
#else
	cl_set_parm_long(pInfoParm,(long)iValue);
#endif
	return 0;
}

/****************************************/
/*	05.5								*/
/****************************************/
int cl_set_parm_uint(pInfoParm,uiValue)
tdtINFO_PARM *pInfoParm;
int uiValue;
{
#if defined(_LP64)
	ulong ulVal;

	ulVal = uiValue;
	cl_set_parm_long(pInfoParm,ulVal);
	pInfoParm->pi_dlen = sizeof(int);
#else
	cl_set_parm_long(pInfoParm,(long)uiValue);
#endif
	return 0;
}

/* 06 */
/**************************************************************
 D_DATA_LPOSDATA(0x40)�𗧂Ă�Ƃ��́Api_pos��long�ŕێ�����B
**************************************************************/
int cl_set_parm_long(pInfoParm,lValue)
tdtINFO_PARM *pInfoParm;
long lValue;
{
	memset(pInfoParm,0,sizeof(tdtINFO_PARM));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_BINA;
	pInfoParm->pi_scale= D_DATA_LPOSDATA;
	pInfoParm->pi_pos  = lValue;
	pInfoParm->pi_dlen = sizeof(long);
	pInfoParm->pi_data = (char *)&(pInfoParm->pi_pos);
	return 0;
}

/****************************************/
/*	07									*/
/****************************************/
int cl_set_parm_double(pInfoParm,dValue)
tdtINFO_PARM *pInfoParm;
double dValue;
{
/*
printf("cl_set_parm_double: dValue=%f\n",dValue);
*/
	memset(pInfoParm,0,sizeof(tdtINFO_PARM));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_FLOA;
	pInfoParm->pi_scale= D_DATA_LPOSDATA;
	memcpy(&pInfoParm->pi_pos,&dValue,sizeof(double));
	pInfoParm->pi_dlen = sizeof(double);
	pInfoParm->pi_data = (char *)&(pInfoParm->pi_pos);
	return 0;
}

/* 08 */
/************************************************/
/*	opt = 'P' pi_data��val��ݒ肷��			*/
/*		= 'V' pi_data��val���R�s�[����			*/
/*		= ���̑� pi_data��cl_tmp_const_malloc()���āA*/
/*				pi_data��val���R�s�[����		*/
/************************************************/
int cl_set_parm_mpa2(pInfoParm,val,opt)
tdtINFO_PARM *pInfoParm;
MPA *val;
char opt;
{
	char *p,uopt;
	int len;

	len = sizeofMPA();
	if (!val) val = m_get_i(0);
/*
printf("cl_set_parm_mpa2: opt=[%c]\n",opt);
*/
	uopt = akxcupper(opt);
	if (uopt == 'P') p = (char *)val;
	else {
		if (uopt == 'V') p = pInfoParm->pi_data;
		else if (!(p=cl_tmp_const_malloc(len))) return -215130801;
		memcpy(p,val,len);
	}
	if (opt=='p' || opt=='v') pInfoParm->pi_data = p;
	else {
		memset(pInfoParm,0,sizeof(tdtINFO_PARM));
		pInfoParm->pi_id = ' ';
		pInfoParm->pi_attr = DEF_ZOK_DECI;
		pInfoParm->pi_scale= 0;
		pInfoParm->pi_dlen = len;
		pInfoParm->pi_data = p;
	}
	return 0;
}

/****************************************/
/*	09									*/
/****************************************/
int cl_set_parm_mpa(pInfoParm,val)
tdtINFO_PARM *pInfoParm;
MPA *val;
{
	return cl_set_parm_mpa2(pInfoParm,val,0);
}

/****************************************/
/*	10									*/
/****************************************/
int cl_conv_const_mpasub(p,len,pValue,pMsg,iAttr,opt)
char *p;
int  len;
long *pValue;
char *pMsg;
int  iAttr[];
int  opt;	/* AKX_CNVN_OPT_DOUBLE = ON:double �Q�i���������_��, OFF:decimal �P�O�i���������_��  */
{
	static char *_fn_="cl_conv_const_mpasub";
	int rc,attr,k,size,opt17,iUL,iU,iL,iVal,iOVER,iI,iULI,iR,iCOMP;
	long lValue;
	double dVal;
	char   buf[33],*pp;
	MPA ma,*pma;
/*
printf("cl_conv_const_mpasub: p=[%s] len=%d opt=%08x iAttr[0]=%d\n",p,len,opt,iAttr[0]);
*/
	iR = iULI = iUL = iU = iL = iI = rc = 0;
	/* 2022.6.17 */
	opt17 = cl_get_option(17,0);
	opt |= opt17 | AKX_CNVN_OPT_DIGIT;
	if (!(opt & 0x200)) opt |= AKX_CNVN_OPT_FU_MPA;
	opt17 &= 0x1ff;
	k = cl_chk_digit_fopt(10,p,len,opt,iAttr);
	if (k > 0) {
		iU = k & AKX_NUM_U;
		iL = k & AKX_NUM_L;
		iI = k & AKX_NUM_I;
		iR = k & AKX_NUM_R;
		iUL = iU | iL;
		iULI = iUL | iI | iR;
		k &= ~AKX_NUM_ULIR;
	}
/*
printf("cl_conv_const_mpasub: k=%08x iAttr[0]=%d opt17=%04x iULI=%04x\n",k,iAttr[0],opt17,iULI);
*/
	if (iU) len--;
	if (iL) len--;
	if (iI) len--;
	if (iR) len--;
	if (k==8) {
		if (iAttr[0]==3) k = 1;
		/* 2022.2.7 */
		else if (iAttr[0]==4) k = 2;
		else if (iAttr[0]==2 && !(opt17 & 0x80)) k = 2;
		else k = 0;
	}
	if (k==2 &&
	         ((opt & AKX_CNVN_OPT_DOUBLE) || (opt17 & 0x01))) k = 1;
/*
printf("cl_conv_const_mpasub: modified k=%d\n",k);
*/
	if (k == 2) {
		pma = (MPA *)pValue;
		if (rc=m_set_an_opt(pma,p,len,opt)) {
/*
printf("cl_conv_const_mpasub:m_set_an_opt: rc=%d\n",rc);
*/
#if 0	/* 2025.5.8 */
			if (iU) {
				pma->sign = 0;
			}
#endif
			rc = cl_chk_error_mpa(rc,pMsg,p,len);
		}
		attr = DEF_ZOK_DECI;
		size = sizeofMPA();
/*
printf("cl_conv_const_mpasub: k=%08x iAttr[0]=%d iULI=%04x\n",k,iAttr[0],iULI);
*/
	}
	else if (k == 1) {
#if 1	/* 2022.6.17 */
		if (opt & AKX_CNVN_OPT_COMMA) {
			pp = cl_tmp_const_malloc(len+1);
			len = akxcreplace_char2(pp,len,p,len,',','\0');
			*(pp+len) = '\0';
/*
printf("cl_conv_const_mpasub: len=%d pp=[%s]\n",len,pp);
*/
			p = pp;
		}
#endif
		if (rc=akxccvd(p,len,&dVal)) {
			if (rc>0 && (opt & 0x10)) 
				rc = 0;
			else {
				if (pMsg=cl_conv_msg_check(pMsg,rc)) {
					memnzcpy(buf,p,len,sizeof(buf));
							/* %s�Q�i���������_��[%s]�̎w�肪����Ă��܂�(rc=%d)�B */
					ERROROUT3(FORMAT(307),pMsg,buf,rc);
				}
				if (rc < -10) rc = -rc/10;
			}
		}
		memcpy((char *)pValue,&dVal,sizeof(double));
		attr = DEF_ZOK_FLOA;
		size = sizeof(double);
	}
	else if (k == -6) {
		ERROROUT1(FORMAT(624),_fn_);	/* %s: �w����������Ă��܂��B*/
		rc = ECL_SCRIPT_ERROR;
	}
	else if (k == -7) {
		ERROROUT1(FORMAT(625),_fn_);	/* %s: �������d�����Ă��܂��B*/
		rc = ECL_SCRIPT_ERROR;
	}
	else {
		if (!(opt17 & 0x02)) {
			iUL |= AKX_NUM_L;
			iL = AKX_NUM_L;
		}
#if 1	/* 2022.6.17 */
		if (opt & AKX_CNVN_OPT_COMMA) {
			pp = cl_tmp_const_malloc(len+1);
			len = akxcreplace_char2(pp,len+1,p,len,',','\0');
			*(pp+len) = '\0';
/*
printf("cl_conv_const_mpasub: len=%d pp=[%s]\n",len,pp);
*/
			p = pp;
		}
#endif
		/*  2147483648 �́A�I�[�o�[�t���[����
		   -2147483648 �́A�I�[�o�[�t���[���Ȃ� */
		rc = cl_cvn10(p,len,&lValue,iUL,opt17);
		if (rc == -3) {	/* add 2021.9.24 */
			pma = (MPA *)pValue;
			m_set_an_opt(pma,p,len,opt);
			pma->opt |= AKX_MPA_OPT_CVN_OVER;	/* add 2025.5.12 */
#if defined(_LP64)
			if ((opt17 & 0x02) && iL) pma->opt |= AKX_MPA_OPT_SET_LONG;	/* add 2025.5.15 */
#endif
			attr = DEF_ZOK_DECI;
			size = sizeofMPA();
			rc = 0;
			if (opt17 & 0x80) {
				/* 2022.2.7 */
				/* 2147483648�ȏ� �́Adec�ɕϊ����A�I�[�o�[�t���[�����Ȃ����A
				   ��/���̍ő�l��ݒ肷��I�v�V�����̂Ƃ��́A
				   �I�[�o�[�t���[������Ƃ��� -size �Ƃ���B
				   (-(2147483648)��P�����Z���ɁAint�ɖ߂�����) */
				iOVER = 1;
				/* 2025.5.8 */
				if (iU) {
#if defined(_LP64)
					if ((iL && (iCOMP=m_cmp_a(pma,m_get_ULONGMAX(-1)))>=0) ||	/* add 2021.9.26 */
					    (!iL && (iCOMP=m_cmp_a(pma,m_get_UINTMAX(-1)))>=0)) {
#else
					if ((iCOMP=m_cmp_a(pma,m_get_ULONGMAX(-1))) >= 0) {
#endif
						size = -size;	/* add 2022.2.12 */
						if (!iCOMP) iOVER = 0;
					}
				}
				else {
#if defined(_LP64)
					if ((iL && (iCOMP=m_cmp_a(pma,m_get_LONGMAX(-1)))>=0) ||	/* add 2021.9.26 */
					    (!iL && (iCOMP=m_cmp_a(pma,m_get_INTMAX(-1)))>=0)) {
#else
					if ((iCOMP=m_cmp_a(pma,m_get_LONGMAX(-1))) >= 0) {
#endif
						size = -size;	/* add 2022.2.12 */
						if (!iCOMP) iOVER = 0;
					}
				}
			}
/*
printf("cl_conv_const_mpasub: iOVER=%d size=%d lValue=%ld\n",iOVER,size,lValue);
*/
			if (iOVER) {
/*
printf("cl_conv_const_mpasub:m_set_an_opt: opt17=%04x\n",opt17);
*/
				if (opt17 & 0x80) {
							/* (W)(%d)[%s]�I�[�o�t���[���܂����B */
					ERROROUT2(FORMAT(265),len,strtemp(p,len));
					rc = 0;
				}
				else {
					if (iU) pma->sign = 0;
				}
			}
		}
		else {
			if (opt & 0x10) 
				rc = 0;
			else if (rc > 0) {
				if (pMsg=cl_conv_msg_check(pMsg,rc)) {
					/* %s: �����ȊO�̕���[%s]������܂�(pos=%d)�B */
					ERROROUT3(FORMAT(306),pMsg,strtemp(p,len),rc);
				}
				else rc = 0;
			}
#if defined(_LP64)
			if (iL) size = sizeof(long);
			else size = sizeof(int);
#else
			size = sizeof(long);
#endif
			attr = DEF_ZOK_BINA;
			*pValue = lValue;
/*
printf("cl_conv_const_mpasub: size=%d lValue=%ld\n",size,lValue);
*/
		}
	}
	iAttr[0] = attr;
	iAttr[1] = size;
	iAttr[D_IATTR_ULI] = iULI;

/*
printf("cl_conv_const_mpasub:Exit rc=%d attr=%d size=%d iULI=%04x lValue=%ld\n",rc,attr,size,iULI,lValue);
*/
DEBUGOUTL4(LVL_GXEXOBJ+5,"cl_conv_const_mpasub:Exit rc=%d attr=%d size=%d iULI=%04x",rc,attr,size,iULI);

	return rc;
}

/****************************************/
/*	11									*/
/****************************************/
int cl_conv_const_double(p,len,pValue,pMsg,iAttr)
char *p;
int  len;
long *pValue;
char *pMsg;
int  iAttr[];
{
	return cl_conv_const_mpasub(p,len,pValue,pMsg,iAttr,AKX_CNVN_OPT_DOUBLE);
}

/****************************************/
/*	12									*/
/****************************************/
char *cl_conv_msg_check(pMsg,rc)
char *pMsg;
int rc;
{
	char c;

	if (pMsg) {
		if ((c=*pMsg)=='-') {
			if (rc >= 0) pMsg = NULL;
			else pMsg++;
		}
		else if (c=='+') {
			if (rc <= 0) pMsg = NULL;
			else pMsg++;
		}
	}
	return pMsg;
}

/****************************************/
/*	13									*/
/****************************************/
int cl_cvn10(p,len,pvalue,iUL,opt17)
char *p;
int  len,iUL,opt17;
long *pvalue;
{
	int rc,iVal;
	char buf[65];
	long lVal;

	if (len<0) {
		ERROROUT(FORMAT(262));	/* �����񒷂����ł��B */
		rc = ECL_SYSTEM_ERROR;
	}
	else if (len == 0) {
		*pvalue = 0;
		rc = 0;
	}
	else {
	/*
		if (iUL & AKX_NUM_U) len--;
		if (iUL & AKX_NUM_L) len--;
	*/
		if (opt17 & 0x100) iUL |= AKX_NUM_U;	/* add 2022.4.2 */
		rc = akxcgcvlu_opt(p,len,&lVal,iUL,opt17 & 0xf0);
		if (rc) {
			memnzcpy(buf,p,len,sizeof(buf));
				/* (%d)[%s]����������܂���B */
			if      (rc == -1) ERROROUT2(FORMAT(263),len,buf);
				/* (%d)[%s]�i�����s���ł��B */
			else if (rc == -2) ERROROUT2(FORMAT(264),len,buf);
#if 0	/* 2021.9.24 */
			else if (rc == -3) {
				/* (W)(%d)[%s]�I�[�o�t���[���܂����B */
				ERROROUT2(FORMAT(265),len,buf);
				rc = 0;
			}
#endif
		}
#if defined(_LP64)
		else if (!(iUL & AKX_NUM_L)) {
			iVal = lVal;	/* L���Ȃ��Ƃ��́A0x80000000�r�b�g�𕄍��Ƃ��� */
			lVal = iVal;
/*
printf("cl_cvn10: iUL=%02x lVal=%d iVal=%d\n",iUL,lVal,iVal);
*/
		}
#endif
/*
printf("cl_cvn10: iUL=%02x lVal=%d rc=%d\n",iUL,lVal,rc);
*/
		*pvalue = lVal;
	}
	return rc;
}

/****************************************/
/*	14									*/
/****************************************/
long *cl_get_tmpMPA(long *az)
{
	return cl_get_tmpMPA2(az,1);
}

/****************************************/
/*	15									*/
/****************************************/
long *cl_get_tmpMPA2(long *az,int m)
{
#if 1	/* 2023.6.24 */
	return cl_get_tmpMPA3(az,NMPA_LONG,m);
#else
	long *a;

	if (m_get_nmpa10() <= NMPA10) a = az;
	else {
		if (m <= 0) m = 1;
		a = (long *)cl_tmp_const_malloc(sizeofMPA()*m+sizeof(long));
	}
	return a;
#endif
}

/****************************************/
/*	16									*/
/****************************************/
long *cl_get_tmpMPA10W2(long *az,int m)
{
	long *a;

	if (m_get_nmpa10() <= NMPA10) a = az;
	else {
		if (m <= 0) m = 1;
		a = (long *)cl_tmp_const_malloc(sizeofMPA10W()*m+sizeof(long));
	}
	return a;
}

/****************************************/
/*	17									*/
/****************************************/
long *cl_get_tmpMPA_pre1(long *az)
{
	return cl_get_tmpMPA3(az,NMPA_LONG_PRE1,1);
}

/****************************************/
/*	18									*/
/****************************************/
long *cl_get_tmpMPA3(long *az,int nmpa_long,int m)
{
	long *a;
	int nmpa_size,sizeofnmp;

	if (m <= 0) m = 1;	/* 2025.4.2 add */
	nmpa_size = nmpa_long*sizeof(long);
	sizeofnmp = sizeofMPA()*m;	/* 2025.4.2 add *m */
DEBUGOUTL4(198,"cl_get_tmpMPA3: nmpa_long=%d m=%d sizeofnmp=%d nmpa_size=%d",nmpa_long,m,sizeofnmp,nmpa_size);
	if (az && sizeofnmp<=nmpa_size) a = az;
	else {
	/*	if (m <= 0) m = 1;	*/	/* 2025.4.2 del */
		a = (long *)cl_tmp_const_malloc(sizeofnmp+sizeof(long));	/* 2025.4.2 del *m */
	}
	return a;
}

/****************************************/
/*	19									*/
/****************************************/
int cl_sign_reverse(pInfoParm)
tdtINFO_PARM *pInfoParm;
{
	int atr,*p,ret,iALEN,iVal[2];
	long lVal;
	double dVal;
	MPA *ma;
	tdtINFO_PARM tInfoR,tInfoI,tInfo,*ppParm[3];

	ret = 0;
	if (pInfoParm->pi_id == ' ') {
		if ((iALEN=pInfoParm->pi_alen) & D_AULN_RANGE_DATA) {
			if (iALEN & D_AULN_COMPLEX_DATA) {
				ppParm[0] = &tInfoR;
				ppParm[1] = &tInfoI;
				ppParm[2] = &tInfo;
				if ((ret=cl_get_range_info(pInfoParm,ppParm,iVal,0)) < 0) return ret;
				if ((ret=cl_sign_reverse(ppParm[0])) < 0) return ret;
				if ((ret=cl_sign_reverse(ppParm[1])) < 0) return ret;
				ret = cl_gx_range_set(pInfoParm,2,ppParm,0);
			}
			else {
			}
		}
		else {
			atr = pInfoParm->pi_attr;
			if (atr == DEF_ZOK_BINA) {
#if defined(_LP64)
#if 1
				if (pInfoParm->pi_dlen == sizeof(int)) {
					p = (int *)pInfoParm->pi_data;
					*p = -*p;
				}
#else
				pInfoParm->pi_pos = -pInfoParm->pi_pos;
#endif
#else
				pInfoParm->pi_pos = -pInfoParm->pi_pos;
#endif
			}
			else if (atr == DEF_ZOK_FLOA) {
				memcpy(&dVal,pInfoParm->pi_data,sizeof(double));
				dVal = -dVal;
				memcpy(pInfoParm->pi_data,&dVal,sizeof(double));
			}
			else if (atr == DEF_ZOK_DECI) {
				ma = (MPA *)pInfoParm->pi_data;
				ma->sign = 1 - ma->sign;
			}
		}
	}
	return ret;
}

/****************************************************/
/*	20												*/
/*	ret =  1 : ����									*/
/*		=  2 : overflow								*/
/*		=  4 : �����̌���' ','\t'�ȊO				*/
/*		=  0 : �������Ȃ�							*/
/*		= -1 ; buf==NULL							*/
/*		= -2 ; buf_len<0							*/
/*		= -4 : buf_len==0							*/
/*		= -8 : �����̑O�ɕ��������������ȊO������	*/
/*		= -16 : ��������������						*/
/****************************************************/
int cl_qnconv(buf,buf_len,pnum)
char *buf;
int buf_len;
long *pnum;
{
	int ret,i,len,sign_p,sign_m,iNUM;
	char *p,c;
	long num;
/*
printf("cl_qnconv:Enter buf_len=%d buf=[%s]\n",buf_len,buf);
*/
	ret = sign_p = sign_m = iNUM = 0;
	num = 0;
	if (!(p = buf)) ret = -1;
	if ((len=buf_len) < 0) ret += -2;
	else if (!len) ret += -4;
	else if (!ret) {
		while (len > 0) {
			if ((c=*p)>='0' && c<='9') {
				iNUM = 1;
				break;
			}
			else if (c==' ' || c=='\t') ;
			else if (c == '-') sign_m++;
			else if (c == '+') sign_p++;
			else {
				ret = -8;
				break;
			}
			p++;
			len--;
		}
		if (sign_p+sign_m > 1) ret += -16;
		else if (iNUM) {
			ret = 1;
			while (len > 0) {
				if ((c=*p)>='0' && c<='9') {
					if (num >= 0) num = num*10 + c - '0';
				}
				else break;
				p++;
				len--;
			}
			if (num < 0) {
				num = LONG_MAX;
				ret += 2;
			}
/*
printf("cl_qnconv: len=%d p=[%s] ret=%d num=%d\n",len,p,ret,num);
*/
			if (c) {
				while (len-- > 0) {
					if ((c=*p++)==' ' || c=='\t') ;
					else {
						ret += 4;
						break;
					}
				}
			}
		}
	}
	if (pnum) {
		if (sign_m == 1) num = -num;
		*pnum = num;
	}
	return ret;
}
