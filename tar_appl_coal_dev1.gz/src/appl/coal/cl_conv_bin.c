static	char	sccsid[]="@(#) cl_conv_bin.c 1.2 94/12/13 13:35:09";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ� ( �o�C�i���ϊ� )                              *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_bin( piValue , pcValue )				      *
*                      (O)int		*piValue							      *	
*                      (I)char		*pcValue                                  *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
int cl_conv_bin( pcValue, len, piValue )
unsigned int	*piValue;
char	*pcValue;
int len;
{
	int i, rc;
	unsigned int iValueW, n;

	rc = iValueW = 0;
	for ( i = 0 ; i < len ; i++ ) {
		if (iValueW & 0x80000000) {
			rc = 1;
			break;
		}
		iValueW <<= 1;
		n = pcValue[i] - '0';
		if ( n == 0 )
			;
		else if (n == 1)
			iValueW |= n;
		else {
			rc = -1;
			break;
		}
	}

	*piValue = iValueW;

	return( rc );
}

int cl_conv_oct( pcValue, len, piValue )
unsigned int	*piValue;
char	*pcValue;
int len;
{
	int i, rc;
	unsigned int iValueW, n;

	rc = iValueW = 0;
	for ( i = 0 ; i < len ; i++ ) {
		if (iValueW & 0xa0000000) {
			rc = 1;
			break;
		}
		iValueW <<= 3;
		n = pcValue[i] - '0';
		if ( n>=0 || n<=7 )
			iValueW |= n;
		else {
			rc = -1;
			break;
		}
	}

	*piValue = iValueW;

	return( rc );
}

int cl_conv_hex( pcValue, len, piValue )
unsigned int	*piValue;
char	*pcValue;
int len;
{
	int i, rc;
	unsigned int iValueW, n;
	char c;

	rc = iValueW = 0;
	for ( i = 0 ; i < len ; i++ ) {
		if (iValueW & 0xf0000000) {
			rc = 1;
			break;
		}
		iValueW <<= 4;
		if ((c=pcValue[i])>='0' && c<='9') n = c - '0';
		else if (c>='A' && c<='F') n = c - 'A' + 10;
		else if (c>='a' && c<='f') n = c - 'a' + 10;
		else {
			rc = -1;
			break;
		}
		iValueW |= n;
	}

	*piValue = iValueW;

	return( rc );
}
