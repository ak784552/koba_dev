static char sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �f�[�^�m�[�h�t�B���h�t���[��                           *
*                      �f�[�^�t�B�[���h�ݒ菈��                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_rp_data_nfrm_set( pDNCB , pBuff , len )         *
*                                                                             *
*      ������      �F�@(I) DataNodeCB  *pDNCB                                 *
*                    �@(I) char        *pBuff                                 *
*                    �@(I) int         *len                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include "colmn.h"
extern CLPRTBL CLprocTable;
extern CLCOMMON CLcommon;

int cl_rp_data_nfrm_set( mcat, pDataList ,pKAN, fname )
MCAT          *mcat;
prmList       *pDataList;
tdtINDIRECT_INFO *pKAN;
char          *fname;
{
	int rc, w_len, kan_flg;
	char *p,*pd,Buff[30],*pBuff;
	FILE *fp;
	long lpos;
	tdtINFO_PARM rPrm;

	p     = pDataList->VarBD;
	w_len = pDataList->VarLen;
	kan_flg = 0;
	if ((*p & 0x70) == 0x50 && w_len>6) {
		pd = p + 6;
		if (w_len >= 10) {
			if (!memcmp(p+6,"COMP",4)) pd += 8;
		}
		if (memcmp(pd,"GR",2) && memcmp(pd,"FM",2)) kan_flg = 1;
	}
	if (kan_flg) {
/*
printf("cl_rp_data_nfrm_set:COMP data len=%d\n",w_len);
*/
		if (fp = fopen(akb_akb_home_add(fname),"ab")) {
			rc = fwrite(p+6,w_len-6,1,fp);
			fclose(fp);
			if (rc != 1) return (ERROR);
			pBuff = Buff;
			*pBuff++ = 0xd1;
			*pBuff++ = 4 + pKAN->ini_spos;
			pKAN->ini_dlen = w_len - 6;
			memcpy(pBuff,pKAN,sizeof(tdtINDIRECT_INFO));
			strcpy(pBuff+sizeof(tdtINDIRECT_INFO),fname);
			pKAN->ini_dpos = lpos + w_len - 6;
			p = Buff;
			w_len = pKAN->ini_spos + 6;
		}
		else return -1;
	}

	lpos = mcat->mc_ipos;
	if ((rc=axtmcat(mcat,p,w_len))<0) return rc;
	if (CLcommon.ucByteOrder) {
		cmn_change_data(mcat->mc_bufp+lpos,&rPrm,CLcommon.ucByteOrder);
	}

	return( NORMAL );
}
