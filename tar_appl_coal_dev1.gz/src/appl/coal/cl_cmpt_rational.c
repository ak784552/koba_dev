static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************
*  ���� : �L�������Z����												*
*         ���q(Numerator)/����(Denominator)								*
*  ���� : int cl_cmpt_rational											*
*  ���� : (O)tdtINFO_PARM *pInfoParmW :									*
*         (I)char        *pOprtr     :									*
*         (I)tdtINFO_PARM *pInfoParm1 :									*
*         (I)tdtINFO_PARM *pInfoParm2 :									*
*  �ԋp : ERROR															*
*         NORMAL														*
*************************************************************************/
/********************************************/
/*	  coded by A.Kobayashi() 2025.03.24		*/
/*	  error code : -215260101�`-215269999	*/
/********************************************/
/* 01- cl_xxxx	*/
#include <colmn.h>

extern GlobalCt  *pGlobTable;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
static int _divide_by_zero()
{
	ERROROUT(FORMAT(261));		/* zero�f�B�o�C�h���������܂����B*/
	return ECL_SCRIPT_ERROR;
}

/****************************************/
/*										*/
/****************************************/
static int _yakubun(m1,m1div,m2,m2div,myaku)
MPA *m1,*m1div,*m2,*m2div,*myaku;
{
	int rc,mod;
	MPA *m3,mp3z;

	mod = 0;
	m3 = (MPA *)cl_get_tmpMPA(&mp3z);
	if ((rc=m_mod2(m3,m1div,m1,myaku)) < 0) return rc;
	if (m3->zero) {
		if ((rc=m_mod2(m3,m2div,m2,myaku)) < 0) return rc;
/*
printf("_yakubun: m3->zero=%d\n",m3->zero);
*/
		if (m3->zero) {
			mod = 1;
		}
	}
	return mod;
}

/****************************************/
/*	62									*/
/****************************************/
int _set_rational(pRational,pInfoParm1)
tdtINFO_PARM *pRational,*pInfoParm1;
{
	tdtINFO_PARM	*pm[2],tInfoParm,*pInfo;
	int rc;

	pInfo = &tInfoParm;
	cl_set_parm_mpa(pInfo,m_get_i(1));
	pm[0] = pInfoParm1;
	pm[1] = pInfo;
	rc = cl_gx_range_set(pRational,2,pm,0);
	pRational->pi_alen |= D_AULN_RATIONAL;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_get_rational_mpa(pInfoParm,mpp)
tdtINFO_PARM *pInfoParm;
MPA *mpp[];
{
	int ret,len;
	char *p;

	ret = 0;
	if (mpp && pInfoParm->pi_attr==DEF_ZOK_DECI && (pInfoParm->pi_alen & D_AULN_RATIONAL)) {
		len = pInfoParm->pi_dlen;
		p = pInfoParm->pi_data;
		mpp[0] = (MPA *)p;
		p += len;
		mpp[1] = (MPA *)p;
	}
	else ret = -1;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_rational_conv_real(mp3,pInfoParm)
MPA *mp3;
tdtINFO_PARM *pInfoParm;
{
	MPA *mpp[2],*m1,*m2,*m3,mp3z;
	int ret,len;
	char *p;

	ret = 0;
	if (pInfoParm->pi_attr == DEF_ZOK_DECI) {
		if (!(m3=mp3)) m3 = (MPA *)cl_get_tmpMPA(&mp3z);
		if (pInfoParm->pi_alen & D_AULN_RATIONAL) {
			if (!(ret=cl_get_rational_mpa(pInfoParm,mpp))) {
				if (!(ret=m_div(m3,mpp[0],mpp[1]))) {
					if (!mp3) {
						m_cpy(mpp[0],m3,0);
						pInfoParm->pi_alen &= ~(D_AULN_RANGE_DATA | D_AULN_RATIONAL);
					}
				}
			}
		}
		else {
			m_cpy(m3,(MPA *)pInfoParm->pi_data,0);
		}
	}
	else if (mp3) ret = -1;
/*
printf("cl_rational_conv_real: ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_rational_to_real(pInfoParmW,pInfoParm)
tdtINFO_PARM *pInfoParmW,*pInfoParm;
{
#if 1
	MPA *mp3,mp3z;
	int ret;

	mp3 = (MPA *)cl_get_tmpMPA(&mp3z);
	if ((ret=cl_rational_conv_real(mp3,pInfoParm)) >= 0)
		ret = cl_set_parm_mpa(pInfoParmW,mp3);
	return ret;
#else
	tdtINFO_PARM *ppParm[3],tInfoParm,tInfoParm2,tInfoParm3;
	int ret,iVal[2];

	ppParm[0] = &tInfoParm;
	ppParm[1] = &tInfoParm2;
	ppParm[2] = &tInfoParm3;
	if ((ret=cl_get_range_info(pInfoParm,ppParm,iVal,0)) < 0) return ret;
	return cl_cmpt_math_real(pInfoParmW,"/",ppParm[0],ppParm[1]);
#endif
}

/****************************************/
/*	21									*/
/****************************************/
static int _cmpt_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char *pOperator;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
{
	/* ���q(Numerator)/����(Denominator) */
	tdtINFO_PARM *pRational,tInfo,*ppParm[3],tNumer,tDenom;
	tdtINFO_PARM *pInfo1,*pInfo2;
	int ret,iRATIONAL1,iRATIONAL2,cmp_no,result,i;
	char op;
	MPA *mp,*mpp1[2],*mpp2[2];
	MPA *m0,*m1,*m2,*m3,m0z,m1z,m2z,m3z;

DEBUGOUTL1(120,"_cmpt_rational: pOperator=[%s]",pOperator);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_cmpt_rational: Enter pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                      pInfoParm2=",pInfoParm2,0,0);

	iRATIONAL1 = pInfoParm1->pi_alen & D_AULN_RATIONAL;
	iRATIONAL2 = pInfoParm2->pi_alen & D_AULN_RATIONAL;
	op = *pOperator;
	pInfo1 = pInfoParm1;
	pInfo2 = pInfoParm2;
	if (!iRATIONAL1) {
		pRational = &tNumer;
		if ((ret=_set_rational(pRational,pInfoParm1)) < 0) return ret;
		pInfo1 = pRational;
	}
	if (pInfoParm1 == pInfoParm2)
		pInfo2 = pInfo1;
	else {
		if (!iRATIONAL2) {
			pRational = &tDenom;
			if ((ret=_set_rational(pRational,pInfoParm2)) < 0) return ret;
			pInfo2 = pRational;
		}
	}

	m0 = (MPA *)cl_get_tmpMPA(&m0z);
	m1 = (MPA *)cl_get_tmpMPA(&m1z);
	m2 = (MPA *)cl_get_tmpMPA(&m2z);
	m3 = (MPA *)cl_get_tmpMPA(&m3z);

	if ((ret=cl_get_rational_mpa(pInfo1,mpp1)) < 0) return ret;
	if ((ret=cl_get_rational_mpa(pInfo2,mpp2)) < 0) return ret;
	/* a/b : mpp1[0]/mpp1[1] */
	/* c/d : mpp2[0]/mpp2[1] */
	if (op=='+' || op=='-') {	/* (a/b)+-(c/d)=(a*d+c*b)/(b*d) */
		/* a*d */
		if ((ret=m_mul(m2,mpp1[0],mpp2[1])) < 0) return ret;
		/* c*b */
		if ((ret=m_mul(m3,mpp2[0],mpp1[1])) < 0) return ret;
		/* a*d+c*b */
		if (op == '+') {
			if ((ret=m_add(m0,m2,m3)) < 0) return ret;
		}
		else {
			if ((ret=m_sub(m0,m2,m3)) < 0) return ret;
		}
		/* b*d */
		if ((ret=m_mul(m1,mpp1[1],mpp2[1])) < 0) return ret;
	}
	else if (op == '*') {	/* a*c / b*d */
		/* a*c */
		if ((ret=m_mul(m0,mpp1[0],mpp2[0])) < 0) return ret;
		/* b*d */
		if ((ret=m_mul(m1,mpp1[1],mpp2[1])) < 0) return ret;
	}
	else if (op == '/') {	/* a*d / b*c */
		/* a*d */
		if ((ret=m_mul(m0,mpp1[0],mpp2[1])) < 0) return ret;
		/* b*c */
		if ((ret=m_mul(m1,mpp1[1],mpp2[0])) < 0) return ret;
	}
	else {
		if ((cmp_no=_get_comp_no(pOperator,0)) > 0) {
			/* (a/b)-(c/d) */
			/* a*d */
			if ((ret=m_mul(m2,mpp1[0],mpp2[1])) < 0) return ret;
			/* c*b */
			if ((ret=m_mul(m3,mpp2[0],mpp1[1])) < 0) return ret;
			/* a*d-c*b */
			if ((ret=m_sub(m0,m2,m3)) < 0) return ret;
			if (m0->zero) result = 0;
			else if (m0->sign) result = -1;
			else result = 1;
			i = cl_get_comp_judge(cmp_no,result);
/*
printf("_cmpt_rational: cmp_no=%d result=%d i=%d\n",cmp_no,result,i);
*/
			cl_set_parm_int(pInfoParmW,i);
			return 0;
		}
	}
	/* �L�������� */
	ret = cl_set_parm_mpa2(&tNumer,m0,'P');
	ret = cl_set_parm_mpa2(&tDenom,m1,'P');
	ppParm[0] = &tNumer;
	ppParm[1] = &tDenom;
	if ((ret=cl_adjust_rational(pInfoParmW,ppParm,0)) < 0) return ret;
	return ret;
}

/****************************************/
/*		** ��p							*/
/****************************************/
static int _rational_power(pInfoParmW,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	tdtINFO_PARM *ppParm[3],tNumer,tDenom;
	int ret,i,iVal,sig1,sig2;
	MPA *mp,*mpp1[2];
	MPA *m0,*m1,m0z,m1z;

	cl_get_parm_bin(pInfoParm2,&iVal,"_rational_power");

	if ((ret=cl_get_rational_mpa(pInfoParm1,mpp1)) < 0) return ret;
	if (mpp1[0]->zero) {
		return cl_set_parm_mpa(pInfoParmW,mpp1[0]);
	}
	else {
		m0 = m_get_i(1);
		if (m_is_mpa1a(mpp1[0]) && m_is_mpa1a(mpp1[1])) {
			sig1 = mpp1[0]->sign;
			sig2 = mpp1[1]->sign;
			if ((sig1 && !sig2) || (!sig1 && sig2)) {
				if (iVal & 0x01) sig1 = 1;
				else sig1 = 0;
				mpp1[0]->sign = sig1;
				mpp1[1]->sign = 0;
			}
			cl_gx_copy_info(pInfoParmW,pInfoParm1);
			return 0;
		}
	}

	if (!iVal) {
		m1 = m0;
	}
	else {
		if (iVal < 0) {
			m1 = mpp1[1];
			mpp1[1] = mpp1[0];
			mpp1[0] = m1;
			iVal = -iVal;
		}
		m0 = (MPA *)cl_get_tmpMPA(&m0z);
		m1 = (MPA *)cl_get_tmpMPA(&m1z);
		m_cpy(m0,mpp1[0],0);
		m_cpy(m1,mpp1[1],0);
		for (i=0;i<iVal-1;i++) {
			m_mul1(m0,mpp1[0]);
			m_mul1(m1,mpp1[1]);
		}
	}
	/* �L�������� */
	ret = cl_set_parm_mpa2(&tNumer,m0,'P');
	ret = cl_set_parm_mpa2(&tDenom,m1,'P');
	ppParm[0] = &tNumer;
	ppParm[1] = &tDenom;
	ret = cl_adjust_rational(pInfoParmW,ppParm,0);
	return ret;
}

/****************************************/
/*		abs ��p						*/
/****************************************/
static int _rational_abs(pInfoParmW,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	MPA *mpp[2];
	tdtINFO_PARM tInfo1,tInfo2,*ppParm[2];
	int ret;

	ppParm[0] = &tInfo1;
	ppParm[1] = &tInfo2;
	ret=cl_get_rational_mpa(pInfoParm2,mpp);
	mpp[0]->sign = 0;
	mpp[1]->sign = 0;
	ret = cl_set_parm_mpa2(ppParm[0] ,mpp[0],'P');
	ret = cl_set_parm_mpa2(ppParm[1] ,mpp[1],'P');
	ret = cl_adjust_rational(pInfoParmW,ppParm,0);
	return ret;
}

/****************************************/
/*	01									*/
/****************************************/
int cl_cmpt_math_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char *pOperator;
tdtINFO_PARM *pInfoParm1,*pInfoParm2;
{
	int ret,iParm[5],ope,iREAL;
	long lValz[NMPA_LONG],*lVal;
	char op;
	tdtINFO_PARM InfoParm1,InfoParm2;

DEBUGOUTL2(120,"cl_cmpt_math_rational: pInfoParmW=%08x pOperator=[%s]",pInfoParmW,pOperator);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_math_rational: Enter pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                             pInfoParm2=",pInfoParm2,0,0);

	if (pInfoParm1->pi_attr==DEF_ZOK_FLOA || pInfoParm2->pi_attr==DEF_ZOK_FLOA) {
		iREAL = 1;
	}
	else {
		iREAL = 0;
		op = *pOperator;
		ope = 0;
		if (op=='+' || op=='-' || (op=='*' && pOperator[1]!='*') || op=='/') {
			ret = _cmpt_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
		}
		else if (op=='*' && pOperator[1]=='*' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			ret = _rational_power(pInfoParmW,pInfoParm1,pInfoParm2);
		}
		else if (!stricmp(pOperator,"ABS")) {
			ret = _rational_abs(pInfoParmW,pInfoParm1,pInfoParm2);
		}
		else {
			iREAL = 1;
		}
	}
	if (iREAL) {
		if (pInfoParm1->pi_alen & D_AULN_RATIONAL) {
			if ((ret=cl_rational_to_real(&InfoParm1,pInfoParm1)) < 0) return ret;
			pInfoParm1 = &InfoParm1;
		}
		if (pInfoParm2->pi_alen & D_AULN_RATIONAL) {
			if ((ret=cl_rational_to_real(&InfoParm2,pInfoParm2)) < 0) return ret;
			pInfoParm2 = &InfoParm2;
		}
		ret = cl_cmpt_math_real(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
	}

	return ret;
}

/****************************************/
/*	02									*/
/****************************************/
int cl_func_rational(pInfoParmW,nparm,ppParm)
tdtINFO_PARM *pInfoParmW;
int  nparm;
tdtINFO_PARM **ppParm;
{
	static char *_fn_="cl_func_rational";
	int i,rc,atr1,atr2,iAttr1[5],atr;
	long Val1z[NMPA_LONG*2+1],*Val1;
	double dVal1;
	char *p;
	tdtINFO_PARM *pInfo1,*pInfo2,tInfoParm[2],*ppInfo[2];

	pInfo1 = ppParm[0];
	pInfo2 = ppParm[1];
	if ((pInfo1->pi_alen & D_AULN_RATIONAL) || (pInfo2->pi_alen & D_AULN_RATIONAL)) {
		ERROROUT2(FORMAT(318),_fn_,FORMAT(635));	/* ���f�� *//*%s: %s�͎g�p�ł��܂���B*/
		return ECL_SCRIPT_ERROR;
	}
	atr2 = pInfo2->pi_attr;
	Val1 = cl_get_tmpMPA(Val1z);
	p = "val1:";
	for (i=0;i<2;i++) {
		if ((rc=cl_get_parm_dec(ppParm[i],Val1,p)) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		ppInfo[i] = &tInfoParm[i];
		rc = cl_set_parm_mpa(ppInfo[i],(MPA *)Val1);
		p = "val2:";
	}
	if (cl_is_zero(ppInfo[1])) {
		_divide_by_zero();
		return ECL_SCRIPT_ERROR;
	}
	if ((rc=cl_adjust_rational(pInfoParmW,ppInfo,0)) < 0) return rc;
	return rc;
}

/****************************************/
/*	03									*/
/****************************************/
int cl_adjust_rational(pInfoParmW,ppInfo,opt)
tdtINFO_PARM *pInfoParmW,*ppInfo[];
int opt;
{
	MPA *m1,*m2,*m3,*m4,*m1div,*m2div,*myaku;
	MPA mp3z,mp4z,mp1divz,mp2divz,mpyakuz;
	int rc,mod,n,k,sig,exp1,exp2,len1,len2,sa1,sa2,d1,d2;
	int *sosu,max_sosu,yaku,kk;
	long m1sq,m2sq,msq;
	double dval;

	m1 = (MPA *)ppInfo[0]->pi_data;
	if (m1->zero) {
		return cl_set_parm_mpa(pInfoParmW,m1);
	}
	m2 = (MPA *)ppInfo[1]->pi_data;
	if (m2->zero) {
		_divide_by_zero();
		return ECL_SCRIPT_ERROR;
	}
	if (m2->sign) {
		m2->sign = 0;
		m1->sign = 1 - m1->sign;
	}
	sig = m1->sign;
	m1->sign = 0;

  if (opt) {
	exp2 = m2->exp;
	len2 = m2->len;
/*
printf("cl_adjust_rational: exp2=%d len2=%d\n",exp2,len2);
*/
	if (sa2=len2-exp2-1) {
		m1->exp += sa2;
		m2->exp += sa2;
	}
	exp1 = m1->exp;
	len1 = m1->len;
/*
printf("cl_adjust_rational: exp1=%d len1=%d\n",exp1,len1);
*/
	if (sa1=len1-exp1-1) {
		m1->exp += sa1;
		m2->exp += sa1;
	}
	if (!m_is_mpa1a(m1) && !m_is_mpa1a(m2)) {
	  if (opt) {
	/*	max_sosu = akxg_sosu_tbl(&sosu);	*/
		if ((rc=akxg_sosu_next(0)) < 0) return rc;
		max_sosu = akxg_sosu_next_tbl(NULL);
		max_sosu += max_sosu;
		m1div = (MPA *)cl_get_tmpMPA(&mp1divz);
		m2div = (MPA *)cl_get_tmpMPA(&mp2divz);
		myaku = (MPA *)cl_get_tmpMPA(&mpyakuz);
		m_mpa2d(m1,&dval);
		if (dval >= 4.0) m1sq = sqrt(dval);
		else m_mpa2l(m1,&m1sq);
		m_mpa2d(m2,&dval);
		if (dval >= 4.0) m2sq = sqrt(dval);
		else m_mpa2l(m2,&m2sq);
		kk = 0;
		k = 0;
		while (k < max_sosu) {
		/*	yaku = sosu[k];	*/
			if ((yaku=akxg_sosu_next(-1)) < 0) return yaku;
			else if (!yaku) break;
			if (yaku < 100) myaku = m_get_i(yaku);
			else  m_i2mpa(yaku, myaku);
			if (m_cmp_a(m1,m2) <= 0) {
/*
printf("cl_adjust_rational: k=%d yaku=%d m1sq=%d\n",k,yaku,m1sq);
*/
				if ((mod=_yakubun(m1,m1div,m2,m2div,myaku)) < 0) return mod;
				msq = m1sq;
			/*	if (!mod && yaku>m1sq) break;	*/
			}
			else {
/*
printf("cl_adjust_rational: k=%d yaku=%d m2sq=%d\n",k,yaku,m2sq);
*/
				if ((mod=_yakubun(m2,m2div,m1,m1div,myaku)) < 0) return mod;
				msq = m2sq;
			/*	if (!mod && yaku>m2sq) break;	*/
			}
			if (mod) {
				m_cpy(m1,m1div,0);
				m_cpy(m2,m2div,0);
				if (kk++ > 10) break;
				k = 0;
				akxg_sosu_next(0);
				m_mpa2d(m1,&dval);
				m1sq = sqrt(dval);
				m_mpa2d(m2,&dval);
				m2sq = sqrt(dval);
			}
			else k++;
			if (yaku > msq) break;
		}
/*
printf("cl_adjust_rational: k=%d yaku=%d\n",k,yaku);
*/
	  }
	}
	opt = D_AULN_RAT_YAKUBUN;
  }
	m1->sign = sig;
	rc = cl_gx_range_set(pInfoParmW,2,ppInfo,0);
	pInfoParmW->pi_alen |= D_AULN_RATIONAL | opt;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_rational_yakubun(pInfoParmW,pInfoParm1)
tdtINFO_PARM *pInfoParmW,*pInfoParm1;
{
	tdtINFO_PARM *ppParm[3],tInfo1,tInfo2,tInfo3;
	int ret,iVal[2],opt;
/*
printf("cl_rational_yakubun: pInfoParm1->pi_alen=%04x\n",pInfoParm1->pi_alen);
*/
	if (pInfoParm1->pi_alen & D_AULN_RAT_YAKUBUN) opt = 0;
	else opt = 1;
	ppParm[0] = &tInfo1;
	ppParm[1] = &tInfo2;
	ppParm[2] = &tInfo3;
	if ((ret=cl_get_range_info(pInfoParm1,ppParm,iVal,0)) < 0) return ret;

	/* �L�������� */
	ppParm[0] = &tInfo1;
	ppParm[1] = &tInfo2;
	if ((ret=cl_adjust_rational(pInfoParmW,ppParm,opt)) < 0) return ret;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_rational_comp(ppAns,pOperator,opr,pInfoParm1,pInfoParm2)
char **ppAns,*pOperator;
int opr;
tdtINFO_PARM *pInfoParm1,*pInfoParm2;
{
	tdtINFO_PARM tInfoParmW;
	char *pStr;
	long *pAns;
	int ret;

	if ((ret=_cmpt_rational(&tInfoParmW,pOperator,pInfoParm1,pInfoParm2)) >= 0) {
		pStr = *ppAns;
		pAns = (long *)pStr;
		cl_get_parm_long(&tInfoParmW,pAns,"RATIONAL_COMP");
		ret = DEF_ZOK_BINA;
	}
	return ret;
}
#if 0
/****************************************/
/*		** ��p							*/
/****************************************/
static int _rational_power(pInfoParmW,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	tdtINFO_PARM *ppParm[3],tInfo1,tInfo2,tInfo3,tInfo4,*pInfo1,*pInfo2;
	int ret,iVal[2];

	ppParm[0] = pInfo1 = &tInfo1;
	ppParm[1] = pInfo2 = &tInfo2;
	ppParm[2] = &tInfo3;
	if ((ret=cl_get_range_info(pInfoParm1,ppParm,iVal,0)) < 0) return ret;

	cl_get_parm_bin(pInfoParm2,iVal,"_rational_power");
	if (iVal[0] < 0) {
		pInfo2 = &tInfo1;
		pInfo1 = &tInfo2;
		cl_set_parm_bin(pInfoParm2,-iVal[0]);
	}
	if ((ret=cl_cmpt_math_real(&tInfo3,"**",pInfo1,pInfoParm2)) < 0) return ret;
	if ((ret=cl_cmpt_math_real(&tInfo4,"**",pInfo2,pInfoParm2)) < 0) return ret;

	/* �L�������� */
	ppParm[0] = &tInfo3;
	ppParm[1] = &tInfo4;
	ret = cl_adjust_rational(pInfoParmW,ppParm,0);
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _cmpt_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char *pOperator;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
{
	tdtINFO_PARM *pRational,tInfo,*ppParm[3],tCmplx[4];
	tdtINFO_PARM *pInfo1,*pInfo2,tCmplx1,tCmplx2;
	tdtINFO_PARM tInfoW1,tInfoW2,tInfoW3,tInfoA;
	tdtINFO_PARM tInfoR1,tInfoI1,tInfoR2,tInfoI2;
	long lValrz[NMPA_LONG],*lValr,lValiz[NMPA_LONG],*lVali;
	int ret,iVal[2],iParm[5],iRATIONAL1,iRATIONAL2,iIMAGE1,iIMAGE2,cmp_no,result,i;
	char op;
	MPA *mp;

DEBUGOUTL1(120,"_cmpt_rational: pOperator=[%s]",pOperator);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_cmpt_rational: Enter pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                      pInfoParm2=",pInfoParm2,0,0);

	iRATIONAL1 = pInfoParm1->pi_alen & D_AULN_RATIONAL;
	iRATIONAL2 = pInfoParm2->pi_alen & D_AULN_RATIONAL;
	op = *pOperator;
	pInfo1 = pInfoParm1;
	pInfo2 = pInfoParm2;
	if (!iRATIONAL1) {
		pRational = &tCmplx1;
		if ((ret=_set_rational(pRational,pInfoParm1)) < 0) return ret;
		pInfo1 = pRational;
	}
	if (pInfoParm1 == pInfoParm2)
		pInfo2 = pInfo1;
	else {
		if (!iRATIONAL2) {
			pRational = &tCmplx2;
			if ((ret=_set_rational(pRational,pInfoParm2)) < 0) return ret;
			pInfo2 = pRational;
		}
	}
	if (cl_is_zero(pInfo2)) {
		_divide_by_zero();
		return ECL_SCRIPT_ERROR;
	}
	ppParm[0] = &tInfoR1;
	ppParm[1] = &tInfoI1;
	ppParm[2] = &tInfo;
	if ((ret=cl_get_range_info(pInfo1,ppParm,iVal,0)) < 0) return ret;
	ppParm[0] = &tInfoR2;
	ppParm[1] = &tInfoI2;
	if ((ret=cl_get_range_info(pInfo2,ppParm,iVal,0)) < 0) return ret;
	lValr = cl_get_tmpMPA(lValrz);
	lVali = cl_get_tmpMPA(lValiz);
	if (op=='+' || op=='-') {	/* (a/b)+-(c/d)=(a*d+c*b)/(b*d) */
		/* a*d */
		if ((ret=cl_cmpt_math_real(&tCmplx[2],"*",&tInfoR1,&tInfoI2)) < 0) return ret;
		/* c*b */
		if ((ret=cl_cmpt_math_real(&tCmplx[3],"*",&tInfoR2,&tInfoI1)) < 0) return ret;
		/* a*d+c*b */
		if ((ret=cl_cmpt_math_real(&tCmplx[0],pOperator,&tCmplx[2],&tCmplx[3])) < 0) return ret;
		/* b*d */
		if ((ret=cl_cmpt_math_real(&tCmplx[1],"*",&tInfoI1,&tInfoI2)) < 0) return ret;
	}
	else if (op == '*') {	/* a*c / b*d */
		/* a*c */
		if ((ret=cl_cmpt_math_real(&tCmplx[0],"*",&tInfoR1,&tInfoR2)) < 0) return ret;
		/* b*d */
		if ((ret=cl_cmpt_math_real(&tCmplx[1],"*",&tInfoI1,&tInfoI2)) < 0) return ret;
	}
	else if (op == '/') {	/* a*d / b*c */
		/* a*d */
		if ((ret=cl_cmpt_math_real(&tCmplx[0],"*",&tInfoR1,&tInfoI2)) < 0) return ret;
		/* b*c */
		if ((ret=cl_cmpt_math_real(&tCmplx[1],"*",&tInfoI1,&tInfoR2)) < 0) return ret;
	}
	else {
		if ((cmp_no=_get_comp_no(pOperator,0)) > 0) {
			/* (a/b)-(c/d) */
			/* a*d */
			if ((ret=cl_cmpt_math_real(&tCmplx[2],"*",&tInfoR1,&tInfoI2)) < 0) return ret;
			/* c*b */
			if ((ret=cl_cmpt_math_real(&tCmplx[3],"*",&tInfoR2,&tInfoI1)) < 0) return ret;
			/* a*d-c*b */
			if ((ret=cl_cmpt_math_real(&tCmplx[0],"-",&tCmplx[2],&tCmplx[3])) < 0) return ret;
			mp = (MPA *)tCmplx[0].pi_data;
			if (mp->zero) result = 0;
			else if (mp->sign) result = -1;
			else result = 1;
			i = cl_get_comp_judge(cmp_no,result);
/*
printf("_cmpt_rational: cmp_no=%d result=%d i=%d\n",cmp_no,result,i);
*/
			cl_set_parm_int(pInfoParmW,i);
			return 0;
		}
	}
	/* �L�������� */
	ppParm[0] = &tCmplx[0];
	ppParm[1] = &tCmplx[1];
	if ((ret=cl_adjust_rational(pInfoParmW,ppParm,0)) < 0) return ret;
	return ret;
}
#endif
