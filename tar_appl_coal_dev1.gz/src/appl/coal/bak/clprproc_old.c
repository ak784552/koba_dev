static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clprproc.c>                                                     */
/*      Proc process   �@�@�@                          */
/*                                            (1992/01/10 Ver 0.01) */
/********************************************************************/

#include "colmn.h"          /* �萔��` */

/************************************/
/* _chk_var_name                      */
/************************************/
static int _chk_var_name(name,len)
char *name;
int len;
{
#if 1
	return cl_def_chk_name(name,len,"cl_process_proc","�ϐ���");
#else
	if (len > Var_NM_MAX) {
		ERROROUT2(FORMAT(555),name,len);
		return ECL_SCRIPT_ERROR;
	}
	else if (chk_name(name,len)) {
		ERROROUT1(FORMAT(556),name);
		return ECL_SCRIPT_ERROR;
	}
	return 0;
#endif
}

/************************************/
/*  _ProcClearVar					*/
/************************************/
static int _proc_clear_var(proc)
ProcCT  *proc;
{
	int scope;
	ScrPrCT *scrct;
	Leaf *topleaf;

	if (!(scrct=cl_search_src_ct())) return 0;
/*
printf("_proc_clear_var: varnam=[%s]\n",varnam);
*/
	scope = D_AUX1_GLOBAL_VAR | D_AUX1_PRIVATE_VAR | D_AUX1_LOCAL_VAR;
	topleaf = proc->ProcTop->leftleaf;
	return cl_gx_clear_var_obj(topleaf,NULL,NULL,proc->Obj,scope);
}

/************************************/
/* cl_process_proc                    */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_proc(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	static char *_fn_="cl_process_proc";
	static char *sep=" \t,()";
	static char *attr_sep=" \t()[],'=";
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int   rc,nparm,len,atr0,atr,per_flg,ipa,ix,*pSize,max_pas,iMAIN,nparm2,iParm[4];
	int   sp_save,is,kk_level,lenw,line_len,iSET;
	parmList *prmp[4],qprmp[4],**cmd_prmp,*parmp;
	char  buf[512],w[16],*name,wrk[256],c,*pp,*line;
	Leaf  wleaf;
	GWPRM_S gwprm;
	SSPL_S ssp;
	tdtINFO_PARM	*pInfoParmC,*pInfoParmW,tInfoParm;
	tdtINFO_PARM   ***tbl_pas,***tbl_vnm;
	GXObject *pbxObj;
	XHASHB *pha_vnm;
	tdtArrayIndex *pIndex;

	if (!leaf || !proc) return ECL_SYSTEM_ERROR;

	if (proc->ProcTop != leaf) {
		proc->Nextleaf = leaf->rightleaf;
		return 0;
	}

	if (!(proc->Nextleaf=leaf->leftleaf)) {
		if (leaf->cmd.cid == C_PROC) name = "�葱��";
		else name = "�֐�";
		ERROROUT1(FORMAT(557),name);
		return ECL_SCRIPT_ERROR;
	}
#if 0
#if 0
	ix = cl_gx_set_proc_obj(proc,leaf);
	cl_gx_clear_obj_addr(leaf->leftleaf,proc->Obj+ix,proc->Obj);
#else
	_proc_clear_var(proc);
#endif
#endif

	if (rc=cl_mk_pr_var_set(proc)) return rc;

	pha_vnm = proc->pha_vnam;
	tbl_vnm = proc->pTBL_vnam;

	nparm = leaf->cmd.prmnum;
	cmd_prmp = leaf->cmd.prmp;
	nparm2 = nparm;
	iMAIN = 0;
	if (leaf->cmd.cid == C_FUNCTION) {
		pInfoParmC = proc->Retval;
		if (pInfoParmC->pi_paux) {
			if ((ix=cl_gx_chk_vnam('s',pha_vnm,"My",2)) <= 0) {
				ERROROUT2(FORMAT(558),"My",ix);
				return ECL_SCRIPT_ERROR;
			}
			pInfoParmW = cl_get_var_ent(tbl_vnm,ix);
			if (cl_gx_rep_info_set(pInfoParmW,pInfoParmC->pi_paux,1)) return -1;
DEBUGOUT_InfoParm(194,"cl_process_proc: name=%s",pInfoParmW,"My",0);
		}
#if 0
		for (ix=1;ix<nparm;ix++) {
			if (!stricmp(cmd_prmp[ix]->prp,"AS")) break;
		}
		if (ix < nparm) {
			nparm2 = ix;
			if (++ix >= nparm) {
				/* %s: �ԋp�l�̑����w�肪����܂���B */
				ERROROUT1(FORMAT(498),_fn_);
				return ECL_SCRIPT_ERROR;
			}
			memset(&ssp,0,sizeof(SSPL_S));
			parmp = cmd_prmp[ix];
			if (rc=cl_get_def_attr_SSP_opt(parmp->prp,parmp->prmlen,&ssp,attr_sep,iParm,1)) return rc;
			if (iParm[0] != DEF_ZOK_VARI) {
				if (rc=cl_set_parm_init(pInfoParmC,iParm,D_GX_OPT_ALC_TMP | 0x01)) {
					/* %s: �ԋp�l�̑����w�肪�s���ł��B */
					ERROROUT1(FORMAT(499),_fn_);
					return ECL_SCRIPT_ERROR;
				}
			}
		}
#endif
	}
	else if (!strcmp(proc->ProcNM,"main")) {
		if (rc=cl_prparmset(/*NULL,*/NULL,proc->ProcNM)) return rc;
		iMAIN = 1;
	}

	parmp = cmd_prmp[0];
	if (pbxObj=parmp->bxobj) {
		if (pbxObj->da) proc->ProcPath = pbxObj->da[0];
	}

	if (nparm2 <= 1) return 0;

	max_pas = proc->varnam_pasento;
	tbl_pas = proc->pTBL_pasento;
	pSize = (int *)tbl_pas[0];

	rc = 0;
	memset(&ssp,0,sizeof(SSPL_S));
/*	ssp.sp = 0;	*/
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	pInfoParmW = NULL;
	atr0 = ',';
	per_flg = ipa  = kk_level = is = 0;
#if 1
	if (rc=cl_mk_gp_parm(&mcat,&gwprm,nparm2-1,&(leaf->cmd.prmp[1]))) return rc;
	line = gwprm.line;
	line_len = gwprm.line_len;
	while ((len=akxtgwnsl(line,line_len,&ssp,sep,0x1)) > 0) {
#else
	gwprm.nparam = nparm2 - 1;
	gwprm.maxlen = sizeof(wrk)-1;
	gwprm.parmLp = &(leaf->cmd.prmp[1]);
	gwprm.iparam = 0;
	while ((len=cl_gpgwse(&gwprm,&ssp,sep,1)) > 0) {
#endif
		atr = ssp.attr[0];
		c = *wrk;
/*
printf("cl_process_proc: kk_level=%d is=%d sp=%d atr=%d wrk=[%s]\n",kk_level,is,ssp.sp,atr,wrk);
*/
		if (per_flg) {
#if 1
			if (c == '(') kk_level++;
			else if (c==',' || c == ')') {
				iSET = 0;
				if (c == ')') {
					if (--kk_level < 0) break;
					else if (!kk_level) iSET = 1;
				}
				else {
					if (kk_level == 1) {
						if (atr0 == ',') {
							ipa++;
							is = ssp.sp;
						}
						else iSET = 1;
					}
				}
				if (iSET) {
					ipa++;
					if (ipa<=max_pas || iMAIN) {
						sp_save = ssp.sp;
						lenw = ssp.sp -is - 1;
						pp = line + is;
						ssp.sp = 0;
						if (rc=cl_get_def_attr_SSP_opt(pp,lenw,&ssp,attr_sep,iParm,0x05)) return rc;
printf("cl_process_proc:get_def_attr: sp=%d wrk=[%s]\n",ssp.sp,wrk);
						if (!iParm[0]) ssp.sp = 0;
						if ((len=akxtgwnsl(pp,lenw,&ssp,sep,0x1)) <= 0) {
							ERROROUT1(FORMAT(559),_fn_);
							return ECL_SCRIPT_ERROR;
						}
printf("cl_process_proc:akxtgwnsl: sp=%d wrk=[%s]\n",ssp.sp,wrk);
						if (rc=_chk_var_name(wrk,len)) return rc;
						if ((ix=cl_gx_chk_vnam('s',pha_vnm,wrk,len)) <= 0) {
							ERROROUT2(FORMAT(560),
							          wrk,ix);
							return ECL_SCRIPT_ERROR;
						}
						pInfoParmW = cl_get_var_ent(tbl_vnm,ix);
						if (iParm[0] && iParm[0]!=DEF_ZOK_VARI) {
							if (rc=cl_set_parm_init(pInfoParmW,iParm,D_GX_OPT_ALC_TMP | 0x01)) {
								/* %s: �ԋp�l�̑����w�肪�s���ł��B */
								ERROROUT1(FORMAT(499),_fn_);
								return ECL_SCRIPT_ERROR;
							}
						}
						pInfoParmC = cl_get_var_ent(tbl_pas,ipa);
DEBUGOUT_InfoParm(194,"cl_process_proc:C: ipa=%d",pInfoParmC,ipa,0);
						if (cl_gx_rep_info_set(pInfoParmW,pInfoParmC,1)) {
							return ECL_SCRIPT_ERROR;
						}
DEBUGOUT_InfoParm(194,"cl_process_proc:W: name=%s",pInfoParmW,wrk,0);
						if (clpeeksl(pp,lenw,&ssp,sep,0x1) > 0) {
							ERROROUT2(FORMAT(561),_fn_,wrk);
							return ECL_SCRIPT_ERROR;
						}
						ssp.sp = sp_save;
						is = ssp.sp;
					}
					else {
						ERROROUT(FORMAT(562));
						return ECL_SCRIPT_ERROR;
					}
				}
			}
#else
			if (atr <= 6) {
				ipa++;
				if (ipa<=max_pas || iMAIN) {
					if (rc=_chk_var_name(wrk,len)) return rc;
					if ((ix=cl_gx_chk_vnam('s',pha_vnm,wrk,len)) <= 0) {
						ERROROUT2(FORMAT(563),
						          wrk,ix);
						return ECL_SCRIPT_ERROR;
					}
					pInfoParmW = cl_get_var_ent(tbl_vnm,ix);
					pInfoParmC = cl_get_var_ent(tbl_pas,ipa);
DEBUGOUT_InfoParm(194,"cl_process_proc:C: ipa=%d",pInfoParmC,ipa,0);
					if (cl_gx_rep_info_set(pInfoParmW,pInfoParmC,1)) {
						return ECL_SCRIPT_ERROR;
					}
DEBUGOUT_InfoParm(194,"cl_process_proc:W: name=%s",pInfoParmW,wrk,0);
				/*	_proc_clear_var(proc,wrk,len);	*/
				}
				else {
					ERROROUT(FORMAT(564));
					return ECL_SCRIPT_ERROR;
				}
			}
			else {
				if (c=='(') {
					ERROROUT(FORMAT(565));
					return ECL_SCRIPT_ERROR;
				}
				else if (c==')') {
					per_flg = 0;
					if (cl_gpgwse(&gwprm,&ssp,sep,1) > 0) {
						ERROROUT1(FORMAT(566),wrk);
						return ECL_SCRIPT_ERROR;
					}
					break;
				}
				else if (c==',') {
					if (atr0 == ',') {
						ipa++;
					}
				}
			}
#endif
		}
		else {
			if (atr <= 6) {
				ipa++;
				if (ipa <= 2) {
					if (rc=_chk_var_name(wrk,len)) return rc;
				}
				else {
					ERROROUT1(FORMAT(567),wrk);
					return ECL_SCRIPT_ERROR;
				}
				if (ipa == 1) {
					sprintf(buf,"%s = %d",wrk,max_pas);
/*
printf("cl_process_proc: %s\n",buf);
*/
					if (rc=cl_set_scalar_var_info(buf,NULL,
					        D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_CONST,&pInfoParmW)) break;
					pInfoParmC = cl_var_size_parm(pSize);
					*pInfoParmW = *pInfoParmC;
					pInfoParmW->pi_scale &= ~D_DATA_LPOSDATA;
					pInfoParmW->pi_aux[0] = pInfoParmW->pi_attr;
					pInfoParmW->pi_aux[1]|= D_AUX1_PROTECTED;
					pInfoParmW->pi_paux    = pInfoParmW->pi_data;
				}
				else if (ipa == 2) {
					if (!(ix=max_pas) || iMAIN) ix = pSize[2];
				/*	sprintf(buf,"%%%s 1 %d",wrk,max_pas);	*/
					sprintf(buf,"%%%s 1 %d",wrk,ix);
					memset(&qprmp[0],0,sizeof(parmList)*2);
					qprmp[1].prmlen = strlen(buf);
					qprmp[1].prp = buf;
					qprmp[1].opt = D_GX_OPT_NO_USE_OBJ;
					prmp[1] = &qprmp[1];
/*
printf("cl_process_proc: %s\n",buf);
*/
					if (rc=cl_pr_ex_def_map_ary(2,prmp,NULL,proc,D_GX_OPT_SET_LOCAL)) break;
					if (!max_pas && !iMAIN) {
						strcpy(buf+1,wrk);
						qprmp[1].prmlen = strlen(buf);
						if (rc=cl_conv_parm_opt(&qprmp[1],&tInfoParm,D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_ADDR)) break;
						if (tInfoParm.pi_id == D_DATA_ID_STOREVAR) {
							pInfoParmW = (tdtINFO_PARM *)tInfoParm.pi_pos;
							if (pInfoParmW->pi_id=='A' && pInfoParmW->pi_dlen==sizeof(tdtArrayIndex)) {
								pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
								pIndex->index[1] = 0;
							}
						}
					}
				}
			}
			else {
				if (c=='(') {
					per_flg = kk_level = 1;
					ipa = 0;
					atr = ',';
					is = ssp.sp;
				}
				else if (c==')') {
					if (--kk_level < 0) break;
				}
				else if (c==',') {
					if (atr0 == ',') {
						ipa++;
					}
				}
			}
		}
		if (!stricmp(wrk,"AS")) {
			if (kk_level) {
				ERROROUT1(FORMAT(568),_fn_);
				return ECL_SCRIPT_ERROR;
			}
			else if (leaf->cmd.cid == C_FUNCTION) {
				if ((len=clpeeksl(line,line_len,&ssp,sep,0x1)) <= 0) {
					/* %s: �ԋp�l�̑����w�肪����܂���B */
					ERROROUT1(FORMAT(498),_fn_);
					return ECL_SCRIPT_ERROR;
				}
				pInfoParmC = proc->Retval;
				if (rc=cl_get_def_attr_SSP_opt(line,line_len,&ssp,attr_sep,iParm,1)) return rc;
				if (iParm[0] != DEF_ZOK_VARI) {
					if (rc=cl_set_parm_init(pInfoParmC,iParm,D_GX_OPT_ALC_TMP | 0x01)) {
						/* %s: �ԋp�l�̑����w�肪�s���ł��B */
						ERROROUT1(FORMAT(499),_fn_);
						return ECL_SCRIPT_ERROR;
					}
				}
				break;
			}
		}
		atr0 = atr;
	}
#if 1
	if (!rc && kk_level) {
		ERROROUT2(FORMAT(569),_fn_,kk_level);
		rc = ECL_SCRIPT_ERROR;
	}
#else
	if (!rc && per_flg) {
		ERROROUT(FORMAT(570));
		rc = ECL_SCRIPT_ERROR;
	}
#endif
	return rc;
}

/************************************/
/* cl_process_end_proc                 */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_end_proc(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	char *name;

	if (leaf == NULL) return(ECL_SYSTEM_ERROR);
	if (proc == NULL) return(ECL_SYSTEM_ERROR);

	if (leaf->cmd.cid == C_ENDPROC) name = "�d�m�c�o�q�n�b";
	else name = "�d�m�c�e�t�m�b";
	ERROROUT1(FORMAT(571),name);
	cmn_set_stat(RET_PR,&proc->ptype,L_ON);
	return 0;
}
