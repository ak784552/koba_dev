static char sccsid[]="%Z% %M% %I% %E% %U%";
#include "colmn.h"

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giHOST_ID_SIZE;

/*********************************/
/*								 */
/*								 */
/*	 2010.9.6 Koba				 */
/*								 */
/*********************************/
int cl_rcv_err_msg(pInd)
char *pInd;
{
	tdtINFO_PARM rPrm,rPrmd;
	int rc,len;

/*	if (cmn_chk_data(pInd,&rPrm))	*/
	if (cmn_change_data(pInd, &rPrm, CLcommon.ucByteOrder))
		return ECL_SYSTEM_ERROR;
	if ((rc=cl_code_trans(&rPrm,&rPrmd))<0) return rc;
	else if (rc>0) {
		memcpy(&rPrm,&rPrmd,sizeof(tdtINFO_PARM));
	}
	if((len=rPrm.pi_dlen)>sizeof(pGlobTable->errmsg)-1)
	len = sizeof(pGlobTable->errmsg) - 1;
	memcpy(pGlobTable->errmsg,rPrm.pi_data,len);
	pGlobTable->errmsg[len] = '\0';
	if (rPrmd.pi_data) Free(rPrmd.pi_data);

	return rPrm.pi_len;
}

/************************************************/
/*												*/
/* SearchResult *cl_process_rcv_chg_ptr(pNew)	*/
/*												*/
/*			2010/02/07 by						*/
/*												*/
/************************************************/
SearchResult *cl_process_rcv_chg_ptr(pStart, pNew)
SearchResult *pStart,
*pNew;
{
	SearchResult *pCurr = NULL,
				 *pPrev = NULL;
	
	/* �J�����g�������ʍ\���̂ɐV�\���̂��Z�b�g */
	pCLprocTable->SearchRsltC = pNew;

	if (!pStart) return pNew;

	pCurr = pStart;

	forever {
		if (!pCurr) break;
		if (!strcmp(pCurr->sAreaId,pNew->sAreaId)) {
			if(!pPrev) {
				pStart = pCurr->Next;
#if 1 /* K-00039 */
				if (pCurr->iIndex) Free(pCurr->iIndex - 2);
				if (pCurr->RslBody) Free(pCurr->RslBody);
				if (pCurr->pzFileName) Free(pCurr->pzFileName);
#endif
				Free(pCurr);
				if (!pStart) return pNew;
				break;
			}
			else {
				pPrev->Next = pCurr->Next;
#if 1 /* K-00039 */
				if (pCurr->iIndex) Free(pCurr->iIndex - 2);
				if (pCurr->RslBody) Free(pCurr->RslBody);
				if (pCurr->pzFileName) Free(pCurr->pzFileName);
#endif
				Free(pCurr);
				break;
			}
		}
		pPrev = pCurr;
		pCurr = pCurr->Next;
	}

	pCurr = pStart;

	forever {
		if (!pCurr->Next) {
			pCurr->Next = pNew;
			break;
		}
		else
			pCurr = pCurr->Next;
	}
	return pStart;
}

/************************************/
/*									*/
/* int cl_process_sqlrcv()			*/
/*									*/
/*			2010/02/07 by 			*/
/*									*/
/************************************/
int cl_process_sqlrcv(prmnum, prmp, Obj)
int	  prmnum;
parmList *prmp[];
int	  *Obj;
{
	int		isw  = 0;
	char	 *pdmy;
	char	 *pInd;
	FILE	 *fp   = NULL;
	SearchResult *pSrc = NULL;
	int		  *plIx = NULL;
	tdtINFO_PARM	 rPrm, rPrmc, rParam;
	tdtDbToCol	*pItfce;
	char c;
	int rc,i;
	tdtINFO_PARM	 rInfoParm,*pInfoParm;
	char *p,buf[128];
	parmList *prmw;
	AKAMSGCOM *tpMsgCom;
	long   lret_h;
	ushort usCmdNo_h, usPrmNum_h;
	char   cAreaIdW[AREA_ID_SIZE+1],*pAreaIdW;

	pGlobTable->tuppl = 0;
	pGlobTable->column = 0;
	pGlobTable->errmsg[0] = '\0';
	if (pCLprocTable->PrPacketp == NULL) {
		ERROROUT("cl_process_sqlrcv:pCLprocTable->PrPacketp==NULL");
		return ECL_SYSTEM_ERROR;
	}

	tpMsgCom = (AKAMSGCOM *)pCLprocTable->PrPacketp;
	pdmy = tpMsgCom->msg_pmsg;

	pItfce = (tdtDbToCol *)pdmy;
	pInd   = pdmy + sizeof(tdtDbToCol);
	lret_h = ntohl(pItfce->lret);
	pGlobTable->exception = cl_mk_exception_code(SQL_EXCEPTION,lret_h);
	pGlobTable->error = lret_h;
	strnzcpy(pGlobTable->errmsg,akb_str_error(lret_h),sizeof(pGlobTable->errmsg)-1);

	usCmdNo_h = ntohs(pItfce->usCmdNo);
	if (usCmdNo_h == 1) {
		if (pInfoParm = cl_get_public_var(D_NAM_TRNSHID)) {
			p = pInfoParm->pi_data;
			p += pInfoParm->pi_dlen-1;
			if (*p == '*') {
				pInfoParm->pi_dlen--;
				if (lret_h != NormalEnd) {
					p -= giHOST_ID_SIZE;
					pInfoParm->pi_dlen -= giHOST_ID_SIZE;
				}
				*p = '\0';
			}
		}
		else {
			ERROROUT1(FORMAT(416),D_NAM_TRNSHID);	/* �O���ϐ�%s������`�ł��B */
			return ECL_EX_SQL;
		}
	}

	if (!memcmp(pItfce->cMsgId,"CM",2)) return NormalEnd;
	usPrmNum_h = ntohs(pItfce->usPrmNum);
	if (usPrmNum_h == 1 || usPrmNum_h == 3) {
		if ((rc=cl_rcv_err_msg(pInd))<0) return rc;
		pInd += rc;
		usPrmNum_h--;
	}
	if (lret_h != NormalEnd) {
		if(lret_h == SQLERROR) ERROROUT("illegal SQL Command ");
		return NormalEnd;
	}

	if (usPrmNum_h < 2) return NormalEnd;

	if (rc=cmn_get_data_byte_order(pInd, &rPrm, CLcommon.ucByteOrder)) {
		ERROROUT1("cl_process_sqlrcv: cmn_get_data_byte_order() rc=%d",rc);
		return ECL_SYSTEM_ERROR;
	}
/*
DEBUGOUT_InfoParm(0,"cl_process_sqlrcv:cmn_get_data_byte_order usPrmNum_h=%d",&rPrm,usPrmNum_h,0);
*/
	
	fp = NULL;
	pSrc = NULL;
	plIx = NULL;

	if (!(pSrc=(SearchResult *)Malloc(sizeof(SearchResult)))) {
		ERROROUT("cl_process_sqlrcv: Malloc(sizeof(SearchResult)) error");
		goto Err;
	}
	memset(pSrc,0,sizeof(SearchResult));

	if (prmnum>=4) prmw = prmp[3];
	else prmw = NULL;
	if (rc=cl_get_area_id(prmw,Obj,&pAreaIdW)) {
		ERROROUT1("cl_process_sqlrcv: cl_get_area_id() rc=%d",rc);
		goto Err;
	}
	pSrc->sAreaId = Strdup(pAreaIdW);
/*
printf("*** DataLen=%d\n",rPrm.pi_dlen);
*/
	/* �������ʂ��O */
	if (rPrm.pi_dlen ==  0) {
		if (rPrm.pi_data) Free (rPrm.pi_data);	/* K-00039 */
		strcpy(pSrc->szType, "B");
		pSrc->iIndex    = 0;
		pSrc->iIndexLen = 0;
		pSrc->iTupleNum = 0;
		pSrc->iColmNum  = 0;
		pSrc->iCrTuple  = 0;
		pSrc->Next      = NULL;

		pGlobTable->exception = 0;
		pGlobTable->error = 0;
		pGlobTable->tuppl = 0;
		pGlobTable->column = 0;

		/* *** ��������(%s)�� %d ���ł� */
		PRINTOUT2(FORMAT(417),cAreaIdW,pGlobTable->tuppl);

		pCLprocTable->SearchRsltF = cl_process_rcv_chg_ptr(pCLprocTable->SearchRsltF,pSrc);
		return NormalEnd;
	}

	if (rPrm.pi_id == 'F') {
		if (!(fp = fopen(akb_akb_home_add(rPrm.pi_data), "r"))) {
			ERROROUT1("cl_process_sqlrcv: file[%s] open error",rPrm.pi_data);
			goto Err;
		}
		strcpy(pSrc->szType, "B");

		if (!(pSrc->RslBody = Malloc(rPrm.pi_dlen))) {
			ERROROUT("cl_process_sqlrcv: RslBody Malloc error");
			goto Err;
		}
		if (fread(pSrc->RslBody, 1, rPrm.pi_dlen, fp) != rPrm.pi_dlen) {
			ERROROUT("cl_process_sqlrcv: RslBody fread error");
			goto Err;
		}
		pSrc->pzFileName = rPrm.pi_data;
		pSrc->iDataLen   = rPrm.pi_dlen;

		if (CLcommon.ucByteOrder) {
			for (i=0;i<rPrm.pi_dlen;){
				cmn_change_data((char *)(pSrc->RslBody)+i, &rParam, 1);
				i += rParam.pi_len;
			}
		}
#ifdef MSPACE /* 2000.6.22 Koba */
		lret_h = akxa_ms_alloc(pSrc->sAreaId);
		if (lret_h > 0) {
			rc = akxa_ms_write(lret_h,pSrc->RslBody,0,pSrc->iDataLen);
			if (rc == pSrc->iDataLen) {
				strcpy(pSrc->szType, "M");
				Free(pSrc->RslBody);
				pSrc->RslBody = NULL;
				pSrc->pzFileName = (char *)lret_h;
			}
			else
				ERROROUT1("ms_write error rc=%d",rc);
		}
		else
			ERROROUT2("ms_alloc([%s]) error ret=%d",pSrc->sAreaId,lret_h);
#endif
		
		pInd = (char *)(pInd+rPrm.pi_len);
	/*	cmn_chk_data(pInd, &rPrmc);	*/
		cmn_change_data(pInd, &rPrmc, CLcommon.ucByteOrder);
		
		if (!(plIx = (int *)Malloc(rPrmc.pi_dlen))) {
			ERROROUT("cl_process_sqlrcv:plIx Malloc error");
			goto Err;
		}
		if (fread((char *)plIx, 1, rPrmc.pi_dlen, fp) != rPrmc.pi_dlen) {
			ERROROUT("cl_process_sqlrcv:plIx fread error");
			goto Err;
		}

		if (CLcommon.ucByteOrder)
			for(i=0;i<rPrmc.pi_dlen/4;i++) plIx[i] = ntohl(plIx[i]);

		pSrc->iIndex    = (int *)&plIx[2];
		pSrc->iIndexLen = rPrmc.pi_dlen;
		pSrc->iTupleNum = plIx[0];
		pSrc->iColmNum  = plIx[1];
		pSrc->iCrTuple  = 0;
		pSrc->Next      = NULL;
		pGlobTable->tuppl = pSrc->iTupleNum;
		pGlobTable->column = pSrc->iColmNum;

		fclose(fp);
	}
	else {
		strcpy(pSrc->szType, "B");
		pSrc->pzFileName = NULL;
		pSrc->RslBody    = rPrm.pi_data;
		pSrc->iDataLen   = rPrm.pi_dlen;
		pSrc->Next       = NULL;

		pInd = pInd + rPrm.pi_len;
	/*	cmn_chk_data(pInd, &rPrmc);	*/
		cmn_change_data(pInd, &rPrmc, CLcommon.ucByteOrder);
		if(!(plIx = (int *)Malloc(rPrmc.pi_dlen))) goto Err;
		memcpy((char *)plIx,rPrmc.pi_data,rPrmc.pi_dlen);
	/*
		plIx = (int *)rPrmc.pi_data;
	*/

		if (CLcommon.ucByteOrder)
			for(i=0;i<rPrm.pi_dlen/4;i++) plIx[i] = ntohl(plIx[i]);

		pSrc->iTupleNum = plIx[0];
		pSrc->iColmNum  = plIx[1];
		pSrc->iIndex    = (int *)&plIx[2];
		pSrc->iCrTuple  = 0;
		pSrc->iIndexLen = rPrmc.pi_dlen;
		pGlobTable->tuppl = pSrc->iTupleNum;
		pGlobTable->column = pSrc->iColmNum;
	}
	pCLprocTable->SearchRsltF=cl_process_rcv_chg_ptr(pCLprocTable->SearchRsltF,pSrc);

	/* *** ��������(%s)�� %d ���ł� */
	PRINTOUT2(FORMAT(417),pAreaIdW,pGlobTable->tuppl);
	pGlobTable->exception = 0;
	pGlobTable->error = 0;
	return NormalEnd;
Err:
	if (rPrm.pi_data) Free(rPrm.pi_data);
	if (fp) fclose(fp);
	if (pSrc) {
		if (pSrc->RslBody) Free(pSrc->RslBody);
		Free(pSrc);
	}
	if (plIx) Free(plIx) ;
/*
	ERROROUT("cl_process_sqlrcv:goto Err");
*/
	return ECL_SYSTEM_ERROR;
}
