static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ��������i�E�ӂ��ϐ��̎��j            �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_rep_info_set(pInfoParmO,pInfoParmI)          *
*                      (O)tdtINFO_PARM *pInfoParmO                             *
*                      (I)tdtINFO_PARM *pInfoParmI                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
/*	  error code : -215220101�`-215229999	*/
#include <colmn.h>
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;
extern tdtIterate_ctl gtIter_ctl[];

/*static int _rep_list_info_set();*/
static int _gx_rep_all_data();
static int _check_exist_mk_key(/*mcat,pInfoParm*/);

/****************************************/
/*	01									*/
/****************************************/
static int _val_set_BINA_FLOA(p,atr,size,Val,attr,len,ix)
char *p;
int atr,size,Val[],attr,len,ix;
{
	int rc,iValue;
	char *name,*pV=(char *)Val;
	double dValue;

	name = "_val_set_BINA_FLOA";
/*
printf("%s:Enter p=%08x atr=%d size=%d Val=%08x attr=%d len=%d ix=%d\n",name,p,atr,size,Val,attr,len,ix);
*/
	p += size*ix;
	pV += len*ix;
	if (ix) Val++;
/*
printf("%s: p=%08x pV=%08x Val=%08x\n",name,p,pV,Val);
*/
	if (attr == DEF_ZOK_BINA) iValue = CL_GET_VAL_BIN(Val);
	else memcpy(&dValue,pV,sizeof(double));
	if (atr == DEF_ZOK_BINA) {
		if (attr == DEF_ZOK_FLOA) iValue = cl_chk_over_flow_d2_i(dValue,name);
		*(int *)p = iValue;
DEBUGOUTL2(151,"%s:BINA:%d",name,*(int *)p);
	}
	else {
		if (attr == DEF_ZOK_BINA) dValue = iValue;
		*(double *)p = dValue;
DEBUGOUTL2(151,"%s:FLOA:%e",name,*(double *)p);
	}
	return 0;
}

/****************************************/
/*	01-1								*/
/****************************************/
static int _val_clr(Val,attr,len,ix)
char *Val;
int attr,len,ix;
{
	int rc;
/*
printf("_val_clr:Enter Val=%08x attr=%d len=%d ix=%d\n",Val,attr,len,ix);
*/
	rc = 0;
	Val += len*ix;
/*
printf("_val_clr:Enter Val=%08x\n",Val);
*/
	if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_FLOA) memset(Val,0,len);
	else if (attr == DEF_ZOK_DECI) memcpy(Val,m_get_i(0),len);
	else rc = -1;
	return rc;
}

/****************************************/
/*	02									*/
/****************************************/
static int _val_set_DECI(pInfoParm,p,size,Val,attr,len,ix)
tdtINFO_PARM *pInfoParm;
char *p;
int size,Val[],attr,len,ix;
{
	int rc;
	char *pV=(char *)Val;
	double dValue;

	p += size*ix;
	pV += len*ix;
	if (attr == DEF_ZOK_BINA) {
		m_i2mpa(Val[ix],(MPA *)p);
	}
	else if (attr == DEF_ZOK_FLOA) {
		memcpy(&dValue,pV,len);
		m_d2mpa(dValue,(MPA *)p);
	}
	else memcpy(p,pV,len);
	if (pInfoParm->pi_hlen) {
		if ((rc=cl_mpa_scale(p,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
	}
	return 0;
}

/****************************************/
/*	03									*/
/****************************************/
static char *_set_mem_size_zero(pInfoParm,size,im)
tdtINFO_PARM *pInfoParm;
int size,im;
{
	char *p;
/*
printf("_set_mem_size_zero: pInfoParm->pi_scale=%02x\n",pInfoParm->pi_scale);
*/
	/* 2021.10.6 */
	if (im==D_OPT_ALC_MALLOC && pInfoParm->pi_scale & D_DATA_MALLOC)
		p = Realloc(pInfoParm->pi_data,size);
	else p = cl_opt_malloc(im,size);
	pInfoParm->pi_data = p;
	if (p) {
		pInfoParm->pi_data = p;
		pInfoParm->pi_paux = p;
	}
	return p;
}

/****************************************/
/*	04									*/
/****************************************/
static char *_gx_rep_get_addr_index(pInfoParmI)
tdtINFO_PARM *pInfoParmI;
{
	char id,*p;
	tdtDefType *pDefType;
	tdtArrayIndex *pIndex;

	id = pInfoParmI->pi_id;
	if (id == D_DATA_ID_STRUCT) {
		pDefType = (tdtDefType *)pInfoParmI->pi_data;
		p = (char *)pDefType->pType;
	}
	else if (id==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY) {
		pIndex = (tdtArrayIndex *)pInfoParmI->pi_data;
		if (!(p=(char *)pIndex->xhp)) p = (char *)pIndex->pVarIndex;
	}
	else p = pInfoParmI->pi_data;
	return p;
}

/****************************************/
/*	05									*/
/****************************************/
static int _gx_rep_set_sca_im(sca,im,opt_tmp,add_flag)
int sca,im,opt_tmp,add_flag;
{
	if (!(sca & D_DATA_LPOSDATA)) {
		if (im == D_OPT_ALC_MALLOC) sca |= D_DATA_MALLOC | add_flag;
		else {
			if (opt_tmp > 0) sca |= D_DATA_INDEX_TMP;
			if (im != D_OPT_ALC_MALLOC) sca &= ~D_DATA_MALLOC;
		}
	}
DEBUGOUTL2(180,"_gx_rep_set_sca_im: im=%d sca=%02x",im,sca);
	return sca;
}

/****************************************/
/*	06									*/
/****************************************/
static int _gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
int iOpt;
{
	static char *name = "_gx_rep_val_set";
	int *pi,rc,iValue,iRANGE,dlen1,dlen2,dlen,im,iUNSIGNED,iIMAGE,iNULL_VALUE;
	int  atr,attr,size,iAttr[4],len;
	double dValue,*pd;
	char *p,w1[32],*p1,*pV,c,w2[32],*p2,c1,c2,*ps;
	uchar uSCALE;
	tdtINFO_PARM tInfoParmI;
	time_t tt;
	long lValue,Valz[NMPA_LONG*2],*Val;
	struct  tm *stm;
	tdtINFO_PARM tInfoParm;

	p = pInfoParmO->pi_paux;
	ps = pInfoParmO->pi_data;
	atr = pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA;
	iUNSIGNED = pInfoParmO->pi_scale & D_DATA_UNSIGNED;
/*
printf("%s:Enter atr=%d\n",name,atr);
*/
DEBUGOUTL2(110,"%s:Enter: atr=%d",name,atr);
	c1 = pInfoParmO->pi_id;
	c2 = pInfoParmI->pi_id;
/*
printf("%s:Enter c1=[%c] c2=[%c]\n",name,c1,c2);
*/
  if (c1==' ' && c2==' ') {
	Val = cl_get_tmpMPA2(Valz,2);
	im = (iOpt & D_GX_OPT_ALC_MASK)>>12;
	if (!im) im = D_OPT_ALC_MALLOC;
	if (atr > 0) iAttr[0] = D_GX_OPT_USE_ATTR | atr;
	else iAttr[0] = 0;
	if (pInfoParmO->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA)) {
		return cl_gx_rep_complex(pInfoParmO,pInfoParmI,iOpt);
	}
	len = size = pInfoParmO->pi_len;
	iRANGE = pInfoParmI->pi_alen & D_AULN_RANGE_DATA;
	uSCALE = pInfoParmI->pi_scale & (D_DATA_IMAGE | D_DATA_UNSIGNED);
	iNULL_VALUE = 0;
	if (!(cl_get_option(1,0) & 0x40)) iNULL_VALUE = pInfoParmI->pi_alen & D_AULN_NULL_VALUE;
#ifdef GET_PARM_RANGE
	if (iRANGE = pInfoParmI->pi_alen & D_AULN_RANGE_DATA) {
		if (size>0 && atr!=DEF_ZOK_BINA) {
			if (atr == DEF_ZOK_CHAR) len++;
			len *= 2;
			p = _set_mem_size_zero(pInfoParmO,len);
		}
	}
	pInfoParmO->pi_alen |= iRANGE;
	pInfoParmO->pi_aux[0] = atr | (pInfoParmI->pi_aux[0] & DEF_ZOK_DATA);
	pV = (char *)Val;
#endif
DEBUGOUTL4(151,"%s: atr=%d pi_paux=%08x pi_len=%d",name,atr,p,size);
#ifdef GET_PARM_RANGE
	if (atr == DEF_ZOK_BINA || atr == DEF_ZOK_FLOA) {
		if ((rc=cl_get_parm_range_double(pInfoParmI,Val,"_gx_rep_val_set.BINA/FLOA",iAttr)) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParmO->pi_scale & 0x80) Free(pInfoParmO->pi_data);
		if (rc=_val_set_BINA_FLOA(p,atr,size,Val,iAttr[0],iAttr[1],0)) return rc;
		if (iRANGE) {
			if (rc=_val_set_BINA_FLOA(p,atr,size,Val,iAttr[0],iAttr[1],1)) return rc;
		}
	}
#else
	if (atr == DEF_ZOK_BINA) {
#if defined(_LP64)	/* 2021.9.6 */
		if (size == sizeof(int)) {
			rc = cl_get_parm_ubin(pInfoParmI,Val,"_gx_rep_val_set.BINA",iUNSIGNED);
			if (rc < 0) return rc;
			else if (rc > 0) return ECL_SCRIPT_ERROR;
			*(int *)p = Val[0];
DEBUGOUTL2(151,"%s:BINA:%d",name,*(int *)p);
		}
		else {
#endif
		/*	if (iUNSIGNED)	*/
				rc = cl_get_parm_ulong(pInfoParmI,Val,"_gx_rep_val_set.BINA",iUNSIGNED);
		/*	else
				rc = cl_get_parm_long(pInfoParmI,Val,"_gx_rep_val_set.BINA");	*/
			if (rc < 0) return rc;
			else if (rc > 0) return ECL_SCRIPT_ERROR;
			*(long *)p = Val[0];
DEBUGOUTL2(151,"%s:BINA:%ld",name,*(long *)p);
#if defined(_LP64)	/* 2021.9.6 */
		}
#endif
		pInfoParmO->pi_scale |= uSCALE;
	/*	if (ps != p) *ps = uSCALE;	*/
		pInfoParmO->pi_dlen = size;	/* add 2023.5.5 */
	}
	else if (atr == DEF_ZOK_FLOA) {
		if ((rc=cl_get_parm_double(pInfoParmI,Val,"_gx_rep_val_set.FLOA")) < 0)
			return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParmO->pi_scale & 0x80) Free(pInfoParmO->pi_data);
		memcpy(&dValue,Val,sizeof(double));
		*(double *)p = dValue;
		pInfoParmO->pi_scale |= uSCALE;
	/*	if (ps != p) *ps = uSCALE;	*/
DEBUGOUTL2(151,"%s:FLOA:%f",name,*(double *)p);
	}
#endif
	else if (atr == DEF_ZOK_DECI) {
#ifdef GET_PARM_RANGE
		if ((rc=cl_get_parm_range_mpa(pInfoParmI,Val,"_gx_rep_val_set.DECI",iAttr)) < 0)
			return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (rc=_val_set_DECI(pInfoParmO,p,size,Val,iAttr[0],iAttr[1],0)) return rc;
		if (iRANGE) {
			if (rc=_val_set_DECI(pInfoParmO,p,size,Val,iAttr[0],iAttr[1],1)) return rc;
		}
#else
		if ((rc=cl_get_parm_dec(pInfoParmI,Val,"_gx_rep_val_set.DECI")) < 0)
			return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		memcpy(p,Val,size);
		if (pInfoParmO->pi_hlen) {
			if ((rc=cl_mpa_scale(p,pInfoParmO->pi_hlen,pInfoParmO->pi_pos))<0) return rc;
		}
		pInfoParmO->pi_scale |= uSCALE;
	/*	if (ps != p) *ps = uSCALE;	*/
#endif
	}
	else if (atr == DEF_ZOK_CHAR) {
		p1 = w1;
		if ((rc = parm_to_char(pInfoParmI,&p1,NULL)) < 0) return rc;
		if (iRANGE && size<=0) {
				dlen1 = rc;
				cl_gx_copy_info(&tInfoParmI,pInfoParmI);
				tInfoParmI.pi_aux[0] = tInfoParmI.pi_alen = 0;
				if (tInfoParmI.pi_attr == DEF_ZOK_BINA) tInfoParmI.pi_pos = tInfoParmI.pi_hlen;
				else tInfoParmI.pi_data += tInfoParmI.pi_dlen;
				p2 = w2;
				if ((rc = parm_to_char(&tInfoParmI,&p2,NULL)) < 0) return rc;
				dlen2 = rc;
				if (pInfoParmI->pi_attr == DEF_ZOK_CHAR) dlen = pInfoParmI->pi_dlen;
				else dlen = X_MAX(dlen1,dlen2) + 1;
				if (!(p=_set_mem_size_zero(pInfoParmO,dlen*2,im))) return ECL_MALLOC_ERROR;
				memzcpy(p,p1,dlen1);
				memzcpy(p+dlen,p2,dlen2);
DEBUGOUTL3(151,"%s:CHAR RANGE:[%s]..[%s]",name,p,p+dlen);
				pInfoParmO->pi_dlen = dlen;
				pInfoParmO->pi_alen |= iRANGE;
				pInfoParmO->pi_aux[0] |= pInfoParmI->pi_aux[0] & DEF_ZOK_DATA;
		}
		else {
			if (size <= 0) {
				size = rc;
				if (!(p=_set_mem_size_zero(pInfoParmO,size+1,im))) return ECL_MALLOC_ERROR;
			}
			pInfoParmO->pi_dlen = memnzcpy(p,p1,rc,size+1);
DEBUGOUTL2(151,"%s:CHAR:[%s]",name,p);
		}
	}
	else if (atr == DEF_ZOK_BULK) {
		if (!(p1=_to_bulk(pInfoParmI,iAttr,0))) return iAttr[0];
		if (size <= 0) {
			size = iAttr[1];
			if (!(p=_set_mem_size_zero(pInfoParmO,size+sizeof(int),im))) return ECL_MALLOC_ERROR;
		}
		pInfoParmO->pi_dlen = rc = X_MIN(iAttr[1],size);
		memcpy(p+size,&rc,sizeof(int));
		memcpy(p,p1,rc);
DEBUGOUTL3(151,"%s:BULK:size=%d len=%d",name,size,rc);
	}
	else if (atr == DEF_ZOK_DATE) {
		if (rc=cl_get_parm_date(pInfoParmI,p,"DATE")) return rc;
DEBUGOUT_InfoParm(151,"cl_get_parm_date: size=%d",pInfoParmO,size,0);
	}
	if (iNULL_VALUE) pInfoParmO->pi_alen |= iNULL_VALUE;
	else pInfoParmO->pi_alen &= ~D_AULN_NULL_VALUE;
  }
  else if (c1 == 'T') {
		if (c1 == c2) {
			if ((p1=(char *)pInfoParmO->pi_pos) && (p2=(char *)pInfoParmI->pi_pos)) {
				len  = cl_get_struct_name_len(p1);
				size = cl_get_struct_name_len(p2);
				if (!_memcmplen(p1,len,p2,size,0)) {
#if 1	/* 2021.2.26 */
					cl_free_info_parm(pInfoParmO);
#endif
					/* 2022.9.18 */
					if ((rc=_gx_rep_all_data(pInfoParmO,pInfoParmI,NULL,iOpt)) < 0) return rc;
				}
				else {
							/* %s: �\���̒�`�����قȂ��Ă��܂��B(����=%s �E��=%s) */
					ERROROUT3(FORMAT(614),name,p1,p2);
					return ECL_SCRIPT_ERROR;
				}
			}
			else {
				ERROROUT1(FORMAT(615),name);	/* %s: �\���̒�`�����m�F�ł��܂���B*/
				return ECL_SCRIPT_ERROR;
			}
		}
		else {
					/* %s: �f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B*/
			ERROROUT3(FORMAT(613),name,c1,c2);
			return ECL_SCRIPT_ERROR;
		}
  }
  else {
  		if (c1 == ' ') {
			cl_print_attr(w2,sizeof(w2),pInfoParmO,NULL);
					/* %s: �f�[�^����(id1=[%c] atr=%s id2=[%c])�������Ă��܂���B*/
			ERROROUT4(FORMAT(652),name,c1,w2,c2);
		}
		else {
			p = (char *)pInfoParmO->pi_pos;
			/* 2021.8.2 */
					/* %s: %s(%s)�ւ̑���͂ł��܂���B */
			ERROROUT3(FORMAT(132),name,cl_gx_get_name_from_id(c1),nval1(p));
		}
  		return ECL_SCRIPT_ERROR;
  }
	pInfoParmO->pi_aux[1] &= ~(D_AUX1_PROTECTED | D_AUX1_HASHED_NAME);
	pInfoParmO->pi_alen |= pInfoParmI->pi_alen & D_AULN_FILE_POINTER;
DEBUGOUT_InfoParm(151,"%s: pInfoParmO:",pInfoParmO,name,0);
/*
printf("%s:Exit\n",name);
*/
DEBUGOUTL1(110,"%s:Exit",name);
	return 0;
}

/****************************************/
/*	11									*/
/****************************************/
static int _rep_list_copy(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
int iOpt;
{
	tdtINFO_PARM *p,*pInfoParm;
	int rc=0,iCHK;
	tdtRB_CTL *pCt,*pCtI;

DEBUGOUTL1(110,"_rep_list_copy:Enter: iOpt=0x%08x",iOpt);
/*
printf("_rep_list_copy:Enter: iOpt=0x%08x\n",iOpt);
*/
	if (iOpt & D_GX_OPT_ALC_TMP) return _tmp_list_copy(pInfoParmO,pInfoParmI);

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"_rep_list_copy");
		return 0;
	}
	if (!(pCt = akxs_rb_new(0,0))) return ECL_MALLOC_ERROR;
	if (pInfoParmI->pi_aux[0] & DEF_ZOK_DATA) iOpt |= D_REP_OPT_DATA_MODE;
	iCHK = iOpt & D_REP_CHK_UNDEF_IN;
	pInfoParmO->pi_data = (char *)pCt;
	pInfoParmO->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
	pCtI = (tdtRB_CTL *)pInfoParmI->pi_data;
	akxs_rb_read(pCtI,0);
	while (p=(tdtINFO_PARM *)akxs_rb_read(pCtI,1)) {
		if (iCHK) {
			if (p->pi_id == D_DATA_ID_UNDEFVAR) {
				rc = ECL_NDEFVAR_ERROR;
				break;
			}
		}
		if (!(pInfoParm=(tdtINFO_PARM *)Malloc(sizeof(tdtINFO_PARM))))
			return ECL_MALLOC_ERROR;
		rc = _rep_list_info_set(pInfoParm,p,iOpt);
DEBUGOUT_InfoParm(198,"_rep_list_copy: ",pInfoParm,0,0);
		if (!akxs_rb_set_n(pCt,pInfoParm)) return ECL_MALLOC_ERROR;
	}
	return rc;
}

/****************************************/
/*	12									*/
/****************************************/
int _rep_list_info_set(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt;
{
	char c;
	int rc;

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"_rep_list_info_set");
		return 0;
	}
	if (pInfoParmI->pi_id == 'S') {
		pInfoParmI = (tdtINFO_PARM *)pInfoParmI->pi_pos;
	}
	if (pInfoParmI->pi_aux[0] & D_AUX0_ZOK_DATA) iOpt |= D_REP_OPT_DATA_MODE;
/*
printf("_rep_list_info_set: iOpt=0x%08x id=[%c]\n",iOpt,pInfoParmI->pi_id);
*/
	*pInfoParmO = *pInfoParmI;
	if ((c=pInfoParmO->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
		if ((rc=_rep_list_copy(pInfoParmO,pInfoParmI,iOpt)) > 0) rc = 0;
	}
	else {
		rc = cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt/* & 0x03*/);
	}
	return rc;
}

/****************************************/
/*	15									*/
/****************************************/
int cl_gx_rep_complex(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
int iOpt;
{
	static char *name = "cl_gx_rep_complex";
	int *pi,rc,iValue,iRANGE,dlen1,dlen2,dlen,im,iUNSIGNED,iIMAGE;
	int  atr,attr,size,iAttr[4],len;
	double dValue,*pd;
	char *p,w1[32],*p1,*pV,c,w2[32],*p2,c1,c2,*ps;
	uchar uSCALE;
	tdtINFO_PARM tInfoParmW,tInfoParm;
	time_t tt;
	long lValue,Valz[NMPA_LONG*2],*Val;
	struct  tm *stm;

	p = pInfoParmO->pi_paux;
/*
printf("%s:Enter p=%08x\n",name,p);
*/
	ps = pInfoParmO->pi_data;
	atr = pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA;
	iUNSIGNED = pInfoParmO->pi_scale & D_DATA_UNSIGNED;
	len = size = pInfoParmO->pi_len;
/*
printf("%s:Enter atr=%d\n",name,atr);
*/
DEBUGOUTL2(110,"%s:Enter: atr=%d",name,atr);
	Val = cl_get_tmpMPA2(Valz,2);
	im = (iOpt & D_GX_OPT_ALC_MASK)>>12;
	if (!im) im = D_OPT_ALC_MALLOC;
	if (atr > 0) iAttr[0] = D_GX_OPT_USE_ATTR | atr;
	else iAttr[0] = 0;

	iRANGE = pInfoParmI->pi_alen & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
	if (atr==DEF_ZOK_BINA || atr==DEF_ZOK_FLOA) {
		if ((rc=cl_get_parm_range_double(pInfoParmI,Val,"cl_gx_rep_complex.BINA/FLOA",iAttr)) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (rc=_val_set_BINA_FLOA(p,atr,size,Val,iAttr[0],iAttr[1],0)) return rc;
		if (!iRANGE) {
			if ((rc=_val_clr(Val,iAttr[0],iAttr[1],1)) < 0) return rc;
		}
		if (rc=_val_set_BINA_FLOA(p,atr,size,Val,iAttr[0],iAttr[1],1)) return rc;
/*
printf("cl_gx_rep_complex: *p=%d\n",*(int *)p);
*/
/*
cl_get_range_str(pInfoParmO,&p1);
printf("cl_gx_rep_complex: p1=[%s]\n",p1);
akxaxdump("1",p,size*2);
*/
	}
	else if (atr == DEF_ZOK_DECI) {
		if ((rc=cl_get_parm_range_mpa(pInfoParmI,Val,"cl_gx_rep_complex.DECI",iAttr)) < 0)
			return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (rc=_val_set_DECI(pInfoParmO,p,size,Val,iAttr[0],iAttr[1],0)) return rc;
		if (!iRANGE) {
			if ((rc=_val_clr(Val,iAttr[0],iAttr[1],1)) < 0) return rc;
		}
		if (rc=_val_set_DECI(pInfoParmO,p,size,Val,iAttr[0],iAttr[1],1)) return rc;
	}
DEBUGOUT_InfoParm(120,"cl_gx_rep_complex: pInfoParmO=",pInfoParmO,0,0);
	if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
	return 0;
}

/****************************************/
/*	16									*/
/****************************************/
int cl_gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
int iOpt;
{
	int ret,aux0,len;
	char *paux;
	tdtINFO_PARM tInfoParm,*pInfoParm;

DEBUGOUT_InfoParm(120,"cl_gx_rep_val_set: pInfoParmO=",pInfoParmO,0,0);
DEBUGOUT_InfoParm(120,"cl_gx_rep_val_set: pInfoParmI=",pInfoParmI,0,0);
	if (pInfoParmO->pi_paux && (pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA)) {
		ret = _gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt);
	}
	else {
		tInfoParm = *pInfoParmO;
		len  = tInfoParm.pi_len;
		paux = tInfoParm.pi_paux;
		aux0 = tInfoParm.pi_aux[0];
		tInfoParm.pi_paux   = tInfoParm.pi_data;
		tInfoParm.pi_aux[0] = tInfoParm.pi_attr;
		ret = _gx_rep_val_set(&tInfoParm,pInfoParmI,iOpt);
		tInfoParm.pi_len = len;
		tInfoParm.pi_paux   = paux;
		tInfoParm.pi_aux[0] = aux0;
	}
	return ret;
}

/****************************************/
/*	17									*/
/****************************************/
int cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt0)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	char c,id,*p,*pp;
	uchar aux0;
	int  rc,len,attr,alen,im,iOpt,iRANGE,len1,iFUNC,sca,aux1_scope,opt2,mask,iDCOPY;
	long *argv[2],lVal,lCount;
	tdtINFO_PARM *pInfoParm;
	tdtRB_CHAIN *xha;

DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data:Enter: iOpt0=%08x pInfoParmO=",pInfoParmO,iOpt0,0);
DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data: pInfoParmI=",pInfoParmI,0,0);

	if (iOpt0 < 0) {
		iOpt = -1;
		iOpt0 = 0;
	}
	else iOpt = iOpt0 & 0x03;

	pInfoParmO->pi_aux[1] &= ~(D_AUX1_PROTECTED | D_AUX1_HASHED_NAME | D_AUX1_VAR_SCOPE);

	id = pInfoParmO->pi_id;
	if ((aux0=pInfoParmO->pi_aux[0]) & ~DEF_ZOK_DATA) {
		/* aux0���A0x15(21),0x16(22),0x17(23) �łȂ���΁A�N���A���� */
		if (!(aux0 & 0x10)) {
			/* 2023.8.23 */
			mask = DEF_ZOK_DATA | D_AUX0_VAR_EXPORT;
			if (id==' ' && (cl_get_option(2,0) & 0x800)) mask |= D_AUX0_ZOK_MASK;
			pInfoParmO->pi_aux[0] &= mask;
		}
		pInfoParmO->pi_alen &= (D_AULN_RANGE_DATA | D_AULN_RANGE_INTVAL | D_AULN_COMPLEX_DATA);
		if (id!='A' && id!='R') pInfoParmO->pi_paux = NULL;
	}

	if (!(im=(iOpt0 & D_GX_OPT_ALC_MASK)>>12)) im = D_OPT_ALC_MALLOC;
	if (pInfoParmO->pi_scale & D_DATA_LPOSDATA) {
#if 1	/* 2021.8.6 */
		if (id == D_DATA_ID_PNAME) {
			pInfoParmO->pi_scale &= ~D_DATA_INDEX_FREE;
			if (iOpt >= 1) {
				if (!(p=cl_opt_malloc(im,sizeof(tdtINFO_PARM)))) {
					if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
					return ECL_MALLOC_ERROR;
				}
				rc = cl_gx_rep_info_set_ign(p,pInfoParmO->pi_pos,1 | (iOpt0 & D_GX_OPT_ALC_MASK));
				pInfoParmO->pi_scale = _gx_rep_set_sca_im(pInfoParmO->pi_scale,im,0,D_DATA_INDEX_FREE);
				pInfoParmO->pi_pos = (long)p;
			}
		}
#endif
		pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
	}
	else if (iOpt >= 1) {
		iRANGE = pInfoParmI->pi_alen & D_AULN_RANGE_DATA;
		pInfoParmO->pi_scale &= ~(D_DATA_MALLOC | D_DATA_INDEX_FREE);
		iDCOPY = 1;
		if (id=='L' || id=='N') {
			if (!(iOpt0 & D_REP_OPT_LN_DCOPY)) iDCOPY = 0;
		}
		else if (id=='A' || id=='R') {
			if (iOpt0 & D_REP_OPT_AR_NCOPY) iDCOPY = 0;
		}
		if (pInfoParmI->pi_dlen>0 && iDCOPY) {
			alen = len = pInfoParmI->pi_dlen;
			iFUNC = 0;
			if ((id=pInfoParmI->pi_id)==' ' || id=='U') {
				attr = pInfoParmI->pi_attr;
				if (attr==DEF_ZOK_CHAR) alen++;
				else if (attr==DEF_ZOK_BULK) alen += sizeof(int);
				if (iRANGE) {
					len1 = alen;
					alen = len1 + len1;
					if (attr==DEF_ZOK_DATE ||
					    (attr!=DEF_ZOK_BINA && (pInfoParmI->pi_alen & D_AULN_RANGE_INTVAL))) alen += len1;
				}
			}
			/* 2021.6.30 */
			else if (strchr("FCIMO",id)) {
				alen++;
				iFUNC = 1;
			}
			if (!(p=cl_opt_malloc(im,alen))) {
				if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
				return ECL_MALLOC_ERROR;
			}
			pInfoParmO->pi_data = p;
			pInfoParmO->pi_scale = _gx_rep_set_sca_im(pInfoParmO->pi_scale,im,0,0);
DEBUGOUTL2(180,"cl_gx_rep_info_copy_data: p=%08x pInfoParmO=%08x",p,pInfoParmO);
/*
printf("cl_gx_rep_info_copy_data: p=%08x pInfoParmI->pi_data=%08x\n",p,pInfoParmI->pi_data);
*/
			memcpy(p,pInfoParmI->pi_data,alen);
			p += len;
			if ((id=pInfoParmO->pi_id)==' ' || id=='U') {
				if (attr==DEF_ZOK_CHAR && !iRANGE) *p = '\0';
			}
			/* 2021.6.30 */
			else if (iFUNC) *p = '\0';
		}
		/* 2021.8.5 */
		if ((c=pInfoParmO->pi_id)=='A' || c=='R' || c=='P' || c=='T') {
			if (p=(char *)pInfoParmI->pi_pos) {
				/* 2022.9.20 */
				if (!(pp=cl_opt_malloc(im,strlen(p)+1))) {
					if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
					return ECL_MALLOC_ERROR;
				}
				strcpy(pp,p);
				pInfoParmO->pi_pos = (long)pp;
				if (im == D_OPT_ALC_MALLOC)
					pInfoParmO->pi_alen &= ~D_AULN_NO_AL_LPOS;
				else
					pInfoParmO->pi_alen |= D_AULN_NO_AL_LPOS;
			}
		}
		if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
	}
	if (iOpt <= 1) {
		if ((c=pInfoParmO->pi_id)=='A' || c=='R' || c=='P' || c=='T') {
		/*	pInfoParmO->pi_scale &= ~(D_DATA_MALLOC | D_DATA_INDEX_FREE);	*/
			pInfoParmO->pi_scale &= ~D_DATA_INDEX_FREE;
		/*	pInfoParmO->pi_alen |= D_AULN_NO_AL_LPOS;	del 2021.8.5 */
		}
	}
#if 1	/* 2024.3.29 */
	if ((id=pInfoParmO->pi_id)=='A' || id=='R') {
		if (p = (char *)pInfoParmO->pi_pos) {
			if (*p == '%') pInfoParmO->pi_aux[1] |= D_AUX1_PROTECTED;
		}
	}
#endif
	/* 2022.9.17 */
	if ((c=pInfoParmO->pi_id)=='I' || c=='C') {
/*
printf("cl_gx_rep_info_copy_data: pInfoParmI=%08x pi_scale=%02x\n",pInfoParmI,pInfoParmI->pi_scale);
*/
		if (pInfoParmI->pi_scale & D_DATA_ORG_PROC) {
			pInfoParmO->pi_scale |= D_DATA_CLEAR_PROC;
			pInfoParmO->pi_scale &= ~D_DATA_ORG_PROC;
		}
		else {
			pInfoParmO->pi_scale &= ~D_DATA_CLEAR_PROC;
		}
/*
printf("cl_gx_rep_info_copy_data: pInfoParmO=%08x pi_scale=%02x\n",pInfoParmO,pInfoParmO->pi_scale);
*/
	}
	if (c==' ' && (pInfoParmO->pi_aux[0] & D_AUX0_ZOK_MASK))
		pInfoParmO->pi_paux = pInfoParmO->pi_data;

DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data: pInfoParmO=",pInfoParmO,0,0);
	return 0;
}
/*	18	*/
/************************************************************/
/*	iOpt0 < 0 --> iIGN=1, iOpt<0, iOpt0=0x10				*/
/*	iOpt0 = 0x7000 (D_GX_OPT_ALC_MASK) 						*/
/*	      | 0x0003 (iOpt)									*/
/*	      | 0x0010 (ignore data of pInfoParmO)				*/
/*	      | 0x0020 (check undef of pInfoParmI)				*/
/*	      | 0x0100 (�f�[�^�^�C�v�Œ莞�̕ϊ��̂�)			*/
/*	      | 0x0200 (�ċArep�̂�)							*/
/*	      | 0x0400 (data rep�̂�)							*/
/*	      | 0x010000 (data mode�łȂ���΁A��`�̂݃R�s�[	*/
/*										add 2022.9.19		*/
/*	      | 0x020000 (�������)			add 2022.9.22		*/
/*	      | 0x040000 (L,N�̂Ƃ��Api_data���R�s�[����)		*/
/*	      | 0x080000 (data mode)		add 2022.9.18		*/
/*	      | 0x100000 (A,R�̂Ƃ��Api_data���R�s�[���Ȃ�)		*/
/*	iOpt = 0 : copy only									*/
/*	    >= 1 : copy & Malloc to_pi_data						*/
/*	    >= 2 : copy & Malloc to_pi_data & Free from_pi_data	*/
/************************************************************/
int cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt0,name)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt0;
char *name;
{
	char c,id,*p;
	int  rc,len,attr,alen,iOpt,iIGN,iAux0,iOpt1,iOptSel;
	int  iOptListCopy,iOptAllData,iAux0DataMode,iOpt2,iOptDefOnly,iOptDataMode;
	ScrPrCT *scrct;
	ProcCT  *proc;
	uchar aux1_scope;
/*
printf("cl_gx_rep_info_set_name:Enter: iOpt0=%08x pInfoParmO=%08x pInfoParmI=%08x\n",iOpt0,pInfoParmO,pInfoParmI);
*/
DEBUGOUTL2(110,"cl_gx_rep_info_set_name:Enter: iOpt0=%08x name=[%s]",iOpt0,nval1(name));
if (iOpt<0 || (iOpt & 0x10)) {
DEBUGOUTL1(170,"cl_gx_rep_info_set_name:O: pInfoParmO=%08x",pInfoParmO);
}
else {
DEBUGOUT_InfoParm(170,"cl_gx_rep_info_set_name:O: ",pInfoParmO,0,0);
}
DEBUGOUT_InfoParm(170,"cl_gx_rep_info_set_name:I: ",pInfoParmI,0,0);

	if (!pInfoParmO || !pInfoParmI) return -1;

	if (iOpt0 & D_REP_CHK_UNDEF_IN) {
		if (pInfoParmI->pi_id == D_DATA_ID_UNDEFVAR) {
			return ECL_NDEFVAR_ERROR;
		}
	}
	if (pInfoParmO == pInfoParmI) {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"cl_gx_rep_info_set_name");
		return 0;
	}

	iOptDefOnly = iOpt0 & D_REP_OPT_DEF_ONLY;
	iOpt0 &= ~D_REP_OPT_DEF_ONLY;
	if (iOpt0 < 0) {
		iOptSel = 0;
		iOpt = -1;
		iIGN = 1;
		iOpt0 = D_REP_IGN_OUT_DATA;
		iOpt1 = 0;
	}
	else {
		if (!(iOptSel = iOpt0 & D_REP_OPT_SEL_MASK)) iOptSel = D_REP_OPT_SEL_MASK;
		iOpt = iOpt0 & D_REP_OPT_CPY_MASK;
		iIGN = iOpt0 & D_REP_IGN_OUT_DATA;
		iOpt1 = iOpt;
	}
	aux1_scope = 0;
	if (!iIGN) {	/* pInfoParmO�̐ݒ�𖳎����Ȃ��Ƃ� */
		aux1_scope = pInfoParmO->pi_aux[1] & D_AUX1_VAR_SCOPE;
	  if (iOptSel & D_REP_OPT_SEL_CNVT) {
		/* 2021.3.27 */
		/* �f�[�^�^�C�v�Œ�̂Ƃ��́A���̃^�C�v�ɕϊ����� */
		if (pInfoParmO->pi_id==' ' && (pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA)) {
			rc = _gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt0);
			if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
			return rc;
		}
	  }
	}
/*
scrct = cl_search_src_ct();
if (scrct) {
DEBUGOUTL3(110,"cl_gx_rep_info_set_name:1: scrct=%08x ProCT=%08x Vary=%08x",scrct,scrct->ProCT,scrct->Vary);
DEBUGOUT_InfoParm(110,"cl_gx_rep_info_set_name:1: ",pInfoParmO,0,0);
}
*/
/*
printf("cl_gx_rep_info_set_name: iIGN=%d iOpt=%08x\n",iIGN,iOpt);
*/
	if (!iIGN && (iOpt>=0)) cl_free_info_parm(pInfoParmO);

	*pInfoParmO = *pInfoParmI;
	if (!(id=pInfoParmO->pi_id)) return 0;
/*
printf("cl_gx_rep_info_set_name: id=%02x\n",id);
*/
	if (!akxm_addrchk(pInfoParmI->pi_data)) return ECL_SYS_INVALID_ADDR;

	pInfoParmO->pi_scale &= ~D_DATA_MALLOC;
	pInfoParmO->pi_alen &= ~D_AULN_DATA_NARABI;
	if (!iIGN) {
		if ((pInfoParmI->pi_aux[0] & DEF_ZOK_DATA) ||
		    id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) pInfoParmO->pi_aux[1] = aux1_scope;
	}
  if (iOptSel & D_REP_OPT_SEL_RCSV) {
	iOptDataMode = 0;	/*iOpt0 & D_REP_OPT_DATA_MODE;*/
	iAux0DataMode = pInfoParmI->pi_aux[0] & D_AUX0_ZOK_DATA;
	if (iAux0DataMode || iOptDataMode) iOptDefOnly = 0;
	/* 2022.9.18 */
/*
printf("cl_gx_rep_info_set_name: id=%c iOptDefOnly=%08x iAux0DataMode=%08x\n",id,iOptDefOnly,iAux0DataMode);
*/
	if (((id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) && !iOptDefOnly) ||
	    ((id==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY || id==D_DATA_ID_STRUCT) &&
	      (iAux0DataMode || (pInfoParmI->pi_scale & D_DATA_INDEX_TMP)))) {	/* add 2021.9.9 */
/*
printf("cl_gx_rep_info_set_name: uc=%02x\n",uc);
*/
		iOpt2 = iOpt1 | iOptDataMode;
		if (iAux0DataMode) iOpt2 |= D_REP_OPT_DATA_MODE;
		/* 2022.9.18 */
		if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
			iOptListCopy = iOpt2 | (iOpt0 & (D_REP_CHK_UNDEF_IN | D_GX_OPT_ALC_TMP));
			rc = _rep_list_copy(pInfoParmO,pInfoParmI,iOptListCopy);
		}
		else {
			iOptAllData = iOpt2;
			rc = _gx_rep_all_data(pInfoParmO,pInfoParmI,name,iOptAllData);
		}
		if (!rc) {
			/* 2023.1.31 */
			pInfoParmO->pi_hlen = _get_gid(NULL,NULL,cl_gx_get_opt_from_aux1(aux1_scope));
			pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
		}
		return rc;
	}
  }
  if (iOptSel & D_REP_OPT_SEL_DATA) {
	if (rc=cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt0)) return rc;
	pInfoParmO->pi_aux[1] |= aux1_scope;	/* add 2021.9.14 */

	if (pInfoParmO->pi_id=='I' && iOpt>0 && name) {
		Free(pInfoParmO->pi_data);
		pInfoParmO->pi_data = Strdup(name);
		pInfoParmO->pi_dlen = strlen(name);
	}
#if 1	/* 2024.5.14 */
	if ((pInfoParmO->pi_aux[1] & D_AUX1_PUBLIC_VAR) && name) {
		cl_set_sys_value_from_public_var(pInfoParmO,name);
	}
#endif
/*
if (scrct) {
DEBUGOUTL3(110,"cl_gx_rep_info_set_name:2: scrct=%08x ProCT=%08x Vary=%08x",scrct,scrct->ProCT,scrct->Vary);
}
*/
DEBUGOUT_InfoParm(110,"cl_gx_rep_info_set_name:Exit: O:",pInfoParmO,0,0);
/*
printf("cl_gx_rep_info_set_name:Exit ret=0\n");
*/
DEBUGOUTL(110,"cl_gx_rep_info_set_name:Exit ret=0");
  }
	return NORMAL;
}

/****************************************/
/*	19									*/
/****************************************/
int cl_gx_rep_info_set(pInfoParmO ,pInfoParmI ,iOpt)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt;
{
	return cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt,NULL);
}

/****************************************/
/*	20									*/
/****************************************/
int cl_gx_rep_info_set_alloc(pvParmO,pInfoParmI,opt)
tdtINFO_PARM **pvParmO,*pInfoParmI;
int opt;
{
	tdtINFO_PARM *pParm;

	/* 2021.9.9 */
	if (!(pParm=(tdtINFO_PARM *)cl_tmp_const_malloc(sizeof(tdtINFO_PARM)))) return -1;
	*pvParmO = pParm;
	return cl_gx_rep_info_set_ign(pParm,pInfoParmI,opt|D_GX_OPT_ALC_TMP);
}

/****************************************/
/*	21									*/
/****************************************/
int cl_gx_rep_info_set_ign(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt;
{
	cl_parm_set0(pInfoParmO);
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt|D_REP_IGN_OUT_DATA);
}

/****************************************/
/*	22									*/
/****************************************/
int cl_gx_rep_info_convert(pInfoParmO,pInfoParmI,iOpt0)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	iOpt0 = (iOpt0 & ~D_REP_OPT_SEL_MASK) | D_REP_OPT_SEL_CNVT;
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt0);
}

/****************************************/
/*	23									*/
/****************************************/
int cl_gx_rep_info_als(pInfoParmO,pInfoParmI,iOpt0)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	gtIter_ctl[0].itc_circ_ref = NULL;
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt0);
}

/****************************************/
/*	24									*/
/****************************************/
int cl_gx_rep_info_als_name(pInfoParmO,pInfoParmI,iOpt0,name)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt0;
char *name;
{
	gtIter_ctl[0].itc_circ_ref = NULL;
	return cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt0,name);
}

/****************************************/
/*	25									*/
/****************************************/
int cl_gx_rep_info_data(pInfoParmO,pInfoParmI,iOpt0)
tdtINFO_PARM  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	iOpt0 = (iOpt0 & ~D_REP_OPT_SEL_MASK) | D_REP_OPT_SEL_DATA | D_REP_OPT_SEL_CNVT;
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt0);
}

/****************************************/
/*	26									*/
/****************************************/
tdtINFO_PARM *cl_gx_copy_info_opt(pInfoParmO,pInfoParmI,opt)
tdtINFO_PARM *pInfoParmO, *pInfoParmI;
int opt;
{
	if (!pInfoParmO || !pInfoParmI) return NULL;
	if (pInfoParmO != pInfoParmI) {
		*pInfoParmO = *pInfoParmI;
		if (pInfoParmO->pi_scale & D_DATA_LPOSDATA)
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
		if (opt & 0x01) pInfoParmO->pi_scale &= ~D_DATA_MALLOC;	/* add 2022.6.14 */
	}
	return pInfoParmO;
}

/*	27	*/
/********1*********2*********3*********4*********5*********6*/
/* �@�\ : pi_data�ȊO��Info���R�s�[���A�f�[�^���R�s�[����	*/
/* ���� : pInfoParmO : �R�s�[��Info							*/
/*			NULL�̂Ƃ��́Atmp_malloc���A�����Ԃ�			*/
/*			O.pi_data��NULL���AO.pi_dlen<I.pi_dlen�̂Ƃ���	*/
/*			O.pi_data��tmp_malloc����						*/
/*		  pInfoParmI : �R�s�[��Info							*/
/*			NULL�̂Ƃ��́ANULL��Ԃ�						*/
/*		  opt        : 	addr�I�v�V����						*/
/*			= 0 : ��L�@�\									*/
/*			= 1 : pInfoParmO<>NULL							*/
/*					pInfoParmO=NULL�̂Ƃ��́A�G���[			*/
/*			= 2 : pInfoParmO->pi_data<>NULL (opt=1���܂�)	*/
/*					pInfoParmO->pi_data=NULL�̂Ƃ��́A�G���[*/
/*			= 3 : pInfoParmO->pi_dlen>=pInfoParmI->pi_dlen	*/
/*											(opt=1,2���܂�)	*/
/*					pInfoParmO->pi_dlen<pInfoParmI->pi_dlen	*/
/*					�̂Ƃ��́A�G���[						*/
/* �ԋp : pInfoParmO										*/
/************************************************************/
tdtINFO_PARM *cl_gx_copy_info2_opt(pInfoParmO,pInfoParmI,opt)
tdtINFO_PARM *pInfoParmO, *pInfoParmI;
int opt;
{
	char *p;
	int ret,len,alen;

	ret = 0;
	if (!pInfoParmI) {
		return NULL;
	}
	if (opt < 0) opt = 0;
	if (!pInfoParmO) {
		if (opt) {
			return NULL;
		}
		if (!(pInfoParmO=(tdtINFO_PARM *)cl_tmp_const_malloc(sizeof(tdtINFO_PARM)))) {
			return NULL;
		}
		memset(pInfoParmO,0,sizeof(tdtINFO_PARM));
	}
	if (pInfoParmO != pInfoParmI) {
		if (pInfoParmI->pi_scale & D_DATA_LPOSDATA) {
			*pInfoParmO = *pInfoParmI;
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
/*
printf("cl_gx_copy_info2: O.pos=%d\n",pInfoParmO->pi_pos);
*/
		}
		else {
			p   = pInfoParmO->pi_data;
			len = pInfoParmI->pi_dlen;
/*
printf("cl_gx_copy_info2: O.data=%08x O.dlen=%d I.data=%08x I.dlen=%d\n",p,pInfoParmO->pi_dlen,pInfoParmI->pi_data,len);
*/
			if (opt>=2 && !p) {
				return NULL;
			}
			else if (opt>=3 && pInfoParmO->pi_dlen<len) {
				return NULL;
			}
			else if (!p || (pInfoParmO->pi_dlen<len)) {
				alen = len;
				if (pInfoParmI->pi_alen & D_AULN_RANGE_DATA) alen += alen;	/* add 2025.3.17 */
				if (pInfoParmI->pi_attr == DEF_ZOK_CHAR) alen++;
				if (!(p=cl_tmp_const_malloc(alen))) {
					return NULL;
				}
			}
			*pInfoParmO = *pInfoParmI;
			if (pInfoParmI->pi_alen & D_AULN_RANGE_DATA) len += len;	/* add 2025.3.17 */
/*
printf("cl_gx_copy_info2_opt: pi_alen = %08x len=%d\n",pInfoParmI->pi_alen,len);
*/
			memcpy(p,pInfoParmI->pi_data,len);
			if (pInfoParmO->pi_attr == DEF_ZOK_CHAR) *(p+len) = '\0';
			pInfoParmO->pi_data = p;
		}
	}
	else {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"cl_gx_copy_info2_opt");
	}
	return pInfoParmO;
}

/****************************************/
/*	28									*/
/****************************************/
tdtINFO_PARM *cl_gx_copy_info2(pInfoParmO,pInfoParmI)
tdtINFO_PARM *pInfoParmO, *pInfoParmI;
{
	return cl_gx_copy_info2_opt(pInfoParmO,pInfoParmI,0);
}

/****************************************/
/*	29									*/
/****************************************/
tdtINFO_PARM *cl_gx_copy_info(pInfoParmO,pInfoParmI)
tdtINFO_PARM *pInfoParmO, *pInfoParmI;
{
	return cl_gx_copy_info_opt(pInfoParmO,pInfoParmI,0);
}

/****************************************/
/*	31									*/
/****************************************/
static int _array_get_info_parm_opt(ppParmI,pIndex1,pTBL1,i,ix1,opt)
tdtINFO_PARM **ppParmI;
tdtArrayIndex *pIndex1;
tdtINFO_PARM ***pTBL1;
int i,ix1;
char opt;
{
	if (pIndex1->xhp) ix1 = i;
	return cl_array_get_info_parm(ppParmI,pIndex1,pTBL1,ix1,opt);
}

/****************************************/
/*	32									*/
/****************************************/
static int _array_get_info_parm(ppParmI,pIndex1,pTBL1,i,ix1)
tdtINFO_PARM **ppParmI;
tdtArrayIndex *pIndex1;
tdtINFO_PARM ***pTBL1;
int i,ix1;
{
	return _array_get_info_parm_opt(ppParmI,pIndex1,pTBL1,i,ix1,'s');
}

/****************************************/
/*	33									*/
/****************************************/
static int _gx_rep_all_hash(xhpO,xhpI,iOpt)
XHASHB *xhpI,*xhpO;
int iOpt;
{
	tdtINFO_PARM *pParmI,*pParmO;
	char *cpKey,*cpDat;
	int rc,i,n,im;

	if (!(im=(iOpt & D_GX_OPT_ALC_MASK)>>12)) im = D_OPT_ALC_MALLOC;
	n = akxs_xhash2(xhpI,'M',NULL,NULL);
	for (i=1;i<=n;i++) {
		xhpI->xha_xhix = i;
		if ((rc=akxs_xhash2(xhpI,'P',&cpKey,&cpDat)) > 0) {
/*
printf("_gx_rep_all_hash: i=%d key=[%s]\n",i,cpKey);
*/
			memcpy(&pParmI,cpDat,sizeof(tdtINFO_PARM *));
			pParmO = (tdtINFO_PARM *)cl_opt_malloc(im,sizeof(tdtINFO_PARM));
			if (!pParmO) return ECL_MALLOC_ERROR;
			if (rc = cl_gx_rep_info_set_ign(pParmO,pParmI,1|iOpt)) return rc;
			pParmO->pi_scale = _gx_rep_set_sca_im(pParmO->pi_scale,im,0,0);
			if ((rc=akxs_xhash2(xhpO,'S',cpKey,&pParmO)) < 0) return  rc;
			else if (!rc) return -12;
		}
		else if (rc < 0) return rc;
	}
	return 0;
}

/****************************************/
/*	34									*/
/****************************************/
static int _gx_rep_all_array(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
int iOpt;
{
	tdtArrayIndex *pIndexO,*pIndexI,tIndex;
	int *index,attr,size,len,n,i,rc,opti,i0,iParm[4],ix,ndim,im;
	tdtINFO_PARM **pvParmI,**pvParmO,*pParmI,*pParmO;
	tdtINFO_PARM ***pTBL;
	char *name,*cpKey,*cpDat,*pVal;
	ScrPrCT *pScCT;
	XHASHB *xhpI,*xhpO;

DEBUGOUT_InfoParm(120,"_gx_rep_all_array:pInfoParmO:",pInfoParmO,0,0);
DEBUGOUT_InfoParm(120,"_gx_rep_all_array:pInfoParmI:",pInfoParmI,0,0);

	pIndexI = (tdtArrayIndex *)pInfoParmI->pi_data;
	pIndexO = (tdtArrayIndex *)pInfoParmO->pi_data;
	if (rc=_get_array_info(1,&pInfoParmI,&tIndex,&pTBL,iParm,1)) {
		if (rc == 2000) xhpI = tIndex.xhp;
		else return rc;
	}
	else xhpI = NULL;

	/* �z�Q�Ə������`�F�b�N */
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}
	/* �z�Q�Ƃ��`�F�b�N */
	pVal = cl_get_circ_addr(&tIndex,pTBL);
	if ((rc=_iterate_circ_ref(&gtIter_ctl[0],pVal,(char *)pInfoParmI->pi_pos)) == 1) return 0;
	else if (rc < 0) return rc;

	if (!(im=(iOpt & D_GX_OPT_ALC_MASK)>>12)) im = D_OPT_ALC_MALLOC;
	iOpt = 1 | D_REP_OPT_DATA_MODE;
	n  = iParm[1];
	ix = iParm[2];
	if (xhpI) {
		if (iOpt & D_GX_OPT_ALC_TMP)
			xhpO = akxs_xhashm_new2(0,pIndexO->index[4],0,pIndexO->size,0,cl_tmp_const_malloc,NULL);
		else
			xhpO = akxs_xhash_new2(0,pIndexO->index[4],0,pIndexO->size);
		if (!(pIndexO->xhp = xhpO)) return -9;
		if (rc=_gx_rep_all_hash(xhpO,xhpI,iOpt)) return rc;	/* 0-->iOpt 2022.9.21 */
		pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
	}
	else {
		index = pIndexO->index;
		size = pIndexO->size;
		if ((attr=pIndexO->uAttr[0]) == DEF_ZOK_CHAR) size++;
		else if (attr == DEF_ZOK_BULK) size += sizeof(int);
		len = n*size;
/*
printf("_gx_rep_all_array: size=%d attr=%d n=%d\n",size,attr,n);
*/
#if 1	/* 2023.3.1 */
	  if (len <= 0) {
	  	pIndexO->pVarIndex = NULL;
	  }
	  else {
#endif
		if (!(pIndexO->pVarIndex=(tdtINFO_PARM **)cl_opt_malloc(im,len))) return -10;
		if (pIndexI->pVarIndex) {
			if (attr == DEF_ZOK_VARI) {
				memset(pIndexO->pVarIndex,0,len);
				pvParmI = pIndexI->pVarIndex;
				pvParmO = pIndexO->pVarIndex;
				for (i=0;i<n;i++) {
					if (pParmI=*pvParmI) {
/*
printf("_gx_rep_all_array: i=%d\n",i);
*/
						if (!(pParmO=(tdtINFO_PARM *)cl_opt_malloc(im,sizeof(tdtINFO_PARM)))) return -1;
						memset(pParmO,0,sizeof(tdtINFO_PARM));
						*pvParmO = pParmO;
					/*	pParmI->pi_aux[0] |= DEF_ZOK_DATA;	*//* add 2021.11.23 *//* del 2022.9.22 */
						if (rc = cl_gx_rep_info_set_ign(pParmO,pParmI,iOpt)) return rc;	/* 1-->iOpt 2022.9.21 */
						pParmO->pi_scale = _gx_rep_set_sca_im(pParmO->pi_scale,im,0,0);
					}
					pvParmO++;
					pvParmI++;
				}
			}
			else memcpy(pIndexO->pVarIndex,pIndexI->pVarIndex,len);
			pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
		}
		else {	/* MAPPEDARRAY */
			memset(pIndexO->pVarIndex,0,len);
			index[3] = 1;
			pvParmO = pIndexO->pVarIndex;
			for (i=0;i<n;i++) {
				pParmI = cl_get_array_and_var_ent(&tIndex,pTBL,ix);
				ix++;
				if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
					if (!(pParmO=(tdtINFO_PARM *)cl_opt_malloc(im,sizeof(tdtINFO_PARM)))) return -1;
					memset(pParmO,0,sizeof(tdtINFO_PARM));
					*pvParmO = pParmO;
					if (rc=cl_gx_rep_info_set_ign(pParmO,pParmI,iOpt)) return rc;	/* 1-->iOpt 2022.9.21 */
					pParmO->pi_scale = _gx_rep_set_sca_im(pParmO->pi_scale,im,0,0);
/*
DEBUGOUT_InfoParm(0,"_gx_rep_all_array:pParmI: i+i0=%d",pParmI,i+i0,0);
DEBUGOUT_InfoParm(0,"_gx_rep_all_array:pParmO: i=%d",pParmO,i,0);
*/
				}
				pvParmO++;
			}
		}
#if 1	/* 2023.3.1 */
	  }
#endif
	}
	pInfoParmO->pi_scale = _gx_rep_set_sca_im(pInfoParmO->pi_scale,im,1,D_DATA_INDEX_FREE);
	return 0;
}

/****************************************/
/*	36									*/
/****************************************/
static int _gx_rep_all_struct(pInfoParmO,pInfoParmI,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
int iOpt;
{
	int  j,rc,ntype,attr,size,im;
	char *p,id;
	tdtINFO_PARM *pParmO,*pParmI;
	tdtDefType *pDeftypeO,*pDeftypeI;

DEBUGOUTL(110,"_gx_rep_all_struct:Enter");
DEBUGOUT_InfoParm(120,"_gx_rep_all_struct:pInfoParmO:",pInfoParmO,0,0);
DEBUGOUT_InfoParm(120,"_gx_rep_all_struct:pInfoParmI:",pInfoParmI,0,0);

/*	pInfoParmO->pi_aux[0] = D_AUX0_TYPE_STRUCT;	2021.2.17 */

	pDeftypeO = (tdtDefType *)pInfoParmO->pi_data;
	pDeftypeI = (tdtDefType *)pInfoParmI->pi_data;
	ntype = pDeftypeI->ntype;
/*
printf("_gx_rep_all_struct: ntype=%d\n",ntype);
*/
	/* �z�Q�Ə������`�F�b�N */
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}
	/* �z�Q�Ƃ��`�F�b�N */
	if ((rc=_iterate_circ_ref(&gtIter_ctl[0],(char *)pDeftypeI,(char *)pInfoParmI->pi_pos)) == 1) return 0;
	else if (rc < 0) return rc;

	if (!(im=(iOpt & D_GX_OPT_ALC_MASK)>>12)) im = D_OPT_ALC_MALLOC;

	if (!(pDeftypeO->pType=(tdtINFO_PARM **)cl_opt_malloc(im,ntype*sizeof(tdtINFO_PARM *)))) return -1;

	iOpt |= 1 | D_REP_OPT_DATA_MODE;
	for (j=0;j<ntype;j++) {
		if (!(pParmO=(tdtINFO_PARM *)cl_opt_malloc(im,sizeof(tdtINFO_PARM)))) return -1;
		pDeftypeO->pType[j] = pParmO;
		pParmI = pDeftypeI->pType[j];
/*
printf("_gx_rep_all_struct: i=%d pi_id=[%c]\n",j,pParmI->pi_id);
*/
		if ((id=pParmI->pi_id)==' ' && (attr=(pParmI->pi_aux[0] & ~DEF_ZOK_DATA))) {
/*
printf("_gx_rep_all_struct: attr=%d\n",attr);
*/
			cl_gx_copy_info(pParmO,pParmI);
			pParmO->pi_scale &= ~D_DATA_MALLOC;
			if (attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) {
				size = pParmI->pi_len;
				if (attr == DEF_ZOK_CHAR) size++;
				else if (attr == DEF_ZOK_BULK)
					size += sizeof(int);
				if (p = cl_opt_malloc(im,size)) {
					if (attr == DEF_ZOK_DECI) memcpy(p,pParmI->pi_data,size);
					else strcpy(p,pParmI->pi_data);
					pParmO->pi_scale = _gx_rep_set_sca_im(pParmO->pi_scale,im,0,0);
				}
				else rc = -1;
				pParmO->pi_data = p;
			}
			pParmO->pi_paux = pParmO->pi_data;
			pParmO->pi_aux[1] &= ~D_AUX1_PROTECTED;
		}
		else {
			if (rc=cl_gx_rep_info_set_ign(pParmO,pParmI,iOpt)) return rc;	/* 1-->iOpt 2022.9.21 */
		}
/*
DEBUGOUT_InfoParm(0,"_gx_rep_all_struct:pParmI: i=%d",pParmI,j,0);
DEBUGOUT_InfoParm(0,"_gx_rep_all_struct:pParmO: i=%d",pParmO,j,0);
*/
	}
	pInfoParmO->pi_scale = _gx_rep_set_sca_im(pInfoParmO->pi_scale,im,1,D_DATA_INDEX_FREE);
	rc = cl_set_struct_name(pInfoParmO,(char *)pInfoParmI->pi_pos);
DEBUGOUTL2(110,"_gx_rep_all_struct:Exit: rc=%d struct_name=[%s]",rc,(char *)pInfoParmO->pi_pos);
	return rc;
}

/****************************************/
/*	37									*/
/****************************************/
/* 2022.9.18 */
static int _gx_rep_all_data(pInfoParmO,pInfoParmI,name,iOpt)
tdtINFO_PARM *pInfoParmO,*pInfoParmI;
char *name;
int iOpt;
{
	tdtRB_CHAIN *xha;
	tdtINFO_PARM rInfoParmI;
	char id,c,*p;
	int rc;
	long argv[2],ih;

DEBUGOUTL1(110,"_gx_rep_all_data:Enter: name=[%s]",name);
DEBUGOUT_InfoParm(120,"_gx_rep_all_data:pInfoParmO: name=[%s]",pInfoParmO,name,0);
DEBUGOUT_InfoParm(120,"_gx_rep_all_data:pInfoParmI:",pInfoParmI,0,0);

	rInfoParmI = *pInfoParmI;
	rInfoParmI.pi_aux[0] = '\0';
	rInfoParmI.pi_scale &= ~D_DATA_INDEX_TMP;	/* add 2021.9.9 */
	if (rc=cl_gx_rep_info_set_ign(pInfoParmO,&rInfoParmI,1)) return rc;
	if (!name) name = "";
	else {
		if (*name=='<') name += D_LEN_SCOPE_MARK;
		if ((c=*name)=='$' || c=='%' || c=='#') name++;
	}
	pInfoParmO->pi_pos = (long)Strdup(name);
	pInfoParmO->pi_alen &= ~D_AULN_NO_AL_LPOS;
/*
printf("_gx_rep_all_data: id=[%c]\n",pInfoParmI->pi_id);
*/
	if ((id=pInfoParmI->pi_id)==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY) {
		pInfoParmO->pi_id = D_DATA_ID_ARRAY;	/* �z��̃f�[�^���R�s�[����Ƃ��́A�ʏ�̔z��ɂ��� */
		rc = _gx_rep_all_array(pInfoParmO,pInfoParmI,iOpt);
	}
	else if(id==D_DATA_ID_STRUCT) {
		rc = _gx_rep_all_struct(pInfoParmO,pInfoParmI,iOpt);
	}

DEBUGOUTL1(110,"_gx_rep_all_data:Exit rc=%d",rc);
	return rc;
}

/****************************************/
/*	41									*/
/****************************************/
static int _check_mk_key(pInfoParm,ppKey)
tdtINFO_PARM *pInfoParm;
char **ppKey;
{
	static char *p=NULL;
	int len,len2,n;
	char *key,*p1;

	key = pInfoParm->pi_data;
	if (ppKey) *ppKey = key;
	len = pInfoParm->pi_dlen;
	if (pInfoParm->pi_id == ' ' ) {
		p1 = NULL;
		if (pInfoParm->pi_attr != DEF_ZOK_CHAR) {
			if ((len=parm_to_char(pInfoParm,&p1,NULL)) < 0) return len;
			key = p1;
		}
	}
	else {
		len2 = len*2 + 1;
		if (p) p = Realloc(p,len2);
		else p = Malloc(len2);
		if (!p) return -1;
		n = akxcxtoc(key,len,p);
		*(p+n) = '\0';
		key = p;
		len = n;
	}
	if (ppKey) *ppKey = key;
/*
printf("_check_mk_key: key=[%s]\n",key);
*/
	return len;
}

/****************************************/
/*	42									*/
/****************************************/
static int _check_exist_mk_key(mcat,pInfoParm)
MCAT *mcat;
tdtINFO_PARM *pInfoParm;
{
	tdtINFO_PARM *pInfo;
	tdtRB_CTL *pCt;
	int len,n;
	char c,*key;

	if ((c=pInfoParm->pi_id)=='L' || c=='N') {
		pCt = (tdtRB_CTL *)pInfoParm->pi_data;
		akxs_rb_read(pCt,0);
		while (pInfo=(tdtINFO_PARM *)akxs_rb_read(pCt,1)) {
			if ((len=_check_exist_mk_key(mcat,pInfo)) < 0) return len;
		}
	}
	else {
		if ((len=_check_mk_key(pInfoParm,&key)) < 0) return len;
		if (mcat->mc_ipos > 0) akxtmcatz(mcat,"`",1);
		akxtmcatz(mcat,key,len);
	}
	return 0;
}

/****************************************/
/*	43									*/
/****************************************/
static int _check_exist(xhpS,pInfoParm)
XHASHB *xhpS;
tdtINFO_PARM *pInfoParm;
{
	MCAT mcat;
	int len,n,ix;
	char *key;

	/* 2021.4.7 */
	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 256;
	if ((ix=_check_exist_mk_key(&mcat,pInfoParm)) < 0) return ix;
	key = mcat.mc_bufp;

	if (!(ix=akxs_xhash(xhpS,'R',key))) {
		if ((n=akxs_xhash(xhpS,'S',key))<0) ix = n;
		else if (!n) ix = -1;
	}
/*
printf("_check_exist: key=[%s] ix=%d\n",key,ix);
*/
	return ix;
}

/****************************************/
/*	44									*/
/****************************************/
static int _check_exist_all(xhpS,pInfoParm)
XHASHB *xhpS;
tdtINFO_PARM *pInfoParm;
{
	MCAT mcat;
	int n,ix;
	char *key;

	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 256;
	if ((ix=_check_exist_mk_key(&mcat,pInfoParm)) < 0) return ix;
	key = mcat.mc_bufp;
	if (!ix) {
		if (!(ix=akxs_xhash(xhpS,'R',key))) {
			if ((n=akxs_xhash(xhpS,'S',key))<0) ix = n;
			else if (!n) ix = -1;
		}
	}
/*
printf("_check_exist_all: key=[%s] ix=%d\n",key,ix);
*/
	if (key) Free(key);
	return ix;
}

/****************************************/
/*	45									*/
/****************************************/
static int _array_add_sub(pvParmO,pos,pInfoParm1,pIndex1,pTBL1,ix1,nm1,xhpS)
int pos;
tdtArrayIndex *pIndex1;
tdtINFO_PARM **pvParmO,*pInfoParm1,***pTBL1;
int ix1,nm1;
XHASHB *xhpS;
{
	tdtINFO_PARM **pvParm,*pParmI;
	int iRc,i,count,iA;

	pvParm = pvParmO + pos;
	count = pos;
	if (pInfoParm1->pi_id == ' ') {
		pParmI = pInfoParm1;
		iA = 0;
	}
	else {
		iA = 1;
	}
	for (i=0;i<nm1;i++,ix1++) {
		if (iA) {
			if ((iRc=cl_array_get_info_parm(&pParmI,pIndex1,pTBL1,ix1,'r')) < 0) return iRc;
			else if (!iRc) continue;
		}
		if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
			if (xhpS) {
				if ((iRc=_check_exist(xhpS,pParmI))<0) return iRc;
				else if (iRc > 0) continue;
			}
			if (iRc=cl_gx_rep_info_set_alloc(pvParm,pParmI,1)) return iRc;
			/* 2021.8.14 */
			pvParm++;
			count++;
		}
	}
	return count;
}

/****************************************/
/*	46									*/
/****************************************/
int cl_gx_array_add(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char       op;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
{
	static XHASHB *xhpS=NULL;
	XHASHB *xhp1,*xhp2,*xhpO;
	tdtINFO_PARM ***pTBL1,***pTBL2,**pvParmO;
	int iRc,ix1,ix2,nm1,nm2,len,iParm[4],*index,size;
	tdtArrayIndex tIndex1,tIndex2,*pIndex,*pIndexO,*pIndex1,*pIndex2;

	xhp1 = xhp2 = NULL;
	nm1 = nm2 = 1;
	ix1 = ix2 = 0;
	pIndex1 = &tIndex1;
	pIndex2 = &tIndex2;
	if (pInfoParm1->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm1,pIndex1,&pTBL1,iParm,1)) {
			if (iRc == 2000) xhp1 = pIndex1->xhp;
			else return iRc;
		}
		/* 2023.10.17 */
		nm1  = iParm[3];
		ix1  = iParm[2];
	}

	if (pInfoParm2->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm2,pIndex2,&pTBL2,iParm,1)) {
			if (iRc == 2000) xhp2 = pIndex2->xhp;
			else return iRc;
		}
		/* 2023.10.17 */
		nm2  = iParm[3];
		ix2  = iParm[2];
	}

	info_parm_clear(pInfoParmW);
	pInfoParmW->pi_id   = 'R';
	pInfoParmW->pi_scale = D_DATA_INDEX_TMP/* | D_DATA_INDEX_FREE*/;
	pInfoParmW->pi_attr = DEF_ZOK_BULK;
	pInfoParmW->pi_dlen  = sizeof(tdtArrayIndex);
	/* 2021.8.14 */
	if (!(pIndexO = (tdtArrayIndex *)cl_tmp_const_malloc(sizeof(tdtArrayIndex)))) return -1;
	memset(pIndexO,0,sizeof(tdtArrayIndex));
	pInfoParmW->pi_data    = (char *)pIndexO;
	index = pIndexO->index;
	pIndexO->size = size = sizeof(tdtINFO_PARM *);
	pIndexO->uAttr[0] = DEF_ZOK_VARI;

	if (xhp1 && xhp2) {
		index[4] = tIndex1.index[4];
		/* 2021.9.9 */
		if (!(pIndexO->xhp=xhpO=akxs_xhashm_new2(0,index[4],0,size,0,cl_tmp_const_malloc,NULL))) return -9;
		if (iRc=_gx_rep_all_hash(xhpO,xhp1,D_GX_OPT_ALC_TMP)) return iRc;
		if (iRc=_gx_rep_all_hash(xhpO,xhp2,D_GX_OPT_ALC_TMP)) return iRc;
	}
	else {
		if (xhpS) akxs_xhash_free(xhpS);
		xhpS = NULL;
		if (op == '|') {
			if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;
		}
		index[0] = 1;
		index[2] = 0;
		index[3] = 1;
		index[4] = nm1+nm2;
		index[1] = index[4];
		index[5] = 0;
		len = index[4]*pIndexO->size;
		/* 2021.9.9 */
		if (!(pvParmO=(tdtINFO_PARM **)cl_tmp_const_malloc(len))) return -10;
		memset(pvParmO,0,len);
		pIndexO->pVarIndex = pvParmO;
		if ((iRc=_array_add_sub(pvParmO,0,pInfoParm1,pIndex1,pTBL1,ix1,nm1,xhpS))<0) return iRc;
		if ((iRc=_array_add_sub(pvParmO,iRc,pInfoParm2,pIndex2,pTBL2,ix2,nm2,xhpS))<0) return iRc;
		index[2] = iRc;
		if (iRc > 0) {
			index[1] = index[4] = iRc;
		}
	}
	return 0;
}

/****************************************/
/*	51 pInfoParm1 - pInfoParm2			*/
/****************************************/
static int _list_minus_sub(pCt,iOpt,pInfoParm1,pInfoParm2,id1)
tdtRB_CTL *pCt;
int iOpt;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
char id1;
{
	static XHASHB *xhpS=NULL;
	tdtINFO_PARM *p,*pInfoParm;
	int rc,iL;
	tdtRB_CTL *pCt1,*pCt2;
	char c1,c2;

DEBUGOUTL3(120,"_list_minus_sub:Enter pCt=%08x iOpt=%08x id1=[%c]",pCt,iOpt,id1);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParm2=",pInfoParm2,0,0);

	if (xhpS) akxs_xhash_free(xhpS);
	xhpS = NULL;
	if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;

	/* 2021.4.7 */
	c1 = pInfoParm1->pi_id;
	c2 = pInfoParm2->pi_id;
	/* 2022.10.7 */
	if ((c2=='L' || c2=='N') && c2==id1) {
		pCt2 = (tdtRB_CTL *)pInfoParm2->pi_data;
		akxs_rb_read(pCt2,0);
		while (p=(tdtINFO_PARM *)akxs_rb_read(pCt2,1)) {
			if ((rc=_check_exist_all(xhpS,p))<0) return rc;
		}
	}
	else {
		if ((rc=_check_exist(xhpS,pInfoParm2))<0) return rc;
	}

	if ((c1=='L' || c1=='N') && c1==id1) {
		pCt1 = (tdtRB_CTL *)pInfoParm1->pi_data;
		akxs_rb_read(pCt1,0);
		iL = 1;
	}
	else {
		iL = 0;
		p = pInfoParm1;
	}

	for (;;) {
		if (iL) {
			if (!(p=(tdtINFO_PARM *)akxs_rb_read(pCt1,1))) break;
		}
		if (!cl_is_null_parm(p)) {
			if ((rc=_check_exist_all(xhpS,p))<0) return rc;
			else if ((iOpt && !rc)||(!iOpt && rc)) {
				/* 2021.9.9 */
				if (!(pInfoParm=(tdtINFO_PARM *)cl_tmp_const_malloc(sizeof(tdtINFO_PARM))))
					return ECL_MALLOC_ERROR;
				/* 2021.9.10 */
				if (rc=_tmp_list_info_set(pInfoParm,p,0)) return rc;
				if (!akxs_rb_set_n(pCt,pInfoParm)) return ECL_MALLOC_ERROR;
			}
		}
		if (!iL) break;
	}
DEBUGOUTL(120,"_list_minus_sub:Exit ret=0");
	return 0;
}

/****************************************/
/*	52									*/
/****************************************/
int cl_gx_list_minus(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char       op;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
{
	int rc,iOpt;
	tdtRB_CTL *pCt,*pCt1,*pCt2;
	char c1,c2;

DEBUGOUTL1(120,"cl_gx_list_minus:Enter op=[%c]",op);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParm2=",pInfoParm2,0,0);

	if ((c2=pInfoParm2->pi_id)=='L' || c2=='N') {
		*pInfoParmW = *pInfoParm2;
	/*	pInfoParmW->pi_scale &= ~D_DATA_MALLOC;	�K�v���ǂ����͖��m�F */
	}
	if ((c1=pInfoParm1->pi_id)=='L' || c1=='N') {
		pCt1 = (tdtRB_CTL *)pInfoParm1->pi_data;
		if (akxs_rb_used(pCt1) <= 0) {
/*
printf("cl_gx_list_minus: 1 nil\n");
*/
			return cl_gx_rep_info_set(pInfoParmW,pInfoParm1,1);
		}
		*pInfoParmW = *pInfoParm1;
	/*	pInfoParmW->pi_scale &= ~D_DATA_MALLOC;	�K�v���ǂ����͖��m�F */
	}

	if (op == '&') iOpt = 0;
	else if (op == '-') iOpt = 1;
	else iOpt = 2;

	/* 2021.9.9 */
	if (!(pCt = cl_tmp_rb_new(0,0,NULL))) return ECL_MALLOC_ERROR;
/*
printf("cl_gx_list_minus: op=[%c] iOpt=%d\n",op,iOpt);
*/
	if ((rc=_list_minus_sub(pCt,iOpt,pInfoParm1,pInfoParm2,c1)) < 0) return rc;
	if (iOpt == 2) {
		if ((rc=_list_minus_sub(pCt,iOpt,pInfoParm2,pInfoParm1,c1)) < 0) return rc;
	}

	pInfoParmW->pi_data = (char *)pCt;
DEBUGOUTL(120,"cl_gx_list_minus:Exit ret=0");
	return 0;
}

/****************************************/
/*	53									*/
/****************************************/
int cl_gx_list_add(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char       op;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
{
	tdtINFO_PARM *ppParm[2];
	int ret;
	char c1,c2;

DEBUGOUTL1(120,"cl_gx_list_add:Enter op=[%c]",op);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParm2=",pInfoParm2,0,0);

	ppParm[0] = pInfoParm1;
	if (op == '+') {
		ppParm[1] = pInfoParm2;
		ret = cl_cons_list(pInfoParmW,2,ppParm);
	}
	else {
#if 1	/* 2021.4.7 */
		c1 = pInfoParm1->pi_id;
		c2 = pInfoParm2->pi_id;
#endif
		if (!(ret=cl_cons_list(pInfoParmW,1,ppParm))) {
#if 1	/* 2023.10.13 */
			if (c1!=D_DATA_ID_LIST && c1!=D_DATA_ID_NARABI) c1 = c2;
			pInfoParmW->pi_id = c1;
#endif
			ret = _list_minus_sub(pInfoParmW->pi_data,1,pInfoParm2,pInfoParm1,c1);
			/* 2021.4.7 *//* 1-->0 2023.10.13 */
		}
	}
/*	pInfoParmW->pi_scale = D_DATA_DATA_FREE;	*/
DEBUGOUTL1(120,"cl_gx_list_add:Exit ret=%d",ret);
	return ret;
}

/****************************************/
/*	56									*/
/****************************************/
static int _array_minus_hash(iOpt,nm1,xhp1,xhp2,xhpO)
int iOpt,nm1;
XHASHB *xhp1,*xhp2,*xhpO;
{
	int i,iRc;
	tdtINFO_PARM *pParmI;
	char *cpKey,*cpDat;

	iRc = 0;
	for (i=1;i<=nm1;i++) {
		xhp1->xha_xhix = i;
		if ((iRc=akxs_xhash2(xhp1,'P',&cpKey,&cpDat)) > 0) {
/*
printf("_array_minus_hash: i=%d key=[%s]\n",i,cpKey);
*/
			memcpy(&pParmI,cpDat,sizeof(tdtINFO_PARM *));
			if ((iRc=akxs_xhash(xhp2,'R',cpKey)) < 0) break;
			else if ((iOpt && !iRc)||(!iOpt && iRc)) {
				if ((iRc=akxs_xhash2(xhpO,'S',cpKey,&pParmI)) <= 0) {
					if (!iRc) iRc = -100;
					break;
				}
			}
		}
		else if (iRc < 0) break;
		iRc = 0;
	}
	xhp1->xha_xhix = 0;
/*
printf("_array_minus_hash: iRc=%d\n",iRc);
*/
	return iRc;
}

/****************************************/
/*	57									*/
/****************************************/
static int _array_minus_sub(pvParmO,pos,iOpt,
	pInfoParm1,pIndex1,pTBL1,ix1,nm1,
	pInfoParm2,pIndex2,pTBL2,ix2,nm2)
tdtINFO_PARM **pvParmO;
int pos,iOpt;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
tdtINFO_PARM ***pTBL1,***pTBL2;
int ix1,ix2,nm1,nm2;
tdtArrayIndex *pIndex1,*pIndex2;
{
	static XHASHB *xhpS=NULL;
	tdtINFO_PARM *pParmI,**pvParm;
	int iRc,i,iA,count;
/*
printf("_array_minus_sub:Enter pos=%d iopt=%d ix1=%d nm1=%d ix2=%d nm2=%d\n",pos,iOpt,ix1,nm1,ix2,nm2);
*/
	if (xhpS) akxs_xhash_free(xhpS);
	xhpS = NULL;
	if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;

	if (pInfoParm2->pi_id == ' ') {
		if ((iRc=_check_exist(xhpS,pInfoParm2))<0) return iRc;
	}
	else {
		for (i=0;i<nm2;i++,ix2++) {
			if ((iRc=cl_array_get_info_parm(&pParmI,pIndex2,pTBL2,ix2,'r')) < 0) return iRc;
			if (pParmI) {
				if (cl_is_undef_parm(pParmI) || cl_is_null_parm(pParmI)) continue;
				else if ((iRc=_check_exist(xhpS,pParmI))<0) return iRc;
				else if (iRc > 0) continue;
			}
		}
	}

	if (pInfoParm1->pi_id == ' ') {
		iA = 0;
		pParmI = pInfoParm1;
		nm1 = 1;
	}
	else {
		iA = 1;
	}

	pvParm = pvParmO + pos;
	count = pos;
	for (i=0;i<nm1;i++,ix1++) {
		if (iA) {
			if ((iRc=cl_array_get_info_parm(&pParmI,pIndex1,pTBL1,ix1,'r')) < 0) return iRc;
		}
		if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
			if ((iRc=_check_exist(xhpS,pParmI)) < 0) return iRc;
			else if ((iOpt && !iRc)||(!iOpt && iRc)) {
				if (iRc=cl_gx_rep_info_set_alloc(pvParm,pParmI,1)) return iRc;
				/* 2021.8.14 */
				pvParm++;
				count++;
			}
		}
	}
/*
printf("_array_minus_sub:Exit count=%d\n",count);
*/
	return count;
}

/****************************************/
/*	58									*/
/****************************************/
int cl_gx_array_minus(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtINFO_PARM *pInfoParmW;
char       op;
tdtINFO_PARM *pInfoParm1;
tdtINFO_PARM *pInfoParm2;
{
	static XHASHB *xhpS=NULL;
	XHASHB *xhp1,*xhp2,*xhpO;
	tdtINFO_PARM ***pTBL1,***pTBL2,**pvParmO,*pParmI;
	int iRc,i,nm1,nm2,ix1,ix2,len,iParm[4],*index,size,iA,iOpt;
	tdtArrayIndex tIndex1,tIndex2,*pIndexO;

	if (op == '&') iOpt = 0;
	else if (op == '-') iOpt = 1;
	else iOpt = 2;

	xhp1 = xhp2 = NULL;
	nm1 = nm2 = 1;
	if (pInfoParm1->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm1,&tIndex1,&pTBL1,iParm,1)) {
			if (iRc == 2000) xhp1 = tIndex1.xhp;
			else return iRc;
		}
		/* 2023.10.17 */
		nm1  = iParm[3];
		ix1  = iParm[2];
	}

	if (pInfoParm2->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm2,&tIndex2,&pTBL2,iParm,1)) {
			if (iRc == 2000) xhp2 = tIndex2.xhp;
			else return iRc;
		}
		/* 2023.10.17 */
		nm2  = iParm[3];
		ix2  = iParm[2];
	}
/*
printf("cl_gx_array_minus: xhp1=%08x nm1=%d ix1=%d\n",xhp1,nm1,ix1);
printf("cl_gx_array_minus: xhp2=%08x nm2=%d ix2=%d\n",xhp2,nm2,ix2);
*/
	info_parm_clear(pInfoParmW);
	pInfoParmW->pi_id   = 'R';
	pInfoParmW->pi_scale = D_DATA_INDEX_TMP/* | D_DATA_INDEX_FREE*/;
	pInfoParmW->pi_attr = DEF_ZOK_BULK;
	pInfoParmW->pi_dlen  = sizeof(tdtArrayIndex);
	/* 2021.8.14 */
	if (!(pIndexO = (tdtArrayIndex *)cl_tmp_const_malloc(sizeof(tdtArrayIndex)))) return -1;
	memset(pIndexO,0,sizeof(tdtArrayIndex));
	pInfoParmW->pi_data    = (char *)pIndexO;
	index = pIndexO->index;
	pIndexO->size = size = sizeof(tdtINFO_PARM *);
	pIndexO->uAttr[0] = DEF_ZOK_VARI;

	if (xhp1 && xhp2) {
		index[4] = tIndex1.index[4];
		/* 2021.9.9 */
		if (!(pIndexO->xhp=xhpO=akxs_xhashm_new2(0,index[4],0,size,0,cl_tmp_const_malloc,NULL))) return -9;
		if ((iRc=_array_minus_hash(iOpt,nm1,xhp1,xhp2,xhpO)) < 0) return iRc;
		if (iOpt == 2) {
			if ((iRc=_array_minus_hash(iOpt,nm2,xhp2,xhp1,xhpO)) < 0) return iRc;
		}
		return 0;
	}

	index[0] = 1;
	index[2] = 0;
	index[3] = 1;
	if (iOpt == 2) index[4] = nm1 + nm2;
	else index[4] = X_MAX(nm1,nm2);
	index[1] = index[4];	/* 2020.4.30 */
	index[5] = 0;
	len = index[4]*pIndexO->size;
	/* 2021.9.9 */
	if (!(pvParmO=(tdtINFO_PARM **)cl_tmp_const_malloc(len))) return -10;
	memset(pvParmO,0,len);
	pIndexO->pVarIndex = pvParmO;

	if ((iRc=_array_minus_sub(pvParmO,0,iOpt,
	                        pInfoParm1,&tIndex1,pTBL1,ix1,nm1,
	                        pInfoParm2,&tIndex2,pTBL2,ix2,nm2)) < 0) return iRc;
	if (iOpt == 2) {
		if ((iRc=_array_minus_sub(pvParmO,iRc,iOpt,
		                        pInfoParm2,&tIndex2,pTBL2,ix2,nm2,
		                        pInfoParm1,&tIndex1,pTBL1,ix1,nm1)) < 0) return iRc;
	}
	index[2] = iRc;
	if (iRc > 0) {
		index[1] = index[4] = iRc;
	}
	return 0;
}

/****************************************/
/*	61									*/
/****************************************/
int cl_set_struct(pWork,pInfoParm,nparm,ppParm)
tdtINFO_PARM *pInfoParm,*ppParm[];
int *pWork,nparm;
{
	int  j,rc,ntype,size,count;
	char id;
	tdtINFO_PARM *pParmO,**ppParmW,tInfoParm;
	tdtDefType *pDeftype;

	count = 0;
	*pWork = 0;
	pDeftype = (tdtDefType *)pInfoParm->pi_data;
	ntype = X_MIN(pDeftype->ntype,nparm);
/*
printf("cl_set_struct: ntype=%d\n",ntype);
*/
	for (j=0;j<ntype;j++) {
		pParmO = pDeftype->pType[j];
DEBUGOUT_InfoParm(161,"cl_set_struct:pParmO: j=%d",pParmO,j,0);
		id = pParmO->pi_id;
		if (id=='R' || id=='A') {
			if (!(ppParmW=(tdtINFO_PARM **)cl_tmp_const_malloc(sizeof(tdtINFO_PARM *)*(nparm-j+2)))) return ECL_MALLOC_ERROR;
			ppParmW[0] = pParmO;
#if 1	/* 2024.9.18 */
			mem_cpy_addr(&ppParmW[1],&ppParm[count],nparm-count);
#else
			ppParmW[1] = &tInfoParm;
			cl_set_parm_bin(&tInfoParm,0);
			mem_cpy_addr(&ppParmW[2],&ppParm[j],nparm-j);
#endif
			rc = cl_set_array(&size,nparm-j+2,ppParmW);
			count += size;
		}
		else if (id == 'T') {
#if 1	/* 2024.9.18 */
			rc = cl_set_struct(&size,pParmO,nparm-count,&ppParm[count]);
#else
			rc = cl_set_struct(&size,pParmO,nparm-j,&ppParm[j]);
#endif
			count += size;
		}
		else {	/*if ((id=pParmO->pi_id) == ' ') {*/
			if (!cl_is_null_parm(pInfoParm)) {
#if 1	/* 2024.9.18 */
				rc = cl_gx_rep_info_set(pParmO,ppParm[count],1);
#else
				rc = cl_gx_rep_info_set(pParmO,ppParm[j],1);
#endif
				count++;
			}
		}
		if (count >= nparm) break;
	}
	*pWork = count;
	return rc;
}

/****************************************/
/*	62									*/
/****************************************/
int cl_func_set_struct(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtINFO_PARM *ppParm[];
{
	int rc;

	rc = cl_check_data_id(ppParm[0],~0x10);
	if (rc < 0) {
		rc = ECL_SCRIPT_ERROR;
	}
	else {
		rc = cl_set_struct(pWork,ppParm[0],nparm-1,&ppParm[1]);
	}
	return rc;
}

/****************************************/
/*	63									*/
/****************************************/
int cl_set_sys_value_from_public_var(pInfoParm,name)
tdtINFO_PARM *pInfoParm;
char *name;
{
	int rc,val;

	rc = 0;
	if (!pInfoParm) rc = -1;
	else if (name) {
		if (!strcmp(name,D_NAM_RECURSION_LIMIT)) {
			if (cl_get_parm_bin(pInfoParm,&val,"sys value:") >= 0) {
				pCLprocTable->cp_recursion_limit = val;
/*
printf("cl_set_sys_value_from_public_var: %s=%d\n",name,val);
*/
			}
		}
		else if (!strcmp(name,D_NAM_MAX_LOOP_WHILE)) {
			if (cl_get_parm_bin(pInfoParm,&val,"sys value:") >= 0) {
				pCLprocTable->cp_max_loop_while = val;
/*
printf("cl_set_sys_value_from_public_var: %s=%d\n",name,val);
*/
			}
		}
	}
	return rc;
}
