static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************
 *								*
 *	�����ړI	: �p�P�b�g�`�F�b�N			*
 *								*
 *	�������e	: �󂯎��p�P�b�g�̃`�F�b�N		*
 *								*
 ****************************************************************/
#include <colmn.h>

#define False		0
#define True		1

extern int giOptions[];
extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;

extern CLCOMMON CLcommon;

/****************************************************************
 *								*
 *	�@�\��		: �p�P�b�g�`�F�b�N����			*
 *	�֐��`��	: int cl_packet_check()			*
 *								*
 *	�������e	: �p�P�b�g�`�F�b�N			*
 *								*
 *	�����̐���	: 					*
 *								*
 *	���^�[���l	: 		*
 *								*
 ****************************************************************/
int cl_packet_check (lInstanceHandle,cpInstanceData,tpRecvMsgCom)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsgCom;
{
	AKAMSGCOM *tpMsgCom;
	int iRc,time_out,i,len,size,*pSize;
	tdtDbToCol *DTDHead;
	char *p,*pm,buf[64];
	ushort usw;
	long lw;
	char cM_QUOTE1 = CLcommon.Quot[0];

DEBUGOUTL3(150,"cl_packet_check lInstanceHandle=%08x cpInstanceData=%08x tpRecvMsgCom=%08x",
lInstanceHandle,cpInstanceData,tpRecvMsgCom);

	p = cpInstanceData;
	if (tpRecvMsgCom->msg_disp == 0) {
		/* �p�P�b�g���R�}���h�̎� */

		DEBUGOUTL(101,FORMAT(11));	/* >> �R�}���h�E�p�P�b�g�ł��B */

		/* �p�P�b�g�̉�� */
#ifdef TIME
akb_ptime('S',"col_mn_analz");
#endif
#ifdef TIME
akb_ptime('E',"col_mn_analz");
#endif
/*
akxaxdump("C RecvMsgCom",tpRecvMsgCom,sizeof(AKAMSGCOM));
akxaxdump("C Msg",tpRecvMsgCom->msg_pmsg,tpRecvMsgCom->msg_mlen);
*/
		/* �֘A�e�[�u���̏����� */
#if 1
		memset(pCLprocTable,0,sizeof(CLPRTBL));
	/*	pCLprocTable = (CLPRTBL *)Malloc(sizeof(CLPRTBL));	*/
		pm = Malloc(sizeof(CLPRTBL));
		pGlobTable   = (GlobalCt *)Malloc(sizeof(GlobalCt));
DEBUGOUTL2(110,"cl_packet_check:cmd: pCLprocTable=%08x pGlobTable=%08x",p,pGlobTable);
		pCLprocTable = (CLPRTBL *)pm;
		memset(pGlobTable,0,sizeof(GlobalCt));
#else
		pCLprocTable = &CLprocTable;
		pGlobTable   = &GlobTable;
#endif
		memcpy(pGlobTable->options,giOptions,sizeof(int)*MAX_OPTIONS);
		cl_mod_option(1,0);
		cl_mod_option(9,0);

		memset(pCLprocTable,0,sizeof(CLPRTBL));
		pCLprocTable->GlobCt = pGlobTable;
		pCLprocTable->lInstanceHandle = lInstanceHandle;
		pCLprocTable->iThread = lInstanceHandle>>16;
		/* set start time */
		aka_get_msec(&pCLprocTable->tScrTimeVal[1]);
/*
printf("cl_packet_check iThread=%08x\n",pCLprocTable->iThread);
*/
/* 10.26 Add Koba */
		i = htonl(time(0));
		memcpy(pCLprocTable->CurCmdId,(char *)&i,4);
		usw = htonl(pCLprocTable->iThread);
		memcpy(pCLprocTable->CurCmdId,(char *)&usw,2);

/* 2000.6.16 Add Koba */
		pCLprocTable->usDbProcId  = CLcommon.usDbProcId
		                    + ((pCLprocTable->iThread - 1) % CLcommon.iDbProcNum);
		pCLprocTable->usDbClassId = CLcommon.usDbClassId;

		DEBUGOUTL(101,FORMAT(12));	/* >> �����̏��������s�Ȃ��܂����B */

		memcpy((char *)&i,pCLprocTable->CurCmdId,4);
		DEBUGOUTL1(101,"CurCmdId=%08x",i);

		memcpy(p,(char *)tpRecvMsgCom,sizeof(AKAMSGCOM));
/*
printf("sizeof(AKAMSGCOM)=%d lMsgLen=%d\n",sizeof(AKAMSGCOM),tpRecvMsgCom->msg_mlen);
*/
		if (!(pm=Malloc(tpRecvMsgCom->msg_mlen))) {
			return ECL_MALLOC_ERROR;
		}
/*
akxaxdump("C Msg2",tpRecvMsgCom->msg_pmsg,tpRecvMsgCom->msg_mlen);
*/
		memcpy(pm,tpRecvMsgCom->msg_pmsg,tpRecvMsgCom->msg_mlen);
		tpMsgCom = (AKAMSGCOM *)p;
		tpMsgCom->msg_pmsg = pm;

		pCLprocTable->CmdPacketp = p;
		pCLprocTable->PrPacketp = NULL;
/*
akxaxdump("C CmdPacket",p,sizeof(AKAMSGCOM));
akxaxdump("C Msg",pm,tpRecvMsgCom->msg_mlen);
*/
		/* �����t���O�n�m */
		cmn_set_stat( COM_PR ,&pCLprocTable->PrSt , L_ON );
 
		/* �X�N���v�g���� */
		cmn_set_stat( SCR_PR ,&pCLprocTable->PrSt ,  L_ON );
		pGlobTable->Trnshid[0] = '\0';
		pCLprocTable->SlstatusSW = 0;
	/*
		memcpy(pGlobTable->options,giOptions,sizeof(int)*MAX_OPTIONS);
		cl_mod_option(1,0);
		cl_mod_option(9,0);
	*/
		cl_tmp_const_ct_set(NULL);

		if (!(pCLprocTable->pha_vnam=akxs_xhash_new2(0,MAX_VAR_IY,0,sizeof(tdtINFO_PARM)))) {
			return ECL_MALLOC_ERROR;
		}
#if 0	/* 2023.4.28 */
		len = sizeof(tdtINFO_PARM **)*(MAX_VAR_IX+1);
		if (!(pCLprocTable->pTBL_vnam=(tdtINFO_PARM ***)Malloc(len))) {
		/*	akxs_xhash_free(pCLprocTable->pha_vnam);
			return ECL_MALLOC_ERROR;	*/
			iRc = ECL_MALLOC_ERROR;
			goto Err;
		}
		memset(pCLprocTable->pTBL_vnam,0,len);
		if (!(pSize=(int *)Malloc(cl_var_size_len(0)))) {
		/*	akxs_xhash_free(pCLprocTable->pha_vnam);
			Free(pCLprocTable->pTBL_vnam);
			return ECL_MALLOC_ERROR;	*/
			iRc = ECL_MALLOC_ERROR;
			goto Err;
		}
		pCLprocTable->pTBL_vnam[0] = (tdtINFO_PARM **)pSize;
		cl_var_set_size(pSize,MAX_VAR_IX,MAX_VAR_IY,"PVN");		/* PUBLIC */
#endif
		pCLprocTable->bxobj = (GXObject **)cl_const_malloc(sizeof(GXObject *)*4);
		memset(pCLprocTable->bxobj,0,sizeof(GXObject *)*4);
#if 1	/* 2021.7.13 */
		sprintf(buf,"$%s = %d",D_NAM_MAX_LOOP_WHILE,MAX_LOOP_WHILE);
	/*	if ((iRc=cl_set_public_var(buf,&pCLprocTable->bxobj[0])) < 0) return iRc;	*/
		if ((iRc=cl_set_public_var(buf,NULL)) < 0) goto Err;	/*return iRc;*/
		sprintf(buf,"$%s = %c%c",D_NAM_TRNSHID,cM_QUOTE1,cM_QUOTE1);
	/*	if ((iRc=cl_set_public_var(buf,&pCLprocTable->bxobj[1])) < 0) return iRc;	*/
		if ((iRc=cl_set_public_var(buf,NULL)) < 0) goto Err;	/*return iRc;*/
		sprintf(buf,"$%s = %c%s%c",D_NAM_UNX_DATE_FORMAT,cM_QUOTE1,D_UNX_DATE_FORMAT,cM_QUOTE1);
		if ((iRc=cl_set_public_var(buf,NULL)) < 0) goto Err;	/*return iRc;*/
		sprintf(buf,"$%s = %c%s%c",D_NAM_SQL_DATE_FORMAT,cM_QUOTE1,D_SQL_DATE_FORMAT,cM_QUOTE1);
		if ((iRc=cl_set_public_var(buf,NULL)) < 0) goto Err;	/*return iRc;*/
#endif
#if 1	/* 2021.7.13 */
		pCLprocTable->myGid = ++pGLprocTable->gid;
		akxs_xhasl(pGLprocTable->pha_gid,'S',pCLprocTable->myGid,0);
#else
		pCLprocTable->pha_gid = akxs_xhasl_new(sizeof(long),20,19,0);
#endif
		if (!(pCLprocTable->pha_fp = akxs_hasl_new(sizeof(FILE *),akb_set_fd_setsize(0),0))) {
			iRc = ECL_MALLOC_ERROR;
			goto Err;
		}
		if (!(pCLprocTable->pha_env = akxs_xhash_new2(0,10,7,0))) {
			iRc = ECL_MALLOC_ERROR;
			goto Err;
		}
#if 0	/* 2022.9.20 */
		if (!(p=Malloc(sizeof(VarTBL)))) {
			iRc = ECL_MALLOC_ERROR;
			goto Err;
		}
		memset(p,0,sizeof(VarTBL));
		pCLprocTable->Vary = (VarTBL *)p;
		if (!(pCLprocTable->Vary->pha_vnam=(XHASHB *)akxs_xhasl_new(sizeof(char *),100,0,0))) {
			iRc = ECL_MALLOC_ERROR;
			goto Err;
		}
#endif
		DEBUGOUTL(101,FORMAT(13));	/* >> �R�}���h�𔭍s���܂��B */
	}
	else {
		DEBUGOUTL(101,FORMAT(14));	/* >> R �ԋp�p�P�b�g�ł��B */

		/* �ۑ����Ă����������ɖ߂� */
		p += sizeof(AKAMSGCOM);
#if 1
		memcpy((char*)&pCLprocTable,p,sizeof(CLPRTBL *));
		p += sizeof(CLPRTBL *);
		memcpy((char*)&pGlobTable,p , sizeof(GlobalCt *));
DEBUGOUTL2(110,"cl_packet_check:ret: pCLprocTable=%08x pGlobTable=%08x",
pCLprocTable,pGlobTable);
#else
		memcpy((char*)&CLprocTable,p,sizeof(CLPRTBL));
		p += sizeof(CLPRTBL);
		memcpy((char*)&GlobTable,p , sizeof(GlobalCt));

		pCLprocTable = &CLprocTable;
		pGlobTable   = &GlobTable;
#endif

		cl_tmp_const_ct_set(NULL);

		/* ���[�h�����ԓ��p�P�b�g�������㏑������ */
		pCLprocTable->PrPacketp = (char *)tpRecvMsgCom;

		/* �㏈�� */
		DEBUGOUTL(101,FORMAT(15));	/* >> R ����߂����Ƃ��ł��܂����B */

		/* ���^�[���p�P�b�g���H */
		if((cmn_chk_stat(RTN_PR , &pCLprocTable->PrSt))) {
			cl_packet_error_check(tpRecvMsgCom);
		}
		else {
			ERROROUT(FORMAT(16));	/* ���^�[���E�p�P�b�g�҂��̏�ԂłȂ��B */
			return 2;
		}
	}
	return NORMAL;
Err:
	if (pCLprocTable->pha_vnam) akxs_xhash_free(pCLprocTable->pha_vnam);
	if (pCLprocTable->pTBL_vnam) Free(pCLprocTable->pTBL_vnam);
	if (pCLprocTable->Vary) Free(pCLprocTable->Vary);
	if (pCLprocTable->pha_fp) Free(pCLprocTable->pha_fp);
	if (pCLprocTable->pha_env) Free(pCLprocTable->pha_env);
	return iRc;
}

/****************************************************************
 *								*
 *	�@�\��		: �p�P�b�g�ۑ�����			*
 *	�֐��`��	: int packet_save()			*
 *								*
 *	�������e	: �󂯎��p�P�b�g�̕ۑ�		*
 *								*
 *	�����̐���	: �Ȃ�					*
 *								*
 *	���^�[���l	: NORMAL ����I��			*
 *			  -1     �ُ�I��			*
 *								*
 ****************************************************************/
int packet_save(p)
char *p;
{
	/* �ۑ��̈�Ɍ�����ۑ����� */
DEBUGOUTL3(110,"cl_packet_check:save: pCLprocTable=%08x pGlobTable=%08x p=%08x",
pCLprocTable,pGlobTable,p);
	p += sizeof(AKAMSGCOM);
#if 1
/*
printf("packet_save: p=%08x pCLprocTable=%08x\n",p,pCLprocTable);
*/
	memcpy(p,(char*)&pCLprocTable,sizeof(CLPRTBL *));
	p += sizeof(CLPRTBL *);
	memcpy(p,(char*)&pGlobTable,sizeof(GlobalCt *));
#else
	memcpy(p,(char*)&CLprocTable,sizeof(CLPRTBL));
	p += sizeof(CLPRTBL);
	memcpy(p,(char*)&GlobTable,sizeof(GlobalCt));
#endif

	DEBUGOUTL(101,FORMAT(17));	/* >> ����ۑ����܂����B */

	return(NORMAL);
}

int cl_packet_error_check(tpRecvMsg)
AKAMSGCOM *tpRecvMsg;
{
	tdtColToDb *pDTD;		/* ���M�p�P�b�g ���ʕ���   */
	int lw;

	if (tpRecvMsg) {
		if (tpRecvMsg->msg_pret) {
			pGlobTable->error = tpRecvMsg->msg_pret;
			strnzcpy(pGlobTable->errmsg,akb_str_error(pGlobTable->error),
			         sizeof(pGlobTable->errmsg)-1);

DEBUGOUTL2(100,"cl_packet_error_check: ERROR=%d ERRMSG=[%s]",
pGlobTable->error,pGlobTable->errmsg);

		}
		if (tpRecvMsg->msg_mlen >= sizeof(tdtColToDb)) {
			pDTD = (tdtColToDb *)tpRecvMsg->msg_pmsg;
			/* �G���[�p�P�b�g�̃`�F�b�N */
			if((pDTD->cMsgId[0]=='C') && (pDTD->cMsgId[1]=='M')) {
				if( tpRecvMsg->msg_pret)
					lw = tpRecvMsg->msg_pret;
				else
					lw = PACKET_RECEIVE_ERROR;
				pDTD->lret = htonl(lw);
			}
		}
	}
	else return -1;
	return 0;
}
