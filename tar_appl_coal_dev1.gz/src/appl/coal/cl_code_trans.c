static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************/
/*                                                                */
/*      Code Transration                                          */
/*                                                                */
/******************************************************************/
#include "colmn.h"

extern CLPRTBL CLprocTable;
extern CLCOMMON CLcommon;

int    cl_cd_tr_to_packt_form( pParm ,ppVar )
tdtINFO_PARM *pParm;		/* �p�����[�^���\����           */
char         **ppVar;
{
	tdtINFO_PARM rInfoParm;	/* �p�����[�^���\����           */
	prmList   varList;
	int rc;

	*ppVar = NULL;
	if ((rc=cl_code_trans(pParm,&rInfoParm))<=0) return rc;
	if (!(rc=cmpktform(&varList,&rInfoParm))) {
		*ppVar = varList.VarBD;
		rc     = varList.VarLen;
	}
	if (rInfoParm.pi_data) Free(rInfoParm.pi_data);

	return rc;
}

int cl_code_trans(pInfoParm, pInfoParmd)
tdtINFO_PARM *pInfoParm, *pInfoParmd;	/* �p�����[�^���\����           */
{
	tdtGENERAL_DATA tParm, tParmd;
	int rc;
/*
DEBUGOUT_InfoParm(0,"cl_code_trans: ",pInfoParm,0,0);
*/
/*	memset(pInfoParmd,0,sizeof(tdtINFO_PARM));	*/
	memcpy(pInfoParmd,pInfoParm,sizeof(tdtINFO_PARM));
#if 1	/* 2022.11.19 */
	if (pInfoParm->pi_dlen <= 0) {
		pInfoParmd->pi_code = CLcommon.cDataCode;
		return 0;
	}
	else if (pInfoParm->pi_attr != DEF_ZOK_CHAR) return -1;
#else
	if ((pInfoParm->pi_dlen==0) ||
	    (pInfoParm->pi_attr!=DEF_ZOK_CHAR) ||
	    ((pInfoParm->pi_attr==DEF_ZOK_CHAR) &&
	     (pInfoParm->pi_code==CLcommon.cDataCode ||
		  pInfoParm->pi_code==CD_TYPE_SYSTEM)) ) {
		return 0;
	}
#endif
/*	memcpy(pInfoParmd,pInfoParm,sizeof(tdtINFO_PARM));	*/
#if 1	/* 2022.11.19 */
	if (pInfoParm->pi_code==CLcommon.cDataCode ||
	    pInfoParm->pi_code==CD_TYPE_SYSTEM) {
		return 0;
	}
#endif
	pInfoParmd->pi_code = CLcommon.cDataCode;
	memcpy(&tParm.gd_id,&pInfoParm->pi_id,4);
	memcpy(&tParmd.gd_id,&pInfoParmd->pi_id,4);
	tParm.gd_dlen  = pInfoParm->pi_dlen;
	tParm.gd_data  = pInfoParm->pi_data;
	tParmd.gd_data = NULL;
	rc = akxt_code_trans(&tParm, &tParmd);
	pInfoParmd->pi_scale = tParmd.gd_scale;
	pInfoParmd->pi_dlen  = tParmd.gd_dlen;
	pInfoParmd->pi_data  = (char *)tParmd.gd_data;
	return rc;
}
