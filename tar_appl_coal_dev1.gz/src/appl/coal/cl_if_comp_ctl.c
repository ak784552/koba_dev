static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/**********************************************************************
*                                                                     *
*      �����ړI�@�@�F  ��r���Z���� 	�@                            *
*                                                                     *
*      �֐����@�@�@�F�@int cl_if_comp_ctl( pLeaf )		              *
*                                                                     *
*      ������      �F�@(I)Leaf          * pLeaf                       *
*                                                                     *
*                                                                     *
*      �߂�l�@�@�@�F�@ERROR                                          *
*                      NORMAL                                         *
*                                                                     *
*      �����T�v�@�@�F�@                                               *
*                                                                     *
**********************************************************************/
#include <colmn.h>

extern GlobalCt  *pGlobTable;
extern CLCOMMON  CLcommon;
extern int giOptions[];

static int iEROUT_NDEF;

/****************************************/
/*										*/
/****************************************/
int cl_if_comp_ctl(pLeaf,proc)
Leaf    *pLeaf;
ProcCT  *proc;
{
	int  	Flag;

	if (pLeaf->cmd.prmnum > 0) {
		if ((Flag = cl_if_compare(pLeaf,proc)) < NORMAL)
			return D_ERROR;
	}
	else {
		ERROROUT1(FORMAT(44),"cl_if_comp_ctl");	/* %s: �p�����[�^���K�v�ł��B */
		Flag  = D_ERROR;
	}

	return Flag;
}

/****************************************/
/*										*/
/****************************************/
int cl_is_true(pInfoParm)
tdtINFO_PARM *pInfoParm;
{
/*	int rc,Ans,atr;
	double dVal;
	char *pWork;	*/

DEBUGOUT_InfoParm(190,"cl_is_true: ",pInfoParm,0,0);

	/* 2022.6.9 */
	return cl_get_logic_val(pInfoParm);
}

/****************************************/
/*										*/
/****************************************/
int cl_is_zero(pInfoParm)
tdtINFO_PARM *pInfoParm;
{
	int rc,iAttr[4],atr;
	long Valz[NMPA_LONG],*Val,lValue;;
	double dValue;
	MPA *mpa;

	rc = 0;
	if (pInfoParm->pi_attr == DEF_ZOK_CHAR) {
		Val = cl_get_tmpMPA(Valz);
		iAttr[0] = 0;
		if ((rc=cl_get_parm_mpa(pInfoParm,Val,"Parm2:",iAttr)) >= 0) {
			atr = iAttr[0];
			if (atr == DEF_ZOK_BINA) {
				if (!CL_GET_VAL_BIN(Val)) rc = 1;
			}
			else if (atr == DEF_ZOK_FLOA) {
				memcpy(&dValue,Val,sizeof(double));
				if (dValue == 0.0) rc = 1;
			}
			else if (atr == DEF_ZOK_DECI) {
				mpa = (MPA *)Val;
				if (mpa->zero) rc = 1;
			}
		}
	}
	else rc = !cl_is_true(pInfoParm);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_if_compare_sub(nparm,prmp,Obj)
int nparm;
parmList *prmp[];
int      *Obj;
{
	int rc,Ans;
	double dVal;
	char *pWork;
	tdtINFO_PARM InfoParm1;

	/* 2021.12.6 */
	if (cl_get_option(24,0) & 0x01)
		rc = cl_gx_exp_obj(nparm,prmp,Obj,&InfoParm1);
	else
		rc = cl_gx_exp_tree_obj(nparm,prmp,Obj,&InfoParm1);
	pWork = InfoParm1.pi_data;
	if (!rc) {
		/* 2019.4.7 */
		rc = cl_is_true(&InfoParm1);
	}
	else if (rc == 100) rc = L_OFF;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_if_compare(pLeaf,proc)
Leaf    *pLeaf;
ProcCT  *proc;
{
	return cl_if_compare_sub(pLeaf->cmd.prmnum,pLeaf->cmd.prmp,proc->Obj);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_exp_tree_obj(nparm,prmp,Obj,pInfoParmW)
int nparm;
parmList  *prmp[];
tdtINFO_PARM **Obj;
tdtINFO_PARM *pInfoParmW;
{
DEBUGOUTL2(150,"cl_gx_exp_tree_obj: nparm=%d prmp[0]->opt=0x%08x",nparm,prmp[0]->opt);
	/* 2021.11.13 */
	return cl_gx_exp_obj_opt_tree(nparm,prmp,Obj,pInfoParmW,0,1);
}

/* 2022.10.22 */
int cl_gx_ex_tree_sub(is,Obj,ix_obj0,pGxObj,pInfoParmW,iOpt,Msa,iva)
int is;
tdtObjHead *Obj;
int ix_obj0;
GXObject *pGxObj;
tdtINFO_PARM *pInfoParmW;
int iOpt,iva[];
MCAT *Msa[];
{
	static char *name="cl_gx_ex_tree_sub";
	short *obj;
	int mc,mc1,mc2,mc3,i1,i2,i3,rc,i,lv,rv,ii,mca[2],ia[2],ib,j,n,mc0;
	long Value1,Value2;
	tdtINFO_PARM tInfoParm1,tInfoParm2;
	/* 2021.11.1 */
	WHERE_TREE *tree;

	tree = pGxObj->tree;
	mc = tree[is].mcode;
	i1 = tree[is].t1;
	i2 = tree[is].t2;
	lv = tree[is].lv;
	rv = tree[is].rv;
	i3 = tree[is].t3;

DEBUGOUTL2(161,"cl_gx_ex_tree_sub:Enter is=%d mc=%d ",is,mc);
DEBUGOUTL5(161,"cl_gx_ex_tree_sub:Enter i1=%d i2=%d lv=%d rv=%d i3=%d",i1,i2,lv,rv,i3);

	if (i1) mc1 = tree[i1].mcode;
	else mc1 = 0;

	if (i2) mc2 = tree[i2].mcode;
	else mc2 = 0;
/*
printf("cl_gx_ex_tree_sub: mc1=%d tree[i1].t1=%d mc2=%d tree[i2].t1=%d\n",mc1,tree[i1].t1,mc2,tree[i2].t1);
*/
/*
printf("Enter any key.");getchar();
*/
	/* 2022.1.26 */
	if (!i3 && (mc==3 || (mc>=5 && mc<=7) || mc==99)) {
		ii=lv;
		for (i=0;i<rv;i++,ii++) {
/*
printf("cl_gx_ex_tree_sub: tree[ii].mcode=%d tree[ii].lv=%d\n",tree[ii].mcode,tree[ii].lv);
*/
			iva[0] = tree[ii].mcode;
			iva[1] = tree[ii].lv;
			/* 2022.10.22 */
			if ((rc=cl_gx_ex_obj_sub(Obj,ix_obj0,pGxObj,&tInfoParm1,iOpt,Msa,iva)) < 0) return rc;
		}
	}
	mca[0] = mc1;
	mca[1] = mc2;
	ia[0] = i1;
	ia[1] = i2;
	if (mc == 59) {
		if (rv = tree[is].rv) {
			iva[0] = tree[rv].mcode;
			iva[1] = tree[rv].lv;
			/* 2022.10.22 */
			if ((rc=cl_gx_ex_obj_sub(Obj,ix_obj0,pGxObj,&tInfoParm1,iOpt,Msa,iva)) < 0) return rc;
		}
	}
	for (i=0;i<2;i++) {
		mc1 = mca[i];
		i1 = ia[i];
		lv = tree[i1].lv;
		/* 2022.10.22 */
		if ((rc=cl_gx_ex_tree_t(mc,mc1,i1,lv,Obj,ix_obj0,pGxObj,pInfoParmW,iOpt,Msa,iva)) < 0) return rc;
		if (rc == 1) break;
	}
	if (rc == 1) mc = 53;	/* 2�� SET */
	/* 2022.1.26 */
	else if (i3 && (mc==1 || mc==3 || (mc>=5 && mc<=7))) {
		for (i=is-1;i>=i3;i--) {
			obj = (short *)&tree[i];
			n = obj[1];
			j = n + 1;
/*
printf("cl_gx_ex_tree_sub: i=%d n=%d j=%d\n",i,n,j);
*/
			while (n-- > 0) {
				ii = obj[j--];
				mc0 = 0;
				mc1 = tree[ii].mcode;
				lv  = tree[ii].lv;
/*
printf("cl_gx_ex_tree_sub: ii=%d mc1=%d lv=%d\n",ii,mc1,lv);
*/
				/* 2022.10.22 */
				if ((rc=cl_gx_ex_tree_t(mc0,mc1,ii,lv,Obj,ix_obj0,pGxObj,pInfoParmW,iOpt,Msa,iva)) < 0) return rc;
			}
		}
	}
	iva[0] = mc;
	ib = tree[is].lv;
	iva[1] = ib;
	/* 2022.10.22 */
	rc = cl_gx_ex_obj_sub(Obj,ix_obj0,pGxObj,pInfoParmW,iOpt,Msa,iva);
	if (rc==0 && mc==59) {
/*
printf("cl_gx_ex_tree_sub: ib+2=%d iva[1]=%d iva[8]=%d\n",ib+2,iva[1],iva[8]);
*/
		i3 = tree[is].t3;
/*
printf("mcode=%d t1=%d t2=%d lv=%d rv=%d t3=%d\n",
tree[i3].mcode,tree[i3].t1,tree[i3].t2,tree[i3].lv,tree[i3].rv,tree[i3].t3);
*/
		if (i3 > 0) {
			if (iva[8])
				i2 = tree[i3].t1;
			else 
				i2 = tree[i3].t2;
			if (i2) mc2 = tree[i2].mcode;
			else mc2 = 0;
			if (mc2) {
				lv = tree[i2].lv;
				/* 2022.10.22 */
				rc = cl_gx_ex_tree_t(mc,mc2,i2,lv,Obj,ix_obj0,pGxObj,pInfoParmW,iOpt,Msa,iva);
			}
		}
	}

DEBUGOUTL2(161,"cl_gx_ex_tree_sub:Exit mc=%d rc=%d",mc,rc);

	return rc;
}

/* 2022.10.22 */
int cl_gx_ex_tree_t(mc,mc1,i1,lv,Obj,ix_obj0,pGxObj,pInfoParmW,iOpt,Msa,iva)
int mc,mc1,i1,lv;
tdtObjHead *Obj;
int ix_obj0;
GXObject *pGxObj;
tdtINFO_PARM *pInfoParmW;
int iOpt,iva[];
MCAT *Msa[];
{
	int rc;
	long Value1;
	tdtINFO_PARM tInfoParm1;

DEBUGOUTL4(161,"cl_gx_ex_tree_t:Enter mc=%d mc1=%d i1=%d lv=%d",mc,mc1,i1,lv);

	rc = 0;
	if (mc1==91 || mc1==92) {
/*
printf("cl_gx_ex_tree_t: mc1=%d lv=%d\n",mc1,lv);
*/
		iva[0] = mc1;
		iva[1] = lv;	/*tree[i1].lv;*/
		/* 2022.10.22 */
		if ((rc=cl_gx_ex_obj_sub(Obj,ix_obj0,pGxObj,&tInfoParm1,iOpt,Msa,iva)) < 0) return rc;
	}
	else if (mc1) {
		/* 2022.10.22 */
		if ((rc=cl_gx_ex_tree_sub(i1,Obj,ix_obj0,pGxObj,&tInfoParm1,iOpt,Msa,iva)) < 0) return rc;
DEBUGOUT_InfoParm(161,"cl_gx_ex_tree_t: mc=%d &tInfoParm1=",&tInfoParm1,mc,0);
		if (mc==51 || mc==52) {	/* && || */
			Value1 = cl_get_logic_val(&tInfoParm1);
			if (mc==51 && !Value1) {
				cl_set_parm_bin(pInfoParmW,0);
				rc = 1;
			}
			else if (mc==52 && Value1) {
				cl_set_parm_bin(pInfoParmW,1);
				rc = 1;
			}
		}
	}

DEBUGOUTL3(161,"cl_gx_ex_tree_t:Exit mc=%d mc1=%d rc=%d",mc,mc1,rc);

	return rc;
}
