static	char	sccsid[]="%Z% %M% %I% %D% %T%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ�                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_make_packet_form( pprmList , pInfoParm )           *
*                      (I)prmList	*pprmList                                 *
*                      (O)tdtINFO_PARM	*pInfoParm                                *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

int cl_make_packet_form( pprmList , pInfoParm )
	prmList   *pprmList;
	tdtINFO_PARM  *pInfoParm;
    {
	int  rc;
	char att;
	char acc;
	int  len;
	char *pBuff;

	att = pInfoParm->pi_attr;
/*
printf("cl_make_packet_form:att = %d, cod = %x\n",att,pInfoParm->pi_code);
*/
	switch( att )
		{
		case DEF_ZOK_CHAR :
			if ( pInfoParm->pi_dlen > 255 )
				acc = D_ACC_EXT;
			else
				acc = D_ACC_STD;
			break;
		case DEF_ZOK_BINA :
			if ( pInfoParm->pi_dlen == sizeof( char ) )
				acc = D_ACC_CHAR;
			else if ( pInfoParm->pi_dlen == sizeof( short int ) )
				acc = D_ACC_SHORT;
			else if ( pInfoParm->pi_dlen == sizeof( long ) )
				acc = D_ACC_LONG;
			else
				return( ERROR );
			break;
		case DEF_ZOK_BULK :
			acc = D_ACC_EXT;
			break;
		case DEF_ZOK_KANS :
			acc = D_ACC_STD;
			break;
		defaults:
			return( ERROR );
		}

	len = pInfoParm->pi_dlen;
	if ( att == DEF_ZOK_BINA ) {
			len += sizeof( FORM_S );
	}
	else {
		if ( acc == D_ACC_EXT )
			len += sizeof( FORM_K );
		else
			len += sizeof( FORM_S );
	}
	if (!(pBuff=Malloc(len))) return ERROR;

	if ( att == DEF_ZOK_BINA )
		{
		att =  ( att << 4 ) & 0xf0 ;
		pBuff[0] = att | acc;
		pBuff[1] = ( char )pInfoParm->pi_dlen;
		memcpy(pBuff+sizeof(FORM_S), pInfoParm->pi_data, pInfoParm->pi_dlen);
		}
	else
		{
		pBuff[0] = (( att << 4 ) & 0xf0 ) | acc;
		if ( att == DEF_ZOK_CHAR )
			pBuff[0] |= (pInfoParm->pi_code << 1) & 0x0e;
/*
printf("cl_make_packet_form:pBuff[0] = %x\n",*pBuff);
*/
		if ( acc == D_ACC_EXT )
			{
			pBuff[1] = 0x00;
			memcpy(pBuff+2, (char *)&pInfoParm->pi_dlen, sizeof(INT4) );
			memcpy(pBuff+sizeof(FORM_K),pInfoParm->pi_data,pInfoParm->pi_dlen);
			}
		else
			{
			pBuff[1] = ( char )pInfoParm->pi_dlen ,
			memcpy(pBuff+sizeof(FORM_S),pInfoParm->pi_data,pInfoParm->pi_dlen);
			}
		}

	pprmList->VarLen  = len;
	pprmList->VarType = ' ';
	pprmList->VarBD   = pBuff;

	return( NORMAL );
	}
