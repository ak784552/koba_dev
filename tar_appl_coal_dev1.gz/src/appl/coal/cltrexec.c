static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_exec                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_exec(y)
condList *y;
{
	static char *_fn_="col_mn_tr_exec";
	int rc,min_prm,ok_prm;
	char *p,c,*p0;
	tdtSubCommand *sc;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->cid == C_CALL) min_prm = 1;
	else min_prm = 2;

	rc = cmd->sub_cid = 0;
	if (cmd->prmnum > 0) {
		ok_prm = 1;
		p0 = p = cmd->prmp[0]->prp;
		if ((c=*p)=='<' || c=='>') {
			p++;
#if 0
			if ((c=*p) == '<') {
				ERROROUT2(FORMAT(155),_fn_,p0);	/* %s(%s)�͎w��ł��܂���B*/
				rc = ECL_TR_EXEC;
			}
			else {
#else
				c = *p;
#endif
#if 0
				if (!c) ok_prm = 2;
				if (cmd->prmnum < ok_prm) {
					ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B*/
					rc = ECL_TR_EXEC;
				}
				else if (cmd->prmnum > ok_prm) {
						/* %s: �]���ȃp�����[�^[%s]������܂��B*/
					ERROROUT2(FORMAT(43),_fn_,cmd->prmp[ok_prm+1]->prp);
					rc = ECL_TR_EXEC;
				}
				else
#endif
				cmd->sub_cid = CS_REDIRECT;
		/*	}	*/
		}
	}

	if (!rc && cmd->sub_cid!=CS_REDIRECT) {
		if (cmd->prmnum < 1) {
			ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B*/
			rc = ECL_TR_EXEC;
		}
		else if (cmd->cid == C_EXEC) {
			if (!(sc = cl_tr_sc_set_scno(cmd,0,0x01,0x80))) {
				ERROROUT1(FORMAT(86),p);	/* col_mn_tr_exec: �葱�����[%s]������Ă��܂��B */
				rc = ECL_TR_EXEC;
			}
			if (cmd->sub_cid!=CS_SH && cmd->prmnum<min_prm) {
				ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B*/
				rc = ECL_TR_EXEC;
			}
		}
	}

	if (!rc && !(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}
#if 0
/*********************************************/
/*                                           */
/*********************************************/
int ColMnTrInteractive(y)
condList *y;
{
	int rc;

	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}
#endif
