static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/***********************************************/
/* ��������                                    */
/*     SELECT�R�}���h�쐬�֐�                  */
/*---------------------------------------------*/
/***********************************************/
#include "colmn.h"

char *cl_sl_ext_order();

extern CLCOMMON CLcommon;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern ViewTBL ViewTbl;
extern ExtTBL  ExtTbl;

#define ALL_HOST

int cl_sl_make_select_command(pPrmp)
parmList  *pPrmp[];
{
	int   i,iRc,size;
	char *buf,*pSelect,*pFrom,*pWhere,*pOrder;
	struct BuffHeader {
		tdtCOMM_PACK_HEAD CPHead ;
		tdtDbToCol      DTDHead ;
	} *BuffHeader;
	char filename[20];
	FILE *fp;
	char cM_QUOTE1 = pGlobTable->Quot[0];

/*
*** ������
 */
	iRc = NORMAL;

/*
*** ����(select)�R�}���h���s�̂��߂̐ݒ�
*/
	/* SQL�R�}���h */
	if ((pSelect = cl_sl_ext_select()) == NULL) {
		ERROROUT1(FORMAT(386),"(SELECT)");		/* SQL�R�}���h(SELECT)�̐����Ɏ��s */
		return ECL_SYSTEM_ERROR;
	}
	if ((pFrom = cl_sl_ext_from()) == NULL) {
		ERROROUT1(FORMAT(386),"(FROM)");		/* SQL�R�}���h(FROM)�̐����Ɏ��s */
		Free(pSelect);
		pSelect = NULL;
		return ECL_SYSTEM_ERROR;
	}
	if ((pWhere = cl_sl_const_where()) == NULL) {
		ERROROUT1(FORMAT(386),"(WHERE)");	/* �R�}���h(WHERE)�̐����Ɏ��s */
		Free(pSelect);
		pSelect = NULL;
		Free(pFrom);
		pFrom = NULL;
		return ECL_SYSTEM_ERROR;
	}
	if ((pOrder = cl_sl_ext_order()) == NULL) {
		ERROROUT1(FORMAT(390),"(ORDER BY)");	/*	SQL�R�}���h(ORDER BY)�̐����Ɏ��s*/
		Free(pSelect);
		pSelect = NULL;
		Free(pFrom);
		pFrom = NULL;
		Free(pWhere);
		pWhere = NULL;
		return ECL_SYSTEM_ERROR;
	}
	size = strlen(pSelect);
	size += strlen(pFrom);
	size += strlen(pWhere);
	size += strlen(pOrder);
	if ((buf = (char *)Malloc(size+1)) == NULL) {
		ERROROUT("memory allocate error");
		return ECL_SYSTEM_ERROR;
	}
	memset(buf,0,++size);

	strcat(buf,pSelect);
	Free(pSelect);pSelect=NULL;

	strcat(buf, pFrom);
	Free(pFrom);pFrom=NULL;

	strcat(buf, pWhere);
	Free(pWhere);pWhere=NULL;

	strcat(buf, pOrder);
	Free(pOrder);pOrder=NULL;

#ifdef DEBUG_OFF
  printf("%s\n", buf);
#endif
	sprintf(filename,"%s%d",BUNKEN_SQL,pCLprocTable->iThread);
	if (fp=fopen(akb_akb_home_add(filename),"w")) {
		if (fprintf(fp,"PROC main;\n\tSQL %%1 c \"%s\" %s;\n",buf,ITEM_AREAID)==EOF) goto Err;
		if (fprintf(fp,"\tIF $ERROR NE 0;RETURN $ERROR;ENDIF;\n\tBEXP $1 = %%3;\n\tIF $TUPLE GT 0;\n\t\tBEXP $2 = %c%c;\n\t\tBEXP $4 = %%3 + $TUPLE;\n",cM_QUOTE1,cM_QUOTE1)==EOF) goto Err;
		if (fprintf(fp,"\t\tLOOP $TUPLE;\n\t\t\tREAD %s;\n\t\t\tIF #1 EQ 'NULL';\n\t\t\t\tBEXP $3 = $2;\n\t\t\tELSE;\n\t\t\t\tBEXP $3 = #1 CONCAT #2;\n\t\t\tENDIF;\n",ITEM_AREAID)==EOF) goto Err;
		fclose(fp);
		iRc = cl_sl_mk_format_data();
	}
	else {
		iRc = ECL_SYSTEM_ERROR;
	}
	if (ExtTbl.iItemNum == 0) {
		pGlobTable->exception = SYSTEM_EXCEPTION;
		pGlobTable->error = -1;
	}
#if 1
	Free(buf);
#endif
	return(iRc);
 Err:
	fclose(fp);
	if (ExtTbl.iItemNum == 0) {
		pGlobTable->exception = SYSTEM_EXCEPTION;
		pGlobTable->error = -1;
	}
	Free(buf);
	return (ECL_SYSTEM_ERROR);
}
