static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       long       col_mn_tr_leave              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/

#include "colmn.h"

int col_mn_tr_leave(y)
condList *y;
{
	int rc,num;

	if ((num=y->cmd->prmnum) == 0) {
		ERROROUT1(FORMAT(44),"col_mn_tr_leave");
		return ECL_TR_LEAVE;
	}
	else if (num > 1) {
		ERROROUT1(FORMAT(41),"col_mn_tr_leave");
		return ECL_TR_LEAVE;
	}


	/* �m�[�h�̗̈���m�� */
	if (!(rc = cl_make_leaf(y)))

	/* �m�[�h���X�^�b�N�ɐς� */
		rc = cl_push(y);

	return rc;
}
