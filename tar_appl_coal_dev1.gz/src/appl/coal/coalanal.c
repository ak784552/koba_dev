static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clanal.c>                                                       */
/*                                                                  */
/********************************************************************/

#include "colmn.h"

extern tdtMSG_CTL tMsgCtl;
extern int giProgram[];
extern CLPRTBL *pCLprocTable;

int col_mn_analz(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	AKAMSGCOM    tMsgCom;
	char         *pFilev[2], filename[256];
	int          iRc, iDisp, init_sc, iWaitTime;
	tdtDbToCol *pDTD;		/* ���M�p�P�b�g ���ʕ���   */
	TrmToSrv  qTTS;

DEBUGOUTL3(110,"col_mn_analz:Enter; lInstanceHandle=%08x cpInstanceData=%08x tMsgCom=%08x",
lInstanceHandle,cpInstanceData,tMsgCom);

	iDisp = 0;
	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		/* aka_registerClass()�ł��̊֐���o�^�����Ƃ��ɌĂ΂��B */
/*
userid[68];
commandid ;
parmnum;
*/
		if (giProgram[0]) init_sc = 1;
		else {
/*
if (cpInstanceData)
printf("col_mn_analz: AKA_REGIST_CLASS: cpInstanceData=[%s]\n",cpInstanceData);
*/
			if (cpInstanceData && *cpInstanceData == 'i') init_sc = 1;
			else init_sc = 0;
		}
		if (init_sc) {
			/* �v���Z�X�N�����ɁA�R�}���h0x0ffffff0�̃X�N���v�g�����s���� */
			memset((char *)&qTTS,0,sizeof(TrmToSrv));
			qTTS.commandid = htonl(0x0ffffff0);
			memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
			tMsgCom.msg_clid = lInstanceHandle & 0x0000ffff;
			tMsgCom.msg_mlen = sizeof(TrmToSrv);
			tMsgCom.msg_pmsg = (char *)&qTTS;
			if ((iRc = aka_post_msg(0,&tMsgCom)) < 0)
				ERROROUT1("col_mn_analz:AKA_REGIST_CLASS: aka_post_msg ret=%d",iRc);
		}
		break;
	case 0:
		/* ���v���Z�X����̔��M���b�Z�[�W�̏����B */
		if (tpRecvMsg->msg_pret) {
			/* �ԐM�����ʃv���b�g�t�H�[�����ŃG���[�ɂȂ�Ԃ��ꂽ�B */
			break;
		}
	case 1:
/*
printf("col_mn_analz: akberr=%d\n",tpRecvMsg->msg_pret);
if (tpRecvMsg->msg_pret)
	akxaxdump("cpMsg",tpRecvMsg->msg_pmsg,tpRecvMsg->msg_mlen);
*/
/*
akxaxdump("col_mn_analz: tpRecvMsg",tpRecvMsg,sizeof(AKAMSGCOM));
*/
	/*	iThread = lInstanceHandle>>16;	*/
		memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
		tMsgCom.msg_filv = pFilev;
		pFilev[0] = filename;
								/* Packet Check & process flag set */
		iRc = cl_packet_check(lInstanceHandle,cpInstanceData,tpRecvMsg);
		if (iRc == 0) {
			pCLprocTable->WrPacketp = (char *)&tMsgCom;
#ifdef TIME
akb_ptime('S',"cl_script_main");
#endif
			iRc = cl_script_main(); /* Script process */
#ifdef TIME
akb_ptime('E',"cl_script_main");
#endif
/*
printf("dmanal:ret=%d MsgLen=%d iThread=%d\n",iRc,tMsgCom.msg_mlen,pCLprocTable->iThread);
printf("dmanal:iDisp=%d cpMsg=%08x\n",iDisp,tMsgCom.msg_pmsg);
*/
		}

DEBUGOUTL3(110,"col_mn_analz: tMsgCom.cpMsg=%08x usDisposition=%04x iThread=%d",
tMsgCom.msg_pmsg,tMsgCom.msg_disp,pCLprocTable->iThread);

		if (tMsgCom.msg_pmsg) {
			if (pCLprocTable->iThread>0) {
				if (tMsgCom.msg_disp & 0x1000) {
					tMsgCom.msg_disp &= ~0x1000;
					memcpy(&iWaitTime,tMsgCom.msg_pmsg+tMsgCom.msg_mlen,sizeof(int));
					iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
				}
				else {
					pDTD = (tdtDbToCol *)tMsgCom.msg_pmsg;
					if (ntohs(pDTD->usCmdNo) == 30001) {	/* SLEEP command */
						iRc = aka_set_sleep(lInstanceHandle,1,ntohl(pDTD->lret));
					}
					else {
						tMsgCom.msg_disp = 1;
						iWaitTime = ntohl(pDTD->lret);
						pDTD->lret = 0;
						iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
					}

DEBUGOUTL2(110,"col_mn_analz: pDTD->usCmdNo=%d iRc=%d",ntohs(pDTD->usCmdNo),iRc);

				}
				if (iRc >= 0) {
					packet_save(cpInstanceData);
					iDisp = 1;
				}
				else {
					ERROROUTRC("SendMsg rc=",iRc);
					if (tpRecvMsg->msg_resv) {
						iRc = aka_reply_msg(lInstanceHandle,&tMsgCom);
						if (iRc<0) ERROROUTRC("ReplyMsg rc=",iRc);
					}
				}
			}
			else if (tMsgCom.msg_disp & 0x0200) {
				iRc = aka_leave_msg(lInstanceHandle,&tMsgCom);
				if (iRc<0) ERROROUTRC("LeaveMsg rc=",iRc);
			}
			else {
				if (tpRecvMsg->msg_resv) {
					iRc = aka_reply_msg(lInstanceHandle,&tMsgCom);
					if (iRc<0) ERROROUTRC("ReplyMsg rc=",iRc);
				}
			}
			Free(tMsgCom.msg_pmsg);
			tMsgCom.msg_pmsg = NULL;
		}
		else {
			if (tpRecvMsg->msg_resv) {
				iRc = aka_reply_msg(lInstanceHandle,&tMsgCom);
				if (iRc<0) ERROROUTRC("ReplyMsg rc=",iRc);
			}
		}
	}

DEBUGOUTL4(110,"col_mn_analz:Exit: tpRecvMsg.msg_resv=%08x tMsgCom.cpMsg=%08x iDisp=%d iRc=%d",
tpRecvMsg->msg_resv,tMsgCom.msg_pmsg,iDisp,iRc);

	return (iDisp);
}

int coal_start_class(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	AKAMSGCOM tMsg;
	int  iRc,len;
	char val[2],*p;
	static char *reply;
	FILE *fp;

	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		reply = cpInstanceData;
		break;
	case 0:
		memset((char *)&tMsg,0,sizeof(AKAMSGCOM));
		tMsg.msg_clid     = 1;
		tMsg.msg_disp = 1;
		tMsg.msg_pmsg   = tpRecvMsg->msg_pmsg;
		tMsg.msg_mlen = tpRecvMsg->msg_mlen;
		if ((iRc = aka_post_msgWaitTime(lInstanceHandle,&tMsg,
#if 1
		                             INT_MAX
#else
		                             Dm_Inf.msg_time_out*1000
#endif
		                                                     ))) {
			ERROROUT1("coalStarClass: 0: aka_post_msg ret=%d",iRc);
			break;
		}
		return 1;
	case 1:
		if (tpRecvMsg->msg_pret) {
			if (tpRecvMsg->msg_pret == PACKET_TIMEOUT_ERROR) val[0] = AKA_SHUT_MODE_FSHUT;
		}
		else {
			val[0] = AKA_SHUT_MODE_SHUT;
			if (reply) {
				if (!*reply) fp = stdout;
				else {
					if (!(fp=fopen(reply,"wb")))
						ERROROUT3("coal_start_class: file[%s] open error!! errno=%d %s",
						          reply,errno,strerror(errno));
				}
				if (fp) {
					if ((len=tpRecvMsg->msg_mlen-sizeof(TrmToSrv)) > 0) {
						iRc=fwrite(tpRecvMsg->msg_pmsg+sizeof(TrmToSrv),len,1,fp);
						if (iRc <= 0) ERROROUT("coal_start_class: Reply write error!!");
					}
					if (fp != stdout) fclose(fp);
				}
			}
		}
		aka_shut_control(AKA_SHUT_MODE,val);
	}
	return 0;
}

int coal_command_class(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	char *argv0[128],parm[256],*key,**argv;
	int  iRc,len,argc;
	long data[1024];
	TrmToSrv   *tpTrmToSrv ;

	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		break;
	case 0:
/*
akxaxdump("coal_command_class: tpRecvMsg",tpRecvMsg,sizeof(AKAMSGCOM));
*/
		argv = argv0;
		argc = akxtgetargv(tpRecvMsg->msg_pmsg,argv,128,parm,sizeof(parm));
/*
printf("coal_command_class: argc=%d argv[0]=[%s]\n",argc,argv[0]);
*/
		iRc = cl_main_set_opt(&argc,&argv);

		if (!iRc && argc>0) {
			len = coal_make_pkt_form(argc, argv, data, sizeof(data));
			tpRecvMsg->msg_pmsg   = (char *)data;
			tpRecvMsg->msg_mlen = len;
			tpRecvMsg->msg_prid = 0;
			tpRecvMsg->msg_clid = 1;
			tpRecvMsg->msg_aopt = 0;
			tpRecvMsg->msg_disp = 1;
			iRc = aka_post_msg(lInstanceHandle,tpRecvMsg);
			if (iRc) {
				sprintf((char *)data,"coalComandClass: aka_post_msg ret=%d",iRc);
				ERROROUT((char *)data);
			}
		}
		else {
			sprintf((char *)data,"coalComandClass: ret=%d argc=%d",iRc,argc);
			iRc = -1;
		}
		if (iRc) {
			if (tpRecvMsg->msg_resv) {
				tpRecvMsg->msg_pmsg   = (char *)data;
				tpRecvMsg->msg_mlen = strlen((char *)data);
				iRc = aka_reply_msg(lInstanceHandle,tpRecvMsg);
				if (iRc < 0) ERROROUT1("ReplyMsg ret=%d",iRc);
			}
			break;
		}
		return 1;
	case 1:
		if (tpRecvMsg->msg_resv) {
			tpTrmToSrv = (TrmToSrv *)tpRecvMsg->msg_pmsg;
			iRc = ntohl(tpTrmToSrv->parmnum);
			if (iRc >= 0) {
				tpRecvMsg->msg_pmsg   += sizeof(TrmToSrv);
				tpRecvMsg->msg_mlen -= sizeof(TrmToSrv);
			}
			else {
				sprintf((char *)data,"*** ret=%d",iRc);
			/*	ERROROUT((char *)data);	*/
				tpRecvMsg->msg_pmsg   = (char *)data;
				tpRecvMsg->msg_mlen = strlen((char *)data);
			}
			iRc = aka_reply_msg(lInstanceHandle,tpRecvMsg);
			if (iRc < 0) ERROROUT1("ReplyMsg ret=%d",iRc);
		}
	}
	return 0;
}

int cl_shut_class(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		/* aka_registerClass()�ł��̊֐���o�^�����Ƃ��ɌĂ΂��B */
		break;
	case 0:
		/* ���v���Z�X����̔��M���b�Z�[�W�̏����B */
		if (tpRecvMsg->msg_pret) {
			/* �ԐM�����ʃv���b�g�t�H�[�����ŃG���[�ɂȂ�Ԃ��ꂽ�B */
			break;
		}
		/* �R�}���h�̉�͂Ǝ��s */
		aka_wake_up_msg(0,D_ERR_SHUT_WAKEUP);
		break;
	default:
		break;
	}
	return 0;
}
