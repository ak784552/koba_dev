char version[] ="@(#) ***[V/R=1.1.1 (mini_for)]***";

