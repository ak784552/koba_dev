/*static    char    sccsid[]="%Z% %M% %I% %E% %U%";*/
/********************************************************/
/*														*/
/*	clprot.h											*/
/*														*/
/*		coded by A.Kobayashi 2010.5.28					*/
/*														*/
/*********************************************************/
#ifndef _CLPROT_H
#define _CLPROT_H

/* cl_anal_parm.c */
int cl_anal_parm(/*pparmList*/);
int cl_chk_parm(/*p,len*/);
int cl_chk_name_pos(/*buf,buflen,opt*/);
int cl_chk_name_opt(/*buf,buflen,opt*/);
int cl_chk_name(/*buf, buflen*/);
int cl_chk_name_const(/*buf,buflen*/);
int cl_chk_proc_name(/*buf,buflen*/);
int cl_chk_file_name(/*buf, buflen*/);
int cl_chk_digit_n(/*prp,prmlen*/);
tdtExtValName *cl_get_sysvar_name(/*name, name_len, opt*/);
int cl_chk_sysvar_name(/*buf, len*/);
char *strname(/*s,len*/);
char *strname3(/*s1,len1,s2,len2,s3,len3*/);
char *strntmp2(/*s1,len1,s2,len2*/);
char *strtmp2(/*s1,s2*/);
char *strtemp(/*s,len*/);
tdtException *cl_get_exception_name(/*name, name_len, opt*/);
int cl_mk_exception_code(/*e,rc*/);
int cl_is_exp(/*line,line_len,opt*/);
int cl_is_proc_scr_name(/*buf,buflen*/);
int cl_chk_name_var(/*buf, buflen*/);

/* cl_array.c */
int cl_array_check_valid(/*pInfoParm*/);
int cl_get_array_index(/*pInfoParm,ppIndex*/);
int cl_get_array_psize(/*pInfoParm,pcn,ppSize,ppTBL*/);
int cl_update_map_array_max(/*pInfoParm*/);
int cl_get_array_index_tbl(/*pInfoParm,pIndex,ppTBL,pMsg*/);
int cl_get_array_index_tbl_ref(/*pInfoParm,ppIndex,ppTBL,pMsg*/);
int cl_gx_conv_index(/*pInfoParm,pIndex*/);
int cl_check_use_mapped_array(/*pInfoParm*/);
int cl_check_use_hash_array(/*pInfoParmArray,pIndex*/);
int cl_get_array_val_opt(/*pInfoParmW,pIndex,iParmNo,opt*/);
int cl_array_get_info_parm(/*ppParmI,pIndex1,pTBL1,ix1,opt*/);
int cl_get_array_info_ref(/*pInfoParm,ppIndex,ppTBL,iParm*/);
int cl_get_array_info(/*pInfoParm,pIndex,ppTBL,iParm*/);
int cl_get_mapped_array(/*pInfoParmW,pInfoParm1,pOperator,pInfoParm2*/);
int cl_free_array_ent(/*pIndex*/);
tdtInfoParm *cl_get_array_ent();
tdtInfoParm *cl_get_array_ent_opt();
tdtInfoParm *cl_get_array_and_var_ent(/*pInfoParmArray,pIndex,pTBL,ix*/);
tdtInfoParm *cl_get_array_and_var_ent_opt(/*pInfoParmArray,pIndex,pTBL,ix,opt*/);

/* cl_chk_digit.c */
int cl_chk_digit(/*rad, buf, len*/);
int cl_chk_digit_x(/*buf, len*/);
int cl_chk_digit_fopt(/*rad, buf, len, opt*/);
int cl_chk_digit_f(/*rad, buf, len*/);
int cl_chk_maybe_num(/*buf,len*/);

/* cl_class.c */
int cl_func_new(/*pInfoParmW,nparm,ppParm*/);
int cl_set_instance_method(/*pInfoParmW,pInfoParm1,pInfoParm2,optW,name,len2*/);
int cl_set_class_method(/*pInfoParmW,pInfoParm1,pInfoParm2,optW,name,len2*/);
int cl_ex_class_method(/*pInfoParmW,pInfoParmM,nparm,ppParm,opt*/);
int cl_exec_super_class(/*cur_procct,procct,pRb,super_nam,super_nam_len*/);

/* cl_cmpt_comp.c */
int _is_1(/*pInfoParm*/);
int _set_complex(/*pComplex,pInfoParm1*/);
int _get_comp_no(/*pOprtr,opt*/);
int _memcmplen(/*p1,len1,p2,len2,opt*/);
int cl_cmpt_comp_opt(/*pAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp,cmp_opt*/);
int cl_cmpt_comp(/*pAns,pOprtr,pInfoParm1,pInfoParm2,narg,prmp*/);
int _get_nparm_opt(/*nparm,ppParm,popt*/);
int cl_func_comp(/*ppWork,pOperator,nparm,ppParm,ope*/);
int _get_str_pos_posb(/*p0,len0,posa,posa1*/);
int _get_str_pos(/*pos,ppp0,plen1,plenm*/);
int _get_pos_len(/*i,pInfoParm,pos*/);
int cl_get_str_pos(/*nparm,ppParm,i1,ppp0,plen1,plenm,ppos,msg*/);
int cl_get_str_pos2(/*nparm,pParm,i1,ppp0,plen1,plenm,ppos,msg*/);
int cl_gx_str_pos(/*pInfoParmW,pInfoParm1,optW,pInfoParm2*/);
int _rep_wildcard(/*pat,pat0,patlen,cmd*/);
int cl_gx_str_edit(/*pInfoParmW,pInfoParm1,pat0,patlen*/);
int cl_gx_str_edit_like(/*text,len1,pat0,patlen0,pos,len,mflg*/);
int cl_comp_list(/*pOprtr,pInfoParm1,pInfoParm2,iParm,cmp_opt*/);
int cl_in_string1(/*pInfoParm0,pInfoParm,opt*/);
int cl_in_string(/*ppWork,nparm,ppParm,opt*/);
int cl_in_number1(/*pInfoParm0,pInfoParm,opt*/);
int cl_in_number_array(/*ppAns,pInfoParm0,pInfoParm1,opt*/);
int cl_in_number_list(/*ppAns,pInfoParm0,pInfoParm1,opt*/);
int cl_in_number_sub(/*ppAns,pInfoParm0,nparm,ppParm,opt*/);
int cl_in_number(/*ppAns,pInfoParm0,nparm,ppParm,opt*/);
int cl_comp_info(/*ppInfoParm,pInfoParm1,pInfoParm2,ope*/);
int cl_func_agg_sub(/*pWork,nparm,ppParm,ope,pInfoParm0*/);
int cl_func_agg(/*pWork,nparm,ppParm,ope0*/);

/* cl_cmpt_complex.c */
int cl_cmpt_complex(/*pInfoParmW,pOprtr,pInfoParm1,pInfoParm2*/);
int cl_func_complex(/*pInfoParmW,nparm,ppParm*/);
int cl_adjust_complex(/*pInfoParmW,pInfoParm1,pInfoParm2*/);

/* cl_cmpt_date.c */
int cl_tm2mpa(/*ma,stm,usec*/);
int cl_mpa2tm(/*stm,ma*/);
int cl_func_to_date(/*pInfoParmW,nparm,ppParm*/);
int cl_func_set_date_part(/*pInfoParmW,nparm,ppParm*/);
int cl_date2uxstr(/*p2,len,p1,ma*/);
int cl_func_to_char(/*pInfoParmW,nparm,ppParm*/);
int cl_get_parm_date(/*pInfoParmW,ma,msg*/);
int cl_set_parm_date(/*pInfoParmW,ma*/);
int cl_get_term_index(/*pInfoParm*/);
char cl_get_term_char(/*index*/);
int cl_func_date_add(/*pInfoParmW,nparm,ppParm*/);
int cl_func_add_to_date(/*pInfoParmW,nparm,ppParm*/);
int cl_date_add_term(MPA *ma, long lValue, int n);
int cl_func_date_diff(/*pInfoParmW,nparm,ppParm*/);
int cl_date_diff_sub(/*ptt,n,ma1,ma2*/);
int cl_func_add_months(/*pInfoParmW,nparm,ppParm*/);
int cl_is_leap_year(/*y*/);
int cl_days_of_month(/*yyyy,mm*/);
int cl_func_last_day(/*pInfoParmW,nparm,ppParm*/);
int cl_cmpt_date(/*pInfoParmW,pOperator,pInfoParm1,pInfoParm2*/);
int cl_chk_time_interval(char *s0,int slen0,int val[],char **p0);
int cl_date2str(/*p2,len2,s0,slen0,ma*/);
int cl_str2date(/*p2,len2,s0,slen0,ma*/);

/* cl_cmpt_is.c */
int cl_cmpt_is(/*pAns,pOprtr,nparm,ppParm,ope,opt*/);

/* cl_cmpt_logic.c */
int cl_get_logic_val(/*pInfoParm1*/);
int cl_cmpt_logic(/*pAns, pOprtr, pInfoParm1, pInfoParm2*/);
int cl_cmpt_agg(/*pInfoParmW,pOprtr,pInfoParm1,pInfoParm2*/);
int cl_func_logic(/*ppWork,pOperator,nparm,ppParm,ope*/);

/* cl_cmpt_math.c */
int cl_cmpt_math_real(/*pInfoParmW,pOperator,pInfoParm1,pInfoParm2*/);
int cl_cmpt_math_info(/*pInfoParmW,pOprtr,pInfoParm1,pInfoParm2*/);
int cl_cmpt_math(/*pAns, pOprtr, pInfoParm1, pInfoParm2,iParm*/);
long cl_chk_over_flow_long_add(/*Val3,Val1,Val2,name,pstat*/);
long cl_chk_over_flow_long_sub(/*Val3,Val1,Val2,name,pstat*/);
long cl_chk_over_flow_long_mult(/*Val3,Val1,Val2,name,pstat*/);
ulong cl_chk_over_flow_ulong_add(/*uVal3,uVal1,uVal2,name,pstat*/);
ulong cl_chk_over_flow_ulong_sub(/*uVal3,uVal1,uVal2,name,pstat*/);
ulong cl_chk_over_flow_ulong_mult(/*uVal3,uVal1,uVal2,name,pstat*/);
int cl_get_parm_ubin_opt(/*pInfoParm,pValue,pMsg,iUNSIG,opt*/);
int cl_get_parm_ubin(/*pInfoParm,pValue,pMsg,iUNSIG*/);
int cl_get_parm_bin_opt(/*pInfoParm,pValue,pMsg,opt*/);
int cl_get_parm_bin(/*pInfoParm,pValue,pMsg*/);
#if 0
int cl_get_parm_ulong_opt(/*pInfoParm,pValue,pMsg,iUNSIG,opt*/);
int cl_get_parm_ulong(/*pInfoParm,pValue,pMsg,iUNSIG*/);
int cl_get_parm_long_opt(/*pInfoParm,pValue,pMsg,opt*/);
int cl_get_parm_long(/*pInfoParm,pValue,pMsg*/);
#endif
int cl_get_parm_mpa_opt(/*pInfoParm,pValue,pMsg,iAttr,opt*/);
int cl_get_parm_mpa(/*pInfoParm,pValue,pMsg,iAttr*/);
int cl_get_parm_double_opt(/*pInfoParm,pValue,pMsg,iAttr,opt*/);
int cl_get_parm_double(/*pInfoParm,pValue,pMsg,iAttr*/);
int cl_get_parm_dec_opt(/*pInfoParm,pValue,pMsg,iAttr,opt*/);
int cl_get_parm_dec(/*pInfoParm,pValue,pMsg,iAttr*/);
long cl_chk_over_flow_d2_l(/*d,name*/);
int cl_chk_over_flow_d2_i(/*d,name*/);
ulong cl_chk_over_flow_d2_ul(/*d,name*/);
uint cl_chk_over_flow_d2_ui(/*d,name*/);
int cl_chk_over_flow_l2_i(/*l,name*/);
int cl_chk_error_mpa(/*rc,pMsg,p,len*/);
int cl_get_data_int(/*pInfoParm*/);
long cl_get_data_long(/*pInfoParm*/);
long cl_get_val_long(/*val*/);
int cl_conv_upper(/*pInfoParm1,pInfoParm2*/);
int cl_get_parm_range_mpa_opt(/*pInfoParm,pValue,pMsg,iAttr,opt*/);
int cl_get_parm_range_mpa(/*pInfoParm,pValue,pMsg,iAttr*/);
int cl_get_parm_range_double(/*pInfoParm,pValue,pMsg,iAttr*/);
int cl_conv_upper2(/*pInfoParmW1,pInfoParmW2,lVal1,lVal2,pInfoParm1,pInfoParm2,opt*/);

/* cl_cmpt_string.c */
int cl_cmpt_string(/*pAns, pOprtr, pInfoParm1, pInfoParm2, nparm, prmp*/);
int concat(/*pAns, pInfoParm1, pInfoParm2, nparm, prmp, pParm*/);
int cl_concat_info(/*ppWork,len1,nparm,prmp,pParm*/);
int substr_mlen(/*pList,p1,len1,msp,mn*/);
int substr_len(/*mflg, pList, pInfoParm1, pInfoParm2, pInfoParm3*/);
int substrm(/*pAns, mflg, pInfoParm1, pInfoParm2, pInfoParm3*/);
int substr(/*pAns, pInfoParm1, pInfoParm2, pInfoParm3*/);
int replace(/*pAns, pInfoParm1, pInfoParm2*/);
int condas(/*pAns, pInfoParm1, pInfoParm2*/);
int cl_double_to_str(/*s,s_len,dValue*/);
int cl_mpa2an(/*mpa,work,w_len,m_flg,dec_pre,dec_sca*/);
int clcnvtb2c(/*bip,len,bu*/);
int cl_parm_to_char_opt(/*pInfoParm1,p1,p1_len,p1_free*/);
int parm_to_char2(/*pInfoParm1,p1,p1_free,opt*/);
int parm_to_char(/*pInfoParm1,p1,p1_free*/);
int parm_to_char_tmp(/*pInfoParm1,p1,len*/);
int cl_get_ITBL_maxargs(/*nparm,ppParm,pIndex,ppTBL,iMINARGS,iMAXARGS,pmaxargs,set_defualt*/);
int cl_get_ITBL_maxargs_ref(/*nparm,ppParm,ppIndex,ppTBL,iMINARGS,iMAXARGS,pmaxargs,set_defualt*/);
int cl_get_args(/*pWork,nparm,ppParm*/);
int cl_split(/*pWork,nparm,ppParm*/);
int cl_get_word(/*pWork,nparm,ppParm*/);
int cl_trim(/*pAns,nparm,ppParm*/);
int cl_strings(/*pAns,nparm,ppParm*/);
int cl_leftm(/*pAns,mflg,nparm,ppParm*/);
int cl_left(/*pAns,nparm,ppParm*/);
int cl_right_leftm(/*pAns,mflg,nparm,ppParm,rl*/);
int cl_rightm(/*pAns,mflg,nparm,ppParm*/);
int cl_right(/*pAns,nparm,ppParm*/);
int cl_in_str(/*pWork,nparm,pParm*/);
int cl_edit_sub(/*pAns,format,nparm,ppParm,iOpta*/);
int cl_edit_opta(/*pAns,nparm,ppParm,iOpta*/);
int cl_edit(/*pAns,nparm,ppParm*/);
int cl_eedit(/*pAns,nparm,ppParm*/);
int cl_chr(/*pAns,nparm,ppParm*/);
int cl_asc(/*pWork,mflg,nparm,ppParm*/);
int _get_pos_text(/*nparm,ppParm*/);
int _get_parm_str_pos(/*nparm,ppParm,pos0*/);
int _get_edit_rep_pat(/*pat,patlen,escape,iOpt,pa,lena*/);
int _get_opt_pat(/*p,opt,sel_opt*/);
int _get_line_pat(/*nparm,ppParm,p1,len,iOpt,pos,pplike,pos_opt*/);
int cl_rep_like(/*pAns,nparm,ppParm*/);
int cl_shsbs(/*pInfoParmW,nparm,ppParm*/);
int cl_in_like(/*pWork,mflg,nparm,ppParm*/);
int cl_rlpad(/*pAns,mflg,nparm,ppParm,ope,pOperator*/);
int cl_get_code_type(/*pInfoParm,tr_dtypea,tr_code*/);
int cl_func_str_conv(/*pAns,nparm,ppParm*/);
int _func_str_conv(/*pAns,tr_dtypea,tr_code,p1,len*/);
int cl_edit_sub(/*pAns,format,nparm,ppParm*/);
int cl_str_conv_type(/*p2,p1,len1,typed,types*/);
int cl_str_conv_get(/*p2,p1,len1*/);
int cl_str_conv_put(/*p2,p1,len1*/);
int cl_in_regex(/*pWork,mflg,nparm,ppParm*/);
int cl_rep_regex(/*pAns,mflg,nparm,ppParm*/);
int cl_get_info_str(/*pInfoParm,ppStr,opt*/);

/* cl_cmpt_strnum.c */
int rstr_exp_num(/*pList,mc,str,str_len,num,i0*/);
int cl_str_exp(/*pInfoParmW,pOperator,pInfoParm1,pInfoParm2*/);
int cl_str_add(/*pInfoParmW,mc0,pInfoParm1,pInfoParm2*/);
int cl_str_mult_str(/*pInfoParmW,pInfoParm1,pInfoParm2*/);
int str_num_cmp(/*a,len_a,b,len_b*/);

/* cl_cmpt_to.c */
int cl_cmpt_to(/*pAns,pOprtr,nparm,ppParm,ope,opt*/);
int cl_cmpt_to_number(/*pWork,nparm,ppParm,iParm*/);
int cl_mpa_scale_opt(/*mpa,precision,scale,option*/);
int cl_mpa_scale(/*mpa,precision,scale*/);

/* cl_code_trans.c */
int cl_code_trans(/*pInfoParm, pInfoParmd*/);

/* cl_const_mem_get.c */
char *cl_const_ct_malloc(/*ConstCt,Len*/);
ConstantCt *cl_const_ct_new_opt(/*opt*/);
ConstantCt *cl_const_ct_new();
char *cl_tmp_const_malloc(/*Len*/);
char *cl_tmp_const_remalloc(/*mem,len*/);
char *cl_tmp_const_free(/*mem*/);
int cl_tmp_const_clear(/*iopt*/);
int cl_tmp_const_ct_set(/*pConstCt*/);
char *cl_scr_malloc(/*iLen*/);
char *cl_leaf_malloc(/*iLen*/);
char *cl_opt_malloc(/*im,iLen*/);
int cl_mem_used(/*n,lena*/);
char *cl_const_ct_malloc2(/*ConstCt,Len,file,line*/);
char *cl_tmp_const_malloc2(/*len,file,line*/);
char *cl_opt_malloc2(/*im,iLen,file,line*/);

/* cl_conv_arg.c */
int cl_conv_arg_opt_kind(/*pparmList, pInfoParm, opt, rc*/);
int cl_conv_arg_opt(/*pparmList, pInfoParm, opt*/);
int cl_conv_arg(/*pparmList, pInfoParm*/);
int cl_arg_to_char_num(/*pparmList,Obj,pInfoParm,msg,opt,only_char*/);
int cl_arg_to_char(/*pparmList,Obj,pInfoParm,msg*/);
int cl_arg_to_char_opt(/*pparmList,Obj,pInfoParm,msg,opt*/);

/* cl_conv_const_c.c */
int cl_conv_const_c(/*pparmList, pInfoParm*/);
int cl_conv_const_cmd(/*pparmList,pInfoParm*/);
int cl_set_parm_char(/*pInfoParm,pBuff,point*/);
int cl_set_parm_char2(/*pInfoParm,pBuff,point,code_type*/);
int cl_conv_yen(/*buff,len,wkstr*/);
int cl_get_char_code_type(/*pInfoParm,opt*/);
int cl_is_mbyte(/*pInfoParm,code_type*/);
int cl_sep_string_with_type(/*par,p,len*/);
char *cl_set_type_to_string(/*p,len1,code_type*/);

/* cl_conv_const_n.c */
int cl_conv_const_n(/*pparmList , pInfoParm*/);
int cl_conv_const_n_str(/*pInfoParm, prp, len*/);
int cl_conv_const_double(/*p,len,pValue,pMsg,iAttr*/);
int cl_set_parm_bin(/*pInfoParm,iValue*/);
int cl_set_parm_int(/*pInfoParm,iValue*/);
int cl_set_parm_long(/*pInfoParm,lValue*/);
int cl_set_parm_double(/*pInfoParm,dValue*/);
int cl_set_parm_mpa2(/*pInfoParm,val,len0*/);
int cl_set_parm_mpa(/*pInfoParm,val*/);
int cl_set_parm_char(/*pInfoParm,pBuff,point*/);
int cl_conv_const_mpasub(/*p,len,pValue,pMsg,iAttr,opt*/);
int cl_cvn10(/*p,len,pvalue*/);
long *cl_get_tmpMPA(/*long *az*/);
long *cl_get_tmpMPA2(/*long *az,int m*/);
long *cl_get_tmpMPA10W2(/*long *az,int m*/);
long *cl_get_tmpMPA_pre1(/*long *az*/);
long *cl_get_tmpMPA3(/*long *az,int nmpa_long,int m*/);
int cl_sign_reverse(/*pInfoParm*/);
int cl_qnconv(/*buf,buf_len,pnum*/);

/* cl_conv_parm.c */
int cl_conv_parm(/*pparmList, pInfoParm*/);
int cl_conv_const_nsub(/*p0,len0,pValue,pMsg,iAttr,opt*/);
int cl_gx_chk_vnam_info(/*opt,pha,name,nl,ppInfo*/);
int cl_gx_chk_vnam(/*opt,pha,name,nl*/);
int cl_gx_get_vnam(/*pha,ix,ppnam*/);
int cl_conv_parm_opt(/*pparmList, pInfoParm, opti*/);
int cl_gx_get_info_parm_opt(/*pScCT,opt,pparmList,ppInfoParm,iOpt*/);
int cl_gx_get_info_parm_opt_psize(/*pScCT,opt,pparmList,ppInfoParm,iOpt,ppar_pSize*/);
int cl_gx_get_info_parm(/*pScCT,opt,pparmList,ppInfoParm*/);
int cl_gx_get_parm_no(/*pScCT,proc,varnam,vnlen,opt,iOpt,ppTBL_vnam,piLGopt*/);
int cl_gx_get_parm_no_info(/*pScCT,proc,varnam,vnlen,opt,iOpt,ppInfo*/);
int cl_gx_get_all_var_ent(/*pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt*/);
int cl_gx_get_all_var_ent_psize(/*pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt,ppar_pSize*/);
int cl_gx_get_lg_var_ent(/*pScCT,opti,name,ppInfoParm,varnam,iOpt,iEROUT_NDEF*/);
int cl_gx_get_lg_var_ent_psize(/*pScCT,opti,name,ppInfoParm,varnam,iOpt,iEROUT_NDEF,ppar_pSize*/);
tdtInfoParm *cl_get_var_ent();
tdtInfoParm *cl_get_var_ent_opt(/*pVarIndex,ParmNo,opt*/);
tdtInfoParm *cl_get_var_ent_opt_psize(/*pVarIndex,ParmNo,opt,ppar_pSize*/);
int cl_free_info_parm(/*pDummy*/);
int cl_free_var_ent(/*pVarIndex*/);
int cl_reset_var_ent(/*pVarIndex*/);
int cl_set_max_var_ent(/*pSize,ParmNo*/);
int cl_gx_chk_scope(/*opt,proc,varnam,vnlen,pprocW*/);
int cl_gx_chk_scope_info(/*opt,proc,varnam,vnlen,pprocW,ppInfo*/);
int _check_gid_alive(/*pInfoParmW,fnam,vnam,iEROUT_NDEF*/);
int cl_mk_static_name(/*wrk,prnam,prlen,varnam,vnlen*/);

/* cl_conv_sysvar.c */
int clgetsysdate(/*ma*/);
int cl_conv_sysvar(/*pparmList, pInfoParm*/);

/* cl_ex_get_proc_name.c */
int cl_trim_proc_name(/*p0,len0,pr_nam*/);
int cl_ex_get_proc_name(/*pparmList, Obj, pr_nam*/);
int cl_dot_name_check_opt(/*func,pr_nam,opt*/);
int cl_dot_name_check(/*pr_nam*/);
int cl_exe_proc_name_check(/*pr_nam*/);
int cl_ex_get_proc_scr_name(/*pparmList,Obj,pr_nam,sc_nam*/);

/* cl_execute_proc.c */
int cl_execute_scr_proc(/*pprmp,prmnum,pProc,scrprct,name*/);
int cl_execute_proc(/*pprmp,prmnum,pProc,name*/);
int cl_exec_function(/*name,pInfoParmW,nparm,ppParm*/);
int cl_exec_func_setup_proc(/*name,pInfoParmW,nparm,ppParm,wkleaf,nodeleaf,opt,class_proc*/);
int cl_exec_func_execute(/*cur_procct*/);

/* cl_get_script_name.c */
int cl_get_script_name(/*pcmdID*/);

/* cl_gx_chk_opt.c */
int cl_gx_chk_opt(/*pOperator,ex_opt*/);
int cl_im_mman_init(/*mcat,id,extlen,maxcnt,im*/);
int cl_im_mcat(/*mcat,s,len*/);
int cl_im_mcatz(/*mcat,s,len*/);

/* cl_gx_compute.c */
int _gx_ppmm(/*atr,pInfoParm*/);
int cl_gx_parm_conv_arg(/*ppParm,ipa,nparm,prmp,Obj,opt,pppParm,pSetNum*/);
int cl_gx_bexp_func_bexp(/*pInfoParmW,pInfoParm1,pOperator,pInfoParm2,nparm,prmp*/);
int cl_proc_bexp(/*pLeaf,proc*/);
int cl_process_let(/*pLeaf, proc*/);
int cl_gx_compute(/*pLeaf,proc*/);
int let_compute_sub_opt(/*nparm,prmp,Obj,opt,ppInfoParm,pInfoParmW*/);
int let_compute_sub(/*nparm,prmp,Obj*/);
int let_compute_prmp_info(/*nparm,prmp,proc,opt,ppInfoParm*/);
int let_compute_prmp_infoW(/*nparm,prmp,proc,opt,pInfoParmW*/);
int let_compute_info(/*pLeaf, proc, opt, ppInfoParm*/);
int let_compute_opt(/*pLeaf, proc, opt*/);
int let_compute(/*pLeaf,proc*/);
int cl_gx_bexp(/*pInfoParmW,pInfoParm1,pOperator,pInfoParm2,nparm,prmp*/);
int let_compute_return(/*leaf,proc*/);
int cl_check_data_id(/*pInfoParm,opt*/);
int cl_check_data_id2(/*pInfoParm,opt,opt2*/);
char *cl_get_variable_type(/*id*/);
int cl_gx_let_ppmm(/*atr,pInfoParm*/);
int cl_gx_cast(/*pInfoParmW,pInfoParm1,pInfoParm2*/);
int cl_check_attr(/*pInfoParm,attr0,msg*/);
int cl_gx_mk_cast(/*pInfoParmW,pm,nparm,ppParm*/);
int cl_func_conv(/*pInfoParmW,ope,pOperator,nparm,ppParm*/);

/* cl_gx_compile.c */
int cl_gx_get_aux1_from_opt(/*opt*/);
int cl_gx_get_opt_from_aux1(/*i*/);
char *cl_gx_get_name_from_id(/*id*/);
char *cl_gx_get_name_from_info(/*pInfoParmW*/);
int cl_skip_scope_mark(/*pLprp,pLlen,pix*/);
int _conv_arg_opt2(/*da,len,pInfoParmW,opt*/);
int _conv_arg_opt(/*da,pInfoParmW,opt*/);
int cl_is_yoyakugo(/*name*/);
int cl_gx_compile_gp_opt(/*pgwprm,pssp,iOpt,pGxObjExpand*/);
int _ex_get_member(/*ppInfoParmW,opt,da,len*/);
int cl_set_storevar(/*pInfoParmW,pInfoParm,opt_set*/);
int cl_chk_protected(/*pInfoParmW,func_name,da*/);
int _ex_conv_parm_opt(/*ppInfoParmW,opt,da*/);
int _kakko_tenkai(/*mcat,tInfoParm2,pInfoParm*/);
void _reset_addr(/*ppmstk,pmstk,irs*/);
#if 1	/* 2021.11.1 */
char **_mk_obj_stack(/*nobj*/);
#else
int _mk_obj_stack(/*pbxObj*/);
#endif
int cl_gx_ex_obj(/*Obj,pGxObj,pInfoParmW,iOpt*/);
int cl_gx_ex_obj_sub(/*Obj,pGxObj,pInfoParmW,iOpt,Msa,iva*/);
tdtObjHead *cl_gx_get_scr_obj();
tdtObjHead *cl_gx_get_proc_obj();
tdtObjHead *cl_gx_get_obj();
int _clear_obj_addr(/*pGxObj,pInfoParm0,obj0*/);
int cl_gx_clear_var_obj(/*leaf,curleaf,varnam,Obj,scope*/);
int cl_gx_clear_var_obj2(/*leaf,curleaf,varnam,Obj,scope*/);
int cl_gx_clear_var_obj_sub(/*leaf,curleaf,varnam,Obj,scope,right_flg*/);
int cl_gx_clear_var90(/*pInfoParm,da*/);
int cl_gx_clear_var_define(/*scrct,proc,varnam,opt*/);
int cl_gx_clear_var_obj_all(/*scrpt,curleaf,varnam,scope*/);
int cl_gx_iif_optimize(/*obj,nob,obj0*/);
int cl_gx_iif_optimize_sub(/*obj,nob,obj0,i0,nam*/);
int cl_gx_iif_optimize_sub2(/*obj,nob,obj0,i0,kind*/);
int cl_gx_iif_optimize_chk_sub(/*obj,nob,obj0,i,pInfoParm*/);
int cl_get_optimize_kind(/*p*/);

/* cl_gx_exp_imd.c */
int cl_get_obj0_used(/*proc,scrct*/);
int cl_gx_expsn_obj_opt(/*buf,len,bxobj,Obj,pInfoParmW,opt*/);
int cl_gx_exps_obj_opt(/*buf,bxobj,Obj,pInfoParmW,opt*/);
int cl_gx_exp_obj_opt(/*nparm,prmp,Obj,pInfoParmW,opt*/);
int cl_gx_exp_obj_opt_tree(/*nparm,prmp,Obj,pInfoParmW,opt,iTREE*/);
int cl_set_obj0_used(/*used*/);
int cl_gx_exp_obj(/*nparm,prmp,Obj,pInfoParmW*/);
int cl_mk_gp_parm(/*mcat,pgwprm,nparm,prmp*/);
int cl_gx_exp_gp_obj_opt(/*pgwprm,pssp,bxobj,Obj,pInfoParmW,opt*/);
int cl_gx_exp_gp_obj_opt_tree(/*pgwprm,pssp,bxobj,Obj,pInfoParmW,opt,iTREE*/);
int cl_gp_gwse(/*gwprm,ssp,sep,opt*/);
int cmpgwnsl(/*line,line_len,ssp,ex_opt*/);
int cmppeekwnsl(/*line,line_len,ssp,ex_opt*/);
int cmp_peekwd(/*gwprm,ssp,ex_opt*/);
int cmp_gtwd(/*gwprm,ssp,ex_opt*/);
int cmp_mkix(/*atr*/);
int cmp_act(/*i1,i2*/);
int cl_gx_func(/*ppmstk,irs,pW,opt,pmstk,dastk*/);
int cl_gx_array3(/*ppmstk,irs,pW,opt,pmstk,dastk*/);
int cl_gx_array_bexp(/*pInfoParmW,nparm,ppParm,opti*/);
int cl_gx_range_tenkai(/*ppmstk,irs,pW,opt,pmstk,dastk,ms_ppmstk,ms_pmstk,ms_dastk*/);
int cl_gx_range(/*pW,nparm,pm,opt*/);
int cl_gx_range_set(/*pW,nparm,pm,opt*/);
int cl_gx_is_operator(/*pOperator,kubun*/);
int cl_gx_is_func_kubun(/*i*/);
int cl_im_expand(/*mcat,cnt,pbuf2*/);
int cl_gx_init_expand(/*mcat,id,size,extent*/);
int cl_gx_expand(/*mcat,cnt,pbuf2*/);
int cl_gx_conv_rc(/*rc, conv_rc*/);
int cl_im_init_expand(/*mcat,id,size,extent,im*/);
int cl_gx_is_separator(/*c*/);
tdtObjHead *_mk_add_obj0(/*Obj,im*/);
tdtObjHead *_add_obj0(/*Obj,pbxObj*/);
int _re_set_obj0(/*Obj,pbxObj*/);
tdtObjHead *_check_add_obj0(/*Obj,pbxObj*/);

/* cl_gx_func_bexp.c */
char *cl_get_func_name(/*no,parm*/);
qOpeTable *cl_get_func_info(/*pName,parm*/);
char *cl_get_func_info_ope(/*func_ope,parm*/);
int cl_gx_func_bexp(/*pInfoParmW,pOperator,nparm,ppParm,opt,pParm*/);
int cl_set_parm(/*pInfoParmW,pWork,dtatr,iParm*/);
int cl_ex_method(/*pInfoParmW,pInfoParm1,optW,p2,len2*/);
int cl_set_system_method(/*pInfoParmW,pInfoParm1,pInfoParm2,optW,p2,len2*/);
int cl_gx_func_method(/*pInfoParmW,pInfoParmM,nparm,ppParm,opt,pParm*/);
int rep_condas(/*pAns,nparm,ppParm,func*/);

/* cl_gx_get_index.c */
int cl_gx_get_index_array(/*pparmList, varnam, ppArrayInfo,iOpt*/);
int _iterate_circ_ref(/*pIter_ctl,pVal,msg*/);
int cl_iterate_info_init2(/*pIter,prmp,pParm,pParm,max_layer,m_alloc*/);
int cl_iterate_info(/*pIter,stack*/);
int cl_iterate_info_sub(/*pIter_ctl*/);
int cl_iterate_info_check(/*pIter,stack,pInfoParmW*/);
int cl_iterate_info_init(/*pIter,prmp,pParm,max_layer*/);
int cl_iterate_info_free(/*pIter_ctl*/);

/* cl_gx_rep_prm_set.c */
int cl_gx_rep_complex(/*pInfoParmO,pInfoParmI,iOpt*/);
int cl_gx_rep_val_set(/*pInfoParmO,pInfoParmI*/);
int cl_gx_rep_info_copy_data(/*pInfoParmO,pInfoParmI,iOpt0*/);
int cl_gx_rep_info_set_name(/*pInfoParmO,pInfoParmI,iOpt0,name*/);
int cl_gx_rep_info_set(/*pInfoParmO ,pInfoParmI ,iOpt*/);
int cl_gx_rep_info_set_alloc(/*pvParmO,pInfoParmI,opt*/);
int cl_gx_rep_info_set_ign(/*pInfoParmO,pInfoParmI,iOpt*/);
int cl_gx_rep_info_convert(/*pInfoParmO,pInfoParmI,iOpt0*/);
int cl_gx_rep_info_als(/*pInfoParmO,pInfoParmI,iOpt0*/);
int cl_gx_rep_info_als_name(/*pInfoParmO,pInfoParmI,iOpt0,name*/);
int cl_gx_rep_info_data(/*pInfoParmO,pInfoParmI,iOpt0*/);
tdtInfoParm *cl_gx_copy_info_opt(/*pInfoParmO,pInfoParmI,opt*/);
tdtInfoParm *cl_gx_copy_info2_opt(/*pInfoParmO, pInfoParmI,opt*/);
tdtInfoParm *cl_gx_copy_info2(/*pInfoParmO, pInfoParmI*/);
tdtInfoParm *cl_gx_copy_info(/*pInfoParmO, pInfoParmI*/);
int cl_gx_array_add(/*pInfoParmW,op,pInfoParm1,pInfoParm2*/);
int cl_gx_list_minus(/*pInfoParmW,op,pInfoParm1,pInfoParm2*/);
int cl_gx_list_add(/*pInfoParmW,op,pInfoParm1,pInfoParm2*/);
int cl_gx_array_minus(/*pInfoParmW,op,pInfoParm1,pInfoParm2*/);

/* cl_gx_rep_set.c */
int _get_array_info_ref(/*nparm,ppParm,ppIndex,ppTBL,iParm,opt*/);
int _get_array_info(/*nparm,ppParm,pIndex,ppTBL,iParm,opt*/);
int _get_array_info_used(/*nparm,ppParm,pIndex,ppTBL,iParm,opt*/);
int cl_set_array(/*pWork,nparm,ppParm*/);
int _tmp_list_copy(/*pInfoParmO,pInfoParmI*/);
int _tmp_list_info_set(/*pInfoParmO ,pInfoParmI*/);
int cl_array_ope_opt(/*pWork,nparm,ppParm,ope,cmp_opt*/);
int cl_cons_list(/*pInfoParmW,nparm,ppParm*/);
int cl_func_index(/*pWork,nparm,ppParm*/);
int cl_ope_list(/*pInfoParmW,pdummy,nparm,ppParm,ope,dummy*/);
int _set_list(/*pCt,p*/);
int cl_set_list(/*pInfoParmW,nparm,ppParm*/);
int cl_set_struct(/*pWork,pInfoParm,nparm,ppParm*/);

/* cl_gx_tree.c */
int cl_gx_cr_tree(/*obj,iob,tree*/);
int cl_gx_cr_tree_sub(/*obj,nob,da,tree,ntr,rstk,iva*/);
int cl_gx_cr_nest0(/*tree,nest,nest_flg*/);
int cl_gx_chk_tree(/*is,tree*/);
int cl_gx_cr_tree_3kou(/*obj,nob,da,tree,ntr,rstk,iva*/);

/* cl_if_comp_ctl.c */
int cl_if_comp_ctl(/*pLeaf,proc*/);
int cl_is_true(/*pInfoParm*/);
int cl_is_zero(/*pInfoParm*/);
int cl_if_compare_sub(/*nparm,prmp,Obj*/);
int cl_if_compare(/*pLeaf,proc*/);
int cl_gx_exp_tree_obj(/*nparm,prmp,Obj,pInfoParmW*/);
int cl_gx_exp_tree_obj_opt(/*nparm,prmp,Obj,pInfoParmW,opt*/);
int cl_gx_exp_gp_tree_obj_opt(/*pgwprm,pssp,bxobj,Obj,pInfoParmW,opt*/);
int cl_gx_ex_tree(/*tree,Obj,pGxObj,pInfoParmW,iOpt*/);
int cl_gx_ex_tree_sub(/*is,tree,pObj0,pGxObj,pInfoParmW,iOpt,Msa,iva*/);
int cl_gx_ex_tree_t(/*mc,mc1,i1,lv,pObj0,pGxObj,pInfoParmW,iOpt,Msa,iva*/);

/* cl_if_pre_proc.c */
int cl_if_pre_proc(/*pLeaf,pProc*/);
int cl_add_block_cb(/*pProc*/);
int cl_del_block_cb(/*pProc*/);
BlockCB *cl_search_block_cb(/*proc,cid,opt*/);

/* cl_loop_max.c */
int cl_loop_max(/*pLeaf, proc, pValue*/);

/* cl_packet_check.c */
int cl_packet_check (/*lInstanceHandle,cpInstanceData,tpRecvMsgCom*/);
int packet_save(/*p*/);
int cl_packet_error_check(/*tpRecvMsg*/);

/* cl_parm_data_set.c */
int cl_parm_data_set(/*iParmNum, sBuff, ParmL*/);

/* cl_path.c */
int cl_process_msg_pre_send(/*leaf,proc*/);
int cl_process_msg_pre_return(/*leaf,proc*/);
int cl_process_bexp(/*cid, leaf, proc*/);
int cl_process_read(/*leaf, proc*/);
int cl_process_output(/*leaf, proc*/);
int cl_process_leave(/*leaf, proc*/);
int cl_process_messag_send(/*nprm,prmp,pbxobj*/);
int cl_process_message_recv(/*nprm,prmp,pbxobj*/);
int cl_process_interactive(/*leaf, proc*/);
int cl_gx_ex_cmd(/*pInfoParmW,pInfoParm2*/);

/* cl_proc_bexp.c */
int cl_proc_bexp(/*pLeaf,proc*/);
int cl_proc_bexp_do(/*pLeaf,proc,cmd*/);
int cl_proc_bexp_sub(/*pLeaf,proc*/);
int cl_process_let(/*pLeaf, proc*/);
int cl_set_scalar_var_info(/*str,bxobj,opt,ppInfoParm*/);
int cl_set_var(/*str,bxobj*/);
int cl_set_global_var(/*str,bxobj*/);
int cl_set_public_var(/*str,bxobj*/);
int cl_set_public_var_info(/*str,bxobj,ppInfoParm*/);
tdtInfoParm *cl_get_var(/*varnam*/);
tdtInfoParm *cl_get_global_var(/*varnam*/);
tdtInfoParm *cl_get_public_var(/*varnam*/);
int cl_mod_option(/*ix,g_mode*/);
int cl_get_option(/*ix,g_mode*/);
int cl_opt_add_del(/*opt0,iADD_DEL,opt*/);
int cl_get_add_del(/*pp,plen*/);
int let_options(/*prmnum, pprmp, Obj*/);
int let_option(/*prmnum, pprmp, Obj*/);
int let_continue(/*leaf,proc*/);
int let_print_echo(/*leaf,proc,scno*/);
int let_dump(/*leaf,proc,scno*/);
int let_printf(/*leaf,proc,scno*/);
int let_goto(/*leaf,proc*/);

/* cl_proc_leave.c */
int cl_proc_leave(/*pLeaf,pProc*/);

/* cl_proc_output.c */
int cl_proc_output(/*pLeaf,proc*/);

/* cl_proc_read.c */
int cl_proc_read(/*prmnum, prmp, Obj*/);
int cl_get_area_id(/*prmp,Obj,temp*/);

/* cl_process_else.c */
int cl_process_else(/*pLeaf, pProc*/);

/* cl_process_else_if.c */
int cl_process_else_if(/*pLeaf, pProc*/);
int cl_process_case(/*pLeaf, pProc*/);
int cl_process_catch(/*pLeaf, pProc*/);

/* cl_process_end_if.c */
int cl_process_end_if(/*pLeaf, pProc*/);

/* cl_process_if.c */
int cl_process_switch(/*pLeaf, pProc*/);
int cl_process_try(/*pLeaf, pProc*/);
int cl_get_InfoParm2(/*tInfoParm2,ppInfoParm,flags*/);

/* cl_scparmset.c */
int cl_scparmset(/*pprmp,prmnum,proc*/);
int cl_prparmset(/*pProc,pExProcName*/);
int cl_prparmset_sub(/*pInfoParmW,pInfoParm*/);
int cl_set_exec_parm(/*pprmp,parmnum,pProc*/);

/* cl_set_result.c */
int cl_set_result(/*pSchRsl*/);

/* cl_user_func.c */
char *cl_get_circ_addr(/*pIndex,pTBL*/);
int cl_user_func(/*pLeaf, proc, name*/);
int cl_str_print(/*ppAns,pParm,iOpt*/);
int cl_print_echo_text(/*prmp,Obj,prmnum,name,opt*/);
int cl_print_text(/*prmp,Obj,prmnum,name*/);
int cl_dump_info(/*pInfoParm,fmt,name*/);
int cl_dump(/*prmp,prmnum,Obj,flgs*/);
int cl_echo_text(/*prmp,Obj,prmnum,opt*/);
int cl_printf_text(/*prmp,Obj,prmnum,name,opt*/);
void cl_print_set_flag(/*p,len,flgs*/);
static int _mcat_print_info_data(/*mcat,pInfoParm,flgs*/);
int cl_print_info_data(/*pInfoParm,flgs*/);
char *cl_get_attr_name_opt(/*iParm,fixed*/);
int cl_print_attr(/*buf,buf_len,pInfoParm,iParm*/);
int cl_check_addr(/*p,buf,buf_len*/);
int cl_print_check_do(/*parl,prmp,prmnum*/);
int cl_get_loop_ctl(/*cmd,pcrLCB,Obj,line,line_len*/);
int cl_print_echo_text_do(/*prmp0,Obj,prmnum0,name,opt,parl*/);
int cl_printf_text_do(/*Obj,nparm,pparm,iOpta,opt,flgs,parl*/);

/* clbyname */
int getdchostbyname(/*dchostp,hostp,ulpaddr_h,procidp*/);
int getsamehost(/*dchostp,samep*/);

/* clchksql.c */
int cl_chk_sql(/*sql*/);
int cl_sqltype(/*pszSQL, pnum*/);

/* clclear.c */
int addrchk(/*file,line,p*/);
int cl_ct_clear();
int cl_scr_clear(/*Dummy*/);
int cl_prc_ct_clear(/*proc*/);
int cl_prc_clear(/*Dummy*/);
int cl_rslt_clear(/*Dummy*/);
int cl_result_clear(/*Dummy*/);
int info_parm_clear(/*DummyE*/);
int cl_leaf_clear(/*Dummy*/);
int cl_list_pac_clear(/*DummyA*/);
int vary_clear(/*DummyF*/);
int const_ct_clear(/*DummyG*/);
void errmsg_clear();

/* clcnvt.c */
int clesc_cut(/*prp,len,p*/);
int clcnvt_index(/*sz,dlm*/);
int clcnvtb2c_rlen(/*bip,len,bu,rlen*/);
int clcnvtb2c(/*bip,len,bu*/);
int cl_sqlcnvt_data(/*pPrm, ppRslt, piRsltLen*/);
int cl_sqlcnvt(/*pszSQL ,ppszRet*/);
int cl_sqlncnvt(/*pszSQL,iSqlLen,ppszRet*/);

/* clerproc */
int  cl_er_lk_proc_ct();

/* clerscpt */
int  cl_er_lk_scr_pr_ct();
int    cl_loop_close();
int    col_mn_tr_file_end();
int    cl_process_end_proc();
int    cl_script_main();
int    cl_make_return_packet();

/* clexescr.c */
int _set_redirect_by_parmList(/*pprmp,parmnum*/);
int cl_set_stdio_redirect(/*red,red0,pStdio*/);
int cl_reset_stdio_redirect(/*red,reset,proc*/);
int cl_execute_script();
int cl_exe_scr_name_check(/*sc_nam,pr_nam*/);
int cl_exe_scr_init();
int cl_exe_scr_file_init(/*name,procname,leaf0,proc,nam_pos*/);
ScrPrCT *cl_mk_scr_and_reg(/*tpLSH,scrct,scrname*/);
int _set_node_path(/*scrct,leaf,argv0,nodeleaf*/);
int cl_exe_scr_set_up(/*procname,leaf0,proc,scrprct,nam_pos*/);
ScrPrCT *cl_mk_scr_mem_and_reg(/*mem,len*/);
int cl_exe_scr_mem_init(/*sc_nam,pr_nam,leaf0,proc,nam_pos*/);
ScrPrCT *cl_search_src_ct();
ScrPrCT *cl_search_scr_ct();
ProcCT  *cl_search_proc_ct();
Leaf    *cl_search_method_leaf(/*leaf,procname,ppTopleaf,tag*/);
Leaf    *cl_search_proc();
Leaf    *cl_search_func();
Leaf    *cl_search_class(/*leaf,procname*/);
Leaf    *cl_search_func_leaf();
#if 0	/* 2021.2.20 */
Leaf    *cl_search_proc_leaf();
Leaf    *cl_search_class_leaf();
Leaf    *cl_search_proc_leaf_inner();
Leaf    *cl_search_func_leaf_inner();
#endif
Leaf    *search_top_leaf();
int cl_lru_scr_init(/*max*/);
int cl_lru_scr_free(/*tpLSH*/);
ScrPrCT *cl_lru_scr_src_opt();
ScrPrCT *cl_lru_scr_src();
int	cl_lru_scr_reg(/*tpLSH,scrprct,fullname*/);
int cl_lru_scr_era(/*tpLSH,scrname*/);
Leaf    *cl_set_func_body();
Leaf    *cl_search_leaf_and_inner();
Leaf    *cl_search_func_leaf_and_inner();
Leaf    *cl_search_proc_leaf_and_inner();
Leaf    *cl_search_class_leaf();
Leaf    *cl_search_class_leaf_and_inner();
int col_leaf(/*scrprCT*/);
int col_leaf_print(/*leaf*/);
int cl_lru_scr_all_clear(/*tpLSH*/);

/* clfunc.c */
int cl_func_process(/*proc*/);
int cl_fflush();
int cl_system(/*p1*/);
int cl_ex_shell(/*pWork,nparm,ppParm*/);
int cl_ex_no_free(/*pWork,nparm,ppParm*/);
int cl_ex_eval(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_channel(/*pWork,nparm,ppParm*/);
int cl_is_null_chk_null_parm(/*pInfoParm*/);
int cl_ex_nval(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_nsval(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_ndef(/*pInfoParmW,nparm,ppParm*/);
int cl_is_ndef(/*pInfoParm*/);
int cl_is_spaces(/*pInfoParm*/);
int cl_ex_shut_ctl(/*pWork,nparm,ppParm*/);
int cl_ex_exit(/*pWork,nparm,ppParm*/);
int cl_ex_exit_finally();
int cl_func_conv_parm(/*pInfoParmW,pOperator,nparm,ppParm,dummy,opt*/);
int cl_func_f(/*pInfoParmW,nparm,ppParm*/);
int cl_func_count_sub(/*pInfoParm,opt*/);
int cl_func_count(/*pWork,nparm,ppParm,opt*/);
int cl_func_env(/*ppWork,pOperator,nparm,ppParm,ope,opt*/);
int cl_env_reset(/*pha*/);
int cl_func_get_time(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_round(/*pInfoParmW,nparm,ppParm*/);
int cl_func_mem_used(/*pAns,nparm,ppParm*/);
int cl_code_type(/*opt,code_type*/);
int cl_func_getval(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_decode(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_iif(/*pInfoParmW,nparm,ppParm*/);
int cl_ex_ecmd(/*pWork,nparm,ppParm*/);
int cl_func_range(/*pInfoParmW,nparm,ppParm*/);
int cl_get_range_info(/*pInfoParm,ppParm,lVal,opt*/);
int cl_func_dec_max_pre(/*pWork,nparm,ppParm*/);
int cl_array_adjust_dec_val();
int cl_get_pname_info(/*ppInfoParmW,pInfoParm,pnama,max_stra*/);

/* clfuncfile.c */
int _check_fp(/*ope,fp,pp*/);
int func_file(/*ppWork,pOperator,nparm,pParm,ope,iParm*/);
int cl_free_fp(/*hp*/);
int cl_check_close_fp(/*fp*/);
int cl_close_fp(/*fp,p,pna,len*/);
int cl_ank_conv(/*pAns,p1,len*/);
int cl_file_code_conv(/*pAns,p1,len,inout*/);
int cl_heredoc_end(/*scrct,proc*/);
int cl_func_redirect(/*pInfoParmW,nparm,ppParm*/);
int cl_is_redirect_fp(/*name,fn*/);
int cl_heredoc_skip_to_eof_close(/*red*/);
int cl_heredoc_skip_to_eof(/*red*/);
int cl_dummy_get_line(/*fp*/);
int cl_skip_line(/*fp,n*/);
int cl_get_line_opt(/*ppWork,size,offset,fp,opt*/);
int cl_get_line(/*ppWork,size,offset,fp*/);
int cl_pgetline(/*ppWork,size*/);
int cl_getline(/*pWork,size*/);
int cl_putline(/*buf,size*/);
int cl_puts(/*buf*/);

/* clfuncmath.c */
int func_math(/*pWork,pOperator,nparm,ppParm,ope*/);
int func_math2(/*pInfoParmW,pOperator,nparm,ppParm,ope*/);

/* clinput.c */
int input();
int cl_input_prep(/*pInfoParm*/);
int cl_input_exec_proc(/*iSel,pPrName*/);

/* clinput_xml.c */
int input();
int input_xml(/*first*/);
int cl_input_exec_proc(/*iSel,pPrName*/);

/* clleaf.c */
int cl_make_leaf();
int cl_push();
int cl_pushd();
int cl_change_tree(/*leaf*/);
Leaf *cl_make_node_leaf(/*pConstCt, cno, name*/);
int cl_make_push_leaf();
Leaf *search_top_leaf();

/* cllex.c */
int cl_chk_act(/*c*/);
int  cl_lex();
int  clparmset();
int  clparmclr();
int  cl_syn_main();
char *cl_lex_snln();
int cl_get_cmd_line(/*pcmd,ppCmdLine*/);
int _rep_def_parm(/*mcat,s,parm*/);

/* cllesy.c */
int  cl_lex_syn();
FILE *cl_file_open();
FILE *cl_lex_file_open();

/* cllexfnc.c */
int  cl_get_str();
cmdTable *cl_cmd_chk();
int cl_chk_label_len(/*wrk,parmlen*/);
int cl_cmd_chk2(/*buff,pp*/);
void cl_cmd_init();
void cl_copy_cmd();
int cl_cmd_chk_cid(/*buff*/);
char *cl_gets_cmd_name(/*cid*/);
int cl_get_cmd_name(/*cid,buf*/);
int cl_get_cmd_line(/*pcmd,ppCmdLine*/);

/* cllog.c */
int cl_log_out_opt_l5(/*log_no,level,opt,file,line,fmt,a1,a2,a3,a4,a5*/);
int cl_log_out_l5(/*log_no,level,file,line,fmt,a1,a2,a3,a4,a5*/);
void cl_debug_out_info_parm5(/*level,file,line,format,pInfo,a1,a2,a3,a4,a5*/);
void cl_debug_out_info_parm(/*level,file,line,format,pInfo,a1,a2*/);
int cl_debug_out_level(/*level,file,line,fmt,a1,a2,a3,a4,a5*/);
int cl_debug_array_info(/*fmt,len,pInfo*/);
int cl_debug_out_return(/*file,line,func,ret*/);
int func_log(/*pAns,pOperator,nparm,ppParm,ope*/);
int func_get_log_parm(/*pAns,nparm,ppParm*/);
int cl_set_log_parmi(/*pInfoParm,argv,iParm,ix*/);
int func_set_log_parm(/*pAns,nparm,ppParm*/);
int func_res_log_parm(/*pAns,nparm,ppParm*/);
int cl_get_range_str_opt(/*pInfo,ppStr,opt*/);
int cl_get_range_str(/*pInfo,ppStr*/);
int cl_log_range_str(/*pInfo,ppStr*/);
void cl_log_debug_leaf(/*level,file,line,msg,leaf*/);
int cl_log_chk_save_info(/*file,line,msg*/);

/* clmkproc */
ProcCT *cl_mk_lk_proc_ct();
ProcCT *cl_mk_pr_make();
int cl_mk_pr_var_set(/*proc*/);
#if 0	/* 2021.2.5 */
ProcCT *cl_mk_pr_push();
int cl_mk_pr_init(/*proc*/);
#else
int cl_mk_pr_push();
#endif
ProcCT *cl_mk_lk_class_method();

/* clmkscpt */
ScrPrCT *cl_mk_lk_scr_pr_ct();
ScrPrCT *cl_mk_lk_make();
ScrPrCT *cl_mk_scr_pr_ct();
ScrPrCT *cl_mk_scr_and_reg();
int  cl_mk_lk_push();
int cl_var_size_len(/*opt*/);
int *cl_var_set_size(/*pSize, iMAX_VAR_IX, iMAX_VAR_IY, name*/);
VarTBL *ver_set();
int var_set_array(/*pInfoParm,varnam,max_num*/);
tdtInfoParm *cl_var_size_parm(/* int *pSize*/);
tdtInfoParm *parm_set0();
int cl_parm_set0(/*pDummy*/);
int cl_null_data(/*pDummy*/);
int cl_null_parm(/*pDummy*/);
int cl_none_parm(/*pDummy*/);
int cl_eof_parm(/*pDummy*/);
int cl_null_value(/*pDummy*/);
int cl_is_null_parm(/*pDummy*/);
int cl_is_none_parm(/*pDummy*/);
int cl_is_null_data_sub(/*pDummy*/);
int cl_is_null_data(/*pDummy*/);
int cl_is_undef_parm(/*pDummy*/);
int cl_is_eof_parm(/*pDummy*/);
int cl_is_null_value(/*pDummy*/);

/* clnode.c */
char *cl_get_pcmdc_line(/*cmd*/);
int  cl_node_process(/*leaf,proc*/);
int  cl_node_process_opt(/*leaf,proc,opt*/);
char *cl_gets_cmd_name();
int cl_debug_mode(/*leaf0,proc,mode*/);
int clerrdisp(/*rc,leaf*/);
int cl_ret_leaf_push(/*proc,leaf*/);
int cl_node_control(/*leaf, proc*/);

/* clpath.c */
int cl_process_interactive(/*leaf, proc*/);

/*clprbrk.c */
int cl_pop_finally(/*proc,pcrLCB*/);
int cl_set_continue(/*leaf,proc*/);
int cl_process_break(/*leaf, proc*/);
int cl_pr_break(/*leaf, proc, ip*/);
int cl_process_continue(/*leaf, proc*/);
int cl_pr_continue(/*leaf, proc, ip*/);
int cl_pr_goto(/*leaf, proc, ip*/);
int cl_pr_label(/*leaf,proc*/);

/* clprdef.c */
int cl_process_top_exec(/*scrct,top_leaf,func1,ncmd,cmd_cid,func2*/);
int cl_process_define(/*scrct,top_leaf*/);
int cl_pr_ex_define(/*leaf, scrct, proc, opt*/);
int cl_pr_ex_re_define(/*leaf, proc*/);
int _get_varname(/*s,slen,ssp,proc,bxobj,pp*/);
int _chk_define(/*scrct,proc,varnam,vnlen,opt,argv*/);
int cl_get_def_scope(/*p*/);
char *cl_get_scope_name_from_opt(/*opt*/);
int cl_get_def_modifier_SSP(/*s,slen,ssp,sep,check,iParm,bxobj,Obj*/);
int cl_def_chk_name(/*varnam,vnlen,func,msg*/);
int _set_index2(/*is,prmnum,pprmp,offset,index,msg,pparm*/);
int _set_index(/*is,prmnum,pprmp,offset,index,msg*/);
int _set_array_info_values(/*pInfoParm,tInfoParm2*/);
int _set_array_values(/*pInfoParm,prmnum,pprmp,Obj*/);
int cl_def_get_psize(/*cn,scrct,proc,opt,ppSize,ppTBL*/);
int cl_def_map_ary_max_chk(/*c,index,scrct,proc,opt*/);
int cl_pr_ex_def_map_ary(/*prmnum, pprmp, scrct, proc, opt*/);
int cl_pr_ex_def_scalar_attr_info(/*prmnum, pprmp, scrct, proc, opt, iParm, ppInfoParm*/);
int cl_pr_ex_def_array_parm(/*cmdobj,prmnum,pprmp,scrct,proc,opt,i_parm*/);
int cl_pr_ex_def_array(/*cmdobj,prmnum,pprmp,scrct,proc,opt*/);
int cl_pr_ex_def_array_engine(/*cmdobj,prmnum,pprmp,scrct,proc,opt*/);
int _def_array(/*prmnum, pprmp, opt, iParm, ptIndex, attr_old, pIndex*/);
int _redefine_size_zero(/*attr,size0,n,size0_old,n_old,pIndex,pIndex_old*/);
int cl_get_def_alsize(/*iParmW*/);
int _def_array_set_init_by_attr(/*attr,n,alsize,ptIndex,iParm*/);
int cl_pr_ex_dim(/*leaf, scrct, proc, opt*/);
int cl_pr_ex_un_define(/*leaf, proc*/);
int cl_get_info_fixed_attr(/*pInfoParm*/);
int _get_gid(/*scrct,proc,opt*/);
int cl_pr_def_redirect(/*leaf,scrct*/);

/* clprdeftype.c */
int cl_complex_attr_check(/*iParm*/);
int cl_get_def_attr_check(/*nparm,ppParm,iParm,opt*/);
int cl_set_parm_init(/*pInfoParm,iParm,opt*/);
int cl_get_def_attr_opt(/*varnam,vnlen,iParm,opt,bxobj,Obj*/);
int cl_skip_to_delm(/*s,slen,delms,ssp,sep,level*/);
int clpeeksl(/*s,slen,ssp,sep,opt*/);
int cl_get_array_def_parm(/*s,slen,dlm,ssp,sep,nmax,qprmp,iEQU*/);
int _def_var_array_member(/*pParm*/);
int _def_var_struct(/*pInfoParm,pDeftypeP*/);
int cl_get_struct_name_len(/*pDefname*/);
int cl_set_struct_name(/*pInfoParm,pDefname*/);
int cl_def_pr5_pr6_pr7(/*iParm*/);
int cl_def_var_mult(/*prmnum,pprmp,scrct,proc,opt,pos,pos_var_end,iParm,pParmIO*/);
int cl_def_var_mult1(/*prmnum,pprmp,scrct,proc,opt,pos,pos_var_end,iParm,pParmIO*/);
int cl_def_var_mult2(/*prmnum,pprmp,scrct,proc,opt,pos,pos_var_end,iParm,pParmIO*/);
int cl_get_def_type(/*line,line_len,ssp,sp_save,proc,pbxobj,iERROROUT,iParm,pInfoParm*/);
int cl_pr_ex_def_type(/*prmnum, pprmp, scrct, proc, opt*/);
int cl_pr_ex_def_var(/*prmnum, pprmp, scrct, proc, opt*/);
int cl_get_def_attr_SSP(/*s,slen,ssp,sep,iParm,bxobj,Obj*/);
int cl_get_def_attr_SSP_opt(/*s,slen,ssp,sep,iParm,opt,bxobj,Obj*/);
int cl_im_parmcpy(/*im,qprmp,prmp0*/);
int _def_var_define_array(/*ppInfoParmW,prmnum,pprmp,scrct,proc,
                          iParm,vnam,vlen,bxobj,n,qprmp3,opt,is*/);
int _define_srch_equ(/*line,line_len,ssp,posa*/);
int cl_free_deftype(/*id,pDeftype*/);
int cl_pr_ex_def_implicit(/*prmnum,pprmp,scrct,proc,opt*/);
int cl_get_implicit(/*varnam,varlen,iParm*/);
int set_attr_scalar_var(/*scrct,proc,scope*/);

/* clprexec */
int cl_set_proc_nm(/*proc,name*/);
int cl_pr_exec_ip(Leaf *leafleaf,ProcCT *proc,int nam_pos);
int cl_pr_exec_ep(/*leaf,proc*/);
int cl_pr_exec_sc(/*leaf,proc,nam_pos*/);
int cl_pr_exec_sc_sub(/*leaf,proc,sc_nam,pr_nam,nam_pos*/);
int cl_pr_exec_sm(/*leaf,proc*/);
int cl_process_exec(/*leaf,proc*/);
int cl_process_exec_return(/*leaf,proc*/);
int cl_process_call(/*leaf,proc*/);
int cl_pr_exec_redirect(/*leaf,proc*/);
int cl_pr_exec_sh(/*leaf,proc*/);

/* clprimport.c */
ScrConstCt *_mk_scr_const(/*scrct*/);
int cl_process_import(/*scrct,leafTop*/);
ScrConstCt *cl_get_scr_const_ct(/*scrct,nodeleaf*/);
int cl_set_scr_const_ct(/*scrct,nodeleaf*/);

/* clprloop.c */
int cl_is_loop_exec(/*leaf,proc*/);
int cl_get_loop_max(/*pMaxLoopWhile*/);
int cl_loop_set_each(/*pcrLCB,ppInfoParmW,cppKey*/);
int cl_is_not_space(/*prmL*/);
int _set_for(/*cmd,Obj,ipOpt,pargv*/);
int _exec_for(/*cmd,Obj,pcrLCB*/);
int cl_process_loop(/*leaf, proc*/);
int loop_pre_proc(/*pLeaf,pProc*/);
int cl_process_do_while(/*leaf, proc*/);

/* clpron.c */
int cl_process_on(/*scrct*/);
int cl_pr_ex_on(/*leaf, scrct, dummy1,dummy2*/);
int cl_pr_ex_on_sel(/*prm*/);
int cl_pr_ex_on_pr_name(/*prm,ppPrName*/);
int cl_pr_ex_on_sc_name(/*prm,ppPrName*/);

/* clprproc */
int  cl_process_proc();

/* clprret.c */
int cl_process_return(/*leaf, proc*/);
int cl_process_throw(/*leaf, proc*/);
int cl_back_with_finally(/*leaf,proc,_push_return*/);

/* clpsend.c */
int cl_process_get_ipaddr(/*pszHostId, pNetId*/);
int cl_process_get_attr(/*prmp, Obj, para*/);
int cl_process_get_sql(/*prmp, para, piCmd, piPrm, TrnId , pszHostId*/);
int cl_process_get_area_id(/*prmnum, prmp, Obj, para, sCmdNo*/);
int cl_process_sqlsnd(/*prmnum, prmp, Obj*/);
int cl_process_sleep_snd(/*nprm, prmp, proc*/);
int cl_process_sleep_rcv(/*nprm, prmp*/);
int cl_process_msg_snd(/*nprm,prmp,Obj*/);
int cl_process_msg_rcv(/*nprm, prmp, Obj*/);

/* clscr.c */
unsigned int cl_get_cmd_id();
int  cl_parameter_set();
int cl_parm_shift(/*pInfoParm*/);
int cl_script_error();
int cl_script_main();

/* clselmn.c */
int cl_sel_main();

/* cldumy.c */    
int  cl_process_sqlsnd();
int  cl_process_sqlrcv();
int  cl_process_break();
int  cl_process_read();
int  cl_process_output();
int  cl_process_if();

/* select process */
char *cl_sl_ext_select();
char *cl_sl_ext_from();
char *cl_sl_const_where();
int  cl_sl_make_select_command();

/* common */
int  cl_const_ct_mem_get();
int  cl_const_mem_get();
char *cl_const_ct_malloc();
char *cl_const_malloc();
char *cl_tmp_const_malloc();
char *cl_scr_malloc();
char *cl_scr_const_malloc();
char *cl_leaf_malloc();
char *cl_opt_malloc();
char *cl_tmp_const_malloc(/*Len*/);
tdtExtValName *cl_get_sysvar_name(/*char *buf, int len*/);
char *cl_get_pcmd_line(/*Leaf *leaf*/);
Leaf *cl_ret_leaf_pop(/*ProcCT *proc*/);
Leaf *cl_ret_leaf_peek(/*ProcCT *proc*/);
Leaf *cl_ret_leaf_pop_search(/*proc,cida,nn*/);
char *cl_set_script_name_extension(/* char *name, int len */);
tdtRbCtl *cl_tmp_rb_new(/*lBS,lRM*/);
char *cl_tmp_rbset_n(/*pCt, addr*/);
BlockCB *cl_search_block_cb(/*proc,cid,opt*/);
char *cl_conv_msg_check(/*pMsg,rc*/);
char *_to_bulk(/*pInfoParm,iParm,opt*/);
char *cl_get_format(/*no*/);
/*
char *cl_mem_add();
char *cl_str_add();
*/
tdtObjHead *cl_mk_add_obj0();
tdtObjHead *cl_mk_obj0();
tdtObjHead *cl_gx_get_scr_obj();
tdtObjHead *cl_gx_get_proc_obj();
char *clmemdup(/*s,slen,im*/);
char *clstrdup(/*s,im*/);
char *cl_get_attr_name(/*ipParm*/);
char *strname(/*s,len*/);
char *strname3(/*s1,len1,s2,len2,s3,len3*/);
char *strtemp(/*s,len*/);
tdtException *cl_get_exception_name(/*name, name_len, opt*/);
char *cl_im_init_set_expand(/*mcat,id,size,extent,buf,im*/);
char *cl_gx_init_set_expand(/*mcat,id,size,extent,buf*/);

/* cltrbexp.c */
qSubCommand *cl_get_name_attr(/*name, name_len, opt,sel*/);
qSubCommand *cl_tr_sc_set_scno(/*scno0,opt,select*/);
int cl_tr_set_scno(/*scno0,opt,select*/);
int cl_tr_gather(/*ip*/);
int cl_prm_gather(/*mcat,prmp,prmnum,ip*/);
qSubCommand *cl_get_name_attr2(/*name, name_len, opt,sel*/);

/* cltredif.c */
int col_mn_tr_end_if(/*y*/);
int cl_if_close(/*y*/);
int col_mn_tr_end_sw(/*y*/);
int cl_search_node_leaf(/*y,deny,nd,able,na,ppleaf,check*/);
int cl_search_node(/*y,deny,nd,able,na*/);
int cl_tr_end_prmnum_check(/*y*/);
int cl_tr_node_check_leaf_check(/*y,deny,nd,able,na,ppleaf,check*/);
int cl_tr_node_check_leaf(/*y,deny,nd,able,na,ppleaf*/);
int cl_tr_node_check(/*y,deny,nd,able,na*/);
int cl_tr_end_node_check(/*y,deny,nd,able,na*/);
int cl_tr_end_nest_check(/*y*/);
int col_mn_tr_end_node(/*y,deny,nd,able,na*/);

/* cltrdef.c */
int cl_tr_get_def_is(/*scno*/);

/* cltredlp.c */
int col_mn_tr_end_loop();
int cl_loop_close(/*cid*/);
int cl_search_loop(/*cid*/);

/* cltree.c */
int cl_tree_main();

/* cltrelse.c */
int col_mn_tr_default();

/* cltrloop.c */
int cl_change_from_for_sub(/*line,line_len,parl*/);
int cl_change_from_for(/*line,line_len,parl*/);
int cl_set_to_step_parm(/*p1,p2,p3,pos,argv,pp0*/);
int cl_change_from_to_step_sub(/*prmL,num,parl*/);
int cl_change_from_to_step(/*prmp,prmnum,parl*/);
int cl_change_from_do_sub(/*line,line_len,parl,pConstCt*/);
int cl_change_from_do(/*line,line_len,argv,pConstCt*/);
int cl_tr_insert(/*ip,name*/);
int cl_search_active_loop();

/* cltrfled.c */
int cl_is_name(/*nam,n*/);

int    cl_change_stcb();
int    cl_make_leaf();
int    cl_push();
int    cl_change_tree();
Leaf  *cl_make_node_leaf();

int    cl_search_nest();
int    cl_nest_tag();
int    cl_pre_nest();
int    cl_check_nest();

int    col_mn_tr_bexp();
int    col_mn_tr_end_if();
int    col_mn_tr_end_loop();
int    col_mn_tr_else_if();
int    col_mn_tr_else();
int    col_mn_tr_exec();
int    col_mn_tr_if();
int    col_mn_tr_loop();
int    col_mn_tr_on();
int    col_mn_tr_output();
int    col_mn_tr_read();
int    col_mn_tr_return();
int    col_mn_tr_sql();
int    col_mn_tr_proc();
int    col_mn_tr_end_proc();
int    col_mn_tr_leave();
int    col_mn_tr_break();
int    col_mn_tr_continue();
int    col_mn_tr_define();
int    col_mn_tr_re_define();
int    col_mn_tr_un_define();
int    col_mn_tr_try();
int    col_mn_tr_catch();
int    col_mn_tr_exception();
int    col_mn_tr_finally();
int    col_mn_tr_end_try();
int    col_mn_tr_throw();
int    col_mn_tr_case();
int    col_mn_tr_end_sw();
int    col_mn_tr_label();
int    col_mn_tr_msg();
qSubCommand *cl_tr_sc_set_scno(/*scno0,opt,select*/);
int cl_if_close();
int get_pos_as_name(/*pprm,nprm*/);

/* cltrproc.c */
int cl_tr_split(/*ip,sep*/);
int cl_tr_chk_proc_name(/*pnm, len, opt, _fn_, name*/);

/* coalmain.c */
int coal_main(/*argc, argv*/);
int cl_getenvf();
int cl_getenvf_print();
int cl_get_host_id ();
void _set_log_flg_cd_opt(/*log_no,kind*/);

/* colinit.c */
int col_mn_init();

/* clterm.c */
int col_mn_term();

/* cmgetdata.c */
int cmn_get_data(/*pPrmHead, pInfoParm*/);
int cmn_get_data_byte_order(/*pPrmHead, pInfoParm, ucByteOrder*/);
int cmn_chk_data(/*pPrmHead, pInfoParm*/);
int cmn_change_data(/*pPrmHead, pInfoParm, iOption*/);

/* cmitoa.c */
int cmn_i_to_a(/*n, str*/);
int cmn_reverse(/*str*/);
int cmn_mrzcpy(/*str1,str2,len*/);

/* cmmemwrt.c */
int cmn_mem_wrt(/*pMemPos, pData, pLen*/);

/*cmpktform.c */
int cmpktform(/*pprmList, pInfoParm*/);
int cm_set_pkt_form(/*pInfoParm ,pBuff*/);

/* cmstat.c */
void cmn_set_stat(/*s, sf, val*/);
int cmn_chk_stat(/*s, sf*/);

#endif	/* _CLPROT_H */
