static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_read                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*  Version                    1.00  2010/05/28  */
/*************************************************/
/* */

#include "colmn.h"
#if 0
extern condList CLcList;
#endif
/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_read(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum > 2) {
		ERROROUT1(FORMAT(41),"col_mn_tr_read");
		return ECL_TR_READ;
	}

	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}
