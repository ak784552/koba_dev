static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************/
/*  <clTree>										*/
/*  �����Ǘ�										*/
/*	�\����͉�͖؍쐬���|�`��						*/
/****************************************************/
#include "colmn.h"
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
#endif
extern int giOptions[];
extern GlobalCt  *pGlobTable;

static int _tr_end();
static int _tr_get_as_name();

/**************************************************/
/* cl_tree_main (select process as kind of tag)	 */
/**************************************************/
int cl_tree_main(y)
condList *y;
{
	int rc,inter_mode,cmnd;
	char *name,*p;
	ScrPrCT *scrptct;
	cmdInfo *cmd;
	ParList *pal;
/*
printf("cl_tree_main:Enter: cmd=%s\n",cl_gets_cmd_name(y->cmd.cid));
*/
	cmd = y->cmd;
	if (scrptct = cl_search_src_ct())
		inter_mode = scrptct->pFlag & D_SCRPT_INTERACTIVE;
	else inter_mode = 0;
/*
printf("cl_tree_main:Enter: cid=%08x cmd=%s\n",cmd->cid,cl_gets_cmd_name(cmd->cid));
*/
	switch (cmnd=cmd->cid) {
		case C_PROC:
		case C_FUNCTION:
		case C_CLASS:
			if (pGlobTable->options[7] & 0x02) break;
		case C_IMPORT:
		case C_DEFINE:
		case C_ONN:
			if (inter_mode) {
				/* cl_tree_main: [%s]�͎g�p�ł��܂���B */
				ERROROUT1(FORMAT(81),cl_gets_cmd_name(cmnd));
				return ECL_TREE;
			}
			break;
		case C_DIM:
	/*	case C_TYPEDEF:	*/
		case C_FEND:
	/*	case C_PRAGMA:	*/
			break;
		default:
			if (!inter_mode) {
				if (cl_nest_tag(y,1) == SysError) {
					if (cmnd == C_LET) {
						cmd->cid = C_DEFINE;
						strcpy(y->cmd->parl[2].par,"DEF");
					}
					else {
						/* cl_tree_main: [%s]��PROC/FUNC/CLASS�̊O���ł͎g�p�ł��܂���B */
						ERROROUT1(FORMAT(82),cl_gets_cmd_name(cmnd));
						return ECL_TREE;
					}
				}
			}

	}
	switch (cmnd=cmd->cid) {
		case C_IMPORT:
		case C_DEFINE:
		case C_ONN:
			if (!inter_mode) {
				if (cl_nest_tag(y,1) != SysError) {
					/* cl_tree_main: [%s]��PROC/FUNC/CLASS�̓����ł͎g�p�ł��܂���B */
					ERROROUT1(FORMAT(84),cl_gets_cmd_name(cmnd));
					return ECL_TREE;
				}
			}
			break;
	}
	if (cmnd==C_LOOP || cmnd==C_FOR || cmnd==C_WHILE || cmnd==C_UNTIL
	 || cmnd==C_DO || cmnd==C_SWITCH) {
		if ((rc=_tr_get_as_name(cmd)) < 0) return rc;
#if 1	/* 2023.8.15 */
		if (rc > 0) {
			rc--;
			if (rc) rc--;	/* 2023.9.24 */
			pal = cmd->parl;
			pal->par[rc] = '\0';
			pal->parlen = rc;
/*
printf("cl_tree_main: rc=%d par=[%s]\n",rc,pal->par);
*/
		}
#endif
	}
	switch (cmnd) {
		case C_CALL:
		case C_EXEC:		rc = col_mn_tr_exec(y);		break;
		case C_FUNCTION:
		case C_CLASS:
		case C_PROC:		rc = col_mn_tr_proc(y);		break;
		case C_ENDFUNC:
		case C_ENDCLASS:
		case C_ENDPROC:		rc = col_mn_tr_end_proc(y);	break;
		case C_MSG:			rc = col_mn_tr_msg(y);		break;
		case C_SQL:			rc = col_mn_tr_sql(y);		break;
		case C_FOR:
		case C_WHILE:
		case C_UNTIL:
		case C_DO:
		case C_LOOP:		rc = col_mn_tr_loop(y);		break;
		case C_ENDDO:
		case C_NEXT:
		case C_ENDFOR:
		case C_ENDWHILE:
		case C_ENDUNTIL:
		case C_ENDLOOP:		rc = col_mn_tr_end_loop(y);	break;
		case C_CONTINUE:	rc = col_mn_tr_continue(y);	break;
		case C_BREAK:		rc = col_mn_tr_break(y);	break;
		case C_READ:		rc = col_mn_tr_read(y);		break;
		case C_OUTPUT:		rc = col_mn_tr_output(y);	break;
		case C_IMPORT:
		case C_DIM:
	/*	case C_TYPEDEF:	*/
		case C_DEFINE:		rc = col_mn_tr_define(y);	break;
		case C_REDEFINE:	rc = col_mn_tr_re_define(y);break;
		case C_UNDEFINE:	rc = col_mn_tr_un_define(y);break;
		case C_ONN:			rc = col_mn_tr_on(y);		break;
	/*	case C_TRY:			rc = col_mn_tr_try(y);		break;
		case C_EXCEPTION:	rc = col_mn_tr_exception(y);break;	*/
		case C_SWITCH:
		case C_IF:			rc = col_mn_tr_if(y);		break;
	/*	case C_ELSEL;	*/
		case C_ELSE:		rc = col_mn_tr_else(y);		break;
		case C_ELSEIF:		rc = col_mn_tr_else_if(y);	break;
		case C_ENDIF:		rc = col_mn_tr_end_if(y);	break;
		case C_CASE:		rc = col_mn_tr_case(y);		break;
		case C_DEFAULT:		rc = col_mn_tr_default(y);	break;
		case C_ENDSW:		rc = col_mn_tr_end_sw(y);	break;
	/*
		case C_CATCH:		rc = col_mn_tr_catch(y);	break;
		case C_FINALLY:		rc = col_mn_tr_finally(y);	break;
		case C_ENDTRY:		rc = col_mn_tr_end_try(y);	break;
		case C_THROW :		rc = col_mn_tr_throw(y);	break;
	*/
		case C_LET:
		case C_BEXP:		rc = col_mn_tr_bexp(y);		break;
		case C_SLEEP:
		case C_RETURN:		rc = col_mn_tr_return(y);	break;
		case C_FEND:		rc = col_mn_tr_file_end(y);	break;
		case C_LEAVE:		rc = col_mn_tr_leave(y);	break;
		case C_LABEL:		rc = col_mn_tr_label(y);	break;
		case C_END:			rc = _tr_end(y);			break;
	/*	case C_INTERACTIVE: rc = ColMnTrInteractive(y);	break;	*/
		default: rc = ECL_TREE;
	}
	return rc;
}

static int _tr_end(y)
condList *y;
{
	char *p;
	int  cnum,cnum1,i,num;
	cmdInfo *cmd;

	cmd = y->cmd;
	p = cmd->prmp[0]->prp;
	cnum = cl_cmd_chk_cid(p);
	if (cmd->prmnum > 1) {
		if (!strnicmp(p,"WHILE",5) || !strnicmp(p,"UNTIL",5)) {
			cl_tr_split(y,0,"(");
			p = cmd->prmp[0]->prp;
			cnum = cl_cmd_chk_cid(p);
		}
		if (cnum == C_DO) {
			cnum1 = cl_cmd_chk_cid(cmd->prmp[1]->prp);
			if (cnum1==C_WHILE || cnum1 == C_UNTIL) {
				cmd->cid = C_ENDDO;
				cmd->sub_cid = cnum1;
				num = --cmd->prmnum;
				for (i=0;i<num;i++) cmd->prmp[i] = cmd->prmp[i+1];
				return cl_tree_main(y);
			}
		}
		else if (cnum==C_WHILE || cnum==C_UNTIL) {
			if (cnum==C_WHILE) cmd->cid = C_ENDWHILE;
			else cmd->cid = C_ENDUNTIL;
			num = --cmd->prmnum;
			for (i=0;i<num;i++) cmd->prmp[i] = cmd->prmp[i+1];
/*
for (i=0;i<CLcList.cmd.prmnum;i++) printf("end: prmp[%d]=[%s]\n",i,cmd->prmp[i]->prp);
*/
			return cl_tree_main(y);
		}
	}
	if (cmd->prmnum != 1) {
		ERROROUT(FORMAT(83));	/* _tr_end: �p�����[�^���P�K�v�ł��B */
		return ECL_TREE;
	}
	switch (cnum) {
		case C_PROC:	cnum = C_ENDPROC;	break;
		case C_FUNCTION:cnum = C_ENDFUNC;	break;
		case C_LOOP:	cnum = C_ENDLOOP;	break;
		case C_DO:		cnum = C_ENDDO;		break;
		case C_IF:		cnum = C_ENDIF;		break;
		case C_SWITCH:	cnum = C_ENDSW;		break;
	/*	case C_TRY	:	cnum = C_ENDTRY;	break;	*/
		case C_WHILE:	cnum = C_ENDWHILE;	break;
		case C_UNTIL:	cnum = C_ENDUNTIL;	break;
		case C_FOR:		cnum = C_ENDFOR;	break;
		default:
			ERROROUT2(FORMAT(45),"_tr_end",p);	/* %s: �p�����[�^[%s]������Ă��܂��B */
			return ECL_TREE;
	}
	cmd->cid = cnum;
	cmd->prmnum = 0;
	return cl_tree_main(y);
}

/********************************************/
/*											*/
/********************************************/
static int _tr_get_as_name(pcmd)
cmdInfo *pcmd;
{
	static char *_NAME_="_tr_get_as_name";
	int cmnd,i,ret,nprm,len,iTOO;
	char *name,*p;
	parmList **pprm,*prm;

	cmnd = pcmd->cid;
	iTOO = ret = 0;
	pprm = pcmd->prmp;
	nprm = pcmd->prmnum;
	if ((i=get_pos_as_name(pprm,nprm)) > 0) {
		ret = pprm[i-1]->opt;	/* i>0�̂Ƃ��Aopt�ɂ́ACLcList.cmd.parl[0]->par��AS�̈ʒu�������Ă��� */
		pprm[i-1]->opt = 0;
		if ((cmnd==C_DO && i==1 && nprm==2) || (cmnd!=C_DO && i==nprm-1)) {
			if (prm = pprm[i]) {
				name = prm->prp;
				len = prm->prmlen;
/*
printf("_tr_get_as_name: len=%d nam=[%s]\n",len,name);
*/
				if (cl_is_name(name,len) <= 0) {
					/*_%s: %s��[%s]���s���ł��B*/
					ERROROUT3(FORMAT(113),_NAME_,FORMAT(598),name);
					ret = ECL_SCRIPT_ERROR;
				}
				else if (len > 0) {
					pcmd->prmnum = i - 1;
					p = Malloc(len+1);
					memzcpy(p,name,len);
					pcmd->parl[D_LEAF_LABEL].par = p;
					pcmd->parl[D_LEAF_LABEL].parlen = len;
				}
			}
		}
		else {
			if (i == nprm)
				/* %s: �p�����[�^������܂���B */
				ERROROUT1(FORMAT(42),_NAME_);
			else iTOO = 1;
			ret = ECL_SCRIPT_ERROR;
		}
	}
	else if (cmnd==C_DO && nprm>=1) {
		iTOO = 1;
		ret = ECL_SCRIPT_ERROR;
	}
	if (iTOO) {
			/* %s: �]���ȃp�����[�^[%s]������܂��B */
		ERROROUT2(FORMAT(43),_NAME_,pprm[iTOO-1]->prp);
	}
	return ret;
}
