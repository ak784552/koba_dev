static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int        cl_change_stcb               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         int   NestLevel              */
/*                  Leaf  leaf                   */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     CLNCB �̃l�X�g�|�C���^�̏��ւ����s���B    */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */
extern Leaf *AddressRoot;

#endif
/********************************************/
/*											*/
/********************************************/
int cl_change_stcb(y)
condList *y;
{
	CLNCB *p;

	switch(y->AddressRoot->cmd.type) {
	case 1:
		y->clstcb->nestLev1 = y->AddressRoot;
		break;
	case 2:
		y->clstcb->nestLev2 = y->AddressRoot;
		break;
	default :
		return SysError;
	}
	return NormalEnd;
}
