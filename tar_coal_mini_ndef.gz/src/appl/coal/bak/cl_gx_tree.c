static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************/
/*													*/
/*	optimize for obj by tree						*/
/*													*/
/*		coded by A.Kobayashi 2021.09.28				*/
/*													*/
/*==================================================*/
/*	       int cl_gx_cr_tree(obj,iobj,tree)			*/
/*	static int _gx_cr_nest(is,tree,nest,nnest)		*/
/*         int cl_gx_cr_nest0(tree,nest)			*/
/*         int cl_gx_chk_tree(is,tree)				*/
/****************************************************/
#include "colmn.h"

#define DEBUG_TREE

int cl_gx_cr_tree(obj,iob,tree)
int iob;
short obj[];
WHERE_TREE tree[];
{
	short rstk[100];
	int irs,itr,ntr;
	int ib,mc,rdt,v,a,b,t,j;

	ib=irs=0;
	ntr=1;
	if (iob<1) return 1;
	while (ib<=iob) {
		mc = obj[ib++];
#ifdef DEBUG_TREE
printf("cr_tree:ib+1=%d mc=%d\n",ib,mc);
#endif
		if (!mc || mc==60) ;
		else if (mc == 99) {
#ifdef DEBUG_TREE
printf("cr_tree:mc=%d irs=%d\n",mc,irs);
#endif
			if (irs<0) return -1;
			else if (irs >= 1) {
				irs--;
				ntr = rstk[irs];
#ifdef DEBUG_TREE
printf("cr_tree:mc=%d rstk[%d]=%d\n",mc,irs,ntr);
#endif
				tree[0].mcode = tree[ntr].mcode;
				tree[0].t2    = tree[ntr].t2;
				tree[0].t1    = tree[ntr].t1;
#ifdef DEBUG_TREE
printf("cr_tree: ntr=%d mcode=%d t1=%d t2=%d\n",0,tree[0].mcode,tree[0].t1,tree[0].t2);
#endif
			}
			return ntr;
		}
		else if (mc==91 || mc==92) {
			if (ntr >= FIL_MAX_TREE) return ERROR_MAX_TREE;
			tree[ntr].mcode = mc;
			tree[ntr].t1 = obj[ib];
			tree[ntr].lv = ib++;
			tree[ntr].t2 = 0;
#ifdef DEBUG_TREE
printf("cr_tree: ntr=%d mcode=%d t1=%d t2=%d lv=%d\n",ntr,tree[ntr].mcode,tree[ntr].t1,tree[ntr].t2,tree[ntr].lv);
#endif
			rstk[irs++]=ntr++;
#ifdef DEBUG_TREE
printf("cr_tree:mc=%d obj=%d rstk[%d]=%d\n",mc,obj[ib-1],irs-1,rstk[irs-1]);
#endif
		}
		else if (mc==98) {	/* , */
		}
		else if (mc<0 ||				/* �P�����Z�q + - */
		         (mc>=71 && mc<=90) ||	/* ������Z�q */
		 (mc==6) ||						/* �z�� */
	/*	 (mc==1 || mc==3) ||	*/		/* () [�f�[�^����] */
		 (mc==5 || mc==7) ||			/* �֐� {} */
		 (mc == D_IMD_RANGE) ||			/* 95 .. */
		 (mc==93) ||					/* GOTO */
		 (mc==59)) {					/* ? */
			if (irs<1) return -1;
			b = rstk[--irs];
			if (ntr >= FIL_MAX_TREE) return ERROR_MAX_TREE;
			tree[ntr].mcode = mc;
			tree[ntr].t2    = b;
			if (mc==1) tree[ntr].t1 = rstk[irs-1];
			else tree[ntr].t1 = 0;
#ifdef DEBUG_TREE
printf("cr_tree: ntr=%d mcode=%d t1=%d t2=%d\n",ntr,tree[ntr].mcode,tree[ntr].t1,tree[ntr].t2);
#endif
			rstk[irs++]=ntr++;
#ifdef DEBUG_TREE
printf("cr_tree:mc=%d b=%d rstk[%d]=%d\n",mc,b,irs-1,rstk[irs-1]);
#endif
		}
		else if ((mc>=1 && mc<=52) || mc==96 || mc==97) {
			if (irs<2) return -1;
			if (ntr >= FIL_MAX_TREE) return ERROR_MAX_TREE;
			tree[ntr].mcode = mc;
			tree[ntr].t2    = rstk[--irs];
			tree[ntr].t1    = rstk[--irs];
#ifdef DEBUG_TREE
printf("cr_tree: ntr=%d mcode=%d t1=%d t2=%d\n",ntr,tree[ntr].mcode,tree[ntr].t1,tree[ntr].t2);
#endif
			rstk[irs++]=ntr++;
#ifdef DEBUG_TREE
printf("cr_tree:mc=%d rstk[%d]=%d\n",mc,irs-1,rstk[irs-1]);
#endif
		}
		else {
			break;
		}
	}
	return -99;
}

static int _gx_cr_nest(is,tree,nest,nnest)
int is;
short *nest,nnest;
WHERE_TREE *tree;
{
	int mc,i1,i2;

	mc = tree[is].mcode;
	if (mc == 51) {	/* and */
		i1 = tree[is].t1;
		i2 = tree[is].t2;

printf("cr_nest:is=%d,mc=%d,i1=%d,i2=%d\n",is,mc,i1,i2);

		if (tree[i1].mcode) nnest = _gx_cr_nest(i1,tree,nest,nnest);
		if (tree[i2].mcode) nnest = _gx_cr_nest(i2,tree,nest,nnest);
	}
	else {
		if (nnest >= FIL_MAX_NEST) return ERROR_MAX_NEST;
		nest[nnest++] = is;

printf("cr_nest:nnest=%d,is=%d\n",nnest,is);

	}
	return nnest;
}
#if 1
int cl_gx_cr_nest0(tree,nest,nest_flg)
#else
int cl_gx_cr_nest0(bndp,tree,nest,nest_flg)
SQLDA_FIL *bndp;
#endif
WHERE_TREE *tree;
short *nest,*nest_flg;
{
	int i,rc,nnest;

	nnest = _gx_cr_nest(0,tree,nest,0);
	if (nnest < 0) return nnest;
	for (i=0;i<nnest;i++) {
#if 1
		rc = cl_gx_chk_tree(nest[i],tree);
#else
		rc = cl_gx_chk_tree(bndp,nest[i],tree);
#endif

printf("cr_nest0_tree:i=%d,rc=%d\n",i,rc);

		nest_flg[i] = rc;
	}
	return nnest;
}
#if 1
int cl_gx_chk_tree(is,tree)
#else
int cl_gx_chk_tree(bndp,is,tree)
SQLDA_FIL *bndp;
#endif
int is;
WHERE_TREE *tree;
{
	int mc,i1,i2;
	int i,rc=0;

	mc = tree[is].mcode;
	i1 = tree[is].t1;
	i2 = tree[is].t2;
	if (mc) {

printf("chk_tree:is=%d,mc=%d,i1=%d,i2=%d\n",is,mc,i1,i2);

		if (i1>0) {
#if 1
			rc = cl_gx_chk_tree(i1,tree);
#else
			rc = cl_gx_chk_tree(bndp,i1,tree);
#endif
			if (rc) return rc;
		}
		if (i2>0)
#if 1
			rc = cl_gx_chk_tree(i2,tree);
#else
			rc = cl_gx_chk_tree(bndp,i2,tree);
#endif
	}
	else {

printf("chk_tree:is=%d,mc=%d,i1=%d\n",is,mc,i1);

		/* rowid �ȊO�̃J����������A�C���f�b�N�X�������ĂȂ��Ƃ��A�P�ɂ��� */
#if 1
		if ((i1>101 && i1<201) || (i1>201 && i1<301)) rc = 1;
#else
		if (i1>101 && i1<201) {
			if (!bndp->M[i1-101]) rc = 1;
		}
		else if (i1>201 && i1<301) {
			if (!bndp->M[i1-201]) rc = 1;
		}
#endif
	}
	return rc;
}
