/* static char sccsid[]="%Z% %M% %I% %E% %U%"; */
/********************************************************/
/*														*/
/*	cmerror.h											*/
/*														*/
/*		coded by A.Kobayashi 2010.8.10					*/
/*														*/
/*********************************************************/
#ifndef _CMERROR_H
#define _CMERROR_H
/*  */
#define ECM_APPL_ERROR		-10001		/* �A�v���P�[�V�����G���[ */

/*****************************************/
/*		coal�̃G���[�R�[�h		 */
/*****************************************/

#define NormalEnd	 0
#define SysError	-1
#define NIL			-1

#define ECL_SCRIPT_ERROR	-11001
#define ECL_CMDSCR_NOTFD	-11002
#define ECL_CMD_NOTFOUND	-11003
#define ECL_SCR_NOTFOUND	-11004
#define ECL_SCR_PARM_ERR	-11005
#define ECL_SCR_ATTR_ERR	-11006
#define ECL_MALLOC_ERROR	-11007
#define C_EXECUTE_SCRIPT	 11008
#define C_LET_CONTINUE		 11009
#define ECL_DEFINED_ARRAY	-11010
#define C_LET_EXEC_IP		 11011
#define ECL_NDEFVAR_ERROR	-11012
#define ECL_VAR_FUNC		-11013
#define C_PARM_CONTINUE		 11014
#define C_PARM_START		 11015
#define C_NO_ENTRY			 11016
#define ECL_SYNTAX_ERROR	-11017
#define ECL_MAX_OBJ_ERROR	-11018
#define ECL_MAX_DA_ERROR	-11019
#define C_SKIP_COMMAND		 11020
#define ECL_NULL_DATA		 11021
#define ECL_DEFINED_VAR		 11022
#define ECL_CAN_NOT_STORE	-11023
#define ECL_ATTR_FUNCTION	-11024
#define ECL_NOT_FOUND_FUNC	-11025
#define ECL_NOT_FOUND_PROC	-11026
#define ECL_DEC_OVERFLOW	 11027
#define ECL_DEC_UNDERFLOW	 11028
#define ECL_OVER_OR_UNDER	 11029
#define ECL_CHK_VAR_ERROR	-11030	/* reserve to -11040 */
#define ECL_FUNC_CLASS		 11041
#define C_DEF_PARM			 11042	/* �p�����[�^�����define */
#define C_NO_DEF_PARM		 11043	/* �p�����[�^�Ȃ���define */
#define ECL_NOT_FUNCTION	-11044
#define ECL_NULL_POINTER	-11045
#define ECL_NOT_CAST_NAME	-11046
#define C_DO_OPTIMIZE		 11047
#define C_CAN_NOT_OPTIMIZE	 11048
#define ECL_OPTIMIZE_ERROR	-11049
#define C_NULL_PARM			 11050
/* add 93.5.28 Koba */
#define ECL_ELMCOND_LONG	-11051
#define ECL_TBLCOND_LONG	-11052
#define ECL_FIELD_MAX		-11053
#define C_EX_DEF_SCALAR		 11054
#define ECL_DUPLICATE		-11055
#define ECL_NO_DATA_ERROR	-11056	/* �f�[�^���ݒ� */
#define C_PARM_HEREDOC		 11057
#define ECL_TOO_PARAMETER	-11058
#define ECL_FEW_PARAMETER	-11059

/* 1993.10.12 tsuru V3003 */
#define ECL_LV_TRANS_ERROR	-11060
#define ECL_LV_LEAVE_ERROR	-11061

#define ECL_NOT_FREE_INFO	 11066

#define ECL_GX_FUNC_ERROR1	-11071
#define ECL_GX_FUNC_ERROR2	-11072
#define ECL_GX_FUNC_ERROR3	-11073

#define ECL_OUT_ERROR		-11097
#define ECL_IN_ERROR		-11098
#define ECL_IO_ERROR		-11099
#define ECL_END_OF_FILE		-11100

#define ECL_LEX				-11101
#define ECL_TREE			-11110
#define ECL_TR_PROC			-11111
#define ECL_TR_ENDPROC		-11121
#define ECL_TR_EXEC			-11131
#define ECL_TR_RETURN		-11141
#define ECL_TR_LOOP			-11151
#define ECL_TR_ENDLOOP		-11161
#define ECL_TR_BREAK		-11171
#define ECL_TR_CONTINUE		-11176
#define ECL_TR_IF			-11181
#define ECL_TR_ELSEIF		-11191
#define ECL_TR_ELSE			-11201
#define ECL_TR_ENDIF		-11211
#define ECL_TR_SQL			-11221
#define ECL_TR_MSG			-11226
#define ECL_TR_READ			-11231
#define ECL_TR_OUTPUT		-11241
#define ECL_TR_ON			-11251
#define ECL_TR_BEXP			-11261
#define ECL_TR_LEAVE		-11271
#define ECL_TR_LET			-11281
#define ECL_TR_DEFINE		-11291

#define ECL_EX_SCRIPT		-11401
#define ECL_EX_PROC			-11411
#define ECL_EX_ENDPROC		-11431
#define ECL_EX_EXEC			-11451
#define ECL_EX_EXEC_TREE	 11452
#define ECL_EX_RETURN		-11471
#define ECL_EX_LOOP			-11491
#define ECL_EX_ENDLOOP		-11511
#define ECL_EX_BREAK		-11531
#define ECL_EX_CONTINUE		-11541
#define ECL_EX_IF			-11551
#define ECL_EX_ELSEIF		-11571
#define ECL_EX_ELSE			-11591
#define ECL_EX_ENDIF		-11611
#define ECL_EX_SQL			-11631
#define ECL_EX_MSG			-11641
#define ECL_EX_READ			-11651
#define ECL_NO_AREA_ID		-11652
#define ECL_NO_TUPLE		-11653
#define ECL_TPLNO_OUTR		-11654
#define ECL_EX_OUTPUT		-11671
#define ECL_EX_ON			-11691
#define ECL_EX_BEXP			-11711
#define ECL_EX_LEAVE		-11731
#define ECL_EX_INPUT		-11751
#define ECL_EX_SELMAIN		-11771
#define ECL_EX_LET			-11791
#define ECL_EX_DEFINE		-11811
#define ECL_EX_IMPORT		-11812
#define ECL_EX_SLEEP		-11821

#define ECL_RESET_REDIRECT	0x000f0000

/* Kijima '92.08.19 (Wed) start */
#if 0
#define PACKET_TIMEOUT_ERROR	-11901 /* �ۑ��p�P�b�g�̃^�C���A�E�g�G���[ */
#define PACKET_ID_ERROR			-11903 /* �p�P�b�g�̂h�c���s�� */
#endif
#define PACKET_RECEIVE_ERROR	-11902 /* ��M�p�P�b�g�̃G���[ */

/* 95.1.31 Koba */
#define ECL_MULT_OVER		-11904
#define ECL_SHUT_PROC		-11905

#define ECL_DO_STACK_ZERO	-11911

#define ECL_SYSTEM_ERROR	-11999
#define ECL_SYS_LEAF_NULL	-11998
#define ECL_SYS_SCCT_NULL	-11997
#define ECL_SYS_PRCT_NULL	-11996
#define ECL_SYS_ERLK_SCPR	-11995
#define ECL_SYS_ERLK_PRCT	-11994

#define ERROR_MAX_OBJ		-215249901
#define ERROR_MAX_DA		-215249902
#define ERROR_MAX_TREE		-215249903
#define ERROR_MAX_NEST		-215249904
#define ERROR_MAX_STACK		-215249905
#define ERROR_MIN_STACK		-215249906

/*****************************************/
/*		 �c�a�Ǘ��̃G���[�R�[�h		*/
/*****************************************/

#define NORMAL			0		 /* ����(���^�[���l)					   */

/*
 * SQL�G���[�R�[�h
 */
#define SQLERROR		-10002		 /* �r�p�k���s�ُ�(���^�[���l)			 */

/*
 * �V�X�e���G���[�R�[�h
 */
#define EDB_MKPCKT		-10101		 /*							*/
#define SYSTEMERROR		-10111		 /* �V�X�e���G���[							*/

/*
 * ���W�J���G���[
 */
#define LOGICALERROR	-10201		 /* ���W�J���G���[						   */
#define NODESCRIPTOR	-10202		 /* �\�P�b�g�w�肪�Ȃ�������			   */
#define UPDATESTART		-10203		 /* �A�b�v�f�[�g�J�n�G���[					*/
#define SAMEUPDTSTART	 10203		 /* same�A�b�v�f�[�g�J�n				 */
#define UPDATEEND		-10204		 /* �A�b�v�f�[�^�I���G���[					*/
#define ANLYERROR		-10205		 /* ��͕s�\						   */

/* Empress Error Number Base */
#define EMPRESSERROR	-10900

/*************************/
/*		��O�R�[�h		 */
/*************************/

#define ALL_EXCEPTION					0x80000000
#define IS_EXCEPTION					(ALL_EXCEPTION | 0x01000000)
#define TO_EXCEPTION					(ALL_EXCEPTION | 0x02000000)
#define CMPR_EXCEPTION					(ALL_EXCEPTION | 0x03000000)
#define MATH_EXCEPTION					(ALL_EXCEPTION | 0x04000000)
#define MATH_COMP_EXCEPTION				(MATH_EXCEPTION | 0x010000)
#define MATH_COMP_ERROR_EXCEPTION		MATH_COMP_EXCEPTION
#define MATH_COMP_DEVIDE_EXCEPTION		(MATH_COMP_EXCEPTION | 0x0001)
#define MATH_ETC_EXCEPTION				(MATH_EXCEPTION | 0xfe0000)
#define MATH_ETC_ERROR_EXCEPTION		MATH_ETC_EXCEPTION
#define STRING_EXCEPTION				(ALL_EXCEPTION | 0x05000000)
#define FILE_EXCEPTION					(ALL_EXCEPTION | 0x06000000)
#define FILE_OPEN_EXCEPTION				(FILE_EXCEPTION | 0x010000)
#define FILE_OPEN_ERROR_EXCEPTION		FILE_OPEN_EXCEPTION
#define FILE_OPEN_NOTFOUND_EXCEPTION	(FILE_OPEN_EXCEPTION | 0x0002)
#define FILE_CLOSE_EXCEPTION			(FILE_EXCEPTION | 0x020000)
#define FILE_CLOSE_ERROR_EXCEPTION		FILE_CLOSE_EXCEPTION
#define FILE_READ_EXCEPTION				(FILE_EXCEPTION | 0x030000)
#define FILE_READ_ERROR_EXCEPTION		FILE_READ_EXCEPTION
#define FILE_READ_END_EXCEPTION			(FILE_READ_EXCEPTION | 0x0001)
#define FILE_WRITE_EXCEPTION			(FILE_EXCEPTION | 0x040000)
#define FILE_WRITE_ERROR_EXCEPTION		FILE_WRITE_EXCEPTION
#define FILE_ETC_EXCEPTION				(FILE_EXCEPTION | 0xfe0000)
#define FILE_ETC_ERROR_EXCEPTION		FILE_ETC_EXCEPTION
#define LOG_EXCEPTION					(ALL_EXCEPTION | 0x07000000)
#define SQL_EXCEPTION					(ALL_EXCEPTION | 0x08000000)
#define COMM_EXCEPTION					(ALL_EXCEPTION | 0x09000000)
#define USER_EXCEPTION					(ALL_EXCEPTION | 0x7c000000)
#define SYSTEM_EXCEPTION				(ALL_EXCEPTION | 0x7d000000)
#define ETC_EXCEPTION					(ALL_EXCEPTION | 0x7e000000)

#endif	/* _CMERROR_H */
