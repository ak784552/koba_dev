#!/bin/sh

LC_TIME=C
export LC_TIME
#echo 'char	make_date[] ="@(#) ***[DATE='`date`']***";' > date.c
echo 'char	make_date[] ="@(#) ***[DATE='`date "+%Y/%m/%d %H:%M:%S"`']***";' > date.c
