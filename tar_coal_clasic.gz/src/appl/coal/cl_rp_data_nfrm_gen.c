static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �f�[�^�m�[�h�t�B���h�t���[����������                   *
*                                                                             *
*      �֐����@�@�@�F�@int cl_rp_data_nfrm_gen( pDNCB , pBuff , len )         *
*                                                                             *
*      ������      �F�@(I) DataNodeCB  *pDNCB                                 *
*                    �@(I) char        *pBuff                                 *
*                    �@(I) int         *len                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include "colmn.h"
extern CLPRTBL *pCLprocTable;

int cl_rp_data_nfrm_gen(pLeaf,proc)
Leaf  *pLeaf;
ProcCT  *proc;
{
int rc,TapleNo,Fieldnum;
int i ;
	int w_len;
	char   wBuff[20], *fname;
	cmdInfo   *pwcmd;
	MCAT      *mcat;
	ScrPrCT   *pScCT;
	prmList   prm_list;
	tdtIndirectInfo *pKAN;

	if (!pLeaf) return( ERROR );
	pwcmd = &(pLeaf->cmd);
	if (pwcmd->prmnum < 3) {
		ERROROUT("Parameter is few!! (DT i n D1 D2 ... Dn)");
		return ECL_EX_OUTPUT;
	}
									/* �^�v���ԍ��̃Z�b�g         */
	if (rc = cl_ot_conv_arg(pwcmd->prmp[1],proc->Obj,&TapleNo)) return( rc );
	if ( TapleNo >= 90000 ) {
		if ( TapleNo <= 99000 ) {
			cl_user_func(pLeaf,proc,"DT");
			return 0;
		}
	}
									/* �f�[�^�t�B�[���h���̃Z�b�g */
	if (rc = cl_ot_conv_arg(pwcmd->prmp[2],proc->Obj,&Fieldnum)) return( rc );

	if ( Fieldnum != pwcmd->prmnum - 3 ) {
		ERROROUT("Data number is too or few!! Error Fixed.");
		Fieldnum = pwcmd->prmnum - 3 ;
	}
	if (!(pScCT=cl_search_src_ct())) {
		return( ECL_SCRIPT_ERROR );
	}

	if (rc=cl_make_list_pbody()) return rc;
	mcat = &pCLprocTable->ListPBody->mCat;
	pKAN = &pCLprocTable->ListPBody->indInfo;
	fname = pCLprocTable->ListPBody->fname;

	sprintf( wBuff ,"DT%-5d%-5d" ,  TapleNo, Fieldnum );
	if ((rc=axtmcats(mcat, wBuff))<0) return rc;

	for (i = 0 ; i < Fieldnum ; i++ ) {
		if (rc=cl_arg_to_var(pwcmd->prmp[i+3],proc->Obj,&prm_list)) {
			/* %s: �� %d �p�����[�^������Ă��܂�(rc=%d)�B */
			ERROROUT3(FORMAT(47),"cl_rp_data_nfrm_gen",i+3,rc);
			prm_list_clear(&prm_list);
			return( ECL_SCRIPT_ERROR );
		}
		if (rc=cl_rp_data_nfrm_set(mcat,&prm_list,pKAN,fname)) return rc;
		prm_list_clear(&prm_list);
	}

	return( NORMAL );
}

static int _file(mcat, file)
MCAT *mcat;
char *file;
{
	int rc,len;
	char buf[256];
	FILE *fp;

	if (!(fp=fopen(akb_akb_home_add(file),"r"))) return -1;
	len = -1;
	while (fgets(buf,sizeof(buf),fp)) {
		len = strlen(buf);
		if ((rc=axtmcat(mcat,buf,len)) < 0) break;
	}
	if (len>=1 && buf[len-1]!='\n') axtmcat(mcat,"\n",1);
	return 0;
}

int cl_rp_text_nfrm_gen(pLeaf,proc,opt)
Leaf  *pLeaf;
ProcCT  *proc;
int   opt;	/* 0/1/2=non LF/+LF/file */
{
	int rc,nparm;
	int i;
	cmdInfo   *pwcmd;
	MCAT      *mcat;
	parmList  **prm;
	tdtInfoParm InfoParmW;
	char      w1[16],*p1;

	if (!pLeaf) return( ERROR );
	pwcmd = &(pLeaf->cmd);
	nparm = pwcmd->prmnum;		/* �f�[�^�t�B�[���h���̃Z�b�g */
	if (nparm <= 1) return 0;

	if (rc=cl_make_list_pbody()) return rc;
	mcat = &pCLprocTable->ListPBody->mCat;
	prm = pwcmd->prmp;

	for (i=1;i<nparm;i++) {
		InfoParmW.pi_scale = 0;
		if (rc=cl_gx_exp_obj(1,&prm[i],proc->Obj,&InfoParmW)) {
			/* %s: ��������Ă��܂�(rc=%d)�B */
			ERROROUT2(FORMAT(48),"rp_text_nfrm_gen",rc);
			if (rc > 0) rc = -1;
			break;
		}
		p1 = w1;
		if ((rc=parm_to_char(&InfoParmW,&p1,NULL))<0) break;
		if (opt == 2) {	/* input file */
			rc = _file(mcat, p1);
		}
		else {
			rc = akxtmcat(mcat, p1, rc);
		}
		if (rc < 0) break;
	}
	if (rc < 0) {
		return rc;
	}
	if (opt == 1) if ((rc = akxtmcat(mcat, "\n", 1)) < 0) return rc;

	return 0;
}
