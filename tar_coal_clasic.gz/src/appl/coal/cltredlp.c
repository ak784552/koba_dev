static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       ColMnTrEndloop                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
static int _tr_loop_node_check(y,able,na,loop_name)
condList *y;
int  *able[],na;
char *loop_name;
{
	Leaf *leaf;
	char *p;
	int rc=0;

	rc = cl_tr_node_check_leaf(y,NULL,0,able,na,&leaf);
	if (rc) rc = ECL_TR_ENDLOOP;
	else if (leaf->cmd.cid==C_LOOP && stricmp(p=leaf->cmd.prmp[0]->prp,loop_name)) {
		/* col_mn_tr_end_loop: ���[�v�̊J�n��[LOOP ]%s�ɂȂ��Ă��܂��Bline=%d */
		ERROROUT2(FORMAT(71),p,leaf->cmd.rc);
		rc = ECL_TR_ENDLOOP;
	}
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_loop(y)
condList *y;
{
	static int able[]={C_LOOP};
	static int abledl[]={C_LOOP};
	int  rc;
	Leaf *leaf;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum > 0) {
		ERROROUT1(FORMAT(41),"col_mn_tr_end_loop");
		return ECL_TR_ENDLOOP;
	}
	else {
		if (cmd->cid==C_ENDLOOP) {
			rc = cl_tr_node_check(y,NULL,0,able,2);
			if (rc) return ECL_TR_ENDLOOP;
		}
	}
	rc = cl_nest_tag(y,2);
	if (rc != -1) {
		rc=cl_change_tree(y,y->clstcb->nestLev2 );
	/*	if (rc) return (rc);	*/
		cl_search_nest(y,2);
	}
	else return ECL_TR_ENDLOOP;
/*  else clError(30); */
	return NormalEnd;
}

/************************************************/
/*                                              */
/*     cl_loop_close                            */
/*----------------------------------------------*/
/*                                              */
/*                                              */
/************************************************/
/* */
int cl_loop_close(y,cid)
condList *y;
int cid;
{
	int rc,cmdid;
	Leaf *leaf;

	rc = 0;
	for (;;) {
		if (!(leaf=y->clstcb->nestLev2)) break;
		cmdid = leaf->cmd.cid;
		if (cid==C_LOOP && cmdid!=C_LOOP) {
			rc = cl_nest_tag(y,2);
			if (rc != -1) {
				cl_change_tree(y,y->clstcb->nestLev2);
				cl_search_nest(y,2);
			/*	ERROROUT(FORMAT(73));	*/
				rc = 10000;
			}
		}
		else {
			break;
		}
	}
	return rc;
}

/************************************************/
/*                                              */
/*     cl_search_loop                           */
/*----------------------------------------------*/
/*                                              */
/*                                              */
/************************************************/
/* */
int cl_search_loop(y,cid)
condList *y;
int cid;
{
	Leaf  *Dummy;
	int cmdid;
	CLNCB *p;

	p = y->clstcb;
	Dummy = p->nestLev2;
	for(;;) {
		if (Dummy==p->nestLev1 || !Dummy) {
			return ECL_SCRIPT_ERROR;
		}

		cmdid = Dummy->cmd.cid;
		if (cid) {
			if (cmdid==cid) return 0;
		}
		else {
			if (cmdid==C_LOOP) return 0;
		}

		Dummy = Dummy->preleaf;
	}
}
