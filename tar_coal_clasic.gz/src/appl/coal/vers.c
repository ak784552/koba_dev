char version[] ="@(#) ***[V/R=1.0.0 (clasic)]***";
