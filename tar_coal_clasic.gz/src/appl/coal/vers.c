char version[] ="@(#) ***[V/R=1.0.1 (clasic)]***";
