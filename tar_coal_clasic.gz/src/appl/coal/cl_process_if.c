static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �h�e�R�}���h���C��                                     *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_if( pLeaf )                             *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
#define NEORET
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

/********************************************/
/*											*/
/********************************************/
static int _is_if_exec(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
/*	IfCB *next;	*/
	BlockCB *next;

	next = proc->pTopBlockCB;
	while (next) {
		if (next->Blockleaf == leaf) {

DEBUGOUTL2(190,"_is_if_exec: found leaf=%08x in IfCB=%08x",leaf,next);

			return next->TureFlag;
		}
		next = next->nextBlockCB;
	}
	return -1;
}

/********************************************/
/*											*/
/********************************************/
int cl_process_if(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int  rc;
	int  Tupple;
	int  Value;
	int  Flag;
	BlockCB *pIfCB;

DEBUGOUTL1(110,"cl_process_if: enter proc=%08x",pProc);
	if (rc = cl_if_pre_proc(pLeaf, pProc)) return rc;

	if ((Flag = cl_if_comp_ctl(pLeaf,pProc)) < NORMAL) return ECL_EX_IF;

	if (Flag == L_ON) {
		pIfCB = pProc->pcrBlockCB;
		pIfCB->TureFlag = L_ON;
		pIfCB->Blockleaf = pLeaf;
		pProc->Nextleaf = pLeaf->leftleaf;
DEBUGOUTL1(110,"cl_process_if: push [ %s ]",cl_get_pcmd_line(pLeaf->rightleaf));
		cl_ret_leaf_push(pProc,pLeaf->rightleaf);
	}
	else {
		pProc->Nextleaf = pLeaf->rightleaf;
	}

	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_get_InfoParm2(tInfoParm2,ppInfoParm,flags)
tdtInfoParm tInfoParm2[],**ppInfoParm;
int flags[];
{
	tdtInfoParm *pInfoParm;
	int nparm,iPARMINFO2;

#if 1	/* 2024.5.7 */
	if (tInfoParm2[0].pi_id == 'S') {
		nparm = 1;
		pInfoParm = tInfoParm2;
		iPARMINFO2 = 0;
	}
	else
#endif
	if ((tInfoParm2[0].pi_alen & D_AULN_PARMINFO2) && (nparm=tInfoParm2[1].pi_pos)) {
		pInfoParm = (tdtInfoParm *)tInfoParm2[1].pi_data;
		iPARMINFO2 = 1;
	}
	else {
		nparm = 1;
		pInfoParm = tInfoParm2;
		iPARMINFO2 = 0;
	}
	*ppInfoParm = pInfoParm;
	if (flags) flags[0] = iPARMINFO2;
	return nparm;
}
