static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ��������i�E�ӂ��ϐ��̎��j            �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_rep_info_set(pInfoParmO,pInfoParmI)          *
*                      (O)tdtInfoParm *pInfoParmO                             *
*                      (I)tdtInfoParm *pInfoParmI                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
/*	  error code : -215220101�`-215229999	*/
#include <colmn.h>

extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;
extern CLCOMMON CLcommon;
extern tdtIterate_ctl gtIter_ctl[];
extern char *ScopeNames[];
extern char *ScopeMarks[];
extern int  ScopeGXOpts[];
extern int  ScopeAUX1s[];

/*static int _rep_list_info_set();*/
static int _gx_rep_all_data();
static int _check_exist_mk_key(/*mcat,pInfoParm*/);

#if 1
/****************************************/
/*	01									*/
/****************************************/
static int _val_set_BINA_FLOA(p,atr,size,Val,attr,len,ix)
char *p;
int atr,size,Val[],attr,len,ix;
{
	int rc,iValue;
	char *name,*pV=(char *)Val;
	double dValue;

	name = "_val_set_BINA_FLOA";
/*
printf("%s:Enter p=%08x atr=%d size=%d Val=%08x attr=%d len=%d ix=%d\n",name,p,atr,size,Val,attr,len,ix);
*/
	p += size*ix;
	pV += len*ix;
	if (ix) Val++;
/*
printf("%s: p=%08x pV=%08x Val=%08x\n",name,p,pV,Val);
*/
	if (attr == DEF_ZOK_BINA) iValue = CL_GET_VAL_BIN(Val);
	else memcpy(&dValue,pV,sizeof(double));
	if (atr == DEF_ZOK_BINA) {
		if (attr == DEF_ZOK_FLOA) iValue = cl_chk_over_flow_d2_i(dValue,name);
		*(int *)p = iValue;
DEBUGOUTL2(151,"%s:BINA:%d",name,*(int *)p);
	}
	else {
		if (attr == DEF_ZOK_BINA) dValue = iValue;
		*(double *)p = dValue;
DEBUGOUTL2(151,"%s:FLOA:%e",name,*(double *)p);
	}
	return 0;
}

/****************************************/
/*	01-1								*/
/****************************************/
static int _val_clr(Val,attr,len,ix)
char *Val;
int attr,len,ix;
{
	int rc;
/*
printf("_val_clr:Enter Val=%08x attr=%d len=%d ix=%d\n",Val,attr,len,ix);
*/
	rc = 0;
	Val += len*ix;
/*
printf("_val_clr:Enter Val=%08x\n",Val);
*/
	if (attr==DEF_ZOK_BINA || attr==DEF_ZOK_FLOA) memset(Val,0,len);
	else if (attr == DEF_ZOK_DECI) memcpy(Val,m_get_i(0),len);
	else rc = -1;
	return rc;
}

/****************************************/
/*	02									*/
/****************************************/
static int _val_set_DECI(pInfoParm,p,size,Val,attr,len,ix)
tdtInfoParm *pInfoParm;
char *p;
int size,Val[],attr,len,ix;
{
	int rc;
	char *pV=(char *)Val;
	double dValue;

	p += size*ix;
	pV += len*ix;
	if (attr == DEF_ZOK_BINA) {
		m_i2mpa(Val[ix],(MPA *)p);
	}
	else if (attr == DEF_ZOK_FLOA) {
		memcpy(&dValue,pV,len);
		m_d2mpa(dValue,(MPA *)p);
	}
	else memcpy(p,pV,len);
	if (pInfoParm->pi_hlen) {
		if ((rc=cl_mpa_scale(p,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
	}
	return 0;
}

#endif
/****************************************/
/*	03									*/
/****************************************/
static char *_set_mem_size_zero(pInfoParm,size,im)
tdtInfoParm *pInfoParm;
int size,im;
{
	char *p;
/*
printf("_set_mem_size_zero: pInfoParm->pi_scale=%02x\n",pInfoParm->pi_scale);
*/
	/* 2021.10.6 */
	if (im==D_OPT_ALC_MALLOC && pInfoParm->pi_scale & D_DATA_MALLOC)
		p = Realloc(pInfoParm->pi_data,size);
	else p = cl_opt_malloc(im,size);
	pInfoParm->pi_data = p;
	if (p) {
		pInfoParm->pi_data = p;
		pInfoParm->pi_paux = p;
	}
	return p;
}

/****************************************/
/*	04									*/
/****************************************/
static char *_gx_rep_get_addr_index(pInfoParmI)
tdtInfoParm *pInfoParmI;
{
	char id,*p;
	tdtDefType *pDefType;
	tdtArrayIndex *pIndex;

	id = pInfoParmI->pi_id;
	if (id == D_DATA_ID_STRUCT) {
		pDefType = (tdtDefType *)pInfoParmI->pi_data;
		p = (char *)pDefType->pType;
	}
	else if (id==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY) {
		pIndex = (tdtArrayIndex *)pInfoParmI->pi_data;
		if (!(p=(char *)pIndex->xhp)) p = (char *)pIndex->pVarIndex;
	}
	else p = pInfoParmI->pi_data;
	return p;
}

/****************************************/
/*	05									*/
/****************************************/
static int _gx_rep_set_sca_im(sca,im,opt_tmp,add_flag)
int sca,im,opt_tmp,add_flag;
{
	if (!(sca & D_DATA_LPOSDATA)) {
		if (im == D_OPT_ALC_MALLOC) sca |= D_DATA_MALLOC | add_flag;
		else {
			if (opt_tmp > 0) sca |= D_DATA_INDEX_TMP;
			if (im != D_OPT_ALC_MALLOC) sca &= ~D_DATA_MALLOC;
		}
	/*	else if (!opt_tmp && im==D_OPT_ALC_TMP) sca |= D_DATA_INDEX_TMP;	2023.2.4 */
	}
	return sca;
}

/****************************************/
/*	06									*/
/****************************************/
static int _gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt)
tdtInfoParm *pInfoParmO,*pInfoParmI;
int iOpt;
{
	static char *name = "_gx_rep_val_set";
	int *pi,rc,iValue,iRANGE,dlen1,dlen2,dlen,im,iNULL_VALUE;
	int  atr,attr,size,iAttr[4],len;
	double dValue,*pd;
	char *p,w1[32],*p1,*pV,c,w2[32],*p2,c1,c2;
	tdtInfoParm tInfoParmI;
	time_t tt;
	long lValue,Valz[NMPA_LONG*2],*Val;
	struct  tm *stm;
	tdtInfoParm tInfoParm;

	p = pInfoParmO->pi_paux;
	atr = pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA;
/*
printf("%s:Enter atr=%d\n",name,atr);
*/
DEBUGOUTL2(110,"%s:Enter: atr=%d",name,atr);
	c1 = pInfoParmO->pi_id;
	c2 = pInfoParmI->pi_id;
/*
printf("%s:Enter c1=[%c] c2=[%c]\n",name,c1,c2);
*/
  if (c1==' ' && c2==' ') {
	Val = cl_get_tmpMPA2(Valz,2);
	im = (iOpt & D_GX_OPT_ALC_MASK)>>12;
	if (!im) im = D_OPT_ALC_MALLOC;
	if (atr > 0) iAttr[0] = D_GX_OPT_USE_ATTR | atr;
	else iAttr[0] = 0;
	len = size = pInfoParmO->pi_len;
	iRANGE = pInfoParmI->pi_alen & D_AULN_RANGE_DATA;
	iNULL_VALUE = 0;
	if (!(cl_get_option(1,0) & 0x40)) iNULL_VALUE = pInfoParmI->pi_alen & D_AULN_NULL_VALUE;
DEBUGOUTL4(151,"%s: atr=%d pi_paux=%08x pi_len=%d",name,atr,p,size);
	if (atr == DEF_ZOK_BINA) {
		if ((rc=cl_get_parm_long(pInfoParmI,Val,"_gx_rep_val_set.BINA")) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParmO->pi_scale & 0x80) Free(pInfoParmO->pi_data);
#if defined(_LP64)	/* 2021.9.6 */
		if (size == sizeof(int)) {
			*(int *)p = Val[0];
DEBUGOUTL2(151,"%s:BINA:%d",name,*(int *)p);
		}
		else {
			*(long *)p = Val[0];
DEBUGOUTL2(151,"%s:BINA:%ld",name,*(long *)p);
		}
#else
		*(long *)p = Val[0];
DEBUGOUTL2(151,"%s:BINA:%d",name,*(long *)p);
#endif
		pInfoParmO->pi_dlen = size;	/* add 2023.5.5 */
	}
	else if (atr == DEF_ZOK_FLOA) {
		if ((rc=cl_get_parm_double(pInfoParmI,Val,"_gx_rep_val_set.FLOA")) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParmO->pi_scale & 0x80) Free(pInfoParmO->pi_data);
		memcpy(&dValue,Val,sizeof(double));
		*(double *)p = dValue;
DEBUGOUTL2(151,"%s:FLOA:%f",name,*(double *)p);
	}
	else if (atr == DEF_ZOK_DECI) {
		if ((rc=cl_get_parm_dec(pInfoParmI,Val,"_gx_rep_val_set.DECI")) < 0)
			return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		memcpy(p,Val,size);
		if (pInfoParmO->pi_hlen) {
			if ((rc=cl_mpa_scale(p,pInfoParmO->pi_hlen,pInfoParmO->pi_pos))<0) return rc;
		}
	}
	else if (atr == DEF_ZOK_CHAR) {
		p1 = w1;
		if ((rc = parm_to_char(pInfoParmI,&p1,NULL)) < 0) return rc;
		if (iRANGE && size<=0) {
				dlen1 = rc;
				cl_gx_copy_info(&tInfoParmI,pInfoParmI);
				tInfoParmI.pi_aux[0] = tInfoParmI.pi_alen = 0;
				if (tInfoParmI.pi_attr == DEF_ZOK_BINA) tInfoParmI.pi_pos = tInfoParmI.pi_hlen;
				else tInfoParmI.pi_data += tInfoParmI.pi_dlen;
				p2 = w2;
				if ((rc = parm_to_char(&tInfoParmI,&p2,NULL)) < 0) return rc;
				dlen2 = rc;
				if (pInfoParmI->pi_attr == DEF_ZOK_CHAR) dlen = pInfoParmI->pi_dlen;
				else dlen = X_MAX(dlen1,dlen2) + 1;
				if (!(p=_set_mem_size_zero(pInfoParmO,dlen*2,im))) return ECL_MALLOC_ERROR;
				memzcpy(p,p1,dlen1);
				memzcpy(p+dlen,p2,dlen2);
DEBUGOUTL3(151,"%s:CHAR RANGE:[%s]..[%s]",name,p,p+dlen);
				pInfoParmO->pi_dlen = dlen;
				pInfoParmO->pi_alen |= iRANGE;
				pInfoParmO->pi_aux[0] |= pInfoParmI->pi_aux[0] & DEF_ZOK_DATA;
		}
		else {
			if (size <= 0) {
				size = rc;
				if (!(p=_set_mem_size_zero(pInfoParmO,size+1,im))) return ECL_MALLOC_ERROR;
			}
			pInfoParmO->pi_dlen = memnzcpy(p,p1,rc,size+1);
DEBUGOUTL2(151,"%s:CHAR:[%s]",name,p);
		}
	}
	else if (atr == DEF_ZOK_BULK) {
		if (!(p1=_to_bulk(pInfoParmI,iAttr,0))) return iAttr[0];
		if (size <= 0) {
			size = iAttr[1];
			if (!(p=_set_mem_size_zero(pInfoParmO,size+sizeof(int),im))) return ECL_MALLOC_ERROR;
		}
		pInfoParmO->pi_dlen = rc = X_MIN(iAttr[1],size);
		memcpy(p+size,&rc,sizeof(int));
		memcpy(p,p1,rc);
DEBUGOUTL3(151,"%s:BULK:size=%d len=%d",name,size,rc);
	}
	if (iNULL_VALUE) pInfoParmO->pi_alen |= iNULL_VALUE;
	else pInfoParmO->pi_alen &= ~D_AULN_NULL_VALUE;
  }
  else {
  		if (c1 == ' ') {
			cl_print_attr(w2,sizeof(w2),pInfoParmO,NULL);
					/* %s: �f�[�^����(id1=[%c] atr=%s id2=[%c])�������Ă��܂���B*/
			ERROROUT4(FORMAT(652),name,c1,w2,c2);
		}
		else {
			p = (char *)pInfoParmO->pi_pos;
#if 1	/* 2021.8.2 */
					/* %s: %s(%s)�ւ̑���͂ł��܂���B */
			ERROROUT3(FORMAT(132),name,cl_gx_get_name_from_id(c1),nval1(p));
#else
					/* %s: %s�ɂ͑���ł��܂���B*/
			ERROROUT2(FORMAT(126),name,nval1(p));
#endif
		}
  		return ECL_SCRIPT_ERROR;
  }
	pInfoParmO->pi_aux[1] &= ~(D_AUX1_PROTECTED | D_AUX1_HASHED_NAME);
	pInfoParmO->pi_alen |= pInfoParmI->pi_alen & D_AULN_FILE_POINTER;
DEBUGOUT_InfoParm(151,"%s: pInfoParmO:",pInfoParmO,name,0);
/*
printf("%s:Exit\n",name);
*/
DEBUGOUTL1(110,"%s:Exit",name);
	return 0;
}

/****************************************/
/*	16									*/
/****************************************/
int cl_gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt)
tdtInfoParm *pInfoParmO,*pInfoParmI;
int iOpt;
{
	int ret,aux0,len;
	char *paux;
	tdtInfoParm tInfoParm,*pInfoParm;

DEBUGOUT_InfoParm(120,"cl_gx_rep_val_set: pInfoParmO=",pInfoParmO,0,0);
DEBUGOUT_InfoParm(120,"cl_gx_rep_val_set: pInfoParmI=",pInfoParmI,0,0);
	if (pInfoParmO->pi_paux && (pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA)) {
		ret = _gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt);
	}
	else {
		tInfoParm = *pInfoParmO;
		len  = tInfoParm.pi_len;
		paux = tInfoParm.pi_paux;
		aux0 = tInfoParm.pi_aux[0];
		tInfoParm.pi_paux   = tInfoParm.pi_data;
		tInfoParm.pi_aux[0] = tInfoParm.pi_attr;
		ret = _gx_rep_val_set(&tInfoParm,pInfoParmI,iOpt);
		tInfoParm.pi_len = len;
		tInfoParm.pi_paux   = paux;
		tInfoParm.pi_aux[0] = aux0;
	}
	return ret;
}

/****************************************/
/*	17									*/
/****************************************/
int cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt0)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	char c,id,*p,*pp;
	uchar aux0;
	int  rc,len,attr,alen,im,iOpt,iRANGE,len1,iFUNC,sca,aux1_scope,opt2,mask,iDCOPY;
	long *argv[2],lVal,lCount;
	tdtInfoParm *pInfoParm;
	tdtRbChain *xha;

DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data:Enter: iOpt0=%08x pInfoParmI=",pInfoParmI,iOpt0,0);

	if (iOpt0 < 0) {
		iOpt = -1;
		iOpt0 = 0;
	}
	else iOpt = iOpt0 & 0x03;

	pInfoParmO->pi_aux[1] &= ~(D_AUX1_PROTECTED | D_AUX1_HASHED_NAME | D_AUX1_VAR_SCOPE);

	id = pInfoParmO->pi_id;
	if ((aux0=pInfoParmO->pi_aux[0]) & ~DEF_ZOK_DATA) {
		/* aux0���A0x15(21),0x16(22),0x17(23) �łȂ���΁A�N���A���� */
		if (!(aux0 & 0x10)) {
#if 1	/* 2023.8.23 */
			mask = DEF_ZOK_DATA | D_AUX0_VAR_EXPORT;
			if (id==' ' && (cl_get_option(2,0) & 0x800)) mask |= D_AUX0_ZOK_MASK;
			pInfoParmO->pi_aux[0] &= mask;
#else
			pInfoParmO->pi_aux[0] &= (DEF_ZOK_DATA | D_AUX0_VAR_EXPORT);
#endif
		}
		pInfoParmO->pi_alen &= (D_AULN_RANGE_DATA | D_AULN_RANGE_INTVAL | D_AULN_COMPLEX_DATA);
		if (id!='A' && id!='R') pInfoParmO->pi_paux = NULL;
	}

	if (!(im=(iOpt0 & D_GX_OPT_ALC_MASK)>>12)) im = D_OPT_ALC_MALLOC;
	if (pInfoParmO->pi_scale & D_DATA_LPOSDATA) {
		/* 2021.8.6 */
		if (id == D_DATA_ID_PNAME) {
			pInfoParmO->pi_scale &= ~D_DATA_INDEX_FREE;
			if (iOpt >= 1) {
				if (!(p=cl_opt_malloc(im,sizeof(tdtInfoParm)))) {
					if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
					return ECL_MALLOC_ERROR;
				}
				rc = cl_gx_rep_info_set_ign(p,pInfoParmO->pi_pos,1 | (iOpt0 & D_GX_OPT_ALC_MASK));
				pInfoParmO->pi_scale = _gx_rep_set_sca_im(pInfoParmO->pi_scale,im,0,D_DATA_INDEX_FREE);
				pInfoParmO->pi_pos = (long)p;
			}
		}
		pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
	}
	else if (iOpt >= 1) {
		iRANGE = pInfoParmI->pi_alen & D_AULN_RANGE_DATA;
		pInfoParmO->pi_scale &= ~(D_DATA_MALLOC | D_DATA_INDEX_FREE);
		iDCOPY = 1;
		if (id=='L' || id=='N') {
			if (!(iOpt0 & D_REP_OPT_LN_DCOPY)) iDCOPY = 0;
		}
		else if (id=='A' || id=='R') {
			if (iOpt0 & D_REP_OPT_AR_NCOPY) iDCOPY = 0;
		}
		if (pInfoParmI->pi_dlen>0 && iDCOPY) {
			alen = len = pInfoParmI->pi_dlen;
			iFUNC = 0;
			if ((id=pInfoParmI->pi_id)==' ' || id=='U') {
				attr = pInfoParmI->pi_attr;
				if (attr==DEF_ZOK_CHAR) alen++;
				else if (attr==DEF_ZOK_BULK) alen += sizeof(int);
				if (iRANGE) {
					len1 = alen;
					alen = len1 + len1;
					if (attr==DEF_ZOK_DATE ||
					    (attr!=DEF_ZOK_BINA && (pInfoParmI->pi_alen & D_AULN_RANGE_INTVAL))) alen += len1;
				}
			}
			/* 2021.6.30 */
			else if (strchr("FCIMO",id)) {
				alen++;
				iFUNC = 1;
			}
			if (!(p=cl_opt_malloc(im,alen))) {
				if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
				return ECL_MALLOC_ERROR;
			}
			pInfoParmO->pi_data = p;
			pInfoParmO->pi_scale = _gx_rep_set_sca_im(pInfoParmO->pi_scale,im,0,0);
/*
printf("cl_gx_rep_info_copy_data: p=%08x pInfoParmI->pi_data=%08x\n",p,pInfoParmI->pi_data);
*/
			memcpy(p,pInfoParmI->pi_data,alen);
			p += len;
			if ((id=pInfoParmO->pi_id)==' ' || id=='U') {
				if (attr==DEF_ZOK_CHAR && !iRANGE) *p = '\0';
			}
			/* 2021.6.30 */
			else if (iFUNC) *p = '\0';
		}
		/* 2021.8.5 */
		if ((c=pInfoParmO->pi_id)=='A' || c=='R' || c=='P' || c=='T') {
			if (p=(char *)pInfoParmI->pi_pos) {
				/* 2022.9.20 */
				if (!(pp=cl_opt_malloc(im,strlen(p)+1))) {
					if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
					return ECL_MALLOC_ERROR;
				}
				strcpy(pp,p);
				pInfoParmO->pi_pos = (long)pp;
				if (im == D_OPT_ALC_MALLOC)
					pInfoParmO->pi_alen &= ~D_AULN_NO_AL_LPOS;
				else
					pInfoParmO->pi_alen |= D_AULN_NO_AL_LPOS;
			}
		}
		if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
	}
	if (iOpt <= 1) {
		if ((c=pInfoParmO->pi_id)=='A' || c=='R' || c=='P' || c=='T') {
		/*	pInfoParmO->pi_scale &= ~(D_DATA_MALLOC | D_DATA_INDEX_FREE);	*/
			pInfoParmO->pi_scale &= ~D_DATA_INDEX_FREE;
		/*	pInfoParmO->pi_alen |= D_AULN_NO_AL_LPOS;	del 2021.8.5 */
		}
	}
#if 1	/* 2024.3.29 */
	if ((id=pInfoParmO->pi_id)=='A' || id=='R') {
		if (p = (char *)pInfoParmO->pi_pos) {
			if (*p == '%') pInfoParmO->pi_aux[1] |= D_AUX1_PROTECTED;
		}
	}
#endif
	/* 2022.9.17 */
	if ((c=pInfoParmO->pi_id)=='I' || c=='C') {
/*
printf("cl_gx_rep_info_copy_data: pInfoParmI=%08x pi_scale=%02x\n",pInfoParmI,pInfoParmI->pi_scale);
*/
		if (pInfoParmI->pi_scale & D_DATA_ORG_PROC) {
			pInfoParmO->pi_scale |= D_DATA_CLEAR_PROC;
			pInfoParmO->pi_scale &= ~D_DATA_ORG_PROC;
		}
		else {
			pInfoParmO->pi_scale &= ~D_DATA_CLEAR_PROC;
		}
/*
printf("cl_gx_rep_info_copy_data: pInfoParmO=%08x pi_scale=%02x\n",pInfoParmO,pInfoParmO->pi_scale);
*/
#if 0	/* 2023.1.31 */
		if ((c=pInfoParmO->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI ||
		    c==D_DATA_ID_MAPEDARY || c==D_DATA_ID_ARRAY || c==D_DATA_ID_STRUCT) {
			aux1_scope = pInfoParmO->pi_aux[1] & D_AUX1_VAR_SCOPE;
			pInfoParmO->pi_hlen = _get_gid(NULL,NULL,cl_gx_get_opt_from_aux1(aux1_scope));
		}
#endif
	}
	if (c==' ' && (pInfoParmO->pi_aux[0] & D_AUX0_ZOK_MASK))
		pInfoParmO->pi_paux = pInfoParmO->pi_data;

DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data: pInfoParmO=",pInfoParmO,0,0);
	return 0;
}
/*	18	*/
/************************************************************/
/*	iOpt0 < 0 --> iIGN=1, iOpt<0, iOpt0=0x10				*/
/*	iOpt0 = 0x7000 (D_GX_OPT_ALC_MASK) 						*/
/*	      | 0x0003 (iOpt)									*/
/*	      | 0x0010 (ignore data of pInfoParmO)				*/
/*	      | 0x0020 (check undef of pInfoParmI)				*/
/*	      | 0x0100 (�f�[�^�^�C�v�Œ莞�̕ϊ��̂�)			*/
/*	      | 0x0200 (�ċArep�̂�)							*/
/*	      | 0x0400 (data rep�̂�)							*/
/*	      | 0x010000 (data mode�łȂ���΁A��`�̂݃R�s�[	*/
/*										add 2022.9.19		*/
/*	      | 0x020000 (�������)			add 2022.9.22		*/
/*	      | 0x040000 (L,N�̂Ƃ��Api_data���R�s�[����)		*/
/*	      | 0x080000 (data mode)		add 2022.9.18		*/
/*	      | 0x100000 (A,R�̂Ƃ��Api_data���R�s�[���Ȃ�)		*/
/*	iOpt = 0 : copy only									*/
/*	    >= 1 : copy & Malloc to_pi_data						*/
/*	    >= 2 : copy & Malloc to_pi_data & Free from_pi_data	*/
/************************************************************/
int cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt0,name)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
char *name;
{
	char c,id,*p;
	int  rc,len,attr,alen,iOpt,iIGN,iAux0,iOpt1,iOptSel;
	int  iOptListCopy,iOptAllData,iAux0DataMode,iOpt2,iOptDefOnly,iOptDataMode;
	ScrPrCT *scrct;
	ProcCT  *proc;
	uchar aux1_scope;
/*
printf("cl_gx_rep_info_set_name:Enter: iOpt0=%08x pInfoParmO=%08x pInfoParmI=%08x\n",iOpt0,pInfoParmO,pInfoParmI);
*/
DEBUGOUTL2(110,"cl_gx_rep_info_set_name:Enter: iOpt0=%08x name=[%s]",iOpt0,nval1(name));
if (iOpt<0 || (iOpt & 0x10)) {
DEBUGOUTL1(170,"cl_gx_rep_info_set_name:O: pInfoParmO=%08x",pInfoParmO);
}
else {
DEBUGOUT_InfoParm(170,"cl_gx_rep_info_set_name:O: ",pInfoParmO,0,0);
}
DEBUGOUT_InfoParm(170,"cl_gx_rep_info_set_name:I: ",pInfoParmI,0,0);

	if (!pInfoParmO || !pInfoParmI) return -1;

	if (iOpt0 & D_REP_CHK_UNDEF_IN) {
		if (pInfoParmI->pi_id == D_DATA_ID_UNDEFVAR) {
			return ECL_NDEFVAR_ERROR;
		}
	}
	if (pInfoParmO == pInfoParmI) {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"cl_gx_rep_info_set_name");
		return 0;
	}

	iOptDefOnly = iOpt0 & D_REP_OPT_DEF_ONLY;
	iOpt0 &= ~D_REP_OPT_DEF_ONLY;
	if (iOpt0 < 0) {
		iOptSel = 0;
		iOpt = -1;
		iIGN = 1;
		iOpt0 = D_REP_IGN_OUT_DATA;
		iOpt1 = 0;
	}
	else {
		if (!(iOptSel = iOpt0 & D_REP_OPT_SEL_MASK)) iOptSel = D_REP_OPT_SEL_MASK;
		iOpt = iOpt0 & D_REP_OPT_CPY_MASK;
		iIGN = iOpt0 & D_REP_IGN_OUT_DATA;
		iOpt1 = iOpt;
	}
	aux1_scope = 0;
	if (!iIGN) {	/* pInfoParmO�̐ݒ�𖳎����Ȃ��Ƃ� */
		aux1_scope = pInfoParmO->pi_aux[1] & D_AUX1_VAR_SCOPE;
	  if (iOptSel & D_REP_OPT_SEL_CNVT) {
		/* �f�[�^�^�C�v�Œ�̂Ƃ��́A���̃^�C�v�ɕϊ����� */
		if (pInfoParmO->pi_id==' ' && (pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA)) {
			rc = _gx_rep_val_set(pInfoParmO,pInfoParmI,iOpt0);
			if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
			return rc;
		}
	  }
	}
/*
scrct = cl_search_src_ct();
if (scrct) {
DEBUGOUTL3(110,"cl_gx_rep_info_set_name:1: scrct=%08x ProCT=%08x Vary=%08x",scrct,scrct->ProCT,scrct->Vary);
DEBUGOUT_InfoParm(110,"cl_gx_rep_info_set_name:1: ",pInfoParmO,0,0);
}
*/
/*
printf("cl_gx_rep_info_set_name: iIGN=%d iOpt=%08x\n",iIGN,iOpt);
*/
	if (!iIGN && (iOpt>=0)) cl_free_info_parm(pInfoParmO);

	*pInfoParmO = *pInfoParmI;
	if (!(id=pInfoParmO->pi_id)) return 0;
/*
printf("cl_gx_rep_info_set_name: id=%02x\n",id);
*/
	if (!akxm_addrchk(pInfoParmI->pi_data)) return ECL_SYS_INVALID_ADDR;

	pInfoParmO->pi_scale &= ~D_DATA_MALLOC;
	pInfoParmO->pi_alen &= ~D_AULN_DATA_NARABI;
	if (!iIGN) {
		if ((pInfoParmI->pi_aux[0] & DEF_ZOK_DATA) ||
		    id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) pInfoParmO->pi_aux[1] = aux1_scope;
	}
  if (iOptSel & D_REP_OPT_SEL_RCSV) {
	iOptDataMode = 0;
	iAux0DataMode = pInfoParmI->pi_aux[0] & D_AUX0_ZOK_DATA;
	if (iAux0DataMode || iOptDataMode) iOptDefOnly = 0;
	if (((id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) && !iOptDefOnly) ||
	    ((id==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY || id==D_DATA_ID_STRUCT) &&
	      (iAux0DataMode || (pInfoParmI->pi_scale & D_DATA_INDEX_TMP)))) {	/* add 2021.9.9 */
/*
printf("cl_gx_rep_info_set_name: uc=%02x\n",uc);
*/
		iOpt2 = iOpt1 | iOptDataMode;
		if (iAux0DataMode) iOpt2 |= D_REP_OPT_DATA_MODE;
			iOptAllData = iOpt2;
			rc = _gx_rep_all_data(pInfoParmO,pInfoParmI,name,iOptAllData);
		if (!rc) {
#if 1	/* 2023.1.31 */
			pInfoParmO->pi_hlen = _get_gid(NULL,NULL,cl_gx_get_opt_from_aux1(aux1_scope));
#else
			if (aux1_scope & D_AUX1_LOCAL_VAR) {
				if (proc=cl_search_proc_ct()) pInfoParmO->pi_hlen = proc->ProcGid;
			}
			else if (aux1_scope & D_AUX1_PRIVATE_VAR) {
				if (scrct=cl_search_src_ct()) pInfoParmO->pi_hlen = scrct->ScrGid;
			}
#endif
			pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
		}
		return rc;
	}
  }
  if (iOptSel & D_REP_OPT_SEL_DATA) {
	if (rc=cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt0)) return rc;
	pInfoParmO->pi_aux[1] |= aux1_scope;	/* add 2021.9.14 */

	if (pInfoParmO->pi_id=='I' && iOpt>0 && name) {
		Free(pInfoParmO->pi_data);
		pInfoParmO->pi_data = Strdup(name);
		pInfoParmO->pi_dlen = strlen(name);
	}
/*
if (scrct) {
DEBUGOUTL3(110,"cl_gx_rep_info_set_name:2: scrct=%08x ProCT=%08x Vary=%08x",scrct,scrct->ProCT,scrct->Vary);
}
*/
DEBUGOUT_InfoParm(110,"cl_gx_rep_info_set_name:Exit: O:",pInfoParmO,0,0);
/*
printf("cl_gx_rep_info_set_name:Exit ret=0\n");
*/
DEBUGOUTL(110,"cl_gx_rep_info_set_name:Exit ret=0");
  }
	return NORMAL;
}

/****************************************/
/*	19									*/
/****************************************/
int cl_gx_rep_info_set(pInfoParmO ,pInfoParmI ,iOpt)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt;
{
	return cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt,NULL);
}

/****************************************/
/*	20									*/
/****************************************/
int cl_gx_rep_info_set_alloc(pvParmO,pInfoParmI,opt)
tdtInfoParm **pvParmO,*pInfoParmI;
int opt;
{
	tdtInfoParm *pParm;

	/* 2021.9.9 */
	if (!(pParm=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) return -1;
	*pvParmO = pParm;
	return cl_gx_rep_info_set_ign(pParm,pInfoParmI,opt|D_GX_OPT_ALC_TMP);
}

/****************************************/
/*	21									*/
/****************************************/
int cl_gx_rep_info_set_ign(pInfoParmO,pInfoParmI,iOpt)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt;
{
	cl_parm_set0(pInfoParmO);
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt|D_REP_IGN_OUT_DATA);
}

/****************************************/
/*	22									*/
/****************************************/
int cl_gx_rep_info_convert(pInfoParmO,pInfoParmI,iOpt0)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	iOpt0 = (iOpt0 & ~D_REP_OPT_SEL_MASK) | D_REP_OPT_SEL_CNVT;
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt0);
}

/****************************************/
/*	23									*/
/****************************************/
int cl_gx_rep_info_als(pInfoParmO,pInfoParmI,iOpt0)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	gtIter_ctl[0].itc_circ_ref = NULL;
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt0);
}

/****************************************/
/*	24									*/
/****************************************/
int cl_gx_rep_info_als_name(pInfoParmO,pInfoParmI,iOpt0,name)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
char *name;
{
	gtIter_ctl[0].itc_circ_ref = NULL;
	return cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt0,name);
}

/****************************************/
/*	25									*/
/****************************************/
int cl_gx_rep_info_data(pInfoParmO,pInfoParmI,iOpt0)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
{
	iOpt0 = (iOpt0 & ~D_REP_OPT_SEL_MASK) | D_REP_OPT_SEL_DATA | D_REP_OPT_SEL_CNVT;
	return cl_gx_rep_info_set(pInfoParmO,pInfoParmI,iOpt0);
}

/****************************************/
/*	26									*/
/****************************************/
tdtInfoParm *cl_gx_copy_info_opt(pInfoParmO,pInfoParmI,opt)
tdtInfoParm *pInfoParmO, *pInfoParmI;
int opt;
{
	if (!pInfoParmO || !pInfoParmI) return NULL;
	if (pInfoParmO != pInfoParmI) {
		*pInfoParmO = *pInfoParmI;
		if (pInfoParmO->pi_scale & D_DATA_LPOSDATA)
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
		if (opt & 0x01) pInfoParmO->pi_scale &= ~D_DATA_MALLOC;	/* add 2022.6.14 */
	}
	return pInfoParmO;
}

/*	27	*/
/********1*********2*********3*********4*********5*********6*/
/* �@�\ : pi_data�ȊO��Info���R�s�[���A�f�[�^���R�s�[����	*/
/* ���� : pInfoParmO : �R�s�[��Info							*/
/*			NULL�̂Ƃ��́Atmp_malloc���A�����Ԃ�			*/
/*			O.pi_data��NULL���AO.pi_dlen<I.pi_dlen�̂Ƃ���	*/
/*			O.pi_data��tmp_malloc����						*/
/*		  pInfoParmI : �R�s�[��Info							*/
/*			NULL�̂Ƃ��́ANULL��Ԃ�						*/
/*		  opt        : 	addr�I�v�V����						*/
/*			= 0 : ��L�@�\									*/
/*			= 1 : pInfoParmO<>NULL							*/
/*					pInfoParmO=NULL�̂Ƃ��́A�G���[			*/
/*			= 2 : pInfoParmO->pi_data<>NULL (opt=1���܂�)	*/
/*					pInfoParmO->pi_data=NULL�̂Ƃ��́A�G���[*/
/*			= 3 : pInfoParmO->pi_dlen>=pInfoParmI->pi_dlen	*/
/*											(opt=1,2���܂�)	*/
/*					pInfoParmO->pi_dlen<pInfoParmI->pi_dlen	*/
/*					�̂Ƃ��́A�G���[						*/
/* �ԋp : pInfoParmO										*/
/************************************************************/
tdtInfoParm *cl_gx_copy_info2_opt(pInfoParmO,pInfoParmI,opt)
tdtInfoParm *pInfoParmO, *pInfoParmI;
int opt;
{
	char *p;
	int ret,len,alen;

	ret = 0;
	if (!pInfoParmI) {
		return NULL;
	}
	if (opt < 0) opt = 0;
	if (!pInfoParmO) {
		if (opt) {
			return NULL;
		}
		if (!(pInfoParmO=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) {
			return NULL;
		}
		memset(pInfoParmO,0,sizeof(tdtInfoParm));
	}
	if (pInfoParmO != pInfoParmI) {
		if (pInfoParmI->pi_scale & D_DATA_LPOSDATA) {
			*pInfoParmO = *pInfoParmI;
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
/*
printf("cl_gx_copy_info2: O.pos=%d\n",pInfoParmO->pi_pos);
*/
		}
		else {
			p   = pInfoParmO->pi_data;
			len = pInfoParmI->pi_dlen;
/*
printf("cl_gx_copy_info2: O.data=%08x O.dlen=%d I.data=%08x I.dlen=%d\n",p,pInfoParmO->pi_dlen,pInfoParmI->pi_data,len);
*/
			if (opt>=2 && !p) {
				return NULL;
			}
			else if (opt>=3 && pInfoParmO->pi_dlen<len) {
				return NULL;
			}
			else if (!p || (pInfoParmO->pi_dlen<len)) {
				alen = len;
				if (pInfoParmI->pi_attr == DEF_ZOK_CHAR) alen++;
				if (!(p=cl_tmp_const_malloc(alen))) {
					return NULL;
				}
			}
			*pInfoParmO = *pInfoParmI;
			memcpy(p,pInfoParmI->pi_data,len);
			if (pInfoParmO->pi_attr == DEF_ZOK_CHAR) *(p+len) = '\0';
			pInfoParmO->pi_data = p;
		}
	}
	else {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"cl_gx_copy_info2_opt");
	}
	return pInfoParmO;
}

/****************************************/
/*	28									*/
/****************************************/
tdtInfoParm *cl_gx_copy_info2(pInfoParmO,pInfoParmI)
tdtInfoParm *pInfoParmO, *pInfoParmI;
{
	return cl_gx_copy_info2_opt(pInfoParmO,pInfoParmI,0);
}

/****************************************/
/*	29									*/
/****************************************/
tdtInfoParm *cl_gx_copy_info(pInfoParmO,pInfoParmI)
tdtInfoParm *pInfoParmO, *pInfoParmI;
{
	return cl_gx_copy_info_opt(pInfoParmO,pInfoParmI,0);
}

/****************************************/
/*	37									*/
/****************************************/
/* 2022.9.18 */
static int _gx_rep_all_data(pInfoParmO,pInfoParmI,name,iOpt)
tdtInfoParm *pInfoParmO,*pInfoParmI;
char *name;
int iOpt;
{
	tdtInfoParm rInfoParmI;
	char id,c;
	int rc;

DEBUGOUTL1(110,"_gx_rep_all_data:Enter: name=[%s]",name);
DEBUGOUT_InfoParm(120,"_gx_rep_all_data:pInfoParmO: name=[%s]",pInfoParmO,name,0);
DEBUGOUT_InfoParm(120,"_gx_rep_all_data:pInfoParmI:",pInfoParmI,0,0);

	rInfoParmI = *pInfoParmI;
	rInfoParmI.pi_aux[0] = '\0';
	rInfoParmI.pi_scale &= ~D_DATA_INDEX_TMP;	/* add 2021.9.9 */
	if (rc=cl_gx_rep_info_set_ign(pInfoParmO,&rInfoParmI,1)) return rc;
	if (!name) name = "";
	else {
		if (*name=='<') name += D_LEN_SCOPE_MARK;
		if ((c=*name)=='$' || c=='%' || c=='#') name++;
	}
	pInfoParmO->pi_pos = (long)Strdup(name);
	pInfoParmO->pi_alen &= ~D_AULN_NO_AL_LPOS;
/*
printf("_gx_rep_all_data: id=[%c]\n",pInfoParmI->pi_id);
*/
DEBUGOUTL1(110,"_gx_rep_all_data:Exit rc=%d",rc);
	return rc;
}

/****************************************/
/*	41									*/
/****************************************/
static int _check_mk_key(pInfoParm,ppKey)
tdtInfoParm *pInfoParm;
char **ppKey;
{
	static char *p=NULL;
	int len,len2,n;
	char *key,*p1;

	key = pInfoParm->pi_data;
	if (ppKey) *ppKey = key;
	len = pInfoParm->pi_dlen;
	if (pInfoParm->pi_id == ' ' ) {
		p1 = NULL;
		if (pInfoParm->pi_attr != DEF_ZOK_CHAR) {
			if ((len=parm_to_char(pInfoParm,&p1,NULL)) < 0) return len;
			key = p1;
		}
	}
	else {
		len2 = len*2 + 1;
		if (p) p = Realloc(p,len2);
		else p = Malloc(len2);
		if (!p) return -1;
		n = akxcxtoc(key,len,p);
		*(p+n) = '\0';
		key = p;
		len = n;
	}
	if (ppKey) *ppKey = key;
/*
printf("_check_mk_key: key=[%s]\n",key);
*/
	return len;
}

/****************************************/
/*	42									*/
/****************************************/
static int _check_exist_mk_key(mcat,pInfoParm)
MCAT *mcat;
tdtInfoParm *pInfoParm;
{
	tdtInfoParm *pInfo;
	tdtRbCtl *pCt;
	int len,n;
	char c,*key;

	if ((c=pInfoParm->pi_id)=='L' || c=='N') {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		akxs_rb_read(pCt,0);
		while (pInfo=(tdtInfoParm *)akxs_rb_read(pCt,1)) {
			if ((len=_check_exist_mk_key(mcat,pInfo)) < 0) return len;
		}
	}
	else {
		if ((len=_check_mk_key(pInfoParm,&key)) < 0) return len;
		if (mcat->mc_ipos > 0) akxtmcatz(mcat,"`",1);
		akxtmcatz(mcat,key,len);
	}
	return 0;
}

/****************************************/
/*	43									*/
/****************************************/
static int _check_exist(xhpS,pInfoParm)
XHASHB *xhpS;
tdtInfoParm *pInfoParm;
{
	MCAT mcat;
	int len,n,ix;
	char *key;

	/* 2021.4.7 */
	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 256;
	if ((ix=_check_exist_mk_key(&mcat,pInfoParm)) < 0) return ix;
	key = mcat.mc_bufp;

	if (!(ix=akxs_xhash(xhpS,'R',key))) {
		if ((n=akxs_xhash(xhpS,'S',key))<0) ix = n;
		else if (!n) ix = -1;
	}
/*
printf("_check_exist: key=[%s] ix=%d\n",key,ix);
*/
	return ix;
}

/****************************************/
/*	44									*/
/****************************************/
static int _check_exist_all(xhpS,pInfoParm)
XHASHB *xhpS;
tdtInfoParm *pInfoParm;
{
	MCAT mcat;
	int n,ix;
	char *key;

	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 256;
	if ((ix=_check_exist_mk_key(&mcat,pInfoParm)) < 0) return ix;
	key = mcat.mc_bufp;
	if (!ix) {
		if (!(ix=akxs_xhash(xhpS,'R',key))) {
			if ((n=akxs_xhash(xhpS,'S',key))<0) ix = n;
			else if (!n) ix = -1;
		}
	}
/*
printf("_check_exist_all: key=[%s] ix=%d\n",key,ix);
*/
	if (key) Free(key);
	return ix;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_aux1_from_opt(opt)
int opt;
{
	int i,k;

	i = 0;
	if ((k=akxs_iseq_opt(ScopeGXOpts,D_MAX_SCOPE,opt,1)) > 0) i = ScopeAUX1s[k-1];
	return i;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_opt_from_aux1(i)
int i;
{
	int opt,k;

	opt = 0;
	if ((k=akxs_iseq_opt(ScopeAUX1s,D_MAX_SCOPE,i,1)) > 0) opt = ScopeGXOpts[k-1];
	return opt;
}

/****************************************/
/*										*/
/****************************************/
static char *cl_get_scope_from_opt(opt)
int opt;
{
	char *pp;
	int k;

	pp = "";
	if ((k=akxs_iseq_opt(ScopeGXOpts,D_MAX_SCOPE,opt,1)) > 0) pp = ScopeMarks[k-1];
	return pp;
}

/************************************/
/*	cl_get_def_scope				*/
/************************************/
int cl_get_def_scope(p)
char *p;
{
	int i,opt,k;

	i = opt = 0;
	if (k=akxs_seqr_str(ScopeNames,D_MAX_SCOPE,p,1)) i = k;
	else if (k=akxs_seqr_str(ScopeMarks,D_MAX_SCOPE,p,1)) i = k;
	if (i) opt = ScopeGXOpts[i-1];
/*
printf("cl_get_def_scope: p=[%s] opt=%08x\n",p,opt);
*/
	return opt;
}

/****************************************/
/*										*/
/****************************************/
char *cl_get_scope_name_from_opt(opt)
int opt;
{
	int k;
	char *pp;

	pp = "";
	if ((k=akxs_iseq_opt(ScopeGXOpts,D_MAX_SCOPE,opt,1)) > 0) pp = ScopeNames[k-1];
	return pp;
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_get_name_from_id(id)
char id;
{
	/* 2023.8.24 */
	return cl_get_variable_type(id);
}

/****************************************/
/*										*/
/****************************************/
char *cl_gx_get_name_from_info(pInfoParmW)
tdtInfoParm *pInfoParmW;
{
	char id,*nam;
	tdtInfoParm *pInfo;

	id = pInfoParmW->pi_id;
	if (id == ' ') {
		if (pInfoParmW->pi_aux[1] & D_AUX1_PROTECTED) {
			nam = FORMAT(302);
			return nam;
		}
	}
	else if (id == 'S') {
		if (!(pInfoParmW->pi_aux[1] & D_AUX1_POINTER)) {
			pInfo = (tdtInfoParm *)pInfoParmW->pi_pos;
			return cl_gx_get_name_from_info(pInfo);
		}
	}
	nam = cl_gx_get_name_from_id(id);
	return nam;
}

/************************************/
/* _get_gid							*/
/************************************/
int _get_gid(scrct,proc,opt)
ScrPrCT  *scrct;
ProcCT   *proc;
int      opt;
{
	int gid;

	gid = 0;
	if (opt & D_GX_OPT_SET_LOCAL) {
		if (!proc) proc = cl_search_proc_ct();
		if (proc) gid = proc->ProcGid;
	}
	else if (opt & D_GX_OPT_SET_PRIVATE) {
		if (!scrct) scrct = cl_search_src_ct();
		if (scrct) gid = scrct->ScrGid;
	}
	else if (opt & D_GX_OPT_SET_PUBLIC)
		gid = pCLprocTable->myGid;
	else if (opt & D_GX_OPT_SET_GLOBAL)
		gid = pGLprocTable->myGid;
	else {
		if (!proc) proc = cl_search_proc_ct();
		if (proc) gid = proc->ProcGid;
		else {
			if (!scrct) scrct = cl_search_src_ct();
			if (scrct) gid = scrct->ScrGid;
		}
	}
DEBUGOUTL4(170,"_get_gid: scrct=%08x proc=%08x opt=%08x gid=%d",scrct,proc,opt,gid);
	return gid;
}

/************************************/
/*	cl_set_parm_init				*/
/************************************/
int cl_set_parm_init(pInfoParm,iParm,opt)
tdtInfoParm *pInfoParm;
int iParm[],opt;
{
	int rc,attr,size,im,iRANGE;
	char *p;

	size = iParm[1];
	/* iParm[0]�ɂ́A21,22,23 �������ČĂ΂�邱�Ƃ�����̂ŁADEF_ZOK_MASK�Ń}�X�N�ł��Ȃ� */
	switch (attr=iParm[0]) {
		case 0:					/* add 2021.12.31 */
		case DEF_ZOK_VARI:
			rc = cl_parm_set0(pInfoParm);
			break;
		case DEF_ZOK_CHAR:
			rc = cl_set_parm_char(pInfoParm,NULL,0);
			break;
		case DEF_ZOK_BINA:
			rc = cl_set_parm_bin(pInfoParm,0);
			pInfoParm->pi_dlen = size;	/* add 2023.5.5 */
			if (iParm[3] == DEF_ZOK_USMASK) pInfoParm->pi_scale |= D_DATA_UNSIGNED;
			break;
		case DEF_ZOK_FLOA:
			rc = cl_set_parm_double(pInfoParm,0.0);
			break;
		case DEF_ZOK_BULK:
			rc = cl_set_parm_char(pInfoParm,NULL,0);
			pInfoParm->pi_attr = attr;
			break;
		default:
			rc = -100;
	}
/*
printf("cl_set_parm_init: attr=%d size=%d\n",attr,size);
*/
	if ((opt & 0x01) && attr && (attr!=DEF_ZOK_VARI) && !rc) {
		pInfoParm->pi_len = size;
		pInfoParm->pi_aux[0] = attr;
		iRANGE = opt & (D_AULN_RANGE_DATA | D_AULN_COMPLEX_DATA);
		if ((attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) ||
		    (attr==DEF_ZOK_FLOA && iRANGE)) {
			if (attr == DEF_ZOK_CHAR) size++;
			else if (attr == DEF_ZOK_BULK) size += sizeof(int);
			im = (opt & D_GX_OPT_ALC_MASK)>>12;
			if (!im) im = D_OPT_ALC_MALLOC;
			if (im & (D_OPT_ALC_TMP | D_OPT_ALC_MALLOC)) {
				if (iRANGE) size += size;
				if (p = cl_opt_malloc(im,size)) {
					if ((attr==DEF_ZOK_DECI || attr==DEF_ZOK_DATE) && pInfoParm->pi_data)
						memcpy(p,pInfoParm->pi_data,size);
					else memset(p,0,size);
					if (im == D_OPT_ALC_MALLOC) pInfoParm->pi_scale |= D_DATA_MALLOC;
				}
				else rc = -1;
/*
if (attr==4) {
if (p) m_print_debug("cl_set_parm_init",p,0);
else printf("cl_set_parm_init: rc=%d\n",rc);
}
*/
				pInfoParm->pi_data = p;
				pInfoParm->pi_scale &= ~D_DATA_LPOSDATA;
			}
			else rc = -1;
		}
		pInfoParm->pi_paux = pInfoParm->pi_data;
	}
DEBUGOUT_InfoParm(151,"cl_set_parm_init: attr=%d rc=%d",pInfoParm,attr,rc);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_storevar_ex_obj(pInfoParmW,pInfoParm,opt_set,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm,*pInfoParm1,*pInfoParm2;
int opt_set;	/* 0x01: pInfoParm->pi_aux[1], 0x02: D_AUX1_POINTER */
				/* 0x10: no check D_AUX1_POINTER	*/
{
	tdtInfoParm *pInfoParm3;

	if (!(opt_set & 0x10) &&
	    pInfoParm->pi_id==D_DATA_ID_STOREVAR && (pInfoParm->pi_aux[1] & D_AUX1_POINTER)) {
		cl_gx_copy_info(pInfoParmW,pInfoParm);
	}
	else {
		if (pInfoParm==pInfoParm1 || pInfoParm==pInfoParm2) {
			if (!(pInfoParm3=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
		/*	*pInfoParm3 = *pInfoParm;	*/
			cl_gx_copy_info(pInfoParm3,pInfoParm);

DEBUGOUTL4(LVL_GXEXOBJ+1,"cl_set_storevar_ex_obj: pInfoParm3=%08x pInfoParm =%08x pInfoParm1=%08x pInfoParm2=%08x",pInfoParm3,pInfoParm,pInfoParm1,pInfoParm2);

		}
		else pInfoParm3 = pInfoParm;
		cl_set_parm_long(pInfoParmW,(long)pInfoParm3);
		pInfoParmW->pi_id = D_DATA_ID_STOREVAR;
		if (opt_set & 0x01) pInfoParmW->pi_aux[1] = pInfoParm->pi_aux[1];
		if (opt_set & 0x02) pInfoParmW->pi_aux[1] |= D_AUX1_POINTER | D_AUX1_PROTECTED;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_storevar(pInfoParmW,pInfoParm,opt_set)
tdtInfoParm *pInfoParmW,*pInfoParm;
int opt_set;	/* 0x01: set pInfoParm->pi_aux[1]	*/
				/* 0x02: set D_AUX1_POINTER			*/
				/* 0x10: no check D_AUX1_POINTER	*/
{
	return cl_set_storevar_ex_obj(pInfoParmW,pInfoParm,opt_set,NULL,NULL);
}
