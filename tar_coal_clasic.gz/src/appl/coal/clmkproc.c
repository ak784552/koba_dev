static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int        cl_mk_lk_proc_ct             */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*  �n���ꂽ�v���V�[�W���e�[�u���������P�[�W���� */
/* --------------------------------------------- */
/*************************************************/
/* */
#include "colmn.h"          /* �萔��` */

extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;

ProcCT *cl_mk_lk_proc_ct()
{
	ScrPrCT *Dummy;
	ProcCT  *ProRoot;

	if (pCLprocTable->PrCTp == NULL) {
		return NULL;
	}
	else {
#ifdef PROC_NO_FREE	/* 2021.2.5 */
		if (!(ProRoot=cl_mk_pr_push())) return NULL;
#else
		if (!(ProRoot=cl_mk_pr_make())) return NULL;
		if (cl_mk_pr_push(ProRoot)) return NULL;
#endif
		cl_tmp_const_ct_set(ProRoot->pTmpConstCt);
		pCLprocTable->CurProc = ProRoot;
		Dummy = cl_search_src_ct();
		Dummy->CurProc = ProRoot;

		ProRoot->ProcGid = ++pGLprocTable->gid;
		akxs_xhasl(pGLprocTable->pha_gid,'S',ProRoot->ProcGid,0);
	}

	return ProRoot;
}

/*************************************************/
/*  Program name                                 */
/*       leaf      *cl_mk_pr_make                */
/* --------------------------------------------- */
/*  Function :                                   */
/* --------------------------------------------- */
/*************************************************/
/* */
ProcCT *cl_mk_pr_make()
{
	ProcCT  *Dummy;
	int len,*pSize;

	Dummy = (ProcCT *)Malloc(sizeof(ProcCT));
	if (Dummy == NULL) return NULL;

	memset(Dummy,0,sizeof(ProcCT));
	Dummy->pRetStack = akxs_rb_new(0,0);
	Dummy->pTmpConstCt = cl_const_ct_new();
#if 1	/* 2022.5.21 */
	Dummy->redirect = (tdtREDIRECT *)Malloc(sizeof(tdtREDIRECT));
	memset(Dummy->redirect,0,sizeof(tdtREDIRECT));
#endif

	return Dummy;
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_mk_pr_push                */
/* --------------------------------------------- */
/*  Function :                                   */
/*************************************************/
#ifdef PROC_NO_FREE	/* 2021.2.5 */
ProcCT *cl_mk_pr_push()
{
	ScrPrCT  *Dummy;
	ProcCT   *Temp,*ProRoot;

	ProRoot = NULL;
	if (Dummy = cl_search_src_ct()) {
		if (Temp = cl_search_proc_ct()) {
			if (ProRoot=Temp->nextPCT) {
				cl_mk_pr_init(ProRoot);
			}
			else {
				if (ProRoot = cl_mk_pr_make()) {
					ProRoot->prePCT = Temp;
					Temp->nextPCT = ProRoot;
				}
			}
		}
		else {
			ProRoot = cl_mk_pr_make();
			Dummy->ProCT = ProRoot;
		}
	}
	return ProRoot;
#else
int cl_mk_pr_push(ProRoot)
ProcCT  *ProRoot;
{
	ScrPrCT  *Dummy;
	ProcCT   *Temp;
	int rc;

	if (ProRoot==NULL) return(-1);
	Dummy = pCLprocTable->PrCTp;
	for(;;) {
		if (Dummy->nextScCT == (ScrPrCT *)NULL) {
			Temp = Dummy->ProCT;
			if (Temp == (ProcCT *)NULL) {
				Dummy->ProCT = ProRoot;
				break;
			}
			else {
				for(;;) {
					if (Temp->nextPCT == (ProcCT *)NULL) {
						ProRoot->prePCT = Temp;
						Temp->nextPCT = ProRoot;
						break;
					}
					Temp = Temp->nextPCT;
				}
				break;
			}
		}
		Dummy = Dummy->nextScCT;
	}
	return 0;
#endif
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_mk_pr_var_set             */
/* --------------------------------------------- */
/*  Function :                                   */
/*************************************************/
int cl_mk_pr_var_set(proc)
ProcCT  *proc;
{
	int *pSize,len;
	tdtInfoParm ***pDummy ;
	XHASHB *xha;
#if 0
	if (!proc->pTBL_pasento) {
		pSize = (int *)Malloc(cl_var_size_len(0));
		if (!pSize) goto Err;

		len = sizeof(tdtInfoParm **)*(MAX_PAS_IX+1);
		pDummy = (tdtInfoParm ***)Malloc(len);
		if (!pDummy) goto Err;

		memset(pDummy,0,len);
		proc->pTBL_pasento = pDummy;

		proc->pTBL_pasento[0] = (tdtInfoParm **)pSize;
		cl_var_set_size(pSize,MAX_PAS_IX,MAX_PAS_IY,"LPA");
	}
	return 0;
 Err:
#else
	if (!proc->pha_vnam) {
		xha = akxs_xhash_new2(0,MAX_LVR_IY,0,sizeof(tdtInfoParm));
		proc->pha_vnam = xha;

		pSize = (int *)Malloc(cl_var_size_len(0)*2);
		if (!pSize) goto Err;

#if 1
		len = sizeof(tdtInfoParm **)*(MAX_PAS_IX+1);
#else
		len = sizeof(tdtInfoParm **)*((MAX_LVR_IX+1)+(MAX_PAS_IX+1));
#endif
		pDummy = (tdtInfoParm ***)Malloc(len);
		if (!pDummy) goto Err;

		memset(pDummy,0,len);
#if 1
		proc->pTBL_pasento = pDummy;
#else

		proc->pTBL_vnam    = pDummy;
		proc->pTBL_pasento = proc->pTBL_vnam + MAX_LVR_IX+1;
#endif
/*
DEBUGOUT2("cl_mk_pr_var_set: proc->pTBL_vnam=%08x proc->pTBL_pasento=%08x",
proc->pTBL_vnam,proc->pTBL_pasento);
*/
#if 0
		proc->pTBL_vnam[0] = (tdtInfoParm **)pSize;
		pSize = cl_var_set_size(pSize,MAX_LVR_IX,MAX_LVR_IY,"LVN");
#endif
		proc->pTBL_pasento[0] = (tdtInfoParm **)pSize;
		cl_var_set_size(pSize,MAX_PAS_IX,MAX_PAS_IY,"LPA");
	}
	return 0;
 Err:
	if (proc->pha_vnam) {
		akxs_xhash_free(proc->pha_vnam);
		proc->pha_vnam = NULL;
	}
#endif
	if (pSize) Free(pSize);
	return -1;
}

#ifdef PROC_NO_FREE	/* 2021.2.5 */
/*************************************************/
/*  Program name                                 */
/*       int        cl_mk_pr_init                */
/* --------------------------------------------- */
/*  Function :                                   */
/*************************************************/
int cl_mk_pr_init(proc)
ProcCT *proc;
{
	int rc;

	rc = 0;
	if (proc) {
		akxs_rb_buf_free(proc->pRetStack);
		akxm_cct_reset(proc->pTmpConstCt);
		akxs_xhash_reset(proc->pha_vnam);
		cl_reset_var_ent(proc->pTBL_vnam);
		cl_reset_var_ent(proc->pTBL_pasento);
		proc->ProcGid = ++pGLprocTable->gid;
		akxs_xhasl(pGLprocTable->pha_gid,'S',proc->ProcGid,0);
	}
	else rc = -1;
	return rc;
}
#endif
/****************************************************/
/*	Program name									*/
/*		tdtObjHead *cl_mk_add_obj0					*/
/* ------------------------------------------------ */
/*	Function :										*/
/*	���� : ObjH     : 								*/
/*		   add_obj0 : ObjH=NULL�̂Ƃ�(Proc�J�n��)�� */
/*					  �O���used������				*/
/****************************************************/
tdtObjHead *cl_mk_add_obj0(ObjH,add_obj0)
tdtObjHead *ObjH;
int add_obj0;
{
	int i,m,alsize;
	tdtInfoParm **ppObj0,*pObj0,**Obj0,*pInfo;
	tdtObjHead *Obj;
/*
printf("cl_mk_add_obj0:Enter ObjH=%08x add_obj0=%d\n",ObjH,add_obj0);
*/
	if (add_obj0 <= 0) add_obj0 = MAX_CMD_OBJ0;
	if (Obj=ObjH) {
		alsize = Obj->alsz;
		ppObj0 = Obj->Obj0;
		pInfo = ppObj0[0];
	}
	else {
		if (!(Obj=(tdtObjHead *)Malloc(sizeof(tdtObjHead)))) return NULL;
		Obj->used = 0;	/* Proc�̊J�n���́A0 ����n�܂� */
		alsize = 0;
		ppObj0 = NULL;
		pInfo = NULL;
	}
	Obj->alsz = m = alsize + add_obj0;

DEBUGOUTL3(158,"cl_mk_add_obj0: Obj=%08x ppObj0=%08x pInfo=%08x",Obj,ppObj0,pInfo);
DEBUGOUTL4(158,"cl_mk_add_obj0: alsize=%d add_obj0=%d m=%d used=%d",alsize,add_obj0,m,Obj->used);
/*
printf("cl_mk_add_obj0: Obj=%08x alsize=%d add_obj0=%d m=%d used=%d\n",Obj,alsize,add_obj0,m,Obj->used);
*/
	if (!(ppObj0=(tdtInfoParm **)MRealloc(ppObj0,sizeof(tdtInfoParm *)*m))) return NULL;
	if (!(pObj0 =(tdtInfoParm *)MRealloc(pInfo,sizeof(tdtInfoParm)*m))) {
		Free(ppObj0);
		return NULL;
	}
	memset(pObj0+alsize,0,sizeof(tdtInfoParm)*add_obj0);
	if (Obj->used > 0) {
		pInfo = pObj0;
		for (i=0;i<Obj->used;i++) {
			if (pInfo->pi_scale & D_DATA_LPOSDATA) {
				pInfo->pi_data = (char *)&pInfo->pi_pos;
DEBUGOUT_InfoParm(161,"cl_mk_add_obj0: i=%d",pInfo,i,0);
			}
			pInfo++;
		}
	}
DEBUGOUTL3(158,"cl_mk_add_obj0: Obj=%08x ppObj0=%08x pObj0=%08x",Obj,ppObj0,pObj0);
	Obj->Obj0 = ppObj0;
	for (i=0;i<m;i++) {
		*ppObj0++ = pObj0++;
	}
	return Obj;
}

/************************************************/
/*	Program name								*/
/*		tdtObjHead *cl_mk_obj0					*/
/* -------------------------------------------- */
/*	Function :									*/
/*	���� : used		: �O���used������			*/
/************************************************/
tdtObjHead *cl_mk_obj0(used,max_obj0)
int used,max_obj0;
{
	tdtObjHead *Obj;

	if (used > max_obj0) max_obj0 = used;
	if (Obj = cl_mk_add_obj0(NULL,max_obj0)) {
#if 1	/* 2021.7.11 Proc�̊J�n���́AObj->used=0 ����n�܂� *//* 2021.7.16 0-->1 */
		Obj->used = max_obj0;
DEBUGOUTL2(158,"cl_mk_obj0: Obj=%08x used=%d",Obj,max_obj0);
#endif
/*
printf("cl_mk_obj0: Obj=%08x used=%d\n",Obj,max_obj0);
*/
	}
	return Obj;
}
