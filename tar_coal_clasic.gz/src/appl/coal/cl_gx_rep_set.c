static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �������                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_rep_set( pparmList , ppmList )               *
*                      (O)parmList  *pparmList                                *
*                      (I)prmList  *pprmList                                  *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern int giOptions[];
extern GlobalCt  *pGlobTable;
extern tdtIterate_ctl gtIter_ctl[];

static int _array_hash_clr();
static int _list_array_set();

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_set(pparmList ,pInfoParm)
parmList  *pparmList;
tdtInfoParm *pInfoParm;
{
	int		rc;
	ScrPrCT *pSPCT;
	tdtInfoParm *pInfoParmW;

	pSPCT = cl_search_src_ct();

	if (rc= cl_gx_get_info_parm(pSPCT,'s',pparmList,&pInfoParmW)) {
		return rc;
	}
	/* 2021.10.27 */
	return cl_gx_rep_info_als(pInfoParmW ,pInfoParm ,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_set_global( pparmList ,pInfoParm )
parmList  *pparmList;
tdtInfoParm *pInfoParm;
{
	/* %s: %s�ɂ͑���ł��܂���B */
	ERROROUT2(FORMAT(126),"cl_gx_rep_set_global",pparmList->prp);
	return ECL_SCRIPT_ERROR;
}

/****************************************/
/*										*/
/****************************************/
int _get_num_msg_no(pInfoParm,msg_no,opt,pix0)
tdtInfoParm *pInfoParm;
int msg_no,opt,*pix0;
{
	int iRc,ix0;

	iRc = -1;
	ix0 = 0;
	if (msg_no <= 0) msg_no = 577;	/* (%d)���s���ł��B */
	if (pInfoParm && pix0) {
		iRc = 0;
		if (pInfoParm->pi_dlen > 0) {
			if (iRc = cl_get_parm_bin(pInfoParm,&ix0,"_get_start_pos.ix0:")) return iRc;
			if (ix0 < 0) {
				ERROROUT1(FORMAT(msg_no),ix0);	/* �E�E�E(%d)���s���ł��B */
				iRc = -1;
			}
		}
		else if (opt & 0x01) iRc = C_NULL_PARM;
		*pix0 = ix0;
	}
/*
printf("_get_num_msg_no: ix0=%d iRc=%d\n",ix0,iRc);
*/
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info(nparm,ppParm,pIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	iRc = _get_array_info_ref(nparm,ppParm,&pIndexW,ppTBL,iParm,opt);
	if (!iRc || iRc==2000) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********7*/
/*	����: nparm    : ppParm�̐� (>=2)						*/
/*		  ppParm   : tdtInfoParm�̃|�C���^�z��				*/
/*						ppParm[0] : ���ׂ�Ώ�				*/
/*						ppParm[1] : �J�n�ʒu				*/
/*						ppParm[2]�ڍs�͔C��					*/
/*		  ppIndex  : �z�����Ԃ�							*/
/*					 *ppIndex �ɂ́A&tIndex ���ݒ肳���	*/
/*						���邱��(�㏑������Ȃ�)			*/
/*					 *ppIndex �ɂ́AA or R �̂Ƃ��A�z���	*/
/*						pIndex���Ԃ����(�㏑�������)		*/
/*		  ppTBL    : <>NULL�̂Ƃ��A							*/
/*					 MappIndex(A)�̔z���ւ̃|�C���^���Ԃ�	*/
/*					 A�łȂ��Ƃ��́ANULL��Ԃ�				*/
/*		  iParm    : <>NULL�̂Ƃ��Aindex����Ԃ��z��		*/
/*					 iParm[0] : �J�n�ʒu(nparm<=1�̂Ƃ���0)	*/
/*					 iParm[1] : �ő�v�f�� - �J�n�ʒu		*/
/*					 iParm[2] : off_set + �J�n�ʒu			*/
/*					 iParm[3] : �J�n�ʒu����ݒ�ςݗv�f��	*/
/*								 �ő�ʒu�܂ł̗v�f��		*/
/*		  opt      : �I�v�V����								*/
/*						0x01 : �n�b�V���z����G���[�Ƃ��Ȃ�	*/
/*						0x02 : %��#�̔z����G���[�Ƃ���		*/
/* �ԋp : 0   : ����										*/
/*		  200 : �n�b�V���z��								*/
/*		  <0  : �G���[										*/
/************************************************************/
int _get_array_info_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtInfoParm *pInfoParm;
	int iRc,ix0,*index;
	XHASHB *xhp;
	tdtArrayIndex *pIndex;

	if (nparm<=0 || !ppParm || !ppIndex) return -1;
	pInfoParm = ppParm[0];
	if (opt & 0x02) {
		if (iRc = cl_check_use_mapped_array(pInfoParm)) return iRc;
	}
	pIndex = *ppIndex;
/*
printf("_get_array_info_ref:1 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	if (iRc = cl_get_array_info_ref(pInfoParm,ppIndex,ppTBL,iParm)) return iRc;
	pIndex = *ppIndex;
/*
printf("_get_array_info_ref:2 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	if ((opt & 0x01) && pIndex->xhp) {
		if (iParm) iParm[0] = 0;		/* �J�n�ʒu */
		return 2000;
	}

	ix0 = 0;
	if (nparm >= 2) {
		if (iRc = _get_num_msg_no(ppParm[1],222,0,&ix0)) return iRc;
	}
/*
printf("_get_array_info_ref:3 ix0=%d iParm[1]..[3]=%d %d %d\n",ix0,iParm[1],iParm[2],iParm[3]);
*/
	if (iParm) {
		iParm[0] = ix0;		/* �J�n�ʒu */
		iParm[1] -= ix0;	/* �ő�v�f�� - �J�n�ʒu */
		iParm[3] = iParm[3] - iParm[2] + 1 - ix0;	/* �J�n�ʒu����ݒ�ςݗv�f�̐擪����̍ő�ʒu�܂ł̗v�f�� */
		iParm[2] += ix0;	/* off_set + �J�n�ʒu */
	}
/*
printf("_get_array_info_ref:4 ix0=%d iParm[1]..[3]=%d %d %d\n",ix0,iParm[1],iParm[2],iParm[3]);
*/
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info_used_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtInfoParm ***pTBL,*pInfoParm;
	int iRc,*pSize;
	char c;

	if (iRc = _get_array_info_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)) return iRc;
	pInfoParm = ppParm[0];
	c = pInfoParm->pi_id;
/*
printf("_get_array_info_used: c=[%c] iParm[0]..[3] =%d %d %d %d\n",c,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
	if (c!='R' && c!='A') {
		if (ppTBL) {
			pTBL = *ppTBL;
			pSize = (int *)pTBL[0];
			iParm[3] = pSize[7] - (iParm[2] - 1);	/* 6-->7 2020.4.30 *//* 1-->3 2021.5.9 */
		}
	}
DEBUGOUTL4(194,"_get_array_info_used: iParm[0]..[3] =%d %d %d %d",iParm[0],iParm[1],iParm[2],iParm[3]);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info_used(nparm,ppParm,pIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	iRc = _get_array_info_used_ref(nparm,ppParm,&pIndexW,ppTBL,iParm,opt);
	if (!iRc || iRc==2000) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _get_array_num(nparm,ppParm,nm1,pNum)
int  nparm;
tdtInfoParm *ppParm[];
int nm1,*pNum;
{
	tdtInfoParm *pInfoParm;
	int nm,iRc;

	nm = nm1;
/*
printf("_get_array_num: nparm=%d nm1=%d nm=%d\n",nparm,nm1,nm);
*/
	if (nparm >= 1) {
		if ((iRc=_get_num_msg_no(ppParm[0],223,0x01,&nm)) == C_NULL_PARM) nm = nm1;
		else if (iRc) return iRc;
		else if (nm1>0 && nm>nm1) {
			if (cl_get_option(22,0) & 0x01) {
					/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
				ERROROUT2(FORMAT(224),nm,nm1);
			}
			nm = nm1;
		}
	}
	*pNum = nm;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_array_ix(pWork,nparm,ppParm,s_ix)
char *pWork;
int  nparm,s_ix;
tdtInfoParm *ppParm[];
{
	static char *_fn_="cl_set_array";
	tdtInfoParm *pInfoParm,*pInfoParmW,tInfoParm,**ppParmW,*pInfoP;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix0,ix,nm,count,len,attr,nset,ii,type,iCOMPLEX,num,ii_s;
	char c,*name,*p1;
	tdtArrayIndex *pIndex,tIndex;
	int *index,iParm[4];
	tdtDefType *pDeftype;

	if (s_ix < 0) s_ix = 0;
	nm = 0;
	memcpy(pWork,&nm,sizeof(int));

#if 1	/* 2023.12.17 */
	nm = nparm - 1;
#else
	nm = nparm - 2;
#endif
	pIndex = &tIndex;

DEBUGOUTL4(170,"%s:Enter pIndex=%08x Index=%08x",_fn_,nm,pIndex,pIndex->index);

	/* 2023.12.17 */
	iRc = _get_array_info_ref(1,ppParm,&pIndex,&pTBL,iParm,3);
	if (iRc) return iRc;

DEBUGOUTL5(194,"%s: iParm=%d %d %d %d",_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);

	iCOMPLEX = ppParm[0]->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA);
/*
printf("%s: iCOMPLEX=%08x\n",_fn_,iCOMPLEX);
*/
	ix0 = iParm[0];
	ix  = iParm[2];
	n = 1;
	attr = pIndex->uAttr[0];
	pInfoP = pIndex->pInfoType;

DEBUGOUT_InfoParm(194,"cl_set_array: attr=%d pInfoP=",pInfoP,attr,0);

	if (pInfoP) n = 0;
	else if ((!attr || attr==DEF_ZOK_VARI) && !pInfoP) {
#if 1	/* 2023.10.17 */
		nset = iParm[3] + s_ix;
#else
		nset = iParm[3] - iParm[2] + 1;
#endif
		nset -= s_ix;
		for (i=0;i<nset;i++,ix++) {
			pInfoParmW = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'r');
			if (pInfoParmW) {
				if ((c=pInfoParmW->pi_id)=='T' || c=='R' || c=='A') {
					n = 0;
					break;
				}
			}
		}
		ix  = iParm[2] + s_ix;
	}
	if (n && nm>iParm[1]-s_ix) {
		if (cl_get_option(22,0) & 0x01) {
				/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
			ERROROUT2(FORMAT(224),nm,iParm[1]);
		}
		nm = iParm[1];
	}
/*
printf("%s:2 pIndex=%08x Index=%08x\n",_fn_,pIndex,pIndex->index);
*/
DEBUGOUTL4(194,"%s: n=%d nm=%d ix=%d",_fn_,n,nm,ix);
/*
printf("%s: n=%d nm=%d ix=%d\n",_fn_,n,nm,ix);
*/
	num = count = ii = 0;
	for (i=count=0;i<iParm[1];i++,ix++) {
		if (ii >= nm) break;
		ii_s = ii + 1;
		pInfoParmW = cl_get_array_and_var_ent(pIndex,pTBL,ix);
		if (pInfoParmW) {
			num++;
			pInfoParmW->pi_alen |= iCOMPLEX;
#if 1	/* 2022.12.07 */
			if (pInfoP) {
#else
			if (pInfoP && !pInfoParmW->pi_id) {
#endif
				if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoP,1)) return iRc;
				type = pInfoP->pi_aux[0];
/*
printf("cl_set_array: i=%d type=%d\n",i,type);
*/
				pInfoParmW->pi_hlen = ppParm[0]->pi_hlen;	/* add 2021.3.30 */
			}
/*
printf("cl_set_array: nm=%d i=%d ii=%d id=[%c]\n",nm,i,ii,pInfoParmW->pi_id);
*/
				pInfoParm = ppParm[ii_s];
				if (!cl_is_null_parm(pInfoParm)) {
					if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
					count++;
				}
				ii++;
		}
		else {
			return -1;
		}
	}

DEBUGOUTL3(194,"%s: num=%d count=%d",_fn_,num,count);

	/* 2023.10.22 */
	cl_set_max_array_index(pIndex,0,num);
#if 1	/* 2023.12.18 */
	/* �z�񂪃}�b�v����Ă���Ƃ��́A���̔z��̍ő�ݒ�ʒu���X�V���� */
	cl_update_map_array_max(ppParm[0]);
#endif
	memcpy(pWork,&count,sizeof(int));

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_array(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	return cl_set_array_ix(pWork,nparm,ppParm,0);
}

/****************************************/
/*										*/
/****************************************/
tdtRbCtl *cl_tmp_rb_new(lBS,lRM,pConstCt)
long lBS,lRM;
ConstantCt *pConstCt;
{
	char *(*m_alloc)();

	if (pConstCt) m_alloc = cl_const_ct_malloc;
	else  m_alloc = cl_tmp_const_malloc;
/*
printf("cl_tmp_rb_new: m_alloc=%08x pConstCt=%08x\n",m_alloc,pConstCt);
*/
	return akxs_rb_new2(lBS,lRM,m_alloc,pConstCt);
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_rbset_n(pCt, addr)
tdtRbCtl *pCt;
char *addr;
{
	return akxs_rb_set_n(pCt, addr);
}
