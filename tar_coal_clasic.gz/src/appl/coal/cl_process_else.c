static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************/
/*																		*/
/*	�����ړI	�F �d�k�r�d�R�}���h���C��								*/
/*																		*/
/*	�֐���		�F int cl_process_else(pLeaf, pProc)					*/
/*																		*/
/*	������		�F (I)Leaf		: * pLeaf								*/
/*				   (I)ProcCT	: * pProc								*/
/*																		*/
/*	�߂�l		�F ERROR												*/
/*				   NORMAL												*/
/*																		*/
/*	�����T�v	�F														*/
/*																		*/
/************************************************************************/

#include "colmn.h"
#define NEORET

extern GlobalCt *pGlobTable;

int cl_process_else(pLeaf, pProc)
Leaf   *pLeaf;
ProcCT *pProc;
{
	int rc;
	char buf[32];
	int id;
	BlockCB *pIfCB;
	BlockCB *pBlockCB;

DEBUGOUTL1(110,"cl_process_else: Enter pProc=%08x",pProc);

	if (!(pIfCB = pProc->pcrBlockCB)) return -1;
	id = pIfCB->cid;
	if (id == C_IF) ;
	else return -1;

	if( pIfCB->ElseFlag == L_ON ) {
		if (cl_get_cmd_name(pLeaf->cmd.cid,buf)) return -2;
		ERROROUT1(FORMAT(366),buf);	/* %s���d�����Ă��܂��B */
		return ECL_EX_ELSE;
	}

	/* �d�k�r�d�R�}���h�t���O���I�� */
	pIfCB->ElseFlag = L_ON;

	/* 2017.03.18 */
	id = pLeaf->cmd.cid;
	if (id==C_ELSE && pIfCB->TureFlag!=L_ON) {
	/*	pIfCB->iUsed = D_SWITCH_DEFAULT;	*//* Add 2017.3.25 */
		pIfCB->Blockleaf = pLeaf->rightleaf;	/* Add 2017.3.25 */
		pProc->Nextleaf = pLeaf->leftleaf;
		cl_ret_leaf_push(pProc,pLeaf->rightleaf);
	}
	else {
		pProc->Nextleaf = pLeaf->rightleaf;
	}

	return 0;
}
