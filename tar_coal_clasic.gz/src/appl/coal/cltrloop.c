static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_loop                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Justify no shori.                         */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/********************************************/
/*											*/
/********************************************/
int col_mn_tr_loop(y)
condList *y;
{
	static char *_fn="col_mn_tr_loop";
	int rc,len,n,i,pnum,cid,scno;
	char *name,*pnm;
	cmdInfo *cmd;
	parmList **prmL;

	cmd = y->cmd;
	cid = cmd->cid;
	prmL = cmd->prmp;
	pnum = cmd->prmnum;
	if (pnum > 0)
		pnm = prmL[0]->prp;
	else pnm = "";

	scno = 0;
	if (scno < 0) {
		ERROROUT1(FORMAT(42),_fn);
		return  ECL_TR_LOOP;
	}
	cmd->sub_cid |= scno;

	if (!(rc=cl_make_leaf(y))) {
		cl_pre_nest(y);
		if (!(rc=cl_push(y))) rc= cl_change_stcb(y);
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_tr_insert(y,ip,name)
condList *y;
int ip;
char *name;
{
	int rc,len,n,i,num;
	cmdInfo *cmd;

	cmd = y->cmd;
	num = cmd->prmnum;
	if (ip<num && num<y->max_prmnum) {
		for (i=num;i>ip;i--) cmd->prmp[i] = cmd->prmp[i-1];
		cmd->prmnum = ip;
		if (rc=clparmset(y,name,strlen(name))) return rc;
		n = cmd->prmnum = num + 1;
	}
	else n = 0;
	return n;
}

int cl_search_active_loop(y)
condList *y;
{
	Leaf  *Dummy;
	CLNCB *p;

	p = y->clstcb;
	if (!(Dummy = p->nestLev2)) return 0;
	while (Dummy) {

		if ( Dummy == p->nestLev1 ||
		    (Dummy->cmd.type == 0 && Dummy->cmd.cid == C_LOOP) )
			return ( 0 );
	/*
		else if ( Dummy->cmd.cid == C_LOOP ) return ( -2 );
	*/
		Dummy = Dummy->preleaf;
	}
	return -1;
}
