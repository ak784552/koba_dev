static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�����[�^�ϊ�                                         *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_parm( pparmList , pInfoParm )              *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtInfoParm	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern int giOptions[];
extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;
extern GlobalCt  *pGlobTable;

static long lnull = 0;

/****************************************/
/*										*/
/****************************************/
static int _set_nest_var_name(pparmList, pInfoParm)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
{
	int ret,vnlen;
	char *p,*vname;

	if (pInfoParm->pi_scale & D_DATA_ARRAY_INDEX) {	/* 0x10 */
		if (!(p=(char *)pInfoParm->pi_pos)) return ECL_SYSTEM_ERROR;
/*
printf("_set_nest_var_name: p=[%s] vnlen=%d vname=[%s]\n",
p,pparmList->prmlen,pparmList->prp);
*/
		if ((vnlen=pparmList->prmlen-strlen(p)-1) <= 0) return ECL_SYSTEM_ERROR;
		vname = pparmList->prp;
		if (!(p=cl_tmp_const_malloc(vnlen+Var_NM_MAX*2+1))) {
			ERROROUT("_set_nest_var_name: nest var name area malloc");
			return ECL_SYSTEM_ERROR;
		}
		strnzcpy(p,vname,vnlen);
		pInfoParm->pi_pos = (long)p;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_conv_parm(pparmList, pInfoParm)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
{
	return cl_conv_parm_opt(pparmList, pInfoParm, 0);
}

/****************************************/
/*										*/
/****************************************/
int cl_conv_parm_opt(pparmList, pInfoParm, opti)
parmList   *pparmList;
tdtInfoParm *pInfoParm;
int opti;
{
	int	rc, alclen, opt, ret;
	int ParmNo;
	tdtInfoParm *pInfoParmW;
	ScrPrCT     *pScCT;
	char op,c,*p;
	ParList par_pSize;

	if (!pparmList) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return( ECL_SYSTEM_ERROR );
	}
	if (!pparmList->prp) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return( ECL_SYSTEM_ERROR );
	}
	if (!pInfoParm) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}

DEBUGOUTL2(194,"--->cl_conv_parm_op: pparmList->prp=[%s] opti=%08x",pparmList->prp,opti);

	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pScCT = cl_search_src_ct();
	opt = opti & D_GX_OPT_STORE;
	if (opt) op = 's';
	else {
		if (opti & D_GX_OPT_NOEROUT_NDEF) op = 'R';
		else op = 'r';
	}
	rc = cl_gx_get_info_parm_opt_psize(pScCT,op,pparmList,&pInfoParmW,opti,&par_pSize);

DEBUGOUT_InfoParm(194,"cl_conv_parm_opt:<---cl_gx_get_info_parm_opt_psize opt=%d rc=%d",
pInfoParmW,opt,rc);

	if (rc) {
		if (rc == ECL_DEFINED_ARRAY) {
			if (!pInfoParmW) return -1;
			if (ret=_set_nest_var_name(pparmList,pInfoParmW)) return ret;
		}
		else return rc;
	}
	if (opt || (opti & D_GX_OPT_SET_ADDR)) {
		if (pInfoParmW->pi_id != 'S')
			cl_set_storevar(pInfoParm,pInfoParmW,1);
		else
			cl_gx_copy_info(pInfoParm,pInfoParmW);
		if (!(pInfoParm->pi_aux[1] & D_AUX1_POINTER)) {	/* add 2023.5.13 */
			/* 2024.02.23 */
			cl_set_pSize_index(pInfoParm,par_pSize.par,NULL,par_pSize.parlen,pInfoParmW->pi_paux);
		}
	}
	else {
		memcpy(pInfoParm,pInfoParmW,sizeof(tdtInfoParm));
		if ((c=pInfoParmW->pi_id) == 'A' || c == 'R') rc = ECL_DEFINED_ARRAY;
	}
DEBUGOUT_InfoParm(194,"cl_conv_parm_opt:Exit rc=%d",pInfoParm,rc,0);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_vnam_info(opt,pha,name,nl,ppInfo)
char opt,*name;
int nl;
XHASHB *pha;
tdtInfoParm **ppInfo;
{
	char hakey[Var_NM_MAX*2+2];
	int i;
	tdtInfoParm tInfo,*pInfo;

	if (!pha) return 0;
#ifdef HASH_FIXED_KEYL  /* 2001.2.22 Koba */
	if (nl >= pha->xha_keylen) {
		memcpy(hakey,name,pha->xha_keylen);
	}
	else {
		memset(hakey,' ',pha->xha_keylen);
		memcpy(hakey,name,nl);
	}
	hakey[Var_NM_MAX] = '\0';
/*
ERROROUT3("opt=[%c] name=[%s] nl=%d",opt,name,nl);
*/
#else
	nl = memnzcpy(hakey,name,nl,sizeof(hakey));
#endif

DEBUGOUTL4(194,"cl_gx_chk_vnam_info: pha=%08x opt=%c nl=%d hakey=[%s]",pha,opt,nl,hakey);
/*
printf("cl_gx_chk_vnam_info: pha=%08x opt=%c nl=%d hakey=[%s] i=%d\n",pha,opt,nl,hakey,i);
*/
	pInfo = NULL;
	if (ppInfo) *ppInfo = pInfo;
	pha->xha_xhix = 0;
#if 1	/* 2023.4.28 */
	if (toupper(opt) == 'S') {
		if ((i=akxs_xhash2(pha,'R',hakey,&pInfo)) > 0) {
			pInfo->pi_aux[1] |= D_AUX1_HASHED_NAME;
			if (ppInfo) *ppInfo = pInfo;
		}
		else if (!i) {
			pInfo = &tInfo;
			if (cl_get_option(1,0) & 0x01) cl_null_data(pInfo);
			else cl_parm_set0(pInfo);
			if ((i=akxs_xhash2(pha,opt,hakey,pInfo))>0 && ppInfo) {
				if ((i=akxs_xhash2(pha,'R',hakey,&pInfo)) > 0) {
					pInfo->pi_aux[1] |= D_AUX1_HASHED_NAME;
					*ppInfo = pInfo;
				}
			}
		}
	}
	else if ((i=akxs_xhash2(pha,opt,hakey,&pInfo)) > 0) {
		pInfo->pi_aux[1] |= D_AUX1_HASHED_NAME;
		if (ppInfo) *ppInfo = pInfo;
	}
#if 1	/* 2023.9.20 */
	if (pInfo) {
		if (!pInfo->pi_id) {
			if (cl_get_option(1,0) & 0x01) cl_null_data(pInfo);
			else cl_parm_set0(pInfo);
		}
	}
#endif
#else
	i = akxs_xhash(pha,opt,hakey);
#endif
DEBUGOUT_InfoParm(190,"cl_gx_chk_vnam_info:pInfo",pInfo,0,0);
DEBUGOUTL3(194,"cl_gx_chk_vnam_info:Exit opt=[%c] i=%d pInfo=%08x",opt,i,pInfo);
	return i;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_vnam(opt,pha,name,nl)
char opt,*name;
int nl;
XHASHB *pha;
{
	return cl_gx_chk_vnam_info(opt,pha,name,nl,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_vnam(pha,ix,ppnam)
XHASHB *pha;
int ix;
char **ppnam;
{
	int i;

	pha->xha_xhix = ix;
	i = akxs_xhash(pha,'P',ppnam);
	return i;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_gx_setprm_list_g(name,len)
char *name;
int len;
{
	tdtInfoParm InfoParm,*pInfoParm;
	parmList pL;
	char buf[33],*p;

	*buf = '$';
	if (len>31) len = 31;
	memzcpy(buf+1,name,len);
	pL.prp = buf;
	pL.prmlen = len + 1;
	if (cl_conv_sysvar(&pL,&InfoParm)) return NULL;
	if (pInfoParm = (tdtInfoParm *)cl_const_malloc(sizeof(tdtInfoParm))) {
		if (cl_gx_rep_info_set_ign(pInfoParm ,&InfoParm ,0)) {
			pInfoParm = NULL;
		}
	}
	return pInfoParm;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm_opt(pScCT,opt,pparmList,ppInfoParm,iOpt)
ScrPrCT	  *pScCT;
char opt;
parmList  *pparmList;
tdtInfoParm **ppInfoParm;
int iOpt;
{
	return cl_gx_get_info_parm_opt_psize(pScCT,opt,pparmList,ppInfoParm,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm_opt_psize(pScCT,opt,pparmList,ppInfoParm,iOpt,ppar_pSize)
ScrPrCT *pScCT;
char opt;
parmList *pparmList;
tdtInfoParm **ppInfoParm;
int iOpt;
ParList *ppar_pSize;
{
	int ParmNo,rc,vnlen,pLlen,iLOCAL,ix,code_type;
	char c,*vname,*pLprp,data_id,*p;
	tdtInfoParm *pInfoParm,***pTBL_vnam,tInfoParm;
	char varnam[Var_NM_MAX+1];
	tdtArrayIndex tIndex;
	ProcCT *proc;
	uchar ucLGopt;
	parmList tparmList;

	if (ppar_pSize) {
		ppar_pSize->par = NULL;
		ppar_pSize->parlen = 0;
	}
	if (!ppInfoParm) return -1;
	*ppInfoParm=NULL;
	pInfoParm=NULL;

	pLlen = pparmList->prmlen;
	pLprp = pparmList->prp;
	code_type = GET_TYPE_OPT(pparmList->opt);
	/* 2022.6.11 */
	if (!(rc=cl_skip_scope_mark(pLprp,pLlen,&ix))) ;
	else if (rc > 0) {
		iOpt |= ix;
		tparmList = *pparmList;
		pparmList = &tparmList;
		pLlen -= rc;
		pLprp += rc;
		pparmList->prmlen = pLlen;
		pparmList->prp = pLprp;
	}
	else  return rc;

DEBUGOUTL4(194,"--->cl_gx_get_info_parm_opt_psize: pScCT=%08x opt=%c name=[%s] iOpt=%08x",
pScCT,opt,pLprp,iOpt);

	LOGBUF(strlen(pLprp)+128);
	c = *pLprp;
	if ((c=='$' || c=='%' || c=='#') && *(pLprp+1)=='(') {
		if ((rc=cl_conv_parm_func(&tInfoParm,pLprp,pLlen,iOpt)) >= 0) {
			if (!(pInfoParm = (tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
			cl_gx_copy_info(pInfoParm,&tInfoParm);
			*ppInfoParm = pInfoParm;
			rc = 0;
		}
/*
printf("cl_gx_get_info_parm_opt_psize: rc=%d\n",rc);
*/
		return rc;
	}
	if ((ParmNo=cl_gx_get_index_array(pparmList,varnam,&pInfoParm,iOpt)) < 0) {
		if (ParmNo == ECL_DEFINED_ARRAY) *ppInfoParm = pInfoParm;
				/* cl_gx_get_info_parm_opt:%s�̓p�����[�^�Ɍ�肪����܂��B */
		else if (!(iOpt & D_GX_OPT_NOEROUT_NDEF)) ERROROUT1(FORMAT(311),pLprp);
		return ParmNo;
	}

	c = *pLprp;
	if (ParmNo==0 && *varnam &&		/* �ϐ������z�񖼂��ǂ����̃`�F�b�N */
	    (c=='%' || c=='#')) {		/* �z�񖼂́A%,#�t���œo�^����Ă��� */
		ucLGopt = 0;
		rc = 0;
		proc = NULL;
		if (pScCT) proc = cl_search_proc_ct();
	/*	rc = cl_gx_get_parm_no(pScCT,proc,pLprp,pLlen,'r',0,&pTBL_vnam,&ucLGopt);	*/
		rc = cl_gx_get_parm_no_info(pScCT,proc,pLprp,pLlen,'r',0,&pInfoParm);
DEBUGOUTL5(194,"<---cl_gx_get_info_parm_opt_psize.array: pScCT=%08x proc=%08x ParmNo=%d %s rc=%d",
pScCT,proc,ParmNo,pLprp,rc);
		if (rc > 0){
			/* �z�񖼂Ƃ��ēo�^����Ă��� */
		/*	if (pInfoParm = cl_get_var_ent(pTBL_vnam,rc)) {	*/
			if (pInfoParm) {

DEBUGOUT_InfoParm(194,"cl_gx_get_info_parm_opt_psize.array: ",pInfoParm,0,0);

			/*	if (iLOCAL) pInfoParm->pi_aux[1] |= D_AUX1_LOCAL_VAR;	*/
				pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | ucLGopt;
				*ppInfoParm = pInfoParm;
				return 0;
			}
		}
#if 1	/* 2024.3.29 */
		else {
			ERROROUT1(FORMAT(151),pLprp);	/* �ϐ�(%s)�͖���`�ł��B*/
			return ECL_SCRIPT_ERROR;
		}
#endif
	}
	rc = cl_gx_get_all_var_ent_psize(pScCT,opt,pLprp,ppInfoParm,ParmNo,varnam,iOpt,ppar_pSize);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_info_parm(pScCT,opt,pparmList,ppInfoParm)
ScrPrCT	  *pScCT;
char opt;
parmList  *pparmList;
tdtInfoParm **ppInfoParm;
{
	return cl_gx_get_info_parm_opt(pScCT,opt,pparmList,ppInfoParm,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_parm_no_info(pScCT,proc,varnam,vnlen,opt,iOpt,ppInfo)
ScrPrCT	*pScCT;
ProcCT  *proc;
char    *varnam;
int      vnlen;
char     opt;
int      iOpt;
tdtInfoParm **ppInfo;
{
	int  ParmNo,iNEW_LEX,iSKIP,iCHECK,iLGopt,vlen;
	char *vnam,wrk[Pr_NM_MAX+Var_NM_MAX+2],*p;
	tdtInfoParm ***pTBL_vnam,*pInfo;
	ProcCT  *procW;
	ScrPrCT	*pGLScCT;

DEBUGOUTL5(190,"--->cl_gx_get_parm_no: pScCT=%08x proc=%08x [%s] opt=%c iOpt=%08x",
pScCT,proc,varnam,opt,iOpt);
	if ((iOpt & D_GX_OPT_SET_PRIVATE) ||
	    (opt=='s' && (pGlobTable->options[9] & 0x01))) iSKIP = 1;
	else iSKIP = 0;
	if (pScCT) iNEW_LEX = pScCT->sc_pFlag & D_SCRPT_NEW_LEX;
	else iNEW_LEX = 0;
DEBUGOUTL2(190,"cl_gx_get_parm_no: iNEW_LEX=%08x iSKIP=%d",iNEW_LEX,iSKIP);
	vnlen = akxnskipto(varnam,vnlen,".");
	ParmNo = 0;
	iLGopt= 0;
	if (proc && proc->pha_vnam && iNEW_LEX && !iSKIP) {
		if ((ParmNo=cl_gx_chk_scope_info(opt,proc,varnam,vnlen,&procW,ppInfo)) > 0) {
			iLGopt = D_AUX1_LOCAL_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: LOCAL ParmNo=%d",ParmNo);
		}
		else if (!ParmNo) {
			vlen = cl_mk_static_name(wrk,proc->ProcNM,strlen(proc->ProcNM),varnam,vnlen);
			if ((ParmNo=cl_gx_chk_vnam_info(opt,pScCT->Vary->pha_vnam,wrk,vlen,ppInfo)) > 0) {
				iLGopt = D_AUX1_LOCAL_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: LOCAL ParmNo=%d",ParmNo);
			}
		}
	}
	if (ParmNo<=0 && pScCT) {
		if ((ParmNo=cl_gx_chk_vnam_info(opt,pScCT->Vary->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
			iLGopt = D_AUX1_PRIVATE_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: SCRIPT ParmNo=%d",ParmNo);
		}
	}
	if (ParmNo<=0 && opt=='r') {
		if ((ParmNo=cl_gx_chk_vnam_info(opt,pCLprocTable->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
			iLGopt = D_AUX1_PUBLIC_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: PUBLIC ParmNo=%d",ParmNo);
		}
	}
#if 0
	if (ParmNo<=0 && opt=='r') {
		if ((ParmNo=cl_gx_chk_vnam_info(opt,pGLprocTable->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
			iLGopt = D_AUX1_GLOBAL_VAR;
DEBUGOUTL1(190,"cl_gx_get_parm_no: GLOBAL ParmNo=%d",ParmNo);
		}
	}
#endif
	if (ParmNo > 0) {
		if (pInfo = *ppInfo) pInfo->pi_aux[1] |= iLGopt;
	}
	return ParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_all_var_ent(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
int  ParmNo;
char *varnam;
int  iOpt;
{
	return cl_gx_get_all_var_ent_psize(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_all_var_ent_psize(pScCT,opti,name,ppInfoParm,ParmNo,varnam,iOpt,ppar_pSize)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
int  ParmNo;
char *varnam;
int  iOpt;
ParList *ppar_pSize;
{
	static char *_fn_="cl_gx_get_all_var_ent_psize";
	int rc, vnlen,*pSize,iEROUT_NDEF,iLOCAL,ix,iLGopt,val,ex_opt1;
	char c,opt,optw;
	tdtInfoParm *pInfoParm, ***pTBL_vnam;
	ProcCT  *proc;

	rc = 0;
	if (ppar_pSize) {
		ppar_pSize->par = NULL;
		ppar_pSize->parlen = 0;
	}
	if (!ppInfoParm) return -1;
	*ppInfoParm = NULL;
	pInfoParm = NULL;
	iEROUT_NDEF = !(iOpt & D_GX_OPT_NOEROUT_NDEF);
	if ((opt=opti) == 'R') {
		iEROUT_NDEF = 0;
		iOpt |= D_GX_OPT_NOEROUT_NDEF;
		opt = 'r';
	}
	iLOCAL = iOpt & D_GX_OPT_SET_LOCAL;

DEBUGOUTL5(190,"--->cl_gx_get_all_var_ent_psize: opti=%c pScCT=%08x ParmNo=%d %s(%s)",
opti,pScCT,ParmNo,name,varnam);
DEBUGOUTL4(190,"%s: iOpt=%08x opt=%c iEROUT_NDEF=%d",_fn_,iOpt,opt,iEROUT_NDEF);

	if ((c=name[0])=='$' || (c!='%' && c!='#')) {
		if (ParmNo == 0 && *varnam) {	/* �z��łȂ��ϐ����̃`�F�b�N */
										/* $,%,#�Ȃ��œo�^����Ă��� */
			if (iOpt & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_GLOBAL | D_GX_OPT_SET_PUBLIC/* | D_GX_OPT_SET_PRIVATE*/))
				return cl_gx_get_lg_var_ent_psize(pScCT,opti,name,ppInfoParm,varnam,iOpt,ppar_pSize);
			vnlen = strlen(varnam);
			if (cl_chk_sysvar_name(varnam,vnlen)) {
				pInfoParm = cl_gx_setprm_list_g(varnam,vnlen);
			}
			else {
				ex_opt1 = cl_get_option(1,0);
				if ((ex_opt1 & 0x02) && !(ex_opt1 & 0x10)) opt = 's';	/* 2021.7.16 add */
				iLGopt = 0;
				proc = NULL;
				if (pScCT) proc = cl_search_proc_ct();
/*
printf("cl_gx_get_all_var_ent_psize: proc=%08x\n",proc);
*/
				ParmNo = cl_gx_get_parm_no_info(pScCT,proc,varnam,vnlen,'r',iOpt,ppInfoParm);
DEBUGOUTL2(190,"%s:r ParmNo=%d",_fn_,ParmNo);
				if (ParmNo <= 0) {
					/* 2021.8.4 */
					if (opt == 'r') {
										/* cl_gx_get_all_var_ent: %s(%s)�͖���`�ł��B */
						if (iEROUT_NDEF)
							ERROROUT3(FORMAT(317),_fn_,name,varnam);
						else if (!(iOpt & D_GX_OPT_NOHOLD_NDEF))
							ERRORHOLD5(FORMAT(317),_fn_,name,varnam,0,0);
						return ECL_NDEFVAR_ERROR;
					}
					ParmNo = cl_gx_get_parm_no_info(pScCT,proc,varnam,vnlen,'s',iOpt,ppInfoParm);
DEBUGOUTL2(190,"%s:s ParmNo=%d",_fn_,ParmNo);
				}
				if (ParmNo <= 0) {
					if (opt == 's')
						/* %s: %s(%s)�̃G���g���p�̋󂫂�����܂���B */
						ERROROUT3(FORMAT(316),_fn_,name,varnam);
					else {
										/* %s: %s(%s)�͖���`�ł��B */
						if (iEROUT_NDEF) ERROROUT3(FORMAT(317),_fn_,name,varnam);
						return ECL_NDEFVAR_ERROR;
					}
					return ECL_SCRIPT_ERROR;
				}
				else {
					pInfoParm = *ppInfoParm;
/*
printf("cl_gx_get_all_var_ent_psize: opt=[%c] ParmNo=%d pInfoParm=%08x varnam=[%s]\n",opt,ParmNo,pInfoParm,varnam);
*/
					if (!pInfoParm) rc = -2;
					else {
						pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | iLGopt;
					/*	if (opt == 's') pInfoParm->pi_aux[1] |= D_AUX1_OPT_STORE;	*/
						if (ppar_pSize) ppar_pSize->parlen = ParmNo;
					}
				}
			}
		}
		else {
			if (!*varnam &&
			    (iOpt & (D_GX_OPT_SET_LOCAL | D_GX_OPT_SET_PUBLIC | D_GX_OPT_SET_GLOBAL))) {
				/* cl_gx_get_all_var_ent: %s�͎g�p�ł��܂���B */
				ERROROUT2(FORMAT(318),_fn_,name);
				return ECL_SCRIPT_ERROR;
			}
			if (!pScCT) return -1;
			pSize = (int *)pScCT->Vary->pTBL_dolu[0];
			if (ParmNo>0 && ParmNo<=pSize[2]) {
				pInfoParm = cl_get_var_ent_opt_psize(pScCT->Vary->pTBL_dolu,ParmNo,opt,ppar_pSize);
				if (!pInfoParm) rc = -2;
				else pInfoParm->pi_aux[1] |= D_AUX1_PRIVATE_VAR;
			}
			else if (opt=='r' && ParmNo==0) {
				pInfoParm = cl_var_size_parm(pSize);
			}
			else rc = -1;
		}
	}
	else if (c=='%' || c=='#') {
		if (!ParmNo && *varnam) {
			/* cl_gx_get_all_var_ent: %s�͎g�p�ł��܂���B */
			ERROROUT2(FORMAT(318),_fn_,name);
			return (ECL_SCRIPT_ERROR);
		}
		else {
			if (!pScCT) return -1;
			if (c == '%') {
				if (iLOCAL) {
					if (!(proc = cl_search_proc_ct())) return SysError;
					if (pTBL_vnam=proc->pTBL_pasento) pSize = (int *)pTBL_vnam[0];
					else ParmNo = -1;
					iLGopt = D_AUX1_LOCAL_VAR;
				}
				else {
					pTBL_vnam = pScCT->Vary->pTBL_pasento;
					pSize = (int *)pTBL_vnam[0];
					iLGopt = D_AUX1_PRIVATE_VAR;
				}
				if (ParmNo>0 && ParmNo<=pSize[2]) {
					if (iLOCAL && strcmp(proc->ProcNM,"main") && opt=='r' && ParmNo>pSize[7]) rc = -1;
					else pInfoParm = cl_get_var_ent(pTBL_vnam,ParmNo);
				/*	pInfoParm = cl_get_var_ent_opt_psize(pTBL_vnam,ParmNo,'r',ppar_pSize);	*/
				}
				else if (ParmNo == 0) {
					pInfoParm = cl_var_size_parm(pSize);
				}
				else rc = -1;
				if (!rc && pInfoParm) {
					if (!pInfoParm->pi_id) cl_null_parm(pInfoParm);
#if 1	/* 2024.7.15 */
					pInfoParm->pi_aux[1] |= iLGopt;
					if (!(pInfoParm->pi_aux[1] & D_AUX1_POINTER)) pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
#else
					pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED | iLGopt;
#endif
				}
			}
			else if (c=='#') {
				if (ParmNo>0 && ParmNo<=pScCT->Vary->varnam_igeta)
					pInfoParm = cl_get_var_ent_opt_psize(pScCT->Vary->pTBL_igeta,ParmNo,'r',ppar_pSize);
				else if (ParmNo == 0) {
					pInfoParm = cl_var_size_parm(pScCT->Vary->pTBL_igeta[0]);
				}
				else rc = -1;
				if (!rc) pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED | D_AUX1_PRIVATE_VAR;
			}
		}
	}
	else {
		/* %s: %s�͕ϐ��ł͂���܂���B */
		ERROROUT2(FORMAT(319),_fn_,name);
		return ECL_SCRIPT_ERROR;
	}

DEBUGOUT_InfoParm(194,"cl_gx_get_all_var_ent_psize: rc=%d name=%s",pInfoParm,rc,name);

	if (rc) {
		if (rc == -1)
			/* %s: %s�̃C���f�b�N�X(%d)�͔͈͊O�ł��B */
			ERROROUT3(FORMAT(320),_fn_,name,ParmNo);
		else
			/* %s: %s�p��Malloc�G���[�B*/
			ERROROUT2(FORMAT(321),_fn_,name);
		return ECL_SCRIPT_ERROR;
	}
	if (pInfoParm == NULL) {
		return ECL_SCRIPT_ERROR;
	}
	else if (opt == 'r' && pInfoParm->pi_id == '\0') {
		if (pGlobTable->options[0] & 0x01) {
			val = pInfoParm->pi_aux[1];
			cl_null_data(pInfoParm);
			pInfoParm->pi_aux[1] = val;
			rc = 0;
		}
		else {
			if (iOpt & D_GX_OPT_INFO_MODE) rc = 0;
			else {
								/* %s: %s�̃f�[�^�����ݒ�ł��B */
				if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,name);
				rc = ECL_NO_DATA_ERROR;
			}
		}
	}
	/* 2021.3.24 */
	else if (iEROUT_NDEF && ((c=pInfoParm->pi_id)=='A' || c=='R') && pInfoParm->pi_hlen) {
		/* 2021.4.4 */
		if (rc = _check_gid_alive(pInfoParm,_fn_,name,iEROUT_NDEF)) return rc;
	}
	*ppInfoParm = pInfoParm;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _get_lg_var_ent(scope,opti,pxha,varnam,vnlen,iOpt,ppInfo)
char *scope,opti;
XHASHB	*pxha;
char *varnam;
int vnlen,iOpt;
tdtInfoParm **ppInfo;
{
	static char *_fn_="_get_lg_var_ent";
	int iParmNo,iEROUT_NDEF;
	char opt,name[Var_NM_MAX+1];

	iEROUT_NDEF = !(iOpt & D_GX_OPT_NOEROUT_NDEF);
	if (pGlobTable->options[0] & 0x02) opt = 's';
	else opt = opti;
	memnzcpy(name,varnam,vnlen,sizeof(name));
/*
printf("_get_lg_var_ent: opti=%c name=[%s]\n",opti,name);
*/
	if ((iParmNo=cl_gx_chk_vnam_info('r',pxha,varnam,vnlen,ppInfo)) < 0) return iParmNo;
	else if (!iParmNo) {
		/* 2021.8.4 */
		if (opt != 's') {
								/* cl_gx_get_all_var_ent: %s(%s)�͖���`�ł��B */
			if (iEROUT_NDEF) ERROROUT3(FORMAT(317),_fn_,name,varnam);
			else ERRORHOLD5(FORMAT(317),_fn_,name,varnam,0,0);
			return ECL_NDEFVAR_ERROR;
		}
		if (opt == 's') {
			iParmNo = cl_gx_chk_vnam_info(opt,pxha,varnam,vnlen,ppInfo);
			if (iParmNo <= 0) {
						/* _get_lg_var_ent: %s��%s�G���g���p�̋󂫂�����܂���B */
				ERROROUT3(FORMAT(323),_fn_,name,scope);
				iParmNo = ECL_SCRIPT_ERROR;
			}
		}
	}
DEBUGOUTL5(190,"%s: scope=[%s] opt=%c name=[%s] iParmNo=%d",_fn_,scope,opt,name,iParmNo);
	return iParmNo;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_lg_var_ent(pScCT,opti,name,ppInfoParm,varnam,iOpt)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
char *varnam;
int  iOpt;
{
	return cl_gx_get_lg_var_ent_psize(pScCT,opti,name,ppInfoParm,varnam,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_get_lg_var_ent_psize(pScCT,opti,name,ppInfoParm,varnam,iOpt,ppar_pSize)
ScrPrCT	  *pScCT;
char opti,*name;
tdtInfoParm **ppInfoParm;
char *varnam;
int  iOpt;
ParList *ppar_pSize;
{
	static char *_fn_="cl_gx_get_lg_var_ent_psize";
	int rc,vnlen,iEROUT_NDEF;
	tdtInfoParm *pInfoParm, ***pTBL_vname,*pInfo,**ppInfo;
	ProcCT  *proc,*procW;
	int  iParmNo,iLGopt;
	XHASHB	*pxha;

DEBUGOUTL5(190,"--->%s: pScCT=%08x opti=[%c] varnam=[%s] iOpt=%08x",_fn_,pScCT,opti,varnam,iOpt);

	iEROUT_NDEF = !(iOpt & D_GX_OPT_NOEROUT_NDEF);
	rc = 0;
	ppInfo = &pInfo;
	vnlen = strlen(varnam);
	vnlen = akxnskipto(varnam,vnlen,".");
	if (pScCT) proc = cl_search_proc_ct();
	if (iOpt & D_GX_OPT_SET_LOCAL) {
		proc = NULL;
		if (pScCT) proc = cl_search_proc_ct();
/*
printf("%s: proc=%08x\n",_fn_,proc);
*/
		if (proc && proc->pha_vnam) {
			if (opti=='r' && !(pGlobTable->options[0] & 0x02)) {
				if ((iParmNo=cl_gx_chk_scope_info(opti,proc,varnam,vnlen,&procW,ppInfo)) < 0) return iParmNo;
				else if (!iParmNo) {
								/* %s: %s�͖���`�ł��B */
					if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,strname(varnam,vnlen));
					return ECL_NDEFVAR_ERROR;
				}
			}
			else {
				pxha = proc->pha_vnam;
				if ((iParmNo=_get_lg_var_ent("LOCAL",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
			}
			iLGopt = D_AUX1_LOCAL_VAR;
		}
		else return -1;
	}
	else {
		if (iOpt & D_GX_OPT_SET_PUBLIC) {
			pxha = pCLprocTable->pha_vnam;
			if ((iParmNo=_get_lg_var_ent("PUBLIC",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
			iLGopt = D_AUX1_PUBLIC_VAR;
		}
		else if (pScCT) {
			pxha = pScCT->Vary->pha_vnam;
			if ((iParmNo=_get_lg_var_ent("SCRIPT",opti,pxha,varnam,vnlen,iOpt,ppInfo)) < 0) return iParmNo;
			iLGopt = D_AUX1_PRIVATE_VAR;
		}
		else {
			/* %s: SCRIPT�ϐ�[%s]�͒�`�ł��܂���B */
			ERROROUT2(FORMAT(324),_fn_,varnam);
			return ECL_SCRIPT_ERROR;
		}
	}

DEBUGOUTL2(190,"%s: iParmNo = %d",_fn_,iParmNo);

/*	pInfoParm = cl_get_var_ent_opt_psize(pTBL_vname,iParmNo,'r',ppar_pSize);	*/
	pInfoParm = *ppInfo;
	if (!pInfoParm) rc = -2;
	else {
		if (opti=='r' && pInfoParm->pi_id == '\0') {
			if (pGlobTable->options[0] & 0x01) {
				cl_null_data(pInfoParm);
				rc = 0;
			}
			if (iOpt & D_GX_OPT_INFO_MODE) rc = 0;
			else {
				if (iEROUT_NDEF) ERROROUT2(FORMAT(127),_fn_,varnam);
				rc = ECL_NO_DATA_ERROR;
			}
		}
		pInfoParm->pi_aux[1] |= D_AUX1_HASHED_NAME | iLGopt;
		if (ppar_pSize) ppar_pSize->parlen = iParmNo;
	}
/*
printf("%s: pInfoParm=%08x\n",_fn_,pInfoParm);
*/
	if (ppInfoParm) *ppInfoParm = pInfoParm;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent(pVarIndex,ParmNo)
tdtInfoParm **pVarIndex[];
int ParmNo;
{
	return cl_get_var_ent_opt(pVarIndex,ParmNo,'r');
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent_opt(pVarIndex,ParmNo,opt)
tdtInfoParm **pVarIndex[];
int ParmNo;
char opt;
{
	ParList par_pSize;

	return cl_get_var_ent_opt_psize(pVarIndex,ParmNo,opt,&par_pSize);
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_get_var_ent_opt_psize(pVarIndex,ParmNo,opt,ppar_pSize)
tdtInfoParm **pVarIndex[];
int ParmNo;
char opt;
ParList *ppar_pSize;
{
	int ix,iy,i,*pSize,iMAX_VAR_IX,iMAX_VAR_IY,val;
	tdtInfoParm *pDummy, **TBL_var;

	if (!pVarIndex || ParmNo<=0) return NULL;
	pSize = (int *)pVarIndex[0];
	if (ParmNo > pSize[2]) return NULL;
	iMAX_VAR_IX = pSize[0];
	iMAX_VAR_IY = pSize[1];
	pVarIndex++;
/*
printf("cl_get_var_ent_opt_psize: id=%s iMAX_IX=%d iMAX_IY=%d MAX_XY=%d\n",
&pSize[3],iMAX_VAR_IX,iMAX_VAR_IY,pSize[2]);
*/
	ParmNo--;
	ix = ParmNo / iMAX_VAR_IY;
	iy = ParmNo % iMAX_VAR_IY;

DEBUGOUTL4(190,"--->cl_get_var_ent_opt_psize:pVarIndex=%08x ParmNo=%d ix=%d iy=%d",
pVarIndex,ParmNo,ix,iy);
/*
printf("--->cl_get_var_ent_opt_psize:pVarIndex=%08x ParmNo=%d ix=%d iy=%d\n",
pVarIndex,ParmNo,ix,iy);
*/
	if (!(TBL_var = pVarIndex[ix])) {
		if (!(TBL_var=(tdtInfoParm **)Malloc(sizeof(tdtInfoParm *)*iMAX_VAR_IY)))
			return NULL;
/*
printf("cl_get_var_ent_opt_psize:Malloc TBL_var=%08x\n",TBL_var);
*/
		memset(TBL_var,0,sizeof(tdtInfoParm *)*iMAX_VAR_IY);
		pVarIndex[ix++] = TBL_var;
		pSize[5] = X_MAX(ix,pSize[5]);
		if (!(pDummy=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)*iMAX_VAR_IY)))
			return NULL;
/*
printf("cl_get_var_ent_opt_psize:Malloc pDummy=%08x\n",pDummy);
*/
		for(i=0;i<iMAX_VAR_IY;i++) {
			TBL_var[i] = (tdtInfoParm *)parm_set0(pDummy);
			pDummy++;
		}
	}
/*
printf("cl_get_var_ent_opt_psize: TBL_var=%08x\n",TBL_var);
*/
	ParmNo++;
	pSize[6] = ParmNo;
/*
printf("cl_get_var_ent_opt_psize: ParmNo=%d pSize[6]=%d opt=[%c]\n",ParmNo,pSize[6],opt);
*/
	if (opt == 's') {
		cl_set_max_var_ent(pSize,ParmNo);
		if (ppar_pSize) {
			ppar_pSize->par = NULL;
			ppar_pSize->parlen = 0;
		}
	}
	else {
		if (ppar_pSize) {
			ppar_pSize->par = (char *)pSize;
			ppar_pSize->parlen = ParmNo;
		}
	}
/*
printf("cl_get_var_ent_opt_psize:TBL_var[%d]=%08x\n",iy-1,TBL_var[iy-1]);
printf("cl_get_var_ent_opt_psize:TBL_var[%d]=%08x\n",iy,TBL_var[iy]);
*/
	pDummy = TBL_var[iy];
	if (!pDummy->pi_id) {
		if (cl_get_option(1,0) & 0x01) cl_null_data(pDummy);
		else cl_parm_set0(pDummy);
	}

DEBUGOUT_InfoParm(LVL_GXEXOBJ+1,"cl_get_var_ent_opt_psize:",pDummy,0,0);

	return pDummy;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_max_var_ent(pSize,ParmNo)
int *pSize,ParmNo;
{
	tdtInfoParm *pInfoParm;
	int ret,val;
	char *name;

	if (ParmNo<0 || ParmNo>pSize[7]) {
		name = (char *)&pSize[3];

DEBUGOUTL3(200,"cl_set_max_var_ent: name=[%s] ParmNo=%d pSize[7]=%d",name,ParmNo,pSize[7]);

		if (ParmNo < 0) ParmNo = 0;
		pSize[7] = ParmNo;
		pInfoParm = cl_var_size_parm(pSize);
		cl_set_parm_bin(pInfoParm,ParmNo);
		pInfoParm->pi_aux[1] |= D_AUX1_PROTECTED;
	/*	ret = cl_reflect_size_of_number_array(name,ParmNo);	*/
/*
printf("cl_set_max_var_ent: name=[%s] ParmNo=%d pSize[7]=%d\n",name,ParmNo,pSize[7]);
*/
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_info_parm(pDummy)
tdtInfoParm *pDummy;
{
	tdtArrayIndex *pIndex;
	char c,*p;
	XHASHB *xhp;
	tdtInfoParm *pParm;
	tdtInfoParm *pInfoParm1,*pInfoS;
	tdtRbCtl *pCt;
	tdtDefType *pDeftype;
	int ix,type,i,len,n,rc;
	ProcCT *proc;

DEBUGOUT_InfoParm(250,"--->cl_free_info_parm:",pDummy,0,0);
DEBUGOUTL1(250,"cl_free_info_parm: pDummy->pi_data=%08x",pDummy->pi_data);

  if (pDummy) {
	if (pDummy->pi_id) {
DEBUGOUTL2(250,"cl_free_info_parm: id=[%c] pi_scale=%02x",pDummy->pi_id,pDummy->pi_scale);
		if (pDummy->pi_scale & D_DATA_MALLOC) {
			c = pDummy->pi_id;
			if (c==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
				if (pCt=(tdtRbCtl *)pDummy->pi_data) {
					while (pParm=(tdtInfoParm *)akxs_rb_get_n(pCt)) {
						cl_free_info_parm(pParm);
						if (!pCt->rb_malloc) Free(pParm);
					}
					akxs_rb_free(pCt);
				}
			}
			else if (c==D_DATA_ID_INSTANCE || c==D_DATA_ID_CLASS || c==D_DATA_ID_CLMETHOD) {
DEBUGOUTL4(250,"cl_free_info_parm: id=%c pDummy=%08x pi_scale=%02x pi_data=[%s]"
,c,pDummy,pDummy->pi_scale,pDummy->pi_data);
/*
printf("cl_free_info_parm: id=%c pDummy=%08x pi_scale=%02x pi_data=[%s]\n",c,pDummy,pDummy->pi_scale,pDummy->pi_data);
*/
				if (p=pDummy->pi_data) Free(p);
				if (proc=(ProcCT *)pDummy->pi_len) {
					if (pDummy->pi_scale & D_DATA_CLEAR_PROC) cl_prc_clear(proc);
				/*	if (!(pDummy->pi_scale & D_DATA_COPIED_PROC)) cl_prc_clear(proc);	*/
				/*	else if (!(pDummy->pi_scale & D_DATA_NO_FREE_PROC)) Free(proc);	*/
				}
			}
			else if (c == D_DATA_ID_PNAME) {
				if (pInfoParm1 = (tdtInfoParm *)pDummy->pi_pos) {
					if (pDummy->pi_scale & D_DATA_INDEX_FREE) {
DEBUGOUTL1(198,"cl_free_info_parm: pInfoParm1=%08x",pInfoParm1);
						rc = cl_free_info_parm(pInfoParm1);
						if (rc != ECL_NOT_FREE_INFO) {
DEBUGOUTL1(198,"cl_free_info_parm: Free(pInfoParm1)",0);
							Free(pInfoParm1);
						}
					}
				}
			}
			else if (p=pDummy->pi_data) Free(p);
			pDummy->pi_data = NULL;
		}
		else if (pDummy->pi_alen & D_AULN_PARMINFO2) {
			pInfoParm1 = pDummy + 1;
			if (pInfoParm1->pi_scale & D_DATA_MALLOC) {
				len = pInfoParm1->pi_dlen;
				pInfoS = (tdtInfoParm *)pInfoParm1->pi_data;
				n = len/sizeof(tdtInfoParm);
				for (i=0;i<n;i++,pInfoS++) {
					pInfoS->pi_alen &= ~D_AULN_PARMINFO2;
					cl_free_info_parm(pInfoS);
				}
				Free(pInfoParm1->pi_data);
			}
		}
	/*	cl_parm_set0(pDummy);	2023.9.20 */
	}
#if 1	/* 2023.9.20 */
	if (cl_get_option(1,0) & 0x01) cl_null_data(pDummy);
	else cl_parm_set0(pDummy);
#endif
  }
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_var_ent_opt(pVarIndex,reset)
tdtInfoParm **pVarIndex[];
int reset;
{
	int ix,iy;
	tdtInfoParm *pDummy, **TBL_var;
	int *pSize,iMAX_VAR_IX,iMAX_VAR_IY;

DEBUGOUTL1(190,"--->cl_free_var_ent:pVarIndex=%08x",pVarIndex);

	if (!pVarIndex) return -1;
	pSize = (int *)pVarIndex[0];
	iMAX_VAR_IX = pSize[5];
	iMAX_VAR_IY = pSize[1];
	pVarIndex++;

DEBUGOUTL4(190,"cl_free_var_ent: id=%s iMAX_IX=%d iMAX_IY=%d MAX_XY=%d",
&pSize[3],iMAX_VAR_IX,iMAX_VAR_IY,pSize[2]);

	for (ix = 0; ix < iMAX_VAR_IX; ix++) {
		if (TBL_var = pVarIndex[ix]) {
			if (TBL_var[0]) {
				for (iy = 0; iy < iMAX_VAR_IY; iy++) {
					pDummy = TBL_var[iy];
					if (pDummy && pDummy->pi_id) {
						if (reset) parm_set0(pDummy);
						else cl_free_info_parm(pDummy);
					}
				}
				if (!reset) Free(TBL_var[0]);
			}
			if (!reset) {
				Free(TBL_var);
				pVarIndex[ix] = NULL;
			}
		}
	}
	if (reset) {
		pSize[5] = pSize[6] = pSize[7] = 0;
		cl_set_parm_bin(cl_var_size_parm(pSize),0);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_free_var_ent(pVarIndex)
tdtInfoParm **pVarIndex[];
{
	return cl_free_var_ent_opt(pVarIndex,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_reset_var_ent(pVarIndex)
tdtInfoParm **pVarIndex[];
{
	return cl_free_var_ent_opt(pVarIndex,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_scope(opt,proc,varnam,vnlen,pprocW)
char     opt;
ProcCT  *proc;
char    *varnam;
int      vnlen;
ProcCT  **pprocW;
{
	return cl_gx_chk_scope_info(opt,proc,varnam,vnlen,pprocW,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_chk_scope_info(opt,proc,varnam,vnlen,pprocW,ppInfo)
char     opt;
ProcCT  *proc;
char    *varnam;
int      vnlen;
ProcCT  **pprocW;
tdtInfoParm **ppInfo;
{
	static char *_fn_="cl_gx_chk_scope_info";
	ProcCT	*procW;
	char *path0,*path;
	int ParmNo,len,len0;

DEBUGOUTL3(120,"%s:Enter opt=%c varnam=[%s]",_fn_,opt,strname(varnam,vnlen));

DEBUGOUTL4(120,"%s: proc->pha_vnam=%08x options[7]=%08x path=[%s]",
_fn_,proc->pha_vnam,pGlobTable->options[7],nval1(proc->ProcPath));

	if ((ParmNo=cl_gx_chk_vnam_info(opt,proc->pha_vnam,varnam,vnlen,ppInfo)) > 0) *pprocW = proc;
	else if (!ParmNo && (pGlobTable->options[7] & 0x02) && (path=proc->ProcPath)) {
	/*	path = proc->ProcPath;	*/

DEBUGOUTL2(120,"%s: path=[%s]",_fn_,path);

		if (*path == '*') {
			path++;
		}
		if ((len=akxnrskipto(path,strlen(path),".")) <= 0) return 0;
		procW = proc;
		while (procW = procW->prePCT) {
/*
printf("cl_gx_chk_scope_info: procW->ProcPath=%08x\n",procW->ProcPath);
*/
			if (path0 = procW->ProcPath) {
				len0 = strlen(path0);
/*
printf("cl_gx_chk_scope_info: path0=[%s] len0=%d\n",path0,len0);
*/
				if (len0 <= len) {
					if (!memcmp(path,path0,len0)) {
						if ((ParmNo=cl_gx_chk_vnam_info(opt,procW->pha_vnam,varnam,vnlen,ppInfo)) > 0) {
							*pprocW = procW;
/*
printf("cl_gx_chk_scope_info: found ParmNo=%d in path0=[%s]\n",ParmNo,path0);
*/
							break;
						}
						else if (ParmNo < 0) return ParmNo;
					}
				}
			}
			else {
				/* cl_gx_chk_scope_info:W: %s�̏�ʂ�ProcPath��NULL��proc������܂��B */
				ERROROUT1(FORMAT(325),path);
			}
		}
	}
DEBUGOUTL2(120,"%s:Exit ParmNo=%d",_fn_,ParmNo);
	return ParmNo;
}

/************************************/
/*	_check_gid_alive				*/
/************************************/
int _check_gid_alive(pInfoParmW,fnam,vnam,iEROUT_NDEF)
tdtInfoParm *pInfoParmW;
char *fnam,*vnam;
int iEROUT_NDEF;
{
	int rc,ix;
	long gid;

	rc = 0;
	if (gid=pInfoParmW->pi_hlen) {
DEBUGOUTL2(170,"_check_gid_alive: pInfoParmW=%08x gid=%d",pInfoParmW,gid);
		if ((ix=akxs_xhasl(pGLprocTable->pha_gid,'R',gid,0)) <= 0) {
						/* %s: �ϐ�(%s)�̔z��͖����ł�(gid=%d hash ix=%d)�B */
			if (!fnam) fnam = "_check_gid_alive";
			if (!vnam) vnam = (char *)pInfoParmW->pi_pos;
			if (iEROUT_NDEF) ERROROUT4(FORMAT(322),fnam,nvalid(vnam,""),gid,ix);
			cl_free_info_parm(pInfoParmW);
			rc = ECL_NDEFVAR_ERROR;
		}
	}
	return rc;
}

/************************************/
/*	cl_mk_static_name				*/
/************************************/
int cl_mk_static_name(wrk,prnam,prlen,varnam,vnlen)
char *wrk,*prnam,*varnam;
int prlen,vnlen;
{
	char *p;

	p = wrk;
	memcpy(p,prnam,prlen);
	p += prlen;
	*(p++) = '.';
	memzcpy(p,varnam,vnlen);
/*
printf("cl_mk_static_name: wrk=[%s]\n",wrk);
*/
	return prlen+vnlen+1;
}

/************************************/
/*	cl_set_pSize_index				*/
/************************************/
int cl_set_pSize_index(pInfoParmW,pSize,index,ParmNo,pParent)
tdtInfoParm *pInfoParmW,*pParent;
int pSize[],index[],ParmNo;
{
	char **ppp,*p1;

DEBUGOUTL5(102,"cl_set_pSize_index: pInfoParmW=%08x pSize=%08x index=%08x ParmNo=%d pParent=%08x",
pInfoParmW,pSize,index,ParmNo,pParent);
	if (index) {
		if (!(ppp=(char **)cl_tmp_const_malloc(sizeof(char *)*2))) return -1;
		ppp[0] = (char *)index;
		ppp[1] = (char *)pParent;	/* �e�̃|�C���^�������Ă��� */
	}
	else ppp = NULL;
	pInfoParmW->pi_len = (long)ppp;
	pInfoParmW->pi_paux = (char *)pSize;
	pInfoParmW->pi_hlen = ParmNo;
	return 0;
}
