static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	  �����ړI�@�@�F  ���Z����												*
*																			*
*	  �֐����@�@�@�F�@int cl_gx_funcBexp(pInfoParmW,pOperator,nparm,pParm)	*
*						tdtInfoParm *pInfoParmW;							*
*						char *pOperator;									*
*						tdtInfoParm *pParm;									*
*						int nparm;											*
*																			*
*	  �߂�l�@�@�@�F�@ERROR									�@				*
*					  NORMAL												*
*																			*
*	  �����T�v�@�@�F�@														*
*																			*
*****************************************************************************/
#include <colmn.h>

extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];

int replace();
int condas();
int cl_cmpt_is();
int cl_cmpt_math();
int cl_cmpt_to();
int substrm();
int concat();
int cl_func_conv_parm();
/*	name		nparm ope					kubun		reta    arg_kbn ret_kbn option resv[2] */
static qOpeTable tOpeTbl[]=
	{"IS"			,2,D_FUC_IS				,IS			,DEF_ZOK_BINA,2,3,cl_cmpt_is		,0,0,0	/* 2-->3*/
	,"MOD"			,2,D_FUC_MOD			,MATH		,DEF_ZOK_BINA,0,4,cl_cmpt_math		,0,0,0
	,"TO"			,2,D_FUC_TO				,TO			,DEF_ZOK_CHAR,2,6,cl_cmpt_to		,0,0,0
	,"REP"			,2,D_FUC_REP			,STRING		,DEF_ZOK_CHAR,10,2,replace		,0,0,0
	,"CONDAS"		,2,D_FUC_CONDAS			,STRING		,DEF_ZOK_CHAR,10,2,condas		,0,0,0
	,"SUBSTR"		,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x0b,2,substrm	,0,0,0
	,"SUBSTRB"		,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x8b,2,substrm	,0,0,0
	,"MID"			,2,D_FUC_SUBSTR			,STRING		,DEF_ZOK_CHAR,0x0b,2,substrm	,0,0,0
	,"MIDB"			,2,D_FUC_SUBSTRB		,STRING		,DEF_ZOK_CHAR,0x8b,2,substrm	,0,0,0
	,"CONCAT"		,1,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat		,0,0,0
	,"&+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat		,0,0,0
	,"|+"			,2,D_FUC_CONCAT			,STRING		,DEF_ZOK_CHAR,12,2,concat		,0,0,0
	,"$"			,0,D_FUC_DOL			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm	,0,0,0
	,"#"			,0,D_FUC_IGE			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm	,0,0,0
	,"%"			,0,D_FUC_PAS			,FUNCTION	,DEF_ZOK_CHAR,2,1,cl_func_conv_parm	,0,0,0
	,NULL,0,0,0,0,0,0,NULL,0,0,0
	};

/****************************************/
/*										*/
/****************************************/
int rep_condas(pAns,nparm,ppParm,func)
char **pAns;
int nparm;
tdtInfoParm	*ppParm[];
int (*func)();
{
	tdtInfoParm *pInfoParm1,tInfoParm;
	tdtInfoParm *pInfoParm2;
	int  rc,len1,code_type;
	char *p1;
	ParList3 par3;

	pInfoParm1 = ppParm[0];
	pInfoParm2 = ppParm[1];
	if (nparm > 2) {
		if (pInfoParm2->pi_id==' ' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			code_type = cl_get_char_code_type(pInfoParm1,1);
			if ((rc=cl_get_str_pos(nparm,ppParm,0,&par3,NULL,"")) < 0) return rc;
			p1 = par3.par;
			len1 = par3.parlen;
			pInfoParm1 = &tInfoParm;
			cl_set_parm_char2(pInfoParm1,p1,len1,code_type);
			pInfoParm2 = ppParm[rc];
		}
	}
	return func(pAns,pInfoParm1,pInfoParm2);
}
