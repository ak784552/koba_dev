static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_end_if              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
/* */

#include "colmn.h"          /* �\���̒�` */

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_if(y)
condList *y;
{
	static int able[]={C_IF,C_ELSEIF,C_ELSE};
	static int deny[]={0};

	return col_mn_tr_end_node(y,deny,0,able,3);
}

/************************************************/
/*                                              */
/*     cl_if_close                              */
/*----------------------------------------------*/
/*                                              */
/*                                              */
/************************************************/
/* */
int cl_if_close(y)
condList *y;
{
	int rc = 0;
	CLNCB *p;

	p = y->clstcb;
	for (;;) {
		if (!p->nestLev2) break;
		if (p->nestLev2->cmd.cid == C_LOOP ) {
			rc = cl_nest_tag(y,2);
			if (rc != -1) {
				cl_change_tree(y,p->nestLev2);
				cl_search_nest(y,2);
/*
				ERROROUT(FORMAT(66));
*/
				rc = 10000;
			}
		}
		else break;
	}
	return rc;
}

/************************************************/
/*     cl_search_node_leaf                      */
/************************************************/
int cl_search_node_leaf(y,deny,nd,able,na,ppleaf,check)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
int check;
{
	Leaf  *Dummy;
	int i,id,flag,able_id;
/*
printf("cl_search_node: nestLev1=%08x[%s] nestLev2=%08x[%s]\n",
CLSTCB.nestLev1,cl_gets_cmd_name(CLSTCB.nestLev1->cmd.cid),
CLSTCB.nestLev2,cl_gets_cmd_name(CLSTCB.nestLev2->cmd.cid));
*/
	if (ppleaf) *ppleaf = NULL;
#if 1
	if (Dummy = y->clstcb->nestLev2) {
		id = Dummy->cmd.cid;
		flag = Dummy->cmd.sub_cid & check;
		for (i=0;i<na;i++) {
			able_id = able[i];
			if (flag) {
				if (able_id & flag) able_id &= ~C_CMD_FLAGS;
				else continue;
			}
			if (id == able_id) {
				if (ppleaf) *ppleaf = Dummy;
				return 0;
			}
		}
		return -1;
	}
	if (ppleaf) *ppleaf = Dummy;
	return -2;
#else
	if (!(Dummy = CLSTCB.nestLev2)) return 0;
	while(Dummy) {
	/*	if (Dummy == CLSTCB.nestLev1) break;	*/
		id = Dummy->cmd.cid;

printf("cl_search_node: Dummy=%08x id=[%s] \n",Dummy,cl_gets_cmd_name(id));

		for (i=0;i<nd;i++) {
			if (id == deny[i]) return i+1;
		}
		for (i=0;i<na;i++) {
			if (id == able[i]) return 0;
		}
		if (Dummy == CLSTCB.nestLev1) break;
		Dummy = Dummy->preleaf;
	}
	return -1;
#endif
}

/************************************************/
/*     cl_search_node                             */
/************************************************/
int cl_search_node(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	return cl_search_node_leaf(y,deny,nd,able,na,NULL,0);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_end_prmnum_check(y)
condList *y;
{
	int rc, i;

	if (y->cmd->prmnum > 0) {
		ERROROUT1(FORMAT(41),"col_mn_tr_end_node");	/* %s: �s�v�ȃp�����[�^������܂��B */
		rc = ECL_TR_ENDIF;
	}
	else rc = 0;
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_node_check_leaf_check(y,deny,nd,able,na,ppleaf,check)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
int check;
{
	int rc, i, able_id, flag;
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};

	rc = cl_search_node_leaf(y,deny,nd,able,na,ppleaf,check);
	if (rc) {
		mcat.mc_ipos = 0;
		if (rc < 0) {
			for (i=0;i<na;i++) {
				if (i > 0) akxtmcats(&mcat,",");
				able_id = able[i];
				flag = able_id & C_CMD_FLAGS;
				akxtmcats(&mcat,cl_gets_cmd_name(able_id & ~C_CMD_FLAGS));
				if (flag == C_LOOP_DO) akxtmcats(&mcat," DO");
			}
			ERROROUT2(FORMAT(67),	/* col_mn_tr_end_node: %s���Ȃ��̂�%s���ݒ肳��܂����B */
				mcat.mc_bufp,cl_gets_cmd_name(y->cmd->cid));
		}
		else if (deny && nd>0) {
		/*
			for (i=0;i<nd;i++) {
				if (i > 0) akxtmcats(&mcat,",");
				akxtmcats(&mcat,cl_gets_cmd_name(deny[i]));
			}
			ERROROUT2(FORMAT(68),
				mcat.mc_bufp,cl_gets_cmd_name(CLcList.cmd.cid));
		*/
			ERROROUT2(FORMAT(68),	/* col_mn_tr_end_node: %s�̌��%s�͎g�p�ł��܂���B */
				cl_gets_cmd_name(deny[rc-1]),cl_gets_cmd_name(y->cmd->cid));
		}
		return ECL_TR_ENDIF;
	}
	return rc ;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_node_check_leaf(y,deny,nd,able,na,ppleaf)
condList *y;
int deny[],nd;
int able[],na;
Leaf  **ppleaf;
{
	return cl_tr_node_check_leaf_check(y,deny,nd,able,na,ppleaf,0);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_node_check(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	return cl_tr_node_check_leaf(y,deny,nd,able,na,NULL);
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_end_node_check(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc = cl_tr_node_check(y,deny,nd,able,na))) {
	/*
		rc = cl_if_close();
		if (rc == 10000) {
			ERROROUT(FORMAT(69));
			return (ECL_TR_ENDIF);
		}
	*/
	}
	return rc ;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_end_nest_check(y)
condList *y;
{
	int rc ,tree;

	tree = cl_nest_tag(y,2);
	if (tree != -1) {
		rc=cl_change_tree(y,y->clstcb->nestLev2 );
	/*	if (rc) return rc;	*/
		cl_search_nest(y,2);
	}
	else return ECL_TR_ENDIF;
  /* else clError(30); */

	if (!(rc=cl_make_leaf(y))) rc = cl_push(y);

	return rc ;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_end_node(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_prmnum_check(y))) {
		if (!(rc=cl_tr_end_node_check(y,deny,nd,able,na))) rc = cl_tr_end_nest_check();
	}
	return rc ;
}
