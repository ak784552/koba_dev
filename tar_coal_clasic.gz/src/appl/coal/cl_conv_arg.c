static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �R�}���h�����ϊ�                                       *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_arg(pparmList)                             *
*                      (I)prmList	*pparmList                                *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
/********************************************/
/*	  coded by A.Kobayashi() 2010.XX.XX		*/
/*	  error code : -215120101�`-215129999	*/
/********************************************/
#include "colmn.h"

extern char cmp_sep2[];

/****************************************/
/*	01									*/
/****************************************/
int cl_conv_arg_opt_kind(pparmList,pInfoParm,opt,rc)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
int opt,rc;
{
/*
printf("cl_conv_arg_opt_kind: kind=%d opt=%08x\n",rc,opt);
*/
	switch (rc) {
		case	PARAMETER :
			rc = cl_conv_parm_opt(pparmList,pInfoParm,opt);
			break;
		case	CONSTANT_NUM :
			rc = cl_conv_const_n(pparmList,pInfoParm);
			break;
		case	CONSTANT_CHR :
			rc = cl_conv_const_c(pparmList,pInfoParm);
			break;
		case	CONSTANT_CMD :
		/*	rc = cl_conv_const_cmd(pparmList,pInfoParm);	*/
			rc = D_ERROR;
			break;
		case	SYSVAR :
			rc = cl_conv_sysvar(pparmList,pInfoParm);
			break;
		case	NULL_PARM :
			rc = cl_null_parm(pInfoParm);
			break;
		case	0 :
			rc = D_ERROR;
			break;
		case	SEPARATOR :
			break;
		default:
			cl_set_parm_char2(pInfoParm,pparmList->prp,pparmList->prmlen,GET_TYPE_OPT(pparmList->opt));
			rc = NAME_CONST;
			break;
	}
	return rc;
}

/****************************************/
/*	02									*/
/****************************************/
int cl_conv_arg_opt(pparmList,pInfoParm,opt)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
int opt;
{
	int	rc,pLlen,iDATA,x;
	char *pLprp;
	parmList qprmL;

	qprmL = *pparmList;
	qprmL.opt = SET_TYPE_OPT(akxt_get_code_type());
	if (!(rc=cl_skip_scope_mark(qprmL.prp,qprmL.prmlen,&x))) ;
	else if (rc > 0) {
		qprmL.prp += rc;
		qprmL.prmlen -= rc;
	/*	opt |= x;	2022.9.26 */
		opt = (opt & ~D_GX_OPT_SET_SCOPE) | x;
	}
	else return rc;

/*	opt &= ~D_GX_OPT_STORE;	*/
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pLlen = pparmList->prmlen;
	pLprp = pparmList->prp;
	if (*qprmL.prp=='(' && *(qprmL.prp+qprmL.prmlen-1)==')') {
		qprmL.prp++;
		qprmL.prmlen -= 2;
		*(qprmL.prp+qprmL.prmlen) = '\0';
	}
	iDATA = 0;
	if (*pLprp == '*') {
		qprmL.prp++;
		qprmL.prmlen--;
		*(qprmL.prp+qprmL.prmlen) = '\0';
		iDATA = DEF_ZOK_DATA;
	}
/*
printf("cl_conv_arg_opt: qprmL.prmlen=%d qprmL.prp=[%s]\n",qprmL.prmlen,qprmL.prp);
*/
	rc = cl_anal_parm(&qprmL);
	if ((rc=cl_conv_arg_opt_kind(&qprmL,pInfoParm,opt,rc))<0 || rc==NAME_CONST) {
				/* %s: �p�����[�^[%s]������Ă��܂��B*/
		ERROROUT2(FORMAT(45),"cl_conv_arg_opt",pparmList->prp);
		rc = ECL_SCRIPT_ERROR;
	}
	else {
DEBUGOUT_InfoParm(110,"cl_conv_arg_opt: rc=%d iDATA=%08x",pInfoParm,rc,iDATA);
		if (pInfoParm->pi_id == 'S') {
			pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
		}
		pInfoParm->pi_aux[0] |= iDATA;
		rc = 0;
	}
	return rc;
}

/****************************************/
/*	03									*/
/****************************************/
int cl_conv_arg(pparmList,pInfoParm)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
{
	return cl_conv_arg_opt(pparmList,pInfoParm,0);
}

/* K-00057 �ȉ��ǉ� */
/****************************************/
/*	04									*/
/****************************************/
int cl_arg_to_var(pparmList,Obj,pprList)
parmList *pparmList;
int      *Obj;
prmList  *pprList;
{
	int	rc;
	tdtInfoParm  InfoParm;

	memset(pprList,0,sizeof(prmList));
	rc = cl_gx_exp_obj(1,&pparmList,Obj,&InfoParm);
	if (rc == NORMAL) {
		rc = cmpktform(pprList,&InfoParm);
	}
	return(rc);
}

/****************************************/
/*	05									*/
/****************************************/
int cl_arg_to_char(pparmList,Obj,pInfoParm,msg)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
{
	return cl_arg_to_char_opt(pparmList,Obj,pInfoParm,msg,0);
}

/****************************************/
/*	06									*/
/****************************************/
int cl_arg_to_char_num(pparmList,Obj,pInfoParm,msg,opt,only_char)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
int       opt;
int       only_char;	/* =0:char or num, =1: only char,
						   =2:$%#name,'XYZ',func()�̂ݕϊ����� */
{
	int  rc,len,atr,opt_type,code_type,kind,iEXP;
	char *p,*dat,c;

	if (!(p=msg)) p = FORMAT(297);	/* �p�����[�^ */
#if 1	/* 2020.3.1 */
	dat = pparmList->prp;
	len = pparmList->prmlen;
	code_type = GET_TYPE_OPT(pparmList->opt);
DEBUGOUTL3(120,"cl_arg_to_char_num:Enter len=%d dat=[%s] p=[%s]",len,dat,p);
	/* 2020.3.15 */
	if (!cl_chk_name_opt(dat,len,pparmList->opt)) {
DEBUGOUTL3(120,"cl_arg_to_char_num: NAME_CONST rc=%d len=%d dat=[%s]",rc,len,dat);
		return cl_set_parm_char2(pInfoParm,dat,len,code_type);
	}
#endif
	kind = cl_anal_parm(pparmList);
/*
printf("cl_arg_to_char_num: kind=%d only_char=%d\n",kind,only_char);
*/
	if (kind < 0) {
		ERROROUT1(FORMAT(298),p);	/* %s�擾�G���[ */
		return kind;
	}
	else if (kind == NULL_PARM) {
		rc = cl_null_parm(pInfoParm);
	}
	else {
		rc = 0;
		len = pparmList->prmlen;
		dat = pparmList->prp;
		opt_type = pparmList->opt & CD_TYPE_OPT_MASK;
/*
printf("cl_arg_to_char_num: opt_type=%08x len=%d dat=[%s]\n",opt_type,len,dat);
*/
		iEXP = 0;
		if (kind == NAME_CONST) {
			if (only_char==1 && ((c=*dat)=='-' || c=='+')) ;	/* {-|+}parameter */
			else {
				if (akx_skip_opt(dat,len,cmp_sep2+2,0x08 | opt_type) < len) iEXP = 1;	/* skip_to */
			}
			if (!iEXP) {
				rc = cl_set_parm_char(pInfoParm,dat,len);
DEBUGOUTL2(120,"cl_arg_to_char_num: NAME_CONST2 len=%d dat=[%s]",len,dat);
				return rc;
			}
		}
#if 1	/* 2023.8.12 */
/*
printf("cl_arg_to_char_num: iEXP=%d\n",iEXP);
*/
		if (only_char == 2) {
			if (iEXP==1 || kind==CONSTANT_CHR || kind==PARAMETER) {
			/*
				if ((rc=cl_gx_exp_obj_opt(1,&pparmList,Obj,pInfoParm,opt)) < 0) return rc;
				if ((len=parm_to_char_tmp(pInfoParm,&dat,0)) < 0) return len;
			*/
				;
			}
			else
			return cl_set_parm_char(pInfoParm,dat,len);
		}
#endif
		if (!rc) rc = cl_gx_exp_obj_opt(1,&pparmList,Obj,pInfoParm,opt);
		if (rc) {
			ERROROUT2(FORMAT(299),p,dat);	/* %s[%s]�Ɍ�肪����܂��B */
			rc = ECL_SCRIPT_ERROR;
		}
		else {
DEBUGOUT_InfoParm(120,"cl_arg_to_char_num: ",pInfoParm,0,0);
			atr = pInfoParm->pi_attr;
#if 1	/* 2023.8.11 */
			if (only_char == 2) {
				if (atr != DEF_ZOK_CHAR) {
					if ((rc=parm_to_char_tmp(pInfoParm,&dat,0)) < 0) return rc;
/*
printf("cl_arg_to_char: rc=%d dat=[%s]\n",rc,dat);
*/
					rc = cl_set_parm_char(pInfoParm,dat,rc);
				}
			}
			else
#endif
			if (only_char==1 && atr != DEF_ZOK_CHAR) {
				ERROROUT2(FORMAT(300),p,dat);	/* %s[%s]�������^�ł͂���܂���B */
				rc = ECL_SCRIPT_ERROR;
			}
			else if (atr==DEF_ZOK_CHAR || atr==DEF_ZOK_BINA ||
			         atr==DEF_ZOK_FLOA || atr==DEF_ZOK_DECI) ;
			else {
				ERROROUT2(FORMAT(45),p,dat);	/* %s: �p�����[�^[%s]������Ă��܂��B */
				rc = ECL_SCRIPT_ERROR;
			}
		}
	}
	return rc;
}

/****************************************/
/*	07									*/
/****************************************/
int cl_arg_to_char_opt(pparmList,Obj,pInfoParm,msg,opt)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
int       opt;
{
	return cl_arg_to_char_num(pparmList,Obj,pInfoParm,msg,opt,1);
}

/****************************************/
/*	08									*/
/****************************************/
int cl_ot_conv_arg(pparmList,Obj,pValue)
parmList   *pparmList;
int        *Obj;
int		   *pValue;
{
	int			rc,Value;
	tdtInfoParm 	InfoParm;
	char        *pWork,*name;

	name = "cl_ot_conv_arg";
	pWork = pparmList->prp;
	rc = cl_gx_exp_obj(1,&pparmList,Obj,&InfoParm);
	if (rc) {
		ERROROUT2(FORMAT(45),name,pWork);	/* %s: �p�����[�^[%s]������Ă��܂��B */
		return ECL_EX_OUTPUT;
	}

	if (InfoParm.pi_attr != DEF_ZOK_BINA) {
		ERROROUT2(FORMAT(46),name,pWork);	/* "%s: �p�����[�^[%s]�����l�ł͂���܂���B */
		return ECL_EX_OUTPUT;
	}

/*	memcpy(pValue,InfoParm.pi_data,sizeof(int));	*/
	*pValue = Value = cl_get_data_long(&InfoParm);

	if (Value < 0 || Value > 99999) {
		ERROROUT2(FORMAT(116),name,Value);	/* %s: �l(%d)���͈͊O(0-99999)�ł��B */
		rc = ECL_EX_OUTPUT;
	}

	return rc;
}
