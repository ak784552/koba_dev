static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �R�}���h�����ϊ�                                       *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_arg(pparmList)                             *
*                      (I)prmList	*pparmList                                *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
/********************************************/
/*	  coded by A.Kobayashi() 2010.XX.XX		*/
/*	  error code : -215120101�`-215129999	*/
/********************************************/
#include "colmn.h"

extern char cmp_sep2[];

/****************************************/
/*	01									*/
/****************************************/
int cl_conv_arg_opt_kind(pparmList,pInfoParm,opt,rc)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
int opt,rc;
{
/*
printf("cl_conv_arg_opt_kind: kind=%d opt=%08x\n",rc,opt);
*/
	switch (rc) {
		case	PARAMETER :
			rc = cl_conv_parm_opt(pparmList,pInfoParm,opt);
			break;
		case	CONSTANT_NUM :
			rc = cl_conv_const_n(pparmList,pInfoParm);
			break;
		case	CONSTANT_CHR :
			rc = cl_conv_const_c(pparmList,pInfoParm);
			break;
		case	CONSTANT_CMD :
			rc = cl_conv_const_cmd(pparmList,pInfoParm);
			break;
		case	SYSVAR :
			rc = cl_conv_sysvar(pparmList,pInfoParm);
			break;
		case	NULL_PARM :
			rc = cl_null_parm(pInfoParm);
			break;
		case	0 :
			rc = D_ERROR;
			break;
		case	SEPARATOR :
			break;
		default:
			cl_set_parm_char2(pInfoParm,pparmList->prp,pparmList->prmlen,GET_TYPE_OPT(pparmList->opt));
			rc = NAME_CONST;
			break;
	}
	return rc;
}

/****************************************/
/*	02									*/
/****************************************/
int cl_conv_arg_opt(pparmList,pInfoParm,opt)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
int opt;
{
	int	rc,pLlen,iDATA;
	char *pLprp;
	parmList tparmList;
	

	opt &= ~D_GX_OPT_STORE;
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pLlen = pparmList->prmlen;
	pLprp = pparmList->prp;
	iDATA = 0;
	if (*pLprp == '*') {
		pparmList = &tparmList;
		pLlen--;
		pLprp++;
		pparmList->prmlen = pLlen;
		pparmList->prp = pLprp;
		iDATA = DEF_ZOK_DATA;
	}
	rc = cl_anal_parm(pparmList);
	if (rc==PARAMETER || rc==CONSTANT_NUM || rc==CONSTANT_CHR || rc==SYSVAR) {
		if ((rc=cl_conv_arg_opt_kind(pparmList,pInfoParm,opt,rc)) >= 0) {
			if (pInfoParm->pi_id == 'S') {
				pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			}
			pInfoParm->pi_aux[0] |= iDATA;
			rc = 0;
		}
DEBUGOUT_InfoParm(110,"cl_conv_arg_opt: rc=%d iDATA=%08x",pInfoParm,rc,iDATA);
	}
	else {
				/* %s: �p�����[�^[%s]������Ă��܂��B*/
		ERROROUT2(FORMAT(45),"cl_conv_arg_opt",pparmList->prp);
		rc = ECL_SCRIPT_ERROR;

	}
	return rc;
}

/****************************************/
/*	03									*/
/****************************************/
int cl_conv_arg(pparmList,pInfoParm)
parmList   *pparmList;
tdtInfoParm  *pInfoParm;
{
	return cl_conv_arg_opt(pparmList,pInfoParm,0);
}

/* K-00057 �ȉ��ǉ� */
/****************************************/
/*	04									*/
/****************************************/
int cl_arg_to_var(pparmList,Obj,pprList)
parmList *pparmList;
int      *Obj;
prmList  *pprList;
{
	int	rc;
	tdtInfoParm  InfoParm;

	memset(pprList,0,sizeof(prmList));
	rc = cl_gx_exp_obj(1,&pparmList,Obj,&InfoParm);
	if (rc == NORMAL) {
		rc = cmpktform(pprList,&InfoParm);
	}
	return(rc);
}

/****************************************/
/*	05									*/
/****************************************/
int cl_arg_to_char(pparmList,Obj,pInfoParm,msg)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
{
	return cl_arg_to_char_opt(pparmList,Obj,pInfoParm,msg,0);
}

/****************************************/
/*	06									*/
/****************************************/
int cl_arg_to_char_num(pparmList,Obj,pInfoParm,msg,opt,only_char)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
int       opt;
int       only_char;	/* =0:char or num, =1: only char,
						   =2:$%#name,'XYZ',func()�̂ݕϊ����� */
{
	int  rc,len,atr,opt_type,code_type,kind,iEXP;
	char *p,*dat,c;

	if (!(p=msg)) p = FORMAT(297);	/* �p�����[�^ */
#if 1	/* 2020.3.1 */
	dat = pparmList->prp;
	len = pparmList->prmlen;
	code_type = GET_TYPE_OPT(pparmList->opt);
DEBUGOUTL3(120,"cl_arg_to_char_num:Enter len=%d dat=[%s] p=[%s]",len,dat,p);
	/* 2020.3.15 */
	if (!cl_chk_name_opt(dat,len,pparmList->opt)) {
DEBUGOUTL3(120,"cl_arg_to_char_num: NAME_CONST rc=%d len=%d dat=[%s]",rc,len,dat);
		return cl_set_parm_char2(pInfoParm,dat,len,code_type);
	}
#endif
	kind = cl_anal_parm(pparmList);
/*
printf("cl_arg_to_char_num: kind=%d only_char=%d\n",kind,only_char);
*/
	if (kind < 0) {
		ERROROUT1(FORMAT(298),p);	/* %s�擾�G���[ */
		return kind;
	}
	else if (kind == NULL_PARM) {
		rc = cl_null_parm(pInfoParm);
	}
	else {
		rc = 0;
		len = pparmList->prmlen;
		dat = pparmList->prp;
		opt_type = pparmList->opt & CD_TYPE_OPT_MASK;
/*
printf("cl_arg_to_char_num: opt_type=%08x len=%d dat=[%s]\n",opt_type,len,dat);
*/
		iEXP = 0;
		if (kind == NAME_CONST) {
			if (only_char==1 && ((c=*dat)=='-' || c=='+')) ;	/* {-|+}parameter */
			else {
				if (akx_skip_opt(dat,len,cmp_sep2+2,0x08 | opt_type) < len) iEXP = 1;	/* skip_to */
			}
			if (!iEXP) {
				rc = cl_set_parm_char(pInfoParm,dat,len);
DEBUGOUTL2(120,"cl_arg_to_char_num: NAME_CONST2 len=%d dat=[%s]",len,dat);
				return rc;
			}
		}
#if 1	/* 2023.8.12 */
/*
printf("cl_arg_to_char_num: iEXP=%d\n",iEXP);
*/
		if (only_char == 2) {
			if (iEXP==1 || kind==CONSTANT_CHR || kind==PARAMETER) {
			/*
				if ((rc=cl_gx_exp_obj_opt(1,&pparmList,Obj,pInfoParm,opt)) < 0) return rc;
				if ((len=parm_to_char_tmp(pInfoParm,&dat,0)) < 0) return len;
			*/
				;
			}
			else
			return cl_set_parm_char(pInfoParm,dat,len);
		}
#endif
		if (!rc) rc = cl_gx_exp_obj_opt(1,&pparmList,Obj,pInfoParm,opt);
		if (rc) {
			ERROROUT2(FORMAT(299),p,dat);	/* %s[%s]�Ɍ�肪����܂��B */
			rc = ECL_SCRIPT_ERROR;
		}
		else {
DEBUGOUT_InfoParm(120,"cl_arg_to_char_num: ",pInfoParm,0,0);
			atr = pInfoParm->pi_attr;
#if 1	/* 2023.8.11 */
			if (only_char == 2) {
				if (atr != DEF_ZOK_CHAR) {
					if ((rc=parm_to_char_tmp(pInfoParm,&dat,0)) < 0) return rc;
/*
printf("cl_arg_to_char: rc=%d dat=[%s]\n",rc,dat);
*/
					rc = cl_set_parm_char(pInfoParm,dat,rc);
				}
			}
			else
#endif
			if (only_char==1 && atr != DEF_ZOK_CHAR) {
				ERROROUT2(FORMAT(300),p,dat);	/* %s[%s]�������^�ł͂���܂���B */
				rc = ECL_SCRIPT_ERROR;
			}
			else if (atr==DEF_ZOK_CHAR || atr==DEF_ZOK_BINA ||
			         atr==DEF_ZOK_FLOA || atr==DEF_ZOK_DECI) ;
			else {
				ERROROUT2(FORMAT(45),p,dat);	/* %s: �p�����[�^[%s]������Ă��܂��B */
				rc = ECL_SCRIPT_ERROR;
			}
		}
	}
	return rc;
}

/****************************************/
/*	07									*/
/****************************************/
int cl_arg_to_char_opt(pparmList,Obj,pInfoParm,msg,opt)
parmList  *pparmList;
int       *Obj;
tdtInfoParm *pInfoParm;
char      *msg;
int       opt;
{
	return cl_arg_to_char_num(pparmList,Obj,pInfoParm,msg,opt,1);
}

/****************************************/
/*	08									*/
/****************************************/
int cl_ot_conv_arg(pparmList,Obj,pValue)
parmList   *pparmList;
int        *Obj;
int		   *pValue;
{
	int			rc,Value;
	tdtInfoParm 	InfoParm;
	char        *pWork,*name;

	name = "cl_ot_conv_arg";
	pWork = pparmList->prp;
	rc = cl_gx_exp_obj(1,&pparmList,Obj,&InfoParm);
	if (rc) {
		ERROROUT2(FORMAT(45),name,pWork);	/* %s: �p�����[�^[%s]������Ă��܂��B */
		return ECL_EX_OUTPUT;
	}

	if (InfoParm.pi_attr != DEF_ZOK_BINA) {
		ERROROUT2(FORMAT(46),name,pWork);	/* "%s: �p�����[�^[%s]�����l�ł͂���܂���B */
		return ECL_EX_OUTPUT;
	}

/*	memcpy(pValue,InfoParm.pi_data,sizeof(int));	*/
	*pValue = Value = cl_get_data_long(&InfoParm);

	if (Value < 0 || Value > 99999) {
		ERROROUT2(FORMAT(116),name,Value);	/* %s: �l(%d)���͈͊O(0-99999)�ł��B */
		rc = ECL_EX_OUTPUT;
	}

	return rc;
}

/****************************************/
/*	21									*/
/****************************************/
int cl_gx_exp_obj_opt(nparm,prmp,Obj,pInfoParm,opt)
int nparm;
parmList *prmp[];
int *Obj;
tdtInfoParm *pInfoParm;
int opt;
{
	int rc,len,i,n;
	char *p,*pOperator,*argv[256],work[512];
	tdtInfoParm InfoParm1,InfoParm2;
	parmList *parm,*pparm[256];
/*
printf("cl_gx_exp_obj_opt: nparm=%d opt=%08x\n",nparm,opt);
*/
	if (nparm > 0) {
		if (nparm == 1) {
/*
printf("cl_gx_exp_obj_opt: prmp[0]=%08x\n",prmp[0]);
*/
			p   = prmp[0]->prp;
			len = prmp[0]->prmlen;
/*
printf("cl_gx_exp_obj_opt: len=%d p=[%s]\n",len,p);
*/
			if ((n=cl_getitems(p,len,argv,256,work,sizeof(work)," \t")) < 0) return n;
		/*	if ((n=akxtgetargvns2(p,len,argv,256,work,sizeof(work)," ",0x10000)) < 0) return n;	*/
			else if (n >= 1) {
				len = n*sizeof(parmList);
				if (!(parm=(parmList *)cl_tmp_const_malloc(len))) return ECL_MALLOC_ERROR;
				memset(parm,0,len);
				for (i=0;i<n;i++) {
					pparm[i] = parm++;
					pparm[i]->prp = argv[i];
					pparm[i]->prmlen = strlen(argv[i]);
/*
printf("cl_gx_exp_obj_opt: i=%d argv[i]=[%s]\n",i,argv[i]);
*/
				}
				prmp = pparm;
				nparm = n;
			}
/*
printf("cl_gx_exp_obj_opt: n=%d\n",n);
*/
		}
		if (nparm == 2) {
			pOperator = prmp[0]->prp;
			cl_none_parm(&InfoParm1);
			rc = cl_conv_arg_opt(prmp[1],&InfoParm2,opt);
/*
printf("cl_gx_exp_obj_opt:1 rc=%d pOperator=[%s] var=[%s]\n",rc,pOperator,prmp[1]->prp);
*/
		}
		else if (nparm==1 || nparm>=3) {
			rc = 0;
			if (nparm >= 3) {
				pOperator = prmp[1]->prp;
				len = prmp[1]->prmlen;
				if (!cl_gx_is_operator(pOperator,COMP) && *(pOperator+len-1) == '=') {
					return cl_gx_compute_sub(nparm,prmp,NULL,opt);
				}
				rc = cl_conv_arg_opt(prmp[2],&InfoParm2,opt);
/*
printf("cl_gx_exp_obj_opt:2 rc=%d\n",rc);
*/
			}
			if (rc >= 0) {
				rc = cl_conv_arg_opt(prmp[0],pInfoParm,opt);
/*
printf("cl_gx_exp_obj_opt:3 rc=%d\n",rc);
*/
				if (nparm >= 3) cl_gx_copy_info(&InfoParm1,pInfoParm);
			}
		}
		if (rc>=0 && nparm >= 2) {
			rc = cl_gx_bexp(pInfoParm,&InfoParm1,pOperator,&InfoParm2,nparm-3,prmp+3);
/*
printf("cl_gx_exp_obj_opt:4 rc=%d\n",rc);
*/
		}
	}
	else {
		cl_null_value(pInfoParm);
		rc = 0;
	}
	if (rc) {
	}
	return rc;
}

/****************************************/
/*	22									*/
/****************************************/
int cl_gx_exp_obj(nparm,pparmList,Obj,pInfoParm)
int nparm;
parmList *pparmList[];
int *Obj;
tdtInfoParm *pInfoParm;
{
	return cl_gx_exp_obj_opt(nparm,pparmList,Obj,pInfoParm,0);
}

/****************************************/
/*	23									*/
/****************************************/
int cl_gx_expsn_obj_opt(buf,len,bxobj,Obj,pInfoParmW,opt)
char *buf;
int  len;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	parmList parmList,*prmp[2];
/*
printf("cl_gx_expsn_obj_opt: len=%d buf=[%s]\n",len,buf);
*/
	parmList.prmlen = len;
	parmList.prp = buf;
	parmList.opt = 0;
	parmList.bxobj = NULL;
	prmp[0] = &parmList;
	return cl_gx_exp_obj_opt(1,prmp,Obj,pInfoParmW,opt);
}

/****************************************/
/*	24									*/
/****************************************/
int cl_gx_exps_obj_opt(buf,bxobj,Obj,pInfoParmW,opt)
char *buf;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	return cl_gx_expsn_obj_opt(buf,strlen(buf),bxobj,Obj,pInfoParmW,opt);
}

/****************************************/
/*	25									*/
/****************************************/
int cl_skip_scope_mark(pLprp,pLlen,pix)
char *pLprp;
int pLlen,*pix;
{
	char buf[D_LEN_SCOPE_MARK+1];
	int rc,ix;

	rc = 0;
	if (!pLprp) return -1;
	ix = 0;
	if (*pLprp == '<') {
		memzcpy(buf,pLprp,D_LEN_SCOPE_MARK);
		if (!(ix=cl_get_def_scope(buf))) {
			ERROROUT2(FORMAT(135),"cl_skip_scope_mark",buf);	/* %s: Invalid scope name[%s] */
			return -1;
		}
		rc = D_LEN_SCOPE_MARK;
	}
	if (pix) *pix = ix;
	return rc;
}

/****************************************/
/*	26									*/
/****************************************/
int cl_conv_parm_func(pInfoParmW,vname,vnlen,opt)
tdtInfoParm *pInfoParmW;
char *vname;
int  vnlen,opt;
{
	char *_fn_="cl_conv_parm_func";
	tdtInfoParm InfoParm,*pInfoParm;
	char *pOperator,fun_nam[2];
	int  rc,n,nparm,index,atr,posa[2],iParm[4];

DEBUGOUTL4(120,"%s:Enter: vname=[%s] vnlen=%d opt=%08x",_fn_,vname,vnlen,opt);

	rc = 0;
	pOperator = vname;
	pInfoParm = &InfoParm;
	vnlen--;
	vname++;
	n = instr2(vname,vnlen,"(",")",posa);
/*
printf("%s: n=%d\n",_fn_,n);
*/
	if (n == 1) {
		rc = -215122601;
	}
	else {
		if (n == 2) {
			vnlen -= 2;
			vname++;
		}
		if (!vnlen) nparm = 0;
		else {
			if ((rc=cl_gx_expsn_obj_opt(vname,vnlen,NULL,NULL,pInfoParm,0)) < 0) return rc;
			if (pInfoParm->pi_id == ' ') {
				if ((atr=pInfoParm->pi_attr) == DEF_ZOK_CHAR) {
					cl_get_parm_bin(pInfoParm,&index,"get index");
				}
				else if (atr == DEF_ZOK_BINA) index = 1;
				cl_set_parm_long(pInfoParm,index);
			}
			else index = 0;
			if (index <= 0) {
				iParm[0] = pInfoParm->pi_attr;
				iParm[1] = iParm[2] = iParm[3] = 0;
				ERROROUT2(FORMAT(218),_fn_,cl_get_attr_name(iParm));	/* %s: INDEX�̌^[%s]�������Ă��܂���B */
				rc = -215122602;
			}
			nparm = 1;
		}
	}
	if (rc >= 0) {
		memzcpy(fun_nam,pOperator,1);
		rc = cl_func_conv_parm(pInfoParmW,fun_nam,nparm,&pInfoParm,0,opt);
	}
	return rc;
}

/****************************************/
/*	27									*/
/****************************************/
int cl_getitems(buf,buf_len,item,maxitem,parm,parm_len,sep)
char *buf,*item[],*parm,*sep;
int buf_len,maxitem,parm_len;
{
	static char *gwsep=" \n'\"(){}[]";
	int rc,n,len,kk1,kk2,kk3,disp,ips,wlen,pmlen,bflen;
	char c,cs,*ps,*pm;
	SSPL_S sspl;

printf("cl_getitems:Enter: buf_len=%d buf=[%s]\n",buf_len,buf);

	cl_chk_act(-1);
	memset(&sspl,0,sizeof(SSPL_S));
	kk1 = kk2 = kk3 = disp = n = ips = 0;
	ps = buf;
	pm = parm;
	bflen = buf_len;
	pmlen = parm_len;
	sspl.sp = 0;
	sspl.wd = pm;
	sspl.wdmax = pmlen - 1;
	while (bflen > 0) {
		if ((len=akxnskipin(ps,bflen,sep)) == bflen) break;
		else if (len > 0) {
			bflen -= len;
			ps    += len;
			sspl.sp = 0;
			sspl.wd = pm;
			sspl.wdmax = pmlen - 1;
printf("cl_getitems: skip len=%d\n",len);
		}
		if ((len=akxtgwnsl(ps,bflen,&sspl,gwsep,1)) > 0) {
printf("cl_getitems: disp=%d getw len=%d wd=[%s]\n",disp,len,sspl.wd);
			c = *sspl.wd;
			cs = *(ps+sspl.sp);
			if (instrchar("(){}[]",c) > 0) {
				if (cl_chk_act(c) < 0) {
					n = ECL_SCRIPT_ERROR;
					break;
				}
				if (c == '(') kk1++;
				else if (c == ')') kk1--;
				else if (c == '{') kk2++;
				else if (c == '}') kk2--;
				else if (c == '[') kk3++;
				else if (c == ']') kk3--;
				if (!(kk1+kk2+kk3)) disp = 0;
				else disp = 1;
printf("cl_getitems: c=%c cs=%c disp=%d kk1=%d kk2=%d kk3=%d\n",c,cs,disp,kk1,kk2,kk3);
			}
		}
		else {
			c = cs = '\0';
		}
		if ((!disp && instrchar(sep,cs)>0) || len<0) {
			wlen = sspl.sp;
			if (pmlen <= wlen) break;
			memzcpy(pm,ps,wlen);
			item[n++] = pm;
printf("cl_getitems: n=%d wlen=%d pm=[%s]\n",n,wlen,pm);
			ps += wlen;
			bflen -= wlen;
			pm += wlen + 1;
			pmlen -= wlen + 1;
			disp = 0;
		}
	}
	if (disp) {
		wlen = sspl.sp - 1;
		if (pmlen > wlen) {
			memzcpy(pm,ps,wlen);
			item[n++] = pm;
printf("cl_getitems: disp=%d n=%d wlen=%d pm=[%s]\n",disp,n,wlen,pm);
		}
	}
printf("cl_getitems:Exit: n=%d\n",n);
	return n;
}
