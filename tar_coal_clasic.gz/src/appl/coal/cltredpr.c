static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_end_proc            */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */
#endif
/*********************************************/
/*                                           */
/*********************************************/

int col_mn_tr_end_proc(y)
condList *y;
{
	int  rc,cmdid,cmd;
	char *name;

	name = "col_mn_tr_end_proc";
	if (y->cmd->prmnum > 0) {
		ERROROUT1(FORMAT(41),name);
		return ( ECL_TR_ENDPROC );
	}

	cmdid = y->cmd->cid;
	if (cmdid == C_ENDPROC) cmd = C_PROC;
	else {
		ERROROUT2(FORMAT(318),name,cl_gets_cmd_name(cmdid));	/* %s: %s�͎g�p�ł��܂���B*/
		return ECL_TR_ENDPROC;
	}
	rc = cl_nest_tag(y,1);
	if (rc == -1) {
		ERROROUT2(FORMAT(76),name,cl_gets_cmd_name(cmd));	/* "%s: %s������܂���B */
		return ECL_TR_ENDPROC;
	}
	if (rc != cmd) {
		ERROROUT2(FORMAT(77),name,cl_gets_cmd_name(rc));	/* %s: %s�Ƃ̑Ή������Ă��܂���B */
		return ECL_TR_ENDPROC;
	}
/*	for(;;)
	{	*/
		if (y->clstcb->nestLev2) {
			rc = cl_nest_tag(y,2);
			if (rc == -1) return rc;
			else {
			/*	if (rc=cl_change_tree( CLSTCB.nestLev2 )) return (rc);
				cl_search_nest( 2 );
				ERROROUT1(FORMAT(78),name);*/
				ERROROUT2(FORMAT(79),name,cl_gets_cmd_name(rc));	/* %s: %s��END���Ă��܂���B */
				return ECL_TR_ENDPROC;
			}
		}
/*		else
		{
			break;
		}
	}	*/

	if (rc = cl_make_leaf(y)) return rc;
	if (rc = cl_push(y)) return rc;
	rc = cl_nest_tag(y,1);
	if (rc == -1) return ECL_TR_ENDPROC;
	else {
		rc=cl_change_tree(y,y->clstcb->nestLev1);
	/*	if (rc) return (rc);	*/
		cl_search_nest(y,1);
	}
	return NormalEnd;
}
