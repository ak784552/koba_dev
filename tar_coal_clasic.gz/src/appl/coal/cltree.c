static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************/
/*  <clTree>										*/
/*  �����Ǘ�										*/
/*	�\����͉�͖؍쐬���|�`��						*/
/****************************************************/
#include "colmn.h"

extern int giOptions[];
extern GlobalCt  *pGlobTable;

static int _tr_end();

/**************************************************/
/* cl_tree_main (select process as kind of tag)	 */
/**************************************************/
int cl_tree_main(y)
condList *y;
{
	int rc,cmnd;
	char *name,*p;
	ScrPrCT *scrptct;
	cmdInfo *cmd;
	ParList *pal;
/*
printf("cl_tree_main:Enter: cmd=%s\n",cl_gets_cmd_name(y->cmd.cid));
*/
	cmd = y->cmd;

DEBUGOUTL2(110,"cl_tree_main:Enter: cid=%08x cmd=%s",cmd->cid,cl_gets_cmd_name(cmd->cid));

	switch (cmnd=cmd->cid) {
		case C_PROC:
		case C_DEFINE:
		case C_ONN:
		case C_DIM:
		case C_FEND:
			break;
		default:
				if (cl_nest_tag(y,1) == SysError) {
					if (cmnd == C_LET) {
						cmd->cid = C_DEFINE;
						strcpy(y->cmd->parl[2].par,"DEF");
					}
					else {
						/* cl_tree_main: [%s]��PROC/FUNC/CLASS�̊O���ł͎g�p�ł��܂���B */
						ERROROUT1(FORMAT(82),cl_gets_cmd_name(cmnd));
						return ECL_TREE;
					}
				}

	}
	switch (cmnd=cmd->cid) {
		case C_ONN:
			if (cl_nest_tag(y,1) != SysError) {
			/* cl_tree_main: [%s]��PROC/FUNC/CLASS�̓����ł͎g�p�ł��܂���B */
				ERROROUT1(FORMAT(84),cl_gets_cmd_name(cmnd));
				return ECL_TREE;
			}
			break;
	}
	switch (cmnd) {
		case C_CALL:
		case C_EXEC:		rc = col_mn_tr_exec(y);		break;
		case C_PROC:		rc = col_mn_tr_proc(y);		break;
		case C_ENDFUNC:
		case C_ENDCLASS:
		case C_ENDPROC:		rc = col_mn_tr_end_proc(y);	break;
		case C_MSG:			rc = col_mn_tr_msg(y);		break;
		case C_SQL:			rc = col_mn_tr_sql(y);		break;
		case C_LOOP:		rc = col_mn_tr_loop(y);		break;
		case C_ENDLOOP:		rc = col_mn_tr_end_loop(y);	break;
		case C_CONTINUE:	rc = col_mn_tr_continue(y);	break;
		case C_BREAK:		rc = col_mn_tr_break(y);	break;
		case C_READ:		rc = col_mn_tr_read(y);		break;
		case C_OUTPUT:		rc = col_mn_tr_output(y);	break;
		case C_ONN:			rc = col_mn_tr_on(y);		break;
		case C_IF:			rc = col_mn_tr_if(y);		break;
		case C_ELSE:		rc = col_mn_tr_else(y);		break;
		case C_ELSEIF:		rc = col_mn_tr_else_if(y);	break;
		case C_ENDIF:		rc = col_mn_tr_end_if(y);	break;
		case C_LET:
		case C_BEXP:		rc = col_mn_tr_bexp(y);		break;
		case C_SLEEP:
		case C_RETURN:		rc = col_mn_tr_return(y);	break;
		case C_FEND:		rc = col_mn_tr_file_end(y);	break;
		case C_LEAVE:		rc = col_mn_tr_leave(y);	break;
		case C_END:			rc = _tr_end(y);			break;
		default: rc = ECL_TREE;
	}
	return rc;
}

static int _tr_end(y)
condList *y;
{
	char *p;
	int  cnum,cnum1,i,num;
	cmdInfo *cmd;

	cmd = y->cmd;
	p = cmd->prmp[0]->prp;
	cnum = cl_cmd_chk_cid(p);
	if (cmd->prmnum != 1) {
		ERROROUT(FORMAT(83));	/* _tr_end: �p�����[�^���P�K�v�ł��B */
		return ECL_TREE;
	}
	switch (cnum) {
		case C_PROC:	cnum = C_ENDPROC;	break;
		case C_LOOP:	cnum = C_ENDLOOP;	break;
		case C_IF:		cnum = C_ENDIF;		break;
		default:
			ERROROUT2(FORMAT(45),"_tr_end",p);	/* %s: �p�����[�^[%s]������Ă��܂��B */
			return ECL_TREE;
	}
	cmd->cid = cnum;
	cmd->prmnum = 0;
	return cl_tree_main(y);
}
