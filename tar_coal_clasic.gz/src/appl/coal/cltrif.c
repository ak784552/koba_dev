static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_if                  */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Justify no shori.                         */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/********************************************/
/*											*/
/********************************************/
static int _parmset(y,p,len)
condList *y;
char *p;
int len;
{
	int rc;
	ParList parl;
/*
printf("_parmset:Enter: len=%d\n",len);
*/
	rc = 0;
#if 1	/*2024.5.24 */
	if ((len=akxtstrim2(0x04,p,len,&parl," \t")) > 0)
		rc = clparmset(y,parl.par,parl.parlen);
#else
#if 1
	if ((len=akxtstrim(0,p,len," \t")) > 0)	/* 1-->0 2018.10.14 */
#else
	if (akxnskipin(p,len," \t") < len)
#endif
		rc = clparmset(y,p,len);
#endif
/*
printf("_parmset:Exit : len=%d\n",len);
*/
	return rc;
}
/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_if(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum == 0) {
		ERROROUT(FORMAT(91));	/* col_mn_tr_if: �_�������K�v�ł��B */
		return ECL_TR_IF;
	}
/*	if ((rc = cl_tr_gather(y,0)) >= 0)	*/
		rc = cl_make_push_leaf(y);
	return rc;
}
