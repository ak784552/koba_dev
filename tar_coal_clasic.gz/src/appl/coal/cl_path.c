static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*******************************************************/
/* <cldPath.c>                                         */
/*      exec command  process                          */
/*******************************************************/
#include "colmn.h"

#undef DEBUG

extern condList *pCLcList;		/* ��񃊃X�g */
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable;

/**************************************************************/
/* cl_process_msg_pre_send                                    */
/**************************************************************/
int cl_process_msg_pre_send(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc = 0, cmd;

	if (leaf) {
		cmd = leaf->cmd.cid;
		proc->Curleaf = leaf;
		cl_ret_leaf_push(proc,leaf);
		if (cmd == C_SQL)
			rc = cl_process_sqlsnd(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		else if (cmd == C_SLEEP)
			rc = cl_process_sleep_snd(leaf->cmd.prmnum,leaf->cmd.prmp,proc);
		else if (cmd == C_MSG)
			rc = cl_process_messag_send(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		if (rc == ECL_EX_MSG_NO_SLEEP) {
			rc = 0;
		}
		else if (rc) {
			pGlobTable->error = rc;
			if (!pGlobTable->exception)
				pGlobTable->exception = cl_mk_exception_code(COMM_EXCEPTION,rc);
			pGlobTable->tuppl = 0;
		}
		else {
			cmn_set_stat(RTN_PR,&pCLprocTable->PrSt,L_ON);
			cmn_set_stat(RTN_PR,&proc->ptype,L_ON);
		}
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_msg_pre_return                                  */
/**************************************************************/
int cl_process_msg_pre_return(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
	ScrPrCT *scrprct;
	ProcCT  *procct;
	int rc, cmd;

	if (leaf) {
		procct = cl_search_proc_ct();
		if ((cmd=leaf->cmd.cid) == C_SQL)
			rc = cl_process_sqlrcv(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		else if (cmd == C_SLEEP)
			rc = cl_process_sleep_rcv(leaf->cmd.prmnum,leaf->cmd.prmp);
		else if (cmd == C_MSG)
			rc = cl_process_message_recv(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
		if (pCLprocTable->WaitPacketp) Free(pCLprocTable->WaitPacketp);
		pCLprocTable->WaitPacketp = NULL;
		cmn_set_stat(RTN_PR,&procct->ptype,L_OFF);
		cmn_set_stat(RTN_PR,&pCLprocTable->PrSt,L_OFF);
	}
	else {
		ERROROUT("cl_process_msg_pre_return:leaf==NULL");
		rc = ECL_SYSTEM_ERROR;
	}

	return rc;
}

/**************************************************************/
/* cl_proc_bexp                                               */
/**************************************************************/
int cl_process_bexp(cid, leaf, proc)
int     cid;
Leaf    *leaf;
ProcCT  *proc;
{
	int rc;

	if (leaf && proc) {
		if (cid == C_BEXP) rc = cl_proc_bexp(leaf,proc);
		else rc = cl_process_let(leaf,proc);
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_read                                            */
/**************************************************************/
int cl_process_read(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc;

	if (leaf && proc) {
		rc = cl_proc_read(leaf->cmd.prmnum,leaf->cmd.prmp,proc->Obj);
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_output                                          */
/**************************************************************/
int cl_process_output(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int   rc;

	if (leaf && proc)  rc = cl_proc_output(leaf,proc);
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_leave                                           */
/**************************************************************/
int cl_process_leave(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	int rc;

	if (leaf && proc) {
		/* �k�d�`�u�d�������s */
		rc = cl_proc_leave(leaf, proc);
	}
	else rc = ECL_SYSTEM_ERROR;

	return rc;
}

/**************************************************************/
/* cl_process_messag_send                                     */
/**************************************************************/
int cl_process_messag_send(nprm,prmp,pbxobj)
int nprm;
parmList *prmp[];
GXObject *pbxobj[];
{
	char *p;
	int rc;

	p = prmp[0]->prp;
 	if (!stricmp(p,"SEND") ||
 	    !stricmp(p,"POST") ||
 	    !stricmp(p,"REPLY"))
			rc = cl_process_msg_snd(nprm,prmp,pbxobj);
	else if (!stricmp(p,"SQL"))
			rc = cl_process_sqlsnd(nprm-1,prmp+1,pbxobj);
	else if (!stricmp(p,"SLEEP"))
			rc = cl_process_sleep_snd(nprm-1,prmp+1,pbxobj);
	else {
		ERROROUT1("[%s] not SQL,SLEEP,SEND,POST,REPLY",p);
		rc = ECL_EX_MSG;
	}
	return rc;
}

/**************************************************************/
/* cl_process_message_recv                                    */
/**************************************************************/
int cl_process_message_recv(nprm,prmp,pbxobj)
int nprm;
parmList *prmp[];
GXObject *pbxobj[];
{
	char *p;
	int rc;

	p = prmp[0]->prp;
 	if (!stricmp(p,"SEND") ||
 	    !stricmp(p,"POST") ||
 	    !stricmp(p,"REPLY"))
			rc = cl_process_msg_rcv(nprm,prmp,pbxobj);
	else if (!stricmp(p,"SQL"))
			rc = cl_process_sqlrcv(nprm-1,prmp+1,pbxobj);
	else if (!stricmp(p,"SLEEP"))
			rc = cl_process_sleep_rcv(nprm-1,prmp+1);
	else {
		ERROROUT1("[%s] not SQL,SLEEP,SEND,POST,REPLY",p);
		rc = ECL_SYSTEM_ERROR;
	}
	return rc;
}
