static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       long       col_mn_tr_else               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else(y)
condList *y;
{
	static int able[]={C_IF,C_ELSEIF};
	static int deny[]={C_ELSE};
	char *p;
	int  cnum,i;
	int  rc;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum > 0) {
		p = cmd->prmp[0]->prp;
		cnum = cl_cmd_chk_cid(p);
		if (cnum == C_IF) {
			cmd->cid = C_ELSEIF;
			cmd->prmnum--;
			for (i=0;i<cmd->prmnum;i++)
				cmd->prmp[i]->prp = cmd->prmp[i+1]->prp;
			return col_mn_tr_else_if(y);
		}
		else {
			/* %s: �]���ȃp�����[�^[%s]������܂��B */
			ERROROUT2(FORMAT(43),"col_mn_tr_else",p);
			return ECL_TR_ELSE;
		}
	}
	if (!(rc=cl_tr_end_node_check(y,deny,1,able,2))) rc = cl_tr_else_nest_check(y);
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_else_nest_check(y)
condList *y;
{
	int  rc ,tree;

	tree = cl_nest_tag(y,2);
	if ( tree != -1 ) {
		rc=cl_change_tree(y,y->clstcb->nestLev2 );
/*
		if (rc) return (rc);
*/
		cl_search_nest(y,2);
	}
	else return ECL_TR_ELSE;

	return cl_make_push_leaf(y);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_elseNode(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_prmnum_check(y))) {
		if (!(rc=cl_tr_end_node_check(y,deny,nd,able,na))) rc = cl_tr_else_nest_check(y);
	}
	return rc;
}
