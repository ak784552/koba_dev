static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************************/
/* <clpron.c>                                        */
/*      On process   �@�@�@                          */
/*****************************************************/

#include "colmn.h"

extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */
extern CLPRTBL   CLprocTable;
extern CLCOMMON CLcommon;

extern int cl_process_define_exec();
int cl_pr_ex_on();

/************************************/
/* cl_process_top_exec              */
/************************************/
int cl_process_top_exec(scrct,top_leaf,func1,ncmd,cmd_cid,func2)
ScrPrCT  *scrct;
Leaf *top_leaf;
int (*func1)();
int ncmd,cmd_cid[];
int (*func2[])();
{
	Leaf *leaf,*leafw;
	int cno,rc=0;

	if (!scrct || !top_leaf || !func1) return ECL_SYSTEM_ERROR;
	leaf = top_leaf;
	while (leaf) {
		if ((cno=leaf->cmd.cid)==C_NODE_SCRIPT || cno==C_NODE_IMPORT) {
			if (leafw=leaf->leftleaf) {
				leafw->pFlag |= D_LEAF_IMPORTMODE;			/* 2021.7.14 add */
				rc = func1(scrct,leafw,ncmd,cmd_cid,func2);
				if (rc) break;
			}
			leaf = leaf->rightleaf;
		}
		else {
			rc = func1(scrct,leaf,ncmd,cmd_cid,func2);
			break;
		}
	}
	return rc;
}

/************************************/
/* cl_process_define_exec           */
/************************************/
int cl_process_define_exec(scrct,leaf,ncmd,cmd_cid,func)
ScrPrCT  *scrct;
Leaf *leaf;
int ncmd,cmd_cid[];
int (*func[])();
{
	int rc,cno,i,iIMPORT;

	if (!leaf) return ECL_SYSTEM_ERROR;

	rc = 0;
	iIMPORT = leaf->pFlag & D_LEAF_IMPORTMODE;	/* 2021.7.14 add */
/*
printf("cl_process_define_exec: iIMPORT=%08x\n",iIMPORT);
*/
	while (leaf && rc==NormalEnd) {
		cno=leaf->cmd.cid;
		if (cno==C_PROC || cno==C_FUNCTION || cno==C_CLASS) break;
		else if (cno == C_NODE_DEFINE) leaf = leaf->leftleaf;
		else {
			/* 2021.7.1 */
/*
printf("cl_process_define_exec: leaf->pFlag=%8x\n",leaf->pFlag);
*/
			if (!(leaf->pFlag & D_LEAF_DEF_EXECUTED)) {
				for (i=0;i<ncmd;i++) {
					if (cno == cmd_cid[i]) {
DEBUGOUTL1(100,"[ %s ]",cl_get_pcmd_line(leaf));
						if (CLcommon.dbgopt[0]) {
							cl_debug_mode(leaf,NULL,0);
						}
						scrct->sc_pFlag2 &= ~D_SC_PFLAG2_EXTERN;	/* add 2024.3.3 */
						rc = func[i](leaf,scrct,NULL,D_GX_OPT_DEFINE);	/* 0->D_GX_OPT_DEFINE 2023.9.7 */
						if (rc) {
							clerrdisp(rc,leaf);
							return rc;
						}
/*
printf("cl_process_define_exec: sc_pFlag2=%02x\n",scrct->sc_pFlag2);
*/
						if (scrct->sc_pFlag2 & D_SC_PFLAG2_EXTERN) {	/* add 2024.3.3 */
							/* 2021.7.1 */
							if (iIMPORT) leaf->pFlag |= D_LEAF_DEF_EXECUTED;	/* 2021.7.14 add if (iIMPORT) */
						}
						scrct->sc_pFlag2 &= ~D_SC_PFLAG2_EXTERN;	/* add 2024.3.3 */
						break;
					}
				}
			}
			leaf = leaf->rightleaf;
		}
	}
	return rc;
}

/************************************/
/* cl_process_on                    */
/************************************/
int cl_process_on(scrct)
ScrPrCT  *scrct;
{
	int cmd[1];
	int (*func[1])();

	cmd[0] = C_ONN;
	func[0] = cl_pr_ex_on;
/*	return cl_process_define_exec(scrct,C_ONN,cl_pr_ex_on);	*/
	return cl_process_top_exec(scrct,scrct->TreeTop,cl_process_define_exec,1,cmd,func);
}

/************************************/
/* cl_pr_ex_on                    */
/************************************/
int cl_pr_ex_on(leaf, scrct, dummy1,dummy2)
Leaf    *leaf;
ScrPrCT  *scrct;
int dummy1,dummy2;
{
	static char *_fn_="cl_pr_ex_on";
	int rc,iSel,num_max;
	int i,gr,offset,parmnum,err=0,k,len;
	ONTBL *ontbl;
	char *p,*pTag;
	cmdInfo *pcmd;
	parmList **prmp,*prp;

	if (!leaf || !scrct) return ECL_SYSTEM_ERROR;

	/* parameter check */
	parmnum = leaf->cmd.prmnum;
	pcmd = &leaf->cmd;
	prmp = pcmd->prmp;
/*
printf("cl_pr_ex_on: parmnum = %d\n",parmnum);
*/
	for (i=0;i<parmnum;i++) {
		if (leaf->cmd.prmp[i]->prmlen == 0) {
			ERROROUT1(FORMAT(486),_fn_);	/* %s:�p�����[�^��NULL�ł��B */
			return(ECL_SCRIPT_ERROR);
		}
	}
	pTag = NULL;
	if (parmnum > 1) {
		len = prmp[0]->prmlen;
/*
printf("cl_pr_ex_on: len=%d prp=[%s]\n",len,prmp[0]->prp);
*/
		if (!stricmp((p=prmp[0]->prp),"GR")) {
			offset = 0;
			if (parmnum < 6) err = 1;
			else if (parmnum > 8) err = 2;
		}
		else if (*p=='<' && *(p+len-1)=='>') {
			offset = -1;
			p++;
			if (*p == '?') gr = 99001;
			else if (*p == '!') gr = 99002;
			else {
				len -= 2;
				if (len > 0) pTag = p;
				gr = 99003;
			}
			if (gr == 99003) {
				if (parmnum < 5) err = 1;
				else if (parmnum > 7) err = 2;
			}
			else {
				if (parmnum < 3) err = 1;
				else if (parmnum > 3) err = 2;
			}
		}
		else {
			/* %s: ���p�����[�^�� 'GR'or '<'�ł͂���܂���B */
			ERROROUT1(FORMAT(491),_fn_);
			return ECL_SCRIPT_ERROR;
		}
	}
	else err = 1;

	if (err) {
		if (err == 1) ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂��� */
		else ERROROUT1(FORMAT(41),_fn_);	/* %s: �s�v�ȃp�����[�^������܂� */
		return ECL_EX_ON;
	}

	/* initialize */
	rc = 0;
	if (!scrct->ONCOND) {
		if (!(scrct->ONCOND=(ONTBL **)Malloc(sizeof(ONTBL *)*ON_NUM_MAX))) {
			ERROROUT("scrct->ONCOND allocate error ");
			return ECL_SYSTEM_ERROR;
		}
		memset(scrct->ONCOND,0,sizeof(ONTBL *)*ON_NUM_MAX);
		scrct->on_num_max = ON_NUM_MAX;
	}
	/* ONTBL entry search */
	num_max = scrct->on_num_max;
/*
printf("cl_pr_ex_on: num_max = %d\n",num_max);
*/
	for (i=0;i<num_max;i++) {
		if (!scrct->ONCOND[i]) break;
	}
	if (i >= num_max) {
		num_max += ON_NUM_MAX;
#if 1
		if (!(scrct->ONCOND=(ONTBL **)Realloc(scrct->ONCOND,sizeof(ONTBL *)*num_max))) {
			ERROROUT("scrct->ONCOND reallocate error ");
			return ECL_SYSTEM_ERROR;
		}
		memset(scrct->ONCOND+scrct->on_num_max,0,sizeof(ONTBL *)*ON_NUM_MAX);
		scrct->on_num_max = num_max;
/*
printf("cl_pr_ex_on: num_max = %d\n",num_max);
*/
#else
		ERROROUT("Too many ON-CONDITION.");
		return ECL_EX_ON;
#endif
	}
	/* ONTBL allocate */
	ontbl = (ONTBL *)Malloc(sizeof(ONTBL));
	if (!ontbl) {
		ERROROUT("ontbl allocate error ");
		return ECL_SYSTEM_ERROR;
	}
	memset((char *)ontbl,0,sizeof(ONTBL));
	/* ONTBL address set */
	scrct->ONCOND[i] = ontbl;

	/* parameter set */
	if (offset == 0) {
		if (axccvn(10,prmp[1]->prp,prmp[1]->prmlen,
		           &(ontbl->FldNum))) return ECL_SCRIPT_ERROR;
	}
	else {
		ontbl->FldNum = gr;
	}
/*
printf("cl_pr_ex_on: ontbl->FldNum = %d\n",ontbl->FldNum);
*/
	for (i=offset+2;i<parmnum;i++) {
		if (prp=leaf->cmd.prmp[i]) {
			switch (k=i-offset-2) {
			case 0:
			case 2:
			case 4:
				if ((iSel = cl_pr_ex_on_sel(prp)) < 0) rc = iSel;
				else ontbl->PrSel[k/2] = iSel;
				break;
			case 1:
			case 3:
			case 5:
				if (iSel == D_PRSEL_SC)
					rc=cl_pr_ex_on_sc_name(prp,&ontbl->PrName[k/2]);
				else
					rc=cl_pr_ex_on_pr_name(prp,&ontbl->PrName[k/2]);
				break;
			}
			if (rc) return rc;
		}
	}
/*
if (pTag) printf("cl_pr_ex_on: pTag=[%s]\n",pTag);
*/
	if (pTag) p = Memdup(pTag,len);
	else p = NULL;
	ontbl->PrName[3] = p;

	return rc;
}

int cl_pr_ex_on_sel(prm)
parmList *prm;
{
	int rc;

	rc = ECL_SCRIPT_ERROR;
	if (prm->prmlen == 2) {
		if      (!memicmp(prm->prp,"IP",2)) rc = D_PRSEL_IP;
		else if (!memicmp(prm->prp,"EP",2)) rc = D_PRSEL_EP;
		else if (!memicmp(prm->prp,"SC",2)) rc = D_PRSEL_SC;
	}
	return rc;
}

int cl_pr_ex_on_pr_name(prm,ppPrName)
parmList *prm;
char **ppPrName;
{
	if (prm->prmlen > PR_NM_DEF) return ECL_SCRIPT_ERROR;
	if (cl_chk_proc_name(prm->prp,prm->prmlen)) return ECL_SCRIPT_ERROR;
	if (*ppPrName = Memdup(prm->prp,prm->prmlen)) return 0;
	else return -1;
}

int cl_pr_ex_on_sc_name(prm,ppPrName)
parmList *prm;
char **ppPrName;
{
	int len,rc;
	char *name;

	len  = prm->prmlen;
	name = prm->prp;
	if (rc=cl_exe_scr_name_check(name,len)) return rc;
	if (*ppPrName = Memdup(name,len)) return 0;
	else return -1;
}
