static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clanal.c>                                                       */
/*                                                                  */
/********************************************************************/

#include "colmn.h"

extern int giProgram[];
extern CLPRTBL *pCLprocTable;

int col_mn_analz(lInstanceHandle,cpInstanceData,tpRecvMsg)
long lInstanceHandle;
char *cpInstanceData;
AKAMSGCOM *tpRecvMsg;
{
	AKAMSGCOM    tMsgCom;
	char         *pFilev[2], filename[256], val[2];
	int          iRc, iDisp, init_sc, iWaitTime;
	qDbToCol *pDTD;		/* ���M�p�P�b�g ���ʕ���   */
	TrmToSrv  qTTS;

DEBUGOUTL3(110,"col_mn_analz:Enter lInstanceHandle=%08x cpInstanceData=%08x tMsgCom=%08x",
lInstanceHandle,cpInstanceData,tMsgCom);

	iDisp = 0;
	switch (tpRecvMsg->msg_disp) {
	case AKA_REGIST_CLASS:
		/* aka_register_class()�ł��̊֐���o�^�����Ƃ��ɌĂ΂��B */
		if (cpInstanceData && *cpInstanceData == 'i') {
			/* �v���Z�X�N�����ɁA�R�}���h0x0ffffff0�̃X�N���v�g�����s���� */
			memset((char *)&qTTS,0,sizeof(TrmToSrv));
			qTTS.commandid = htonl(0x0ffffff0);
			memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
			tMsgCom.msg_clid = lInstanceHandle & 0x0000ffff;
			tMsgCom.msg_mlen = sizeof(TrmToSrv);
			tMsgCom.msg_pmsg = (char *)&qTTS;
			if ((iRc = aka_post_msg(0,&tMsgCom)) < 0)
				ERROROUT1("col_mn_analz:AKA_REGIST_CLASS: aka_post_msg ret=%d",iRc);
		}
		break;
	case 0:
		/* ���v���Z�X����̔��M���b�Z�[�W�̏����B */
		if (tpRecvMsg->msg_pret) {
			/* �ԐM�����ʃv���b�g�t�H�[�����ŃG���[�ɂȂ�Ԃ��ꂽ�B */
			break;
		}
	case 1:
		memset((char *)&tMsgCom,0,sizeof(AKAMSGCOM));
		tMsgCom.msg_filv = pFilev;
		pFilev[0] = filename;
								/* Packet Check & process flag set */
		iRc = cl_packet_check(lInstanceHandle,cpInstanceData,tpRecvMsg);
		if (iRc == 0) {
			pCLprocTable->WrPacketp = (char *)&tMsgCom;
			iRc = cl_script_main(); /* Script process */
		}

DEBUGOUTL3(150,"col_mn_analz: tMsgCom.cpMsg=%08x usDisposition=%04x iThread=%d",
tMsgCom.msg_pmsg,tMsgCom.msg_disp,pCLprocTable->iThread);

		if (tMsgCom.msg_pmsg) {
			if (pCLprocTable->iThread>0) {
				if (tMsgCom.msg_disp & 0x1000) {
					tMsgCom.msg_disp &= ~0x1000;
					memcpy(&iWaitTime,tMsgCom.msg_pmsg+tMsgCom.msg_mlen,sizeof(int));
					iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
				}
				else {
					pDTD = (qDbToCol *)tMsgCom.msg_pmsg;
					if (ntohs(pDTD->usCmdNo) == 30001) {	/* SLEEP command */
						iRc = aka_set_sleep(lInstanceHandle,1,ntohl(pDTD->lret));
					}
					else {
						tMsgCom.msg_disp = 1;
						iWaitTime = ntohl(pDTD->lret);
						pDTD->lret = 0;
						iRc = aka_send_msg_wait_time(lInstanceHandle,&tMsgCom,iWaitTime);
					}
				}

DEBUGOUTL1(150,"col_mn_analz: iRc=%d",iRc);

#if 0	/* 2024.3.17 */
				if (iRc < 0) {
					ERROROUT1("col_mn_analz: SendMsg rc=%d",iRc);
printf("col_mn_analz: SendMsg rc=%d\n",iRc);
					iRc = cl_sleep_make_packet(0);
					iRc = aka_set_sleep(lInstanceHandle,1,0);
				}
				packet_save(cpInstanceData);
				iDisp = 1;
#else
				if (iRc >= 0) {
					packet_save(cpInstanceData);
					iDisp = 1;
				}
				else {
					ERROROUT1("SendMsg rc=%d",iRc);
				}
#endif
			}
			Free(tMsgCom.msg_pmsg);
			tMsgCom.msg_pmsg = NULL;
		}
		if (!iDisp) {
			val[0] = AKA_SHUT_MODE_SHUT;
			aka_shut_control(AKA_SHUT_MODE,val);
		}
	}

DEBUGOUTL1(110,"col_mn_analz:Exit iDisp=%d",iDisp);

	return iDisp;
}
