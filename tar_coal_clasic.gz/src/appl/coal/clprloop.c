static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*******************************************************/
/* <clprloop.c>                                        */
/*      Loop process   �@�@�@                          */
/*******************************************************/

#include "colmn.h"

extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;

static int gMaxLoopWhile=0;
static int _end_each();

/************************************/
/*									*/
/************************************/
int cl_is_loop_exec(leaf,proc)
Leaf    *leaf;
ProcCT  *proc;
{
	BlockCB *next;
/*
printf("_is_loop_exec: proc->pcrBlockCB=%08x\n",proc->pcrBlockCB);
*/
	if (next=proc->pcrBlockCB) {
/*
printf("_is_loop_exec: next->iUsed=%08x leaf=%08x next->Blockleaf=%08x\n",next->iUsed,leaf,next->Blockleaf);
*/
		if (next->iUsed && leaf==next->Blockleaf) {
DEBUGOUTL2(190,"_is_loop_exec: match leaf=%08x in LoopCB=%08x",leaf,next);
			return 1;
		}
	}
	return 0;
}

/************************************/
/*									*/
/************************************/
static int _get_loop_max()
{
	tdtInfoParm *pInfoParm;
	int ret,loop_max;

#if 1	/* 2024.5.15 */
	if ((loop_max=pCLprocTable->cp_max_loop_while) > 0) {
		gMaxLoopWhile = loop_max;
#else
	if (pInfoParm = cl_get_public_var(D_NAM_MAX_LOOP_WHILE)) {
		if ((ret = cl_get_parm_bin(pInfoParm,&loop_max,"_get_loop_max:")) < 0)
			loop_max = ret;
		else gMaxLoopWhile = loop_max;
#endif

DEBUGOUTL1(190,"_get_loop_max: loop_max=%d",loop_max);

	}
	else loop_max = MAX_LOOP_WHILE;
	return loop_max;
}
/************************************/
/*									*/
/************************************/
int cl_is_not_space(prmL)
parmList *prmL;
{
	int  len,ret;
	char *p;
	
	if ((len=prmL->prmlen)>0 && (p=prmL->prp)
		                     && akxnskipin(p,len," \t")<len) ret=1;
	else ret=0;
	return ret;
}

/************************************/
/* clPrcessLoop						*/
/************************************/
int cl_process_loop(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	static char *_fn_="cl_process_loop";
	int rc,loop_max,lb_used,pnum,iOpt,count,ex_opt,iBRK_PR;
	BlockCB *pcrLCB;
	tdtInfoParm tInfoParm[4];
	char **argv,*p;
	cmdInfo *pcmd;

	if (!leaf) return -1;
	if (!proc) return -2;

	rc = 0;
	iBRK_PR = proc->ptype & BRK_PR;
	cmn_set_stat(BRK_PR,&proc->ptype,L_OFF);
	pcrLCB = proc->pcrBlockCB;
	if (cl_is_loop_exec(leaf,proc)) {
		pcrLCB->iLoopCounter++;
	}
	else {
		memset(&tInfoParm,0,sizeof(tInfoParm));
		iOpt = 0;
		/* Loop max value set process */
		/* �ŏ��ɁA�b��ŁA�ő�l�ɐݒ肷�� */
		loop_max = INT_MAX;
		lb_used = leaf->cmd.sub_cid & ~C_CMD_FLAGS;
			if (leaf->cmd.cid == C_LOOP) {
				if (leaf->cmd.prmnum > 0) {
					if ((rc = cl_loop_max(leaf,proc,&loop_max)) != NORMAL)
						return ECL_EX_LOOP;
				}
			}
			else loop_max = 1;	/* C_DO */
			lb_used = D_LOOP_NORMAL;
/*
printf("%s: proc = %s, loop_max = %d lb_used = %d\n",_fn_,proc->ProcNM,loop_max,lb_used);
*/
DEBUGOUTL3(190,"%s: proc = %s, loop_max = %d",_fn_,proc->ProcNM,loop_max);

		if (loop_max > 0) {
			if (rc = loop_pre_proc(leaf,proc)) return rc;
			cmn_set_stat(LOP_PR,&proc->ptype,L_ON);
			pcrLCB = proc->pcrBlockCB;
			pcrLCB->iLoopMax = loop_max;
			pcrLCB->Blockleaf = leaf; /* set Loop first leaf */
			pcrLCB->iUsed = lb_used;
			pcrLCB->iOpt = iOpt;
			pcrLCB->pSwParm = (char *)argv;
			pcmd = &(leaf->cmd);
			pcrLCB->BlockName = Strdup(pcmd->parl[D_LEAF_LABEL].par);
			proc->Nextleaf = leaf->leftleaf;
		}
		else {
			proc->Nextleaf = leaf->rightleaf;
			return 0;
		}
	}

DEBUGOUTL3(190,"%s: proc = %s, loop_count = %d",_fn_,proc->ProcNM,pcrLCB->iLoopCounter);

	/* ���̎��_�ł�MAX_LOOP_WHILE�����߂� */
	ex_opt = cl_get_option(27,0);
	if (ex_opt & 0x10) {
		loop_max = INT_MAX;
	}
	else {
		if ((loop_max = _get_loop_max()) < 0) return ECL_EX_LOOP;
	}
	count = pcrLCB->iLoopCounter;
	if (count<loop_max && count < pcrLCB->iLoopMax) {
		/* ���ꂼ��̃R�}���h�ł̃��[�v�����𔻒肷�� */
		rc = 1;
		lb_used = pcrLCB->iUsed;
	}
	else {
		if (count >= loop_max) {
/*
printf("%s: count=%d loop_max=%d\n",_fn_,count,loop_max);
*/
			if (!iBRK_PR && ((ex_opt & 0x01) || gMaxLoopWhile==MAX_LOOP_WHILE))
				ERROROUT2(FORMAT(646),_fn_,gMaxLoopWhile);	/* %s: ���[�v�J�E���g���A%d �ɒB���܂����B*/
		}
		rc = 0;
	}

	if (rc) {
		proc->Nextleaf = leaf->leftleaf;
DEBUGOUTL2(200,"%s: push [ %s ]",_fn_,cl_get_pcmd_line(leaf));
		cl_ret_leaf_push(proc,leaf);
		rc = 0;
	}
	else {	/* end loop */
		proc->Nextleaf = leaf->rightleaf;
		pcrLCB->iLoopCounter = 0;
		pcrLCB->iLoopMax = 0;
		pcrLCB->iUsed = 0;
		if (!cl_search_block_cb(proc,C_LOOP,1)) {
			cmn_set_stat( LOP_PR , &proc->ptype , L_OFF );
			cmn_set_stat( BRK_PR , &proc->ptype , L_OFF );
		}
		proc->pcrBlockCB = pcrLCB->preBlockCB;

DEBUGOUTL3(190,"%s: proc = %s, end pcrLoopCB = %08x",_fn_,proc->ProcNM,proc->pcrBlockCB);

	}
	return rc;
}

/************************************/
/* loop_pre_proc					*/
/************************************/
int loop_pre_proc(pLeaf,pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int  	rc;
	BlockCB	*pLoopCB;

	if (!pLeaf || !pProc) return D_ERROR;
	/* BlockCB���� */
	if (rc = cl_add_block_cb(pProc)) return rc;
	pLoopCB = pProc->pcrBlockCB;
	pLoopCB->cid = pLeaf->cmd.cid;

DEBUGOUTL1(190,"loop_pre_proc: set pcrLoopCB = %08x",pLoopCB);

	return 0;
}
