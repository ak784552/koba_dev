static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_elseif              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else_if(y)
condList *y;
{
	static int able[]={C_IF,C_ELSEIF};
	static int deny[]={C_ELSE};

	return col_mn_tr_else_ifNode(y,deny,1,able,2);
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_else_ifNode(y,deny,nd,able,na)
condList *y;
int deny[],nd;
int able[],na;
{
	int rc;

	if (!(rc=cl_tr_end_node_check(y,deny,1,able,2))) {
		if (!y->cmd->prmnum) {
			ERROROUT1(FORMAT(92),"col_mn_tr_else_if");	/* %s: �����K�v�ł� */
			rc =ECL_TR_ELSEIF;
		}
		else rc = cl_tr_else_nest_check(y);
	}
	return rc;
}
