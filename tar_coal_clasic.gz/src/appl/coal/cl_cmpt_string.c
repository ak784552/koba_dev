static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/****************************************************************************
*																			*
*	�����ړI�@�F moji���Z����												*
*																			*
*	�֐����@  �F int cl_cmpt_string(pAns, pOprtr, pInfoParm1, pInfoParm2)	*
*				(O)char		*pAns											*
*				(I)char  	*pOprtr											*
*				(I)tdtInfoParm *pInfoParm1									*
*				(I)tdtInfoParm *pInfoParm2									*
*																			*
*	�߂�l�@�@�F ERROR														*
*				 NORMAL														*
*																			*
*	�����T�v�@�F															*
*																			*
*****************************************************************************/
#include <colmn.h>

#define ARGSEP  '&'
#define ARGSEP2 '@'
#define ARGPOS  '&'
#define ARGPOS2 '@'
extern CLPRTBL  *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
int cl_cmpt_string(pAns, pOprtr, pInfoParm1, pInfoParm2, nparm0, prmp)
	char		**pAns;
	char		*pOprtr;
	tdtInfoParm	*pInfoParm1;
	tdtInfoParm	*pInfoParm2;
	int nparm0;
	parmList  *prmp[];
{
	int rc,len,bmode,mflg,nparm;
	char *p;
	tdtInfoParm InfoParm3,*pInfoParm3;
	tdtInfoParm **ppParm,*pParm,*ppParm0[2],pParm0[2];

DEBUGOUTL2(120,"cl_cmpt_string:Enter nparm=%d pOprtr=[%s]",nparm,pOprtr);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_string: pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_string: pInfoParm2=",pInfoParm2,0,0);

	if (pAns) *pAns = NULL ;
	else {
		ERROROUT("pAns == NULL");
		return (-1);
	}
	nparm = nparm0;
	bmode = 0;
	mflg = pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX;
	if (!stricmp(pOprtr,"CONCAT") || !stricmp(pOprtr,"&+") || !stricmp(pOprtr,"|+")) {
		rc=concat(pAns,pInfoParm1,pInfoParm2,nparm,prmp,NULL);
	}
	else if (!stricmp(pOprtr,"SUBSTR") || (bmode=!stricmp(pOprtr,"SUBSTRB")) ||
	         !stricmp(pOprtr,"MID")    || (bmode=!stricmp(pOprtr,"MIDB"))) {
		if (nparm>0) {
			if ((rc=cl_gx_exp_obj_opt(1,&prmp[0],NULL,&InfoParm3,0)) < 0) return rc;
			pInfoParm3 = &InfoParm3;
		}
		else pInfoParm3 = NULL;
		if (bmode) mflg = 0;
		rc=substrm(pAns,mflg,pInfoParm1,pInfoParm2,pInfoParm3);
	}
	else if (!stricmp(pOprtr,"REP"))
		rc=replace(pAns,pInfoParm1,pInfoParm2);
	else if (!stricmp(pOprtr,"CONDAS"))			/* K-00044 */
		rc=condas(pAns,pInfoParm1,pInfoParm2);
#if 0
	else {
		pParm = pParm0;
		ppParm = ppParm0;
		nparm = 2;
		cl_gx_copy_info(&pParm[0],pInfoParm1);
		cl_gx_copy_info(&pParm[1],pInfoParm2);
		ppParm[0] = pInfoParm1;
		ppParm[1] = pInfoParm2;
		if (!stricmp(pOprtr,"TRIM"))
			rc = cl_trim(pAns,nparm,ppParm);
		else if (!stricmp(pOprtr,"STRINGS"))
			rc = cl_strings(pAns,nparm,ppParm);
		else if (!stricmp(pOprtr,"LEFT") || (bmode=!stricmp(pOprtr,"LEFTB"))) {
			if (bmode) mflg = 0;
			rc = cl_leftm(pAns,mflg,nparm,ppParm);
		}
		else if (!stricmp(pOprtr,"RIGHT") || (bmode=!stricmp(pOprtr,"RIGHTB"))) {
			if (bmode) mflg = 0;
			rc = cl_rightm(pAns,mflg,nparm,ppParm);
		}
	}
#endif
if (*pAns) {
	ParList2 par2;
	p = *pAns;
	cl_sep_string_with_type(&par2,p,strlen(p));
	DEBUGOUTL2(120,"cl_cmpt_string:Exit rc=%d *p=[%s]",rc,par2.par);
}
else DEBUGOUTL1(120,"cl_cmpt_string:Exit rc=%d *pAns=NULL",rc);
	return (rc);
}

/****************************************/
/*										*/
/****************************************/
int concat(pAns, pInfoParm1, pInfoParm2, nparm, prmp, pParm)
char		**pAns;
tdtInfoParm	*pInfoParm1;
tdtInfoParm	*pInfoParm2;
int nparm;
parmList  *prmp[];
tdtInfoParm	*pParm;
{
	static char *_fn_ = "concat";
	int rc,len1,i,max_layer,code_type,mcode[2];
	char *p1,*pWork,*p;
	parmList **prmpW;
	tdtInfoParm *pParmW,*pParm12[2],*pInfo;
	tdtIterate_ctl tIter_ctl;
	tdtIterate *pIter;

DEBUGOUTL5(180,"concat:Enter pInfoParm1=%08x pInfoParm2=%08x nparm=%d prmp=%08x pParm=%08x",
pInfoParm1,pInfoParm2,nparm,prmp,pParm);

	pWork = NULL;
	*pAns = pWork;
	rc = 0;
	code_type = -1;
	max_layer = -1;
	len1 = 0;
	pParm12[0] = pInfoParm1;
	pParm12[1] = pInfoParm2;
	mcode[0] = code_type;
	mcode[1] = 0;
	for (i=0;i<2;i++) {
		if (pParmW=pParm12[i]) {
			if ((rc=cl_iterate_info_init(&tIter_ctl,NULL,pParmW,max_layer)) < 0) goto err;
			for (;;) {
				if ((rc=cl_iterate_info(&tIter_ctl)) < 0) goto err;
				pIter = tIter_ctl.itc_pIter;
				if (!(pInfo=pIter->it_pInfo)) break;
				if ((rc=cl_concat_info(&pWork,len1,pInfo,mcode)) < 0) goto err;
				len1 = rc;
			}
		}
	}
	prmpW = NULL;
	pParmW = NULL;
	for (i=0;i<nparm;i++) {
		if (pParm) pParmW = &pParm[i];
		else prmpW = &prmp[i];
		if ((rc=cl_iterate_info_init(&tIter_ctl,prmpW,pParmW,max_layer)) < 0) goto err;
		for (;;) {
			if ((rc=cl_iterate_info(&tIter_ctl)) < 0) goto err;
			pIter = tIter_ctl.itc_pIter;
			if (!(pInfo=pIter->it_pInfo)) break;
			if ((rc=cl_concat_info(&pWork,len1,pInfo,mcode)) < 0) goto err;
			len1 = rc;
		}
	}
	p1 = pWork;
	if (pWork = cl_tmp_const_malloc(len1+3)) {
		p = pWork;
		code_type = mcode[0];
		if (code_type < 0) code_type = 0;
		p = cl_set_type_to_string(p,len1,code_type);
		memzcpy(p,p1,len1);
	}
	else rc = ECL_MALLOC_ERROR;
	if (p1) Free(p1);
	*pAns = pWork;
err:

DEBUGOUTL3(180,"%s:Exit rc=%d pWork=%08x",_fn_,rc,pWork);

	if (rc<0 && pWork) {
		Free(pWork);
		*pAns = NULL;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_concat_info(ppWork,len1,pInfoParmW,mcode)
char **ppWork;
int len1,mcode[];
tdtInfoParm	*pInfoParmW;
{
	static char *_fn_ = "concat_info";
	int len,len2,code_type,type,iM1,iM2;
	char id,*p2,*pWork;

DEBUGOUTL3(180,"%s:Enter len1=%d pInfoParmW=%08x",_fn_,len1,pInfoParmW);

	if (!pInfoParmW) return len1;

	code_type = mcode[0];
	iM1 = mcode[1];
	pWork = *ppWork;
	id = pInfoParmW->pi_id;

DEBUGOUTL2(180,"%s: id=[%c]",_fn_,id);

	if (id == 'S') {
		pInfoParmW = (tdtInfoParm *)pInfoParmW->pi_pos;
		id = pInfoParmW->pi_id;

DEBUGOUTL2(180,"%s: id=[%c]",_fn_,id);

	}

DEBUGOUT_InfoParm(180,"%s: pInfoParmW=",pInfoParmW,_fn_,0);

	if (cl_is_undef_parm(pInfoParmW) || cl_is_null_parm(pInfoParmW)) ;
	else if (id == ' ') {
		p2 = NULL;
		if ((len2=parm_to_char(pInfoParmW,&p2,NULL)) < 0) {
			len1 = -1;
		}
		else {
			type = cl_get_char_code_type(pInfoParmW,1);
			iM2 = cl_is_mbyte(pInfoParmW,type);
			if (code_type < 0) code_type = type;
			else if (iM1 | iM2) {
				if (akxq_code_type_cmp(code_type,type)) {
					ERROROUT3(FORMAT(648),_fn_,code_type,type);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
					return ECL_SCRIPT_ERROR;
				}
			}
			mcode[0] = code_type;
			mcode[1] = iM1 | iM2;
			len = len1+len2;
			if (!(pWork = MRealloc(pWork,len+1))) {
				ERROROUT("concat: malloc error");
				len1 = ECL_MALLOC_ERROR;
			}
			else {
				memzcpy(pWork+len1,p2,len2);
				len1 = len;

DEBUGOUTL4(180,"%s: len2=%d len1=%d pWork=[%s]",_fn_,len2,len1,pWork);

			}
		}
	}
	if (len1 < 0) {
		if (pWork) Free(pWork);
		pWork = NULL;
	}
	*ppWork = pWork;

DEBUGOUTL3(180,"%s:Exit len1=%d pWork=%08x",_fn_,len1,pWork);

	return len1;
}

/****************************************/
/*										*/
/****************************************/
int substr_mlen(par2,p1,len1,msp,mn)
ParList2 *par2;
char *p1;
int  len1,msp,mn;
{
	int i,n,m,code_type;
	char *p,*psp;

	if (mn <= 0) {
		psp = NULL;
		n = 0;
	}
	else {
		code_type = GET_TYPE_OPT(par2->option);
		p = p1;
		for (i=1;i<msp;i++) {
			if (m=akxqismbs(code_type,p)) p += m;
			else p++;
		}
		psp = p;
		n = 0;
		for (i=0;i<mn;i++) {
			if (m=akxqismbs(code_type,p)) {
				p += m;
				n += m;
			}
			else {
				p++;
				n++;
			}
		}
	}
	par2->par = psp;
	par2->parlen = n;
	return n;
}

/****************************************/
/*										*/
/****************************************/
int substr_len(mflg,par2,pInfoParm1,pInfoParm2,pInfoParm3)
int mflg;
ParList2 *par2;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParm3;
{
	int  rc,len1,len2,value,sp,n,i,mlen,attr,code_type;
	char w1[16],w2[26],*p1,*p2,*psp,*p;
	char *pAns;

	rc = NORMAL;
	p1 = w1;
	if ((len1 = parm_to_char(pInfoParm1,&p1,NULL))<0) {
		return len1;
	}
/*
akxaxdump("p1",p1,len1);
*/
	code_type = cl_get_char_code_type(pInfoParm1,1);
	if (mflg) {
		mlen = akxqmlen_type(p1,len1,code_type);
		if (mlen == len1) mflg = 0;
		else len1 = mlen;
	}
	if ((attr=pInfoParm2->pi_attr)==DEF_ZOK_BINA ||
	     attr == DEF_ZOK_FLOA || attr == DEF_ZOK_DECI) {
		if (rc = cl_get_parm_bin(pInfoParm2,&sp,"substr.p2")) return rc;
		if (sp < 0) sp = len1+sp+1;
		if ((n=len1-sp+1)<0) n=0;
/*
printf("substr parm2 bin:sp=%d n=%d\n",sp,n);
*/
	}
	else if (attr == DEF_ZOK_CHAR) {
		if ((len2=pInfoParm2->pi_dlen)>25) len2=25;
		memcpy(w2,pInfoParm2->pi_data,len2);
		w2[len2]='\0';
		for (i=0;i<len2;i++) {
			if (w2[i]==',') break;
		}
		rc = axccvn(10,w2,i,&sp);
		if (rc == -1) sp = 1;
		else if (rc>0 || rc< -1) {
			ERROROUT(FORMAT(281));	/* �J�n�ʒu�������ł͂���܂���B */
			return -1;
		}
		if (sp < 0) sp = len1+sp+1;
		if (i>=len2-1) {
			if ((n=len1-sp+1)<0) n=0;
		}
		else {
			rc = axccvn(10,w2+i+1,len2-(i+1),&n);
			if (rc>0 || rc< -1) {
				ERROROUT(FORMAT(282));	/* �����������ł͂���܂���B */
		 		return -1;
	 		}
			else if (rc == -1) {
				if ((n=len1-sp+1)<0) n=0;
			}
			if (n>(len1-sp+1)) n=len1-sp+1;
		}
/*
printf("substr parm2 char:sp=%d n=%d\n",sp,n);
*/
	}
	else {
		/* %s: �p�����[�^�̌^(%d)�������Ă��܂���B */
		ERROROUT2(FORMAT(285),"substr_len",attr);
		 return -1;
	}
	if (pInfoParm3) {
		if (pInfoParm3->pi_dlen > 0) {
			if (rc = cl_get_parm_bin(pInfoParm3,&n,"substr.p3")) return rc;
		}
		else n=len1-sp+1;
/*
printf("substr parm3:n=%d\n",n);
*/
		if (n>(len1-sp+1)) n=len1-sp+1;
	}
	par2->option = SET_TYPE_OPT(code_type);
	if (n<0) n=0;
	if (sp<1 || sp>len1) n=0;
	if (mflg) {
		n = substr_mlen(par2,p1,len1,sp,n);
		psp = par2->par;
	}
	else psp=p1+sp-1;
	if (!(p = cl_tmp_const_malloc(n+1))) {
		ERROROUT("substr:malloc error");
	 	return ECL_MALLOC_ERROR;
	}
	pAns = p;
	if (n>0) memcpy(pAns,psp,n);
	*(pAns+n)='\0';
/*
printf("substr:p=[%s] sp=%d n=%d\n",p1,sp,n);
printf("substr:pAns=[%s]\n",pAns);
*/
	par2->par = pAns;
	par2->parlen = n;

	return NORMAL;
}

/****************************************/
/*										*/
/****************************************/
int substrm(pAns, mflg, pInfoParm1, pInfoParm2, pInfoParm3)
char **pAns;
int  mflg;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParm3;
{
	int ret,n;
	char *p;
	ParList2 par2;

	if ((ret=substr_len(mflg,&par2,pInfoParm1,pInfoParm2,pInfoParm3)) >= 0) {
		if ((n=par2.parlen) > 0) {
			if (!(p = cl_tmp_const_malloc(n+3))) {
				ERROROUT("substrm: malloc error");
				return ECL_MALLOC_ERROR;
			}
			*pAns = p;
			p = cl_set_type_to_string(p,n,GET_TYPE_OPT(par2.option));
			memzcpy(p,par2.par,n);
		}
		else *pAns = par2.par;
	}
	else *pAns = NULL;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int substr(pAns, pInfoParm1, pInfoParm2, pInfoParm3)
char **pAns;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParm3;
{
	return substrm(pAns,pCLprocTable->CurScr->sc_pFlag & D_SCRPT_NEW_LEX
	              ,pInfoParm1,pInfoParm2,pInfoParm3);
}

/****************************************/
/*										*/
/****************************************/
int replace(pAns, pInfoParm1, pInfoParm2)
char **pAns;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	static char *_fn_ = "replace";
	int  rc,len1,len2,value,i,j,index,attr,code_type1,code_type2,m,iM1,iM2;
	char w1[16],w2[16],*p1,*p2,*p,argpos,*p0,c;
	struct ume {
		int spi;
		int len;
	} *pp;

	rc = NORMAL;
	if ((attr=pInfoParm1->pi_attr) == DEF_ZOK_BINA) {
		value = cl_get_data_long(pInfoParm1);
		cmn_i_to_a(value,w1);
		p1   = w1;
		len1 = strlen(w1);
	}
	else if (attr == DEF_ZOK_CHAR) {
		p1   = pInfoParm1->pi_data;
		len1 = pInfoParm1->pi_dlen;
	}
	else {
		/* %s: �p�����[�^�̌^(%d)�������Ă��܂���B */
		ERROROUT2(FORMAT(285),_fn_,attr);
		return -1;
	}
	if ((attr=pInfoParm2->pi_attr) == DEF_ZOK_BINA) {
		value = cl_get_data_long(pInfoParm2);
		cmn_i_to_a(value,w2);
		p2   = w2;
		len2 = strlen(w2);
	}
	else if (attr == DEF_ZOK_CHAR) {
		p2   = pInfoParm2->pi_data;
		len2 = pInfoParm2->pi_dlen;
	}
	else {
		/* %s: �p�����[�^�̌^(%d)�������Ă��܂���B */
		ERROROUT2(FORMAT(285),_fn_,attr);
	}
	code_type1 = cl_get_char_code_type(pInfoParm1,1);
	code_type2 = cl_get_char_code_type(pInfoParm2,1);
	iM1 = cl_is_mbyte(pInfoParm1,code_type1);
	iM2 = cl_is_mbyte(pInfoParm2,code_type2);
/*
printf("%s: code_type1=%d code_type2=%d iM1=%d iM2=%d\n",_fn_,code_type1,code_type2,iM1,iM2);
*/
/*	if (code_type1 != code_type2) {	*/
	if ((iM1 | iM2) && akxq_code_type_cmp(code_type1,code_type2)) {
		ERROROUT3(FORMAT(648),_fn_,code_type1,code_type2);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
		return ECL_SCRIPT_ERROR;
	}

	if (!(p0 = *pAns = cl_tmp_const_malloc(len1+len2+3))) {
		ERROROUT("replace: malloc error");
		return -1;
	}
	p = cl_set_type_to_string(p0,len1+len2,code_type1);
	value=0;
	/* 2022.11.30 */
	i = 0;
	while (i < len2-1) {
		m = akxqmbsnlen(code_type1,p2+i,len2-i);
		if (m == 1) {
			if ((c=p2[i])==ARGSEP || c==ARGSEP2) {
				i++;
				m = akxqmbsnlen(code_type1,p2+i,len2-i);
				if (m == 1) {
					if (p2[i] == c) {
						value++;
					}
					i++;
				}
				else i += m;
			}
			else i++;
		}
		else i += m;
	}
	if (!(pp = (struct ume *)Malloc((value+1)*8))) {
		ERROROUT("replace: malloc error");
		Free(p);
		*pAns = NULL;
		return -1;
	}
	value=0;
	pp[value].spi=0;
	/* 2022.11.30 */
	i = 0;
	while (i < len2-1) {
		m = akxqmbsnlen(code_type1,p2+i,len2-i);
		if (m == 1) {
			if ((c=p2[i])==ARGSEP || c==ARGSEP2) {
				i++;
				m = akxqmbsnlen(code_type1,p2+i,len2-i);
				if (m == 1) {
					if (p2[i] == c) {
						pp[value].len=i-1-pp[value].spi;
						pp[++value].spi=i+1;
					}
					i++;
				}
				else i += m;
			}
			else i++;
		}
		else i += m;
	}
	pp[value].len=len2-pp[value].spi;
	if (pp[value].len>0) value++;
	for (i=0;i<len1;i++) {
		/* 2022.11.30 */
		m = akxqmbsnlen(code_type1,p1+i,len1-i);
		if (m > 1) {
			memcpy(p,p1+i,m);
			p += m;
			i += m - 1;
			continue;
		}
		if ((p1[i]!=ARGPOS) && (p1[i]!=ARGPOS2)) {
			*p++ = p1[i];
			continue;
		}
		argpos = p1[i];
		if (i<len1-1 && p1[i+1]>='0' && p1[i+1]<='9') {
			for (j=i+2;j<len1;j++) {
				if (p1[j]<'0' || p1[j]>'9')
					break;
			}
			if (j<len1 && p1[j]==argpos) {
				if (axccvn(10,p1+i+1,j-(i+1),&index)) {
					/* replace: �u���w�肪�����ł͂���܂���B */
					ERROROUT(FORMAT(284));
					Free(p0);
					Free(pp);
					*pAns = NULL;
	 				return( -1 );
				}
				if (index<value) {
					memcpy(p,p2+pp[index].spi,pp[index].len);
					p+=pp[index].len;
					i=j;
					continue;
				}
				else if ( argpos == ARGPOS ) {
					i = j;
					continue;
				}
			}
		}
		*p++ = argpos;
	}
	*p='\0';
	Free(pp);
	return( NORMAL );
}

/****************************************/
/*										*/
/****************************************/
int condas(pAns, pInfoParm1, pInfoParm2)
char **pAns;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	static char *_fn_ = "condas";
	int  rc,len1,len2,value,i,flag,attr,code_type1,code_type2,m,iM1,iM2;
	char w1[16],w2[26],*p1,*p2,*p2w,sepc,*peq,*pt,*pf;
	char *p,*p1w,*p0;

	p1w = p2w = NULL;
	rc = -1;
	p1 = w1;
	if ((len1 = parm_to_char(pInfoParm1,&p1,NULL))<0) {
		return rc;
	}

	if ((attr=pInfoParm2->pi_attr)==DEF_ZOK_CHAR && pInfoParm2->pi_dlen>2) {
		p2   = pInfoParm2->pi_data;
		len2 = pInfoParm2->pi_dlen;
	}
	else {
		/* %s: �p�����[�^�̌^(%d)�������Ă��܂���B */
		ERROROUT2(FORMAT(285),_fn_,attr);
		goto err;
	}
	code_type1 = cl_get_char_code_type(pInfoParm1,1);
	code_type2 = cl_get_char_code_type(pInfoParm2,1);
	iM1 = cl_is_mbyte(pInfoParm1,code_type1);
	iM2 = cl_is_mbyte(pInfoParm2,code_type2);
	if ((iM1 | iM2) && akxq_code_type_cmp(code_type1,code_type2)) {
		ERROROUT3(FORMAT(648),_fn_,code_type1,code_type2);	/* %s: �����R�[�h���قȂ��Ă��܂��B��1=%d ��2=%d */
		return ECL_SCRIPT_ERROR;
	}
	m = akxqmbsnlen(code_type2,p2,len2);
	if (m != 1) {
		ERROROUT("condas: no 1st seperator.");
		goto err;
	}
	if (!(p2w = Malloc(len2+1))) {
		ERROROUT("condas: p2w malloc error");
		goto err;
	}
	memcpy(p2w,p2,len2);
	*(p2w+len2) = '\0';
	sepc = *p2w;
	pt = peq = p2w + 1;
	i = 1;
	for (;i<len2;i++,pt++) {
		m = akxqmbsnlen(code_type2,pt,len2-i);
		if (m == 1) {
			if (*pt == sepc) break;
		}
		else {
			m--;
			pt += m;
			i  += m;
		}
	}
	if (i>=len2) {
		ERROROUT("condas: no 2nd seperator.");
		goto err;
	}
	*pt++ = '\0';
/*
printf("%s:1 i=%d pt=[%s]\n",_fn_,i,pt);
*/
	i++;
	pf = pt;
	for (;i<len2;i++,pf++) {
		m = akxqmbsnlen(code_type2,pf,len2-i);
		if (m == 1) {
			if (*pf == sepc) break;
		}
		else {
			m--;
			pf += m;
			i  += m;
		}
	}
	if (i>=len2) {
		ERROROUT("condas: no 3rd seperator.");
		goto err;
	}
	*pf++ = '\0';
/*
printf("%s:2 i=%d pf=[%s]\n",_fn_,i,pf);
*/
	if (strcmp(p1,peq))
		p2 = pf;
	else
		p2 = pt;
	p = p2;
/*
printf("%s:3 len2=%d p=[%s]\n",_fn_,len2,p);
*/
	while (*p) {
		if (i > len2) break;
		m = akxqmbsnlen(code_type2,p,len2-i);
/*
printf("%s:4 i=%d m=%d\n",_fn_,i,m);
*/
		if (m > 1) {
			p += m;
			i += m;
		}
		else if (*p == '%') {
			p++;
			i++;
			m = akxqmbsnlen(code_type2,p,len2-i);
/*
printf("%s:5 i=%d m=%d\n",_fn_,i,m);
*/
			if (m > 1) {
				p += m;
				i += m;
			}
			else {
				if (*p=='q') {
					*p = 's';
					if (len1==0) break;
					len1 += len1;
					if (!(p1w = Malloc(len1+1))) {
						ERROROUT("condas: p1w malloc error");
						goto err;
					}
					p = p1w;
					while (*p++ = *p1) {
						if (*p1++ == M_QUOTE1) *p++ = M_QUOTE1;
					}
					*p = '\0';
					p1 = p1w;
					break;
				}
				p++;
				i++;
			}
		}
		else {
			p++;
			i++;
		}
	}

	if (*pAns = p0 = cl_tmp_const_malloc(len1+len2+3)) {
		p = cl_set_type_to_string(p0,len1+len2,code_type1);
		sprintf(p,p2,p1);
		rc = 0;
	}
	else ERROROUT("condas: pAns malloc error");

err:
	if (p1w) Free(p1w);
	if (p2w) Free(p2w);
	return rc;
}

/********************************************************/
/*	���l�̂Ƃ��́Ap1_len>0 ���� *p1<>NULL�Ȃ�*p1�ɕԂ��B*/
/*	p1_len=0 �Ȃ� *p1�͐ݒ肵�Ȃ��Ă悢					*/
/*	opt = 0x01 : Range/Complex�̂Ƃ��́A���̕\��		*/
/********************************************************/
int cl_parm_to_char_opt(pInfoParm1,p1,p1_len,p1_free,opt)
tdtInfoParm	*pInfoParm1;
char **p1,**p1_free;
int p1_len,opt;
{
	int len1,len2,len3,i,rc,attr,im,add1,add2,iP1USE,p_len,iVal[2];
	char *p,*pp,*p0,*pStr1,*pStr2,*pStr3,dummy[16],wrk[2];
	tdtInfoParm *pInfo,tInfo[3],*ppParm[3];
/*
printf("cl_parm_to_char_opt: pInfoParm1=%08x p1=%08x\n",pInfoParm1,p1);
*/
	if (!pInfoParm1 || !p1) return -1;
	if (rc=cl_check_data_id(pInfoParm1,0)) return rc+ECL_CHK_VAR_ERROR;

	if (p1_len>0 && *p1) {
		iP1USE = p1_len;
		**p1 = '\0';
		p_len = p1_len;
	}
	else {
		iP1USE = 0;
		p_len = 32;
	}
	if (p1_free) {
		im = D_OPT_ALC_MALLOC;
		*p1_free = NULL;
	}
	else im = D_OPT_ALC_TMP;

	len1 = cl_get_info_str(pInfoParm1,&pStr1,im);
	if (len1 >= 0) {
		pp = pStr1;
		if ((attr=pInfoParm1->pi_attr) == DEF_ZOK_BINA) {
			if (iP1USE) memzcpy(*p1,pp,len1);
			else *p1 = pp;
		}
		else {
			*p1 = pp;
		}
		if (p1_free) *p1_free = pp;
	}
	return len1;
}

/****************************************/
/*	*p1�͐ݒ肷��K�v������				*/
/****************************************/
int parm_to_char2(pInfoParm1,p1,p1_free,opt)
tdtInfoParm	*pInfoParm1;
char **p1, **p1_free;
int opt;
{
/*
 * *p1�͐ݒ肷��K�v������B
 * BINA��FLOA�ɂ��ẮA*p1�̃A�h���X�Ɍ��ʂ�Ԃ��B
 *   *p1��NULL�̂Ƃ��́A�ȉ��Ɠ����B
 * CHAR,DECI,BULK�ɂ��ẮA
 *     p1_free!=NULL �̂Ƃ��́AMalloc����(im=4)�B
 *     p1_free==NULL �̂Ƃ��́Acl_tmp_const_malloc����(im=3)�B
 */
	int p1_len;

	if (!pInfoParm1 || !p1) return -1;
	if (*p1) p1_len = 16;	/* BINA��FLOA�ɂ��ẮAp1�̃A�h���X�Ɍ��ʂ�Ԃ� */
	else p1_len = 0;
	return cl_parm_to_char_opt(pInfoParm1,p1,p1_len,p1_free,opt);
}

/****************************************/
/*	*p1�͐ݒ肷��K�v������				*/
/****************************************/
int parm_to_char(pInfoParm1,p1,p1_free)
tdtInfoParm	*pInfoParm1;
char **p1, **p1_free;
{
	int opt;

	opt = 0x01;
	if (cl_get_option(2,0) & 0x400) opt = 0;
	return parm_to_char2(pInfoParm1,p1,p1_free,opt);
}

/*****************************************************/
/*	���l�̂Ƃ��́Alen>0 ���� *p1<>NULL�Ȃ�*p1�ɕԂ��B*/
/*	len=0 �Ȃ� *p1�͐ݒ肵�Ȃ��Ă悢				 */
/*****************************************************/
int parm_to_char_tmp(pInfoParm1,p1,len)
tdtInfoParm *pInfoParm1;
char **p1;
int len;
{
	int opt;

	opt = 0x01;
	if (cl_get_option(2,0) & 0x400) opt = 0;
	return cl_parm_to_char_opt(pInfoParm1,p1,len,NULL,opt);	/* cl_tmp_const_malloc */
}

/****************************************/
/*										*/
/****************************************/
int cl_double_to_str(s,s_len,dValue)
char *s;
int s_len;
double dValue;
{
	int pre,len1,pos1,pos2,pos3,inx,pre1,inx1,n,leng,pos20,pre2,sei,ret,opt;
	int opt11,iZSUP,opt20,zsap,pre_inx;
	char *p,*p1,*pp,wrk[10],buf[30];
	double dw;
	MPA10W wz,*w;

	if (!s || s_len<2) return -1;

	iZSUP = 0;
#if 1	/* 2024.9.28 */
	opt20 = cl_get_option(20,0);
	zsap =  opt20 / 10000;
	pre_inx = opt20 % 10000;
	pre = pre_inx % 100;
	inx = pre_inx/100;
	if (zsap) iZSUP = 0x0100;
#else
	opt = cl_get_option(20,0) & 0xffff;
	pre = opt & 0xff;
	inx = opt>>8;
#endif
	if (pre > 0) {
		if (pre > MAXDBLPRE) pre = MAXDBLPRE;
#if 1	/* 2024.9.28 */
		if (zsap) iZSUP = 0x0100;
		else iZSUP = 0;
#else
		iZSUP = 0;
#endif
	}
	else {
		if (dValue == 0.0) {
			s_len--;
			strnzcpy(s,"0.0",s_len);
			return strlen(s);
		}
		pre = MAXDBLPRE;
		iZSUP = 0x0100;
	}
	pre2 = pre + 2;
	len1 = s_len - 7;
	if (pre2 > len1) pre2 = len1;
	sprintf(wrk,"%%.%de",pre2);
	snprintf(s,s_len,wrk,dValue);
	len1 = strlen(s);
/*
printf("cl_double_to_str: iZSUP=%08x s_len=%d pre=%d pre2=%d len1=%d s=[%s]\n",iZSUP,s_len,pre,pre2,len1,s);
*/
	w = (MPA10W *)cl_get_tmpMPA10W2(&wz,1);
	ret = m_an_to_mpa10_opt(w,s,s_len,0);
	opt11 = cl_get_option(11,0);
	opt = opt11 | (cl_get_option(12,0)<<12) | iZSUP;
	if (pre >= MAXDBLPRE) {
		ret = m_precision_10(w,pre+1,opt);
		iZSUP = opt & 0x0100;
		ret = m_precision_10(w,pre,0x1000 | iZSUP);
	}
	else ret = m_precision_10(w,pre,opt | iZSUP);
	if ((opt11 & 0x40) || (X_ABS(w->exp)>m_get_nmpa10())) {
		len1 = m_mpa10_to_exp(w,s,s_len,pre,inx,opt11);
		akxtsrepc(s,'E','e');
	}
	else
		len1 = m_mpa10_to_an(w,s,s_len,opt11);
	return len1;
}

/****************************************/
/*										*/
/****************************************/
static int _edit_width(widths,p_b,data,len)
int widths;
char *p_b,*data;
int len;
{
	int width;

	if ((width=widths) < 0) width = -width;

	if (widths >= 0) {
		memzcpy(p_b,data,len);
		if (width > len) {
			memset(p_b+len,' ',width-len);
			*(p_b+width) = '\0';
		}
	}
	else if (widths < 0) {
		if (width > len) {
			memset(p_b,' ',width-len);
			p_b += width-len;
		}
		memzcpy(p_b,data,len);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _edit_sub_s(pp_b,form,c0,widths,pInfoParm,iOpta)
char **pp_b,*form,c0;
tdtInfoParm *pInfoParm;
int iOpta[],widths;
{
	int  len_d,width,iSTR;
	char *p,*p_b,buf[256],*p_d,attr,w1[16],id;

/*
DEBUGOUT_InfoParm(0,"cl_edit: ",pInfoParm,0,0);
*/
	p_b = *pp_b;
		if ((width=widths) < 0) width = -width;
			id   = pInfoParm->pi_id;
			attr = pInfoParm->pi_attr;
			p_d  = pInfoParm->pi_data;
			len_d = pInfoParm->pi_dlen;
				if (id==' ' &&
				    !(pInfoParm->pi_aux[0] & DEF_ZOK_DATA) &&
				    !(pInfoParm->pi_alen & D_AULN_RANGE_DATA)) {
					if (attr != DEF_ZOK_CHAR) {
						p_d = w1;
						len_d = parm_to_char(pInfoParm,&p_d,NULL);
					}
/*
printf("cl_edit: p_d=[%s]\n",p_d);
*/
				}
				else {
					iSTR = 0;
					if (iOpta) {
						if (iOpta[1] & D_PRN_OPT_NGEN) {
							if (c0 == 'S') iOpta[1] |= D_PRN_OPT_LTGT;
							len_d = cl_str_print(&p_d,pInfoParm,iOpta);
							if (len_d == ECL_EX_CONTINUE) len_d = 0;
							iSTR = 1;
						}
						else len_d = -1;
					}
					else len_d = -1;
					if (len_d<0 && !iSTR) len_d = parm_to_char(pInfoParm,&p_d,NULL);
				}
				if (len_d < 0) {
					p = "(ERR)";
					_edit_width(widths,p_b,p,strlen(p));
				}
				else {
					if (len_d>width && len_d>sizeof(buf)-1) {
						if (!(p_b = cl_tmp_const_malloc(len_d+1))) {
							*pp_b = NULL;
							return -1;
						}
						*pp_b = p_b;
					}
/*
printf("cl_edit: form=[%s] p_d=[%s]\n",form,p_d);
*/
					sprintf(p_b,form,p_d);
				}
/*
printf("cl_edit:Exit form=[%s] p_d=[%s]\n",form,p_d);
*/
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_edit_sub(pAns,format,nparm,ppParm,iOpta)
char **pAns,*format;
int  nparm;
tdtInfoParm **ppParm;	/* (buf,opt) */
int iOpta[];
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	tdtInfoParm *pInfoParm;
	int  len_f,len_d,i,len,ipa,val,width,widths,ret,iVal[2],iAttr[3],iSTR;
	int  isca,scale,len1,len2,opt,slen;
	char form[256],buf[256],*p_b,*p,*p_f,*p_d,c,c0,cc,attr,w1[16],id,*p_p,*pp,buf2[100],buf3[100];
	double dValue;
	uchar uc;
	MPA *mpa,mpaz;
	ParList par_dat;
/*
printf("cl_edit_sub:Enter nparm=%d format=[%s]\n",nparm,format);
*/
	if (!pAns) return -1;
	*pAns = NULL;
	len_f = strlen(p_f=format);
	if (len_f <= 0) return 0;
	ipa = 0;
	buf[0] = '\0';
	mcat.mc_ipos = 0;
	for (;;) {
/*
printf("cl_edit_sub:1: len_f=%d p_f=[%s]\n",len_f,p_f);
*/
		c = '\0';
		scale = isca = i = 0;
		while (i<len_f && (c=*(p_f+i))) {
			if (c=='%') {
				if ((cc=*(p_f+i+1))=='%') {
					i++;	/* add 2923.10.30 */
					akxtmcat(&mcat,p_f,i);
					i++;
					p_f += i;
					len_f -= i;
					i = 0;
				}
#if 1	/* 2923.10.30 */
				else if (cc=='/') {
					akxtmcat(&mcat,p_f,i);
					len1 = cl_print_set_flag(p_f+i+1,len_f-1,iOpta+1);
/*
printf("cl_edit_sub:1: len1=%d len_f=%d p_f+i=[%s]\n",len1,len_f,p_f+i);
*/
					i += len1+1;
					p_f += i;
					len_f -= i;
					i = 0;
/*
printf("cl_edit_sub:2: len_f=%d p_f=[%s]\n",len_f,p_f);
*/
				}
#endif
				else break;
			}
#if 1	/* 2923.10.39 */
			else i++;
#else
			i++;
#endif
		}
		akxtmcat(&mcat,p_f,i);
		if (c != '%') {
			break;
		}
		p_f += i;
		len_f -= i;
/*
printf("cl_edit_sub:2: len_f=%d p_f=[%s]\n",len_f,p_f);
*/
		widths = atoi(p_f+1);
		if ((width=widths) < 0) width = -width;
		i = 1;
		p_b = buf;
		if (width > sizeof(buf)-1) {
			if (!(p_b=cl_tmp_const_malloc(width+1))) return -1;
		}
		*p_b = '\0';
		while (i<len_f && (c=*(p_f+i)) &&
		       ((c>='0' && c<='9')||(c=='.')||(c=='+')||(c=='-'))) {
			i++;
			if (c == '.') isca = i;
		}
		i++;
		if (ipa < nparm) {
			memnzcpy(form,p_f,i,sizeof(form));
/*
printf("cl_edit_sub: form=[%s] widths=%d i=%d\n",form,widths,i);
*/
			if (isca) scale = atoi(form+isca);
			if (c == 'S') *(form+i-1) = 's';
			c0 = c;
			c = toupper(c);
			pInfoParm = ppParm[ipa];
			id   = pInfoParm->pi_id;
			attr = pInfoParm->pi_attr;
			p_d  = pInfoParm->pi_data;
			len_d = pInfoParm->pi_dlen;
			if (len_d > 0) {
				if (attr==DEF_ZOK_FLOA)
					memcpy(&dValue,p_d,sizeof(double));
				else if (attr==DEF_ZOK_BINA)
					val = cl_get_data_long(pInfoParm);
			}
			if (cl_is_null_value(pInfoParm)) {
				p = D_STR_NAME_NULL;
				_edit_width(widths,p_b,p,strlen(p));
			}
			else if (len_d <= 0) {
				if (c=='S' && attr==DEF_ZOK_CHAR) {
					sprintf(p_b,form,"");
				}
				else {
					p = AKX_NULL_PRINT;
					_edit_width(widths,p_b,p,strlen(p));
				}
			}
			else if (c == 'S') {
				/* 2021.11.30 */
				if ((ret=_edit_sub_s(&p_b,form,c0,widths,pInfoParm,iOpta)) < 0) return ret;
			}
			else if (c == 'C') {
				if (attr==DEF_ZOK_FLOA) {
					val = dValue;
					uc = val;
				}
				else if (attr==DEF_ZOK_BINA) uc = val;
				else if (attr==DEF_ZOK_DECI) {
					if (cl_get_parm_bin(pInfoParm,&val,"cl_edit_sub:C")) uc = ' ';
					else uc = val;
				}
				else if (attr==DEF_ZOK_DATE) {
					p_d = w1;
					len_d = parm_to_char(pInfoParm,&p_d,NULL);
					if (len_d < 0) {
						p = "(ERR)";
						_edit_width(widths,p_b,p,strlen(p));
					}
					uc = (uchar)*p_d;
				}
				else uc = (uchar)*p_d;
				sprintf(p_b,form,uc);
			}
			else if (c=='F' || c=='E' || c=='G' || c=='A') {
				if (attr == DEF_ZOK_FLOA) sprintf(p_b,form,dValue);
				else if (attr == DEF_ZOK_BINA) {
					dValue = val;
					sprintf(p_b,form,dValue);
				}
				else if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_DECI) {
					if (ret=cl_get_parm_double(pInfoParm,&dValue,"cl_edit_sub:DOUBLE")) {
						p = "(ERR)";
						_edit_width(widths,p_b,p,strlen(p));
					/*	return -1;	*/
					}
					else {
						sprintf(p_b,form,dValue);
					}
				}
				else {
					p = "(ERR)";
					_edit_width(widths,p_b,p,strlen(p));
				}
			}
			else if (c=='D' || c=='I' || c=='O' || c=='U' || c=='X') {
				if (attr == DEF_ZOK_BINA) sprintf(p_b,form,val);
				else if (attr == DEF_ZOK_FLOA) {
					val = cl_chk_over_flow_d2_i(dValue,"cl_edit_sub");
					sprintf(p_b,form,val);
				}
				else if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_DECI) {
					if (ret=cl_get_parm_bin(pInfoParm,&val,"cl_edit_sub:BIN")) {
						p = "(ERR)";
						_edit_width(widths,p_b,p,strlen(p));
					/*	return -1;	*/
					}
					else sprintf(p_b,form,val);
				}
				else if (attr==DEF_ZOK_DATE) {
					p = "(ERR)";
					_edit_width(widths,p_b,p,strlen(p));
				}
				else sprintf(p_b,form,p_d);
			}
			else if (c == 'R') {
				p_p = form + i - 1;
				if (attr == DEF_ZOK_BINA) {
					if (pInfoParm->pi_pos & D_DATA_UNSIGNED) *p_p = 'u';
					else *p_p = 'd';
					sprintf(p_b,form,val);
				}
				else if (attr == DEF_ZOK_FLOA) {
					*p_p = 'f';
					sprintf(p_b,form,dValue);
				}
				else if (attr == DEF_ZOK_CHAR) {
					*p_p = 's';
					sprintf(p_b,form,p_d);
				}
				else {
					*p_p = 's';
					if ((ret=_edit_sub_s(&p_b,form,c0,widths,pInfoParm,iOpta)) < 0) return ret;
				}
			}
#if 1	/* 2024.5.11 */
			else if (c == 'M') {
				p_p = form + i - 1;
				p = buf2;
				if (attr == DEF_ZOK_BINA) {
					if (pInfoParm->pi_pos & D_DATA_UNSIGNED) *p_p = 'u';
					else *p_p = 'd';
					sprintf(p,form,val);
				}
				else if (attr == DEF_ZOK_FLOA) {
					sprintf(p,"%g",dValue);
				}
				else {
					p = "(ERR)";
				}
				len1 = akxtcomma(buf3,p);
				_edit_width(widths,p_b,buf3,len1);
			}
#endif
			else {
				sprintf(p_b,form,p_d);
			}
			ipa++;
		}
		else {
			p = "(N/A)";
			_edit_width(widths,p_b,p,strlen(p));
		}
		akxtmcats(&mcat,p_b);
		p_f += i;
		len_f -= i;
	}
	*pAns = mcat.mc_bufp;
	return mcat.mc_ipos;
}

/****************************************/
/*										*/
/****************************************/
int cl_edit_opta(pAns,nparm,ppParm,iOpta)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
int iOpta[];
{
	tdtInfoParm *pInfoParm;
	int ret,len_f;
	char *pWork,*p,*format;
/*
printf("cl_edit_opta:Enter nparm=%d\n",nparm);
*/
	if (!pAns) return -1;
	*pAns = NULL;
	ret = 0;
	pWork = "";
	if (nparm > 0) {
		pInfoParm = ppParm[0];
/*
DEBUGOUT_InfoParm(0,"cl_edit_opta: ",pInfoParm,0,0);
*/
		len_f = pInfoParm->pi_dlen;
/*
printf("cl_edit_opta: len_f=%d\n",len_f);
*/
		if (len_f > 0) {
/*
printf("cl_edit_opta: attr=%d\n",pInfoParm->pi_attr);
*/
			if (pInfoParm->pi_attr != DEF_ZOK_CHAR) return -2;
			format = pInfoParm->pi_data;
			if ((ret=cl_edit_sub(&pWork,format,nparm-1,&ppParm[1],iOpta)) < 0) return ret;
		}
	}
	if (!(p=cl_tmp_const_malloc(ret+1))) return -1;
	memzcpy(p,pWork,ret);
	*pAns = p;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_edit(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
	int iOpta[MAX_PRINT_FLGS+1],opt13;

	mem_set_int(iOpta,0,MAX_PRINT_FLGS+1);
	opt13 = cl_get_option(13,0);
	return cl_edit_opta(pAns,nparm,ppParm,iOpta);
}

/****************************************/
/*										*/
/****************************************/
int cl_eedit(pAns,nparm,ppParm)
char **pAns;
int  nparm;
tdtInfoParm **ppParm;
{
	int iOpta[MAX_PRINT_FLGS+1],opt13;

	mem_set_int(iOpta,0,MAX_PRINT_FLGS+1);
	opt13 = cl_get_option(13,0);
	if (opt13 & 0x40) iOpta[1] & ~D_PRN_OPT_NGEN;
	else iOpta[1] |= D_PRN_OPT_NGEN;
	if (opt13 & 0x80) iOpta[1] &= ~D_PRN_OPT_LTGT;
	else iOpta[1] |= D_PRN_OPT_LTGT;
	return cl_edit_opta(pAns,nparm,ppParm,iOpta);
}

/********1*********2*********3*********4*********5*********6*********/
/*		IN  : pInfoParm    : BIN  : �����R�[�h						*/
/*							 CHAR : �R�[�h������					*/
/*			  tr_dtypea[0] : �����R�[�h�̃f�t�H���g�l				*/
/*		OUT : tr_dtypea[0] : 1)�R�[�h������=0�̂Ƃ��́A�f�t�H���g	*/
/*							   �l��Ԃ��B							*/
/*							   �f�t�H���g�l=0�̂Ƃ��́Asystem��		*/
/*							   �����R�[�h��Ԃ��B					*/
/*							 2)�R�[�h������>0�̂Ƃ��́A�Ή�����	*/
/*							   �����R�[�h��Ԃ��B					*/
/*			  tr_code[0]   : �R�[�h�������Ԃ��B					*/
/********************************************************************/
int cl_get_code_type(pInfoParm,tr_dtypea,tr_code)
tdtInfoParm *pInfoParm;
int  tr_dtypea[];
char *tr_code[];
{
	int  ret,len,outlen,i,i1,tr_dtype,atr,opt,i0,tr_stype,n,val;
	char ww[16],*p1,*p,**code_str,*pospa[2],*argv[10],parm[128];

	if (!pInfoParm && !tr_dtypea && !tr_code) return 0;
	ret = 0;
	if (tr_dtypea) tr_dtype = tr_dtypea[0];
	p = "";
	if (pInfoParm) {
		atr = pInfoParm->pi_attr;
		if (atr == DEF_ZOK_BINA) {
			tr_dtype = cl_get_data_int(pInfoParm);
		}
		else {
			p = ww;
			if (!(ret = parm_to_char(pInfoParm,&p,0))) atr = DEF_ZOK_BINA;
			else {
				if ((n=akxtnsplit(p,ret,argv,10,parm,sizeof(parm)," ,+/|",5,0)) < 0) return n;
				tr_dtype = 0;
				for (i=0;i<n;i++) {
					/* 2023.2.18 */
					val = akxc_get_code_num2(argv[i],pospa);
/*
printf("cl_get_code_type: val=%08x\n",val);
*/
					if (val > 0) {
						tr_dtype |= val;
						p = pospa[0];
/*
printf("cl_get_code_type: tr_dtype=%d pospa[0]=[%s] pospa[1]=[%s]\n",tr_dtype,p,pospa[1]);
*/
					}
					else {
						/* �ϊ��f�[�^�^�C�v(%s)������Ă��܂��B*/
						ERROROUT1(FORMAT(601),argv[i]);
						ret = ECL_SCRIPT_ERROR;
					}
				}
			}
		}
	}
	else atr = DEF_ZOK_BINA;
	if (!ret && atr==DEF_ZOK_BINA){
		if (!tr_dtype) tr_dtype = akxt_get_code_type();
		if (!(p=akxc_get_code_str(tr_dtype))) {
			/* �ϊ��f�[�^�^�C�v(%d)������Ă��܂��B*/
			ERROROUT1(FORMAT(602),tr_dtype);
			ret = ECL_SCRIPT_ERROR;
		}
	}
	if (tr_dtypea) tr_dtypea[0] = tr_dtype;
	if (tr_code) tr_code[0] = p;
	return ret;
}

/****************************************/
/*	rstr=str_conv(str, to [,from])		*/
/****************************************/
/* 2022.11.21 */
int cl_func_str_conv(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	char *outbuf;		/* output buffer  */
	int  ret,len,outlen,i,i1,tr_dtype,atr,tr_dtypea[2],opt,i0,tr_stype;
	int  opta[10],max_opta,len_cmd;
	char ww[16],*p1,*tr_code[2],*p,cmd[3],c,*pAns;
	tdtInfoParm *pInfoParm,tInfoParm[2],*ppParm2[2];
	ParList parl;
	ParList2 parl2;

DEBUGOUT_InfoParm(161,"cl_func_str_conv: nparm=%d ppParm[0]=",ppParm[0],nparm,0);
if (nparm >= 2) DEBUGOUT_InfoParm(161,"cl_func_str_conv: ppParm[1]=",ppParm[1],0,0);

	p1 = ww;
	if ((ret = parm_to_char(ppParm[0],&p1,0)) < 0) return ret;
	outbuf = p1;
	len = ret;
	ret = 0;
/*
printf("cl_func_str_conv: len=%d p1=[%s]\n",len,p1);
*/
	/* tr_dtypea[0] : to_code   */
	/* tr_dtypea[1] : from_code */
	tr_dtypea[0] = 0;
	tr_dtypea[1] = cl_get_char_code_type(ppParm[0],2);	/* 1-->2 2023.2.18 */
/*
printf("cl_func_str_conv: tr_dtypea[1]=%d\n",tr_dtypea[1]);
*/
	tr_code[0] = tr_code[1] = "";
	i1 = 1;
	nparm--;
	for (i=0;i<nparm;i++) {
		/* 2022.4.10 */
		pInfoParm = ppParm[i1];
		if ((ret=cl_get_code_type(pInfoParm,&tr_dtypea[i],&tr_code[i])) < 0) return ret;
/*
printf("cl_func_str_conv: i=%d tr_dtype=%d tr_code=[%s]\n",i,tr_dtypea[i],tr_code[i]);
*/
		if (tr_dtypea[i] & CD_TYPE_FACEMRK) {
			if (i > 0) {
						/* %s: �� %d �p�����[�^������Ă��܂�(rc=%d)�B*/
				ERROROUT3(FORMAT(47),"cl_func_str_conv",i+1,tr_dtypea[i]);
				return ECL_SCRIPT_ERROR;
			}
			tr_code[i] = "";
		}
		i1++;
	}
/*
printf("cl_func_str_conv: tr_dtype=%d\n",tr_dtype);
*/
	/* 2022.11.21 */
	if (len > 0) {
		tr_dtype = tr_dtypea[0];
		tr_stype = tr_dtypea[1] & CD_TYPE_CODE;
/*
printf("cl_func_str_conv: tr_dtype=%08x tr_stype=%d\n",tr_dtype,tr_stype);
*/
		if (tr_dtype & CD_TYPE_FACEMRK) {
			max_opta = 0;
			opt = tr_dtype & CD_TYPE_FACE;
			if (opt & CD_TYPE_FRGANA) opta[max_opta++] = CD_TYPE_FRGANA;
			if (opt & CD_TYPE_KTKANA)      opta[max_opta++] = CD_TYPE_KTKANA;
			else if (opt & CD_TYPE_HRGANA) opta[max_opta++] = CD_TYPE_HRGANA;
			if (opt & CD_TYPE_HEBON) opta[max_opta++] = CD_TYPE_HEBON;
			if (opt & CD_TYPE_PROPER) opta[max_opta++] = tr_dtype & CD_TYPE_PROPER;
			if (opt & CD_TYPE_WIDE)        opta[max_opta++] = CD_TYPE_WIDE;
			else if (opt & CD_TYPE_NARROW) opta[max_opta++] = CD_TYPE_NARROW;
/*
printf("cl_func_str_conv: max_opta=%d\n",max_opta);
*/
		/*	tr_dtype = tr_stype;	*/
			for (i=0;i<max_opta;i++) {
				opt = opta[i];
/*
printf("cl_func_str_conv: i=%d opt=%08x\n",i,opt);
*/
				if (opt==CD_TYPE_NARROW || opt==CD_TYPE_WIDE) {
					outlen = len*4 + 1;
					outbuf = cl_tmp_const_malloc(outlen);
/*
printf("cl_func_str_conv: outlen=%d outbuf=%08x\n",outlen,outbuf);
*/
					if (opt == CD_TYPE_NARROW)
						ret = akxctohan_type(len,p1,outbuf,tr_stype);
					else
						ret = akxctozen_type(len,p1,outbuf,tr_stype);
					p1 = outbuf;
					len = ret;
					/* 2022.11.21 */
				/*	tr_dtype = tr_stype;	*/
				}
				else if (opt==CD_TYPE_UPPER || opt==CD_TYPE_LOWER || opt==CD_TYPE_PROPER ||
				         opt==CD_TYPE_KTKANA || opt==CD_TYPE_HRGANA || opt==CD_TYPE_FRGANA ) {
					cmd[1] = '\0';
					len_cmd = 1;
					if (opt == CD_TYPE_UPPER) c = 'U';
					else if (opt == CD_TYPE_LOWER) c = 'L';
					else if (opt == CD_TYPE_KTKANA) c = 'K';
					else if (opt==CD_TYPE_HRGANA || opt==CD_TYPE_FRGANA) {
						c = 'K';
						if (opt == CD_TYPE_HRGANA) cmd[1] = 'H';
						else cmd[1] = 'F';
						cmd[2] = '\0';
						len_cmd = 2;
					}
					else c = 'P';
					ppParm2[0] = &tInfoParm[0];
					ppParm2[1] = &tInfoParm[1];
					cl_set_parm_char2(ppParm2[0],p1,len,tr_stype);
					cmd[0] = c;
/*
printf("cl_func_str_conv: cmd=[%s]\n",cmd);
*/
					cl_set_parm_char(ppParm2[1],cmd,len_cmd);
					if ((ret=cl_cmpt_to(&pAns,"TO",2,ppParm2,0,0)) < 0) return ret;
					cl_sep_string_with_type(&parl2,pAns,strlen(pAns));
					p1 = outbuf = parl2.par;
					ret = len = parl2.parlen;
				}
				else if (opt == CD_TYPE_HEBON) {
					outlen = len*2 + 1;
					outbuf = cl_tmp_const_malloc(outlen);
					ret = akxc_to_hebon(&parl,p1,len,SET_TYPE_OPT(tr_stype));
					if (ret >= 0) memzcpy(outbuf,parl.par,ret);
					p1 = outbuf;
					len = ret;
				}
			}
			if (!(tr_dtype & CD_TYPE_CODE)) tr_dtypea[0]  = tr_stype;
		}
		tr_dtypea[0] &= CD_TYPE_CODE;
		tr_dtypea[1] &= CD_TYPE_CODE;
		if (akxq_code_type_cmp(tr_dtypea[0],tr_dtypea[1])) {
/*
printf("cl_func_str_conv: tr_dtypea[0]=%08x tr_dtypea[1]=%08x\n",tr_dtypea[0],tr_dtypea[1]);
printf("cl_func_str_conv: tr_code[0]=[%s] tr_code[1]=[%s]\n",tr_code[0],tr_code[1]);
*/
			ret = _func_str_conv(&outbuf,tr_dtypea,tr_code,p1,len);
		}
		tr_dtype = tr_dtypea[0];
	}
	if (ret >= 0) {
/*
printf("cl_func_str_conv: ret=%d outbuf=[%s]\n",ret,outbuf);
*/
		cl_set_parm_char2(pInfoParmW,outbuf,ret,tr_dtype);
		ret = 0;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int _func_str_conv_sub(pAns,tr_dtypea,tr_code,p1,len)
char **pAns;
int  tr_dtypea[],len;
char *tr_code[],*p1;
{
	int  ret,opt,tr_dtype,tr_stype;
	char *p,*pW,*tr_codew[2];

	ret = 0;
/*
printf("_func_str_conv: tr_code[0]=[%s] tr_code[1]=[%s] tr_dtypea[0]=%d tr_dtypea[1]=%d\n"
,tr_code[0],tr_code[1],tr_dtypea[0],tr_dtypea[1]);
*/
	opt = (cl_get_option(9,0) & 0x30)<<12;
/*	pW = p1;	*/
	p = p1;
	/* 2023.2.18 */
	tr_dtype = tr_dtypea[0];
	tr_stype = tr_dtypea[1];
	if (!akxq_code_type_cmp(tr_dtype,tr_stype)) {
		p = p1;
		ret = len;
	}
	else {
		if (!tr_code) {
			tr_code = tr_codew;
			tr_code[1] = tr_code[0] = "";
		}
		if (!*tr_code[0]) {
			if (!tr_dtype) tr_dtype = akxt_get_code_type();
			tr_code[0] = akxc_get_code_str(tr_dtype);
		}
		if (!*tr_code[1]) tr_code[1] = akxc_get_code_str(tr_stype);
/*
printf("_func_str_conv: tr_code[0]=[%s] tr_code[1]=[%s]\n",tr_code[0],tr_code[1]);
*/
		ret = akxc_str_conv(&p,tr_dtypea,tr_code,p1,len,opt);
	}
#if 0
	if (ret >= 0) {
		if (!(pW = cl_tmp_const_malloc(ret+1))) return ECL_MALLOC_ERROR;
		memzcpy(pW,p,ret);
		if (p != p1) Free(p);
	}
/*
printf("_func_str_conv: pW=[%s]\n",pW);
*/
#endif
/*	if (pAns) *pAns = pW;	*/
	if (pAns) *pAns = p;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int _func_str_conv(pAns,tr_dtypea,tr_code,p1,len)
char **pAns;
int  tr_dtypea[],len;
char *tr_code[],*p1;
{
	char *p,*pW;
	int ret;

	pW = p1;
	ret = _func_str_conv_sub(&p,tr_dtypea,tr_code,p1,len);
	if (ret >= 0) {
		if (!(pW = cl_tmp_const_malloc(ret+1))) return ECL_MALLOC_ERROR;
		memzcpy(pW,p,ret);
		if (p != p1) Free(p);
	}
/*
printf("_func_str_conv: pW=[%s]\n",pW);
*/
	if (pAns) *pAns = pW;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_str_conv_type_opt(pp2,p1,len1,typed,types,opt)
char *p1,**pp2;
int len1,typed,types,opt;
{
	char *p;
	int  ret,tr_dtypea[2];
	tdtGeneralData tParms,tParmd;
/*
printf("cl_str_conv_type: len1=%d typed=%d types=%d\n",len1,typed,types);
*/
	if (!types) types = akxt_get_code_type();
	if (!typed) typed = akxt_get_code_type();
	if (types==typed || len1<=0) {
		if (pp2) *pp2 = p1;
		ret = len1;
	}
	else {
		/* 2022.12.3 */
		tr_dtypea[0] = typed;
		tr_dtypea[1] = types;
		if (opt) ret = _func_str_conv(pp2,tr_dtypea,NULL,p1,len1);
		else ret = _func_str_conv_sub(pp2,tr_dtypea,NULL,p1,len1);
	}
/*
printf("cl_str_conv_type: ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_str_conv_type(pp2,p1,len1,typed,types)
char *p1,**pp2;
int len1,typed,types;
{
	return cl_str_conv_type_opt(pp2,p1,len1,typed,types,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_str_conv_get(p2,p1,len1)
char *p1,**p2;
int len1;
{
	int opt,typed,types;

	opt = cl_get_option(21,0);
	types = (opt>>8) & CD_TYPE_CODE;
	typed = akxt_get_code_type();
	return cl_str_conv_type(p2,p1,len1,typed,types);
}

/****************************************/
/*										*/
/****************************************/
int cl_str_conv_put_opt(p2,p1,len1,opt0)
char *p1,**p2;
int len1,opt0;
{
	int opt,types,typed;

	opt = cl_get_option(21,0);
	typed = opt & CD_TYPE_CODE;
	types = akxt_get_code_type();
	return cl_str_conv_type_opt(p2,p1,len1,typed,types,opt0);
}

/****************************************/
/*										*/
/****************************************/
int cl_str_conv_put(p2,p1,len1)
char *p1,**p2;
int len1;
{
	return cl_str_conv_put_opt(p2,p1,len1,1);
}

/****************************************/
/*										*/
/*	opt: =	0x07 �ȉ��Ƀ}�b�v����		*/
/*			0 --> D_OPT_ALC_TMP    (3)	*/
/*			1 --> D_OPT_ALC_MALLOC (4)	*/
/*			2 --> D_OPT_ALC_SCR    (2)	*/
/*			3 --> D_OPT_ALC_TMP    (3)	*/
/*			4 --> D_OPT_ALC_MALLOC (4)	*/
/*			5 --> D_OPT_ALC_LEAF   (0)	*/
/*			6 --> D_OPT_ALC_CONST  (1)	*/
/****************************************/
int cl_get_info_str(pInfoParm,ppStr,opt)
tdtInfoParm	*pInfoParm;
char **ppStr;
int opt;
{
	int len1,ret,attr,im,dec_pre,pre,size,p_len;
	long value;
	char *p,*pp;
	double dValue,dw;
	MPA *mpa;
/*
printf("cl_get_info_str: pInfoParm=%08x ppStr=%08x\n",pInfoParm,ppStr);
*/
	if (!pInfoParm || !ppStr) return -1;

	im = opt & 0x07;
	if (!im) im = D_OPT_ALC_TMP;
	else if (im == 1) im = D_OPT_ALC_MALLOC;
	else if (im >= 5) im -= 5;
	p = NULL;
	*ppStr = p;

	if (ret=cl_check_data_id(pInfoParm,0)) return ret+ECL_CHK_VAR_ERROR;

	if ((attr=pInfoParm->pi_attr) == DEF_ZOK_BINA) {
		p_len = 32;
		value = cl_get_data_long(pInfoParm);
		if (!(p = cl_opt_malloc(im,p_len))) {
			ERROROUT("cl_get_info_str: BINA p cl_opt_malloc error");
			return ECL_MALLOC_ERROR;
		}
		if (pInfoParm->pi_scale & D_DATA_UNSIGNED) akxcultoa(value,p,10,p_len);
		else akxcltoa(value,p,10,p_len);
		len1 = strlen(p);
/*
printf("cl_get_info_str: p=[%s]\n",p);
*/
	}
	else if (attr == DEF_ZOK_FLOA) {
		p_len = 32;
		memcpy(&dValue,pInfoParm->pi_data,sizeof(double));
		if (!(p = cl_opt_malloc(im,p_len))) {
			ERROROUT("cl_get_info_str: FLOA p cl_opt_malloc error");
			return ECL_MALLOC_ERROR;
		}
		if ((len1=cl_double_to_str(p,p_len,dValue)) < 0) return len1;
	}
	else if (attr == DEF_ZOK_CHAR) {
		len1 = pInfoParm->pi_dlen;
/*
printf("cl_get_info_str: attr=%d len1=%d\n",attr,len1);
*/
		pp = pInfoParm->pi_data;
		len1 = akxstrnlen(pp,len1);
		if (len1 > 0) {
/*
printf("cl_get_info_str: p1=[%s]\n",*p1);
*/
			if (pInfoParm->pi_scale & 0x80) p = pp;
			else {
				if (!(p = cl_opt_malloc(im,len1+1))) {
					ERROROUT("cl_get_info_str: CHAR p cl_opt_malloc error");
					return ECL_MALLOC_ERROR;
				}
				memzcpy(p,pp,len1);
			}
		}
		else p = "";
	}
	else if (attr == DEF_ZOK_BULK) {
		len1 = pInfoParm->pi_dlen;
		if (len1>0) {
			if (!(p = cl_opt_malloc(im,len1*D_BULK_TYPE+1))) {
				ERROROUT("cl_get_info_str: BULK p cl_opt_malloc error");
				return ECL_MALLOC_ERROR;
			}
			len1 = clcnvtb2c(pInfoParm->pi_data,len1,p);
		}
	}
	else if (attr == DEF_ZOK_DATE) {
		if (!(p = cl_opt_malloc(im,20))) {
			ERROROUT("cl_get_info_str: DATE p cl_opt_malloc error");
			return ECL_MALLOC_ERROR;
		}
		len1 = akxc_date2uxstr(p,20,NULL,pInfoParm->pi_data);
	}
	else if (attr) {
		/* %s: �f�[�^�^(%d)���s���ł��B */;
		ERROROUT2(FORMAT(395),"cl_get_info_str",attr);
		len1 = ECL_SCRIPT_ERROR;
	}
	else {
		/* parm_to_char: �ϐ��܂��̓f�[�^������`�ł��B */
		ERROROUT(FORMAT(286));
		len1 = ECL_NDEFVAR_ERROR;
	}
	*ppStr = p;
/*
printf("cl_get_info_str:Exit len1=%d\n",len1);
*/
	return len1;
}
