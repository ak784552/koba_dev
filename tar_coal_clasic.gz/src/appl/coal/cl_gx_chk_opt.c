static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ���Z�q�`�F�b�N����                    �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_chk_opt( pOperator )                         *
*                      (I)Char     *pOperator                                 *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;
extern GlobalCt  *pGlobTable;
extern CLCOMMON  CLcommon;
extern char cmp_sep2[];
extern char cmp_sep3[];
extern char cmp_sep[];
extern char *cl_opt_malloc();

static char *logical[]={"AND","OR","NOT","&&","||","!",NULL};
static char *math[]={"+","-","*","/","&","^","|","~","%","<<",">>","**",">>>","..",NULL};
static char *hk[]={"<=","=<",">=","=>","==","==","<>","><","!=","!=","<",">",NULL};
static char *HK[]={"LT","GT","LE","GE","EQ","NE","iEQ","iNE",NULL};
static char *ex[]={"&=","^=","|=","","","","","","~=","",
"*=","/=","%=","+=","-=","<<=",">>=","&+=","|+=",">>>=",NULL};
static char *cast[]={"CCHAR","CBIN","CINT","CLONG","CLNG","CDEC","CFLOAT","CFLT","CDOUBLE","CDBL","CBULK","CDATE","FUNC",NULL};

int cl_gx_chk_opt(pOperator,ex_opt)
char *pOperator;
int  ex_opt;
{
	int  rc,parm[6],len,opt;
	char c;

	opt = 1;
	if (ex_opt & D_GX_OPT_PROC_NAME) opt |= 2;
	if      (rc = cl_gx_is_operator(pOperator,MATH)) ;
	else if (rc = cl_gx_is_operator(pOperator,COMP)) ;
	else if (rc = cl_gx_is_operator(pOperator,LOGICAL)) ;
	else if (cl_get_func_info(pOperator,parm)) rc = parm[2];
	else {
		len = strlen(pOperator);
		c = *pOperator;
		if ((c>='A' && c<='Z') || (c>='a' && c<='z')) {
			if (cl_chk_sysvar_name(pOperator,len)) rc = SYSVAR;
		}
		if (!rc) {
			if (!cl_chk_name_opt(pOperator,len,opt)) rc = NAME_CONST /*VAR or FUNCTION*/;
#if 1	/* 2022.10.17 */
			else if (!rc && len==1) {
				if (cl_gx_is_separator(c)) rc = SEPARATOR;
			}
#endif
		}
	}
/*
printf("cl_gx_chk_opt: pOperator=[%s] rc=%d\n",pOperator,rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _match(name_list,name)
char *name_list[],*name;
{
	char **nl,*p;
	int i;
/*
printf("_match: name=[%s]\n",name);
*/
	nl = name_list;
	for (i=1;p=*nl;i++,nl++) {
/*
printf("_match: i=%d p=[%s]\n",i,p);
*/
		if(!stricmp(p,name)) return i;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_is_operator(pOperator,kubun)
char *pOperator;
int  kubun;
{
	int rc;
	char c,*p=pOperator;

	rc = 0;
	switch (kubun) {
		case MATH:
			if (_match(math,p)) rc = kubun;
			break;
		case COMP:
			if (_match(hk,p) || _match(HK,p)) rc = kubun;
			break;
		case LOGICAL:
			if (_match(logical,p)) rc = kubun;
			break;
		case FUNCCAST:
			if (_match(cast,p)) rc = kubun;
			else {
				if ((c=*p)=='C' || c=='c') {
					if ((c=*(p+1))!='H' && c!='h') p++;
				}
				if (cl_get_name_attr(p,strlen(p),0x01,0x20)) rc = kubun;
			}
			break;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_is_separator(c)
char c;
{
/*	if (strchr(cmp_sep,c)) return 1;	*/
	if (strchr(cmp_sep2,c)) return 1;
	else return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_is_func_kubun(i)
int i;
{
	if (i==FUNCMATH || i==FUNCTION || i==FUNCFILE || i==FUNCLOG || i==FUNC_OPE) return 1;
	else return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_im_mman_init(mcat,id,extlen,maxcnt,im)
MCAT *mcat;
char *id;
int  extlen,maxcnt,im;
{
	if (!mcat) return -1;
	memset(mcat,0,sizeof(MCAT));
	mcat->mc_id[0] = *id;
	mcat->mc_extlen = extlen;
	mcat->mc_maxcnt = maxcnt;
	if (im<0 || im>4) return -2;
	mcat->mc_id[1] = im;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_im_mcat(mcat,s,len)
MCAT *mcat;
char *s;
int len;
{
	return akxtmmanfunc(2,mcat,s,len,cl_opt_malloc);
}

/****************************************/
/*										*/
/****************************************/
int cl_im_mcatz(mcat,s,len)
MCAT *mcat;
char *s;
int len;
{
	akxtmmanfunc(2,mcat,s,len,cl_opt_malloc);
	akxtmmanfunc(2,mcat,"",1,cl_opt_malloc);
	return --mcat->mc_ipos;
}
