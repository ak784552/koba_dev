static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �d�m�c�h�e�R�}���h���C��                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_end_if( pLeaf, pProc )                  *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                      (I)ProcCT        * pProc                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/

#include "colmn.h"

extern CLCOMMON  CLcommon;
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

int cl_process_end_if(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int irc,id,blk_id;
	BlockCB *pIfCB;
	Leaf  *Dummy;

	if (!(pIfCB = pProc->pcrBlockCB)) return -1;
	blk_id = pIfCB->cid;

DEBUGOUTL2(110,"cl_process_end_if: Enter cid=%08x %s",blk_id,cl_gets_cmd_name(blk_id));

	if (blk_id == C_IF) ;
	else return -1;

	irc = 0;
	id = pLeaf->cmd.cid;
	if (id == C_ENDIF) {
		id = C_IF;
	}
	else return -1;
	if (blk_id == id) {
		pIfCB->iUsed = 0;
		pProc->pcrBlockCB = pIfCB->preBlockCB;
	}

DEBUGOUTL1(110,"cl_process_end_if: Return pProc->pcrBlockCB=%08x",pProc->pcrBlockCB);

	return irc;
}
