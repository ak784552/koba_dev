static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************************/
/*                                                   */
/*       Execute expression imediately               */
/*                                                   */
/*****************************************************/
#include "colmn.h"

extern GlobalCt  *pGlobTable;
extern CLCOMMON  CLcommon;
extern int giOptions[];
extern char cmp_sep2[];
extern char cmp_sep3[];
/* 2021.11.1 */
extern char cmp_sep[];

static char *logical[]={"AND","OR","NOT","&&","||","!",NULL};
static char *math[]={"+","-","*","/","&","^","|","~","%","<<",">>","**",">>>","..",NULL};
static char *hk[]={"<=","=<",">=","=>","==","==","<>","><","!=","!=","<",">",NULL};
static char *HK[]={"LT","GT","LE","GE","EQ","NE","iEQ","iNE",NULL};
static char *ex[]={"&=","^=","|=","","","","","","~=","",
"*=","/=","%=","+=","-=","<<=",">>=","&+=","|+=",">>>=",NULL};
static char *cast[]={"CCHAR","CBIN","CINT","CLONG","CLNG","CDEC","CFLOAT","CFLT","CDOUBLE","CDBL"
	,"CBULK","CDATE","FUNC","CIMG","CIMAGE",NULL};

/****************************************/
/*										*/
/****************************************/
int cmppeekwnsl(line,line_len,ssp,ex_opt)
char *line;
int  line_len,ex_opt;
SSPL_S *ssp;
{
	int sp,ret,attr0;

	attr0 = ssp->attr[1];	/* add 2023.05.27 */
	sp = ssp->sp;
	ret = cmpgwnsl(line,line_len,ssp,ex_opt);
	ssp->attr[1] = attr0;	/* add 2023.05.27 */
	ssp->sp = sp;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cmp_peekwd(gwprm,ssp,ex_opt)
GWPRM_S *gwprm;
SSPL_S  *ssp;
int ex_opt;
{
	GWPRM_S qgwprm;
	SSPL_S  qssp;
	parmList *pparmList;
	char *line;

	if (!gwprm || !ssp) return -1;

	memcpy(&qgwprm,gwprm,sizeof(GWPRM_S));
	memcpy(&qssp,ssp,sizeof(SSPL_S));
	return cmp_gtwd(&qgwprm,&qssp,ex_opt);
}

/****************************************/
/*										*/
/****************************************/
int cmpgtwdx(line,line_len,ssp,ex_opt)
char *line;
int  line_len,ex_opt;
SSPL_S *ssp;
{
	SSPL_S  qssp;
	char *wd0,c,c1,wrk_sep[32];
	int  len0,len,i,attr0,gw_opt;

	strcpy(wrk_sep,cmp_sep3);
	if (!(ex_opt & D_GX_OPT_PROC_NAME)) strcat(wrk_sep,"-");
	gw_opt = 0x845;
	attr0 = ssp->attr[1];
	if ((len=akxtgwnsl(line,line_len,ssp,wrk_sep,gw_opt)) <= 0) {
		if (len == -1) len = 0;
		return len;
	}
	if ((i=ssp->attr[0]) > 10) {
		if (*ssp->wd=='.') {
/*
printf("cmpgtwdx: attr0=%02x c=[%c]\n",attr0,line[ssp->sp]);
*/
DEBUGOUTL3(152,"cmpgtwdx: attr0=%02x c=[%c] ssp->sp=%d",attr0,line[ssp->sp],ssp->sp);

			if ((c=line[ssp->sp])=='.') {
				strcpy(ssp->wd,"..");
				ssp->sp++;
				len = 2;
/*
printf("cmpgtwdx: wd=%s\n",ssp->wd);
*/
			}
			/* ���O���A�����萔 NAME ) ] } �̂Ƃ��́A�h�b�g���Z�q�ƌ��Ȃ�
			  (�����̂Ƃ��́A���ɁA���l�萔�ƂȂ��Ă��āA�����ɂ͗��Ȃ� */
			else if ((attr0>0 && attr0<=10) || attr0==0xa9 || attr0==0xdd || attr0==0xfd) ;
			else if (c>='0' && c<='9') {
				qssp.wd = ssp->wd;
				len0 = len;
				ssp->wd += len;
				len = akxtgwnsl(line,line_len,ssp,wrk_sep,gw_opt);
				ssp->wd = qssp.wd;
				if (len > 0) len0 += len;
				len = len0;
			}
		}
		return len;
	}
	else if (i != 1) return len;
	else if ((c=*ssp->wd)<'0' || c>'9') return len;
	memcpy(&qssp,ssp,sizeof(SSPL_S));
	len0 = len;
	qssp.wd += len;
	len = akxtgwnsl(line,line_len,&qssp,wrk_sep,gw_opt);
	if (len>0 && *qssp.wd=='.') {
		if ((c=line[qssp.sp]) == '.') {
			if (ssp->wdmax) ssp->wd[len0] = '\0';
			return len0;
		}
		else if ((c>='0' && c<='9') ||
		         (strchr("efdEFD",c) &&
				  (((c1=line[qssp.sp+1])>='0' && c1<='9') || c1=='-' || c1=='+'))) {	/* 2023.8.7 add '-','+' */
			qssp.wd++;
			len0++;
			len = akxtgwnsl(line,line_len,&qssp,wrk_sep,gw_opt);
			ssp->sp = qssp.sp;
			if (len > 0) len0 += len;
			return len0;
		}
		else if (strchr(cmp_sep,c)) {
			len0++;
			ssp->sp = qssp.sp;
		}
	}
	if (ssp->wdmax) ssp->wd[len0] = '\0';
	return len0;
}

/****************************************/
/*										*/
/****************************************/
static int _chk_point(line,ssp,len0)
char *line;
SSPL_S *ssp;
int len0;
{
	int k,len=len0;
	char *spwd;

	spwd = ssp->wd;
	if ((k=akxnskipto(spwd,len,".")) < len) {
		ssp->sp -= len-k;
		while (line[ssp->sp] != '.') ssp->sp--;
		len = k;
		if (ssp->wdmax) *(spwd+len) = '\0';
	}
	return len;
}

/****************************************/
/*										*/
/****************************************/
static int _chk_number(line,line_len,ssp,len0,cmp_sep)
char *line;
int  line_len;
SSPL_S *ssp;
int len0;
char *cmp_sep;
{
	int k,len=len0;
	char *spwd,c,*p;

	spwd = ssp->wd;
	if ((c=toupper(spwd[len-1]))=='E' || c=='D') {
		if ((c=line[ssp->sp])=='+' || c=='-' ||
		    (c>='0' && c<='9')) {
			p = spwd + len;
			if (c=='+' || c=='-') {
				*p++ = c;
				ssp->sp++;
			}
			ssp->wd = p;
			akxtgwnsl(line,line_len,ssp,cmp_sep,0x5);
			ssp->wd = spwd;
/*
printf("cmp_gtwd: wd=[%s]\n",spwd);
*/
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cmpgwnsl(line,line_len,ssp,ex_opt)
char *line;
int  line_len,ex_opt;
SSPL_S *ssp;
{
	parmList  **prmp;
	int len,atr,i,k,kk;
	char wk[5],c,*p,*spwd;

	atr=0;
	if ((len=cmpgtwdx(line,line_len,ssp,ex_opt)) <= 0) return len;
	ssp->attr[1] = ssp->attr[0];
	spwd = ssp->wd;

DEBUGOUTL4(152,"cmpgwnsl:cmpgtwdx len=%d, wd=[%s] ssp.sp=%d ssp.attr[0]=%d",
len,spwd,ssp->sp,ssp->attr[0]);

	if ((k=ssp->attr[0]) < 10) {
		if (k >= 5) atr = 5000;
		else {
			if ((c=*spwd)=='.' || (c>='0' && c<='9')) {
				atr=5000;
				_chk_number(line,line_len,ssp,len,cmp_sep);
			}
			else if (len >= 2 && len <= 3) {
#if 0	/* 2022.6.4 �֐��ł��g�p�ł���悤�ɂ��邽�߉��Z�q�Ƃ��Ȃ� */
				for(i=0,p=HK[0];p=HK[i];i++) {
					if (!akxstricmp2(spwd,len,p,strlen(p))) {
						if (i >= 6) atr=i+59;
						else atr=i+31;
						return atr;
					}
				}
#endif
				if (!akxstricmp2(spwd,len,"OR",2)) atr=61;	/*atr=52;*/
				else if (!akxstricmp2(spwd,len,"NEW",3)) atr=13;
			}
		}
		if (!atr) {
			i = cl_gx_chk_opt(spwd,ex_opt);
			if (i==IS || i==TO || i==COMP || i==FUNC_OPE) atr=61;
			else if (cl_gx_is_func_kubun(i)) atr=62;
			else if (i==FUNCCAST) atr = 10001;
			else if (i==STRING) {
				if (!akxstricmp2(spwd,len,"CONCAT",6) && line[ssp->sp]=='=') {
					atr = 88;
					ssp->sp++;
					strcpy(spwd,"&+=");
				}
				else atr = 61;
			}
			else if (i==SYSVAR) {
				atr = 4000;	/* System Var. */
			}
			else if (i==NAME_CONST) {
				len = _chk_point(line,ssp,len);
				atr = 10000;
			}
			else if (!akxstricmp2(spwd,len,"AND",3)) atr=61;	/*atr=51;*/
			else if (!akxstricmp2(spwd,len,"NOT",3)) {
				if (line[ssp->sp] == '=') {
					atr = 36;
					ssp->sp++;
					strcpy(spwd,"!=");
				}
				else atr=18;
			}
			else if (!akxstricmp2(spwd,len,"MOD",3) ||
			         !akxstrcmp2(spwd,len,"%",1)) {
				if (line[ssp->sp] == '=') {
					atr = 83;
					ssp->sp++;
					strcpy(spwd,"%=");
				}
				else if (!akxstricmp2(spwd,len,"MOD",3)) atr = 63;
				else atr = 23;
			}
			else if (!akxstricmp2(spwd,len,"ABS",3)) {
				atr = 28;
			}
			else {
				atr=5000;
				len = _chk_point(line,ssp,len);
				if (c=='%' || c=='#') atr = 3000;	/* Variable */
				else if (c=='$') {
					if (cl_chk_sysvar_name(spwd+1,len-1)) atr = 4000;	/* SYSVAR */
					else atr = 3000;	/* Variable */
				}
			}
		}
	}
	else if (len==2) atr=D_IMD_RANGE;	/* .. */
	else if ((c=spwd[0])==';') atr=99;
	else if (c=='.') atr=29;
	else if (c==',') atr=98;
	else if (c=='(') atr=1;
	else if (c==')') atr=2;
	else if (c=='[') atr=3;
	else if (c==']') atr=4;
	else if (c=='{') atr=7;
	else if (c=='}') atr=8;
	else {
		wk[0]=c;
		wk[1]=line[ssp->sp];
		wk[2]='\0';
		for(i=0,p=hk[0];p=hk[i];i++) {
			if (!strcmp(wk,p)) {
				if (i<10) {
					atr=(i/2)+33;
					if (atr==37) atr=36;
					else if (atr==33 || atr==35) break;	/* <=, == */
					ssp->sp++;
					strcpy(spwd,wk);
				}
				else {
					atr = i + 21;	/* <, > */
/*
printf("cmp_gtwd: hk: wk=[%s] i=%d atr=%d\n",wk,i,atr);
*/
				}
				return atr;
			}
		}
		if (!strcmp(wk,"<<")) atr=26;
		else if (!strcmp(wk,">>")) atr=27;
		else if (!strcmp(wk,"&+")) atr=61;
		else if (!strcmp(wk,"|+")) atr=61;
		if (atr) {
			k = ssp->sp + 1;
/*
printf("cmp_gtwd: line_len=%d k=%d\n",line_len,k);
*/
			if (k<line_len) {
				c = line[k];
				if (atr==33) {
					if  (c=='=') {
						atr = D_IMD_PNAME;
						strcpy(&wk[2],"=");
						ssp->sp++;
					}
				}
				else if (atr==35) {
					if  (c=='>') {
						atr = D_IMD_NAMED;
						strcpy(&wk[2],">");
						ssp->sp++;
					}
				}
				else if (c=='=') {
					if (atr==61) {
						atr = 88;
						strcpy(wk,"&+=");
					}
					else {
						atr += 60;
						strcpy(&wk[2],"=");
					}
					ssp->sp++;
				}
				else if (atr==27) {
					if  (c=='>') {
						atr = 48;
						strcpy(&wk[2],">");
						ssp->sp++;
						k = ssp->sp + 1;
						if (k<line_len) {
							c = line[k];
							if (c == '=') {	/* >>>= */
								atr = 89;
								strcpy(&wk[3],"=");
								ssp->sp++;
							}
						}
					}
				}
			}
			ssp->sp++;
			strcpy(spwd,wk);
/*
printf("cmp_gtwd: wk=[%s]\n",wk);
*/
			return atr;
		}
		for(i=0,p=ex[i];p=ex[i];i++) {
			if (!strcmp(wk,p)) {
				atr=i+71;
				ssp->sp++;
				strcpy(spwd,wk);
				return atr;
			}
		}
		if (!strcmp(wk,"++")) atr=14;
		else if (!strcmp(wk,"--")) atr=15;
		else if (!strcmp(wk,"||")) atr=52;
		else if (!strcmp(wk,"&&")) atr=51;
		else if (!strcmp(wk,"!!")) atr=16;
		else if (!strcmp(wk,"~~")) atr=17;
		else if (!strcmp(wk,"**")) atr=30;
		if (atr) {
			ssp->sp++;
			strcpy(spwd,wk);
		}
		else if (c=='*') atr=21;
		else if (c=='/') atr=22;
		else if (c=='+') atr=24;
		else if (c=='-') atr=25;
		else if (c=='=') atr=90;
		else if (c=='!') atr=18;
		else if (c=='~') atr=19;
		else if (c=='>') atr=32;
		/* 2021.12.29 */
		else if (c=='<') {
			atr=31;
			k = ssp->sp;
			if (k+1 < line_len) {
				if (c=='<' && line[k+1]=='>') {
					wk[0]=c;
					wk[1]=line[k];
					wk[2]=line[k+1];
					wk[3]='\0';
					strcpy(spwd,wk);
					ssp->sp = k + 2;
					atr = 10000;
/*
printf("cmp_gtwd: wk=[%s] ssp->sp=%d line[ssp->sp]=[%c]\n",wk,ssp->sp,line[ssp->sp]);
*/
				}
			}
		}
		else if (c=='&') atr=41;
		else if (c=='^') atr=42;
		else if (c=='|') atr=43;
		else if (c=='?') atr=59;
		else if (c==':') atr=60;
		else atr = -1;
	}
	return atr;
}

/****************************************/
/*										*/
/****************************************/
int cmp_gtwd(gwprm,ssp,ex_opt)
GWPRM_S *gwprm;
SSPL_S *ssp;
int ex_opt;
{
	return cmpgwnsl(gwprm->line,gwprm->line_len,ssp,ex_opt);
}


/****************************************/
/*	21									*/
/****************************************/
int cl_gx_exp_obj_opt(nparm,prmp,Obj,pInfoParm,opt)
int nparm;
parmList *prmp[];
int *Obj;
tdtInfoParm *pInfoParm;
int opt;
{
	static char *_fn_="cl_gx_exp_obj_opt";
	int rc,len,i,n;
	char *p,*pOperator,*argv[256],*work;
	tdtInfoParm InfoParm1,InfoParm2,*pInfoParm1,*pInfoParm2;
	parmList *parm,*pparm[256];

DEBUGOUTL3(120,"%s: nparm=%d opt=%08x",_fn_,nparm,opt);

	if (nparm > 0) {
		if (nparm == 1) {
/*
printf("cl_gx_exp_obj_opt: prmp[0]=%08x\n",prmp[0]);
*/
			p   = prmp[0]->prp;
			len = prmp[0]->prmlen;

DEBUGOUTL3(170,"%s: len=%d p=[%s]",_fn_,len,strmemk(p,len,"cl_gx_exp_obj_opt"));

			if (!(work=cl_tmp_const_malloc(len+len+1))) return ECL_MALLOC_ERROR;
			if ((n=cl_getitems(p,len,argv,256,work,len+len+1," \t")) < 0) return n;
		/*	if ((n=akxtgetargvns2(p,len,argv,256,work,sizeof(work)," ",0x10000)) < 0) return n;	*/
			else if (n >= 1) {
				len = n*sizeof(parmList);
				if (!(parm=(parmList *)cl_tmp_const_malloc(sizeof(parmList)*n))) return ECL_MALLOC_ERROR;
				memset(parm,0,len);
				for (i=0;i<n;i++) {
					pparm[i] = parm++;
					pparm[i]->prp = argv[i];
					pparm[i]->prmlen = strlen(argv[i]);

DEBUGOUTL3(170,"%s: i=%d argv[i]=[%s]",_fn_,i,argv[i]);

				}
				prmp = pparm;
				nparm = n;
			}

DEBUGOUTL2(170,"%s: n=%d",_fn_,n);

		}
		if (nparm == 2) {
			pOperator = prmp[0]->prp;
			cl_none_parm(&InfoParm1);
			rc = cl_conv_arg_opt(prmp[1],&InfoParm2,opt);

DEBUGOUTL4(170,"%s:1 rc=%d pOperator=[%s] var=[%s]",_fn_,rc,pOperator,prmp[1]->prp);

		}
		else if (nparm==1 || nparm>=3) {
			rc = 0;
			if (nparm >= 3) {
				pOperator = prmp[1]->prp;
				len = prmp[1]->prmlen;
				if (!cl_gx_is_operator(pOperator,COMP) && *(pOperator+len-1) == '=') {
					return cl_gx_compute_sub(nparm,prmp,NULL,opt);
				}
				rc = cl_conv_arg_opt(prmp[2],&InfoParm2,opt);

DEBUGOUTL2(170,"%s:2 rc=%d",_fn_,rc);

			}
			if (rc >= 0) {
				rc = cl_conv_arg_opt(prmp[0],pInfoParm,opt);

DEBUGOUTL2(170,"%s:3 rc=%d",_fn_,rc);

				if (nparm >= 3) cl_gx_copy_info(&InfoParm1,pInfoParm);
			}
		}
		if (rc>=0 && nparm >= 2) {
			pInfoParm1 = &InfoParm1;
			pInfoParm2 = &InfoParm2;
			if (pInfoParm1->pi_id == D_DATA_ID_STOREVAR) pInfoParm1 = (tdtInfoParm *)pInfoParm1->pi_pos;
			if (pInfoParm2->pi_id == D_DATA_ID_STOREVAR) pInfoParm2 = (tdtInfoParm *)pInfoParm2->pi_pos;
			rc = cl_gx_bexp(pInfoParm,pInfoParm1,pOperator,pInfoParm2,nparm-3,prmp+3);

DEBUGOUTL2(170,"%s:4 rc=%d",_fn_,rc);

		}
	}
	else {
		cl_null_value(pInfoParm);
		rc = 0;
	}
	if (rc) {
	}
	return rc;
}

/****************************************/
/*	22									*/
/****************************************/
int cl_gx_exp_obj(nparm,pparmList,Obj,pInfoParm)
int nparm;
parmList *pparmList[];
int *Obj;
tdtInfoParm *pInfoParm;
{
	return cl_gx_exp_obj_opt(nparm,pparmList,Obj,pInfoParm,0);
}

/****************************************/
/*	23									*/
/****************************************/
int cl_gx_expsn_obj_opt(buf,len,bxobj,Obj,pInfoParmW,opt)
char *buf;
int  len;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	parmList parmList,*prmp[2];

DEBUGOUTL2(120,"cl_gx_expsn_obj_opt: len=%d buf=[%s]",len,buf);

	parmList.prmlen = len;
	parmList.prp = buf;
	parmList.opt = 0;
	parmList.bxobj = NULL;
	prmp[0] = &parmList;
	return cl_gx_exp_obj_opt(1,prmp,Obj,pInfoParmW,opt);
}

/****************************************/
/*	24									*/
/****************************************/
int cl_gx_exps_obj_opt(buf,bxobj,Obj,pInfoParmW,opt)
char *buf;
GXObject *bxobj[];
tdtObjHead *Obj;
tdtInfoParm *pInfoParmW;
int opt;
{
	return cl_gx_expsn_obj_opt(buf,strlen(buf),bxobj,Obj,pInfoParmW,opt);
}

/****************************************/
/*	25									*/
/****************************************/
int cl_skip_scope_mark(pLprp,pLlen,pix)
char *pLprp;
int pLlen,*pix;
{
	char buf[D_LEN_SCOPE_MARK+1];
	int rc,ix;

	rc = 0;
	if (!pLprp) return -1;
	ix = 0;
	if (*pLprp == '<') {
		memzcpy(buf,pLprp,D_LEN_SCOPE_MARK);
		if (!(ix=cl_get_def_scope(buf))) {
			ERROROUT2(FORMAT(135),"cl_skip_scope_mark",buf);	/* %s: Invalid scope name[%s] */
			return -1;
		}
		rc = D_LEN_SCOPE_MARK;
	}
	if (pix) *pix = ix;
	return rc;
}

/****************************************/
/*	26									*/
/****************************************/
int cl_conv_parm_func(pInfoParmW,vname,vnlen,opt)
tdtInfoParm *pInfoParmW;
char *vname;
int  vnlen,opt;
{
	char *_fn_="cl_conv_parm_func";
	tdtInfoParm InfoParm,*pInfoParm,*ppParm[2];
	char *pOperator,fun_nam[2];
	int  rc,n,nparm,index,atr,posa[2],iParm[4];

DEBUGOUTL4(120,"%s:Enter: vname=[%s] vnlen=%d opt=%08x",_fn_,vname,vnlen,opt);

	rc = 0;
	pOperator = vname;
	pInfoParm = &InfoParm;
	vnlen--;
	vname++;
	n = instr2(vname,vnlen,"(",")",posa);

DEBUGOUTL2(170,"%s: n=%d",_fn_,n);

	if (n == 1) {
		rc = -215122601;
	}
	else {
		if (n == 2) {
			vnlen -= 2;
			vname++;
		}
		if (!vnlen) nparm = 0;
		else {
			if ((rc=cl_gx_expsn_obj_opt(vname,vnlen,NULL,NULL,pInfoParm,0)) < 0) return rc;
			if (pInfoParm->pi_id == ' ') {
				if ((atr=pInfoParm->pi_attr) == DEF_ZOK_CHAR) {
					cl_get_parm_bin(pInfoParm,&index,"get index");
					cl_set_parm_long(pInfoParm,index);
				}
				else if (atr == DEF_ZOK_BINA) index = 1;
			}
			else index = 0;
DEBUGOUT_InfoParm(170,"%s: index=%d",pInfoParm,_fn_,index);
			if (index <= 0) {
				iParm[0] = pInfoParm->pi_attr;
				iParm[1] = iParm[2] = iParm[3] = 0;
				ERROROUT2(FORMAT(218),_fn_,cl_get_attr_name(iParm));	/* %s: INDEX�̌^[%s]�������Ă��܂���B */
				rc = -215122602;
			}
			nparm = 1;
		}
	}
	if (rc >= 0) {
		memzcpy(fun_nam,pOperator,1);
		ppParm[0] = pInfoParm;
		rc = cl_func_conv_parm(pInfoParmW,fun_nam,nparm,ppParm,0,opt);
	}
	return rc;
}

/****************************************/
/*	27									*/
/****************************************/
int cl_getitems(buf,buf_len,item,maxitem,parm,parm_len,sep)
char *buf,*item[],*parm,*sep;
int buf_len,maxitem,parm_len;
{
	static char *_fn_="cl_getitems";
	static char *gwsep=" \n'\"(){}[]";
	int rc,n,len,kk1,kk2,kk3,disp,ips,wlen,pmlen,bflen;
	char c,cs,*ps,*pm;
	SSPL_S sspl;

DEBUGOUTL3(120,"%s:Enter: buf_len=%d buf=[%s]",_fn_,buf_len,buf);

	cl_chk_act(-1);
	memset(&sspl,0,sizeof(SSPL_S));
	kk1 = kk2 = kk3 = disp = n = ips = 0;
	ps = buf;
	pm = parm;
	bflen = buf_len;
	pmlen = parm_len;
	sspl.sp = 0;
	sspl.wd = pm;
	sspl.wdmax = pmlen - 1;
	while (bflen > 0) {
DEBUGOUTL4(170,"%s: disp=%d bflen=%d sp=%d",_fn_,disp,bflen,sspl.sp);
		if ((len=akxnskipin(ps,bflen,sep)) == bflen) break;
		else if (len > 0) {
			bflen -= len;
			ps    += len;
			sspl.sp = 0;
			sspl.wd = pm;
			sspl.wdmax = pmlen - 1;

DEBUGOUTL3(170,"%s: skip len=%d ps=[%s]",_fn_,len,ps);

		}
		len = akxtgwnsl(ps,bflen,&sspl,gwsep,1);
DEBUGOUTL2(170,"%s: akxtgwnsl len=%d",_fn_,len);
		if (len > 0) {

DEBUGOUTL5(170,"%s: disp=%d getw len=%d sp=%d wd=[%s]",_fn_,disp,len,sspl.sp,sspl.wd);

			c = *sspl.wd;
			if (sspl.sp >= bflen) cs = ' ';
			else cs = *(ps+sspl.sp);
			if (instrchar("(){}[]",c) > 0) {
				if (cl_chk_act(c) < 0) {
					n = ECL_SCRIPT_ERROR;
					break;
				}
				if (c == '(') kk1++;
				else if (c == ')') kk1--;
				else if (c == '{') kk2++;
				else if (c == '}') kk2--;
				else if (c == '[') kk3++;
				else if (c == ']') kk3--;
				if (!(kk1+kk2+kk3)) disp = 0;
				else disp = 1;

DEBUGOUTL4(170,"%s: c=%c cs=%c disp=%d\n",_fn_,c,cs,disp);
DEBUGOUTL4(170,"%s: kk1=%d kk2=%d kk3=%d\n",_fn_,kk1,kk2,kk3);

			}
		}
		else {
			c = cs = '\0';
			break;
		}
		if ((!disp && instrchar(sep,cs)>0) || len<=0) {
			wlen = sspl.sp;
			if (pmlen <= wlen) break;
			memzcpy(pm,ps,wlen);
			item[n++] = pm;

DEBUGOUTL4(170,"%s: n=%d wlen=%d pm=[%s]",_fn_,n,wlen,pm);

			ps += wlen;
			bflen -= wlen;
			pm += wlen + 1;
			pmlen -= wlen + 1;
			disp = 0;
		}
	}
	if (disp) {
		wlen = sspl.sp - 1;
		if (pmlen > wlen) {
			memzcpy(pm,ps,wlen);
			item[n++] = pm;

DEBUGOUTL5(170,"%s: disp=%d n=%d wlen=%d pm=[%s]",_fn_,disp,n,wlen,pm);

		}
	}

DEBUGOUTL2(120,"%s:Exit: n=%d",_fn_,n);

	return n;
}
