static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************/
/*																		*/
/*	�����ړI	�F �d�k�r�d�h�e�R�}���h���C��							*/
/*																		*/
/*	�֐���		�F int cl_process_else_if(pLeaf, pProc)					*/
/*																		*/
/*	������		�F (I)Leaf		: * pLeaf								*/
/*				   (I)ProcCT	: * pProc								*/
/*																		*/
/*	�߂�l		�F ERROR												*/
/*				   NORMAL												*/
/*																		*/
/*	�����T�v	�F														*/
/*																		*/
/************************************************************************/

#include "colmn.h"

extern GlobalCt *pGlobTable;

static char sep[]={" \t'+-*/&|=^~!<>[](),;"};

int cl_process_else_if(pLeaf, pProc)
Leaf   *pLeaf;
ProcCT *pProc;
{
	int rc,id;
	BlockCB *pIfCB,*pBlockCB;

	if (!(pIfCB = pProc->pcrBlockCB)) return -1;
	id = pIfCB->cid;
	if (id != C_IF) return -1;

	if (pIfCB->ElseFlag == L_ON) {
		ERROROUT1(FORMAT(368),"ELSE");	/* �O�� ELSE ������܂��B */
		return ECL_EX_ELSEIF;
	}

	if (pIfCB->TureFlag == L_ON) {
		pProc->Nextleaf = pLeaf->rightleaf;
		return 0;
	}
	if ((rc = cl_if_comp_ctl(pLeaf,pProc)) < NORMAL) return ECL_EX_IF;

	if (rc == L_ON) {
		pIfCB->TureFlag = L_ON;
		pProc->Nextleaf = pLeaf->leftleaf;
DEBUGOUTL1(200,"cl_process_else_if: push [ %s ]",cl_get_pcmd_line(pLeaf->rightleaf));
		cl_ret_leaf_push(pProc,pLeaf->rightleaf);
	}
	else {
		pProc->Nextleaf = pLeaf->rightleaf;
	}

	return 0;
}

/********************************/
/*								*/
/********************************/
static int _mk_exp(swParm,nparm,prmp,mcat)
char *swParm;
int  nparm;
parmList  *prmp[];
MCAT *mcat;
{
	char *line;
	int line_len;
	SSPL_S ssp;
	int rc,i,len,lpar1,lpar2,atr0,atr,flag;
	char wrk[256],*p,c;

	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	line = prmp[0]->prp;
	line_len = prmp[0]->prmlen;
	mcat->mc_ipos = 0;
	if (mcat->mc_bufp) *mcat->mc_bufp = '\0';
	len = strlen(swParm);
	akxtmcat(mcat,swParm,len);
	flag = 0;
	while ((rc=akxtgwnsl(line,line_len,&ssp,sep,1)) > 0) {
		if (flag) {
			akxtmcats(mcat,")||");
			akxtmcat(mcat,swParm,len);
		}
		lpar1 = lpar2 = 0;
		if (cl_gx_is_operator(wrk,COMP) ||
		    !stricmp(wrk,"LIKE") || !stricmp(wrk,"iLIKE")) ;
		else {
			akxtmcats(mcat,"==");
			if ((c=*wrk) == '(') lpar1 = 1;
			else if (c == '[') lpar2 = 1;
		}
		atr = ssp.attr[0];
		akxtmcats(mcat,wrk);
		while ((rc=akxtgwnsl(line,line_len,&ssp,sep,1)) > 0) {
			atr0 = atr;
			atr  = ssp.attr[0];
			if ((c=*wrk) == '(') lpar1++;
			else if (c == ')') lpar1--;
			else if (c == '[') lpar2++;
			else if (c == ']') lpar2--;
			if (!lpar1 && !lpar2 && c==',') break;
			if (atr0<10 && atr<10) akxtmcats(mcat," ");
			akxtmcat(mcat,wrk,rc);
		}
		if (lpar1 || lpar2) {
			ERROROUT(FORMAT(369));	/* �J�b�R�̑Ή������Ă��܂���B */
			return -1;
		}
		flag = 1;
	}
	akxtmcats(mcat,")");

DEBUGOUTL1(120,"_mk_exp: buf=[%s]",mcat->mc_bufp);

	return mcat->mc_ipos;
}
