static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/**********************************************************************
*                                                                     *
*      �����ړI�@�@�F  ��r���Z���� 	�@                            *
*                                                                     *
*      �֐����@�@�@�F�@int cl_if_comp_ctl( pLeaf )		              *
*                                                                     *
*      ������      �F�@(I)Leaf          * pLeaf                       *
*                                                                     *
*                                                                     *
*      �߂�l�@�@�@�F�@ERROR                                          *
*                      NORMAL                                         *
*                                                                     *
*      �����T�v�@�@�F�@                                               *
*                                                                     *
**********************************************************************/
#include <colmn.h>

extern GlobalCt  *pGlobTable;
extern CLCOMMON  CLcommon;
extern int giOptions[];

static int iEROUT_NDEF;

/****************************************/
/*										*/
/****************************************/
int cl_if_comp_ctl(pLeaf,proc)
Leaf    *pLeaf;
ProcCT  *proc;
{
	int  	Flag;

	if (pLeaf->cmd.prmnum > 0) {
		if ((Flag = cl_if_compare(pLeaf,proc)) < NORMAL)
			return D_ERROR;
	}
	else {
		ERROROUT1(FORMAT(44),"cl_if_comp_ctl");	/* %s: �p�����[�^���K�v�ł��B */
		Flag  = D_ERROR;
	}

	return Flag;
}

/****************************************/
/*										*/
/****************************************/
int cl_is_true(pInfoParm)
tdtInfoParm *pInfoParm;
{
/*	int rc,Ans,atr;
	double dVal;
	char *pWork;	*/

DEBUGOUT_InfoParm(190,"cl_is_true: ",pInfoParm,0,0);

	/* 2022.6.9 */
	return cl_get_logic_val(pInfoParm);
}

/****************************************/
/*										*/
/****************************************/
int cl_is_zero(pInfoParm)
tdtInfoParm *pInfoParm;
{
	int rc,iAttr[4],atr;
	long Valz[NMPA_LONG],*Val,lValue;;
	double dValue;
	MPA *mpa;

	rc = 0;
	if (pInfoParm->pi_attr == DEF_ZOK_CHAR) {
		Val = cl_get_tmpMPA(Valz);
		iAttr[0] = 0;
		if ((rc=cl_get_parm_mpa(pInfoParm,Val,"Parm2:",iAttr)) >= 0) {
			atr = iAttr[0];
			if (atr == DEF_ZOK_BINA) {
				if (!CL_GET_VAL_BIN(Val)) rc = 1;
			}
			else if (atr == DEF_ZOK_FLOA) {
				memcpy(&dValue,Val,sizeof(double));
				if (dValue == 0.0) rc = 1;
			}
			else if (atr == DEF_ZOK_DECI) {
				mpa = (MPA *)Val;
				if (mpa->zero) rc = 1;
			}
		}
	}
	else rc = !cl_is_true(pInfoParm);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_if_compare_sub(nparm,prmp,Obj)
int nparm;
parmList *prmp[];
int      *Obj;
{
	int rc,Ans;
	double dVal;
	char *pWork,*pOperator;
	tdtInfoParm InfoParm,*pInfoParm;

	pInfoParm = &InfoParm;
	rc = cl_gx_exp_obj_opt(nparm,prmp,NULL,pInfoParm,0);
	if (!rc) {
		/* 2019.4.7 */
		rc = cl_is_true(pInfoParm);
	}
	else if (rc == 100) rc = L_OFF;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_if_compare(pLeaf,proc)
Leaf    *pLeaf;
ProcCT  *proc;
{
	return cl_if_compare_sub(pLeaf->cmd.prmnum,pLeaf->cmd.prmp,proc->Obj);
}
