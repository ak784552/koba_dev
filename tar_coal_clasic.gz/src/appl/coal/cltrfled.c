static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_end_proc            */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */
#endif
extern CLCOMMON  CLcommon;
extern XHASHB	*ProcIndex;

tdtCONSTCT *const_ct;
char *stack_as_name[20];

/********************************************/
/*											*/
/********************************************/
int cl_is_name(nam,n)
char *nam;
int n;
{
	int ret;
	uchar c;

	if (!nam || n<0) ret = -1;
	else if (n <= 0) ret = 0;
	else {
		ret = 0;
		if (akxqkanjilen2(nam,n) == 1) {
			c = akxcupper(*nam);
			if (c=='_' || (c>='A' && c<='Z') || (c>=0xa6 && c<=0xdd)) ret = 1;
		}
		else ret = 1;
	}
	return ret;
}

/********************************************/
/*											*/
/********************************************/
void _set_nodeLevel(leaf,level)
Leaf  *leaf;
int   level;
{
	if (leaf) {
		leaf->type = level;
		if (leaf->leftleaf) {
			_set_nodeLevel(leaf->leftleaf,level+1);
		}
 		if (leaf->rightleaf) {
			_set_nodeLevel(leaf->rightleaf,level);
		}
	}
}

/********************************************/
/*											*/
/********************************************/
int col_mn_tr_file_end(y)
condList *y;
{
	Leaf  *leaf;
	int ret;

	if (y->clstcb->nestLev1) {
		/* %s: �d�m�c�o�q�n�b�܂��͂d�m�c�e�t�m�b���ݒ肳��܂���ł����B */
		ERROROUT1(FORMAT(36),"col_mn_tr_file_end");
		return ( ECL_LEX );
	}
	if (!y->clstcb->TopStack) {
		/* col_mn_tr_file_end: �L���ȕ�������܂���B */
		ERROROUT(FORMAT(37));
		return ( ECL_LEX );
	}
/*
	if (ProcIndex) akxs_xhash_free(ProcIndex);
	ProcIndex = akxs_xhash_new2(0,10,7,sizeof(Leaf *));
*/
	_set_nodeLevel(leaf=search_top_leaf(y),0);
	return ret;
}
