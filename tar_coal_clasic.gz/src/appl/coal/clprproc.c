static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/*	<clprproc.c>													*/
/*		Proc process												*/
/********************************************************************/
#include "colmn.h"

extern GXObjectExpand CLobjExp;	/* add 20231203 */

/************************************/
/*	_chk_var_name					*/
/************************************/
static int _chk_var_name(name,len)
char *name;
int len;
{
#if 1	/* 2024.7.6 */
	if (*name == '*') {
		name++;
		len--;
	}
#endif
	return cl_def_chk_name(name,len,"cl_process_proc",FORMAT(441));
}
#if 0
#if 1	/* 2021.7.22 */
/************************************/
/*	_ProcClearVar					*/
/************************************/
static int _proc_clear_var(proc)
ProcCT  *proc;
{
	int scope;
	ScrPrCT *scrct;
	Leaf *topleaf;

	if (!(scrct=cl_search_src_ct())) return 0;
/*
printf("_proc_clear_var: varnam=[%s]\n",varnam);
*/
	scope = /*D_AUX1_GLOBAL_VAR | D_AUX1_PUBLIC_VAR | D_AUX1_PRIVATE_VAR | */D_AUX1_LOCAL_VAR;
	if (!strcmp(proc->ProcNM,"main")) scope |= D_AUX1_PRIVATE_VAR;
	topleaf = proc->ProcTop->leftleaf;
	return cl_gx_clear_var_obj2(topleaf,NULL,NULL,proc->Obj,scope);
}
#endif
#endif
/************************************/
/*	_chk_pname						*/
/************************************/
static int _chk_pname(iob0,obj,da,max_pas,tbl_pas)
int iob0,obj[],max_pas;
char *da[];
tdtInfoParm ***tbl_pas;
{
	tdtInfoParm *pInfoParm;
	int i,npa,ipa,ida,rc,iob;
	char *pnam;

	if (!obj || !da || !tbl_pas) return -1;
	rc = 0;
	for (i=1;i<=max_pas;i++) {
		if (pInfoParm = cl_get_var_ent(tbl_pas,i)) {
			if (pInfoParm->pi_id == D_DATA_ID_PNAME) {
				pnam = pInfoParm->pi_paux;
/*
printf("_chk_pname: i=%d pnam=[%s]\n",i,pnam);
*/
				iob = iob0;
				npa = obj[iob++];
				rc = ECL_SCRIPT_ERROR;
				while (npa-- > 0) {
					ipa = obj[iob++];
					ida = obj[iob++];
/*
printf("_chk_pname: ipa=%d da=[%s]\n",ipa,da[ida]);
*/
					if (!strcmp(pnam,da[ida])) {
						rc = 0;
						break;
					}
					iob += 4;
				}
				if (rc) {
					/* %s: %d �ԖڂɎw��̉�������[%s]������܂���B */
					ERROROUT3(FORMAT(509),"_chk_pname",i,pnam);
					break;
				}
			}
		}
	}
	return rc;
}

/************************************/
/*	_get_pname_var_ent				*/
/************************************/
static tdtInfoParm *_get_pname_var_ent(name,max_pas,tbl_pas,ippa)
char *name;
int max_pas,*ippa;
tdtInfoParm ***tbl_pas;
{
	tdtInfoParm *pInfoParmC,*pInfoParm;
	int i,ii,ipa;

	if (ippa) ipa = *ippa;
	else ipa=0;
DEBUGOUTL3(151,"_get_pname_var_ent: name=[%s] max_pas=%d ipa=%d",name,max_pas,ipa);
	pInfoParmC = NULL;
	for (i=1,ii=0;;i++) {
		if (pInfoParm = cl_get_var_ent(tbl_pas,i)) {
			if (pInfoParm->pi_id == D_DATA_ID_PNAME) {
				if (name) {
					if (!strcmp(name,pInfoParm->pi_paux)) {
						pInfoParmC = (tdtInfoParm *)pInfoParm->pi_pos;
#if 1	/* 2021.8.11 */
						if (pInfoParmC->pi_id == 'S') pInfoParmC = (tdtInfoParm *)pInfoParmC->pi_pos;
#endif
						break;
					}
				}
			}
			else if (name) {
				if (i > max_pas) break;
			}
			else if (ippa) {
				if (++ii == ipa) {
					pInfoParmC = pInfoParm;
					*ippa = ++ipa;
					break;
				}
			}
		}
	}
	return pInfoParmC;
}

/************************************/
/*	cl_process_proc					*/
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_proc(leaf, proc)
Leaf   *leaf;
ProcCT *proc;
{
	static char *_fn_="cl_process_proc";
	static char *sep=" \t,()='";
	static char *attr_sep=" \t()[],'=";
	int   rc,nparm,len,atr,per_flg,ipa,ix,*pSize,max_pas,iMAIN,iParm[4],cmnd,*index;
	int   sp_save,is,kk_level,lenw,line_len,iSET,atr1,lend,check[4],attr,attr0;
	parmList *prmp[4],qprmp[4],**cmd_prmp,*parmp;
	char  buf[512],w[16],*name,wrk0[256],c,c0,*pp,*line,*dflt,*wrk,*p;
	SSPL_S ssp;
	tdtInfoParm	*pInfoParmC,*pInfoParmW,tInfoParm,*pInfoParmT,*pInfo;
	tdtInfoParm ***tbl_pas,***tbl_vnm;
	GXObject *pbxObj;
	XHASHB *pha_vnm;
	tdtArrayIndex *pIndex;
	int i,npr,npa,inpa,iob,ida,ipr,*obj,*jParm,iPNAME,iPN,iADDR;
	char **da;
	CMDObject *cmdobj;
	parmList pList;

DEBUGOUTL3(110,"%s:Enter leaf=%08x proc=%08x",_fn_,leaf, proc);

	if (!leaf || !proc) return ECL_SYSTEM_ERROR;

	/* ���̃m�[�h(leaf)�����s���悤�Ƃ��Ă���proc/func�łȂ��Ƃ�
	  (���s���悤�Ƃ��Ă���proc/func����proc/func�̂Ƃ�)�́A�X�L�b�v���� */
	if (proc->ProcTop != leaf) {
		proc->Nextleaf = leaf->rightleaf;
		return 0;
	}

#ifdef CMDOBJECT
	cmdobj = leaf->cmd.cmdobj;
/*	cmdobj->cid = leaf->cmd.cid;	*/
#endif

	if (!(proc->Nextleaf=leaf->leftleaf)) {
		if ((cmnd=leaf->cmd.cid) == C_PROC) name = FORMAT(114);	/* �葱�� */
		else if (cmnd == C_FUNCTION) name = FORMAT(115);	/* �֐� */
		else name = FORMAT(120);	/* �N���X */
		ERROROUT2(FORMAT(501),_fn_,name);	/* %s: %s���ɕ�������܂���B */
		return ECL_SCRIPT_ERROR;
	}

	if (rc=cl_mk_pr_var_set(proc)) return rc;

	pha_vnm = proc->pha_vnam;
/*	tbl_vnm = proc->pTBL_vnam;	*/

	nparm = leaf->cmd.prmnum;
	cmd_prmp = leaf->cmd.prmp;
	iMAIN = 0;

DEBUGOUTL2(120,"%s: leaf->cmd.cid=[%s]",_fn_,cl_gets_cmd_name(leaf->cmd.cid));

	if (cmnd==C_PROC && !strcmp(proc->ProcNM,"main")) {
		if (rc=cl_prparmset(/*NULL,*/NULL,proc->ProcNM)) return rc;
		iMAIN = 1;
#ifdef CMDOBJECT
		cmdobj->option = iMAIN;
#endif
	}

DEBUGOUTL2(120,"%s:1 proc->ProcPath=[%s]",_fn_,nval1(proc->ProcPath));

	parmp = cmd_prmp[0];

DEBUGOUTL2(120,"%s: parmp->bxobj=%08x",_fn_,parmp->bxobj);

	if (pbxObj=parmp->bxobj) {
		if (p = proc->ProcPath) {

DEBUGOUTL2(120,"%s:2 proc->ProcPath=[%s]",_fn_,p);

			if (*p != '*') p = NULL;
		}
		if (!p) {
#if 1	/* 2024.3.4 */
/*
printf("%s: pbxObj->nda=%d\n",_fn_,pbxObj->nda);
printf("%s: pbxObj->da[0]=[%s]\n",_fn_,pbxObj->da[0]);
*/
			if (pbxObj->nda > 0) {
				if (akxm_addrchk(pbxObj->da)) {
					p = pbxObj->da[0];
					if (p && !akxm_addrchk(p)) p = NULL;
					proc->ProcPath = p;
				}
				if (!p) {
			/*	else {	*/
					ERROROUT("pbxObj->da is invalid.");
					return -1;
				}
			}
		/*	proc->ProcPath = p;	*/
#else
			if (pbxObj->da) proc->ProcPath = pbxObj->da[0];
#endif

DEBUGOUTL2(120,"%s:3 proc->ProcPath=[%s]",_fn_,nval1(proc->ProcPath));

		}
	}
#if 0
	_proc_clear_var(proc);	/* proc�J�n���ɁAObj��obj0��clear����邪�A
							   leaf��obj0��clear����Ȃ��̂ŁA����͕K�v */
#endif
	if (nparm <= 1) return 0;

	max_pas = proc->varnam_pasento;
	tbl_pas = proc->pTBL_pasento;
	pSize = (int *)tbl_pas[0];
/*
printf("%s: max_pas=%d\n",_fn_,max_pas);
*/
	iPNAME = 0;
	for (i=1;i<=max_pas;i++) {
		if (pInfoParmC = cl_get_var_ent(tbl_pas,i)) {
DEBUGOUT_InfoParm(151,"%s :PNAME: i=%d",pInfoParmC,_fn_,i);
			if (pInfoParmC->pi_id == D_DATA_ID_PNAME) {
				iPNAME = 1;
				break;
			}
		}
	}
	return 0;
}

/************************************/
/* cl_process_end_proc              */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_end_proc(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	char *name;
	int cmnd;

	if (leaf == NULL) return(ECL_SYSTEM_ERROR);
	if (proc == NULL) return(ECL_SYSTEM_ERROR);
/*
printf("cl_process_end_proc: proc=%08x name[%s]\n",proc,proc->ProcNM);
*/
	if (!(proc->pr_pFlag & D_PFLAG_CONSTRUCT)) {
		if ((cmnd=leaf->cmd.cid) == C_ENDPROC) name = FORMAT(506);	/* �d�m�c�o�q�n�b */
		else if (cmnd == C_ENDFUNC) name = FORMAT(507);	/* �d�m�c�e�t�m�b */
		else name=NULL;
				/* %s: %s���ɒB���܂����B�q�d�s�t�q�m���܂��B */
		if (name) ERROROUT2(FORMAT(508),"cl_process_end_proc",name);
	}
	cmn_set_stat(RET_PR,&proc->ptype,L_ON);
	return 0;
}
