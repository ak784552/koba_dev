tar cvf tar_coal_clasic \
	backup.sh .alias *.txt \
	src/Makefile src/*.mk \
	src/appl/Makefile src/appl/mdiff* \
	src/appl/cmn/*.c src/appl/cmn/makefile \
	src/appl/coal/*.c src/appl/coal/makefile src/appl/coal/*.ctl src/appl/coal/test \
	src/appl/include/*.h \
	src/appl/tools/*.[ch] src/appl/tools/Makefile src/appl/tools/*.mk \
	src/appl/tools/*.txt  src/appl/tools/*.sh \
	src/tools
gzip tar_coal_clasic
