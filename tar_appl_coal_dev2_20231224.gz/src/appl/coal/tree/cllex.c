static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <cllex.c>														*/
/*		�����														*/
/*			���p���̈����ύX										*/
/*			�����񒷃`�F�b�N�����ύX								*/
/********************************************************************/

#include "colmn.h"

#define YEN '\\'
#define WKBUFLEN	BUFLEN*8	/* 512*8 */
#define WKBUFMAX	WKBUFLEN-1

extern CLCOMMON CLcommon;
extern GlobalCt *pGlobTable;
extern int giOptions[];
extern XHASHB *xhp_main_def;
extern char cmp_sep[];

static int _parmset();
static int _kugiri();
static int _proc_pragma();
static int _rep_define();
static int _resume_define();
static int _include_define();

static XHASHB *sqp_lex_def=NULL;
static XHASHB *xhp_lex_def=NULL;
static char comstr[MAX_LEN_LABEL+2];
static char cM_QUOTE1, cM_QUOTE2;
static char *def_sep=" \t'\";(){}[]";
static int gSqlMode=0;
static char *gpLabel=NULL;
static cmdTable *gpCmd=NULL;

typedef struct {
	int  pra_opt;	/* 0:rep_def, 1:include */
	char *pra_defkey;
	SSPL_S pra_sspl;
	condList pra_cList;	/* ��񃊃X�g */
} tdtPragmaStack;

#define CLISTSTACKMAX	20
static int iListStack=0;
static int iListStack0=0;
static tdtPragmaStack tPragmaStack[CLISTSTACKMAX+1];

#define MAXIFNEST	20
static int ifnest_cnt,ifnest[MAXIFNEST],iftrue[MAXIFNEST];

#define DEF_OPTC_ICASE	'*'
#define DEFICASEMAX	20

/************************************/
/* cl_chk_pos						*/
/************************************/
static int _chk_pos(y,psspl,pos)
condList *y;
SSPL_S *psspl;
int pos;
{
	int i,len,l,rc,lend;
	char *buf,*p;

	buf = psspl->wd;
	i   = psspl->sp;
	len = psspl->wdmax;
/*
printf("cl_chk_pos Enter:pos=%d i=%d len=%d attr[3]=%d\n",pos,i,len,psspl->attr[3]);
*/
DEBUGOUTL4(LEX_LOG_GROUP+255,"cl_chk_pos enter:pos=%d i=%d len=%d attr[3]=%d",pos,i,len,psspl->attr[3]);

	if (i>=len && psspl->attr[3]) return -1;
	if (i+pos >= len) {
		l = len - i;
		if (l>0 && i>0) {
			memcpy(buf,buf+i,l);
			len = l;
		}
		else len = 0;
		buf[len] = '\0';
		psspl->sp = 0;
		i = psspl->sp + pos;
		p = buf + len;
		while (i>=len && !psspl->attr[3]) {
			if (len>0 && *p=='\n') {
				len--;
				*(--p) = '\n';
			}
			rc = cl_get_str(y,p);
DEBUGOUTL3(LEX_LOG_GROUP+122,"_chk_pos: rc=%d len=%d buf=[%s]",rc,strlen(buf),buf);
			if (rc) {
				psspl->attr[3] = 1;		/* File End */
				if (!len) return -1;
			}
			else {
				l = strlen(p);
				len += l;
				p   += l;
			}
		}
		psspl->wdmax = len;
/*
printf("cl_chk_pos ret  :i=%d len=%d sp=%d attr[3]=%d buf=[%s]\n",i,len,psspl->sp,psspl->attr[3],buf);
*/
DEBUGOUTL4(LEX_LOG_GROUP+124,"cl_chk_pos ret  :i=%d len=%d attr[3]=%d buf=[%s]",i,len,psspl->attr[3],buf);

	}
	return psspl->sp;
}

static int cl_chk_pos(y,psspl,pos)
condList *y;
SSPL_S *psspl;
int pos;
{
	int i;

	if ((i=_chk_pos(y,psspl,pos)) < 0) {
		if (_resume_define(y,psspl)) i = psspl->sp;
		else i = ECL_END_OF_FILE;
	}
	return i;
}

/************************************/
/* _alloc_cmd_parl					*/
/************************************/
static int _alloc_cmd_parl(y)
condList *y;
{
	char *p;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (!cmd->parnum) {
		if (!(cmd->parl=(ParList *)cl_const_ct_malloc(y->ConstCt,sizeof(ParList)*MAX_PARL))) {
 			ERROROUT("Malloc CLcList_parl");
			return ECL_MALLOC_ERROR;
		}
		cmd->parnum = MAX_PARL;
		memset(cmd->parl,0,sizeof(ParList)*cmd->parnum);
		cmd->parl[1].par = y->fullname;
		cmd->parl[1].parlen = 0;
/*
DEBUGOUTL1(LEX_LOG_GROUP+120,"_lex_cmd_init: y->fullname=[%s]",y->fullname);
*/
	}
	return 0;
}

/************************************/
/* cl_lex_snln						*/
/************************************/
char *cl_lex_snln(y)
condList *y;
{
	static char *fmt="at script=[%s] line=%d";
	static char wrk[128],*p0=NULL;
	char *buf,*name,sname[33];
	int len;

	if (!(buf=y->fullname)) buf = y->fname;
	name = akxt_get_last_name("\\/",buf);
	len = strlen(name) + 30;
	if ((len=akxmemwork(len,&buf,&p0,wrk,sizeof(wrk))) <= 0) {
		buf = wrk;
		strncpy(sname,name,32);
		name = sname;
	}
DEBUGOUTL1(LEX_LOG_GROUP+120,"cl_lex_snln: name=[%s]",name);
	sprintf(buf,fmt,name,y->line);
	return buf;
}

/***************************************************/
/* _parmset (�\���� cmdInfo �ւ̃p�����[�^�̐ݒ�)  */
/***************************************************/
static int _parmset(y,pp,len,opt)
condList *y;
char *pp;
int  len,opt;
{
	parmList *lp;
	int rc;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum+2 >= y->max_prmnum) {
		y->max_prmnum += 64;	/*PM_MAX;*/
		if (!(cmd->prmp=(parmList **)Realloc(cmd->prmp,sizeof(parmList *)*(y->max_prmnum)))) {
			ERROROUT("Realloc CLcList_prmp");
			return ECL_MALLOC_ERROR;
		}
/*
printf("_parmset: y->max_prmnum=%d\n",y->max_prmnum);
*/
	}
	lp = (parmList *)cl_const_ct_malloc(y->ConstCt,sizeof(parmList));
	if (!lp) {
		ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),pp);
		return ECL_MALLOC_ERROR;
	}
	memset(lp,0,sizeof(parmList));
	lp->prmlen = len;
	lp->prp = (char *)pp;
/*
printf("_parmset: cid=%08x prmnum=%d len=%d pp=[%s]\n",cmd->cid,cmd->prmnum,len,pp);
*/
	cmd->prmp[cmd->prmnum] = lp;
	cmd->prmnum++;
	if (opt) {
		if (y->mcat->mc_ipos > 0) {
			rc = akxtmcats(y->mcat," ");
		}
		else rc = 0;
		if (rc >= 0) rc = akxtmcat(y->mcat,pp,len);
		if (rc < 0) {
			ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),pp);
			return ECL_MALLOC_ERROR;
		}
	}
	rc = _alloc_cmd_parl(y);
	return rc;
}

/************************************/
/* clparmset						*/
/************************************/
int clparmsetopt(y,wkstr,parmlen,opt)
condList *y;
char *wkstr;
int parmlen,opt;
{
	char *parm;
	int rc;

	parm = cl_const_ct_malloc(y->ConstCt,parmlen+1);
	if (parm) {
		memzcpy(parm,wkstr,parmlen);
		parmlen = strlen(parm);
		rc = _parmset(y,parm,parmlen,opt);
	}
	else {
		ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),wkstr);
		rc = ECL_MALLOC_ERROR;
	}
	return rc;
}

int clparmset(y,wkstr,parmlen)
condList *y;
char *wkstr;
int parmlen;
{
	return clparmsetopt(y,wkstr,parmlen,0);
}

/************************************/
/* clparmset2						*/
/************************************/
int clparmset2(y)
condList *y;
{
	char *p;
	int len,lenc,rc=0;
	cmdInfo *cmd;

	cmd = y->cmd;
	lenc = strlen(comstr);
	len = y->mcat->mc_ipos;
	p = cl_const_ct_malloc(y->ConstCt,len+lenc+2);
	if (p) {
		if (rc=_alloc_cmd_parl(y)) return rc;
		memzcpy(p,y->mcat->mc_bufp,len);
		cmd->parl[0].par = p;
		cmd->parl[0].parlen = len;
		y->mcat->mc_ipos = 0;
#if 1	/* SET_CMD_NAME */
		p += len + 1;
		memzcpy(p,comstr,lenc);
/*		p = Strdup(cl_gets_cmd_name(cmd->cid));	*/
		cmd->parl[2].par = p;
		cmd->parl[2].parlen = lenc;
/*
printf("clparmset2: parl[2].par=[%s]\n",p);
*/
#endif
	}
	else {
		ERROROUT2("cllex:malloc error.%s parm[%s]",cl_lex_snln(y),y->mcat->mc_bufp);
		rc = ECL_MALLOC_ERROR;
	}
	return rc;
}

/***************************************************/
/* clparmclr (�\���� cmdInfo �̃p�����[�^�̏���)�@ */
/***************************************************/
int clparmclr(y)
condList *y;
{
	int i;

	y->cmd->prmnum = 0;
	y->mcat->mc_ipos = 0;
	return 0;
}

/***************************************************/
/* cl_syn_main                                     */
/***************************************************/
int cl_syn_main(y)
condList *y;
{
	int rc;
	char *pCmdLine;

if (DEBUGOUTCHECK(LEX_LOG_GROUP+120)) {
	if (!cl_get_cmd_line(y->cmd,&pCmdLine)) DEBUGOUTL1(LEX_LOG_GROUP+120,"cl_syn_main:[%s]",pCmdLine);
}
	rc = cl_tree_main(y);	/* �؍\���쐬 */
	if (rc) {
#if 1	/* 2023.8.12 */
		if (!cl_get_cmd_line(y->cmd,&pCmdLine)) {
			if (pCmdLine) {
				ERROROUT2("cllex:Create tree error=%d %s",rc,cl_lex_snln(y));
				ERROROUT1(" ---> [%s]",pCmdLine);
			}
		}
#else
		ERROROUT2("cllex:Create tree error=%d %s",rc,cl_lex_snln(y));
		if (!cl_get_cmd_line(y->cmd,&pCmdLine)) {
			if (!pCmdLine) pCmdLine = "";
			ERROROUT1(" ---> [%s]",pCmdLine);
		}
#endif
	}
	return rc;
}

/************************************/
/* _to_han_type						*/
/*  flag :  = 0 : ���p�ɕϊ����ꂽ	*/
/*			= 1 : �S�p�̂܂܎g��	*/
/************************************/
static int _to_han_type(moji,quote,wrk,type)
char *moji,quote,*wrk;
int  type;
{
	int flag=1;	/*  */
	char c;

	if (!(pGlobTable->options[8] & 0x02)) {
		if (akxctohan_type_opt(1,moji,wrk,type,0x10) == 1) {
			c = wrk[0];
			wrk[1] = '.';
			if (pGlobTable->options[8] & 0x01) flag = 0;	/* �S�Ẳp���L���𔼊p�ɕϊ����� */
			else if (!quote/* || c=='\'' || c=='"'*/) flag = 0;
		}
	}
	return flag;
}

/************************************/
/* _is_han_type						*/
/************************************/
static char _is_han_type(moji,quote,wrk,type)
char *moji,quote,*wrk;
int  type;
{
	int lenc,c;

	if (lenc=akxqismbs(type,moji)) {
		c = '\0';
		if (!_to_han_type(moji,quote,wrk+1,type)) c = wrk[1];
	}
	else {
		lenc = 1;
		c = moji[0];
	}
	wrk[0] = lenc;
/*
printf("_is_han: lenc=%d c=%c\n",lenc,c);
*/
	return c;
}

/************************************/
/* _skip_line						*/
/************************************/
static int _skip_line(y,buf,psspl)
condList *y;
char *buf;
SSPL_S *psspl;
{
	int len,flg,rc,i;
	char c1;

	len = psspl->wdmax;
/*
printf("_skip_line:Enter len=%d\n",len);
*/
	flg = 1;
	while (flg) {
		if ((c1=buf[len-1])=='\n' || c1=='\r') flg = 0;
		rc = cl_get_str(y,buf);	/* ���ݍs���̂ĂāA���̍s��Ǎ��� */
		if (rc != 0) {
			if (_resume_define(y,psspl)) {
				i = psspl->sp;
				return i;
			}
			else return ECL_END_OF_FILE;	/* File End */
		}
		len = strlen(buf);
DEBUGOUTL2(LEX_LOG_GROUP+122,"_skip_line: len=%d buf=[%s]",len,buf);
/*
printf("_skip_line: len=%d buf=[%s]\n",len,buf);
*/
	}
	i = 0;
	psspl->wdmax = len;
	return i;
}

/************************************/
/* _add_LF							*/
/************************************/
static void _add_LF(cont,cont_len)
char *cont;
int cont_len;
{
	char *p,c1;

	p = cont + cont_len;
	if (cont_len > 0) {
		if (!((c1=cont[cont_len-1])=='\n' || c1=='\r')) strcpy(p,"\n");
	}
	else strcpy(p,"\n");
}

/************************************/
/* _get_def_cont					*/
/* opt = 0 : �S�p���p�ϊ���̏���	*/
/*           ���s�͂��̂܂ܓǂݍ��� */
/*     <>0 : �S�p���p�ϊ�����       */
/*           ���s�p����������       */
/************************************/
/* 2022.1.17 */
static int _get_def_cont(y,wbuf,len,cont,cont_max,sc_code,opt,buf,psspl)
condList *y;
char *wbuf,*buf;
int len;
char *cont;
int cont_max,sc_code,opt;
SSPL_S *psspl;
{
	int flg,rc,i,cont_rem,m1,m2,ret,cont_len,cmlevel;
	char c1,c2,*p,quot,cM_QUOTE1,cM_QUOTE2,*pp,wrk[10],quot1,quot2;

	cM_QUOTE1 = pGlobTable->Quot[0];
	cM_QUOTE2 = pGlobTable->Quot[1];
	cont_rem = cont_max;
	cont_len = 0;
	p = cont;
/*
printf("_get_def_cont:Enter opt=%d len=%d buf=[%s]\n",opt,len,buf);
*/
/*
 * "KEY (a,...)"�̂Ƃ��́A���������Ȃ��Ƃ��邽�߁AKEY����̋󔒕����̓X�L�b�v���Ȃ��B
	i = akxnskipin(buf+pos,len-pos," \t");
	pos += i;
*/
	quot1 = quot2 = quot = '\0';
	cmlevel = ret = 0;
	i = 0;
	while (i < len) {
		pp = wbuf + i;
		if (cmlevel) {
			m1 = akxqmbsnlen(sc_code,pp,len-i);
			if (m1 > 1) {
				i += m1;
				continue;
			}
			else c1 = *pp;
		}
		else {
			c1 = _is_han_type(pp,quot1,wrk,sc_code);
			m1 = wrk[0];
		}
		i += m1;
		if (!c1) {
/*
printf("_get_def_cont: i=%d m1=%d pp=[%s]\n",i,m1,pp);
*/
			if (!cmlevel) {
				memcpy(p,pp,m1);
				p += m1;
			}
			continue;
		}
/*
printf("_get_def_cont: i=%d m1=%d c1=[%c]\n",i,m1,c1);
*/
		if (c1=='\n' || c1=='\r' || c1=='\\') {
			flg = 0;
			if (c1 == '\\') {
				pp = wbuf + i;
				c2 = _is_han_type(pp,quot1,wrk,sc_code);
				m2 = wrk[0];
				i += m2;
/*
akxcxtocn(pp,3,wrk,10,0);
printf("_get_def_cont: i=%d m=%d pp=[%s] wrk=[%s]\n",i,m,pp,wrk);
*/
				if (!c2) {
					*p++ = c1;
					memcpy(p,pp,m2);
					p += m2;
				}
				else {
					if (c2=='\n' || c2=='\r') flg = 1;
					else {
						*p++ = c1;
						*p++ = c2;
					}
				}
			}
			else if (quot || cmlevel>0) {
				if (quot) *p++ = c1;
				flg = 1;
			}
			else if (opt) break;
			else {
				continue;
			}
			if (flg && opt) {
				rc = cl_get_str(y,buf);	/* ���̍s��Ǎ��� */
				if (rc != 0) {
					if (!_resume_define(y,psspl)) break;
				}
				len = strlen(buf);

DEBUGOUTL2(LEX_LOG_GROUP+120,"_get_def_cont: len=%d buf=[%s]\n",len,buf);
/*
printf("_get_def_cont: len=%d buf=[%s]\n",len,buf);
*/
				psspl->wdmax = len;
				wbuf = buf;
				i = 0;
			}
		}
		else if (cmlevel) {
			if (c1 == '*') {
				pp = wbuf + i;
				c2 = _is_han_type(pp,'\0',wrk,sc_code);
				m2 = wrk[0];
/*
printf("_get_def_cont:CM i=%d cmlevel=%d m2=%d c2=[%c]\n",i,cmlevel,m2,c2);
*/
				if (c2 == '/') {
					cmlevel--;
					if (cmlevel < 0) break;
					i += m2;
/*
printf("_get_def_cont:CM i=%d cmlevel=%d\n",i,cmlevel);
*/
				}
			}
		}
		else if (quot) {
			if (c1 == quot) {
				if (c1 == cM_QUOTE2) {
					*p++ = c1;
					quot = '\0';
				}
				else {
					pp = wbuf + i;
					c2 = _is_han_type(pp,'\0',wrk,sc_code);
					m2 = wrk[0];
					if (c2 == quot) {
						i += m2;
						*p++ = c1;
					}
					else {
						quot = quot2;
						quot1 = quot2 = '\0';
					}
					*p++ = c1;
				}
			}
			else {
				memcpy(p,pp,m1);
				p += m1;
			}
		}
		else if (c1 == '/') {
			pp = wbuf + i;
			c2 = _is_han_type(pp,'\0',wrk,sc_code);
			m2 = wrk[0];
			if (c2 == '/') {
				break;
			}
			else if (c2 == '*') {
				cmlevel++;
				i += m2;
/*
printf("_get_def_cont:CM i=%d cmlevel=%d\n",i,cmlevel);
*/
			}
			else {
				*p++ = c1;
			}
		}
		else if (c1 == '*') {
			pp = wbuf + i;
			c2 = _is_han_type(pp,quot1,wrk,sc_code);
			m2 = wrk[0];
			if (c2 == '/') {
				cmlevel--;
				if (cmlevel < 0) break;
				i += m2;
/*
printf("_get_def_cont:CM i=%d cmlevel=%d pos=%d\n",i,cmlevel,pos);
*/
			}
			else {
				*p++ = c1;
			}
		}
		else if (c1==cM_QUOTE1 || c1==cM_QUOTE2) {
			quot = c1;
			*p++ = c1;
			if (c1 == cM_QUOTE1) quot1 = c1;
		}
		else *p++ = c1;
	}
	if (quot || cmlevel) {
		*p = '\0';
		ret = -1;
/*
printf("_get_def_cont: quot=[%c] %02x cmlevel=%d\n",quot,quot,cmlevel);
*/
	}
	else {
		*p = '\0';
		akxtstrim(0,cont,strlen(cont),NULL);
	}
/*
printf("_get_def_cont:Exit cont=[%s]\n",cont);
*/
	return ret;
}

/************************************/
/* �������̃X�^�b�N�ɂ��Ǘ�		*/
/************************************/
#define _SP_EXT	64
static int _sp_max=0;
static int *_stack=NULL;
static int _sp=0;

/****************************/
/* _push					*/
/****************************/
static int _push(x)
int x;
{
	if (_sp >= _sp_max) {
		_sp_max += _SP_EXT;
		if (_stack) _stack = (int *)Realloc(_stack,_sp_max*sizeof(int));
		else        _stack = (int *)Malloc(_sp_max*sizeof(int));
		if (!_stack) return -4;
	}
	_stack[_sp++] = x;
	return 0;
}

/****************************/
/* _pop						*/
/****************************/
static int _pop()
{
	if (_sp <= 0) return -5;
	return _stack[--_sp];
}

/****************************/
/* _peek					*/
/****************************/
static int _peek()
{
	if (_sp <= 0) return 0;
	return _stack[_sp-1];
}

/****************************/
/* _chk_act					*/
/****************************/
static int _chk_act(c)
char c;
{
	int i,j,rc;

	if (c < 0) {
		_sp = 0;
		return 0;
	}
	else if (!c) {
		return _sp;
	}
	else if (c == '(') j = 1;
	else if (c == '{') j = 2;
	else if (c == '[') j = 3;
	else if (c == ')') j = 4;
	else if (c == '}') j = 5;
	else if (c == ']') j = 6;
	else return -2;

	rc = 0;
	if (j <= 3) rc = _push(j);
	else {
		i = _peek();
/*
printf("_chk_act: j=%d i=%d\n",j,i);
*/
		if (i<1 || i>3) rc = -3;
		else if (i == j-3) rc = _pop();
		else rc = -11;
	}
	if (rc > 0) rc = 0;
	return rc;
}

/****************************/
/* _chk_act					*/
/****************************/
int cl_chk_act(c)
char c;
{
	return _chk_act(c);
}

/****************************/
/* _is_sjis_hankaku_kana	*/
/****************************/
static int _is_sjis_hankaku_kana(c)
uchar c;
{
	int rc;

	if (c>=161 && c<=223) rc = 1;
	else rc = 0;
	return rc;
}

/************************************/
/* _add_wkstr_mcat					*/
/************************************/
static int _add_wkstr_mcat(par,mcat,wkstr,h)
ParList *par;
MCAT *mcat;
char *wkstr;
int  h;
{
	wkstr[h] = '\0';
/*
printf("_set_kugiri_wkstr:Enter mc_ipos=%d h=%d wkstr=[%s]\n",mcat->mc_ipos,h,wkstr);
*/
	if (!mcat->mc_ipos) {
		par->par = wkstr;
		par->parlen = h;
	}
	else {
		if (h > 0) {
			akxtmcat(mcat,wkstr,h);
			h = 0;
		}
		par->par = mcat->mc_bufp;
		par->parlen = mcat->mc_ipos;
		akxtmcats(mcat,"");
	}
/*
printf("_set_kugiri_wkstr:Exit h=%d parlen=%d par=[%s]\n",h,par->parlen,par->par);
*/
	return h;
}

/************************************/
/* cl_lex (�f�l�k�^�O������)		*/
/************************************/
int cl_lex(y)
condList *y;
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int   kugiri_flg = 0,iKUGIRI;
	char  buff[BUFLEN*2];
	char  wkstr[BUFLEN],*wwkstr;
	int	exit_flag=0, line_cont;
	ushort sjis;
	char  comstr[24],wrk[16];
	char  *parm,*p;
	int   len,cut;
	int   rc,rc_def;
	int   i,tree,h,wh,parmlen,cnum,j,flag,lenc,len8,ex_opt,sc_code,cmnd,ex_opt9_03;
	char  code,info,quote,c,c1,quote1,quote2,cc;
	unsigned char uc;
	int   new_lex = 0;
	int   moji_const = 0;	/* BEXP $a = '//null/%s';��//���R�����g�ɂ��Ȃ� */
	SSPL_S sspl;
	int   cm_level=0;	/* �^���@���^�`���̃R�����g�̃l�X�g���x�� */
	int   kk_level=0;	/* ()�̃l�X�g���x�� */
	int   k2_level=0;	/* {}�̃l�X�g���x�� */
	int   k3_level=0;	/* []�̃l�X�g���x�� */
	int   ka[3];
	int   def_parm;
	ScrPrCT *scrptct;
	int   inter_mode;
	ParList par;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (y->fp == NULL) return(-1);
	y->rbuf = buff;
	rc = cl_get_str(y,buff);
	if (rc) {
		ERROROUT(FORMAT(40));	/* cllex:�X�N���v�g�E�t�@�C������ł��B */
		goto FEND2;					/* File End */
	}
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buff=[%s]",strlen(buff),buff);
	if (!memcmp(buff,"#!",2)) {
		rc = cl_get_str(y,buff);		/* ���ݍs���̂ĂāA���̍s��Ǎ��� */
		if (rc != 0) goto FEND2;	/* File End */
	}
	len = strlen(buff);
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buff=[%s]",len,buff);
	def_parm = 0;
	h = 0;
	mcat.mc_ipos = 0;
	i = 0;
	info  = 'N';					/* NewLine */
	quote1 = quote2 = quote = '\0';
	clparmclr(y);
	y->clstcb->nestLev1 = NULL;
	y->clstcb->nestLev2 = NULL;
	cl_cmd_init(y->cmd);		/* �����ݒ� */
	y->mcat->mc_ipos = 0;
	if (y->option & D_SCRPT_NEW_LEX) new_lex = 1;

	if (scrptct = cl_search_src_ct()) inter_mode = scrptct->pFlag & D_SCRPT_INTERACTIVE;
	else inter_mode = 0;

	cM_QUOTE1 = pGlobTable->Quot[0];
	cM_QUOTE2 = pGlobTable->Quot[1];

	if ((rc=_alloc_cmd_parl(y)) < 0) return rc;
	if (rc=_proc_pragma(y,NULL,0,0,0,0)) return rc;

	if (y->option & D_CLST_OPT_USE_DTYPE) {
		sc_code = (y->option & D_CLST_OPT_DTYPE)>>16;
/*
printf("cllex: y->option=%08x sc_code=%d\n",y->option,sc_code);
*/
	}
	else {
		sc_code = CD_TYPE_SJIS;
		ex_opt = cl_get_option(21,0);
/*
printf("cllex: ex_opt=%08x\n",ex_opt);
*/
		ex_opt = (ex_opt>>20) & CD_TYPE_CODE;	/* file */
		if (ex_opt) sc_code = ex_opt;
/*
printf("cllex: sc_code=%d\n",sc_code);
*/
	}

	_chk_act(-1);
	sspl.wd = buff;
	sspl.wdmax = len;
	sspl.attr[3] = 0;
	ex_opt9_03 = cl_get_option(9,0) & 0x03;
	while (!exit_flag) {
		/* 2022.11.24 */
		if (h+3 > BUFLEN) {
			h = _add_wkstr_mcat(&par,&mcat,wkstr,h);
		}
/*
printf("cllex:1 len=%d h=%d i=%d c=%c\n",len,h,i,buff[i]);
*/
		sspl.sp = i;
		if ((i=cl_chk_pos(y,&sspl,0)) < 0) goto FEND;		/* File End */
/*
printf("cllex:2 len=%d h=%d i=%d buff=[%s]\n",len,h,i,buff+i);
*/
#ifdef CYGWIN_U8	/* 2020.5.5 */
		uc = *(buff+i);
		if (lenc=akxqismbs(sc_code,buff+i)) {
#else
		if (lenc=iskanji(buff+i)) {
#endif
			flag = 1;
			if (h > BUFLEN*8-2) exit_flag = 1;
			else {
				if (!cm_level || ex_opt9_03==1) {
					flag = _to_han_type(buff+i,quote1,wrk,sc_code);
					c = wrk[0];
/*
printf("cllex: lenc=%d flag=%d wrk=%02x %02x\n",lenc,flag,wrk[0] & 0xff,wrk[1] & 0xff);
*/
					if (sc_code == CD_TYPE_SJIS) {
						if (flag) {	/* ���͒l�����̂܂܎g�� */
							sjis = *(buff+i);
							sjis = sjis<<8 | (uchar)*(buff+i+1);
							/* 2022.11.22 */
							p = wkstr + h;
							len8 = akxc_sj_to_utf8(sjis,p,NULL);
							if (!*p) {
										/* %s: %s(%08x)�̕ϊ���R�[�h������܂���B*/
								ERROROUT3(FORMAT(647),"cllex","S-JIS",sjis);
								memset(p,'?',len8);
							}
/*
printf("cllex:zenkaku flga=%d len8=%d\n",flag,len8);
*/
							h += len8;
						}
						else if (_is_sjis_hankaku_kana(c)) {
							sjis = uc;
							len8 = akxc_sj_to_utf8(sjis,wkstr+h,NULL);
/*
printf("cllex:_hankaku_kana flga=%d len8=%d\n",flag,len8);
*/
							h += len8;
							i += lenc;
							continue;
						}
					}
					else {
						if (flag) {	/* ���͒l�����̂܂܎g�� */
							memcpy(wkstr+h,buff+i,lenc);
							h += lenc;
						}
					}
				}
				i += lenc;
			}
			if (flag) continue;
		}
#ifdef CYGWIN_U8	/* 2020.5.6 */
		else if (!cm_level && sc_code==CD_TYPE_SJIS && _is_sjis_hankaku_kana(uc=*(buff+i))) {
			sjis = uc;
			len8 = akxc_sj_to_utf8(sjis,wkstr+h,NULL);
/*
printf("cllex:_hankaku_kana len8=%d\n",len8);
*/
			h += len8;
			i++;
			continue;
		}
#endif
		else {
			c = buff[i++];
		}
		len = sspl.wdmax;
/*
if (DEBUGOUTCHECK(LEX_LOG_GROUP+255)) {
DEBUGOUTL3(LEX_LOG_GROUP+255,"cllex:len=%d h=%d i=%d",len,h,i);
p=buff+i;
lenc=akxqkanjilen2(p,len-i);
memzcpy(wrk,p,lenc);
DEBUGOUTL2(LEX_LOG_GROUP+255,"cllex:c=[%c] [%s]",c,wrk);
*/
DEBUGOUTL4(LEX_LOG_GROUP+255,"cllex:def_parm=%d kk_level=%d k2_level=%d k3_level=%d",def_parm,kk_level,k2_level,k3_level);
DEBUGOUTL3(LEX_LOG_GROUP+255,"cllex: info=[%c] quote=[%c] cm_level=%d",info,quote,cm_level);
/*}*/
/*
if (y->option & D_SCRPT_MEMORY) printf("cllex: len=%d h=%d i=%d c=%c\n",len,h,i,c);
*/
		iKUGIRI = 0;
/*
printf("cllex:0 i=%d c=[%c] quote=[%c] quote2=[%c]\n",i,c,quote,quote2);
*/
#if 1	/* 2022.10.10 */
		cc = c;
		if (c==M_QUOTE3 && gSqlMode) cc = 'X';	/* default �ɂȂ镶���Ȃ牽�ł��ǂ� */
#endif
		switch(cc) {
			case '#':
				if (cm_level) break;
				else if (!quote && (info=='N')) {
					sspl.sp = i;
					if ((i=cl_chk_pos(y,&sspl,0)) < 0) {	/* 1-->0 2021.5.16 */
						wkstr[h++] = c;
						goto FEND;
					}
					len = sspl.wdmax;
					c1 = _is_han_type(buff+i,'\0',wrk,sc_code);
					if (c1=='!') {
						if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
						break;
					}
					else if (strchr(M_PRAGMA,c1)) {
						i += wrk[0];
						if ((i=_proc_pragma(y,buff,i,&sspl,c1,sc_code)) < 0) {
							if (i == ECL_END_OF_FILE) {
								if (!_resume_define(y,&sspl)) goto FEND;		/* File End */
								i = sspl.sp;
							}
							else {
								rc = i;
								goto ERR;
							}
						}
						break;
					}
				}
				wkstr[h++] = c;
				break;
			case '*':
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:ASTAR 1 c=[%c] cm_level=%d quote=[%c]",c,cm_level,quote);
				sspl.sp = i;
				if ((i=cl_chk_pos(y,&sspl,0)) < 0) {	/* 1-->0 2021.5.16 */
					wkstr[h++] = c;
					goto FEND;
				}
				len = sspl.wdmax;
				c1 = _is_han_type(buff+i,quote,wrk,sc_code);
DEBUGOUTL1(LEX_LOG_GROUP+120,"cllex:ASTAR 2 c1=[%c]",c1);
				/* 2022.12.04 */
				if (((!cm_level && !quote) || cm_level>0) && c1=='/') {
					if (cm_level > 0) {
						cm_level--;
/*
printf("cllex:i=%d len=%d buf=[%s] cm_level=%d(end)\n",i,len,buff,cm_level);
*/
						i += wrk[0];
					/*	i++;	*/
					}
					else {
						ERROROUT1("cllex: unpaired '*/' at line=%d",y->line);
						return ECL_LEX;
					}
				}
				else if (!cm_level) {
					wkstr[h++] = c;
				}
				break;
			case '/':
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:/ 1 c=[%c] cm_level=%d quote=[%c]",c,cm_level,quote);
				sspl.sp = i;
				if ((i=cl_chk_pos(y,&sspl,0)) < 0) {
					wkstr[h++] = c;
					goto FEND;
				}
				len = sspl.wdmax;
				c1 = _is_han_type(buff+i,quote,wrk,sc_code);

DEBUGOUTL4(LEX_LOG_GROUP+255,"cllex:i=%d len=%d c1=%c buff=[%s]",i,len,c1,buff);
DEBUGOUTL2(LEX_LOG_GROUP+255,"cllex:moji_const=%d quote=[%c]",moji_const,quote);
/*
printf("cllex: c=[%c] cm_level=%d quote=%c h=%d c1=[%c]\n",c,cm_level,quote,h,c1);
*/
				/* 2022.12.04 */
				if ((!cm_level && (moji_const || quote)) || (c1!='/' && c1!='*')) {
					if (!cm_level) {
						wkstr[h++] = c;
					}
					break;
				}
				if (c1 == '*') {
/*
printf("cllex:i=%d len=%d buf=[%s] cm_level=%d(start)\n",i,len,buff,cm_level);
*/
					cm_level++;
					i += wrk[0];
					break;
				}
				if (!cm_level) {
					new_lex = 1;
					y->option |= D_SCRPT_NEW_LEX;
				}
			case M_COMMENT:
/*
printf("cllex: c=[%c] cm_level=%d quote=%c h=%d\n",c,cm_level,quote,h);
*/
				if (new_lex && quote) {
					if (!cm_level) wkstr[h++] = c;
					break;
				}
				if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
				break;
			case ')':
			case '}':
			case ']':
				if (!cm_level) {
					if (!quote) {
						rc = 0;
/*
printf("cllex:)}]:1 kk_level=%d k2_level=%d k3_level=%d c=%c\n",kk_level,k2_level,k3_level,c);
*/
						if (c==')' && kk_level>0) {
							kk_level--;
							if (!kk_level && cmd->cid==C_TRY) {
								wkstr[h++] = c;
								iKUGIRI = 1;
								break;
							}
						}
						else if (c=='}' && k2_level>0) k2_level--;
						else if (c==']' && k3_level>0) k3_level--;
						else rc = -11;
						if (!rc) rc = _chk_act(c);
						if (rc) {
							ERROROUT3("cllex: unpaired '%c' %s rc=%d",c,cl_lex_snln(y),rc);
							return ECL_LEX;
						}
/*
printf("cllex:)}]:2 kk_level=%d k2_level=%d k3_level=%d c=%c\n",kk_level,k2_level,k3_level,c);
*/
						if (!kk_level && !k2_level && !k3_level) {
							sspl.sp = i;
							if ((i=cl_chk_pos(y,&sspl,0)) < 0) {	/* 1-->0 2021.5.16 */
								wkstr[h++] = c;
								goto FEND;
							}
							len = sspl.wdmax;
							c1 = _is_han_type(buff+i,'\0',wrk,sc_code);
/*
printf("cllex:i=%d c1=%c kk_level=%d k2_level=%d k3_level=%d\n",i,c1,kk_level,k2_level,k3_level);
*/
							/* 2022.1.5 */
							if (info == 'C') {
								cmnd = cmd->cid;
								/* 2022.1.5 */
								if (cmnd == C_LET) ;
								else if (c1!=' ' && (cmnd==C_IF || cmnd==C_ELSEIF ||
								     cmnd==C_LOOP || cmnd==C_FOR || cmnd==C_WHILE || cmnd==C_UNTIL ||
								     cmnd==C_DO || cmnd==C_SWITCH)) {
									iKUGIRI = 1;
									wkstr[h++] = c;
									break;
								}
							}
						}
					}
					wkstr[h++] = c;
				}
				break;
			case '{':
				if (!cm_level) {
					wkstr[h++] = c;
					if (!quote && !def_parm) {
						k2_level++;
						if (rc=_chk_act(c)) goto ERR;
					}
				}
				break;
			case '\n':
			case '\r':
/*
printf("cllex:CR/LF: new_lex=%d inter_mode=%d i=%d len=%d c=%c buff=[%s]\n",new_lex,inter_mode,i,len,c,buff);
*/
				if (!new_lex) break;
				if (len==1 && inter_mode) goto FEND;
			case '\t':
			case '(':
			case '[':
			case M_SPACE:
			case M_KUGIRI:
				if (cm_level) break;
				if (!quote) {
					if (c=='(' || c=='[') {
						if (c == '(') kk_level++;
						else if (c=='[') k3_level++;
						if (rc=_chk_act(c)) {
							wkstr[h++] = c;
							goto ERR;
						}
					}
				}
/*
printf("cllex:i=%d h=%d c=%c kk_level=%d\n",i,h,c,kk_level);
*/
				if (quote || (info=='C' && (c=='[' || c=='('))) {
				/*	if (buff[i] == '\t')
						buff[i] = ' ';	*/
					wkstr[h++] = c;
				}
				else if (c==M_KUGIRI && kk_level>0) {
					wkstr[h++] = c;
				}
				else {
					iKUGIRI = 2;
				}
				break;
			case M_QUOTE1:	/* ' */
			case M_QUOTE2:	/* " */
			case M_QUOTE3:	/* ` */	/* 2022.10.10 */
DEBUGOUTL5(LEX_LOG_GROUP+120,"cllex:QUOTE 1 c=[%c] cm_level=%d quote=[%c] quote1=[%c] quote2=[%c]",c,cm_level,quote,quote1,quote2);
				/* 2022.11.24 */
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:QUOTE 2 quote=[%c] quote1=[%c] quote2=[%c]",quote,quote1,quote2);
				if (c==cM_QUOTE1 || c==M_QUOTE3) {
					if (cm_level) break;
					if (!new_lex) {
						if (h == 0) moji_const = 1;	/* add 2001.8.20 Koba */
						wkstr[h++] = c;
						break;
					}
				}
				if (cm_level) break;
/*
printf("cllex:i=%d c=[%c]\n",i,c);
*/
				if ((c==cM_QUOTE2 && quote==cM_QUOTE2) ||
				    (c==cM_QUOTE1 && quote==cM_QUOTE1) ||
				    (c==M_QUOTE3 && quote==M_QUOTE3)) {
					if (c==cM_QUOTE1 || c==M_QUOTE3) {
						wkstr[h++] = c;
						sspl.sp = i;
						if ((i=cl_chk_pos(y,&sspl,0)) < 0) goto FEND;	/* 1-->0 2021.5.16 */
						len = sspl.wdmax;
						/* ���p���p���̎����S�p���p���̂Ƃ��́A�A�����锼�p���p���ƌ��Ȃ��B */
						/* ���ׂ̈�quote�ł͂Ȃ�'\0'���w�肵�Ĕ��p�ɕϊ������悤�ɂ���B */
						c1 = _is_han_type(buff+i,'\0',wrk,sc_code);
/*
printf("cllex:i=%d len=%d c1=%c buff+i=[%s]\n",i,len,c1,buff+i);
*/
						if (c1 == c) {
							wkstr[h++] = c1;
							i += wrk[0];
							break;
						}
						/* 2021.10.31 *//* 0 -> 1 */
						else {
							quote = quote2;
							quote1 = quote2 = '\0';
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:QUOTE 3 quote=[%c] quote1=[%c] quote2=[%c]",quote,quote1,quote2);
/*
printf("cllex:1 i=%d c=[%c] quote=[%c] quote2=[%c]\n",i,c,quote,quote2);
*/
							if (quote)  break;
							else if (c1!='\t' && c1!=M_SPACE && c1!=M_KUGIRI) {
								moji_const = 0;
/*
printf("cllex:moji_const=%d quote=%02x\n",moji_const,quote);
*/
								/* 2022.1.6 */
								if (info == 'C') {
									cmnd = cmd->cid;
									if (cmnd == C_LET) break;
									else if (c1!=' ' && (cmnd==C_IF || cmnd==C_ELSEIF ||
									     cmnd==C_LOOP || cmnd==C_FOR || cmnd==C_WHILE || cmnd==C_UNTIL ||
									     cmnd==C_DO || cmnd==C_SWITCH)) ;
									else break;
								}
								else break;
							}
						}
						c = c1;
					}
/*
printf("cllex:moji_const=%d info=[%c] h=%d\n",moji_const,info,h);
*/
					iKUGIRI = 3;
				}
				else {
					if (!quote) {
						if (h>0 && (c==cM_QUOTE2 ||
						            ((c==cM_QUOTE1 || c==M_QUOTE3) && info=='N' && new_lex))) {
							wkstr[h] = '\0';
							iKUGIRI = 4;
							break;
						}
						quote = c;
						if (c == cM_QUOTE2) {
							break;
						}
						else quote1 = quote;
					}
					else if (quote==cM_QUOTE2 && !quote2 && (c==cM_QUOTE1 || c==M_QUOTE3)) {
						quote2 = quote;
						quote1 = quote = c;
					}
/*
printf("cllex:2 i=%d c=[%c] quote=[%c] quote2=[%c]\n",i,c,quote,quote2);
*/
					wkstr[h++] = c;
DEBUGOUTL3(LEX_LOG_GROUP+120,"cllex:QUOTE 4 quote=[%c] quote1=[%c] quote2=[%c]",quote,quote1,quote2);
				}
				break;
			case YEN:
				sspl.sp = i;
				if ((i=cl_chk_pos(y,&sspl,0)) < 0) goto FEND;	/* 2-->0 2021.5.16 */
				len = sspl.wdmax;
				if (i < len) {
					if (akxqismbs(sc_code,buff+i)) break;
					c=buff[i];
					if (new_lex) {
						if (quote==cM_QUOTE1 || quote==M_QUOTE3) {
							if (c=='\r' || c=='\n') i++;
							else if (!cm_level) wkstr[h++] = YEN;
						}
						else {
							if (c=='\r' || c=='\n') i++;
							else {
								if (!cm_level) {
									wkstr[h++] = c;
								}
								i++;
							}
						}
					}
					else {
						if (c!='\t' && c!='\n' && c!=M_SPACE) {
							if (!cm_level) {
								wkstr[h++] = c;
							}
							i++;
						}
					}
				}
				break;
			default:
				if (!cm_level) {
					wkstr[h++] = c;
				}
				if (info=='N' && c==':') iKUGIRI = 1;
				break;
		}
		/* 2021.10.31 */
		if (iKUGIRI) {
/*
printf("cllex: cl_syn_main iKUGIRI=%d\n",iKUGIRI);
*/
			h = _add_wkstr_mcat(&par,&mcat,wkstr,h);
			wwkstr = par.par;
			wh = par.parlen;
			if ((rc=_rep_define(&sspl,wwkstr,wh,kk_level,k2_level,k3_level,ka)) < 0) {
				goto ERR;
			}
			else if (rc == 1) {
				iKUGIRI = 0;
				h = strlen(wwkstr);
				if (wwkstr!=wkstr && h>0) memzcpy(wkstr,wwkstr,h);
				i = sspl.sp;
				kk_level = ka[0];
				k2_level = ka[1];
				k3_level = ka[2];
			}
			if (iKUGIRI == 1) {
				if (rc = _kugiri(y,' ',wh,wwkstr,&info)) return rc;
				h = 0;
				moji_const = 0;
			}
			else if (iKUGIRI == 2) {
			/*
				if (info=='C' && cmd->cid==C_DO &&
				    !cmd->prmnum && stricmp(wwkstr,"AS")) {
					if (rc = _kugiri(y,';',0,wwkstr,&info)) return rc;
				}
			*/
				rc = _kugiri(y,c,wh,wwkstr,&info);
				if (rc == C_PARM_CONTINUE) {
					wkstr[h++] = c;
				}
				else if (rc == C_PARM_START) {
					h = 0;
					wkstr[h++] = c;
					moji_const = 0;
				}
				else if (rc == C_PARM_HEREDOC) {
					sspl.wdmax = 1;
					*buff = '\n';
					if ((i=_skip_line(y,buff,&sspl)) < 0) goto FEND;
/*
printf("cllex: buff=[%s]\n",buff);
*/
					h = 0;
					moji_const = 0;
				}
				else if (rc) return rc;
				else {
					h = 0;
					moji_const = 0;	/* add 2001.8.20 Koba */
				}
			}
			else if (iKUGIRI == 3) {
				if (info == 'N') {	/* �R�}���h */
					if (rc = _kugiri(y,c,wh,wwkstr,&info)) return rc;
				}
				else {
					parmlen = wh;
					wwkstr[wh] = '\0';
					if (rc = clparmsetopt(y,wwkstr,parmlen,1)) return rc;
				}
				h = 0;
				moji_const = 0;	/* add 2001.8.20 Koba */
				quote2 = quote1 = quote = '\0';
			}
			else if (iKUGIRI == 4) {
				if (rc = _kugiri(y,c,wh,wwkstr,&info)) return rc;
				h = 0;
				moji_const = 0;	/* add 2001.8.20 Koba */
				quote = c;
				if (c != cM_QUOTE2) {
					wkstr[h++] = c;
					quote1 = c;
				}
			}
			iKUGIRI = 0;
		}
	}
	ERROROUT2("cllex:String too long.[%s] %s", wkstr,cl_lex_snln(y));
	return ECL_LEX;
FEND:
	p = cl_lex_snln(y);
	if (kk_level || k2_level || k3_level) {
					/* cllex: �J�b�R('(')�����Ă��܂���(%s)�Bkk_level=%d */
		if (kk_level) ERROROUT2(FORMAT(31),p,kk_level);
					/* cllex: ���J�b�R('{')�����Ă��܂���(%s)�Bk2_level=%d */
		if (k2_level) ERROROUT2(FORMAT(38),p,k2_level);
					/* cllex: ��J�b�R('[')�����Ă��܂���(%s)�Bk3_level=% */
		if (k3_level) ERROROUT2(FORMAT(39),p,k3_level);
		return ECL_LEX;
	}
	else if (cm_level) {
		/* cllex: �R�����g�����Ă��܂���(%s)�Bcm_level=%d */
		ERROROUT2(FORMAT(32),p,cm_level);
		return ECL_LEX;
	}
	else if (quote) {
		/* "cllex: ���p��(%c)�����Ă��܂���(%s)�B */
		ERROROUT2(FORMAT(33),quote,p);
		return ECL_LEX;
	}
	else if (info=='C' || h>0) {
		if (h>0) {
			wkstr[h] = '\0';
/*
printf("lex: h=%d wkstr=[%s]\n",h,wkstr);
*/
			clparmsetopt(y,wkstr,h,1);
		}
		ERROROUT1(FORMAT(34),p);	/* cllex: �����I�����Ă��܂���(%s)�B */
		if (!cl_get_cmd_line(y->cmd,&parm)) ERROROUT1(" ---> [%s]",parm);
		else ERROROUT1(FORMAT(35),wkstr);	/* cllex: [%s]�͗L���ȕ��ł͂���܂���B */
		return ECL_LEX;
	}
FEND2:
	cl_cmd_init(y->cmd);
	clparmclr(y);
	cmd->cid = C_FEND;	/* �t�@�C���I������ */
	cmd->type = 0;
	rc = cl_syn_main(y);
/*
printf("cllex: cl_syn_main rc=%d\n",rc);
*/
	cl_cmd_init(y->cmd);
	clparmclr(y);
	y->clstcb->nestLev1 = NULL;
	y->clstcb->nestLev2 = NULL;
	info = 'N';
	return rc;
ERR:
	ERROROUT2("cllex:rc=%d %s",rc,cl_lex_snln());
	wkstr[h] = '\0';
	if (cl_get_cmd_line(cmd,&parm)) parm = "";
	ERROROUT2(" ---> [%s %s]",parm,wkstr);
	return rc;
}

/************************************/
/* if level �̃X�^�b�N�ɂ��Ǘ�	*/
/************************************/
#define IF_LEVEL_EXT	16
static int if_level_max=0;
static int if_level=0;
static char *if_stack=NULL;

/************************************/
/* _set_if_level					*/
/************************************/
static int _set_if_level(up,thenl)
int up,thenl;
{
	if (up >= 0) {
		if (up) if_level++;
		if (if_level >= if_level_max) {
			if_level_max += IF_LEVEL_EXT;
			if_stack = MRealloc(if_stack,if_level_max);
			if (!if_stack) return -1;
		}
		if_stack[if_level] = thenl;
	}
	else if (up < 0) {
		if (if_level > 0) if_level--;
		if (if_level > 0) thenl = if_stack[if_level];
		else thenl = 0;
	}
/*
printf("_set_if_level: up=%d thenl=%d if_level=%d\n",up,thenl,if_level);
*/
	return thenl;
}

/************************************/
/* _get_if_level					*/
/************************************/
static int _get_if_level()
{
	int thenl;

	if (if_stack && if_level>0) thenl = if_stack[if_level];
	else thenl = 0;
/*
printf("_get_if_level: thenl=%d if_level=%d\n",thenl,if_level);
*/
	return thenl;
}

/************************************/
/* _insert_ENDIF					*/
/************************************/
static int _insert_ENDIF(y,n)
condList *y;
int n;
{
	int rc=0;
	cmdInfo *cmd;
	cmdTable *pcmd;
	condList TmpcList;
	parmList *tmplp;
/*
printf("cllex:_insert_ENDIF: n=%d\n",n);
*/
	if (n > 0) {
		cmd = y->cmd;
		TmpcList = *y;
		tmplp = cmd->prmp[0];
		strcpy(comstr,"ENDIF");
		pcmd = cl_cmd_chk(comstr);
		cl_cmd_init(cmd);
		cmd->cid  = pcmd->cmdid;
		cmd->type = pcmd->type;
		cmd->rc   = y->line;
		while (n-- > 0) {
/*
printf("cllex:_insert_ENDIF: comstr=[ENDIF] at line=%d\n",CLcList.line);
*/
			cmd->prmnum = 0;
			if (rc = clparmset(y,"",0)) break;
			cmd->prmnum--;
			if (rc = clparmset2()) break;
			if (rc = cl_syn_main()) break;
		}
		*y = TmpcList;
		cmd->prmp[0] = tmplp;
	}
	return rc;
}

/************************************/
/* _chk_heredoc						*/
/************************************/
int _chk_heredoc(y)
condList *y;
{
	int i,parm_pos,len,nam_len,rc,cid,pos,del_tab_space,len_b,opt800;
	char *p,*name,buf[BUFLEN],*pp;
	parmList **prmp,*lp;
	cmdInfo *cmd;
	MCAT mcat;
/*
printf("_chk_heredoc:Enter\n");
*/
	cmd = y->cmd;
	prmp = cmd->prmp;
	rc = nam_len = del_tab_space = 0;
	name = NULL;
	for (i=0;i<cmd->prmnum;i++) {
		lp = prmp[i];
		nam_len = lp->prmlen;
		p = lp->prp;
/*
printf("_chk_heredoc: i=%d p=[%s]\n",i,p);
*/
		if (nam_len>=2 && !memcmp(p,"<<",2)) {
			nam_len -= 2;
			if (nam_len > 0) {
				p += 2;
				pos = akxnskipin(p,nam_len,"-=!");
/*
printf("_chk_heredoc: i=%d pos=%d\n",i,pos);
*/
				if (pos > 0) {
					del_tab_space = D_PFLAG2_DEL_TAB;
					if (inmemchars(p,pos,"=")) del_tab_space |= D_PFLAG2_DEL_SPACE;
/*
printf("_chk_heredoc: i=%d rc=%d del_tab_space=%02x\n",i,rc,del_tab_space);
*/
					p += pos;
					nam_len -= pos;
				}
			}
			if (nam_len > 0) name = akxttrim2(0,p,&nam_len);
			if (nam_len > 0) break;
			else if (i < cmd->prmnum - 1) {
				lp = prmp[i+1];
				nam_len = lp->prmlen;
				name = akxttrim2(0,lp->prp,&nam_len);
				if (nam_len > 0) break;
				return -1;
			}
			else return -1;
		}
	}
	if (name) {
		del_tab_space |= cl_get_option(25,0) & (AKX_TRIM_DEL_TAB | AKX_TRIM_DEL_SPACE);
		name = strmem(name,nam_len);
/*
printf("_chk_heredoc: name=[%s]\n",name);
*/
		rc = 0;
		if (instrchar("$%#'",*name)) {
					/* %s: heredoc�̏I�[������[%s]������Ă��܂��B*/
			ERROROUT2(FORMAT(632),"_chk_heredoc",name);
			rc = -1;
		}
		opt800 = cl_get_option(25,0) & D_RED_PFLAG2_FILE;
		if (!opt800) {
			memset(&mcat,0,sizeof(MCAT));
			mcat.mc_extlen = 512;
		}
		while (!rc) {
			if (rc = cl_get_str(y,buf)) {
						/* %s: heredoc�̏I���s[%s]������܂���B*/
				ERROROUT2(FORMAT(631),"_chk_heredoc",name);
				rc = -1;
				break;
			}
			len = strlen(buf);
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buf=[%s]",len,buf);
			if (opt800) {
				len_b = 0;
			}
			else {
				len_b = mcat.mc_ipos;
				akxtmcat(&mcat,buf,len);
			}
			p = buf + len - 1;
			if (*p == '\n') *p = '\0';
/*
printf("_chk_heredoc: buf=[%s]\n",buf);
*/
			if (del_tab_space) {
				len = strlen(buf);
				p = akxttrim2(del_tab_space|2,buf,&len);
/*
printf("_chk_heredoc: p=[%s]\n",p);
*/
			}
			else p = buf;
			if (!strcmp(p,name)) {
				rc = 1;
				len = cmn_i_to_a(cmd->rc,buf);
				/* �I�[���������蒼�� */
				nam_len = lp->prmlen;
				name = akxttrim2(0,lp->prp,&nam_len);
				/* �ϐ��̈���m�� */
				p = CTMalloc(y->ConstCt,nam_len+len+len_b+4);
				lp->prp = p;
				/* �I�[��������R�s�[ */
				memzcpy(p,name,nam_len);
				p += nam_len;
				if (opt800) {
					/* " F"�ƃR�}���h�s�ԍ����R�s�[ */
					*p++ = ' ';
					*p++ = 'F';
					memzcpy(p,buf,len);
					lp->prmlen = nam_len + len + 2;
				}
				else {
					/* '.'�ƃR�}���h�s�ԍ����R�s�[ */
					*p++ = '.';
					memzcpy(p,buf,len);
					p += len;
					/* " M"�Ɠ��̓f�[�^���R�s�[ */
					pp = mcat.mc_bufp;
/*
printf("_chk_heredoc: len=%d pp=[%s]\n",len_b,pp);
*/
					*p++ = ' ';
					*p++ = 'M';
					if (pp && len_b>0) {
						memzcpy(p,pp,len_b);
						Free(pp);
					}
					lp->prmlen = nam_len + len + len_b + 3;
				}
/*
printf("_chk_heredoc: lp->prmlen=%d lp->prp=[%s]\n",lp->prmlen,lp->prp);
*/
				break;
			}
		}
	}
/*
printf("_chk_heredoc:Exit rc=%d\n",rc);
*/
	return rc;
}

/************************************/
/* _kugiri							*/
/************************************/
static int _kugiri(y,kc,h,wkstr,pinfo)
condList *y;
char kc,*wkstr,*pinfo;
int  h;
{
	int rc,parmlen,cnum,cid,no_kugiri,n,i,thenl,elsel,cmd_count,scno,pos,heredoc,cmd_type;
	cmdTable *pcmd;
	char *p,wrk[2];
	cmdInfo *cmd;

	cmd = y->cmd;
	parmlen = h;
	wkstr[parmlen] = '\0';

DEBUGOUTL5(LEX_LOG_GROUP+124,"_kugiri: kc=[%c] h=%d wkstr=[%s] info=[%c] cid=%08x",kc,h,wkstr,*pinfo,cmd->cid);

/*
printf("_kugiri: kc=%c h=%d wkstr=[%s] info=%c cid=%08x\n",kc,h,wkstr,*pinfo,cmd->cid);
*/
/*
printf("_kugiri: cid=%08x thenl_level=%d\n",cid,thenl_level);
*/
	if (*pinfo == 'N') cmd->cid = C_UNKNOWN;
	thenl = 0;
	elsel = 0;
	heredoc = 0;
	if (parmlen>0 || (!parmlen && (kc=='(' || kc=='['))) {
		if (*pinfo == 'N') {	/* �R�}���h */
			cl_cmd_init(cmd);
#if 1	/* 2023.8.11 */
			if ((cmd_type=cl_cmd_chk2(wkstr,&pcmd)) < 0) return cmd_type;
			else if (cmd_type == 9) {
				if (gpLabel) {
					if ((rc=_kugiri(y,M_KUGIRI,0,wrk,pinfo)) < 0) return rc;
				}
				gpCmd = pcmd;
			/*	strcpy(comstr,wkstr);	*/
				wkstr[parmlen-1] = '\0';
/*
printf("_kugiri: wkstr=[%s] cmd_type=%d\n",wkstr,cmd_type);
*/
				gpLabel = Strdup(wkstr);
				cl_cmd_init(cmd);
				clparmclr(y);
				return 0;
			}
#else
			pcmd = cl_cmd_chk(wkstr);
#endif
/*
printf("_kugiri: wkstr=[%s] at line=%d\n",wkstr,CLcList.line);
*/
			if ((cid=pcmd->cmdid) == C_UNKNOWN) {
				strcpy(comstr,"LET");
				pcmd = cl_cmd_chk(comstr);
				cmd->cid = cid = pcmd->cmdid;
				cmd->type = pcmd->type;
				cmd->rc  =  y->line;
				*pinfo = 'C';
				if (kc=='[' || kc=='(') return C_PARM_CONTINUE;
				if (rc=clparmsetopt(y,wkstr, parmlen,1)) return rc;
			}
		/*	else if (cid == C_ERROR) return ECL_SCRIPT_ERROR;	2023.8.11 del */
			else {
				gSqlMode = 0;
				cmd->cid = cid = pcmd->cmdid;
				cmd->type = pcmd->type;
				cmd->rc  =  y->line;/*add 95.1.4 Koba*/
/*
printf("_kugiri: wkstr=[%s] pcmd->type=%d\n",wkstr,pcmd->type);
*/
				*pinfo = 'C';
				strcpy(comstr,wkstr);
				if (kc == '(') return C_PARM_START;
				if ((cid==C_ELSE || cid==C_DEFAULT || cid==C_ELSEL ||
				     cid==C_FINALLY) &&
				    (kc==' ' || kc=='\t' || kc=='\n')) {
					kc = M_KUGIRI;
					if (cid == C_ELSEL) {
						cmd->cid = cid = C_ELSE;
						elsel = 1;
					}
				}
				else if (cid == C_SQL) gSqlMode = 1;
			}
		}
		else {	/* �p�����[�^ */
			cmd->rc  =  y->line;
			no_kugiri = 1;
			cid = cmd->cid;
			if (cid==C_IF || cid==C_ELSEIF) {
				if (!stricmp(wkstr,"THEN")) {
					no_kugiri = 0;
					kc = M_KUGIRI;
				}
				else if (!stricmp(wkstr,"THENL")) {
					no_kugiri = 0;
					kc = M_KUGIRI;
					thenl = 1;
				}
			}
			else if ((cid==C_LOOP || cid==C_FOR || cid==C_WHILE || cid==C_UNTIL) &&
			     !stricmp(wkstr,"DO")) {
				no_kugiri = 0;
				kc = M_KUGIRI;
				cmd->sub_cid = C_LOOP_DO;
			}
			else if (cid == C_TRY) {
				pos= akxnskipin(wkstr,strlen(wkstr)," \t");
				if (!cmd->prmnum && wkstr[pos]!='(') {
					if ((rc=_kugiri(y,M_KUGIRI,0,wrk,pinfo)) < 0) return rc;
					return _kugiri(y,kc,h,wkstr,pinfo);
				}
			}
			if (no_kugiri) {
				if (rc=clparmsetopt(y,wkstr,parmlen,1)) return rc;
			}
		}
	}
#if 1	/* 2023.8.11 */
	if (gpLabel && kc==M_KUGIRI && *pinfo=='N' && !parmlen) {
		strcpy(comstr,gpLabel);		/* tree�\���ŃR�}���h�Ƃ��ĕ\�������邽�� */
		strcat(comstr,":");
		cmd->cid = C_LABEL;
		cmd->type = gpCmd->type;
		cmd->rc  =  y->line;
		if (rc=clparmsetopt(y,gpLabel,strlen(gpLabel),1)) return rc;
		Free(gpLabel);
		gpLabel = NULL;
	}
#endif
	cid = cmd->cid;
	if (kc==M_KUGIRI && cid!=C_UNKNOWN) {
		if (cid==C_EXEC || cid==C_CALL) {
			if ((rc=_chk_heredoc(y)) < 0) return rc;
			else if (rc > 0) heredoc = 1;
		}
/*
printf("_kugiri: comstr=[%s] at line=%d\n",comstr,y->line);
*/
		if (rc = clparmset(y,"",0)) return rc;	/* ���[�N�G���A���Ō�ɕt���� */
		if (rc = clparmset(y,"",0)) return rc;	/* 2020.10.29 add */
		cmd->prmnum -= 2;				/* �p�����[�^���ɏ�L�͓���Ȃ� */
		if (rc = clparmset2(y)) return rc;
		cid = cmd->cid;
/*
printf("_kugiri: thenl_level=%d else_level=%d cmd_count=%d\n",
thenl_level,else_level,cmd_count);
*/
		if ((cmd_count=_get_if_level()) > 0) {
			if (cid==C_ELSE || cid==C_ELSEIF ||
			    (cid==C_END && !stricmp(wkstr,"IF")) || cmd_count>1) {
				while (_get_if_level() > 0) {
					if (rc=_insert_ENDIF(y,1)) return rc;
					_set_if_level(-1,0);
				}
				elsel = 0;
			}
		}
#if 1	/* 2023.8.11 */
	/*	if (cid != C_LABEL) {	*/
			y->cdl_label = gpLabel;
	/*	}	*/
#endif
		if (rc = cl_syn_main(y)) {	/* ��͖؍쐬 */
			return rc;
		}
#if 1	/* 2023.8.11 */
		gpLabel = NULL;
#endif
		scno = cmd->sub_cid;
		if ((cid==C_LET || cid==C_DEFINE) && (scno==CS_OPTIONS || scno==CS_OPTION)) {
			cM_QUOTE1 = pGlobTable->Quot[0];
			cM_QUOTE2 = pGlobTable->Quot[1];
		}
		/* "end if" �́Acl_syn_main()�̒���C_ENDIF�ɕϊ������̂�cid���Đݒ肷�� */
		cid = cmd->cid;
/*
printf("_kugiri: comstr=[%s] at line=%d thenl=%d elsel=%d thenl_level=%d\n",
comstr,CLcList.line,thenl,elsel,_get_if_level());
*/
		if (cid == C_IF) {
			if (_get_if_level() > 0) _set_if_level(0,2);
			_set_if_level(1,thenl);
		}
		else if (cid == C_ELSEIF) _set_if_level(0,thenl);
		else if (cid == C_ELSE)   _set_if_level(0,elsel);
		else if (cid == C_ENDIF)  _set_if_level(-1,0);
		else {
			while (_get_if_level() > 0) {
				if (rc = _insert_ENDIF(y,1)) return rc;
				_set_if_level(-1,0);
			}
		}
		*pinfo = 'N';
		cl_cmd_init(cmd);
		clparmclr(y);
	}
	if (heredoc) rc = C_PARM_HEREDOC;
	else rc = 0;
	return rc;
}

/************************************/
/* _nest_up							*/
/************************************/
static int _nest_up(ifnest_cnt)
int ifnest_cnt;
{
	ifnest_cnt++;
	if (ifnest_cnt>=MAXIFNEST) {
		ERROROUT("if nest over!!");
		return -1;
	}
	return ifnest_cnt;
}

/************************************/
/* _check_defined					*/
/************************************/
static int _check_defined(word,pp)
char *word,**pp;
{
	int ix;

	ix = 0;
	if (       sqp_lex_def)  ix = akxs_xseqs2(sqp_lex_def,'R',word,pp);
	if (!ix && xhp_main_def) ix = akxs_xhash2(xhp_main_def,'R',word,pp);
	if (!ix && xhp_lex_def)  ix = akxs_xhash2(xhp_lex_def,'R',word,pp);
/*
printf("_check_defined: ix=%d\n",ix);
*/
	return ix;
}

/************************************/
/* _PragmaStackInit					*/
/************************************/
static int _PragmaStackInit(y)
condList *y;
{
	SSPL_S *pspSTK;
	tdtInfoParm *pInfoParm;
	condList *pCLcList;
	tdtPragmaStack *pPrag;
	char *p;

	while (iListStack > 0) {
		pPrag = &tPragmaStack[iListStack];
		pCLcList = &pPrag->pra_cList;
		if (pCLcList->option & D_SCRPT_MEMORY) {
			pInfoParm = (tdtInfoParm *)pCLcList->fp;
			Free(pInfoParm->pi_data);
			Free(pInfoParm->pi_paux);
			Free(pInfoParm);
		}
		iListStack--;
		pPrag = &tPragmaStack[iListStack];
		if (p=pPrag->pra_defkey) Free(p);
		pspSTK = &pPrag->pra_sspl;
		if (p=pspSTK->wd) Free(p);
	}
	p = akxt_get_last_name("\\/",y->fullname);
/*
printf("_PragmaStackInit: p=[%s]\n",p);
*/
	pPrag = &tPragmaStack[0];
	pPrag->pra_opt = 1;
	pPrag->pra_defkey = Strdup(p);
	pspSTK = &pPrag->pra_sspl;
	pspSTK->wd = NULL;
	iListStack0=1;
	iListStack=1;
	if (xhp_lex_def) {
		akxs_xhash_free(xhp_lex_def);
		xhp_lex_def = NULL;
	}
	if (sqp_lex_def) {
		akxs_xseqs_free(sqp_lex_def);
		sqp_lex_def = NULL;
	}
	return 0;
}

/************************************/
/* _proc_pragma						*/
/************************************/
static int _proc_pragma(y,buf,pos,psspl,optc,sc_code)
condList *y;
char *buf;
int pos,sc_code;
SSPL_S *psspl;
char optc;
{
	static char *_fn_="_proc_pragma";
	static char *command[]=
		{"define","undef","ifdef","ifndef","if","elif","else","endif","elifdef","elifndef","include",NULL};
	SSP_S ssp;
	char *p,word0[BUFLEN*8],cmd,c,*key,*wbuf,*word;
	int len,i,ix,icmd,iTrue,tr,ifflg,word_len,buf_len;
	int op,stack[2],istack,v,rc;
	cmdInfo *ycmd;

	ycmd = y->cmd;
	if (!buf) {
		ifnest_cnt=0;
		ifnest[0]=1;
		iftrue[0]=0;
		return _PragmaStackInit(y);
	}
	word = word0;
	word_len = sizeof(word0);
	wbuf = buf;
	buf_len = psspl->wdmax;
#if 1	/* 2022.1.17 */
	_get_def_cont(y,buf+pos,buf_len-pos,word,word_len,sc_code,1,buf,psspl);
	wbuf = word;
	pos = 0;
	buf_len = strlen(wbuf);
	word += buf_len + 1;
	word_len -= buf_len + 1;
#endif
	ycmd->cid = C_PRAGMA;
	ssp.sp = pos;
	ssp.wd = word;
	if ((len=akxtgwsp(wbuf,&ssp)) > 0) {

DEBUGOUTL1(LEX_LOG_GROUP+122,"_proc_pragma: word=[%s]",ssp.wd);

		clparmclr(y);
		clparmset(y,wbuf+pos,psspl->wdmax-pos);
		icmd = i = 0;
		while (p=command[i++]) {
			if (!strcmp(word,p)) break;
		}
		if (p) {
			icmd=i;
		}
		else {
			ERROROUT1("_proc_pragma: invalid command(%s).",word);
			return -1;
		}
		ycmd->sub_cid = i;
/*
printf("_proc_pragma: icmd=%d ifnest_cnt=%d ifnest=%d\n",icmd,ifnest_cnt,ifnest[ifnest_cnt]);
*/
		if (icmd==1 || icmd==2) {			/* define, undef */
/*
printf("_proc_pragma: icmd=%d optc=%c\n",icmd,optc);
*/
			if (optc == DEF_OPTC_ICASE) {
				if (!sqp_lex_def) {
					if (!(sqp_lex_def=akxs_xseqs_new2(0,DEFICASEMAX,0,0))) return -1;
					sqp_lex_def->xha_prereg = AKX_ARGV_USE_ICMP;
				}
			}
			else {
				if (!xhp_lex_def) {
					if (!(xhp_lex_def=akxs_xhash_new2(0,10,7,0))) return -1;
				}
			}
			if ((len=akxtgwse(wbuf,&ssp," \t(",0x01)) > 0) {
DEBUGOUTL2(LEX_LOG_GROUP+122,"_proc_pragma: icmd=%d word=[%s]",icmd,word);
				/* 2021.11.2 */
				if ((i=cl_chk_name_pos(word,len)) != 0) {
					/* %s: �L�[[%s]��(pos=%d)�Ɏg�p�ł��Ȃ�����������܂��B */
					ERROROUT3(FORMAT(52),_fn_,word,i);	/* i+1 ==> i 2021.11.2 */
					return -1;
				}
				if (icmd==1) {
/*
printf("_proc_pragma: word=[%s]\n",word);
*/
					if (optc == DEF_OPTC_ICASE)
						ix = akxs_xseqs(sqp_lex_def,'R',word);
					else
						ix = akxs_xhash(xhp_lex_def,'R',word);
					if (ix < 0) return ix;
#if 0	/* 2021.7.18 del �㏑���ɕύX */
					else if (ix > 0) {
						/* %s: �L�[[%s]����`�ς݂ł��B */
						ERROROUT2(FORMAT(53),_fn_,word);
						return -1;
					}
#endif
					cmd = 'S';
					ssp.wd += len + 1;
					/* 2022.1.17 */
					i = _get_def_cont(y,wbuf+ssp.sp,buf_len-ssp.sp,ssp.wd,word_len-(len+1),sc_code,0,buf,psspl);
/*
printf("_proc_pragma: ssp.wd=[%s]\n",ssp.wd);
*/
					if (i < 0) return i;
				}
				else cmd = 'D';
				if (optc == DEF_OPTC_ICASE)
					ix = akxs_xseqs2(sqp_lex_def,cmd,word,ssp.wd);
				else
					ix = akxs_xhash2(xhp_lex_def,cmd,word,ssp.wd);
				if (ix < 0) return ix;
				ssp.wd = word;
			}
		}
		else if (icmd == 11) {	/* include */
			if ((len=akxtgwse(wbuf,&ssp," \t",0x03)) <= 0) {
				/* %s: �t�@�C�������w�肳��Ă��܂���B */
				ERROROUT1(FORMAT(54),_fn_);
				return -1;
			}
			return _include_define(y,psspl,word);
		}
		else if (icmd > 0) {
			if (icmd>=6 && ifnest_cnt<=0) {
				/* %s: if,ifdef,ifndef���Ȃ��̂ɁA[%s]���w�肳��܂����B */
				ERROROUT2(FORMAT(54),_fn_,word);
				return -1;
			}
			tr = iTrue = iftrue[ifnest_cnt];
/*
printf("_proc_pragma: iTrue=%d icmd=%d\n",iTrue,icmd);
*/
			if (icmd==7) {		/* else */
				if (iTrue) v = 0;
				else v = 1;
				ifnest[ifnest_cnt] = v;
				iftrue[ifnest_cnt] = 1;
/*
printf("_proc_pragma: else ifnest_cnt=%d ifnest=%d\n",ifnest_cnt,ifnest[ifnest_cnt]);
*/
			}
			else if (icmd==8) {	/* endif */
				ifnest_cnt--;
			}
			else {
/*
printf("_proc_pragma: word=[%s]\n",word);
*/
				if (icmd==3 || icmd==4 ||		/* ifdef, ifndef */
				    icmd==9 || icmd==10) {		/* elifdef, elifndef */
					if ((len=akxtgwse(wbuf,&ssp," \t(",0x01)) > 0) {
DEBUGOUTL2(LEX_LOG_GROUP+122,"_proc_pragma: icmd=%d word=[%s]\n",icmd,word);
						if (icmd==3 || icmd==4) {
							if ((ifnest_cnt=_nest_up(ifnest_cnt)) < 0) return ifnest_cnt;
						}
						if ((icmd==9 || icmd==10) && iTrue) ix = 0;
						else {
							ix = _check_defined(word,NULL);
							if (ix < 0) return ix;
							if (icmd==4 || icmd==10) {
								if (ix) ix = 0;
								else ix = 1;
							}
							tr = ix;
						}
						ifnest[ifnest_cnt] = ix;
						iftrue[ifnest_cnt] = tr;
/*
printf("_proc_pragma: icmd=%d ifnest_cnt=%d ifnest=%d iftrue=%d\n",icmd,ifnest_cnt,v,tr);
*/
					}
				}
				else if (icmd==5 || icmd==6) {	/* if, elif */
					if ((len=akxtgwsp(wbuf,&ssp)) > 0) {
DEBUGOUTL2(LEX_LOG_GROUP+122,"_proc_pragma: icmd=%d word=[%s]\n",icmd,word);
						if (icmd==5) {
							if ((ifnest_cnt=_nest_up(ifnest_cnt)) < 0) return ifnest_cnt;
						}
						if (icmd==6 && iTrue) v = 0;
						else {
							if (((c=*word)>='0' && c<='9') || c=='+' || c=='-') {
		 						tr = v = atoi(word);
							}
							else {
								tr = v = istack = 0;
								while (len>0) {
									if (!strcmp(word,"defined")) {
										len=akxtgwsp(wbuf,&ssp);	/* '(' */
										len=akxtgwsp(wbuf,&ssp);

DEBUGOUTL1(LEX_LOG_GROUP+122,"_proc_pragma:if: word=[%s]\n",word);

										ix=_check_defined(word,NULL);
										if (ix>0) v = 1;
										else v = 0;
										tr = v;
										len = akxtgwsp(wbuf,&ssp);	/* ')' */
										stack[istack++] = v;
										if (istack == 2) {
											if (op) v = stack[0] && stack[1];
											else    v = stack[0] || stack[1];
											ifnest[ifnest_cnt] = v;

DEBUGOUTL3(LEX_LOG_GROUP+122,"if: stack[0]=%d stack[1]=%d v=%d",stack[0],stack[1],v);

											istack = 0;
										}
									}
									else {
										/* %s: if syntax error!! defined only(word=[%s]). */
										ERROROUT2(FORMAT(551),_fn_,word);
										return -1;
									}
									if ((len=akxtgwsp(wbuf,&ssp)) > 0) {
										if (!strcmp(word,"||")) op = 0;
										else if (!strcmp(word,"&&")) op = 1;
										else {
											/* %s: if syntax error!! op=[%s] */
											ERROROUT2(FORMAT(552),_fn_,word);
											return -1;
										}
/*
printf("if: op=%s %d\n",w,op);
*/
										len = akxtgwsp(wbuf,&ssp);
									}
								}
							}
						}
						ifnest[ifnest_cnt] = v;
						iftrue[ifnest_cnt] = tr;
/*
printf("_proc_pragma: icmd=%d ifnest_cnt=%d ifnest=%d iftrue=%d\n",icmd,ifnest_cnt,v,tr);
*/
					}
				}
			}
			ifflg = 1;
			for (i=1;i<=ifnest_cnt;i++) {
				if (!ifnest[i]) {
					ifflg = 0;
					break;
				}
			}
/*
printf("_proc_pragma: icmd=%d ifflg=%d\n",icmd,ifflg);
*/
			i = _skip_line(y,buf,psspl);
			if (!ifflg) {
				while (i>=0) {
					if (buf[0]=='#' && strchr(M_PRAGMA,buf[1])) break;
					i = _skip_line(y,buf,psspl);
				}
			}
			return i;
		}
	}
	i = _skip_line(y,buf,psspl);
/*
printf("_proc_pragma:Exit i=%d\n",i);
*/
	return i;
}

/************************************/
/* _rep_define						*/
/************************************/
/* 2021.10.31 */
static int _rep_define_sub(mcat0,s0,n,ssp0)
MCAT *mcat0;
char *s0;
int n;
SSPL_S *ssp0;
{
	static char *_fn_="_rep_define_sub";
	MCAT mcat;
	int i,ix,rc,dlen,ret,len,sp1,sp2,is;
	char *s,*p,*buff,word[256];
	condList *pclSTK;
	SSPL_S *pspSTK,ssp;
	tdtInfoParm *pInfoParm;
	tdtPragmaStack *pPrag;

	rc = 0;
	s0[n] = '\0';

DEBUGOUTL2(LEX_LOG_GROUP+106,"_rep_define_sub: n=%d s0=[%s]",n,s0);

	if (n>0 && (sqp_lex_def || xhp_main_def || xhp_lex_def)) {
/*
printf("_rep_define_sub:Enter n=%d s0=[%s]\n",n,s0);
*/
		s = s0;
		sp1 = ssp0->sp;
		while ((len=akxtgwnsl(s,n,ssp0,cmp_sep,0x41)) > 0) {
/*
printf("%s: len=%d sp=%d wd=[%s] sp1=%d\n",_fn_,len,ssp0->sp,ssp0->wd,sp1);
*/
			if (ssp0->attr[0] == 1) {
				ix = _check_defined(ssp0->wd,&p);
				if (ix > 0) {
					akxtmcat(mcat0,s+sp1,ssp0->sp-len-sp1);
					sp1 = ssp0->sp;
/*
printf("%s: iListStack=%d ix=%d s=[%s] p=[%s]\n",_fn_,iListStack,ix,s,p);
*/
					pPrag = &tPragmaStack[0];
					for (i=0;i<iListStack;i++,pPrag++) {
/*
printf("_rep_define: defStack[%d]=[%s]\n",i,pPrag->pra_defkey);
*/
						if (!pPrag->pra_opt && !strcmp(pPrag->pra_defkey,s)) {
							/* %s: define word[%s] is loop!! */
							ERROROUT2(FORMAT(553),_fn_,s);
							return -1;
						}
					}
					if ((dlen=strlen(p)) <= 0) return C_NO_DEF_PARM;
					is = akxs_in_str_opt(p,"(",0);
					memset(&mcat,0,sizeof(MCAT));
					mcat.mc_extlen = 128;
					if (is > 0) {
						if (*(s+ssp0->sp)!='(') {
							/* %s: �p�����[�^���K�v�ł��B */
							ERROROUT1(FORMAT(44),_fn_);
							return -1;
						}
						if ((rc=_rep_def_parm(&mcat,s0+sp1-len,p,ssp0)) < 0) return rc;
						p = mcat.mc_bufp;
						dlen = mcat.mc_ipos;
					}
					memset(&ssp,0,sizeof(SSP_S));
					ssp.wd = word;
					ssp.wdmax = sizeof(word);
					ret = _rep_define_sub(mcat0,p,dlen,&ssp);
					if (p=mcat.mc_bufp) Free(p);
					rc = 1;
				}
				else akxtmcat(mcat0,s+sp1,ssp0->sp-sp1);
			}
			else akxtmcat(mcat0,s+sp1,ssp0->sp-sp1);
			sp1 = ssp0->sp;
		}
	}
	return rc;
}

static int _adjust_kakko(s0,n,ka)
char *s0;
int n,ka[];
{
	static char *KKO = "({[)}]";
	static char *RKKO = ")}]({[";
	int len,k1,k2,k3,i,pos,rc;
	char c,work[256],*p;
	SSPL_S ssp;
/*
printf("_adjust_kakko:Enter n=%d s0=[%s]\n",n,s0);
*/
	k1 = k2 = k3 = 0;
	memset(&ssp,0,sizeof(SSPL_S));
	i = 0;
	while ((len=akxtgwnsl(s0,n,&ssp,cmp_sep,1)) > 0) {
		if ((c=*ssp.wd) == '(') {
			k1++;
			work[i++] = c;
		}
		else if (c == ')') {
		/*	if (k1 <= 0) return -1;	*/
			k1--;
			work[i++] = c;
		}
		else if (c == '{') {
			k2++;
			work[i++] = c;
		}
		else if (c == '}') {
		/*	if (k1 <= 0) return -1;	*/
			k2--;
			work[i++] = c;
		}
		else if (c == '[') {
			k3++;
			work[i++] = c;
		}
		else if (c == ']') {
		/*	if (k1 <= 0) return -1;	*/
			k3--;
			work[i++] = c;
		}
	}
/*
printf("_adjust_kakko: k1=%d k2=%d k3=%d i=%d\n",k1,k2,k3,i);
*/
	ka[0] -= k1;
	ka[1] -= k2;
	ka[2] -= k3;
	i--;
	for (;i>= 0;i--) {
		c = work[i];
		pos = instrchar(KKO,c);
		rc = _chk_act(*(RKKO+pos-1));
	}
	return 0;
}

static int _rep_define(psspl,s0,n,k1,k2,k3,ka)
SSPL_S *psspl;
char *s0;
int n;
int k1,k2,k3,ka[];
{
	static char *_fn_="_rep_define";
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	int i,ix,rc,len,sp1,nn,len1,i0,m,mm,buf_end;
	char *p,word[256],*pp,*buf;
	SSPL_S ssp;

	rc = 0;
	s0[n] = '\0';
	ka[0] = k1;
	ka[1] = k2;
	ka[2] = k3;
	if (n > 0) {
/*
printf("_rep_define:Enter k1=%d k2=%d k3=%d n=%d s0=[%s]\n",k1,k2,k3,n,s0);
*/
		memset(&ssp,0,sizeof(SSPL_S));
		ssp.wd = word;
		ssp.wdmax = sizeof(word);
		mcat.mc_ipos = 0;
		if (mcat.mc_bufp) *mcat.mc_bufp = '\0';
		while ((len=akxtgwnsl(s0,n,&ssp,cmp_sep,0x41)) > 0) {
/*
printf("%s: len=%d sp=%d wd=[%s]\n",_fn_,len,ssp.sp,ssp.wd);
*/
			if (ssp.attr[0] == 1) {
				ix = _check_defined(ssp.wd,&p);
				if (ix > 0) {
					ssp.sp = ssp.sp - len;
					akxtmcat(&mcat,s0,ssp.sp);
					rc = _rep_define_sub(&mcat,s0,n,&ssp);
					if (rc == 1) {
						_adjust_kakko(s0,n,ka);
						akxtmcats(&mcat,"");
						m = mcat.mc_ipos;
/*
printf("%s: mc_ipos=%d mc_bufp=[%s]\n",_fn_,m,mcat.mc_bufp);
*/
						buf  = psspl->wd;
						i    = psspl->sp;
						len1 = psspl->wdmax;
/*
printf("%s: i=%d len=%d buf=[%s]\n",_fn_,i,psspl->wdmax,buf);
*/
						i0 = i - n;
						nn = n - m;
						if (i0 < 0) {
							nn += i0;
							i0 = 0;
						}
						if (nn > 0) {
							memzcpy(buf+i-nn,buf+i,len1-i);
							psspl->wdmax -= nn;
						}
						else if (nn < 0) {
							psspl->wdmax -= nn;
							p = buf + len1 + 1;
							pp = p - nn;
							buf_end = len1 + 1 - nn;
							if (i0 < 0) {
								psspl->wdmax -= i0;
								pp += -i0;
								buf_end += -i0;
								i0 = 0;
							}
/*
printf("%s: buf_end=%d\n",_fn_,buf_end);
*/
							if (buf_end >= BUFLEN*2) {
								ERROROUT3("%s: input buffer(%d) overflow(%d)",_fn_,BUFLEN*2,buf_end);
								return -1;
							}
							nn = len1 - i + 2;
							while (nn-- > 0) {
								*pp-- = *p--;
							}
						}
						psspl->sp = i0;
						memcpy(buf+i0,mcat.mc_bufp,m);
/*
printf("%s: i0=%d len=%d buf=[%s]\n",_fn_,i0,psspl->wdmax,buf);
*/
						s0[0] = '\0';
					}
					break;
				}
			}
		}
	}
	return rc;
}

/************************************/
/* _resume_define					*/
/************************************/
static int _resume_define(y,psspl)
condList *y;
SSPL_S *psspl;
{
	int ix,rc,ret=0;
	char *p;
	condList *pclSTK;
	SSPL_S *pspSTK;
	tdtInfoParm *pInfoParm;
	SSP_S *ssp;
	condList *pCLcList;
	tdtPragmaStack *pPrag;
/*
printf("_resume_define:1: iListStack=%d psspl->sp=%d psspl->wd=[%s]\n",
iListStack,psspl->sp,psspl->wd);
*/
	if (iListStack > iListStack0) {
		pPrag = &tPragmaStack[iListStack];
		pCLcList = &pPrag->pra_cList;
		if (pCLcList->option & D_SCRPT_MEMORY) {
			pInfoParm = (tdtInfoParm *)pCLcList->fp;
			Free(pInfoParm->pi_data);
			Free(pInfoParm->pi_paux);
			Free(pInfoParm);
		}
		iListStack--;
		pPrag = &tPragmaStack[iListStack];
		if (p=pPrag->pra_defkey) Free(p);
		pPrag->pra_defkey = NULL;
		pCLcList = &pPrag->pra_cList;
		y->fp = pCLcList->fp;
		y->line = pCLcList->line;
		y->option = pCLcList->option;
		y->fullname = pCLcList->fullname;
		pspSTK = &pPrag->pra_sspl;
		p = psspl->wd;
		memcpy(psspl,pspSTK,sizeof(SSPL_S));
		psspl->wd = p;
		memcpy(p,pspSTK->wd,psspl->wdmax);
		Free(pspSTK->wd);
		ret = 1;

DEBUGOUTL3(LEX_LOG_GROUP+122,"_resume_define:2: iListStack=%d psspl->sp=%d psspl->wd=[%s]",
iListStack,psspl->sp,psspl->wd);

	}
	return ret;
}

/************************************/
/* _rep_def_parm					*/
/************************************/
int _rep_def_parm(mcat,s,parm,ssp0)
MCAT *mcat;
char *s,*parm;
SSPL_S *ssp0;
{
	int is,ie,n,np,i,len,parmlen,attr0,opt,kk;
	char *argv[21],buf[128];
	char *argvp[21],bufp[256],word[256],*p,c;
	SSPL_S sspl;

	is = akxs_in_str_opt(s,"(",0);
	memset(&sspl,0,sizeof(SSPL_S));
	sspl.wd = word;
	sspl.wdmax = sizeof(word);
	/* 2021.11.2 */
	sspl.sp = is;
	kk = 1;
	n = strlen(s);
	while ((len=akxtgwnsl(s,n,&sspl," \t'\"()",1)) > 0) {
		if ((c=*sspl.wd) == '(') kk++;
		else if (c == ')') {
			kk--;
			if (kk <= 0) break;
		}
	}
	ie = sspl.sp;
	ssp0->sp += ie;
	n = akxtgetargvn2(s+is,ie-is-1,argv,20,buf,sizeof(buf),AKX_ARGV_DELM_COM|AKX_ARGV_NOT_CUT_QUOT);
	parmlen = strlen(parm);
	is = akxs_in_str_opt(parm,"(",0);
	ie = akxs_in_str_opt(parm,")",0);
	np = akxtgetargvn2(parm+is,ie-is-1,argvp,20,bufp,sizeof(bufp),AKX_ARGV_DELM_COM);
	if (n != np) {
		/* _rep_def_parm: �������̐�(%d)�Ɖ������̐�(%d)�������Ă��܂���B */
		ERROROUT2(FORMAT(555),n,np);
		return -1;
	}
	sspl.sp = ie + 1;
	mcat->mc_ipos = 0;
	attr0 = 100;
	if (pGlobTable->options[8] & 0x04) opt = 0x101;
	else opt = 0x201;
	for (;;) {
		if ((len=akxtgwnsl(parm,parmlen,&sspl,NULL,opt)) < 0) break;
		if (attr0<10 && sspl.attr[0]<10) akxtmcats(mcat," ");
		for (i=0;i<np;i++) {
			if (!strcmp(sspl.wd,argvp[i])) {
				break;
			}
		}
		if (i < np) p = argv[i];
		else p = sspl.wd;
		akxtmcats(mcat,p);
		attr0 = sspl.attr[0];
	}
	return 0;
}

/************************************/
/* _include_define					*/
/************************************/
static int _include_define(y,psspl,name)
condList *y;
SSPL_S *psspl;
char *name;
{
	static char *_fn_="_include_define";
	static char *fmt="***** Include file ( %s ) *****";
	char *scrname,dir[256];
	int i,ix,rc,dlen,ret=0;
	char *buff;
	condList *pclSTK;
	SSPL_S *pspSTK;
	tdtPragmaStack *pPrag;
	FILE *fp;

	if (!(scrname = cl_set_script_name_extension(name,strlen(name)))) return -1;

	pPrag = &tPragmaStack[0];
	for (i=0;i<iListStack;i++,pPrag++) {
/*
printf("_include_define: defStack[%d]=[%s]\n",i,pPrag->pra_defkey);
*/
		if (pPrag->pra_opt && !strcmp(pPrag->pra_defkey,scrname)) {
			/* %s: include file[%s] is loop!! */
			ERROROUT2(FORMAT(556),_fn_,scrname);
			return -1;
		}
	}
	if (iListStack >= CLISTSTACKMAX) {
		/* %s: define stack over(%d)!! */
		ERROROUT2(FORMAT(557),_fn_,iListStack);
		return -1;
	}
/*	PRINTOUT1(fmt,scrname);
	DEBUGOUTL1(1,fmt,scrname);	*/
	PRDBGOUTL1(1,fmt,scrname);

	fp = cl_lex_file_open(scrname,dir,_fn_);
	if (!fp) return ECL_SCR_NOTFOUND;	/* �t�@�C���I�[�v���G���[ */
	if ((i=_skip_line(y,psspl->wd,psspl)) >= 0) psspl->sp = 0;
	pPrag = &tPragmaStack[iListStack];
	pPrag->pra_opt = 1;
	pPrag->pra_defkey = Strdup(scrname);
	memcpy(pclSTK=&pPrag->pra_cList,y,sizeof(condList));
/*	memcpy(pclSTK=&pPrag->pra_cList,&CLcList,sizeof(condList));	*/
	memcpy(pspSTK=&pPrag->pra_sspl,psspl,sizeof(SSPL_S));
	pspSTK->wd = Memdup(buff=psspl->wd,psspl->wdmax);
	y->fp = fp;
	y->line = 0;
	y->option = 0;
	if (!(y->fullname = cl_const_ct_malloc(y->ConstCt,strlen(dir)+1))) {
		Free(pPrag->pra_defkey);
		pPrag->pra_defkey = NULL;
		Free(pspSTK->wd);
		pspSTK->wd = NULL;
		return ECL_MALLOC_ERROR;
	}
	strcpy(y->fullname,dir);
/*
printf("_include_define: iListStack=%d scrname=[%s] dir=[%s]\n",iListStack,scrname,dir);
*/
	y->cmd->parl[1].par = y->fullname;
	iListStack++;
	memcpy(&tPragmaStack[iListStack].pra_cList,y,sizeof(condList));
	if (cl_get_str(y,buff)) {
		_resume_define(y,psspl);
	}
	else {
		psspl->sp = 0;
		psspl->wdmax = strlen(buff);
		psspl->attr[3] = 0;
DEBUGOUTL3(LEX_LOG_GROUP+122,"_include_define: iListStack=%d scrname=[%s] buf=[%s]",
iListStack,scrname,buff);
	}
DEBUGOUTL2(LEX_LOG_GROUP+122,"cllex: len=%d buff=[%s]",strlen(buff),buff);
/*
printf("_include_define:Exit \n");
*/
	return 0;
}
