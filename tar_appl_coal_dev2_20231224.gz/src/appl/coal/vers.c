char version[] ="@(#) ***[V/R=7.4.0 (dev2)]***";

