static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -O -I../include testhashfunc.c akxcom.a -o testhashfunc
*/
#include "akxcommon.h"

static int _hashf2(kp,lklen,mso,mult)
uchar *kp;
int lklen;
int mso;
int mult;
{
	int i,k;
	uchar  uc,*p=kp;
	uint  uk;

	k = 0;
	for (i=0;i<lklen;i++) {
		k = k*mult + *p++;
	}
/*
printf("_func: k=%d\n",k);
*/
	uk=k;
	return (uk%mso+1);
}

static int _hashf1(kp,lklen,mso,mult)
uchar *kp;
int lklen;
int mso;
int mult;
{
	int i,j,k,n;
	uchar  uc,*p;
	uint  uk;
/*
printf("_hashf: klen=%d, mso=%d, mult=%d\n",lklen,mso,mult);
*/
	p = kp + lklen - 1;
	n = 0;
	for (i=0;i<lklen-5;i+=5) {
		k = 0;
		for (j=i;j<i+5;j++) {
			k = k*mult + *p--;
		}
		n += k;
/*
printf("_hashf: i=%d, k=%d, n=%d\n",i,k,n);
*/
	}
	k = 0;
	for (j=i;j<lklen;j++) {
		k = k*mult + *p--;
/*
printf("_hashf: j=%d, k=%d\n",j,k);
*/
	}
	for (;j<i+5;j++) {
		k = k*mult;
/*
printf("_hashf: j=%d, k=%d\n",j,k);
*/
	}
	n += k;
/*
printf("_hashf: i=%d, k=%d, n=%d\n",i,k,n);
*/
	uk=n;
	return (uk%mso+1);
}

int main()
{
	char buf[128],c;
	int  i,j,k,hmax,pre,ix[10240],n[10240],m,flag,kk,mm,mult,klen,h;
    unsigned int init[4]={0x123, 0x234, 0x345, 0x456}, length=4, data[2];

    init_by_array(init, length);

	klen=8;

	printf("Enter hash mult : ");
	gets(buf);
	mult=atoi(buf);
	printf("before mult=%d\n",akxs_hasx_set_mult(mult));

	printf("Enter hash max(>=2, <=10240) : ");
	gets(buf);
	hmax=atoi(buf);

	printf("Enter hash pre (<max)(<=0 auto) : ");
	gets(buf);
	pre=atoi(buf);

	printf("Enter int/char : ");
	gets(buf);
	if ((c=buf[0])=='c') flag=1;
	else flag=0;

	printf("Enter hashf(0/1/2) : ");
	gets(buf);
	h=atoi(buf);

	if (!pre) pre=akxs_hasx_pre_reg(hmax,0);
	else if (pre<0) pre=akxs_hasx_pre_reg(hmax,pre);
	printf("hmax=%d pre=%d\n",hmax,pre);
	if (pre <= 0) exit(1);

	if (hmax < 2 ) {
		for (;;) {
			printf("Enter key : ");
			gets(buf);
			if (*buf == '/') exit(0);
			if (h==1) i = _hashf1(buf,strlen(buf),pre,mult);
			else if (h==2) i = _hashf2(buf,strlen(buf),pre,mult);
			else i = akxs_hasx_func(buf,strlen(buf),pre);
		}
	}

	memset(ix,0,hmax*4);
	memset(n,0,hmax*4);
	k=0;
	for (j=0;j<hmax;j++) {
		if (flag) {
			sprintf(buf,"%d",j);
			if (h==1) i = _hashf1(buf,strlen(buf),pre,mult);
			else if (h==2) i = _hashf2(buf,strlen(buf),pre,mult);
			else i = akxs_hasx_func(buf,strlen(buf),pre);
		}
		else {
			data[0]=genrand_int32();
			data[1]=genrand_int32();
			if (h==1) i = _hashf1(data,klen,pre,mult);
			else if (h==2) i = _hashf2(data,klen,pre,mult);
			else i = akxs_hasx_func(data,klen,pre);
		}
		if (i > 0) ix[i-1]++;
	}
	printf("        no count\n");
	if (!(kk=hmax/20)) kk=1;
	mm=0;
	for (j=0;j<hmax;j+=kk) {
		i=0;
		for (k=j;k<j+kk;k++) i+=ix[k];
		if (i>mm) mm=i;
	}
	if (!(mm=(mm+49)/50)) mm=1;
	for (j=0;j<hmax;j+=kk) {
		i=0;
		for (k=j;k<j+kk;k++) i+=ix[k];
		printf("%10d %6d ",j+kk,i);
		if (i) if (!(i/=mm)) i=1;
		for (k=0;k<i;k++) printf("%s","*");
		printf("\n");
	}
	m=0;
	for (j=0;j<hmax;j++) {
		i=ix[j];
		n[i]++;
		if (i>m) m=i;
	}
	printf("\n     count     m\n");
	mm=0;
	for (i=0;i<=m;i++) {
		kk=n[i];
		if (kk>mm) mm=kk;
	}
	if (!(mm=(mm+49)/50)) mm=1;
	for (i=0;i<=m;i++) {
		printf("%10d %6d ",i,kk=n[i]);
		if (kk) if (!(kk/=mm)) kk=1;
		for (k=0;k<kk;k++) printf("%s","x");
		printf("\n");
	}
	exit(0);
}
