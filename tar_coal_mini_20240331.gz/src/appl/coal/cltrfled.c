static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_end_proc            */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Equote no shori.                          */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;	/* �^�O�̍\����͂��s�����߂̗̈� */
#endif
extern CLCOMMON  CLcommon;
extern XHASHB	*ProcIndex;

tdtCONSTCT *const_ct;
char *stack_as_name[20];

/********************************************/
/*											*/
/********************************************/
int cl_is_name(nam,n)
char *nam;
int n;
{
	int ret;
	uchar c;

	if (!nam || n<0) ret = -1;
	else if (n <= 0) ret = 0;
	else {
		ret = 0;
		if (akxqkanjilen2(nam,n) == 1) {
			c = akxcupper(*nam);
			if (c=='_' || (c>='A' && c<='Z') || (c>=0xa6 && c<=0xdd)) ret = 1;
		}
		else ret = 1;
	}
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int get_pos_as_name(pprm,nprm)
parmList **pprm;
int nprm;
{
	int i,ret,pos;
	char *p;
	parmList *prm;

	ret = 0;
	pos = 1;	/* 2023.9.24 */
	for (i=0;i<nprm;i++) {
		if (prm = pprm[i]) {
			if (p=prm->prp) {
				if (!stricmp(p,"AS")) {
					ret = i + 1;
					prm->opt = pos;		/* ret>0�̂Ƃ��ACLcList.cmd.parl[0]->par��AS�̈ʒu+1������ */
					break;
				}
				pos += prm->prmlen + 1;	/* CLcList.cmd.parl[0]->par�ɂ́Apprm[i]->prp��' '������ŘA������Ă��� */
			}
		}
	}
/*
printf("get_pos_as_name: pos=%d\n",pos);
*/
	return ret;
}
#if 0
/********************************************/
/*											*/
/********************************************/
int get_as_name(pprm,nprm,pnam)
parmList **pprm;
int nprm;
char **pnam;
{
	int i,ret;
	char *nam;
	parmList *prm;

	ret = 0;
	nam = NULL;
	if ((i=get_pos_as_name(pprm,nprm))>0 && i<nprm) {
		if (prm = pprm[i]) {
			nam = prm->prp;
			ret = prm->prmlen;
printf("get_as_name: ret=%d nam=[%s]\n",ret,nam);
		}
	}
	if (pnam) *pnam = nam;
	return ret;
}
#endif
/********************************************/
/*											*/
/********************************************/
static int _chk_as_name_sub(leaf)
Leaf  *leaf;
{
	static char *_NAME_="_chk_as_name_sub";
	int ret,level,cmnd,i,n,pos,len;
	char *p,*nam;
	uchar c;
	cmdInfo *pcmd;

	ret = 0;
	if (leaf) {
		level = leaf->type - 1;
		pcmd = &(leaf->cmd);
		cmnd = pcmd->cid;
/*
printf("_chk_as_name_sub: level=%d cmnd=[%s]\n",level,cl_gets_cmd_name(cmnd));
*/
		if (level>=0 && (cmnd==C_LOOP || cmnd==C_FOR || cmnd==C_DO || cmnd==C_SWITCH)) {
			nam = pcmd->parl[D_LEAF_LABEL].par;
			len = pcmd->parl[D_LEAF_LABEL].parlen;
			if (len > 0) {
#if 0
				if (cl_is_name(nam,len) <= 0) {
					/*_chk_as_name_sub: �u���b�N��[%s]���s���ł��B*/
					ERROROUT3(FORMAT(113),_NAME_,FORMAT(598),nam);
					ret = ECL_SCRIPT_ERROR;
				}
				if (!ret) {
#endif
					if (akxs_seqr_str(stack_as_name,level,nam,0) > 0) {
						/*_chk_as_name_sub: [%s]�Ɠ������O�̃u���b�N������܂��B*/
						ERROROUT2(FORMAT(599),_NAME_,nam);
						ret = ECL_SCRIPT_ERROR;
					}
					else {
						if (!(p = cl_const_ct_malloc(const_ct,len+1))) return ECL_MALLOC_ERROR;
						stack_as_name[level] = p;
						memcpy(p,nam,len+1);
/*
printf("_chk_as_name_sub: level=%d p=[%s]\n",level,p);
*/
					}
#if 0
				}
#endif
				if (!ret) {
					if ((pos=inistr((p=pcmd->parl[0].par),"AS")) >= 3) {
						pos -= 2;
						p[pos] = '\0';
						pcmd->parl[0].parlen = pos;
/*
printf("_chk_as_name_sub: len=%d par[0]=[%s]\n",pos,p);
*/
					}
				}
			}
		}
		if (!ret && leaf->leftleaf) {
			ret = _chk_as_name_sub(leaf->leftleaf);
		}
 		if (!ret && leaf->rightleaf) {
			ret = _chk_as_name_sub(leaf->rightleaf);
		}
	}
	return ret;
}

/********************************************/
/*											*/
/********************************************/
static int _chk_as_name(leaf)
Leaf  *leaf;
{
	int ret;

	memset(stack_as_name,0,sizeof(stack_as_name));
	const_ct = cl_const_ct_new();
	if (const_ct) {
		ret = _chk_as_name_sub(leaf);
		akxm_cct_free(const_ct);
	}
	else ret = ECL_MALLOC_ERROR;
	return ret;
}

/********************************************/
/*											*/
/********************************************/
void _set_nodeLevel(leaf,level)
Leaf  *leaf;
int   level;
{
	if (leaf) {
		leaf->type = level;
		if (leaf->leftleaf) {
			_set_nodeLevel(leaf->leftleaf,level+1);
		}
 		if (leaf->rightleaf) {
			_set_nodeLevel(leaf->rightleaf,level);
		}
	}
}

/********************************************/
/*											*/
/********************************************/
int col_mn_tr_file_end(y)
condList *y;
{
	Leaf  *leaf;
	int ret;

	if (y->clstcb->nestLev1) {
		/* %s: �d�m�c�o�q�n�b�܂��͂d�m�c�e�t�m�b���ݒ肳��܂���ł����B */
		ERROROUT1(FORMAT(36),"col_mn_tr_file_end");
		return ( ECL_LEX );
	}
	if (!y->clstcb->TopStack) {
		/* col_mn_tr_file_end: �L���ȕ�������܂���B */
		ERROROUT(FORMAT(37));
		return ( ECL_LEX );
	}
/*
	if (ProcIndex) akxs_xhash_free(ProcIndex);
	ProcIndex = akxs_xhash_new2(0,10,7,sizeof(Leaf *));
*/
	_set_nodeLevel(leaf=search_top_leaf(y),0);
	ret = _chk_as_name(leaf);
	return ret;
}
