/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akaconst.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKACOMMON_H
#define _AKACOMMON_H

#include "akbcommon.h"
#include "aka.h"

#endif	/* _AKACOMMON_H */
