/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akb.h															*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKB_H
#define _AKB_H

#include "akbconst.h"
#include "akberror.h"
#include "akbstruct.h"
#include "akbmacro.h"
#include "akbprot.h"

#endif	/* _AKB_H */
