/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akxlib.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.5.28						*/
/*																		*/
/************************************************************************/
#ifndef _AKXLIB_H
#define _AKXLIB_H

typedef struct _SSP_S {
	int  sp;
	char *wd;
	uchar attr[4];
} SSP_S;

typedef struct _SSPL_S {
	int  sp;
	char *wd;
	uchar attr[4];
	short wdmax;
	uchar code;
	uchar resv;
} SSPL_S;

int akxtgwsp(/*buf, ssp*/);
int akxtgwnsl(/*buf, len, sspl, sep, opt*/);
int akxtgwns(/*buf, len, ssp, sep, opt*/);
int akxtgwse(/*buf, ssp, sep, opt*/);
int akxtpknsl(/*s, slen, ssp, sep, opt*/);
int akxtpkns(/*s, slen, ssp, sep, opt*/);
extern int akxafxdmp();
extern int akxaxdump();

#if 1	/* 2020.3.30 <-- cllocal.h */
typedef struct ParList {		/*** �p�����[�^���X�g ***/
	int  parlen;
	char *par;
} ParList;
#endif

typedef struct {
	int ac_opt;
	char *(*ac_malloc)();
	tdtCONSTCT *ac_constct;
	char *ac_aux;
} tdtAllocCtl;

/*****************************************
	�n�b�V���Ǘ�
*****************************************/
/* #define AKX_HASX_OPT_NO_USE_ALL	1	*/
#define AKX_HASX_OPT_NO_NEXT	2
#define AKX_HASX_OPT_CASE_KEY	4
#define AKX_HASX_OPT_USE_MALLOC	8
#define AKX_HASX_OPT_TMP_MALLOC	0x10
#define AKX_HASX_OPT_RESET_MEM	0x20
#define AKX_HASX_ID_NO_USE_ALL	'U'
#define AKX_HASX_ID_NO_NEXT		'N'
#define AKX_HASX_MULTIPLIER1	31
#define AKX_HASX_MULTIPLIER2	37

typedef struct {
	char	ha_id[2];
	short	ha_keylen;
	int 	ha_maxreg;
	int 	ha_prereg;
	char	*ha_reg;
	int 	*ha_next;
	char	*ha_key;
	int 	ha_aux;
	int 	ha_hix;
} HASHB;

HASHB *akxs_hasx_new2();	/* (short xha_keylen,long xha_maxreg,long xha_prereg,int iOpt);	*/
HASHB *akxs_hasx_new();		/* (short xha_keylen,long xha_maxreg,long xha_prereg);	*/
int akxs_hasx_free();		/* (HASHB *tph);	*/
int akxs_hasx_pre_reg();	/* (long xha_maxreg);	*/

HASHB *akxs_seqs_new();	/* (sKeyLen,lMaxReg)	*/

typedef struct {
	long hc_flag;
	long hc_hkey;
	long hc_next;
	int  *hc_datp;
} tdtHaslCell;

typedef struct {
	long hc_flag;
	long hc_hkey;
	long hc_next;
	int  *hc_datp;
	ulong hc_akey[4];
} tdtHaslCell4;

HASHB *akxs_hasl_new();	/* (short xha_keylen,long xha_maxreg,long xha_prereg);	*/
int  akxs_hasl_free();	/* (HASHB *tph);	*/

HASHB *akxs_hasl2_new();	/* (short xha_keylen,long xha_maxreg,long xha_prereg);	*/
int  akxs_hasl2_free();	/* (HASHB *tph);	*/

HASHB *akxs_hasl_new2();	/* (short xha_keylen,long xha_maxreg,long xha_prereg,int iOpt);	*/
HASHB *akxs_hasl2_new2();	/* (short xha_keylen,long xha_maxreg,long xha_prereg,int iOpt);	*/

int akxshasli(/*hp*/);
int akxshasls(/*hp,key*/);
int akxshaslr(/*hp,key*/);
int akxshasld(/*hp,key*/);
int akxshaslk(/*hp,keyp*/);
int akxshasl2k(/*hp,key*/);
int akxshaslp(/*hp*/);
int akxshaslu(/*hp*/);
int akxs_hasl_free(/*tph*/);
int akxshasl(/*func,hp*/);

/*****************************************
	�����g���n�b�V���Ǘ�
*****************************************/
typedef struct XHASHB {
	char	xha_id[2];
	short	xha_keylen;
	int 	xha_maxreg;
	int 	xha_prereg;
	int 	xha_xhix;
	HASHB	*xha_hashb;
	struct XHASHB *xha_xhnext;
#if 1
	short	xha_datlen;
	short	xha_option;
#else
	int		xha_datlen;
#endif
	char	*xha_datreg;
	char    *(*xha_malloc)();
	tdtCONSTCT *xha_constct;
} XHASHB;

HASHB *akxs_hasxm_new2(/*sKeyLen,lMaxReg,lPreReg,iOpt,m_alloc,pConstCt*/);
extern XHASHB *akxs_xhash_new();	/* (xha_keylen,xha_maxreg,xha_prereg) */
extern XHASHB *akxs_xhash_init();	/* (xha_keylen,xha_maxreg,xha_prereg) */
int akxs_xhash_free(/*tpxhashb*/);
extern int     akxs_xhash();		/* (tp_xhashb,cCmd,cpKey) */
int akxs_dreg_proc(/*tpX,cCmd,i,cppDat*/);
extern XHASHB *akxs_xhashm_new2();	/* (xha_keylen,xha_maxreg,xha_prereg,xha_datlen,m_alloc,pConstCt) */
extern XHASHB *akxs_xhash_new2();	/* (xha_keylen,xha_maxreg,xha_prereg,xha_datlen) */
extern int     akxs_xhash2();		/* (tp_xhashb,cCmd,cpKey,cpDat) */
int akxs_xhash_reset(/*tpxhashb*/);

int akxshasl2(/*func,hp*/);
int akxs_xhasl(/*tpxhashb,cCmnd,key,ippDat*/);
int akxs_xhasl_free(/*tpxhashb*/);

/*****************************************
	Sequencal search
*****************************************/
HASHB *akxs_seqs_new();	/* (sKeyLen,lMaxReg) */
int   akxs_seqs_free();	/* (HASHB *tph);	*/

extern XHASHB *akxs_xseqs_new();	/* (sKeyLen,lMaxReg)	*/
extern XHASHB *akxs_xseqs_new2();	/* (sKeyLen,lMaxReg,lDatLen)	*/
int akxs_xseqs_free(/*tp_xseqsb*/);
int akxs_xseqs2(/*tp_xseqsb,cCmnd,cpKey,cppDat*/);
int akxs_xseqs(/*tp_xseqsb,cCmd,cpKey*/);
int akxs_seqr_ptr(/*ptra,max_ptra,ptr*/);
int akxs_seqr_str(/*stra,max_stra,str,opt*/);
int akxs_seqr_str_num(/*stra,max_stra,str,opt*/);
int akxs_seqr_str2(/*stra,max_stra,str,opt*/);
int akxs_iseq(/*ia,max_ia,val*/);
int akxs_ins_sseq(/*da,d_pos,max_da,s_val,size*/);
int akxs_ins_sseq_array(/*da,d_pos,max_da,sa,s_pos,n_sa,size,opt*/);
int akxs_ins_shseq(/*da,d_pos,max_da,s_val*/);
int akxs_ins_shseq_array(/*da,d_pos,max_da,sa,s_pos,n_sa,opt*/);

/*****************************************
	�G���A�����g��������A��
*****************************************/
typedef struct {
	char   mc_id[2];
	ushort mc_extlen;
	ushort mc_maxcnt;
	ushort mc_extcnt;
	int    mc_alclen;
	char  *mc_bufp;
	int    mc_ipos;
} MCAT;

typedef struct {
	char   mc_id[2];
	ushort mc_extlen;
	ushort mc_maxcnt;
	ushort mc_extcnt;
	int    mc_alclen;
	char  *mc_bufp;
	int    mc_ipos;
	char *(*mc_malloc)();
} MCAT2;

int akxtmcat(/*pM,s,len*/);
int akxtmset(/*pM,c,len*/);
int akxtmexp(/*pM,len*/);
int akxtmcatz(/*pM,s,len*/);
int akxtmcats(/*pM,s*/);
int akxtmcat2(/*pM,s,len*/);
int akxtmcats2(/*pM,s*/);
int akxtmcatz2(/*pM,s,len*/);

/*****************************************
	�����O�o�b�t�@�Ǘ�
*****************************************/
typedef struct tdtRbChain {
	struct tdtRbChain *rbc_next;
	char *rbc_buf;
} tdtRbChain;

typedef struct {
	int rb_bfsz;
	int rb_max;
	int rb_num;
	int rb_used;
	tdtRbChain *rb_raddr;
	tdtRbChain *rb_waddr;
	tdtRbChain *rb_wpriv;
	int rb_pos;
	tdtRbChain *rb_cur;
	char *(*rb_malloc)();
	tdtCONSTCT *rb_constct;
} tdtRbCtl;

extern tdtRbCtl *akxs_rb_new();
extern tdtRbCtl *akxs_rb_new2();
int akxs_rb_free(/*pCt*/);
extern char *akxs_rb_get();
extern char *akxs_rb_get_n();
extern char *akxs_rb_set_n();
extern char *akxs_rb_read(/*tdtRbCtl *,int*/);

tdtRbChain *akxs_xhasl_new(/*sKeyLen,lMaxReg,lPreReg,iOpt*/);
tdtRbChain *akxs_xhasl2_new();	/* (short sKeyLen,long lMaxReg,long lPreReg,int iOpt);	*/

tdtRbCtl *akxs_list_new();
tdtRbCtl *akxs_elist_new();
int akxs_rb_all_free(/*pCt*/);
int akxs_list_free(/*pCt,free_func*/);
int akxs_list_get(/*pCt,pp*/);
int akxs_rb_used(/*pCt*/);
char *akxs_rb_set_t(/*pCt, addr*/);

int akxs_stack_init(SSPL_S *stack,int max_stack);
SSPL_S *akxs_stack_new(int max_stack);
int akxs_stack_free(SSPL_S *stack);
int akxs_stack_push(SSPL_S *stack,char *val);
int akxs_stack_pop(SSPL_S *stack,char **val);
int akxs_stack_peek(SSPL_S *stack,char **val);
int akxs_statck_srch(SSPL_S *stack,char *val,int opt);

/*****************************************
	�L���[�Ǘ�
*****************************************/
#define QUE_PUT_TOP 	10	/* TOP�ɒǉ����� */
#define QUE_PUT_BOT 	11	/* BOTTOM�ɒǉ����� */
#define QUE_PUT_CUR		12	/* CURRENT�ɒǉ����� */
#define QUE_GET_TOP 	20	/* TOP������o�� */
#define QUE_GET_BOT 	21	/* BOTTOM������o�� */
#define QUE_GET_CUR 	22	/* CURRENT������o�� */
#define QUE_PEEK_TOP 	30	/* TOP�𒲂ׂ� */
#define QUE_PEEK_BOT 	31	/* BOTTOM�𒲂ׂ� */
#define QUE_PEEK_CUR 	32	/* CURRENT�𒲂ׂ� */
#define QUE_PEEK_NEXT	33	/* CURRENT�𒲂ׁACURRENT�����Ɉړ����� */
#define QUE_PEEK_PREV	34	/* CURRENT�𒲂ׁACURRENT��O�Ɉړ����� */
#define QUE_MOVE_PEEK_NEXT	35	/* CURRENT�����Ɉړ����ACURRENT�𒲂ׂ� */
#define QUE_MOVE_PEEK_PREV	36	/* CURRENT��O�Ɉړ����ACURRENT�𒲂ׂ� */
#define QUE_MOVE_TOP	40	/* TOP��CURRENT���ړ����� */
#define QUE_MOVE_BOT	41	/* BOTTOM��CURRENT���ړ����� */
#define QUE_MOVE_NEXT	43	/* ����CURRENT���ړ����� */
#define QUE_MOVE_PREV	44	/* �O��CURRENT���ړ����� */
#define QUE_MOVE_TOPP	45	/* TOP�̑O��CURRENT���ړ����� */
#define QUE_MOVE_BOTN	46	/* BOTTOM�̎���CURRENT���ړ����� */
#define QUE_GET 	QUE_GET_TOP
#define QUE_PUT 	QUE_PUT_BOT
#define QUE_PEEK	QUE_PEEK_TOP
#define QUE_MOVE	QUE_MOVE_NEXT

#define QUE_DFLT	99	/*  */
#define QUE_TOP 	100	/* TOP�𑀍삷�� */
#define QUE_BOT 	101	/* BOTTOM�𑀍삷�� */
#define QUE_CUR		102	/* CURRENT�𑀍삷�� */
#define QUE_AFT_NEXT	103	/* CURRENT�𑀍삵�ACURRENT�����Ɉړ����� */
#define QUE_AFT_PREV	104	/* CURRENT�𑀍삵�ACURRENT��O�Ɉړ����� */
#define QUE_NEXT	105	/* CURRENT�����Ɉړ����ACURRENT�� */
#define QUE_PREV	106	/* CURRENT��O�Ɉړ����ACURRENT�� */
#define QUE_TOP_PREV	107	/* TOP�̑O��CURRENT���ړ����� */
#define QUE_BOT_NEXT	108	/* BOTTOM�̎���CURRENT���ړ����� */
#if 1
typedef struct tdtQueChain {
	struct tdtQueChain *qc_next;
	struct tdtQueChain *qc_prev;
	char *qc_buf;
} tdtQueChain;

typedef struct {
	int qct_bfsz;
	int qct_max;
	int qct_num;
	int qct_used;
	tdtQueChain *qct_top;
	tdtQueChain *qct_bot;
	tdtQueChain *qct_cur;
	tdtQueChain *qct_fre;
} tdtQueCtl;
extern tdtQueCtl *akxs_que_init();
extern tdtQueCtl *akxs_que_new();
#else
typedef struct tdtQueChain {
	struct tdtQueChain *qc_next;
	struct tdtQueChain *qc_prev;
	char *qc_buf;
} tdtQueChain;

typedef struct {
	int qct_bfsz;
	int qct_max;
	int qct_num;
	int qct_used;	/* add 2000.6.10 Koba */
	tdtQueChain *qct_top;
	tdtQueChain *qct_bot;
	tdtQueChain *qct_cur;
	tdtQueChain *qct_fre;
} tdtQueCtl;
extern tdtQueCtl *akxs_que_init();
extern tdtQueCtl *akxs_que_new();
#endif
extern int akxs_que_get();
extern int akxs_que_put();
extern int akxs_que_free();

/*****************************************
	�L���b�V���Ǘ�
*****************************************/
#define AKX_CACHE_EXTENT	10
#define AKX_CACHE_FIXEDKEYL	0x01
#define AKX_CACHE_MEMCMP	0x02
#define AKX_CACHE_DATASAVE	0x04
#define AKX_CACHE_IGNCHKERR	0x08
#define AKX_CACHE_NOAUTOEXT	0x10
#define CACHE_EXTENT		AKX_CACHE_EXTENT
#if 1
typedef struct tdtCacheCtl {
	char *ca_key;
	char *ca_cmp1;
	char *ca_cmp2;
	char *ca_data;
	int   ca_cmpnext;
	int   ca_chktime;	/* Check time */
	struct timeval ca_tval;
	int   ca_locktime;	/* Lock to time */
} tdtCacheCtl;
#else
typedef struct tdtCacheCtl {
	char *ca_key;
	char *ca_cmp1;
	char *ca_cmp2;
	char *ca_data;
	int   ca_cmpnext;
	int   ca_chktime;	/* Check time */
	struct timeval ca_tval;
	int   ca_locktime;	/* Lock to time */
} tdtCacheCtl;
#endif
#if 1
typedef struct tdtListChain {
	struct tdtListChain *lc_next;
	struct tdtListChain *lc_prev;
	tdtCacheCtl *lc_cactl;
	int lc_count;
} tdtListChain;
#else
typedef struct tdtListChain {
	struct tdtListChain *lc_next;
	struct tdtListChain *lc_prev;
	tdtCacheCtl *lc_cactl;
	int lc_count;
} tdtListChain;
#endif
#if 1
typedef struct {
	ushort        ch_imax;
	ushort        ch_smax;
	uchar         ch_opt;
	uchar         ch_kind;
	short         ch_keylen;
	int           ch_cmplen;
	int           ch_cshlen;
	short         ch_interval;
	ushort        ch_entry;
	tdtCacheCtl  *ch_pentry;
	tdtCacheCtl  *ch_prls;
#ifdef CACHE_QUE
	tdtQueCtl    *ch_pque;
#else
#ifdef CACHE_XHAS
	XHASHB        *ch_pxhas;
    int           *ch_pchktime;
#else
#ifdef CACHE_LIST
	tdtListChain *ch_pltop;
	tdtListChain *ch_plbot;
	tdtListChain *ch_plprev;
#else
	tdtCacheCtl  **ch_ppcache;
	struct timeval ch_tctval;
#endif
#endif
#endif
} tdtCacheCtlHead;
#else
typedef struct {
	ushort        ch_imax;
	ushort        ch_smax;
	unsigned char ch_opt;
	unsigned char ch_kind;
	short         ch_keylen;
	int           ch_cmplen;
	int           ch_cshlen;
	short         ch_interval;
	ushort        ch_entry;
	tdtCacheCtl     *ch_pentry;
	tdtCacheCtl     *ch_prls;
#ifdef CACHE_QUE
	tdtQueCtl       *ch_pque;
#else
#ifdef CACHE_XHAS
	XHASHB        *ch_pxhas;
    int           *ch_pchktime;
#else
#ifdef CACHE_LIST
	tdtListChain    *ch_pltop;
	tdtListChain    *ch_plbot;
	tdtListChain    *ch_plprev;
#else
	tdtCacheCtl     **ch_ppcache;
	struct timeval ch_tctval;
#endif
#endif
#endif
} tdtCacheCtlHead;
#endif
#ifdef SUNOS
extern tdtCacheCtlHead *akxs_cache_new();	/*	(int);	*/
extern int akxs_cache_set();	/*	(tdtCacheCtlHead *,tdtCacheCtl *);	*/
extern int akxs_cache_chk();	/*	(tdtCacheCtlHead *,char *,tdtCacheCtl *);	*/
extern int akxs_cache_del();	/*	(tdtCacheCtlHead *,char *);	*/
extern int akxs_cache_free();	/*	(tdtCacheCtlHead *);	*/
#else
extern tdtCacheCtlHead *akxs_cache_new(int);
extern int akxs_cache_set(tdtCacheCtlHead *,tdtCacheCtl *);
extern int akxs_cache_chk(tdtCacheCtlHead *,char *,tdtCacheCtl *);
extern int akxs_cache_del(tdtCacheCtlHead *,char *);
extern int akxs_cache_free(tdtCacheCtlHead *);
#endif

extern tdtCacheCtlHead *akxs_cache_newList();	/*	(int);	*/
extern tdtCacheCtlHead *akxs_cache_newQue();	/*	(int);	*/
extern tdtCacheCtlHead *akxs_cache_newXHas();	/*	(int);	*/

/*****************************************
	�^�C�}�[�Ǘ�
*****************************************/
#define AKX_TIMER_UNUSED	0
#define AKX_TIMER_START		1
#define AKX_TIMER_STOP		2
#if 1
typedef struct tdtTimerCtl {
	uchar  tc_status;	/* 0/1/2=unused/start/stop */
	uchar  tc_resv2;
	uchar  tc_resv3;
	uchar  tc_resv4;
	int  (*tc_pfunc)();
	int    tc_tmrid;
	char  *tc_tmrname;
	int    tc_watime;
	char  *tc_parm;
	struct timeval tc_timeout;
	struct tdtTimerCtl *tc_tmrnext;
	int    tc_event;
} tdtTimerCtl;

typedef struct tdtTimerCtlHead {
	struct timeval th_tmbase;
	int            th_minwait;
	tdtTimerCtl   *th_ptimer;
	int            th_mwtext;
	struct timeval th_latest;
} tdtTimerCtlHead;
#else
typedef struct tdtTimerCtl {
	uchar  tc_status;	/* 0/1/2=unused/start/stop */
	uchar  tc_resv2;
	uchar  tc_resv3;
	uchar  tc_resv4;
	int    (*tc_pfunc)();
	int    tc_tmrid;
	char   *tc_tmrname;
	int    tc_watime;
	char   *tc_parm;
	struct timeval tc_timeout;
	struct tdtTimerCtl *tc_tmrnext;
	int    tc_event;
} tdtTimerCtl;

typedef struct tdtTimerCtlHead {
	struct timeval th_tmbase;
	int th_minwait;
	tdtTimerCtl *th_ptimer;
	int th_minwaitExt;
	struct timeval th_latest;
} tdtTimerCtlHead;
#endif

tdtTimerCtlHead *akxe_timer_new();
int akxe_timer_sub(/*ptvalo,ptvali,ptval2*/);

/************************
	���O�Ǘ�
*************************/
#define D_LOG_FLG_CHECK		-1
#define D_LOG_FLG_NONE		0
#define D_LOG_FLG_STDOUT	0x01
#define D_LOG_FLG_FILE		0x02
#define D_LOG_FLG_STDERR	0x04
#if 1	/* V6 */
#define D_LOG_FLG_SYSLOG	0x08
#define D_LOG_FLG_NO_SRC	0x10
#define D_LOG_FLG_NO_PROC	0x20
#define D_LOG_FLG_NO_TIME	0x40
#define D_LOG_FLG_PRIORITY	0x80
#else	/* V5 */
#define D_LOG_FLG_NO_SRC    0x08
#define D_LOG_FLG_NO_PROC   0x10
#define D_LOG_FLG_NO_TIME   0x20
#endif
#define D_LOG_FLG_LOG_CLEAR	0x0100
#define D_LOG_FLG_OUT_INFO	0x0200
#define D_LOG_FLG_CHK_PRI	0x0400
#define D_LOG_FLG_NOT_LF	0x1000
#define D_LOG_FLG_PUT_CR	0x2000
#define D_LOG_FLG_CNV_LF	0x4000	/* �o�̓��b�Z�[�W����LF��ϊ��ΏۂƂ��� */
#define D_LOG_FLG_STACK		0x8000
#define D_LOG_FLG_CD_OPT	0x1F000000
#define D_LOG_LEVEL_CHECK	-1

#define D_LOG_ROT_ROT_FILE	0x01
#define D_LOG_ROT_NO_HEAD	0x02
#define D_LOG_ROT_SIZE_LINE	0x04
#define D_LOG_ROT_NO_LINCR	0x08

#define AKX_LOG_EMERG		250
#define AKX_LOG_ALERT		210
#define AKX_LOG_CRIT		180
#define AKX_LOG_ERR			150
#define AKX_LOG_WARNING		120
#define AKX_LOG_NOTICE		90
#define AKX_LOG_INFO		60
#define AKX_LOG_DEBUG		30

#define AKX_NEWLINE_NOT_LF	0x01
#define AKX_NEWLINE_PUT_CR	0x02
#define AKX_NEWLINE_CNV_LF	0x04	/* �o�̓��b�Z�[�W����LF��ϊ��ΏۂƂ��� */

#define AKX_LOG_MAX_BITS	32

typedef struct {
	int  lgi_level;
	int  lgi_line;
	int  lgi_pri;
	char *lgi_file;
	char *lgi_format;
	char *lgi_a1;
	char *lgi_a2;
	char *lgi_a3;
	char *lgi_a4;
	char *lgi_a5;
} tdtLogInfo;

typedef struct tdtRotateCtl {
	int   rot_size_max;
	int   rot_size;
	int   rot_file_max;
	int   rot_file_no;
	int   rot_option;
	int   rot_check_point;
	int   rot_count;
} tdtRotateCtl;

typedef struct tdtLogFileLine {
	short  lfl_ope;
	ushort lfl_no;
	int    lfl_line[2];
	char   lfl_file_name[1];
} tdtLogFileLine;

typedef struct tdtLogCtl {
	int   log_flg;
	int   log_level;
	int   log_grp_mask;
	char *log_file;
	tdtRbCtl *rb_file;
	tdtRbCtl *rb_srch;
	tdtRotateCtl log_rot;
	char *log_file_path;
	XHASHB *log_info;
	int   log_priority;
	MCAT  *mcat_file;
	MCAT  *mcat_out;
	uchar log_lvll[AKX_LOG_MAX_BITS];
} tdtLogCtl;

typedef struct tdtLogCtlHead {
	int log_max;
	char *cur_dir;
	char *log_dir;
	char *proc_name;
	tdtLogCtl *log_ctl;
	tdtRbCtl *rb_ct_w;
	char *log_ecnv;
	int log_max_resv;
} tdtLogCtlHead;

extern int   akx_get_log_time(/* buf,len,format */);
extern char *akx_log_time();
extern tdtLogCtlHead *akxa_log_new(/* iMax */);
extern int   akxa_log_free(/* tlh */);
extern tdtLogCtl *akxa_log_get_ctl(/* tlh,i */);
extern int   akxa_log_out_level_main(/* tlh,log_no,level,file,line,format,a1,a2,a3,a4,a5 */);
extern int   akxa_log_flg(/* tlh,i,f */);
extern int   akxa_log_set_proc_name(/* tlh,cpName */);
extern char *akxa_log_get_proc_name(/* tlh */);
extern char *akxa_log_set_file_name(/* tlh, i, cpFile */);
extern char *akxa_log_set_dir(/* tlh,cpDir */);
extern int   akxa_log_level(/* tlh, i,level */);
extern char *akxa_rotate(/* tdtRotateCtl *rot,char *fname */);
extern char *akxa_log_file_path(/* tlh,log_no,opt */);
int akxa_log_set_parm2(/*tlh,argc_i,argv,nParm,iParm_i*/);
int akxa_log_set_parm(/*tlh,argc_i,argv,nParm,iParm_i*/);
int akxa_log_new_line(/*FILE *fp, int iFlg*/);
int akxa_log_free(tdtLogCtlHead *tlh);
int akxa_log_set_command_parm(/*tlh,nset,logno_set,opt_string,parm_string,iOption*/);
int akxa_line_count(/*file, opt*/);
int akxa_log_out_pri(/*cpPath,iLogFlg,cpProc,file,line,pri,format,a1,a2,a3,a4,a5*/);
int akxa_log_str_conv(/*iParm,n,argv0,argv,opt*/);
int akxa_log_printf_len(/*buf,max_len,format,argc,argv*/);
int akxa_log_priority(tdtLogCtlHead *tlh, int i, int priority);

/* akxlog.c */
int akx_print_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akx_error_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akx_debug_out_level(/*level,file,line,format,a1,a2,a3,a4,a5*/);
int akx_log_level(/*i,level*/);

/*****************************************
	Data Code Type
*****************************************/
#define CD_TYPE_SYSTEM	0
#define CD_TYPE_EUC		1
#define CD_TYPE_SJIS	2
#define CD_TYPE_JIS		3
#define CD_TYPE_EBCDIC	4
#define CD_TYPE_UTF8	5
#define CD_TYPE_UNICODE	6
#define CD_TYPE_EBCDIK	8
#define CD_TYPE_NARROW	0x101	/* 257 ���p */
#define CD_TYPE_WIDE	0x102	/* 258 �S�p */

#define CD_SJIS_H_STA1	0x20	/* Hankaku Start 1 */
#define CD_SJIS_H_END1	0x7e	/* Hankaku End   1 */
#define CD_SJIS_H_STA2	0xa1	/* Hankaku Start 2 */
#define CD_SJIS_H_END2	0xdf	/* Hankaku End   2 */

#define CD_SJIS_HK_STA	0xa1	/* ���p�J�i Start */
#define CD_SJIS_HK_END	0xdf	/* ���p�J�i End   */

#define CD_SJIS_Z_STA1	0xa1	/* Zenkaku Start 1 */
#define CD_SJIS_Z_END1	0xfe	/* Zenkaku End   1 */
#define CD_SJIS_Z_STA2	0xa1	/* Zenkaku Start 2 */
#define CD_SJIS_Z_END2	0xfe	/* Zenkaku End   2 */

#define CD_EUC_SS2		0x8e	/* Hankaku Kana */
#define CD_EUC_SS3		0x8f	/* G3 AREA      */
#define	CD_EUC_Z_BEGIN	0xa1	/* Zenkaku Start */
#define	CD_EUC_Z_END	0xfe	/* Zenkaku End */

#define CD_UTF8_HK_STA1	0xEFBDA1	/* ���p�J�i Start 1 */
#define CD_UTF8_HK_END1	0xEFBDBF	/* ���p�J�i End   1 */
#define CD_UTF8_HK_STA2	0xEFBE80	/* ���p�J�i Start 2 */
#define CD_UTF8_HK_END3	0xEFBE9F	/* ���p�J�i End   2 */

/* �X�N���v�g/����/�o�͂̓��{��R�[�h */
#define CD_USE_CODE_CONV	0x10000	/* use akxc_code_conv() */
#define CD_DFLT_SJIS	0x0000	/* S-JIS */
	/* �X�N���v�g */
#define CD_SCRIPT_MASK	0xFF0000	/* MASK */
#define CD_SCRIPT_SJIS	0x010000	/* S-JIS */
#define CD_SCRIPT_UTF8	0x050000	/* UTF-8 */
	/* ���̓f�[�^ */
#define CD_INPUT_MASK	0xFF00	/* MASK */
#define CD_INPUT_SJIS	0x0100	/* SJIS */
#define CD_INPUT_UTF8	0x0500	/* UTF-8 */
	/* �o�̓f�[�^ */
#define CD_OUTPUT_MASK	0x00FF	/* MASK */
#define CD_OUTPUT_SJIS	0x0001	/* SJIS */
#define CD_OUTPUT_UTF8	0x0005	/* UTF-8 */

typedef struct {
	int cc_type_s;
	int cc_type_d;
	int (*cc_qlen1)();
	int (*cc_qlen2)();
	int (*cc_func1)();
	int (*cc_func2)();
	int cc_opt[2];
	short cc_dlen[2];
} tdtCodeConv;

char akxctoank(char c);
int akxcstou81(/*sjis,utf8*/);
int akxcu8tos1(/*utf8,sjis*/);
int akxcstoj1(/*sjis,jis*/);
int akxcjtos1(/*jis,sjis*/);
int akxt_set_code_type(/*ucCodeType*/);
int akxt_get_code_type();
int akxc_set_utf8_file(/*file*/);
int akxctohan_type_opt(/*n, inc, outc, from_type, opt*/);
int akxctohan_opt(/*n, inc, outc, opt*/);
int akxctozen_type(/*n, inc, outc, from_type*/);
int akxctozen1_type(/*n, inc, outc, nn, from_type*/);
int akxctozen1_type_opt(/*n, inc, outc, nn, from_type, opt*/);
int akxctozen1(/*n, inc, outc, nn*/);
int akxqismbs(/*code_type,p*/);
int akxqismbs1(/*code_type,c1*/);
int akxqiskanji(/*p*/);
int akxc_sj_to_utf8(/*sjis,utf8c,ucs4*/);
int akxc_utf8_to_sj(/*utf8c,sjis,ucs4*/);
int akxcstou8(/*n, inc, outc*/);
int akxcu8tos(/*n, inc, outc*/);
int akxc_str_conv(/*pAns,tr_dtypea,tr_code,p1,len*/);
char *akxc_get_iconv_code(/*data_type*/);
int akxc_file_code_conv(/*pAns,p1,len,inout*/);
char *akxc_get_code_str();
int akxqmlen(/*s,slen*/);
char **akxc_get_code_str_addr();
int akxctohan(/*n, inc, outc*/);
int akxctozen(/*n, inc, outc*/);
int akxqkanjilen2(/*p,len*/);
int akxqkanjilen(/*p*/);
int akxqmbslen1(/*code_type,c1*/);
int akxqmbslen(/*code_type,p*/);
int akxqmbsnlen(/*code_type,p,len*/);
int akxqu8nlen(/*p_str, len*/);
int akxqu8len(/*c*/);
int akxcuppern(/*d,s,len*/);
int akxclowern(/*d,s,len*/);
int akxcuplwn(/*opt,d,s,len*/);
int akxcuplw(/*pd,ps,opt*/);
int akxqis_hankaku_kana(/*p,mlen*/);

/*****************************************
	Data Code Replace
*****************************************/
typedef struct {
	uint rr_scmp;
	uint rr_ecmp;
	uint rr_srep;
	int  rr_intval;
} tdtRepRange;

typedef struct {
	int rs_ext;
	XHASHB *rs_xh;
	int rs_max;
	char **rs_pprep;
	int rs_range_ext;
	int rs_range_max;
	int rs_range_used;
	tdtRepRange *rs_range;
	XHASHB *rs_rs_xh2;
	int rs_max2;
	char **rs_pprep2;
} tdtRepStr;

extern tdtRepStr *akxc_rep_str_new(/* char *tfile, int iExt */);
int akxc_rep_str(/*tpRep,opt,in_cod,out_cod*/);

/*****************************************
	Compile and Execute
*****************************************/
typedef struct {
	int ns_maxcolm;
	int ns_maxobj;
	int ns_maxda;
	int ns_maxstack;
	int ns_nobj;
	int *ns_obj;
	char **ns_da;
	int  *ns_dstk;
	int  *ns_stack;
} tdtStplSql;

extern tdtStplSql *akxs_stpl_sql_new(/* nparm,iParm */);
int akxcecvn(/*ppNS,expbuf,len,pnum*/);

/*********************************
		�f�[�^����
*********************************/
#define AKX_ZOK_CHAR	1		/* �����E����			*/
#define AKX_ZOK_BINA	2		/* �����E�Q�i��			*/
#define AKX_ZOK_LONG	2		/* �����E�Q�i��			*/
#define AKX_ZOK_FLOA	3		/* �����E��������		*/
#define AKX_ZOK_DECI	4		/* �����E�P�O�i��		*/
#define AKX_ZOK_BULK	5		/* �����EBULK�^			*/
#define AKX_ZOK_DATE	6		/* �����E���t�^			*/
#define AKX_ZOK_VARI	7		/* �����E�o���A���g�^	*/
#define AKX_ZOK_KANS	8		/* �����E�Ԑ�			*/
#define AKX_ZOK_DATA	0x80	/* �����E����			*/

#define AKX_DATA_MALLOC		0x80	/* malloc data		*/
#define AKX_DATA_LPOSDATA	0x40	/* data to lResv	*/

/*****************************************
	�ėp�f�[�^�\����
*****************************************/
typedef struct  {
	uchar   gd_id;		/* �f�[�^�h�c */
	uchar   gd_attr;	/* ����       */
	uchar   gd_scale;	/* ���x       */
	uchar   gd_code;	/* �R�[�h��� */
	int     gd_dlen;	/* �f�[�^��   */
	char   *gd_data;	/* �f�[�^     */
	int     gd_resv;
} tdtGeneralData;

/*****************************************
	message
*****************************************/
typedef struct {
	int   mm_msgno;
	char *mm_msg[3];
} tdtMessages;

typedef struct {
	short cmh_try;
	short cmh_langmax;
	int   cmh_no_max;
	tdtMessages *cmh_messages;
	tdtMessages **cmh_index;
	tdtRbChain *cmh_xhp;
} tdtConvMsgHead;

tdtConvMsgHead *akxc_conv_msg_new(/* tdtMessages *mesg */);
char *akxc_conv_msg(/* tdtMessages message[],int no,int kind */);

/*******************************
	read_line
********************************/
#define AKX_RECORD_BUFSIZE	256

/*****************************************
	getargv
*****************************************/
#define AKX_ARGV_TERM_IGE			0x01	/* '#'�ȍ~�𖳎����� */
#define AKX_ARGV_IGNR_EQU			0x02	/* �Q���[�h�ڂ��A'='�̂Ƃ��͖������� */
#define AKX_ARGV_DELM_COM			0x04	/* ','����؂�Ƃ��� */
#define AKX_ARGV_DELM_CLN1			0x08
#define AKX_ARGV_DELM_CLN			0x10
#define AKX_ARGV_QUOT_IPV6			0x20
#define AKX_ARGV_DELM_EQU			0x40
#define AKX_ARGV_COM_NOT_IGNR_EQU	0x80
#define AKX_GSFOPEN_CACHE_INVALID	0x0100
#define AKX_GSFOPEN_NO_CACHE		0x0200
#define AKX_GSSTPLX_CACHE_INVALID	0x0400
#define AKX_ARGV_NOT_CUT_QUOT		0x010000
#define AKX_ARGV_USE_ATTR2_SEP		0x020000
#define AKX_ARGV_FOR_CSV			0x040000
#define AKX_ARGV_USE_ICMP			0x100000
#define AKX_ARGV_USE_AKXICMP		0x200000
#define AKX_ARGV_NO_CASE_CMP		0x400000

/*****************************************
	Virtual Area Access
*****************************************/
typedef struct _VAA_S {
	int     opt;
	FILE   *fp;
	SSP_S  *ssp;
	char   *buf;
	size_t  fsize;
} VAA_S;

/*****************************************
	Like
*****************************************/
typedef struct {
	uchar stp;
	uchar len;
	uchar mpn;
	uchar und;
} tdtLikeMask;

typedef struct {
	short lmc_nptn;
	short lmc_slptn;
#if 1	/* 2020.11.08 */
	short lmc_pat_n;
	short lmc_resv;
	int *lmc_pat;
#else
	ushort *lmc_pat;
#endif
	tdtLikeMask *lmc_mask;
} tdtLikeMaskCtl;

typedef struct {
	short lk_max_pat;
	uchar lk_escape;
	char  lk_pad;
	int   lk_option;
#if 1	/* 2020.11.08 */
	int *lk_usap;
#else
	ushort *lk_usap;
#endif
	int   lk_alen;
	int   lk_la;
	tdtLikeMaskCtl *lk_maskctl;
	short lk_nlike;
	short lk_next_like;
	int   *lk_pos;
} tdtLike;

extern tdtLike *akxs_xlike_new(/* int max_pat,option */);
int akxs_like_escape(/*escape*/);
int akxs_xlike_set_line(/*plike,s,len*/);
int akxs_pxlike(/*plike,bp,lbp*/);
int akxs_str_like(/*ap,bp*/);
int akxs_xlike_pos(/*ap,lap,bp,lbp,opt,pos*/);
int akxs_xlike(/*ap,lap,bp,lbp,opt*/);

/*****************************************
	Free & Used Chain List
*****************************************/
typedef struct {
	int uc_entry_size;
	int uc_used_top;
	int uc_used_bot;
	int *uc_uchain;
} tdtUChain;

/*****************************************
	GetSectionStruct
*****************************************/
typedef struct keyInfo {
	int   argc;
	char **argv;
	int  *arglen;
	int   resv;
} tdtKeyInfo;

typedef struct {
	int          maxkey;
	int          nkey;
	tdtKeyInfo **pkeyinfo;
} tdtKeyInfos;

/*****************************************
	MPA
*****************************************/
/* �P�O�i����(�Œ�)�����_���̂O�\��	*/
#define	AKX_MPA_NODISP_SYO_NOSYO	0x00	/* �����_�ȉ����Ȃ��Ƃ��ɏ����_�ȉ���\�����Ȃ��B	*/
#define AKX_MPA_NODISP_ZERO_LESS1	0x01	/* �P�����̂Ƃ��ɍŏ��̂O��\�����Ȃ��B			*/
#define	AKX_MPA_DISP_PIRIOD_NOSYO	0x02	/* �����_�ȉ����Ȃ��Ƃ��ɏ����_��\������B		*/
#define	AKX_MPA_DISP_SYOZERO_NOSYO	0x04	/* �����_�ȉ����Ȃ��Ƃ��ɏ�����P�ʂ̂O��\������B*/
#define	AKX_MPA_DISP_COMMA			0x20	/* �R�����ɃJ���}��t����B						*/

/* �P�O�i�Œ菬���_���̈ʎ�薢���̏���	*/
#define	AKX_MPA_4SHA5NYU	0x00	/* �l�̌ܓ�	*/
#define	AKX_MPA_KIRIAGE		0x01	/* �؎̂�	*/
#define	AKX_MPA_KIRISUTE	0x02	/* �؏グ	*/

#define	AKX_MPA_IGNO_SCALE	0x1000	/* M_PACK��SCALE�𖳎�����	*/
/*
		NMPA1 = NMPA + 1
		NMPA2 = NMPA1 * 2
		NMPA_INT = (NMPA1+12)/4
*/
/*
#define		NMPA10		51
#define		NMPA101		52
#define		NMPA102		104
#define		NMPA_INT10	16
*/
#define		NMPA10		54
#define		RADIX10		10
#define		RADIX10_2	5		/* = RADIX / 2 */
#define		RADIX102	100		/* = RADIX ^ 2 */
#define		NMPA		27
#define		NMPA1		28
#define		NMPA2		56
#define		NMPA_INT	10		/* 10-->11 2020.10.17 */

#define		RADIXBITS	15
#define		RADIX		100
#define		RADIX_2		50		/* = RADIX / 2 */
#define		RADIX2		10000	/* = RADIX ^ 2 */
#define		MAXEXP		32767
#define		MINEXP		-32768
/* 2020.5.24
#define		MAX_LONG	0x7FFFFFFFL
#define		MIN_LONG	0x80000000L
*/
#define		MAXDOUBLE	 1.7976931348623157e+308	/* IEEE double */
#define		MINDOUBLE	-1.7976931348623157e+308
#define		MINSTDDBL	 2.2250738585072014e-308	/* ���̍ŏ��̐��K���� */
#define		MAX_K		180				/* < (sqrt(4 * RADIX + 1) - 1) * 0.5 */
#define		MPA_ME_STR	"2.71828182845904523536028747135266249775724709369995957"
#define		MPA_PI_STR	"3.14159265358979323846264338327950288419716939937510582"
#define		MPA_LOG2_STR	"0.693147180559945309417073593429861981358439123924200345"
#define		MPA_LOG10_STR	"2.302585092994045684017515870599420447449918457320608157"
#define		MPA_1DLOG10_STR	"0.434294481903251827651218619637938040445973309092839801"
#define		MPA_UINT_MAX_STR	"4294967295"
#if defined(_LP64)
#define		MPA_ULONG_MAX_STR	"18446744073709551615"
#else
#define		MPA_ULONG_MAX_STR	"4294967295"
#endif

#define     MPA_ERR_NULL_ADDR	-1
#define     MPA_ERR_MALLOC		-2
#define     MPA_ERR_ZERODIVIDE	-10
#define     MPA_ERR_OVERFLOW	 11
#define     MPA_ERR_UNDERFLOW	-12
#define     MPA_ERR_A_LT_B		-13
#define     MPA_ERR_SIZE_OVER	-14
#define     MPA_ERR_INVALID		-15
#define     MPA_ERR_OVERFLOW_I	-16

#define MPA_DATA_MALLOC		0x80		/* malloc data        */
/*
#define     m_i2mpa	m_l2mpa
*/
typedef struct {
	char   id[2];	/* MP */
	short  opt;
	ushort alen;
	ushort len;
	short exp;
	char sign;
	char zero;
	char num[NMPA1];
} MPA;	/* int[NMPA_INT] */

typedef struct {
	int exp;
	ushort len;
	char sign;
	char zero;
	char num[NMPA2];
} MPA10W;

int m_set_a(MPA *a, char *s);
int m_set_an(MPA *a, char *s, int len);
MPA *m_pset_a(MPA *a, char *s);
MPA *m_pset_an(MPA *a, char *s, int len);
int m_10to100(MPA *a, MPA10W *w);
int m_100to10(MPA *a, MPA10W *w);
int m_normalize(MPA *a);
int m_chk_over_under(MPA *a, int exp);
int m_add(MPA *c, MPA *a, MPA *b);
int m_sub(MPA *c, MPA *a, MPA *b);
int m_add_a(MPA *ans, MPA *a, MPA *b);
int m_sub_a(MPA *ans, MPA *a, MPA *b);
int m_add1(MPA *a, MPA *b);
int m_sub1(MPA *a, MPA *b);
int m_add1_a(MPA *a, MPA *b);
int m_sub1_a(MPA *a, MPA *b);
int m_mul(MPA *ans, MPA *a, MPA *b);
int m_mul1(MPA *a, MPA *b);
int m_div(MPA *ans, MPA *aa, MPA *bb);
int m_div1(MPA *a, MPA *b);
int m_cmp(MPA *a, MPA *b);
int m_cmp_a(MPA *aa, MPA *bb);
void m_print(char *s, MPA *a, int _short);
void m10w_print(char *s, MPA10W *a, int _short);
MPA *m_get_i(int i);
MPA *m_get_mmax();
int m_pack(char *a, int precision, int scale, int opt, MPA *b);
int m_pack_size(char *a, int dec_size, MPA *b);
int m_unpack(MPA *a, char *b, int size, int scale);
int m_mpa2i(MPA *a, int *val);
int m_mpa2l(MPA *a, long *val);
int m_mpa2d(MPA *a, double *dval);
int m_dset(double *dval, MPA *a);
int m_mpa2an(MPA *a, char *s, int len_s, int opt);
int m_i2mpa(int val, MPA *a);
int m_l2mpa(long val, MPA *a);
int m_ll2mpa(off_t val, MPA *a);
int m_d2mpa(double a, MPA *m);
int m_scale(MPA *mpa,int precision,int scale,int opt);
int m_precision(MPA *a, int pre, int opt);
MPA *m_cpy(MPA *d,MPA *s,int iCPY);
char *m_mpa2str(MPA *a, char *s, int len_s, int opt);
char *m_mpa2str_exp(MPA *a, int pre, int inx, int opt);
int m_mpa2an_exp(MPA *a, char *s, int len_s, int pre, int inx, int opt);
int m_an_to_mpa10_opt(MPA10W *w, char *s, int len_s, int opt);
int m_precision_10(MPA10W *w10, int pre, int opt);
int m_mpa10_to_exp(MPA10W *w10, char *s, int len_s, int pre, int inx, int opt);
int m_mpa10_to_an(MPA10W *w, char *s, int len_s, int opt);
int m_set_array(MPA *a_ary, MPA *val, int n);
int m_mod(MPA *ans, MPA *aa, MPA *bb);
int m_ln(MPA *xx, MPA *b);
int m_ln_sub(MPA *xx, MPA *b);

/*****************************************
	���l�ϊ�
*****************************************/
#define  AKX_CNVN_OPT_NOT_NUM	0x0010			/*   */
#define  AKX_CNVN_OPT_COMMA		0x0020			/*   */
#define  AKX_CNVN_OPT_MSIGN		0x0040			/*   */
#define  AKX_CNVN_OPT_DIGIT		0x4000			/*   */
#define  AKX_CNVN_OPT_DOUBLE	0x8000			/*   */

/*****************************************
	Etc
*****************************************/
#define AKX_NULL_PRINT	"(null)"

/* These function names are used on Windows and perhaps other systems.  */
#ifndef SUNOS
#ifndef strcmpi
#define strcmpi strcasecmp
#endif
#ifndef stricmp
#define stricmp strcasecmp
#endif
#ifndef strncmpi
#define strncmpi strncasecmp
#endif
#ifndef strnicmp
#define strnicmp strncasecmp
#endif
#endif

/***************************
	prot type
************************/
/* akxlib.c */
int memicmp(/*sa,sb,len*/);
int memncpy(/*d, s, len, n*/);
int memzcpy(/*d, s, len*/);
int memnzcpy(/*d, s, len, n*/);
int memcat(/*d, s, len*/);
#if !defined(SUNOS5) && !defined(SUNOS) && !defined(LINUX)
int stricmp(/*sa,sb*/);
#endif
#if defined(SUNOS) || defined(AIX)
char *strerror(/*err*/);
#endif
char *strnzcpy(/* char *d, char *s, int n */);
int akxmemwork(/*len,pp1,pp0,work,w_len*/);
char *stristr(/* char *target,char *str */);
char *strmem(/* char *s,int len */);
char *memaddv0(/*argc,argv,argl,pp0*/);
char *memaddv(/*argc,argv,argl*/);
char *memadd0(/* a,alen,b,blen,pp0 */);
char *memadd(/* a,alen,b,blen */);
char *straddv(/*argc,argv */);
char *stradd(/* a,b */);
char *stradd5(/* a,b,c,d,e */);
int akxstrnlen(/*s,len*/);
char akxcupper(/* char ci */);
int akxqupper(/*cc*/);
int akxcctox(/*puc,len,pux*/);
int akxtsrepc(/*s,cs,cd*/);
char *akxt_get_last_name(/* char *delm, char *path */);
int akxcxtoc(/*s,len,d*/);
char *akxt_add_dir2(/* char *cpDir, char *cpFile, char **cppPath */);
int akxt_set_bits(/*ipBits,iMask,iSet*/);
int akxs_in_mem_opt(/*target,ltar,str,lstr,opt*/);
int akxs_in_str_opt(/*target,str,opt*/);
int instrchar(/*target,c*/);
int inistr(/*target,str*/);
char *stristr(/*target,str*/);
int akxt_get_gep_data(/*klen,p,kpp,plalen*/);
int akxt_cmp_gep_data_opt(/*klen,kp,lklen,p,opt*/);
int akxt_cmp_gep_data(/*klen,kp,lklen,p*/);
char *akxc_conv_msg(/* tdtMessages message[],int no,int kind */);
int akx_get_gen_int_data(/*p*/);
UINT4 akxcmb2ul(/*s,len*/);
int akxcul2mb(/*s,ul*/);
int akxmbcmp(/*s1,m1,s2,m2*/);
int akxmbncmp_opt(/*pstr1,nstr1,pstr2,nstr2,opt*/);
int akxstrcmp(/*s1,s2*/);
int akxstricmp(/*s1,s2*/);
int akxmemcmp(/*s1,s2,len*/);
int akxmemicmp(/*s1,s2,len*/);
int akxmemcmp2(/*s1,len1,s2,len2*/);
int akxmemicmp2(/*s1,len1,s2,len2*/);
int akxstrcmp2(/*s1,len1,s2,len2*/);
int akxstricmp2(/*s1,len1,s2,len2*/);
int akx_mem_chr_opt(/*pm1,pm2,len,opt*/);
int akx_skip_opt(/*buf,len,ptn,opt*/);
int akxnskipin(/*buf,len,ptn*/);
int akxnrskipin(/*buf,len,ptn*/);
int akxnskipto(/*buf,len,ptn*/);
int akxnrskipto(/*buf,len,ptn*/);
int akx_conv_yen1(/*s,len,ssp*/);
int akxtstrim(/*opt,pData,len,ptn*/);
int akxtstrim2(/*opt,pData,len,pa_dat,ptn*/);
int akxtsapb(/*opt,pData,len*/);
int akxttrim(/*opt,pData,len*/);
void  printtx();
int mem_set_int(/*a,val,n*/);
int mem_cpy_int(/*d,s,n*/);
int mem_set_addr(/*d,val,n*/);
int mem_cpy_addr(/*d,s,n*/);
int akxq_char_kind(/*s,s_len,opt*/);
char *nval(/*p,p1*/);
char *nval1(/*p*/);
int mem_cmp_int(/*p1,p2,n*/);
int mem_cmp_int_n(/*p1,n1,p2,n2*/);

/* akxgetstpl.c */
int akxtgetwnspl(/*p, len, sspl, opt*/);
int akxa_get_line(/*line,linemax,fp,opt*/);
int akxa_read_line_opt(/*buf, size, fp, opt*/);
int akxa_read_line(/*buf, size, fp*/);
int akxtgetw(/*p, ppos, wd, lmax*/);
int akxs_opt_strcmp(/*s1,s2,opt*/);
int akxtmgetline(/*cpMem, iMemLen, ssp*/);

FILE *akxa_gs_fopen(/* char *file,char *section,char **argv,int maxargc,
                  char *parm,int len,int opt,int pret[] */);
int akxtgetargvn2(/*buf,buflen,argv,maxargcs,parm,len,opt*/);
int akxtgetargvns2(/*buf,buflen,argv,maxargcs,parm,len,sep,opt*/);
int akxtgetargv2(/*buf,argv,maxargcs,parm,len,opt*/);
int akxtgetargv(/*buf,argv,maxargc,parm,len*/);
int akxwdmax_chkm(/*pwd,pattr,lmax,l,s,m*/);
int akxwdmax_chk(/*pwd,pattr,lmax,l,ch*/);

/* akxconvn.c */
int akxqsign(char *s, int len_s, int parm[], char *sep, int opt);
int akxccvl(/*rad,ss,len,pnum*/);
int akxccvd(/*ss,len,dpnum*/);
int akxcgcvl(/*wd0,len0,pnum*/);
int akxcgcvn(/*wd0,len0,pnum*/);
int akxccvx(/*wd0,len0,pnum*/);
int akxccvlx(/*wd0,len0,pnum*/);
int akxccvo(/*wd0,len0,pnum*/);
int akxccvlo(/*wd0,len0,pnum*/);
int akxccvb(/*wd0,len0,pnum*/);
int akxccvlb(/*wd0,len0,pnum*/);
int akxccvn(/*rad,ss,len,pnum*/);
int akxccvn2(/*rad,ss,len,pnum,ppos*/);
int akxcltoa(/*value,str,radix,str_len*/);
int akxcitoa(/*value,str,radix,str_len*/);
int akxtreverse(/*str,len*/);
int akxqnumber(/*buf,buf_len,opt,iParm*/);
int akxccvdotn(/*rad,ss,len,pnum*/);
char *itoa(/* int n */);

/* akxsregex.c */
int akxs_regex(char *regex,char *string,size_t nmatch,regmatch_t pmatch[],
               int flags[],size_t errbuf_size,char *errbuf);

/* akxgmath.c */
int akxg_sosu_tbl(/*pi*/);
int akxg_sosu_chk(/*l*/);

/***************************
	macro
************************/
#define X_MAX(a,b) ((a)>(b)?(a):(b))
#define X_MIN(a,b) ((a)<(b)?(a):(b))
#define X_DIFF(a,b) ((a)>(b)?(a)-(b):(b)-(a))
#define X_ABS(a) ((a)>=0?(a):-(a))
#define X_OFFSET(struc, field)	((int)&(((struc *)0)->field))
#define X_HTONL(x) ((x<<24)&0xff000000 | (x<<8)&0x00ff0000 |\
                    (x>>8)&0x0000ff00 | (x>>24)&0x000000ff)
#define X_HTONS(x) ((x<<8)&0xff00 | (x>>8)&0x00ff)
#define X_NTOHL(x) X_HTONL(x)
#define X_NTOHS(x) X_HTONS(x)

/***********************
	error
************************/
#define XA_ERR		-1000
#define XC_ERR		-1600
#define XE_ERR		-2200
#define XG_ERR		-2800
#define XJ_ERR		-3700
#define XM_ERR		-4600
#define XQ_ERR		-5800
#define XS_ERR		-6400
#define XT_ERR		-6700
#define XX_ERR		-7900

#endif	/* _AKXLIB_H */
