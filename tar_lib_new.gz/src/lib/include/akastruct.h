/*static char sccsid[]="%Z% %M% %I% %E% %U%";*/
/************************************************************************/
/*																		*/
/*		akastruct.h														*/
/*																		*/
/*			Coded by Akito Kobayashi	2010.6.18						*/
/*																		*/
/************************************************************************/
#ifndef _AKASTRUCT_H
#define _AKASTRUCT_H

/* ���b�Z�[�W����\ for aka */
typedef struct tdtMsgCtl {
	int     sd;
	INT4    host_id;
	int     proc;
	tdtTimerCtlHead *timer_ctl;
	int     send_msg_time_out;	/* �ԐM�҂����Ԃ̃f�t�H���g(�~���b) */ 
	int     send_msg_min_wait;	/* �~���b */ 
	int     get_msg_wait_time;	/* �~���b */ 
	struct timeval get_msg_time_out;
	short   wqsuspend;
	short   rqsuspend;
	uchar   shut_mode;
	uchar   shut_suspend;
	uchar   rsv1;				/* message read/write flag in GetMsg*/
	uchar   rsv2;				/* PRINTOUT LEVEL */
	char    *spool_dir;
	short   channel_max;
	short   channel_used;
	tdtRbCtl  *rb_rctl;
	tdtRbCtl  *rb_wctl;
	tdtRbCtl  *rb_wwctl;
	tdtQueCtl *que_rwctl;
	tdtRbCtl  *rb_dwctl;	/* add 2000.3.28 Koba */
	INT4    my_host_id;	/* add 2000.10.17 Koba */
	ushort  apsys_id;
	ushort  us_resv;
	ushort  us_proc;
	ushort  regist_dest_pid;
	int     msg_opt;
	tdtGeneralData *que_used_data;
	short   channel_akb_used;
	short   resv;
} tdtMsgCtl;

/* �C���X�^���X for aka */
typedef struct tdtInstance {
	uchar         used;
	uchar         kind;
	uchar         rsv3;
	uchar         rsv4;
	char          *instance_data;
	int           inst_time_out;
	char          *wait_next;
	tdtMsgCom     *recv_msg_com;
	tdtCommPackHead *pack_head;
	char          *to_free;
	tdtRbCtl      *rb_com_object;
	char          *comment;
	short         recv_packet_no;
	short         recv;
} tdtInstance;

/* �N���X����\ for aka */
typedef struct tdtClassCtl {
	int       (*func_name)();
	int       class_id;
	int       instance_data_size;
	int       max_thread;
	int       option;
	tdtInstance *instance;
	struct tdtClassCtl *class_next;
	int       packet_number;
	int       used_count;
	char      *class_name;
} tdtClassCtl;

/* �N���X�w�b�_ for aka */
typedef struct tdtClassCtlHead {
	int max_thread_total;
	int used_thread_total;
	tdtClassCtl *class;
} tdtClassCtlHead;

#endif	/* _AKASTRUCT_H */
