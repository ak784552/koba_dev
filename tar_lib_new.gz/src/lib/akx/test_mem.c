static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_mem.c libakx_no_iconv.a -o test_mem
*/
#include "akxcommon.h"
main()
{
	char *p;

	p = Malloc(1);
	printf("p=%08x \n",p);
	p = Malloc(480400);
	printf("p=%08x 480400\n",p);
	p = Malloc(1000000);	/* 1G byte */
	printf("p=%08x 1,000,000\n",p);
	p = Malloc(10000000);	/* 1G byte */
	printf("p=%08x 10,000,000\n",p);
	p = Malloc(100000000);	/* 1G byte */
	printf("p=%08x 100,000,000\n",p);
	p = Malloc(1000000000);	/* 1G byte */
	printf("p=%08x 1,000,000,000\n",p);
}
