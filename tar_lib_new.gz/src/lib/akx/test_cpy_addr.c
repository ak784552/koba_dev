static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_cpy_addr.c libakx_no_iconv.a -o test_cpy_addr
*/
#include "akxcommon.h"
main()
{
	char *a[3],*b[3];
	int i;

	for (i=0;i<3;i++) a[i] = (char *)&a[i];
	mem_cpy_addr(b,a,3);
	for (i=0;i<3;i++) printf("%08x %08x\n",a[i],b[i]);
}
