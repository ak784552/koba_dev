/*
	cc -DLINUX -I../include test_seinou.c libakx_no_iconv.a -o test_seinou
*/
#include <akxcommon.h>

char *aa[10000],buf[128];
HASHB *hp;
int main()
{
	FILE *fp;
	int i,k,n,t2,len,m,m0,mm,ih;
	char *argv[10],parm[128];
	tdtTimerCtlHead *pTC;
	struct timeval tval1,tval2,tvalf,tvalh,tvalx,tval3;

	hp = akxs_hasx_new(0,10000,0);
	pTC = akxe_timer_new();

	fp = fopen("/tmp/kakasi/kakasi-2.3.6/kakasidict","r");
	k = 0;
	for (i=0;i<10000;i++) {
		len = akxa_read_line(buf,sizeof(buf),fp);
		if (len < 0) break;
		if (*buf != ';') {
			n = akxtgetargv(buf,argv,2,parm,sizeof(parm));
			aa[k++] = Strdup(argv[0]);
			hp->ha_key = argv[0];
			akxshasx('S',hp);
		}
	}
	fclose(fp);

	for (;;) {
		printf("Enter kaisuu m: ");
		gets(buf);
		m0 = atoi(buf);
		if (m0 <= 0) break;
		printf("Enter kaisuu mm: ");
		gets(buf);
		mm = atoi(buf);
		if (mm <= 0) break;
		akxe_get_msec(pTC,&tval1);
		m = m0;
		while (m-- > 0) {
			for (i=0;i<mm;i++) {
				if (!strcmp(aa[i],"������")) break;
			}
		}
		akxe_get_msec(pTC,&tval2);
		t2 = akxe_timer_sub(&tvalf,&tval2,&tval1);
		printf("%5d.%06d\n",tvalf.tv_sec,tvalf.tv_usec);

		m = m0;
		while (m-- > 0) {
			hp->ha_key = "������";
			ih = akxshasx('R',hp);
		}
		printf("ih=%d\n",ih);
		akxe_get_msec(pTC,&tval3);
		t2 = akxe_timer_sub(&tvalh,&tval3,&tval2);
	
		printf("%5d.%06d\n",tval3.tv_sec,tval3.tv_usec);
		printf("%5d.%06d\n",tval2.tv_sec,tval2.tv_usec);
	
		printf("%5d.%06d\n",tvalh.tv_sec,tvalh.tv_usec);
	}
	exit(0);
}
