/*
	cc -DLINUX -O -I../include sosu.c akxcom.a -o sosu
*/
#include "akxcommon.h"
#define MAX_SOSU	100
main()
{
	char buf[20];
	int b,i,sosu[MAX_SOSU],k;
	int  max_sosu,*sosu_tbl,msosu,msosu2,i0,last,opt,max;

	printf("Entry check su ==> ");
	gets(buf);
	b=atoi(buf);
	printf("l=%d i=%d\n",b,akxg_sosu_chk(b));
	max_sosu = akxg_sosu_tbl(&sosu_tbl);
	memcpy(sosu,sosu_tbl,max_sosu*sizeof(int));

	printf("Entry opt(B/N=0/1) ==> ");
	gets(buf);
	opt=atoi(buf);
	last = 0;
	for (;;) {
		printf("Entry number ==> ");
		gets(buf);
		b=atoi(buf);
		if (b<1) break;
		max=b;
		msosu = sosu[max_sosu-1];
		msosu2 = msosu*msosu;
		if (last>0 && b>last) i0 = last + 2;
		else i0 = 3;
		for (i=i0;i<=max;i+=2) {
			if (akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i,opt)) {
				printf(" %d",i);
				if (max_sosu<MAX_SOSU && i>msosu) {
					sosu[max_sosu++] = msosu = i;
					msosu2 = msosu*msosu;
					printf("%s","+");
				}
				last = i;
				if (i > msosu2) {
					printf("%s","-");
					break;
				}
			}
		}
		printf("\nmax_sosu=%d\n",max_sosu);
	}

	printf("Entry debug flag ==> ");
	gets(buf);
	i=atoi(buf);
	XLOGFLG(X_LOG_NO_DEBUG,i);
/*
	for (;;) {
		printf("Entry debug number ==> ");
		gets(buf);
		b=atoi(buf);
		if (b<1) break;
*/
	for (i=1;i<=max;i+=2) {
		k = akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i,opt);
		printf("i=%d k=%d\n",i,k);
	}

	printf("akxg_sosu_set_tbl ret=%d\n",akxg_sosu_set_tbl(sosu,max_sosu));
	printf("Entry check su ==> ");
	gets(buf);
	b=atoi(buf);
	printf("l=%d i=%d\n",b,akxg_sosu_chk(b));
	printf("akxg_sosu_set_tbl ret=%d\n",akxg_sosu_set_tbl(NULL,0));
	printf("Entry check su ==> ");
	gets(buf);
	b=atoi(buf);
	printf("l=%d i=%d\n",b,akxg_sosu_chk(b));
}
