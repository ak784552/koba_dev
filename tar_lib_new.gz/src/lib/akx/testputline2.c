static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testputline2.c libakx_no_iconv.a -o testputline2
*/
#include <stdio.h>
int main(int argc,char *argv[])
{
	char line[256];
	int n,max,opt,ret;
	FILE *fpr,*fpw;

	fpr = fopen(argv[1],"r");
	if (fpr) {
		fpw = fopen("wwww2_log","a");
		if (fpw) {
			while ((n=akxa_get_line(line,256,fpr,2))>=0) {
				fprintf(fpw,"%s: %s\n",akx_log_time(),line);
			}
			fclose(fpw);
		}
		else printf("file [%s] open error!!\n","wwww2_log");
		fclose(fpr);
	}
	else printf("file [%s] open error!!\n",argv[1]);
	return 0;
}
