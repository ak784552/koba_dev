static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
cc -finput-charset=CP932 -g -DLINUX -I../include test_memicmp.c libakx_no_u8src.a -o test_memicmp

cc -finput-charset=CP932 -g -DLINUX -DUTF8_SRC -I../include test_memicmp.c libakx_no_iconv.a -o test_memicmp
*/
#include "akxcommon.h"
int main()
{
	char buf[256],*p,*pp;
	int len;

	p = "s-jis";
	pp= "S-JIS";
	len = akxcuppern(buf,p,strlen(p));
	printf("len=%d p=[%s] buf=[%s]\n",len,p,buf);
	printf("%d\n",memicmp(pp,p,len));
	printf("%d\n",stricmp(pp,p));
}
