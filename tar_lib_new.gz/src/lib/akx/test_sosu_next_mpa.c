static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_sosu_next_mpa.c libakx_no_iconv.a -o test_sosu_next_mpa
*/
#include "akxcommon.h"
main()
{
	static MPA *sm=NULL;
	char *p,buf[128];
	int i,ret,k,max_size_mpa;
	long *pl;
	MPA *m1,*m,mz,*sosu_mpa;

	m = get_tmpMPA(&sm,&mz);
	max_size_mpa = akxg_sosu_next_mpa_tbl(&sosu_mpa);
	for (i=0;i<212;i++) {
		if (i < 100) m1 = m_get_i(i);
		else {
			m_i2mpa(i,m);
			m1 = m;
		}
		ret = akxg_sosu_chk_mpa_by_tbl(sosu_mpa,max_size_mpa,m1);
		if (ret) printf("i=%d ret=%d\n",i,ret);
	}

	for (i=0;i<100;i++) {
		ret = akxg_sosu_next_mpa(-1,m);
		if (ret<0) break;
		m_mpa2an(m,buf,sizeof(buf),0);
		printf("i=%d ret=%d m=[%s]\n",i,ret,buf);
	}
}
