static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_trim.c libakx_no_u8src.a -o test_trim
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256],pat[256],*p,*p1,c;
	int n,opt,len,ret;
	SSP_S ssp;

	for (;;) {
		printf("Enter opt==>");
		gets(buf);
		opt=atoi(buf);
		if (opt < 0) break;
		printf("Enter string==>");
		gets(buf);
		ssp.sp = 0;
		memset(&ssp,0,sizeof(SSP_S));
		ssp.attr[0] = '\\';
		n = 0;
		len = strlen(buf);
		p1 = pat;
		while (ssp.sp<len) {
			akx_conv_yen1(buf,len,&ssp);
			*p1++ = ssp.attr[1];
			n++;
		}
		*p1 = '\0';
		len = n;
		printf("buf=[%s] len=%d\n",pat,len);
		printf("Enter len==>");
		gets(wd);
		len = atoi(wd);
	/*
		printf("Enter pat==>");
		gets(pat);
	*/
		p = akxttrim2(opt,pat,&len);
		p1 = buf;
		while(c=*p++) {
			if (c == '\t') {
				*p1++ = '\\';
				*p1++ = 't';
			}
			else *p1++ = c;
		}
		*p1 = '\0';
		printf("len=%d p=[%s]\n",len,buf);
	}
}
