static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DAIX -I../include testmb2ul.c akxcom.a -o testmb2ul
*/
#include "akxcommon.h"
main()
{
	char s1[256];
	UINT4 ul;

	for (;;) {
		printf("Enter mb ==>");
		gets(s1);
		printf("akxcmb2ul: ret=%08x\n",akxcmb2ul(s1,strlen(s1)));
	}

}
