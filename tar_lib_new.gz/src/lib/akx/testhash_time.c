static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -O -I../include testhash_time.c akxcom.a -o testhash_time
*/
#include "akxcommon.h"

	char buf[128];
	int  max,rc,i,j,t1,hmax,intval,opt,klen;
	char key[128],cmd[20],c,*form;
	tdtTimerCtlHead *pTC;
	struct timeval tval1,tval2,tvalx0,tvalx1,tvalx2;
	XHASHB *xha0,*xha1,*xha2;
	XHASHB *tpxh;

void _store(t)
int t;
{
		if (xha0) akxs_xhash_free(xha0);
		if (xha1) akxs_xhash_free(xha1);
		if (xha2) akxs_xhash_free(xha2);
		xha0 = akxs_xhash_new(klen,j,0);
		xha0->xha_id[0]='X';
		xha1 = akxs_xhash_new(klen,j,0);
		xha2 = akxs_xhash_new(klen,j,0);
		xha2->xha_id[0]='N';
		xha2->xha_prereg=akxs_hasx_pre_reg(j,1000);
		/*** xhas0 ***/
	if (t) akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,form,i);
			rc=akxs_xhash(xha0,'s',key);
		}
	if (t) {
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx0,&tval2,&tval1);
	}

		/*** xhas1 ***/
	if (t) akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,form,i);
			rc=akxs_xhash(xha1,'s',key);
		}
	if (t) {
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx1,&tval2,&tval1);
	}

		/*** xhas2 ***/
	if (t) akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,form,i);
			rc=akxs_xhash(xha2,'s',key);
		}
	if (t) {
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx2,&tval2,&tval1);
	}
}

int main()
{
	pTC = akxe_timer_new();
	printf("Enter hash max(>=8) : ");
	gets(buf);
	hmax=atoi(buf);
	printf("Enter key len : ");
	gets(buf);
	klen=atoi(buf);
	if (klen == 4) form="%04d";
	else if (klen == 8) form="%08d";
	else form="%d";
	xha0=xha1=xha2=NULL;

	printf("\nData Store\n");
	printf(" count(s)  normal       no_use_all   no_next\n");
	for (j=8;j<=hmax;) {
		_store(1);

		printf("%6d %5d.%06d %5d.%06d %5d.%06d\n",
		j,tvalx0.tv_sec,tvalx0.tv_usec,tvalx1.tv_sec,tvalx1.tv_usec,
		tvalx2.tv_sec,tvalx2.tv_usec);

		j *= 2;
	}

	printf("\nData Retriev\n");
	printf(" count(s)  normal       no_use_all   no_next\n");
	for (j=8;j<=hmax;) {
		_store(0);

		/*** xhas0 ***/
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,"%d",i);
			rc=akxs_xhash(xha0,'r',key);
		}
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx0,&tval2,&tval1);

		/*** xhas1 ***/
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,"%d",i);
			rc=akxs_xhash(xha1,'r',key);
		}
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx1,&tval2,&tval1);

		/*** xhas2 ***/
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,"%d",i);
			rc=akxs_xhash(xha2,'r',key);
		}
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx2,&tval2,&tval1);

		printf("%6d %5d.%06d %5d.%06d %5d.%06d\n",
		j,tvalx0.tv_sec,tvalx0.tv_usec,tvalx1.tv_sec,tvalx1.tv_usec,
		tvalx2.tv_sec,tvalx2.tv_usec);

		j *= 2;
	}

	printf("\nData Used\n");
	tpxh = xha0;
	rc=akxs_xhash(tpxh,'u',NULL);
	printf("tpxh0 used = %d, Pre = %d\n",rc,tpxh->xha_prereg);
	while (tpxh) {
		printf("tpxh0 = %08x, used = %d\n",tpxh,tpxh->xha_xhix);
		tpxh = tpxh->xha_xhnext;
	}
	tpxh = xha1;
	rc=akxs_xhash(tpxh,'u',NULL);
	printf("tpxh1 used = %d, Pre = %d\n",rc,tpxh->xha_prereg);
	while (tpxh) {
		printf("tpxh1 = %08x, used = %d\n",tpxh,tpxh->xha_xhix);
		tpxh = tpxh->xha_xhnext;
	}
	tpxh = xha2;
	rc=akxs_xhash(tpxh,'u',NULL);
	printf("tpxh2 used = %d, Pre = %d\n",rc,tpxh->xha_prereg);
	while (tpxh) {
		printf("tpxh2 = %08x, used = %d\n",tpxh,tpxh->xha_xhix);
		tpxh = tpxh->xha_xhnext;
	}

	printf("\nData delete\n");
	printf(" count(s)  normal       no_use_all   no_next\n");
	for (j=8;j<=hmax;) {
		_store(0);

		/*** xhas0 ***/
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,"%d",i);
			rc=akxs_xhash(xha0,'d',key);
		}
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx0,&tval2,&tval1);

		/*** xhas1 ***/
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,"%d",i);
			rc=akxs_xhash(xha1,'d',key);
		}
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx1,&tval2,&tval1);

		/*** xhas2 ***/
		akxe_getm_sec(pTC,&tval1);
		for (i=0;i<j;i++) {
			sprintf(key,"%d",i);
			rc=akxs_xhash(xha2,'d',key);
		}
		akxe_getm_sec(pTC,&tval2);
		t1 = akxe_timer_sub(&tvalx2,&tval2,&tval1);

		printf("%6d %5d.%06d %5d.%06d %5d.%06d\n",
		j,tvalx0.tv_sec,tvalx0.tv_usec,tvalx1.tv_sec,tvalx1.tv_usec,
		tvalx2.tv_sec,tvalx2.tv_usec);

		j *= 2;
	}

	printf("xhashFree 0:rc = %d\n",akxs_xhash_free(xha0));
	printf("xhashFree 1:rc = %d\n",akxs_xhash_free(xha1));
	printf("xhashFree 2:rc = %d\n",akxs_xhash_free(xha2));
	exit(0);
}
