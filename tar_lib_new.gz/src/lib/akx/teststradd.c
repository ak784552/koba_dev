static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include teststradd.c akxcom.a -o teststradd
*/
#include <stdio.h>
main()
{
	printf("stradd=[%s]\n",stradd("AA","BB"));
	printf("stradd=[%s]\n",stradd("AA",stradd("BB","CC")));
	printf("stradd=[%s]\n",stradd(stradd("AA","BB"),"CC"));
	printf("stradd=[%s]\n",stradd(stradd("AA","BB"),stradd("CC","DD")));
}
