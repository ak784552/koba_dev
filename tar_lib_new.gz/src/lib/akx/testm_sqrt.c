/*		mpa.c		Multiple-Precision Arithmetic	*/
/*
	cc -g -DLINUX -I../include testm_sqrt.c libakx.a -o testm_sqrt
*/
#include	"akxcommon.h"

int main(int argc, char *argv[])
{
	MPA x, w;
	int i,ret,n,pre,inx,opt;
	char line[128],*pa[10],*p,*argv2[5],parm[128];
#if 1
	for (;;) {
		printf("Enter number:");
		gets(line);
		p=line;
		if (*p=='/') break;
		n=akxtgetargv2(line,argv2,4,parm,sizeof(parm),0x04);
printf("n=%d\n",n);
		pre=30;
		inx=2;
		opt=0x0100;
		if (n>=2) {
printf("atgv2[1]=%s\n",argv2[1]);
			if (*(p=argv2[1])) pre=atoi(p);
		}
		if (n>=3) {
printf("atgv2[2]=%s\n",argv2[2]);
			if (*(p=argv2[2])) inx=atoi(p);
		}
		if (n>=4) {
printf("atgv2[3]=%s\n",argv2[3]);
			if (*(p=argv2[3])) akxcgcvn(p,strlen(p),&opt);
		}
		p=argv2[0];
#else
	pre=30;
	inx=2;
	opt=0x0100;
	pa[0] = "0.0";
	pa[1] = "1.0";
	pa[2] = "-1.0";
	pa[3] = "10";
	pa[4] = "100";
	pa[5] = "1000";
	for (i=0;i<6;i++) {
		p = pa[i];
#endif
		printf("m_set_a() %s\n",p);
		m_set_a(&w,p);
		ret= m_sqrt(&x, &w);
		m_print_exp("x=",&x,pre,inx,opt);
	}
	return 0;
}
