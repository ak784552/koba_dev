static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DAIX -I../include testcvd.c ../xcom/akxcom.a -lm -o testcvd
*/
#include "akxcommon.h"
main()
{
	char expbuf[256];
	int ret,num;
	double dVal;

	printf("sizeof(double)=%d\n",sizeof(double));
	for (;;) {
		printf("Enter ==>");
		gets(expbuf);
		if (!stricmp(expbuf,"/EOF")) break;
		ret = akxccvd(expbuf,strlen(expbuf),&dVal);
		printf("dVal=%f\n",dVal);
	}
}
