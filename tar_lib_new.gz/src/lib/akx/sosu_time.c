/*
	cc -DLINUX -O -I../include sosu_time.c akxcom.a -o sosu_time
*/
#include "akxcommon.h"
#define MAX_SOSU	1000
#define PR(x)	

main()
{
	char buf[20];
	int b,i,sosu[MAX_SOSU],k,j;
	int  max_sosu,*sosu_tbl,msosu,msosu2,i0,last,opt,max,max_size,count;
	tdtTimerCtlHead *pTC;
	struct timeval tval1,tval2,tvalH,tvalB,tvalHr,tvalBr;
	int t1;

	pTC = akxe_timer_new();
	max_size = max_sosu = akxg_sosu_tbl(&sosu_tbl);
	memcpy(sosu,sosu_tbl,max_sosu*sizeof(int));
	printf("Entry number ==> ");
	gets(buf);
	b=atoi(buf);
	printf("       max      count     B          H          Br         Hr\n");
	for (max=8;max<=b;max*=2) {
		for (j=0;j<2;j++) {
			akxe_getm_sec(pTC,&tval1);
			max_sosu = max_size;
			msosu = sosu[max_sosu-1];
			msosu2 = msosu*msosu;
			count = 0;
			for (i=1;i<=max;i+=2) {
				if (akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i,j) > 0) {
					count++;
					PR(printf(" %d",i);)
					if (max_sosu<MAX_SOSU && i>msosu) {
						sosu[max_sosu++] = msosu = i;
						msosu2 = msosu*msosu;
						PR(printf("%s","+");)
					}
					last = i;
					if (i > msosu2) {
						PR(printf("%s","-");)
						break;
					}
				}
			}
			PR(printf("\nj=%d max_size=%d max_sosu=%d count=%d\n",
				j,max_sosu,msosu,count);)
			akxe_getm_sec(pTC,&tval2);
			if (j) t1 = akxe_timer_sub(&tvalH,&tval2,&tval1);
			else t1 = akxe_timer_sub(&tvalB,&tval2,&tval1);
		}

		for (j=0;j<2;j++) {
			akxe_getm_sec(pTC,&tval1);
			count = 0;
			for (i=1;i<=max;i+=2) {
				if (akxg_sosu_chk_by_tbl_opt(sosu,max_sosu,i,j) > 0) count++;
			}
			PR(printf("j=%d count=%d\n",j,count);)
			akxe_getm_sec(pTC,&tval2);
			if (j) t1 = akxe_timer_sub(&tvalHr,&tval2,&tval1);
			else t1 = akxe_timer_sub(&tvalBr,&tval2,&tval1);
		}

		printf("%10d %10d %3d.%06d %3d.%06d %3d.%06d %3d.%06d\n",max,count,
			tvalB.tv_sec,tvalB.tv_usec,tvalH.tv_sec,tvalH.tv_usec,
			tvalBr.tv_sec,tvalBr.tv_usec,tvalHr.tv_sec,tvalHr.tv_usec);
	}
}
