static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*											*/
/*	  coded by A.Kobayashi 2010.05.10		*/
/*											*/
/********************************************/
#include "akxcommon.h"

/********************************************************/
/*														*/
/********************************************************/
int memicmp(sa,sb,len)
uchar *sa,*sb;
int len;
{
	uchar ca,cb;
	int i,dif;

	if (!sa || !sb) return -1;
	dif = 0;
	for (i=0;i<len;i++) {
		ca = *sa++;
		cb = *sb++;
		if (dif=akxcupper(ca)-akxcupper(cb)) break;
	}

	return dif;
}

/********************************************************/
/*	n_min<=0 �̂Ƃ��́Alen=n_max �̂Ƃ��ȊO�́A			*/
/*						��v���Ȃ��Ȃ�					*/
/*	n_max<0 or n_min>n_max �̂Ƃ��́A					*/
/*						�͈̓`�F�b�N���s��Ȃ�			*/
/*						mem[i]cmp(sa,sb,len)�Ɠ����ɂȂ�*/
/*	opt : 0x01 : �啶������������Ȃ�					*/
/********************************************************/
int memrngcmp_opt(sa,len,sb,n_min,n_max,opt)
uchar *sa,*sb;
int len,n_min,n_max,opt;
{
	int ret;

	if (!n_min) n_min = n_max;
	if (n_max>=0 && n_min<=n_max) {
		if (len < n_min) return -1;
		if (len > n_max) return 1;
	}
	if (opt & 0x01) ret = memicmp(sa,sb,len);
	else ret = memcmp(sa,sb,len);
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int memrngcmp(sa,len,sb,n_min,n_max)
uchar *sa,*sb;
int len,n_min,n_max;
{
	return memrngcmp_opt(sa,len,sb,n_min,n_max,0);
}

/********************************************************/
/*														*/
/********************************************************/
int memirngcmp(sa,len,sb,n_min,n_max)
uchar *sa,*sb;
int len,n_min,n_max;
{
	return  memrngcmp_opt(sa,len,sb,n_min,n_max,1);
}

/********************************************************/
/*														*/
/********************************************************/
int memncmp(sa,len,sb,n)
uchar *sa,*sb;
int len,n;
{
	return  memrngcmp_opt(sa,len,sb,0,n,0);
}

/********************************************************/
/*														*/
/********************************************************/
int memincmp(sa,len,sb,n)
uchar *sa,*sb;
int len,n;
{
	return  memrngcmp_opt(sa,len,sb,0,n,1);
}

/********************************************************/
/*														*/
/********************************************************/
int memrcpy(d0, s0, len)
char *d0,*s0;
int len;
{
	int i;
	char *d,*s;

	if (!d0) return -1;
	if (len>0 && s) {
		s = s0 + len -1;
		d = d0 + len -1;
		while (len-- > 0) *d-- = *s--;
	}
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memncpy(d, s, len, n)
char *d,*s;
int len,n;
{
	if (!d) return -1;
	if (n < len) len = n;
	if (len < 0) len = 0;
	if (len>0 && s) memcpy(d,s,len);
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memzcpy(d, s, len)
char *d,*s;
int len;
{
	if (!d) return -1;
	if (len < 0) len = 0;
	if (len>0 && s) memcpy(d,s,len);
	*(d+len) = '\0';
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memrzcpy(d, s, len)
char *d,*s;
int len;
{
	len = memrcpy(d,s,len);
	if (len >= 0) *(d+len) = '\0';
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memnzcpy(d, s, len, n)
char *d,*s;
int len,n;
{
	if (!d) return -1;
	n--;	/* 2021.8.22 n�͏I�[null�������܂ޒ��� */
	if (n < len) len = n;
	if (len < 0) len = 0;
	memzcpy(d,s,len);
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int memcat(d, s, len)
char *d,*s;
int len;
{
	if (!d) return -1;
	memzcpy(d+strlen(d),s,len);
	return len;
}

#if !defined(SUNOS5) && !defined(SUNOS) && !defined(LINUX)
/********************************************************/
/*														*/
/********************************************************/
int stricmp(sa,sb)
uchar *sa,*sb;
{
	uchar ca,cb;
	int d=0;

	if (!sa || !sb) return -1;
	for (;;) {
		ca = *sa++;
		cb = *sb++;
		if (!ca && !cb) break;
		if (d=akxcupper(ca)-akxcupper(cb)) break;
	}

	return d;
}
#endif

#if defined(SUNOS) || defined(AIX)
/********************************************************/
/*														*/
/********************************************************/
char *strerror(err)
int err;
{
	char *p;
	extern char *sys_errlist[];
	extern int  sys_nerr;

	if (err>=0 && err<sys_nerr) p = sys_errlist[err];
	else p = AKX_NULL_PRINT;
	return p;
}
#endif

/********************************************************/
/*														*/
/********************************************************/
char *strnzcpy(d, s, len)
char *d,*s;
int len;
{
	if (!d || !s) return NULL;
	if (len < 0) len = 0;
	*(d+len) = '\0';
	return strncpy(d,s,len);
}

/********************************************************/
/* �@�\ : target����str�Ɉ�v����ʒu��Ԃ�				*/
/* ���� : target  : �Ώە�����							*/
/*		  ltar	  : �Ώە����� (�o�C�g)				*/
/*		  str	  : ��v���镶����						*/
/*		  lstr	  : str�� (�o�C�g)						*/
/*		  occurs  : �J��Ԃ���	0�ȉ��́A1�ƌ��Ȃ�		*/
/*		  opt	  : �I�v�V����							*/
/*					0x01 : ignore case					*/
/*			0x20->	0x02 : �S�p���p�𖳎�����			*/
/*					0x08 : �擪�݂̂��r����			*/
/*			0x04->	0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*			0x02->	0x20 : reverse						*/
/*						   occurs�́C1�ƌ��Ȃ�			*/
/*					0x40 : ��v�s��v�𔽓]����			*/
/*			  0x7f000000 : �����R�[�h					*/
/* �ԋp : >=1 ��v�����ʒu�̐擪����̃o�C�g���܂���	*/
/*			  ������									*/
/********************************************************/
int akxs_ino_mem_opt(target,ltar,str,lstr,occurs,opt)
char *target,*str;
int  ltar,lstr,occurs,opt;
{
	char *pt,*ps,z1[5];
	int  i,k,n,opt01,opt02,opt04,opt08,pos,unmatch,opt40,occur;
	int  opt20,m,optw,nn[3],mtar,mstr,len,kk,mm,opt_type,code_type;

	if ((pt=target) && (ps=str)) {
		if (!ltar || !lstr) return 0;
/*
printf("akxs_in_mem_opt: ltar=%d pt=[%s] opt=%08x\n",ltar,pt,opt);
printf("                 lstr=%d ps=[%s]\n",lstr,ps);
*/
		opt01 = opt & 0x01;	/* ignore case */
		opt02 = opt & 0x20;	/* reverse */
		opt04 = opt & 0x10;	/* return moji position */
		opt08 = opt & 0x08;	/* compare top only */
		opt20 = opt & 0x02;	/* ignore zenkaku hankaku */
		opt40 = opt & 0x40;	/* compare except */
		optw = 0x04 | opt01 | opt20 | opt40;
		opt_type = opt & CD_TYPE_OPT_MASK;
		code_type = GET_TYPE_OPT(opt);
		optw |= opt_type;
		if (opt20) {
			mtar = akxctozen_type_opt(ltar,pt,0,code_type,opt_type);
			mstr = akxctozen_type_opt(lstr,ps,0,code_type,opt_type);
			if (opt08 && (mtar != mstr)) return 0;
		}
		else {
			if (opt08 && (ltar != lstr)) return 0;
			mstr = akxqmlen_type(ps,lstr,code_type);
			mtar = akxqmlen_type(pt,ltar,code_type);
		}
		n = mtar - mstr + 1;
/*		n = ltar - lstr + 1;	*/
		if (opt08 && n>1) n = 1;
/*
printf("akxs_in_mem_opt: n=%d opt=%04x optw=%04x\n",n,opt,optw);
*/
		if (occurs <= 0) occurs = 1;
		pos = occur = 0;
		len = ltar;
		i = kk = 1;
#if 1
		for (k=1;k<=n;k++) {
#else
		for (k=1,i=1;i<=n;i++,k++,pt++) {
#endif
/*
printf("akxs_in_mem_opt: k=%d i=%d kk=%d len=%d\n",k,i,kk,len);
*/
#if 1
			unmatch = akxmbncmp_type_opt(pt,len,ps,lstr,code_type,optw);
#else
			if (opt01) unmatch = akxmemicmp(pt,ps,lstr);	/* ignore case */
			else       unmatch = akxmemcmp(pt,ps,lstr);
#endif
			if (!unmatch) {
				occur++;
				if (opt04) {
					if (opt02) pos = kk;	/* reverse */
					else if (occur >= occurs) return kk;
				}
				else {
					if (opt02) pos = i;	/* reverse */
					else if (occur >= occurs) return i;
				}
			}
			mm = m = 1;
			if (opt20) {
				akxctozen1_type_opt(len,pt,0,nn,code_type,opt_type);
				m = nn[0];
				mm = nn[2];
/*
printf("akxs_in_mem_opt:opt20: m=%d mm=%d\n",m,mm);
*/
			}
			else if (k < n) {
			/*	m = akxqkanjilen(pt);	*/
				m = akxqmbsnlen(code_type,pt,len);
/*
printf("akxs_in_mem_opt: m=%d\n",m);
*/
			}
			len -= m;
			kk += mm;
			i  += m;
			pt += m;
		}
		return pos;
	}
	else return -1;
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_in_mem_opt(target,ltar,str,lstr,opt)
char *target,*str;
int  ltar,lstr,opt;
{
	return akxs_ino_mem_opt(target,ltar,str,lstr,1,opt);
}

/********************************************************/
/*														*/
/*					0x01 : ignore case					*/
/*					0x02 : �S�p���p�𖳎�����			*/
/*					0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*					0x20 : reverse						*/
/*			  0x7f000000 : code_type					*/
/********************************************************/
int akxs_in_mem_chars(target,ltar,str,opt)
char *target,*str;
int  ltar,opt;
{
#if 0
	int pos;

	pos = akx_skip_opt(target,ltar,str,opt | 0x08) + 1;
	if (pos > ltar) pos = 0;
	return pos;
#else	/* opt=0x02�𐶂�������akxs_in_mem_opt()���g�� */
	char w[5],*p;
	int lstr,m,code_type,pos,mpos,opt20,rpos,rmpos,ret;

	if (!target || !str) return -1;
	pos  = mpos  = 1;
	rpos = rmpos = 0;
	code_type = GET_TYPE_OPT(opt);
	opt20 = opt & 0x20;
	p = str;
	lstr = strlen(str);
	while (lstr > 0) {
		m = akxqmbsnlen(code_type,p,lstr);
		memzcpy(w,p,m);
		if (ret = akxs_in_mem_opt(target,ltar,w,m,opt)) {
			rpos = pos;
			rmpos = mpos ;
			if (!opt20) break;
		}
		lstr -= m;
		p += m;
		pos += m;
		mpos++;
	}
	if (opt & 0x10) rpos = rmpos;
	return rpos;
#endif
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_ino_str_opt(target,str,occurs,opt)
char *target,*str;
int occurs,opt;
{
	char *pt,*ps;

	if ((pt=target) && (ps=str))
		return akxs_ino_mem_opt(pt,strlen(pt),ps,strlen(ps),occurs,opt);
	else
		return -1;
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_in_str_opt(target,str,opt)
char *target,*str;
int opt;
{
	return akxs_ino_str_opt(target,str,1,opt);
}

/********************************************************/
/*														*/
/********************************************************/
int instr(target,str)
char *target,*str;
{
	return akxs_in_str_opt(target,str,0);
}

/********************************************************/
/*														*/
/********************************************************/
int inistr(target,str)
char *target,*str;
{
	return akxs_in_str_opt(target,str,1);
}

/********************************************************/
/*														*/
/********************************************************/
char *stristr(target,str)
char *target,*str;
{
	int i;

	if ((i=akxs_in_str_opt(target,str,1)) > 0) return target+i-1;
	return NULL;
}

/********************************************************/
/*														*/
/********************************************************/
int inmemstr(target,lt,str)
char *target,*str;
int lt;
{
	if (str)
		return akxs_in_mem_opt(target,lt,str,strlen(str),0);
	else
		return -1;
}

/********************************************************/
/*														*/
/********************************************************/
int instrchar_opt(target,c,opt)
char *target,c;
int opt;
{
	char str[2];
	int pos;

	if (!target) pos = -1;
	else if (*target && c) {
		str[0] = c;
		str[1] = '\0';
		pos = akxs_in_str_opt(target,str,opt & 0x01);
	}
	else pos = 0;
	return pos;
}

/********************************************************/
/*														*/
/********************************************************/
int instrchar(target,c)
char *target,c;
{
	return instrchar_opt(target,c,0);
}

/********************************************************/
/*														*/
/********************************************************/
int instrichar(target,c)
char *target,c;
{
	return instrchar_opt(target,c,1);
}

/********************************************************/
/*														*/
/********************************************************/
int inmemchars(buf,len,ptn)
char *buf,*ptn;
int  len;
{
#if 1
	return akxs_in_mem_chars(buf,len,ptn,0);
#else
	int pos;

	pos = akx_skip_opt(buf,len,ptn,0x08) + 1;
	if (pos > len) pos = 0;
	return pos;
#endif
}

/********************************************************/
/*														*/
/********************************************************/
int inmemichars(buf,len,ptn)
char *buf,*ptn;
int  len;
{
#if 1
	return akxs_in_mem_chars(buf,len,ptn,0x01);
#else
	int pos;

	pos = akx_skip_opt(buf,len,ptn,0x01 | 0x08) + 1;
	if (pos > len) pos = 0;
	return pos;
#endif
}

/********************************************************/
/*														*/
/********************************************************/
int instrchars(buf,ptn)
char *buf,*ptn;
{
	return inmemchars(buf,strlen(buf),ptn);
}

/********************************************************/
/*														*/
/********************************************************/
int instrichars(buf,ptn)
char *buf,*ptn;
{
	return inmemichars(buf,strlen(buf),ptn);
}

/********************************************************/
/*														*/
/********************************************************/
UINT4 akxcmb2ul(s,len)
uchar *s;
int  len;	/* >=1, <=4 */
{
	uchar *p=s;
	int n=len;
	UINT4 ul;

#if 1
	if (n <= 0) ul = 0;
	else {
		ul = *p++;
		if (n == 2) ul = ul<<8 | *p;
		else if (n == 3) ul = (ul<<8 | *p)<<8 | *(p+1);
		else if (n == 1) ;
		else ul = ((ul<<8 | *p)<<8 | *(p+1))<<8 | *(p+2);
	}
#else	/* ���[�v�̕����x�� */
	ul = 0;
	while (n-- > 0) {
		ul = ul<<8 | *p++;
	}
#endif
	return ul;
}

/********************************************************/
/*														*/
/********************************************************/
int akxcul2mb(s,ul)
uchar *s;
UINT4 ul;
{
	uchar *p=s,uc;
	int i,len;

	if (!s) return -1;
	len = 0;
	p = s + 4;
	for (i=0;i<4;i++) {
		uc = ul & 0x000000ff;
		if (uc) {
			*(--p) = uc;
			len++;
		}
		ul >>= 8;
	}
	if (len < 4) memcpy(s,p,len);
	*(s+len) = '\0';
	return len;
}

/********************************************************/
/*														*/
/********************************************************/
int akxmbcmp(s1,m1,s2,m2)
uchar *s1,*s2;
int m1,m2;
{
	return akxcmb2ul(s1,m1) - akxcmb2ul(s2,m2);
}

/********1*********2*********3*********4*********5*********6*********/
/*	�@�\ : ������ƕ�������r����									*/
/*	���� :	pstr1,nstr1,pstr2,nstr2									*/
/*			type  : �����R�[�h										*/
/*			opt   : 0x01 : ignore case								*/
/*					0x02 : ignore zenkaku hankaku					*/
/*					0x04 : �O����v(pstr2��pstr1�̑O���Ɉ�v���邩)	*/
/*					0x10 : ���g�p									*/
/*					0x20 : ���g�p									*/
/*					0x40 : compare except							*/
/*					0x80 : '\0'�������ƌ��Ȃ�						*/
/*				  0x0100 : �ǂ��炩�Z�����̑O����v					*/
/*	�ԋp :	> 0 : ��ꍀ > ���									*/
/*			= 0 : ��ꍀ = ���									*/
/*			< 0 : ��ꍀ < ���									*/
/********************************************************************/
int akxmbncmp_type_opt(pstr1,nstr1,pstr2,nstr2,type,opt)
uchar *pstr1,*pstr2;
int nstr1,nstr2,type,opt;
{
	uchar *s1,*s2,c1,c2;
	int len1,len2,m1,m2,opt01,opt02,opt04,opt10,dif,opt40,d,opt80,opt100;
	uchar u1[5],u2[5],z1[5],z2[5],uc,*p1,*p2;
	int n1,n2,nn[3];

	if (!(s1=pstr1) || !(s2=pstr2)) return -1;
/*
printtx("akxmbncmp_opt",pstr1,nstr1);
printtx("             ",pstr2,nstr2);
printf("             : type=%d opt=%04x\n",type,opt);
*/
	if (type <= 0) type = akxt_get_code_type();
	opt01 = opt & 0x01;	/* ignore case */
	opt02 = opt & 0x02;	/* ignore zenkaku hankaku */
	opt04 = opt & 0x04;	/* �O����v 0x04 <- 0x08 *//* pstr2��pstr1�̑O���Ɉ�v���邩 */
	opt40 = opt & 0x40;	/* compare except */
	opt80 = opt & 0x80;	/* '\0'�������ƌ��Ȃ� */
	opt100 = opt & 0x100;
	len1 = nstr1;
	len2 = nstr2;
	if (!len1 || !len2) {
		if (!len1 && !len2) dif = 0;
		else if (!len1) dif = -1;
		else if (!len2) dif =  1;
		if (opt40) {
			if (dif) dif = 0;
			else dif = 1;
		}
		return dif;
	}
#if 1	/* 2023.3.31 */
	if (opt04) {
		m1 = akxqmlen_type(pstr1,nstr1,type);
		m2 = akxqmlen_type(pstr2,nstr2,type);
		if (m1 < m2) return -1;
	}
#endif
	dif = 0;
/*	for (;;) {	*/
	while (len1>0 || len2>0) {
		c1 = c2 = '\0';
		if (len1 > 0) c1 = *s1;
		if (len2 > 0) c2 = *s2;
		if (!opt80) {
			if (!c1) len1 = 0;
			if (!c2) len2 = 0;
		}
		m1 = m2 = 1;
	/*	if (len1 >= 2) m1 = akxqkanjilen(s1);
		if (len2 >= 2) m2 = akxqkanjilen(s2);	*/
		if (len1 >= 2) m1 = akxqmbsnlen(type,s1,len1);
		if (len2 >= 2) m2 = akxqmbsnlen(type,s2,len2);
/*
printf("akxmbncmp_opt: m1=%d m2=%d\n",m1,m2);
*/
		if (m1==1 && m2==1) {
			if (opt01) {
				c1 = akxcupper(c1);
				c2 = akxcupper(c2);
			}
/*
printf("akxmbncmp_opt: c1=[%c] c2=[%c]\n",c1,c2);
*/
#if 1
			d = c1 - c2;
			if (opt40) {
				if (!d) {
					dif = 1;
					break;
				}
			}
			else if (dif=d) break;
#else
			if (dif=c1-c2) break;
#endif
			len1--;
			len2--;
			s1++;
			s2++;
		}
		else {
			n1 =m1;
			n2 =m2;
			if (opt02) {
				p1 = s1;
				p2 = s2;
				if (m1==1 || type==CD_TYPE_UTF8) {
					m1 = akxctozen1_type_opt(len1,s1,z1,nn,type,0);
					n1 = nn[0];
					p1 = z1;
/*
printtx("akxmbncmp_opt:zen1:1",p1,m1);
*/
				}
				if (m2==1 || type==CD_TYPE_UTF8) {
					m2 = akxctozen1_type_opt(len2,s2,z2,nn,type,0);
					n2 = nn[0];
					p2 = z2;
/*
printtx("akxmbncmp_optzen1:2",p2,m2);
*/
				}
				if (opt & 0x01) {
					akxcuplw(u1,z1,0);
					akxcuplw(u2,z2,0);
					p1 = u1;
					p2 = u2;
/*
printtx("akxmbncmp_opt:up:1",p1,m1);
printtx("             :up:2",p2,m2);
*/
				}
			}
			else {
				if (m1 > len1) m1 = len1;
				if (m2 > len2) m2 = len2;
				p1 = s1;
				p2 = s2;
			}
/*
printf("akxmbncmp_opt: p1=[%s] m1=%d p2=[%s] m2=%d\n",p1,m1,p2,m2);
*/
#if 1
			d = akxmbcmp(p1,m1,p2,m2);
			if (opt40) {
				if (!d) {
					dif = 1;
					break;
				}
			}
			else if (dif=d) break;
#else
			if (dif=akxmbcmp(p1,m1,p2,m2)) break;
#endif
/*
printf("akxmbncmp_opt: n1=%d n2=%d\n",n1,n2);
*/
			s1 += n1;
			s2 += n2;
			len1 -= n1;
			len2 -= n2;
		}
#if 1	/* 2023.3.31 */
		if (opt100 && (len1<=0 || len2<=0)) break;
		if (opt04 && len2<=0) break;
#else
		if (opt04 && (len1<=0 || len2<=0)) break;
#endif
	}
/*
printf("akxmbncmp_opt: dif=%d\n",dif);
*/
#if 0	/* 2023.3.31 */
	if (dif && opt04) {
		if (len1<nstr1 || len2 < nstr2) dif = 0;
	}
#endif
	return dif;
}

/********************************************************/
/*	������ƕ�������r����							*/
/********************************************************/
int akxmbncmp_opt(pstr1,nstr1,pstr2,nstr2,opt)
uchar *pstr1,*pstr2;
int nstr1,nstr2,opt;
{
	akxmbncmp_type_opt(pstr1,nstr1,pstr2,nstr2,akxt_get_code_type(),opt);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstrcmp(s1,s2)
uchar *s1,*s2;
{
	return akxmbncmp_opt(s1,strlen(s1),s2,strlen(s2),0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstricmp(s1,s2)
uchar *s1,*s2;
{
	return akxmbncmp_opt(s1,strlen(s1),s2,strlen(s2),0x01);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemcmp(s1,s2,len)
uchar *s1,*s2;
int len;
{
	if (len <= 0) return 0;
	else return akxmbncmp_opt(s1,len,s2,len,0x10);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemicmp(s1,s2,len)
uchar *s1,*s2;
int len;
{
	if (len <= 0) return 0;
	else return akxmbncmp_opt(s1,len,s2,len,0x11);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemcmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
/*
if (*s2=='%') {
int ret;
printf("len1=%d s1=[%s] len2=%d s2=[%s]\n",len1,s1,len2,s2);
	ret = akxmbncmp_opt(s1,len1,s2,len2,0x10);
printf("ret=%d\n",ret);
	return ret;
}
else
*/
	return akxmbncmp_opt(s1,len1,s2,len2,0x10);
}

/********************************************************/
/*														*/
/********************************************************/
int akxmemicmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	return akxmbncmp_opt(s1,len1,s2,len2,0x11);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstrcmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	return akxmbncmp_opt(s1,len1,s2,len2,0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxstricmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	return akxmbncmp_opt(s1,len1,s2,len2,0x01);
}

/********************************************************/
/*	������(pm1,len)���̕���(pm2)������ʒu��Ԃ�		*/
/********************************************************/
int akx_mem_chr_opt(pm1,pm2,len,opt)
uchar *pm1,*pm2;
int len,opt;
{
	uchar *s1,*s2,c1,c2;
	int pos,opt01,n,m1,m2,dif,code_type;

	if (!(s1=pm1) || !(s2=pm2)) return -1;
	opt01 = opt & 0x01;	/* ignore case */
	code_type = GET_TYPE_OPT(opt);
/*	if (!(m2=akxqiskanji(s2))) {	*/
	if (!(m2=akxqismbs(code_type,s2))) {
		c2 = *s2;
		 if (opt01) c2 = akxcupper(c2);
	}
	pos=0;
	n = len;
	while (n > 0) {
	/*	if (n >= 2) m1=akxqiskanji(s1);	*/
		if (n >= 2) m1=akxqismbs(code_type,s1);
		else m1=0;
		if (m1 && m2) {
			if (m1==m2 && n>=m1) {
				if (!memcmp(s1,s2,m1)) {
					pos=len-n+1;
					break;
				}
			}
		}
		else if (m1==m2) {
			c1 = *s1;
			if (opt01) dif=akxcupper(c1)-c2;
			else dif=c1-c2;
			if (!dif) {
				pos=len-n+1;
				break;
			}
		}
		if (m1) {
			s1+=m1;
			n -=m1;
		}
		else {
			s1++;
			n--;
		}
	}

	return pos;
}

/********************************************************/
/* �@�\ : buf����ptn�̂ǂꂩ�̕����Ɉ�v����ʒu��Ԃ�	*/
/* ���� : buf	  : �Ώە�����							*/
/*		  len	  : �Ώە����� (�o�C�g)				*/
/*		  ptn	  : �ǂꂩ�̕�������v���镶����		*/
/*		  ptn_len : ptn�� (�o�C�g)						*/
/*		  opt	  : �I�v�V����							*/
/*					0x01 : ignore case					*/
/*					0x08 : 0/1:in/to					*/
/*			0x04->	0x10 : �ԋp�l�̒P�� 0/1:�o�C�g/����	*/
/*			0x02->	0x20 : reverse						*/
/*					0x7f000000 : code_type				*/
/* �ԋp : >=0 											*/
/*		IN or TO  :�X�L�b�v�����o�C�g���܂��͕�����		*/
/*				   �p�^�[���Ɉ�v���镶�����Ȃ��Ƃ��́A	*/
/*					IN : 0								*/
/*					TO : len or �Ώە�����				*/
/*		RIN or RTO:�X�L�b�v�����ʒu�̐擪����̃o�C�g��	*/
/*				   �܂��͕�����							*/
/*				   �p�^�[���Ɉ�v���镶�����Ȃ��Ƃ��́A	*/
/*					RIN : len or �Ώە�����				*/
/*					RTO : 0								*/
/*		�y��zbuf="12345678", ptn="78"					*/
/*					IN : 0								*/
/*					TO : 6								*/
/*					RIN : 6								*/
/*					RTO : 8								*/
/*		�y��zbuf="12345678", ptn="12"					*/
/*					IN : 2								*/
/*					TO : 0								*/
/*					RIN : 8								*/
/*					RTO : 2								*/
/********************************************************/
int akxn_skip_opt(buf,len,ptn,ptn_len,opt)
char *buf,*ptn;
int  len,ptn_len,opt;
{
	int  i,lptn,m,k,flg,flgb,code_type;
	char *p;
	int  n,opt01,opt02,opt04,opt08,pos,match;

	if (!buf || !ptn) return -1;
	if (len<=0 || (lptn=ptn_len)<=0) return 0;
	opt04 = opt & 0x10;	/* return moji position */
/*
	if (!*ptn) {
		if (opt04) pos = akxqmlen(buf,len);
		else pos = len;
		return pos;
	}
*/
	code_type = GET_TYPE_OPT(opt);
	opt01 = opt & (CD_TYPE_OPT_MASK | 0x01);	/* opt_type | ignore case */
	opt02 = opt & 0x20;	/* reverse */
	opt08 = opt & 0x08;	/* 0/1=in/to */
	if (opt02) opt08 = opt08 ? 0 : 1;
	pos = 0;
	p = buf;
	m = 1;
	flgb = 0;
	for (i=k=0;i<len;k++) {
		if (!(*p)) break;
		match = akx_mem_chr_opt(ptn,p,lptn,opt01);
/*
printf("akx_skip_opt: i=%d match=%d lptn=%d ptn=[%c] p=[%c]\n",i,match,lptn,*ptn,*p);
*/
		flg = (opt08 && match) || (!opt08 && !match);
		if (opt02) {
			if (!flgb && flg) {
				if (opt04) pos = k;
				else pos = i;
			}
			flgb = flg;
		}
		else {
			if (flg) {
				if (opt04) i = k;
				return i;
			}
		}
	/*	m=akxqkanjilen(p);	*/
		m=akxqmbslen(code_type,p);
		p += m;
		i += m;
	}
	if (opt02) {
		if (!flgb) {
			if (opt04) pos = k;
			else pos = i;
		}
	}
	else {
		if (opt04) pos = k;
		else pos = i;
	}
	return pos;
}

/********************************************************/
/*														*/
/********************************************************/
int akx_skip_opt(buf,len,ptn,opt)
char *buf,*ptn;
int  len,opt;
{
	if (!ptn) return -1;
	return akxn_skip_opt(buf,len,ptn,strlen(ptn),opt);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipin(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnrskipin(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0x20);	/* 0x02 -> 0x20 */
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipto(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0x08);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnrskipto(buf,len,ptn)
char *buf,*ptn;
int  len;
{
	return akx_skip_opt(buf,len,ptn,0x08|0x20);	/* 0x02 -> 0x20 */
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipin2(buf,len,ptn,lptn)
char *buf,*ptn;
int  len,lptn;
{
	return akxn_skip_opt(buf,len,ptn,lptn,0);
}

/********************************************************/
/*														*/
/********************************************************/
int akxnskipto2(buf,len,ptn,lptn)
char *buf,*ptn;
int  len,lptn;
{
	return akxn_skip_opt(buf,len,ptn,lptn,0x08);
}

/********1*********2*********3*********4*********5*********6*********/
/*	�@�\ : �G�X�P�[�v�����ł̒u���������s��							*/
/*		   �G�X�P�[�v�����Ŏn�܂�Ȃ��Ƃ��́A���̕�����Ԃ�			*/
/*	���� : IN  : s    : ������										*/
/*				 len  : ������ (�o�C�g)							*/
/*				 ssp  : ssp.sp		: �Ώۈʒu (�擪��0�o�C�g)		*/
/*						ssp.attr[0] : �G�X�P�[�v����				*/
/*							attr[3] : code_type						*/
/*		   OUT : ssp  : ssp.sp		:								*/
/*						ssp.wd		: <>null �̂Ƃ��Aret=1 or 2 ��	*/
/*										�Ƃ��A�}���`�o�C�g������Ԃ�*/
/*							attr[1] : <>'\0' : �u�������A�܂��́A�擪����	*/
/*									  = '\0' : ret=1 or 2			*/
/*							attr[2] : ret=1 or 2 �̂Ƃ��A�}���`�o�C�g��	*/
/*	�ԋp : = 0 : �G�X�P�[�v�����Œu�����ꂽ�A�܂��́A				*/
/*				 �擪��1�o�C�g�����ŃG�X�P�[�v�����łȂ��Ƃ�		*/
/*			 1 : �擪���}���`�o�C�g�����̂Ƃ�						*/
/*			 2 : �G�X�P�[�v�����̎����}���`�o�C�g�����̂Ƃ�			*/
/********************************************************************/
int akx_conv_yen1(s,len,ssp)
uchar *s;
int    len;
SSP_S *ssp;
{
	uchar *p,c,uc,escape,cc;
	char *pp;
	int i,h,n,max,rad,d,code_type,m,ret;

	i = ssp->sp;
	code_type = ssp->attr[3];
	ssp->attr[1] = '\0';
	if (i >= len) return -1;
#if 1	/* 2022.12.06 */
	p = s + i;
	m = akxqmbsnlen(code_type,p,len);
	i += m;
	if (m > 1) {
		ssp->sp = i;
		ssp->attr[2] = m;
		if (pp=ssp->wd) memzcpy(pp,p,m);
		return 1;
	}
#else
	p = s + i++;
#endif
	ret = 0;
	escape = ssp->attr[0];
	c = *p++;
	if (escape && c==escape && i<len) {
	  m = akxqmbsnlen(code_type,p,len);
	  if (m == 1) {
		c = *p;
		if ((c>='0' && c<='9') || c=='x') {
			if (c == 'x') {
				max = 2;
				rad = 16;
				i++;
				p++;
			}
			else {
				max = 3;
				rad = 8;
			}
			max = X_MIN(i+max,len);
			n=0;
			uc = '\0';
			for (;i<max;i++,p++) {
				c = *p;
				if (c>='0' && c<='7') d = c - '0';
				else d = -1;
				if (rad == 16) {
					if (c>='a' && c<='f') d = c - 'a' + 10;
					else if (c>='A' && c<='F') d = c - 'A' + 10;
				}
				if (d>=0 && d<rad) {
					uc = uc*rad + d;
					n++;
				}
				else {
					break;
				}
			}
			c = uc;
		}
		else {
			switch (c) {
				case 'a': c = '\a'; break;
				case 'b': c = '\b'; break;
				case 'f': c = '\f'; break;
				case 'n': c = '\n'; break;
				case 'r': c = '\r'; break;
				case 't': c = '\t'; break;
				case 'v': c = '\v'; break;
			}
			i++;
		}
	  }
	  else {
		ssp->attr[2] = m;
		if (pp=ssp->wd) memzcpy(pp,p,m);
		c = '\0';
		i += m;
		ret = 2;
	  }
	}
	ssp->sp = i;
	ssp->attr[1] = c;
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtstrim(opt,pData,len,ptn)
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x04:NULL�N���A���Ȃ� */
char *pData,*ptn;
int len;
{
	int  ol;
	char *p;
	ParList pa_dat;

	ol = akxtstrim2(opt,pData,len,&pa_dat,ptn);
	if (ol>0 && pData != (p=pa_dat.par)) {
		memcpy(pData,p,ol);
		if (!(opt & 0x04)) pData[ol] = '\0';
	}
	return ol;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtstrim2(opt,pData,len,pa_dat,ptn)
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x04:NULL�N���A���Ȃ� */
char *pData,*ptn;
int len;
ParList *pa_dat;
{
	int i,ol,opt1,opt2,opt4,lptn,opt_type;
	char *p;

	pa_dat->par    = pData;
	pa_dat->parlen = len;
	if (!(p=pData)) return -1;
	else if ((ol=len) <= 0) return ol;
	if (!ptn) ptn = " \t";
	else if (!(lptn = strlen(ptn))) return ol;

	opt_type = opt & CD_TYPE_OPT_MASK;
	opt4 = opt & 0x04;
	opt &= 0x03;
	if (!opt) opt = 0x03;
	opt1 = opt & 0x01;
	opt2 = opt & 0x02;
	if (opt2) {	/* �O  */
		i = akx_skip_opt(pData,len,ptn,opt_type);	/* akxnskipin(pData,len,ptn); */
		ol = len - i;
		p = pData + i;
	}
	if (opt1 && ol>0) {	/* �� */
		ol = akx_skip_opt(p,ol,ptn,0x20 | opt_type);	/* 0x02 -> 0x20 */ /* akxnrskipin(p,ol,ptn); */
	}
/*
	if (opt>=1 && i>0) memcpy(pData,p,ol);
*/
	if (!opt4 && ol<len) p[ol] = '\0';

	pa_dat->par    = p;
	pa_dat->parlen = ol;

	return ol;
}

/********************************************************/
/*														*/
/********************************************************/
int akxtsapb(opt,pData,len)
	/* 2017.11.03 */
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x04:NULL�t�����Ȃ� */
char *pData;
int len;
{
#if 1	/* 2019.10.03 */
	int ol;

	ol = akxtstrim(opt,pData,len,NULL);
#else
	int i,ol,opt1,opt2;
	char *p, *pb, c;

	if (!(p = pData)) return -1;
	else if (len <= 0) return len;

	for (ol=0;ol<len;ol++) {
		if (!*p) break;
		p++;
	}
	p = pData;
	/* 2017.11.03 */
	if (!opt) opt = 0x03;
	opt1 = opt & 0x01;
	opt2 = opt & 0x02;
	if (opt2) {	/* �O  */
		while (ol>0 && ((c = *p) == ' ') || (c == '\t')) {
			p++;
			ol--;
		}
		if (ol <= 0) {
			*pData = '\0';
			return (0);
		}
	}
	/* 2017.11.03 */
	if (opt1) {	/* �� */
		pb = p + ol - 1;
		while (ol>0) {
			if (((c = *pb--) != ' ') && (c != '\t')) break;
			ol--;
		}
	}
	/* 2017.11.03 */
	if (opt2
	    && pData != p) memcpy(pData,p,ol);

	if (ol<len) pData[ol] = '\0';
#endif	/* 2019.10.03 */
	return ol;
}

/********************************************************/
/*														*/
/********************************************************/
char *akxttrim2(opt,pData,plen)
int opt;	/* 0:�O��, 0x02:�O, 0x01:��, 0x10:NULL�t������ */
char *pData;
int *plen;
{
#if 0	/* 2019.10.03 */ /* 1-->0 2021.10.2 */
	int ol;
	ParList pa_dat;

	ol = akxtstrim2(opt,pData,len,&pa_dat,NULL);
	pp = pa_dat.par;
#else
	int i,ol,ib,len,opt_fb,opt_ts,opt_f,opt_b,opt_t,opt_s,trim_ts;
	char *p, c, *pp;

	if (!(p=pData)) return NULL;
	if (!plen) return p;
	len = *plen;
	if ((ol=len) <= 0) return p;
/*
printf("akxttrim2: len=%d p=[%s]\n",len,p);
*/
	opt_fb = opt & (AKX_TRIM_BACKWARD | AKX_TRIM_FORWARD);
	opt_ts = opt & (AKX_TRIM_DEL_TAB  | AKX_TRIM_DEL_SPACE);
	if (!opt_fb) opt_fb = AKX_TRIM_BACKWARD | AKX_TRIM_FORWARD;
	if (!opt_ts) opt_ts = AKX_TRIM_DEL_TAB  | AKX_TRIM_DEL_SPACE;
	opt_f = opt_fb & AKX_TRIM_FORWARD;
	opt_b = opt_fb & AKX_TRIM_BACKWARD;
	opt_t = opt_ts & AKX_TRIM_DEL_TAB;
	opt_s = opt_ts & AKX_TRIM_DEL_SPACE;
	if (opt_f) {	/* �O  */
#if 1
		while (ol > 0) {
			if (!(c = *p)) break;
			else if (!(opt_s && c==' ' || (opt_t && c=='\t'))) break;
#else
		while (ol>0 && ((opt_s && (c=*p)==' ') || (opt_t && c=='\t'))) {
#endif
			p++;
			ol--;
		}
		if (!c || ol<=0) {
			if (opt & 0x10) *pData = '\0';
			*plen = 0;
			return pData;
		}
	}
	pp = p;
	if (opt_b) {	/* �� */
#if 1	/* 2021.10.2 */
		ib = -1;
		for (i=0;i<ol;i++,p++) {
			if (!(c = *p)) {
				ol = i;
				break;
			}
			trim_ts = (opt_s && c==' ') || (opt_t && c=='\t');
/*
printf("akxttrim2: i=%d ib=%d c=[%c] trim_ts=%d\n",i,ib,c,trim_ts);
*/
			if (ib < 0) {
				if (trim_ts) ib = i;
			}
			else {
				if (trim_ts) ;
				else ib = -1;
			}
		}
		if (ib >= 0) ol = ib;
#else
		ib = -1;
		for (i=0;i<ol;i++,p++) {
			if (((c = *p)==' ') || (c=='\t')) {
				ib = i;
				for (;i<ol;i++,p++) {
					if (((c = *p)==' ') || (c=='\t')) ;
					else {
						if (c) ib = -1;
						break;
					}
				}
			}
			if (!c) {
				ol = i;
				break;
			}
		}
		if (ib >= 0) ol = ib;
#endif
	}
#endif	/* 2019.10.03 */
	if ((opt & 0x10) && ol<len) pp[ol] = '\0';
	*plen = ol;
	return pp;
}

/********************************************************/
/*														*/
/********************************************************/
int akxttrim(opt,pData,len0)
int opt;	/* 0:�O�� 0x02:�O 0x01:�� */
char *pData;
int len0;
{
	int len;
	char *p;

	len = len0;
	if (!opt) opt = 3;
	p = akxttrim2(opt,pData,&len);
	if ((opt & 0x02) && pData!=p) memcpy(pData,p,len);
	if (len<len0) pData[len] = '\0';
	return len;
}

/************************************************/
/* �@�\ : �Ώە����񂪎w�肳�ꂽ��������		*/
/*		  �����݂̂��ǂ����𒲂ׂ�				*/
/* ���� : p1  : �Ώە�����						*/
/*		  len : p1�̃o�C�g��					*/
/*		  str : ���ׂ邢�����̕���(NULL�I�[)	*/
/*				NULL�̂Ƃ��́A" \t\r\n"			*/
/* �ԋp : =0 : str�ȊO������					*/
/*			   �܂��́Ap1=NULL					*/
/*		  =1 : str�݂̂ł���					*/
/*			   �܂��́Ap1��str���󕶎�			*/
/************************************************/
int akxqn_is_str(p1,len,str)
char *p1,*str;
int len;
{
	int ret,pos;

	pos = ret = 0;
	if (p1 && len>0) {
		if (!str) str = " \t\r\n";
		if (!*str) {
			if (!*p1) ret = 1;
		}
		else if ((pos=akxnskipin(p1,len,str)) >= len) ret = 1;
	}
/*
printf("akxqn_is_str: pos=%d ret=%d str=[%s]\n",pos,ret,str);
*/
	return ret;
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_mleft(s,s_len,m_len,opt)
char *s;
int s_len,m_len,opt;
{
	int code_type;

	if (!s || s_len<0) return -1;
	code_type = GET_TYPE_OPT(opt);
	return akxqm2len_type(s,s_len,m_len,code_type);
}

/********************************************************/
/*														*/
/********************************************************/
int akxs_mright(s,s_len,m_len,opt)
char *s;
int s_len,m_len,opt;
{
	int i,mlen,pos,code_type,m;

	if (!s || s_len<0) return -1;
/*
printf("akxs_mright: s_len=%d m_len=%d opt=%08x s=[%s]\n",s_len,m_len,opt,s);
*/
	code_type = GET_TYPE_OPT(opt);
	/* slen�o�C�g�̕����������߂� */
	mlen = akxqmlen_type(s,s_len,code_type);
/*
printf("akxs_mright: mlen=%d\n",mlen);
*/
	m = mlen - m_len;	/* �擪����̕����� */
	if (m > 0) {
		/* �擪����̃o�C�g�� */
		m = akxqm2len_type(s,s_len,m,code_type);
/*
printf("akxs_mright: m=%d\n",m);
*/
	}
	else m = 0;
	return m;
}

/********1*********2*********3*********4*********5*********6*********7**
'*  ���� : cmp_mstr_posa_opt                                           *
'*  �@�\ : �w��̋�؂蕶����̂ǂꂩ���ŋ�؂�ꂽ������̂ǂꂩ���A  *
'*         �Ώە�����Ɉ�v���邩�A�Ώە����񒆂ɂ��邩�ǂ����𒲂ׂ�  *
'*         (��)���p�S�p����ʂ��Ȃ��I�v�V�����ŁAtext0 ���ɑ��_�t��    *
'*             ���p�J�i������Ƃ��A��v�����񒷂��Z���Ȃ�ꍇ������    *
'*  ���� : IN  : text0  : �Ώە�����                                   *
'*               mstr0  : ��؂蕶����̂ǂꂩ���ŋ�؂�ꂽ������     *
'*               opt0   : �I�v�V����                                   *
'*                        0x01 : 0=INSTR / 1=STRCMP                    *
'*                        0x02 : 1=�啶������������ʂ��Ȃ�            *
'*                        0x04 : 1=���p�S�p����ʂ��Ȃ�                *
'*                        0x08 : 1=INSTR�̂Ƃ���������Ώۂɂ���       *
'*                        0x10 : 1=INSTR�̂Ƃ��O����v                 *
'*                        0x20 : 1=INSTR�̂Ƃ������v                 *
'*                        0x40 : 1=LIKE�g�p�����"_"������           *
'*                        0x80 : 1=LIKE�g�p���Ȃ�                      *
'*               dlm    : ��؂蕶����                                 *
'*               posa() : ��v�ʒu(�擪��1)��Ԃ��z��                  *
'*                        posa(0):text0���̈�v�擪�ʒu                *
'*                        posa(1):nstr0���̕�����̔ԍ�(�擪��1�Ԗ�)   *
'*                          �z��̌��ɂ���Ĉȉ���Ԃ�               *
'*                        posa(2):start pos by byte                    *
'*                        posa(3):matching string length by byte       *
'*                        posa(4):start pos by char                    *
'*                        posa(5):matching string length by char       *
'*               max_posa: posa�̌�                                  *
'*  �ԋp : �������� = 0 : text���ɂȂ�                                 *
'*                  > 0 : text���̈�v�擪�ʒu(�擪��1)                *
'*  �쐬 : 20XX/XX/XX Akito Kobayashi                                  *
'*  �X�V :															   *
'**********************************************************************/
int cmp_mstr_posa_opt(text0,mstr0,opt0,dlm,posa,max_posa)
char *text0,*mstr0;
int opt0;
char *dlm;
int posa[],max_posa;
{
	mem_set_int(posa,0,max_posa);
/*
    Dim plike As tdtLIKE_CTL
    Dim plika() As tdtLIKE_CTL
'    Dim ssp As SSPL
    Dim i As Integer
    Dim k As Integer
    Dim m As Integer
    Dim n As Integer
    Dim nn As Integer
    Dim pos As Integer
    Dim opt As Integer
    Dim opt1 As Integer
    Dim opt2 As Integer
    Dim opt4 As Integer
    Dim opt8 As Integer
    Dim opt10 As Integer
    Dim opt20 As Integer
    Dim cmp_opt As Integer
    Dim iLIKE As Integer
    Dim npat As Integer
    Dim text_len As Integer
    Dim posal(5) As Integer
    Dim sep As String
    Dim text As String
    Dim mstr As String
    Dim wwd As String
    Dim wwd0 As String
    Dim ret As String
    Dim text2 As String
    Dim wwd2 As String
    Dim pata(99) As String

    text = text0
    mstr = mstr0
    opt1 = opt0 And &H1
    opt2 = opt0 And &H2
    opt4 = opt0 And &H4
    opt8 = opt0 And &H8
    opt10 = opt0 And &H10
    opt20 = opt0 And &H20
    If opt10 <> 0 And opt20 <> 0 Then
        opt10 = 0
        opt20 = 0
        opt1 = 1
    End If
        If opt1 = 1 Then
            cmp_opt = 3
        Else
            cmp_opt = Int(opt0 / 16) And &H3
        End If

        If opt2 <> 0 Then
            text = UCase(text)
            mstr = UCase(mstr)
        End If
        If opt4 <> 0 Then text = StrConv(text, vbWide)

    opt = &H1 + &H4 + &H8 + &H2000
    n = GetArgs(mstr, pata, UBound(pata) + 1, dlm, opt)
    pos = 0
    ret = ""
    nn = UBound(posa)
    If nn > 5 Then nn = 5
    Call int_array_clear(posa, 0, nn + 1)
        text_len = Len(text)
        For i = 0 To n - 1
            wwd = pata(i)
            wwd0 = wwd
            If opt4 <> 0 Then wwd = StrConv(wwd, vbWide)
            If opt8 <> 0 And text_len < Len(wwd) Then
                text2 = wwd
                wwd2 = text
            Else
                text2 = text
                wwd2 = wwd
            End If
            pos = cmpstr_opt(text2, wwd2, cmp_opt)
            If pos > 0 Then
                posa(0) = pos
                posa(1) = i + 1
                If nn >= 2 Then posa(2) = axLenH(Left(text0, pos - 1)) + 1
                If nn >= 3 Then posa(3) = axLenH(wwd0)
                If nn >= 4 Then posa(4) = pos
                If nn >= 5 Then posa(5) = Len(wwd0)
                ret = Mid(text0, pos, Len(wwd0))
                Exit For
            End If
        Next
*/
	return posa[0];
}
/*
Function cmpstr_opt( _
  ByRef text As String _
, ByRef pat As String _
, Optional ByVal opt As Integer = 0 _
) As String
    Dim len_text As Integer
    Dim len_pat As Integer
    Dim pos As Integer

    opt = opt And &H3
    len_text = Len(text)
    len_pat = Len(pat)
    If len_pat = 0 Or len_text = 0 Or len_pat > len_text Then
        pos = 0
    Else
        If opt = 0 Then
            pos = InStr(text, pat)
        ElseIf opt = 3 Then
            If strcmp(text, pat) = 0 Then pos = 1
        Else
            If opt = 1 Then
                If pat = Left(text, len_pat) Then pos = 1
            Else
                If pat = Right(text, len_pat) Then pos = len_text - len_pat + 1
            End If
        End If
    End If
    cmpstr_opt = pos

End Function
*/
