static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
cc -finput-charset=CP932 -g -DLINUX -I../include test_to_hebon.c libakx_no_u8src.a -o test_to_hebon

cc -finput-charset=CP932 -g -DLINUX -DUTF8_SRC -I../include test_to_hebon.c libakx_no_iconv.a -o test_to_hebon
*/
#include "akxcommon.h"
int main()
{
	char buf[256],wd[256],pat[256],*p;
	int n,opt,len,ret;
	ParList pa_dat;
/*
#ifndef UTF8_SRC
	n = akb_gs_akb_name("COAL","UTF8_CONV",buf);
	if (n > 0) {
		ret = akxc_set_utf8_file(buf);
		printf("UTF8_CONV=[%s] ret=%d\n",buf,ret);
	}
#endif
*/
	akxc_set_utf8_file("/tmp/coal_new/src/lib/akx/sjis0213.txt");
	
	printf("code_type=%d\n",akxt_get_code_type());
	p = "�A�v���P�[�V����";
	printf("%s 0==> %s\n",p,to_hebon(p,0));
	printf("%s 1==> %s\n",p,to_hebon(p,1));
	printf("%s 2==> %s\n",p,to_hebon(p,2));
	printf("%s 4==> %s\n",p,to_hebon(p,4));
	printf("%s 8==> %s\n",p,to_hebon(p,8));
	printf("%s 1+4==> %s\n",p,to_hebon(p,1+4));
	printf("%s 1+8==> %s\n",p,to_hebon(p,1+8));
}
