static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DAIX -I../include testitoa.c ../xcom/akxcom.a -lm -o testitoa
*/
#include "akxcommon.h"
main()
{
	char buf[128],tmp[128];
	int f,ret,num,len;

	printf("Enter test mode (0=num, 1=buff len)==>");
	gets(buf);
	f = atoi(buf);
	if (f) {
		printf("Enter num==>");
		gets(buf);
		num = atoi(buf);
	}
	else {
		printf("Enter buff len==>");
		gets(buf);
		len = atoi(buf);
	}
	for (;;) {
		if (f) {
			printf("Enter buff len==>");
			gets(buf);
			len = atoi(buf);
		}
		else {
			printf("Enter num==>");
			gets(buf);
			num = atoi(buf);
		}
		*tmp = '\0';
		ret = akxc_ito_a(num,tmp,len);
		printf("ret=%d buf=[%s]\n",ret,tmp);
	}
}
