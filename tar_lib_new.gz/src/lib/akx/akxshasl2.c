static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************
 *
 *	akxshasl2.c
 *
 *		  coded by A.Kobayashi 2010/05/10
 *
 *************************************************/
#include "akxcommon.h"

#define HASL2

#define tdtHaslCell	tdtHaslCell4
#define akxshasli	akxshasl2i
#define akxshasls	akxshasl2s
#define akxshaslr	akxshasl2r
#define akxshasld	akxshasl2d
#define akxshaslu	akxshasl2u
#define akxshaslp	akxshasl2p
#define akxs_hasl_new	akxs_hasl2_new
#define akxs_hasl_new2	akxs_hasl2_new2
#define akxs_hasl_free	akxs_hasl2_free
#define akxshasl	akxshasl2
#define akxs_xhasl_new	akxs_xhasl2_new
#define akxs_xhasl_free	akxs_xhasl2_free
#define akxs_xhasl	akxs_xhasl2
#define _xhasl_chk	_xhasl2_chk
#define _xhasl_max	_xhasl2_max

#include "./akxshasl.c"
