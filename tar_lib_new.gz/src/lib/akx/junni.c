static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#include <stdio.h>
main()
{
	int a,b,c,d;

	b = 1;
	c = 2;
	a = b + c = 10;
	printf("a=%d\n",a);
}
