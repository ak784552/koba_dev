static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testbitnum.c libakx_no_u8src.a -o testbitnum
*/
#include "akxcommon.h"
main()
{
	int num,i;
	long bit;
	char buf[50];

	bit = 0;
	num = get_bit_number(bit);
	printf("bit=%08x num=%d\n",bit,num);
	bit = 1;
	for (i=1;i<32;i++) {
		num = get_bit_number(bit);
		printf("bit=%08x num=%d\n",bit,num);
		bit <<= 1;
	}
}
