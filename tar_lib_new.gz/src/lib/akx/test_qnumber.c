static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_qnumber.c libakx_no_iconv.a -o test_qnumber
*/
#include "akxcommon.h"
int main()
{
	char expbuf[256];
	int ret,i,iParm[4],opt;

	printf("Enter opt==>");
	gets(expbuf);
	ret = akxcgcvn(expbuf,strlen(expbuf),&opt);
	printf("ret=%d opt=%08x\n",ret,opt);
	if (ret >= 0) {
		for (;;) {
			printf("Enter number(-123.45E+12)==>");
			gets(expbuf);
			if (!stricmp(expbuf,"/EOF")) break;
			ret = akxqnumber(expbuf,strlen(expbuf),opt,iParm);
			if (ret >= 0) printf("ret=%08x\n",ret);
			else printf("ret=%d\n",ret);
			for (i=0;i<4;i++) printf("iParm[%d]=%d\n",i,iParm[i]);
		}
	}
	return 0;
}
