static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_per_check.c libakx_no_iconv.a -o test_per_check
*/
#include "akxcommon.h"
/****************************************/
/*										*/
/****************************************/
static int _per_check(buf,buf_len,fmt)
char *buf,*fmt;
int buf_len;
{
	int len,i,m,rem_len;
	char *pf,*pb,c,cc;
/*
printf("_per_chack: fmt=[%s]\n",fmt);
*/
	buf_len--;
	len = 0;
	pf = fmt;
	pb = buf;
	rem_len = strlen(fmt);
	while (c = *pf) {
		if (len >= buf_len) break;
		m = akxqkanjilen2(pf,rem_len);
		if (m > 1) {
			memcpy(pb,pf,m);
			pb += m;
			pf += m;
			len += m;
			rem_len -= m;
		}
		else {
			pf++;
			*pb++ = c;
			len++;
			rem_len--;
			if (c == '%') {
				if (len >= buf_len) {
					len--;
					pb--;
					break;
				}
				*pb++ = c;
				len++;
				rem_len--;
			}
		}
	}
	*pb++ = '\0';
/*
printf("_per_chack: len=%d buf=[%s]\n",len,buf);
*/
	return len;
}

int main()
{
	char buf[32],fmt[32],wrk[32];
	int len;
	tdtGeneralData tParms,tParmd;

	strcpy(fmt,"a��%�a%AA");
	akxaxdump_type("fmt",fmt,strlen(fmt),CD_TYPE_SJIS);
	tParms.gd_code = CD_TYPE_SJIS;
	tParmd.gd_code = CD_TYPE_UTF8;
	tParms.gd_data = fmt;
	tParmd.gd_data = wrk;
	tParms.gd_dlen = strlen(fmt);
	tParmd.gd_dlen = sizeof(wrk);
	len = akxt_code_trans(&tParms,&tParmd);
	akxaxdump_type("wrk",wrk,len,CD_TYPE_UTF8);

	len = _per_check(buf,sizeof(buf),wrk);

	tParms.gd_code = CD_TYPE_UTF8;
	tParmd.gd_code = CD_TYPE_SJIS;
	tParms.gd_data = buf;
	tParmd.gd_data = wrk;
	tParms.gd_dlen = strlen(buf);
	tParmd.gd_dlen = sizeof(wrk);
	len = akxt_code_trans(&tParms,&tParmd);
	akxaxdump_type("wrk",wrk,len,CD_TYPE_SJIS);

	printf("len=%d wrk=[%s]\n",len,wrk);
}
