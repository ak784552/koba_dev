static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_skip.c libakx_no_iconv.a -o test_skip
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256],*p;
	int n,opt,len,ret;

	printf("Enter source text ==>");
	gets(buf);
	len=strlen(buf);
	for (;;) {
	/*
		printf("Enter opt ==>");
		gets(wd);
		opt=atoi(wd);
	*/
		printf("Enter search string ==>");
		gets(wd);
		printf("LastName: ret=%s\n",akxt_get_last_name(wd,buf));
		printf("skipto:   ret=%d\n",akxnskipto(buf,len,wd));
		printf("skipin:   ret=%d\n",akxnskipin(buf,len,wd));
		printf("iskipto:  ret=%d\n",akx_skip_opt(buf,len,wd,1+8));
		printf("iskipin:  ret=%d\n",akx_skip_opt(buf,len,wd,1));
		printf("rskipto:  ret=%d\n",akxnrskipto(buf,len,wd));
		printf("rskipin:  ret=%d\n",akxnrskipin(buf,len,wd));
		printf("irskipto: ret=%d\n",akx_skip_opt(buf,len,wd,1+2+8));
		printf("irskipin: ret=%d\n",akx_skip_opt(buf,len,wd,1+2));
		printf("skiptoM:   ret=%d\n",akx_skip_opt(buf,len,wd,4+8));
		printf("skipinM:   ret=%d\n",akx_skip_opt(buf,len,wd,4));
		printf("iskiptoM:  ret=%d\n",akx_skip_opt(buf,len,wd,1+4+8));
		printf("iskipinM:  ret=%d\n",akx_skip_opt(buf,len,wd,1+4));
		printf("rskiptoM:  ret=%d\n",akx_skip_opt(buf,len,wd,2+4+8));
		printf("rskipinM:  ret=%d\n",akx_skip_opt(buf,len,wd,2+4));
		printf("irskiptoM: ret=%d\n",akx_skip_opt(buf,len,wd,1+2+4+8));
		printf("irskipinM: ret=%d\n",akx_skip_opt(buf,len,wd,1+2+4));
	}
}
