static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************
 *
 *	akxsregex.c
 *
 *        coded by A.Kobayashi 2010/06/01
 *
 *************************************************/
#include "akxcommon.h"
/*
int regcomp(regex_t *preg, const char *regex, int cflags);
int regexec(const regex_t *preg, const char *string, size_t nmatch,
            regmatch_t pmatch[], int eflags);
size_t regerror(int errcode, const regex_t *preg, char *errbuf,
                size_t errbuf_size);
void regfree(regex_t *preg);
*/
int akxs_regex(
char *regex,
char *string,
size_t nmatch,
regmatch_t pmatch[],
int flags[],
size_t errbuf_size,
char *errbuf)
{
	regex_t reg;
	int errcode,*pflags,flag[2];

	if (!regex || !string) return -1;
	if (flags) pflags = flags;
	else {
		flag[0] = flag[1] = 0;
		pflags = flag;
	}
	if (errcode = regcomp(&reg,regex,pflags[0])) {
		if (errbuf_size>0 && errbuf) regerror(errcode,&reg,errbuf,errbuf_size);
	}
	else {
		if (errbuf_size>0 && errbuf) *errbuf = '\0';
		errcode = regexec(&reg,string,nmatch,pmatch,pflags[1]);
	}
	regfree(&reg);
	return errcode;
}
