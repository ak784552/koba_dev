static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�ϊ�                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_conv_const_c( pparmList , pInfoParm )           *
*                      (I)prmList	*pparmList                                *
*                      (O)tdtInfoParm	*pInfoParm                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;

static int _conv_const_c(pparmList,pInfoParm,quot)
parmList *pparmList;
tdtInfoParm *pInfoParm;
char quot;
{
	int i,rc,point,len,Headsize,code_type;
	char *pBuff,*p;
/*	char cM_QUOTE1 = pGlobTable->Quot[0];	*/

	if (!pparmList || !(p=pparmList->prp)) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}

	len = pparmList->prmlen;
	code_type = GET_TYPE_OPT(pparmList->opt);
/*
printf("cl_conv_const_c: code_type=%08x\n",code_type);
*/
/*	if ((len>=2)&&(p[0]==cM_QUOTE1 && p[len-1]==cM_QUOTE1)) {	*/
	if ((len>=2)&&(p[0]==quot && p[len-1]==quot)) {
		point = len - 2;
		if (point>=0) {
			if (!(pBuff=cl_tmp_const_malloc(point+1))) return ECL_MALLOC_ERROR;
			point = cl_conv_yen(p+1,point,pBuff,code_type);
		/*	pBuff[point] = '\0';	*/
		}
/*
		else {
printf("cl_conv_const_c: NULL data\n");
		}
*/
	}
	else {
		ERROROUT1(FORMAT(301),p);	/* �����萔�G���[[%s] */
		return ECL_SCRIPT_ERROR;
	}
/*
printf("cl_conv_const_c: point=%d pBuff=[%s]\n",point,pBuff);
*/
	cl_set_parm_char2(pInfoParm,pBuff,point,code_type);
	pInfoParm->pi_aux[1] = D_AUX1_PROTECTED;

	return NORMAL;
}

int cl_conv_const_c(pparmList,pInfoParm)
parmList *pparmList;
tdtInfoParm *pInfoParm;
{
	char cM_QUOTE1 = pGlobTable->Quot[0];

	_conv_const_c(pparmList,pInfoParm,cM_QUOTE1);
}

int cl_conv_const_cmd(pparmList,pInfoParm)
parmList *pparmList;
tdtInfoParm *pInfoParm;
{
	_conv_const_c(pparmList,pInfoParm,M_QUOTE3);
}

int cl_set_parm_char(pInfoParm,pBuff,point)
tdtInfoParm  *pInfoParm;
char *pBuff;
int  point;
{
	return cl_set_parm_char2(pInfoParm,pBuff,point,0);
}

int cl_set_parm_char2(pInfoParm,pBuff,point,code_type)
tdtInfoParm  *pInfoParm;
char *pBuff;
int  point,code_type;
{
	static char null_str[2]={'\0','\0'};
	int Headsize;

	if (!pInfoParm) return -1;

	if (point < 256)
		Headsize = sizeof( FORM_S );
	else
		Headsize = sizeof( FORM_K );
/*	if (code_type <= 0) code_type = CLcommon.cDataCode;	*/
	if (!code_type) code_type = CLcommon.cDataCode;
	memset(pInfoParm,0,sizeof(tdtInfoParm));
	pInfoParm->pi_id = ' ';
	pInfoParm->pi_attr = DEF_ZOK_CHAR;
	pInfoParm->pi_code = code_type;
	pInfoParm->pi_scale= 0;
	pInfoParm->pi_hlen  = 0;
	pInfoParm->pi_pos  = Headsize;
	pInfoParm->pi_dlen  = point;
/*	pInfoParm->pi_len  = Headsize + point;	*/
	pInfoParm->pi_len  = 0;
	if (pInfoParm->pi_dlen == 0) pInfoParm->pi_data = null_str;
	else pInfoParm->pi_data = pBuff;

	return 0;
}

int cl_conv_yen(buff,len,wkstr,code_type)
char *buff,*wkstr;
int  len,code_type;
{
	unsigned char c,uc;
	char wrk[5];
	int i,h,n,max,rad,d,len1,rc,m;
	SSP_S ssp;

	len1=len-1;
	h=0;
	i=0;
	memset(&ssp,0,sizeof(SSP_S));
	ssp.wd = wrk;
	ssp.attr[0] = '\\';
	ssp.attr[3] = code_type;
	while (i<len) {
		if ((n=akxqmbsnlen(code_type,buff+i,len-i)) >= 2) {
			memcpy(wkstr+h,buff+i,n);
			h += n;
			i += n;
			continue;
		}
/*#if 1*/	/* 2021.7.29 */
/*		ssp.sp = i;
		akx_conv_yen1(buff,len,&ssp);
		i = ssp.sp;
		wkstr[h++] = ssp.attr[1];
#else*/
		c=buff[i];
/*
printf("cl_conv_yen:i=%d c=%02x[%c]\n",i,c,c);
*/
		if (c!='\\' || i>=len1) {
			wkstr[h++] = c;
			i++;
		}
		else {
			/* 2021.7.29 */
			ssp.sp = i;
			if (!(rc = akx_conv_yen1(buff,len,&ssp))) {
				wkstr[h++] = ssp.attr[1];
			}
			else {
				m = ssp.attr[2];
				memcpy(wkstr+h,ssp.wd,m);
				h += m;
			}
			i = ssp.sp;
/*
printf("cl_conv_yen:i=%d ssp.attr[1]=%02x\n",i,ssp.attr[1]);
*/
		}
	}
	wkstr[h] = '\0';
	return h;
}

int cl_get_char_code_type(pInfoParm,opt)
tdtInfoParm *pInfoParm;
int opt;	/* ����ł��Ȃ��Ƃ��̕ԋp�l�ݒ� */
			/* opt=0 :				*/
			/*	pInfoParm=NULL : -1	*/
			/*	����ł��Ȃ�   : -2 */
			/* opt=1 :				*/
			/*	pInfoParm=NULL : -1	*/
			/*	����ł��Ȃ�   :  0 */
			/* opt=2 :				*/
			/*	pInfoParm=NULL : -1	*/
			/*	����ł��Ȃ�   : akxt_get_code_type() */
{
	int code_type;

	code_type = -1;
	if (pInfoParm) {
		code_type = -2;
		if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_CHAR)
			code_type = pInfoParm->pi_code;
		else if (opt) code_type = 0;
		if (!code_type && opt==2) code_type = akxt_get_code_type();
	}
	return code_type;
}

int cl_is_mbyte(pInfoParm,code_type)
tdtInfoParm *pInfoParm;
int code_type;
{
	int ret;

	ret = 0;
	if (pInfoParm) {
		if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_CHAR)
			ret = akxqismbyte(code_type,pInfoParm->pi_data,pInfoParm->pi_dlen);
	}
	return ret;
}

int cl_sep_string_with_type(par2,p,len)
ParList2 *par2;
char *p;
int len;
{
	int ret,code_type;
	char c;

	ret = code_type = 0;
	if (len > 0) {
		if (*p == 0x01) {
			p++;
			code_type = *p & CD_TYPE_CODE;	/* code_type=0�̂Ƃ�null�I�[�ɂȂ�̂� */
			p++;
			len -= 2;
			ret = 2;
		}
	}
	par2->option = code_type;
	par2->parlen = len;
	par2->par = p;
	return ret;
}

char *cl_set_type_to_string(p,len1,code_type)
char *p;
int len1,code_type;
{
	if (len1>0 && code_type>=0) {
		*p++ = 0x01;
		*p++ = code_type | 0x80;	/* code_type=0�̂Ƃ�null�I�[�ɂȂ�̂ŁA0x80��t������ */
	}
	return p;
}
