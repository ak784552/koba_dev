#!/bin/sh

#if [ $# -eq 0 ] ; then
#	echo "usage: $0 logfile"
#	exit 1
#fi

echo '+++ ' `date '+%Y/%m/%d %H:%M:%S'`
#ps -eflx | egrep DSD.RUN | egrep -v egrep
ps -efl | egrep '(Main|coal)' | egrep -v egrep
