static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/*****************************************/
/*                                       */
/*                 cl_ct_clear           */
/*---------------------------------------*/
/*  �X�N���v�g�e�[�u���ƃv���V�[�W���[   */
/*  �e�[�u���̍폜                       */
/*---------------------------------------*/
/*                                       */
/*****************************************/
#include "colmn.h"

extern CLPRTBL   *pGLprocTable;
extern CLPRTBL   *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern tdtLruScrHead *tpLruScrHeadImp;
extern tdtLruScrHead *tpLruScrHead;
extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */

int addrchk(file,line,p)
char *file;
int  line;
char *p;
{
	char w[128];

	if (!p) return 0;
	if (!akxm_addrchk(p)) {
		sprintf(w,"address invalid (0x%08x)",p);
		akb_error_out(file,line,w);
		return 0;
	}
	return 1;
}

int cl_ct_clear()
{
	ScrPrCT        *Dummy;
	SearchResult   *DummySE;
	VarTBL         *DummyVR;
	ConstantCt     *DummyCN;
	AKAMSGCOM      *tpMsgCom;

	if (ADDRCHK(CLSTCB.TopStack)) {
		cl_leaf_clear(CLSTCB.TopStack);
		CLSTCB.TopStack = NULL;
	}
	if (pCLprocTable->CmdPacketp) {
		tpMsgCom = (AKAMSGCOM *)pCLprocTable->CmdPacketp;
		if (tpMsgCom->msg_pmsg) {
			Free(tpMsgCom->msg_pmsg);
			tpMsgCom->msg_pmsg = NULL;
		}
	}
	if (pCLprocTable->WaitPacketp) {
		Free(pCLprocTable->WaitPacketp);
		pCLprocTable->WaitPacketp = (char *)NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->PrCTp=%08x\n",pCLprocTable->PrCTp);
*/
	if (ADDRCHK(pCLprocTable->PrCTp)) {
		Dummy = pCLprocTable->PrCTp;
		cl_scr_clear(Dummy);
		pCLprocTable->PrCTp = NULL;
		pCLprocTable->CurScr = NULL;	/* add 2023.5.25 */
	}

	if (ADDRCHK(pCLprocTable->SearchRsltF)) {
		DummySE = pCLprocTable->SearchRsltF;
		cl_rslt_clear(DummySE);
		pCLprocTable->SearchRsltF = NULL;
	}

	if (pCLprocTable->ListPBody != NULL) {
		cl_list_pac_clear(pCLprocTable->ListPBody);
		pCLprocTable->ListPBody = NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->Vary=%08x\n",pCLprocTable->Vary);
*/
	if (ADDRCHK(pCLprocTable->Vary)) {
		DummyVR = pCLprocTable->Vary;
		vary_clear(DummyVR);
		pCLprocTable->Vary = NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->pha_vnam=%08x\n",pCLprocTable->pha_vnam);
*/
	if (ADDRCHK(pCLprocTable->pha_vnam)) {
		akxs_xhash_free(pCLprocTable->pha_vnam);
		pCLprocTable->pha_vnam = NULL;
	}
/*
	if (ADDRCHK(pCLprocTable->pTBL_vnam)) {
		cl_free_var_ent(pCLprocTable->pTBL_vnam);
		Free(pCLprocTable->pTBL_vnam[0]);
		Free(pCLprocTable->pTBL_vnam);
		pCLprocTable->pTBL_vnam = NULL;
	}
*/
/*
printf("cl_ct_clear: Free: pCLprocTable->pha_fp=%08x\n",pCLprocTable->pha_fp);
*/
	if (ADDRCHK(pCLprocTable->pha_fp)) {
		cl_free_fp(pCLprocTable->pha_fp);
		pCLprocTable->pha_fp = NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->pha_env=%08x\n",pCLprocTable->pha_env);
*/
	if (ADDRCHK(pCLprocTable->pha_env)) {
		cl_env_reset(pCLprocTable->pha_env);
		pCLprocTable->pha_env = NULL;
	}
/*
printf("cl_ct_clear: Free: pCLprocTable->ConstCt=%08x\n",pCLprocTable->ConstCt);
*/
	if (ADDRCHK(pCLprocTable->ConstCt)) {
		DummyCN = pCLprocTable->ConstCt;
		const_ct_clear ( DummyCN );
		pCLprocTable->ConstCt = NULL ;
	}
	cl_tmp_const_clear(2);

	pCLprocTable->CurScr = NULL;
	pCLprocTable->CurProc = NULL;

	pGlobTable->tuppl  = 0;
	pGlobTable->column = 0;
	pGlobTable->error  = 0;
	pGlobTable->Return = 0;
	pGlobTable->Retval = NULL;
	pGlobTable->exception = 0;
	pGlobTable->try_level = 0;

	return 0;
}

/**************************************************/
/*   �X�N���v�g�e�[�u���̍폜 (cl_scr_clear)      */
/**************************************************/
static void _free_const(scrconst)
ScrConstCt *scrconst;
{
	char *p;

	if (p=scrconst->pId) Free(p);
	Free(scrconst);
}

int cl_scr_clear(Dummy)
ScrPrCT *Dummy;
{
	int i,j;
	ONTBL *pOntbl;
	char  *p;
	tdtRbCtl *pCt;
	Leaf *leaf;
	tdtInfoParm **Obj0;
	tdtREDIRECT *red;
	MCAT2 *mcat2;
/*
printf("cl_scr_clear: Dummy=%08x [%s] called.\n",Dummy,Dummy->pId);
*/
	if (ADDRCHK(Dummy->ProCT)) {
/*
proc = Dummy->ProCT;
printf("cl_scr_clear: proc=%08x [%s] called.\n",proc,proc->ProcNM);
*/
		cl_prc_clear(Dummy->ProCT);
	}
	Dummy->ProCT = NULL;

	if (ADDRCHK(Dummy->Vary)) {
/*
printf("            [%s] start vary_clear.\n",Dummy->pId);
*/
		vary_clear(Dummy->Vary);
	}
	Dummy->Vary = NULL;
	if (Dummy->ONCOND) {
		for (i=0;i<Dummy->on_num_max;i++) {
			if (pOntbl = Dummy->ONCOND[i]) {
				for (j=0;j<4;j++) {
					if ((p=pOntbl->PrName[j])) Free(p);
				}
				Free (pOntbl);
			}
		}
		Free(Dummy->ONCOND);
		Dummy->ONCOND = NULL;
	}
	if ( ADDRCHK(Dummy->nextScCT) )  cl_scr_clear( Dummy->nextScCT );
	Dummy->nextScCT = NULL;
	if (!(Dummy->pFlag & D_LEAF_IMPORTMODE)) {
/*
printf("            [%s] pFlag=%02x\n",Dummy->pId,Dummy->pFlag);
*/
		if (Dummy->pFlag & D_LEAF_CACHED) cl_lru_scr_era(tpLruScrHead,Dummy->pId);
		else if (ADDRCHK(leaf=Dummy->TreeTop))  cl_leaf_clear(leaf);
	}
/*
printf("cl_scr_clear: Dummy->ConstCt=%08x\n",Dummy->ConstCt);
*/
	if (ADDRCHK(Dummy->ConstCt)) const_ct_clear(Dummy->ConstCt);

	if (pCt=Dummy->pListImport) {
		akxs_list_free(pCt,_free_const);
	}

	if (ADDRCHK(Dummy->Obj)) {
/*
printf("cl_scr_clear: Dummy->Obj=%08x\n",Dummy->Obj);
*/
		if (Obj0 = Dummy->Obj->Obj0) {
			if (Obj0[0]) Free(Obj0[0]);
			Free(Obj0);
		}
		Free(Dummy->Obj);
	}

	if (ADDRCHK(Dummy->ProcIndex)) {
		akxs_xhash_free(Dummy->ProcIndex);
	}
#if 0
	if (pCt=Dummy->pListExport) {
		akxs_list_free(pCt,NULL);
	}
#endif
	if (ADDRCHK(red=Dummy->redirect)) {
		if (Dummy->pFlag2 & D_PFLAG2_ALC_HDNM) {
			if (ADDRCHK(p=red->HereDoc_nm)) Free(p);
		}
		Free(red);
	}
#if 1	/* 2022.10.30 */
	if (ADDRCHK(mcat2=Dummy->pErrmsgOnce)) {
		if (p=mcat2->mc_bufp) Free(p);
		Free(mcat2);
	}
#endif
	Free(Dummy);
	return 0;
}

/***************************************************/
/*   �v���V�[�W���[�e�[�u���̍폜 (cl_prc_clear)   */
/***************************************************/
/* add 2001.1.12 Koba */
int cl_prc_ct_clear(proc)
ProcCT    *proc;
{
	BlockCB *pBlockCB,*wB;
	tdtInfoParm **Obj0,*pInfo;
	char *p,*cpKey;
	tdtREDIRECT *red;
	MCAT2 *mcat2;
	XHASHB *xha;
	int i,m,ih;

	if (!proc) return 0;
/*
printf("cl_prc_ct_clear: proc=%08x ProcNM=[%s]\n",proc,proc->ProcNM);
*/
	cl_tmp_const_ct_set(NULL);

	pBlockCB = proc->pTopBlockCB;
	while (pBlockCB) {
		if (pBlockCB->pEachParm) Free(pBlockCB->pEachParm);
		wB = pBlockCB->nextBlockCB;
		Free (pBlockCB);
		pBlockCB = wB;
	}
	proc->pTopBlockCB = NULL;
	if (proc->INPCB.parmtop) {
		Free(proc->INPCB.parmtop);
		proc->INPCB.parmtop = NULL;
	}

	akxs_rb_free(proc->pRetStack);

	if (xha=proc->pha_vnam) {
#if 1	/* 2023.8.9 */
		m = akxs_xhashn2(xha,'M',NULL,0,NULL);
		for (i=1;i<=m;i++) {
			xha->xha_xhix = i;
			if ((ih = akxs_xhashn2(xha,'P',&cpKey,0,&pInfo)) < 0) break;
			else if (ih > 0) {
/*
printf("cl_prc_ct_clear: cpKey=[%s] pi_id=[%c]\n",cpKey,pInfo->pi_id);
*/
				cl_free_info_parm(pInfo);
			}
		}
#endif
		akxs_xhash_free_opt(proc->pha_vnam,1);
	}
/*
	if (proc->pTBL_vnam) {
*/
		if (!(proc->pFlag & D_PFLAG_PARM_COPY)) cl_free_var_ent(proc->pTBL_pasento);
/*
		cl_free_var_ent(proc->pTBL_vnam);
		Free(proc->pTBL_vnam[0]);
		Free(proc->pTBL_vnam);
	}
*/
	if (ADDRCHK(p=proc->ProcNM)) Free(p);
	if (ADDRCHK(proc->pTmpConstCt)) const_ct_clear(proc->pTmpConstCt);
	if (ADDRCHK(proc->Obj)) {
		Obj0 = proc->Obj->Obj0;
		if (p=(char *)Obj0[0]) Free(p);
		Free(Obj0);
		Free(proc->Obj);
	}
	if (ADDRCHK(p=proc->ProcPath)) {
/*
printf("cl_prc_ct_clear: path=[%s]\n",p);
*/
		if (*p == '*') Free(p);
	}
	if (ADDRCHK(red=proc->redirect)) {
		if (proc->pFlag2 & D_PFLAG2_ALC_HDNM) {
			if (ADDRCHK(p=red->HereDoc_nm)) Free(p);
		}
		Free(red);
	}
	if (ADDRCHK(mcat2=proc->pImplicit)) akxs_mseq_free(mcat2);
	if (ADDRCHK(mcat2=proc->pro_pLabel)) akxs_mseq_free(mcat2);

	return 0;
}

int cl_prc_clear(Dummy)
ProcCT *Dummy;
{
/*
printf("cl_prc_clear: Dummy=%08x [%s] Dummy->nextPCT=%08x\n",Dummy,Dummy->ProcNM,Dummy->nextPCT);
*/
	if (ADDRCHK(Dummy->nextPCT)) {
		cl_prc_clear(Dummy->nextPCT);
		Dummy->nextPCT = NULL;
	}
	cl_prc_ct_clear(Dummy);
	Free(Dummy);
	return 0;
}

/**********************************************/
/*                                            */
/*             cl_leaf_clear                  */
/*--------------------------------------------*/
/*                                            */
/*         �@���[�t�e�[�u���̍폜             */
/*--------------------------------------------*/
/*                                            */
/**********************************************/
/*  */
int cl_leaf_clear(Dummy)
Leaf *Dummy;
{
	Leaf *leaf;
/*
if (ADDRCHK(Dummy)) printf("cl_leaf_clear: [%s]\n",cl_get_pcmd_line(Dummy));
*/
	if (ADDRCHK(leaf=Dummy->rightleaf)) cl_leaf_clear(leaf);
/*
else akxaxdump("ADDRCHK",Dummy,sizeof(Leaf));
*/
	if (ADDRCHK(leaf=Dummy->leftleaf))  cl_leaf_clear(leaf);
	Free(Dummy);

	return 0;
}

/**********************************************/
/*                                            */
/*              cl_rslt_clear                 */
/*--------------------------------------------*/
/*                                            */
/*         �������ʍ\���̂̍폜               */
/*--------------------------------------------*/
/*                                            */
/**********************************************/
/* */
int cl_rslt_clear( Dummy )
SearchResult *Dummy;
{
	cl_result_clear ( Dummy );
	Free ( Dummy );
	return ( 0 );
}

/***********************************************/
/*    �������ʍ\���̂̍폜  (cl_result_clear)  */
/***********************************************/

int cl_result_clear(Dummy)
SearchResult *Dummy;
{
	if ( ADDRCHK(Dummy->Next) ){
		cl_result_clear(Dummy->Next);
		Free(Dummy->Next);
		Dummy->Next = NULL;
	}
	if ( Dummy->szType[0] == 'F' ) {
		if ( Dummy->pzFileName ) Free(Dummy->pzFileName);
	}
	else if ( Dummy->szType[0] == 'B' ) {
		if ( Dummy->iIndex ) Free ( Dummy->iIndex - 2);
		if ( Dummy->RslBody ) Free ( Dummy->RslBody );
		if ( Dummy->pzFileName ) Free(Dummy->pzFileName);
	}
	if (Dummy->sAreaId) Free(Dummy->sAreaId);
	return 0;
}

/***********************************************/
/*      ���C�A�E�g�f�[�^�̏�����               */
/***********************************************/
/*   */

int cl_list_pac_clear(DummyA)
ListPacBody *DummyA ;
{
	if (ADDRCHK(DummyA)) {
		if (ADDRCHK(DummyA->mCat.mc_bufp)) Free(DummyA->mCat.mc_bufp);
	}
	return 0;
}

/******************************************************/
/*         �p�����[�^���X�g �̏�����                  */
/******************************************************/
int prm_list_clear(DummyE)
prmList *DummyE;
{
	if (DummyE->VarBD) Free(DummyE->VarBD);
	return 0;
}

int info_parm_clear(DummyE)
tdtInfoParm *DummyE;
{
	cl_free_info_parm(DummyE);
	memset(DummyE,0,sizeof(tdtInfoParm));
	return 0;
}

/*******************************************************/
/*           �ϐ��e�[�u���̏�����                      */
/*******************************************************/
int vary_clear(DummyF)
VarTBL *DummyF;
{
	char *p;
	cl_free_var_ent(DummyF->pTBL_igeta);
	cl_free_var_ent(DummyF->pTBL_pasento);
	cl_free_var_ent(DummyF->pTBL_dolu);

/*	cl_free_var_ent(DummyF->pTBL_vnam);	*/
	akxs_xhash_free_opt(DummyF->pha_vnam,1);

	p = (char *)DummyF->pTBL_dolu;
	if (p) {
		Free(DummyF->pTBL_dolu[0]);
		Free(p);
	}
	Free(DummyF);
	return 0;
}

/*******************************************************/
/*           CONSTANT�e�[�u���̏�����                  */
/*******************************************************/
int const_ct_clear(DummyG)
ConstantCt *DummyG;
{
	if (ADDRCHK(DummyG)) {
		akxm_cct_mem_free(DummyG);
	}
	return 0;
}

/********************************/
/*	�G���[���b�Z�[�W��̃N���A	*/
/********************************/
void errmsg_clear()
{
	if (!pGlobTable->exception) {
		pGlobTable->err_hist[0].parlen = 0;
		pGlobTable->err_hist[1].parlen = 0;
		*pGlobTable->errmsg = '\0';
	}
}
