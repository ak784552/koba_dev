static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*************************************************
 *
 *  akasys2.c
 *
 *        coded by A.Kobayashi 2002/3/27
 *
 *************************************************/
#include "akacommon.h"

extern tdtMSG_CTL         tMsgCtl;
extern int (*_pHPToEntry)();
extern int giAKA_CHANNEL_MAX;

tdtCLASS_CTLHead    tClassHead  = {0,0,NULL};

static char *nullstring="";
static char *nullname="(null)";

static void instance_free();
static void class_free();
static int  set_up_recv_proc_id();

void aka_wait_packet_free();
INT4 aka_get_pr_host_id();

/********************************************************/
/*                                                      */
/********************************************************/
int aka_registerClass(pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption)
int (*pFuncName)();
int  iClassId     ;
int  iInstanceDataSize;
int  iMaxThread   ;
int  iOption      ;
{
	return aka_registerClass3(pFuncName,iClassId,iInstanceDataSize,iMaxThread,
	                         iOption,nullname,NULL);
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_registerClass2(pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName)
int (*pFuncName)();
int  iClassId     ;
int  iInstanceDataSize;
int  iMaxThread   ;
int  iOption      ;
char *cpClassName ;
{
	return aka_registerClass3(pFuncName,iClassId,iInstanceDataSize,iMaxThread,
	                         iOption,cpClassName,NULL);
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_registerClass3(pFuncName,iClassId,iInstanceDataSize,iMaxThread,iOption,
                     cpClassName,cpUserArea)
int (*pFuncName)();	/* ���b�Z�[�W����������֐��ւ̃|�C���^ */
int  iClassId     ;	/* �����֐��̃N���X���ʔԍ�
                                0:	���ʃv���b�g�t�H�[���p�i�ݒ�s�j
                    65280 - 65535:	�b�o�e�R�}���h�p */
int  iInstanceDataSize;	/* �P�̏����Ŏg�p����ϐ��G���A�̃T�C�Y�i�o�C�g�j */
int  iMaxThread   ;	/* ���b�Z�[�W���������鑽�d�x�̍ő�l */
int  iOption      ;	/* ��P�r�b�g�@�P���ԐM�p�P�b�g���󂯂Ȃ� */
char *cpClassName;	/* �N���X���� */
char *cpUserArea;	/* ���[�U�̈� */
{
	tdtCLASS_CTL *curr,*next;
	tdtINSTANCE *tpIns;
	int i,ret,iFUNC2;

	if (tMsgCtl.sd<0) return -18502301;

	if (!(iOption & AKA_RCO_SYS_CLASS) && !pFuncName) {
		ERROROUT("�֐������m�t�k�k");
		return -18502302;
	}
	iFUNC2 = iClassId & AKA_CLASS_ADDFUNC2;
	iClassId &= ~AKA_CLASS_ADDFUNC2;
	if (iClassId<=0 || iClassId>AKA_CLASS_BASE) {
		ERROROUT("�N���X�h�c���͈͊O");
		return -18502303;
	}
	if (iInstanceDataSize<0) {
		ERROROUT("�C���X�^���X�f�[�^�T�C�Y����");
		return -18502304;
	}
#if 1	/* add 2002.9.27 Koba */
	if (iMaxThread<1 && !iFUNC2) {
#else
	if (iMaxThread<1) {
#endif
		if (tClassHead.max_thread_total<1) {
			ERROROUT("�s�n�s�`�k���d�x���P����");
			return -18502305;
		}
		iMaxThread = tClassHead.max_thread_total;
	}
	next = tClassHead.class;
	while (next) {
		curr = next;
		if (curr->class_id == iClassId) break;
		next = curr->class_next;
	}
	if (next) {
#if 1	/* add 2002.9.27 Koba */
		if (iFUNC2) {
			tpIns = next->instance;	/* 2008.10.31 Koba */
			if ((iInstanceDataSize > 0) || (iMaxThread > next->max_thread)) {
				if (tpIns) {
					for (i=0;i<next->max_thread;i++) aka_instance_buf_free(&tpIns[i]);
				}
				if (iMaxThread > next->max_thread) {
					if (tpIns) Free(tpIns);
					if (!(tpIns = (tdtINSTANCE *)Malloc(iMaxThread*
					                  sizeof(tdtINSTANCE)))) return -18502307;
					next->instance = tpIns;
					next->max_thread = iMaxThread;
				}
				for (i=0;i<next->max_thread;i++) {
					ret = aka_instance_init(0,&tpIns[i],
					 ((next->instance_data_size+15) & ~0x0f)+iInstanceDataSize);
					if (ret) return ret;
				}
			}
			if (iOption >= 0) next->option = iOption;
			next->func_name2 = pFuncName;
			if (cpClassName) next->class_name2 = Strdup(cpClassName);
			next->instance_data_size2 = iInstanceDataSize;
			tpIns[0].recv_msg_com->msg_disp = AKA_REGIST_CLASS;
			ret = pFuncName(iClassId,cpUserArea,tpIns[0].recv_msg_com);
			return ret;
		}
#endif
		if (next->instance)
			instance_free(next->instance,next->max_thread);
	}
	else {
#if 1	/* add 2002.9.27 Koba */
		if (iFUNC2) return -18502313;
#endif
		if (!(next=(tdtCLASS_CTL *)Malloc(sizeof(tdtCLASS_CTL)))) {
			return -18502306;
		}
		memset(next,0,sizeof(tdtCLASS_CTL));	/* add 2000.4.10 Koba */
		if (!tClassHead.class) tClassHead.class = next;
		else curr->class_next = next;
	}
	next->func_name         = pFuncName;
	next->class_id          = iClassId;
	next->instance_data_size = iInstanceDataSize;
	next->max_thread        = iMaxThread;
	next->option           = iOption;
/*	next->cpClassName       = cpClassName;	 add 2000.9.1 Koba */
	if (cpClassName) next->class_name = Strdup(cpClassName);
											/* add 2002.9.27 Koba */
/*** del 2000.4.10 Koba
	next->class_next       = NULL;
***/
	next->packet_number     = 0;
	next->used_count        = 0;
#ifdef TP_MON
	next->max_exec_thread   = next->max_thread;
	next->used_exec_count   = 0;
	if (!(next->msg_que = akxs_rb_init(0,0))) return -18502311;
#endif
	if (!(tpIns = (tdtINSTANCE *)Malloc(iMaxThread*sizeof(tdtINSTANCE)))) {
		return -18502307;
	}
	next->instance = tpIns;
	for (i=0;i<iMaxThread;i++) {
#if 0	/* del 2000.3.30 Koba */
		tpIns[i].used = 0;
		tpIns[i].wait_next = NULL;
		tpIns[i].to_free   = NULL;
#ifndef NO_RECVMSG
		if (!(tpIns[i].pRbToFree  = akxs_rb_init(0,0))) return -18502312;
#endif
		if (iInstanceDataSize>0) {
			if (!(tpIns[i].instance_data = Malloc(iInstanceDataSize))) {
				return -18502308;
			}
		}
		else tpIns[i].instance_data = NULL;
		if (!(tpIns[i].recv_msg_com =
		       (AKAMSGCOM *)Malloc(sizeof(AKAMSGCOM)+256*sizeof(char *)))) {
			return -18502309;
		}
		memset(tpIns[i].recv_msg_com,0,sizeof(AKAMSGCOM));
		if (!(tpIns[i].pack_head =
		        (tdtCOMM_PACK_HEAD *)Malloc(sizeof(tdtCOMM_PACK_HEADA)))) {
			return -18502310;
		}
#else
		if (ret = aka_instance_init(0, &tpIns[i], iInstanceDataSize)) return ret;
#endif
	}
	if (next->option & AKA_RCO_RECVPROC) {
		if (set_up_recv_proc_id(next,akb_log_get_proc_name()) < 0) return -18502313;
	}

	tpIns[0].recv_msg_com->msg_disp = AKA_REGIST_CLASS;
/*
printf("RegisterClass3: iClassId=%d cpUserArea=%08x\n",iClassId,cpUserArea);
if (cpUserArea) printf("                cpUserArea=[%s]\n",cpUserArea);
*/
	ret = pFuncName(iClassId,cpUserArea,tpIns[0].recv_msg_com);

	return ret;
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_instance_buf_free(tpIns)
tdtINSTANCE *tpIns;
{
	char *p;
	tdtWAIT_METHOD *pNext,*pWait;

	if (!tpIns) return -1;
	if (tpIns->instance_data) Free(tpIns->instance_data);
	aka_wait_packet_free(tpIns->wait_next);
	if (tpIns->recv_msg_com)   Free(tpIns->recv_msg_com);
	if (tpIns->pack_head)     Free(tpIns->pack_head);
	if (tpIns->to_free)       Free(tpIns->to_free);
	if (tpIns->rb_com_object) {
		while (p=akxs_rb_get_n(tpIns->rb_com_object)) aka_free_com_object_sub(p,0);
		akxs_rb_free(tpIns->rb_com_object);
	}
	if (tpIns->comment)      Free(tpIns->comment);
	pWait = tpIns->wait_method;
	while (pWait) {
		pNext = pWait->wait_method;
		Free(pWait);
		pWait = pNext;
	}
	return 0;
}

/********************************************************/
/*                                                      */
/********************************************************/
static void instance_free(tpIns,iMaxThread)
tdtINSTANCE *tpIns;
int         iMaxThread;
{
	int i;

	for (i=0;i<iMaxThread;i++) {
		aka_instance_buf_free(&tpIns[i]);
	}
	Free(tpIns);
}

/********************************************************/
/*                                                      */
/********************************************************/
static void	class_free(tpClass)
tdtCLASS_CTL *tpClass;
{
	if (tpClass) {
		class_free(tpClass->class_next);
		if (tpClass->class_name)  Free(tpClass->class_name);
		if (tpClass->class_name2) Free(tpClass->class_name2);
		if (tpClass->method) Free(tpClass->method);
		if (tpClass->instance)
			instance_free(tpClass->instance,tpClass->max_thread);
#ifdef TP_MON
		if (tpClass->msg_que) akxs_rb_free(tpClass->msg_que);
#endif
		Free (tpClass);
	}
}

/********************************************************/
/*                                                      */
/********************************************************/
void aka_wait_packet_free(tpWait)
tdtWAIT_PACKET *tpWait;
{
	if (tpWait) {
		aka_wait_packet_free(tpWait->wait_next);
		if (tpWait->wait_packet) Free(tpWait->wait_packet) ;
		Free(tpWait);
	}
}

/********************************************************/
/* iOpt = 0 : �N���A�Ɨ̈�m��                          */
/* iOpt = 1 : �N���A�̂�                                */
/* iOpt = 2 : �̈���m�ۂ��Ă��Ȃ�������m�ۂ���        */
/*             �N���A�͂��Ȃ�                           */
/********************************************************/
int aka_instance_init(iOpt, tpIns, iInstanceDataSize)
int         iOpt;
tdtINSTANCE *tpIns;
int         iInstanceDataSize;
{
	int iFlg;

	if (iOpt != 2) memset(tpIns,0,sizeof(tdtINSTANCE));
	if (iOpt == 1) return 0;
/***
	iFlg = 1;
	if (iOpt==2 && tpIns->rb_com_object) iFlg = 0;
	if (iFlg) {
		if (!(tpIns->rb_com_object = akxs_rb_init(0,0))) return -18503001;
	}
***/
	if (iInstanceDataSize>0) {
		iFlg = 1;
		if (iOpt==2 && tpIns->instance_data) iFlg = 0;
		if (iFlg) {
			if (!(tpIns->instance_data = Malloc(iInstanceDataSize))) {
				return -18503002;
			}
		}
	}
	iFlg = 1;
	if (iOpt==2 && tpIns->recv_msg_com) iFlg = 0;
	if (iFlg) {
		if (!(tpIns->recv_msg_com =
		       (AKAMSGCOM *)Malloc(sizeof(AKAMSGCOM)+256*sizeof(char *)))) {
			return -18503003;
		}
		memset(tpIns->recv_msg_com,0,sizeof(AKAMSGCOM));
	}
	iFlg = 1;
	if (iOpt==2 && tpIns->pack_head) iFlg = 0;
	if (iFlg) {
		if (!(tpIns->pack_head =
	   	     (tdtCOMM_PACK_HEAD *)Malloc(sizeof(tdtCOMM_PACK_HEADA)))) {
			return -18503004;
		}
		memset(tpIns->pack_head,0,sizeof(tdtCOMM_PACK_HEADA));
	}
	return 0;
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_conv_inst_hndl2(lInstanceHandle, tpInstHndl, iOpt)
long        lInstanceHandle;
tdtINST_HNDL *tpInstHndl;
int         iOpt;
{
	int             iThread,iClassId;
	tdtCLASS_CTL     *tpClass;
	tdtINSTANCE     *tpIns;
	tdtINST_HNDL2    *tpInstHndl2;

	if (!tpInstHndl) return -1;
	memset(tpInstHndl,0,sizeof(tdtINST_HNDL));
	if (lInstanceHandle) {
		/* �N���X�ƃX���b�h�m���̎��o�� */
#ifdef LINUX
		tpInstHndl->thread  = iThread  = (lInstanceHandle>>16) & 0xff;
		tpInstHndl->class_id = iClassId = lInstanceHandle & 0xffff;
#else
		tpInstHndl2 = (tdtINST_HNDL2 *)tpInstHndl;
		tpInstHndl2->instance_handle = lInstanceHandle;
		iThread  = tpInstHndl->thread;
		iClassId = tpInstHndl->class_id;
#endif
#ifdef DEBUG
printf("aka_conv_inst_hndl2: iClassId=%d iThread=%d\n",iClassId,iThread);
#endif
		if (iOpt & 0x10) {
/*
printf("aka_conv_inst_hndl2: call aka_srch_class2(%d,0x%02x)\n",
iClassId,iOpt & 0x01);
*/
			tpInstHndl->class = tpClass = aka_srch_class2(iClassId,iOpt & 0x01);
			if (!tpClass) return -2;
			if (iThread<1 || iThread>tpClass->max_thread) return -3;
			tpInstHndl->instance = tpIns = &tpClass->instance[iThread-1];
			if (!tpIns->used) return -4;
		}
	}
	return 0;
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_conv_inst_hndl(lInstanceHandle, tpInstHndl)
long        lInstanceHandle;
tdtINST_HNDL *tpInstHndl;
{
	return aka_conv_inst_hndl2(lInstanceHandle,tpInstHndl,0x11);
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_expand_tables(iAdd)
int iAdd;
{
	tdtRW_QUE         *pQue;
	tdtCHANNEL     *pCh;
	tdtCOMM_PACK_HEAD  *pHead;
	int iMax,iSize,i,n;
	tdtRWQ_TIME_OUT *p;
#if 0
	if (!tMsgCtl.read_que_pa)  {
		if (!(tMsgCtl.read_que_pa=
			(tdtRW_QUE **)(Malloc(n=sizeof(tdtRW_QUE **)*AKA_CHANNEL_MAX))))
			return -1;
		memset(tMsgCtl.read_que_pa,0,n);
	}
	if (!tMsgCtl.write_que_pa) {
		if (!(tMsgCtl.write_que_pa=
			(tdtRW_QUE **)(Malloc(n=sizeof(tdtRW_QUE **)*AKA_CHANNEL_MAX))))
			return -1;
		memset(tMsgCtl.write_que_pa,0,n);
	}
#endif
	if (!tMsgCtl.channel_pa)  {
		if (!(tMsgCtl.channel_pa=
			(tdtCHANNEL **)(Malloc(n=sizeof(tdtCHANNEL **)*giAKA_CHANNEL_MAX))))
			return -1;
		memset(tMsgCtl.channel_pa,0,n);
	}

	if (iAdd <= 0) return -1;
	iMax = tMsgCtl.channel_max;
	if (iMax >= giAKA_CHANNEL_MAX) return -18502902;
	iSize = iMax + iAdd;
	if (iSize >= giAKA_CHANNEL_MAX) {
		iSize = giAKA_CHANNEL_MAX;
		iAdd = iSize - iMax;
	}

	for (i=iMax;i<iSize;i++) {
#if 0
		/* �q�������L���[�Ǘ��e�[�u�� */
		if (!(pQue=akb_rwque_new(1,1))) goto Err;
		tMsgCtl.read_que_pa[i] = pQue;

		/* �v���������L���[�Ǘ��e�[�u�� */
		if (!(pQue=akb_rwque_new(1,1))) goto Err;
		tMsgCtl.write_que_pa[i] = pQue;
#endif
		/* �`���l���Ǘ��e�[�u�� */
		if (!(pCh=aka_channel_new(1))) goto Err;
		tMsgCtl.channel_pa[i] = pCh;
		pCh->index = i;
#ifndef NO_CHANNEL_QUE
		if (i > 0) {
			if (!(pCh->wpack_que = akxs_que_init(0,0))) {
				aka_channel_free(pCh,1);
				goto Err;
			}
		}
#endif
	}

/*
	tMsgCtl.iReadQueMax  = iSize;
	tMsgCtl.iWriteQueMax = iSize;
*/
	tMsgCtl.channel_max = iSize;

	if (p=tMsgCtl.rwqtime_out) {
	/*	p->pCloseSdFunc = _close_sd_func;	*/
		p->rwt_rqto.qto_qmax = tMsgCtl.channel_max;
		p->rwt_rqto.qto_ppqu   = tMsgCtl.read_que_pa;
		p->rwt_wqto.qto_qmax = tMsgCtl.channel_max;
		p->rwt_wqto.qto_ppqu   = tMsgCtl.write_que_pa;
		for (i=0;i<p->rwt_rqto.qto_qmax;i++)
			p->rwt_rqto.qto_ppqu[i]->rwq_wtime = p->rwt_rqto.qto_wait;
		for (i=0;i<p->rwt_wqto.qto_qmax;i++)
			p->rwt_wqto.qto_ppqu[i]->rwq_wtime = p->rwt_wqto.qto_wait;
	/*
		gtDataQueUsed.gd_dlen = sizeof(short);
		gtDataQueUsed.gd_scale = 0;
		gtDataQueUsed.gd_resv = 0;
		gtDataQueUsed.gd_data   = (char *)&tMsgCtl.channel_used;
		p->rwt_rqto.qto_used = &gtDataQueUsed;
		p->rwt_wqto.qto_used = &gtDataQueUsed;
	*/
		p->rwt_rqto.qto_used->gd_data = (char *)&tMsgCtl.channel_used;
	}

	return 0;
Err:
	akb_rwque_time_out_free(tMsgCtl.rwqtime_out);
	return -1;
}

/********************************************************/
/*                                                      */
/********************************************************/
int aka_init_zero(iSd)
int iSd;
{
	tdtRW_QUE     *pRQ,*pWQ;
	tdtCHANNEL *pCh;
	struct stat tStat;
	int fd;
#if 1
	/* �`���l���Ǘ��e�[�u�� */
	if (!(pCh=aka_channel_new(1))) -18503502;
	tMsgCtl.channel_pa[0] = pCh;
	pCh->index = 0;
	pCh->sys_opt |= AKA_CHSO_AKB_USED | AKA_CHSO_USE_AKB_HEAD;
	pCh->status = 1;
#else
	if (iSd < 0) return -18503501;
	if (!(pCh = tMsgCtl.channel_pa[0]))  return -18503502;
	if (!(pRQ = tMsgCtl.read_que_pa[0]))  return -18503503;
	if (!(pWQ = tMsgCtl.write_que_pa[0])) return -18503504;

	if (pRQ->rwq_sd>=0 || pWQ->rwq_sd>=0) return -18503505;

	tMsgCtl.sd = pCh->sd = iSd;
	if (!(fd=iSd)) {
		iSd = -1;
		if (!fstat(fd,&tStat)) {
			if (S_ISSOCK(tStat.st_mode)) iSd = 0;
		}
	}
	pRQ->rwq_sd = pWQ->rwq_sd = iSd;
	if (!tMsgCtl.host_id) tMsgCtl.host_id = tMsgCtl.my_host_id;

	if (tMsgCtl.host_id != tMsgCtl.my_host_id) {
		pRQ->rwq_option = AKB_RQUE_OPT_XTOF;
		pWQ->rwq_option = AKB_WQUE_OPT_MAKE_XPACK;
	}
	else {
		pRQ->rwq_option = AKB_RQUE_OPT_INDIR;
		pWQ->rwq_option = AKB_WQUE_OPT_MAKE_INDIR;
	}

	if (tMsgCtl.msg_opt & AKA_MSO_NEED_REPLY) {
		pRQ->rwq_option |= AKB_RWQUE_OPT_NEED_REPLY;
		pWQ->rwq_option |= AKB_RWQUE_OPT_NEED_REPLY;
	}
#endif
	return 0;
}

/********************************************************/
/*                                                      */
/********************************************************/
static int  set_up_recv_proc_id(tpClass,cpProcName)
tdtCLASS_CTL *tpClass;
char *cpProcName;
{
	int len,i,n,m;
	char buf[128],*argv[66],*parm[2],*namv[3];
	ushort *usR;

	if (len=strlen(cpProcName)) {
		if (len+2 <= sizeof(buf)) {
			sprintf(buf,"%s.%d",cpProcName,tpClass->class_id);
			namv[0] = D_SECTION_AKB_SYSTEM;
			namv[1] = "RECVPROC";
			namv[2] = buf;
			n = akb_gs_akb_stpl_func(namv,'.',
#if 1
			                     "4 2 3 1 ",argv,66,NULL,NULL);
#else
			                     "4-2-3-1-",argv,66,_setRecvProcId,tpClass);
#endif
			if (n < 0) return n;
			else if (n > 1) {
				if (!(usR = (ushort *)Malloc(n*2*sizeof(ushort))))
					return -1;
				tpClass->recv_proc_id = usR;
				usR += 2;
				for (i=1,m=0;i<n;i++,usR+=2) {
					akxtget2vsep(argv[i],parm,NULL,0,'-',0);
					usR[0] = atoi(parm[0]);
					usR[1] = atoi(parm[1]);
					if (!usR[1]) usR[1] = usR[0];
					if (!usR[0]) usR[0] = usR[1];
					if (usR[0] && usR[1]) m++;
/*
printf("set_up_recv_proc_id: m=%d usR[0]=%d usR[1]=%d\n",m,usR[0],usR[1]);
*/				}
				*(tpClass->recv_proc_id) = m;
			}
		}
	}
	return 0;
}
