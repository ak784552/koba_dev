static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
    cc -g -DLINUX -I../include testhasl.c libakx.a -o testhasl
*/
#include "akxcommon.h"

main()
{
	int n,i,ret,opt,*en,*fn;
	long key;
	char cmd[20],buf[128],c,*hkey[2];
	HASHB *ha;
	tdtHASL_CELL *cell,*ce;
	int max,pre;

	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl_new2(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	ha->ha_key = (char *)hkey;
	en = ha->ha_next;
	fn = en + max;
	cell = (tdtHASL_CELL *)ha->ha_reg;
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			ce = cell;
			printf(" i   en   fn flag   hkey next   data\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %4d %4d %4d %6d %4d %6d\n",
				       i,en[i],fn[i],ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
		/*	key = atoi(buf);	*/
			if (ret=akxcgcvn (buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') hkey[1] = (char *)buf[1];
				else {
				/*	ha->ha_nextp = (int *)atoi(buf);	*/
					if (ret=akxcgcvn (buf,strlen(buf),&n)) break;
					hkey[1] = (char *)n;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",hkey[1]);
			break;
		case 'k':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshaslk(ha,&key);
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,hkey[1]);
			}
			break;
		case 'p':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshaslp(ha);
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,*hkey[0],hkey[1]);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
