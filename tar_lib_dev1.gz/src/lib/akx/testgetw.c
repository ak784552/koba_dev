static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include testgetw.c akxcom.a -o testgetw
*/
#include <stdio.h>
#include <stdio.h>
main()
{
	char buf[256],wd[256];
	int n,pos,max,attr=0,opt;

	printf("Enter MAXCHECK==>");
	gets(buf);
	max=atoi(buf);
	printf("Enter opt==>");
	gets(buf);
	n=akxcgcvn (buf,strlen(buf),&opt);
	printf("ret=%d opt=%08x\n",n,opt);
	if (n) exit(0);
	for (;;) {
		printf("Enter==>");
		gets(buf);
		pos=0;
		while((n=akxtgetw3(buf, &pos, wd, max, &attr, opt))>=0) {
			printf("pos=%d n=%d wd=[%s] attr=%08x\n",pos,n,wd,attr);
		}
		printf("n=%d\n",n);
	/*	if (n<0) break;	*/
	}
}
