/*
    cc -DLINUX -I../include -c -O -S hashf2.c
*/
#include "akxcommon.h"

#define MULTI	AKX_HASX_MULTIPLIER2
static int lMULTIPLIER =MULTI;
static int lMULTIPLIER2=MULTI*MULTI;
static int lMULTIPLIER3=MULTI*MULTI*MULTI;
static int lMULTIPLIER4=MULTI*MULTI*MULTI*MULTI;

static int _hashf(kp,lklen,mso)
uchar *kp;
int lklen;
int mso;
{
	int i,j,k,n;
	uchar  uc,*p;
	uint  uk;
	int   mult=lMULTIPLIER;

	if (!lklen) return 1;

	p = kp + lklen - 1;
	n = 0;
	for (i=0;i<lklen-4;i+=5) {
		k = (*p--) * mult; k += *p--;
		k *= mult; k += *p--;
		k *= mult; k += *p--;
		k *= mult; k += *p--;
		n += k;
	}
	j = lklen - i;	/* 0 to 4 */
	if (j >= 3) {
		if (j >=4) {	/* 4 */
			k = (*p--) * mult; k += *p--;
			k *= mult; k += *p--;
			k *= mult; k += *p--;
			k *= mult;
		}
		else {			/* 3 */
			k = (*p--) * mult; k += *p--;
			k *= mult; k += *p--;
			k *= lMULTIPLIER2;
		}
	}
	else if (j >= 2) {	/* 2 */
		k = (*p--) * mult; k += *p--;
		k *= lMULTIPLIER3;
	}
	else if (j >=1 ) {	/* 1 */
		k = *p--;
		k *= lMULTIPLIER4;
	}
	n += k;
	uk=n;
	return (uk%mso+1);
}
