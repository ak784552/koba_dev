static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************
 *
 *	akxalog.c
 *
 *		  coded by A.Kobayashi 2010/04/04
 *
 *************************************************/
#include "akxcommon.h"

extern M_FILE *m_stdin,*m_stdout,*m_stderr;

/********************************************/
/*											*/
/********************************************/
int akx_get_log_time(buf,len,format)
char *buf,*format;
int  len;
{
	static int check=1,T=1;
	static char *FORM;
	time_t  tt;
	struct  tm *tm_str;

	if (!buf) return -1;
	if (len <= 0) return -2;
	tt=time(NULL);
	tm_str=localtime(&tt);
	if (check) {
		strftime(buf,len,"%T",tm_str);
		if (*buf) FORM = "%Y/%m/%d %T";
		else FORM = "%Y/%m/%d %H:%M:%S";
		check = 0;
	}
	if (!format) format = FORM;
	return strftime(buf,len,format,tm_str);
}

/********************************************/
/*											*/
/********************************************/
char *akx_log_time()
{
	static char buf[64];

	*buf = '\0';

	akx_get_log_time(buf,sizeof(buf),NULL);

	return buf;
}

/********************************************/
/*											*/
/********************************************/
tdtLOG_CTL_HEAD *akxa_log_new(iMax)
int iMax;
{
	tdtLOG_CTL_HEAD *tlh;
	tdtLOG_CTL     *tlc;
	int i;

	if (iMax <= 0) iMax = 10;
	if (!(tlh=(tdtLOG_CTL_HEAD *)Malloc(sizeof(tdtLOG_CTL_HEAD)))) return NULL;
	memset(tlh,0,sizeof(tdtLOG_CTL_HEAD));
	tlh->log_max = iMax;
	tlh->rb_ct_w  = akxs_rb_init(0,0);
	if (!(tlc=(tdtLOG_CTL *)Malloc(sizeof(tdtLOG_CTL)*iMax))) {
		akxa_log_free(tlh);
		return NULL;
	}
	memset(tlc,0,sizeof(tdtLOG_CTL)*iMax);
	tlh->log_ctl = tlc;
/*
printf("akxa_log_new:tlh=%08x tlc=%08x\n",tlh,tlc);
*/
	return tlh;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_free(tlh)
tdtLOG_CTL_HEAD *tlh;
{
	int i;
	tdtLOG_CTL *tlc,*tlc0;
	char *p;
	tdtRB_CTL *pRb;

	if (tlh) {
		if (p=tlh->log_dir) Free(p);
		if (p=tlh->proc_name) Free(p);
		if (pRb=tlh->rb_ct_w) akxs_rb_all_free(pRb);
		if (tlc0 = tlh->log_ctl) {
			tlc = tlc0;
			for (i=0;i<tlh->log_max;i++,tlc++) {
				if (p=tlc->log_file) Free(p);
				if (p=tlc->log_file_path) Free(p);
				if (pRb=tlc->rb_file) akxs_rb_all_free(pRb);
				if (pRb=tlc->rb_srch) akxs_rb_all_free(pRb);
			}
			Free(tlc0);
		}
		Free(tlh);
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
tdtLOG_CTL *akxa_log_get_ctl(tlh,i)
tdtLOG_CTL_HEAD *tlh;
int            i;
{
	if (!tlh) return NULL;
/*
printf("akxa_log_get_ctl:i=%d\n",i);
*/
	if (i<0 || i>=tlh->log_max) return NULL;
	return &tlh->log_ctl[i];
}

/********************************************/
/*											*/
/********************************************/
static int _compar(s,tlFL)
char *s;
tdtLOG_FILE_LINE *tlFL;
{
	char *p;
	int ret;

	if (!s || !tlFL) return -1;
	p = tlFL->lfl_file_name;
	if (!*p) return 0;
	ret = akxs_str_like(s,p);
/*
printf("_compar:akxs_str_like(s,p) ret=%d\n",ret);
*/
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int akxa_rot_size(rot,n,parm)
tdtROTATE_CTL *rot;
int n,parm[];
{

	if (n > 0) {
		if (parm[0] >= 0) rot->rot_size_max = parm[0];
		else parm[0] = rot->rot_size_max;
	}
	if (n > 1) {
		if (parm[1] >= 0) rot->rot_file_max = parm[1];
		else parm[1] = rot->rot_file_max;
	}
#ifdef OLD_CHECK_POINT	/* 2001.11.2 Koba */
	if (n > 2) {
		if (parm[2] >= 0) rot->rot_check_point = parm[2];
		else parm[2] = rot->rot_check_point;
	}
#else
	if (n > 2) {
		if (parm[2] >= 0) rot->rot_option = parm[2];
		else parm[2] = rot->rot_option;
	}
	if (n > 3) {
		parm[3] = rot->rot_file_no;
	}
	if (n > 4) {
		parm[4] = rot->rot_check_point;
	}
#endif
	return rot->rot_size_max;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_size(tlh,log_no,n,parm)
tdtLOG_CTL_HEAD *tlh;
int log_no,n,parm[];
{
	tdtLOG_CTL *tlc;

	if (!(tlc = akxa_log_get_ctl(tlh,log_no))) return -1;
	return akxa_rot_size(&tlc->log_rot,n,parm);
}

/********************************************/
/*											*/
/********************************************/
char *akxa_rotate(rot,fname)
tdtROTATE_CTL *rot;
char *fname;
{
	static char buf[256];
	char *p,*fn;
	int i,len,mt,opt,opt1,opt4,line;
	struct stat tStat;
	FILE *fp;

	opt = rot->rot_option;
	opt4 = opt & D_LOG_ROT_SIZE_LINE;
	if (opt4) rot->rot_count = 0;
	if (!fname || rot->rot_size_max <= 0) return fname;

	opt1 = opt & D_LOG_ROT_ROT_FILE;
	fn = fname;
	if (rot->rot_file_max > 0) {
		if ((len=strlen(fname)) >= sizeof(buf) - 12) return fn;
		memcpy(buf,fname,len+1);
		fn = buf;
		p = buf + len;
		if (!rot->rot_file_no) {	/* �t�@�C���m���̏����l�����߂� */
			if (opt1) rot->rot_file_no = 1;
			else rot->rot_file_no = rot->rot_file_max + 1;
			rot->rot_size = mt = 0;
			for (i=1;i<=rot->rot_file_max;i++) {
				sprintf(p,"%d",i);
				if (stat(fn,&tStat)) break;
/*
printf("akxa_rotate:i=%d time=%d size=%d\n",i,tStat.st_mtime,tStat.st_size);
*/
				if (tStat.st_mtime > mt) {
					mt = tStat.st_mtime;
					if (opt4) {
						if ((line = akxa_line_count(fn,0)) >= 0)
							rot->rot_size = line;
					}
					else rot->rot_size = tStat.st_size;
					rot->rot_file_no = i;
				}
			}
			if (opt4 && !opt1) {
				if ((line = akxa_line_count(fname,0)) >= 0) rot->rot_size = line;
			}
		}
		if (opt1) sprintf(p,"%d",rot->rot_file_no);
		else fn = fname;
	}

	if (opt4 || (++rot->rot_count >= rot->rot_check_point)) {
		if (opt4) {
			if (!(opt & D_LOG_ROT_NO_LINCR)) rot->rot_size++;
		}
		else {
			if (stat(fn,&tStat))
				rot->rot_size = 0;
			else
				rot->rot_size = tStat.st_size;
/*
printf("akxa_rotate:check point fn=[%s] size=%d\n",fn,rot->rot_size);
*/
			rot->rot_count = 0;
			if (rot->rot_size > rot->rot_size_max)
				rot->rot_check_point--;
			else if (rot->rot_size < (rot->rot_size_max*9)/10)
				rot->rot_check_point++;
		}
		if (rot->rot_size >= rot->rot_size_max) {	/* ���[�e�[�V�������s */
			if (rot->rot_file_max > 0) {
									/* ���ɑޔ�����t�@�C���m�������߂� */
				if (++rot->rot_file_no > rot->rot_file_max) {
					rot->rot_file_no = 1;
				}
				fn = buf;
				sprintf(p,"%d",rot->rot_file_no);
				if (!opt1) {
				/*	unlink(fn);	*/
					rename(fname,fn);
					fn = fname;
				}
			}
/*
printf("akxa_rotate:change fn=[%s] size=%d\n",fn,rot->rot_size);
*/
			if (fp = fopen(fn,"w")) {
				if (!(opt & D_LOG_ROT_NO_HEAD))
					fprintf(fp,"***** Change Time (%s) *****\n",akx_log_time());
				fclose(fp);
			}
			rot->rot_size = 0;
			if (opt4) {
				rot->rot_count = 1;
				if (!(opt & D_LOG_ROT_NO_LINCR)) rot->rot_size++;
			}
		}
	}
/*
printf("akxa_rotate:return fn=[%s]\n",fn);
*/
	return fn;
}

/********************************************/
/*  ���O�t���O�̃`�F�b�N                    */
/********************************************/
int akxa_log_flag_check(tdtLOG_CTL *tlc)
{
	int f;

	if (tlc) f = tlc->log_flg &
	    (D_LOG_FLG_STDOUT|D_LOG_FLG_STDERR|D_LOG_FLG_FILE|D_LOG_FLG_SYSLOG);
	else f = 0;
	return f;
}

/********************************************/
/*  ���O���x���ƃ��O�O���[�v�̃`�F�b�N      */
/********************************************/
int akxa_log_level_check(
tdtLOG_CTL *tlc, 
int group_level)
{
	int iLogLevel,group,level,iLogGrpMask,f;
	int i,chk_bit,lvl_mask;

	f = 0;
	if (tlc) {
		iLogLevel = tlc->log_level;
#if 0
		group = 1;
		if (iLogGrpMask=tlc->log_grp_mask) {
			if (group = level & iLogGrpMask) group &= iLogLevel;
			else group = 1;
		}
		lvl_mask = ~iLogGrpMask;
		level = group_level & lvl_mask;
		if (group && (iLogLevel & lvl_mask) >= level) f = 1;
#else
		level = group_level;
		if (iLogGrpMask=tlc->log_grp_mask) {
			lvl_mask = ~iLogGrpMask;
			group = level & iLogGrpMask;
			level &= lvl_mask;
			if (group) {
				if (group &= iLogLevel) {
/*
printf("akxa_log_level_check: group_level=%08x iLogGrpMask=%08x iLogLevel=%08x\n",group_level,iLogGrpMask,iLogLevel);
printf("akxa_log_level_check: group=%08x level=%d\n",group,level);
*/
					chk_bit = 0x40000000;
					for (i=1;i<=AKX_LOG_MAX_BITS-2;i++) {
						if (iLogGrpMask & chk_bit) {
							if ((group & chk_bit) && (tlc->log_lvll[i]>=level)) {
/*
printf("akxa_log_level_check: i=%d chk_bit=%08x lvll[i]=%d\n",i,chk_bit,tlc->log_lvll[i]);
*/
								f = 1;
								break;
							}
						}
						else break;
						chk_bit >>= 1;
					}
				}
			}
			else {
				if ((iLogLevel & lvl_mask) >= level) f = 1;
			}
		}
		else {
			if (iLogLevel >= level) f = 1;
		}
#endif
	}
	return f;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_out_check(tlc,level,file,line)
tdtLOG_CTL *tlc;
int  level,line;
char *file;
{
	tdtLOG_FILE_LINE *tlFL;
	tdtRB_CTL *pCt;
	int    iLogFlg,iLogLevel,line1,line2,disp,group;
	int    iLogGrpMask;
/*
printf("akxa_log_out_check:log_no=%d,level=%x,file=[%s],line=%d\n",
log_no,level,file,line);
*/
	/* ���O�t���O�̃`�F�b�N */
	if (!akxa_log_flag_check(tlc)) return 0;
	/* ���O���x���ƃ��O�O���[�v�̃`�F�b�N */
#if 1
	if (!akxa_log_level_check(tlc,level)) return 0;
#else
	iLogLevel = tlc->log_level;
	group = 1;
	if (iLogGrpMask=tlc->log_grp_mask) {
		if (group = level & iLogGrpMask) group &= iLogLevel;
		else group = 1;
	}
	level &= ~iLogGrpMask;
/*
printf("akxa_log_out_check:GrpMask=%x,level=%x,group=%x,set level=%d\n",
iLogGrpMask,level,group,iLogLevel & ~iLogGrpMask);
*/
	if (!group || (iLogLevel & ~iLogGrpMask) < level) return 0;
#endif
	/* �\�[�X�t�@�C���̍s���w��̃`�F�b�N */
	if (line>0 && (pCt=tlc->rb_file)) {
		disp = 1;
		akxs_rb_read(pCt,0);
		while (tlFL=(tdtLOG_FILE_LINE *)akxs_rb_read(pCt,1)) {
/*
printf("akxa_log_out_check:line1=%d,line2=%d,FileName=[%s]\n",
tlFL->lfl_line[0],tlFL->lfl_line[1],tlFL->lfl_file_name);
*/
			if (!_compar(file,tlFL)) {
				disp = 0;
				line1 = tlFL->lfl_line[0];
				line2 = tlFL->lfl_line[1];
				if (line1<=0 && line2<=0) disp = 1;
				else {
					if (line1 > line2) line2 = line1;
					if (line>=line1 && line<=line2) disp = 1;
				}
				if (disp) break;
			}
		}
		if (!disp) return 0;
	}
	return 1;
}

/********************************************/
/*											*/
/********************************************/
static char *_log_file_path(tlh,tlc,opt)
tdtLOG_CTL_HEAD *tlh;
tdtLOG_CTL *tlc;
int opt;
{
	static char *cpPath2=NULL,*cpPath3=NULL;
	static char buf[256];
	char  *cpPath, *log_file, *p;
	int   len;

	if (!(cpPath = tlc->log_file_path)) {
		if (log_file = tlc->log_file) {
			p = akxt_add_dir2(tlh->log_dir,log_file,&cpPath2);
			if (!p) p = log_file;
			cpPath = akxt_add_dir2(tlh->cur_dir,p,&cpPath3);
			if (!cpPath) cpPath = p;
			tlc->log_file_path = Strdup(cpPath);
			cpPath = tlc->log_file_path;
		}
	}
	if ((opt & 0x01) && (tlc->log_rot.rot_option & D_LOG_ROT_ROT_FILE) &&
	     tlc->log_rot.rot_size_max>0 && cpPath) {
		if ((len=strlen(cpPath)) >= sizeof(buf) - 12) return NULL;
		memcpy(buf,cpPath,len);
		sprintf(buf+len,"%d",tlc->log_rot.rot_file_no);
		cpPath = buf;
	}
	return cpPath;
}

/********************************************/
/*											*/
/********************************************/
char *akxa_log_file_path(tlh,log_no,opt)
tdtLOG_CTL_HEAD *tlh;
int log_no,opt;
{
	tdtLOG_CTL *tlc;

	if (!(tlc = akxa_log_get_ctl(tlh,log_no))) return NULL;
	return _log_file_path(tlh,tlc,opt);
}

/********************************************/
/*											*/
/********************************************/
static void _set_log_info(tlc,level,file,line,pri,nParm,av0)
tdtLOG_CTL *tlc;
char *file,*av0[];
int  level,line,pri,nParm;
{
	XHASHB *pha;
	char *format,*a1,*a2,*a3,*a4,*a5,*av[6];
	int i;
	long key[2];
	tdtLOG_INFO qInfo,*pInfo;

	if (!(pha=tlc->log_info)) {
		if (!(pha = akxs_xhash_new2(sizeof(long)*2,50,0,sizeof(tdtLOG_INFO)))) return;
		tlc->log_info = pha;
	}
	key[0] = line;
	key[1] = (long)file;
	if (!(i = akxs_xhash2(pha,'r',key,NULL))) {
		mem_set_addr(av,NULL,6);
		mem_cpy_addr(av,av0,nParm);
		qInfo.lgi_level = level;
		qInfo.lgi_line  = line;
		qInfo.lgi_pri   = pri;
		qInfo.lgi_file  = file;
		qInfo.lgi_format= av[0];
		qInfo.lgi_a1    = av[1];
		qInfo.lgi_a2    = av[2];
		qInfo.lgi_a3    = av[3];
		qInfo.lgi_a4    = av[4];
		qInfo.lgi_a5    = av[5];
		i = akxs_xhash2(pha,'s',key,&qInfo);
	}
}

/********************************************/
/*											*/
/********************************************/
int akxa_fvlog_out_level_pri_main(tlh,log_no,level,file,line,pri,fp,nParm,av)
tdtLOG_CTL_HEAD *tlh;
char *file,*av[];
int  log_no,level,line,pri,nParm;
FILE *fp;
{
	tdtLOG_CTL *tlc;
	char   *cpPath,*cpProc,*log_file;
	int    iLogFlg;
/*
printf("akxa_log_out_level_main:log_no=%d,level=%x,file=[%s],line=%d\n",
log_no,level,file,line);
*/
	if (!av[0]) return -1;
	if (!(tlc = akxa_log_get_ctl(tlh,log_no))) return -1;
	iLogFlg = tlc->log_flg;
	if (iLogFlg & D_LOG_FLG_OUT_INFO)
		_set_log_info(tlc,level,file,line,pri,nParm,av);

	if (iLogFlg & D_LOG_FLG_CHK_PRI) level = pri;
	if (akxa_log_out_check(tlc,level,file,line) <= 0) return 0;

	/* ���O�o�̓t�@�C�����̍쐬 */
	cpPath = NULL;
	if (iLogFlg & D_LOG_FLG_FILE) {
		cpPath = _log_file_path(tlh,tlc,0);
		cpPath = akxa_rotate(&tlc->log_rot,cpPath);
	}
	cpProc  = tlh->proc_name;
	return akxa_fvlog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,fp,nParm,av);
}

/********************************************/
/*											*/
/********************************************/
int akxa_vlog_out_level_pri_main
    (tlh,log_no,level,file,line,pri,nParm,av)
tdtLOG_CTL_HEAD *tlh;
char *file,*av[];
int  log_no,level,line,pri,nParm;
{
	return akxa_fvlog_out_level_pri_main(tlh,log_no,level,file,line,pri,NULL,nParm,av);
}

/********************************************/
/*											*/
/********************************************/
int akxa_vlog_out_level_main(tlh,log_no,level,file,line,nParm,av)
tdtLOG_CTL_HEAD *tlh;
char *file,*av[];
int  log_no,level,line,nParm;
{
	return akxa_vlog_out_level_pri_main(tlh,log_no,level,file,line,0,nParm,av);
}

/********************************************/
/*											*/
/********************************************/
int akxa_flog_out_level_pri_main
    (tlh,log_no,level,file,line,pri,fp,format,a1,a2,a3,a4,a5)
tdtLOG_CTL_HEAD *tlh;
char *file,*format,*a1,*a2,*a3,*a4,*a5;
int  log_no,level,line,pri;
FILE *fp;
{
	int nParm;
	char *av[6];

	nParm = 6;
	av[0] = format;
	av[1] = a1;
	av[2] = a2;
	av[3] = a3;
	av[4] = a4;
	av[5] = a5;
	return akxa_fvlog_out_level_pri_main(tlh,log_no,level,file,line,pri,fp,nParm,av);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_out_level_pri_main
    (tlh,log_no,level,file,line,pri,format,a1,a2,a3,a4,a5)
tdtLOG_CTL_HEAD *tlh;
char *file,*format,*a1,*a2,*a3,*a4,*a5;
int  log_no,level,line,pri;
{
	return akxa_flog_out_level_pri_main
	    (tlh,log_no,level,file,line,pri,NULL,format,a1,a2,a3,a4,a5);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_out_level_main(tlh,log_no,level,file,line,format,a1,a2,a3,a4,a5)
tdtLOG_CTL_HEAD *tlh;
char *file,*format,*a1,*a2,*a3,*a4,*a5;
int  log_no,level,line;
{
	return akxa_log_out_level_pri_main
	       (tlh,log_no,level,file,line,0,format,a1,a2,a3,a4,a5);
}

/********************************************/
/*											*/
/********************************************/
static int _pri2syspri(pri)
int pri;
{
	static struct {
		int priority;
		int syspri;
	} *ptbl,tbl[]=
		{AKX_LOG_EMERG  ,LOG_EMERG
		,AKX_LOG_ALERT  ,LOG_ALERT
		,AKX_LOG_CRIT   ,LOG_CRIT
		,AKX_LOG_ERR    ,LOG_ERR
		,AKX_LOG_WARNING,LOG_WARNING
		,AKX_LOG_NOTICE ,LOG_NOTICE
		,AKX_LOG_INFO   ,LOG_INFO
		,AKX_LOG_DEBUG  ,LOG_DEBUG
		,0 ,LOG_DEBUG+1};
	int i;

	ptbl = tbl;
	while (i=ptbl->priority) {
		if (pri >= i) {
			i = ptbl->syspri;
			break;
		}
		ptbl++;
	}
	if (!i) i = LOG_DEBUG+1;
	return i;
}

/********************************************/
/*											*/
/********************************************/
static char *_priority(pri)
int pri;
{
	static struct {
		int priority;
		char *msg;
	} *ptbl,tbl[]=
		{LOG_EMERG  ,"EMERG"
		,LOG_ALERT  ,"ALERT"
		,LOG_CRIT   ,"CRIT"
		,LOG_ERR    ,"ERROR"
		,LOG_WARNING,"WARNING"
		,LOG_NOTICE ,"NOTICE"
		,LOG_INFO   ,"INFO"
		,LOG_DEBUG  ,"DEBUG"
		,0          ,NULL};
	char *p;

	ptbl = tbl;
	while (p=ptbl->msg) {
		if (pri == ptbl->priority) break;
		ptbl++;
	}
	if (!p) p = "null";
	return p;
}

/********************************************/
/*											*/
/********************************************/
static void _new_line(fp,iLogFlg)
FILE *fp;
int iLogFlg;
{
/*
printf("_new_line: flg=%08x\n",iLogFlg);
*/
	akxa_log_new_line(fp,(iLogFlg>>12) & 0x07);
}

/********************************************/
/*											*/
/********************************************/
static void _new_line_m(fp,iLogFlg)
M_FILE *fp;
int iLogFlg;
{
/*
printf("_new_line_m: flg=%08x\n",iLogFlg);
*/
/*	akxa_log_new_line_m(fp,(iLogFlg>>12) | (iLogFlg & D_LOG_FLG_STDOUT2MEM));	*/
	akxa_log_new_line_m(fp,(iLogFlg>>12) & 0x07);
}

/********************************************/
/*											*/
/********************************************/
static int _log_chk_format_str(format,iParm,nParm)
char *format;
int iParm[],nParm;
{
	char *p,*pp,c;
	int i,len,ii,disp,ret,n,k,sc;
/*
printf("_log_chk_format_str: format=[%s]\n",format);
*/
	if (!format) return -1;
	mem_set_int(iParm,0,nParm+1);
	p = format;
	k = ret = ii = 0;
	disp = 0;
	len = strlen(format);
	while (len > 0) {
		n = akxqkanjilen2(p,len);
		if (n == 1) {
			c = *p;
			if (disp == 0) {
				if (c == '%') {
					ii++;
					disp = 1;
				}
			}
			else {
				if (c=='s' || c=='c' || c=='f' || c=='e' || c=='g' || c=='G') {
/*
printf("_log_chk_format_str: ii=%d\n",ii);
*/
					disp = 0;
					if (c == 's') sc = 1;
					else if (c == 'c') sc = -1;
					else sc = 3;
					iParm[ii] = sc;
/*
printf("_log_chk_format_str: ii=%d sc=%d\n",ii,sc);
*/
					ret++;
					if (ii >= nParm) break;
				}
				else if (c=='.' || (c>='0' && c<='9')) ;
				else disp = 0;
			}
		}
		else {
			k = 1;
			disp = 0;
		}
/*
printf("_log_chk_format_str: n=%d\n",n);
*/
		p += n;
		len -= n;
	}
	iParm[0] = k;
	if (k) ret++;
/*
printf("_log_chk_format_str: ret=%d k=%d\n",ret,k);
*/
	return ret;
}

/********************************************/
/*											*/
/********************************************/
static void _log_str_conv_free(nav,av0,av,iParm)
int nav,iParm[];
char *av0[],*av[];
{
	int i;

	for (i=0;i<nav;i++) {
		if (iParm[i]==1 && av0[i]!=av[i]) {
/*
printf("_log_str_conv_free: av[%d]=%08x\n",i,av[i]);
*/
			Free(av[i]);
		}
	}
}

/********************************************/
/*											*/
/********************************************/
static int akxa_log_fprintf(mfp,iLogFlg,cpProc,file,line,nStr,iParm,nParm,av0,opt)
M_FILE *mfp;
char *cpProc,*file,*av0[];
int  iLogFlg,line,nStr,iParm[],nParm,opt;
{
	char **av,*p,*pp,*format;
	int ret,len,max_lne,iSTDOUT2MEM,max_len;
	MCAT *mcat;
	FILE *fp;
/*
printf("akxa_log_fprintf: mfp=%08x iLogFlg=%08x file=[%s] file line=%d format=[%s]\n",
mfp,iLogFlg,file,line,av0[0]);
*/
/*	if (!(format=av0[0])) return -1;	*/
	if (nParm > 0) format = av0[0];
	else format = NULL;
#if 1
	if ((ret=m_file_valid(mfp)) < 0) {
		if (ret != -2) return ret;
	}
	if (ret == -2) {
		fp = (FILE *)mfp;
		mcat = NULL;
	}
	else {
		fp = mfp->m_fp;
		mcat = mfp->m_mcat;
	}
	if (!(av=(char **)Malloc(sizeof(char **)*nParm))) return -1;
	mem_cpy_addr(av,av0,nParm);
	if (mcat) {
#else
	iSTDOUT2MEM = iLogFlg & D_LOG_FLG_STDOUT2MEM;
	if (iSTDOUT2MEM && (iLogFlg & D_LOG_FLG_STDOUT)) {
		mcat = (MCAT *)fp;
#endif
		max_len = 0;
		if (*cpProc && !(iLogFlg & D_LOG_FLG_NO_PROC))
			max_len = strlen(cpProc) + 3;
		else if (!(iLogFlg & D_LOG_FLG_NO_SRC))
			max_len = strlen(file) + 15;
		if (format) {
			len = akxa_log_printf_len(NULL,0,format,nParm-1,av+1);
			if (len > max_len) max_len = len;
		}
		p = Malloc(max_len+1);
		if (*cpProc && !(iLogFlg & D_LOG_FLG_NO_PROC))
			sprintf(p,"[%s] ",cpProc);
		else if (!(iLogFlg & D_LOG_FLG_NO_SRC))
			sprintf(p,"%s(%d): ",file,line);
		akxtmcats(mcat,p);
		if (format) {
		/*	sprintf(p,av0[0],av0[1],av0[2],av0[3],av0[4],av0[5]);	*/
			pp = akxa_fsprintfv(NULL,av[0],nParm-1,av+1,opt & CD_TYPE_CODE);
			akxtmcats(mcat,pp);
		}
		Free(p);
		_new_line_m(mfp,iLogFlg);
	}
	else {
		if (*cpProc && !(iLogFlg & D_LOG_FLG_NO_PROC))
			fprintf(fp,"[%s] ", cpProc);
		else if (!(iLogFlg & D_LOG_FLG_NO_SRC))
			fprintf(fp,"%s(%d): ",file,line);
		if (format) {
			if (nStr && (opt & CD_OUTPUT_MASK)) {
				ret = akxa_log_str_conv(iParm,nParm,av0,av,opt);
			}
			else mem_cpy_addr(av,av0,nParm);
		/*	fprintf(fp,av[0],av[1],av[2],av[3],av[4],av[5]);	*/
			akxa_fsprintfv(fp,av[0],nParm-1,av+1,opt & CD_TYPE_CODE);
			if (nStr && (opt & CD_OUTPUT_MASK)) {
				_log_str_conv_free(nParm,av0,av,iParm);
			}
		}
		_new_line(fp,iLogFlg);
	}
/*	_new_line(fp,iLogFlg);	*/
	return 0;
}

#define AKX_TMP_DIR	"/tmp"
/********************************************/
/*											*/
/********************************************/
int akxa_fvlog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,fo,nParm,av0)
char *cpPath,*cpProc,*file,*av0[];
int  iLogFlg,line,pri,nParm;
FILE *fo;
{
	FILE *fp;
	char *buf,work[256],*p,**av,*s,*format,*p1=NULL;
	int  len,i,colon=0,syspri,opt,*iParm,nStr,ret;
	struct stat tStat;
	static int error_count=0;
/*
printf("akxa_flog_out_pri: cpPath=[%s] iLogFlg=%08x cpProc=[%s] file=[%s] file line=%d pri=%d nParm=%d\n format=[%s] file\n",
cpPath,iLogFlg,cpProc,file,line,pri,nParm,av0[0]);
*/
/*	if (!(format=av[0])) return -1;	*/
	if (!cpProc) cpProc = "";
	if (!file) file = "";

	if (!fo) {
		if (iLogFlg & D_LOG_FLG_STDOUT) fo = (FILE *)m_stdout;
		else if (iLogFlg & D_LOG_FLG_STDERR) fo = (FILE *)m_stderr;	/* add else 2023.1.3 */
	}

	opt = (iLogFlg>>16) & CD_OUTPUT_MASK;
	if (iLogFlg & D_LOG_FLG_USE_CODE_CONV) opt |= CD_USE_CODE_CONV;

	if (nParm > 0) format = av0[0];
	else format = NULL;
/*	if (akxmemwork(nParm*sizeof(int),&iParm,&p1,wrk,sizeof(wrk)) < 0) return -1;	*/
	if (!(iParm = (int *)Malloc(sizeof(int)*nParm))) return -1;
	nStr = _log_chk_format_str(format,iParm,nParm-1);

	syspri = _pri2syspri(pri);
	if (cpPath) {
		p = cpPath;
		fp = fopen(cpPath, "a");
		if (!fp) {
			len = strlen(cpPath);
			p = cpPath + len - 1;
			for (i=0;i<len;i++) {
				if (*p == '/') break;
				p--;
			}
			p++;
			sprintf(work,"%s/x_%s",AKX_TMP_DIR,p);
			fp = fopen(work, "a");
			p = work;
			if (!error_count && fp) {
				fprintf(fp,"*** open error file = [%s]\n",cpPath);
			}
			if (++error_count > 20) error_count = 0;
		}
		if (fp) {
			if (!(iLogFlg & D_LOG_FLG_NO_TIME)) {
				buf = akx_log_time();
				if (*buf){
					fprintf(fp,"%s ",buf);
				}
			}
			if (!(iLogFlg & D_LOG_FLG_NO_SRC)) {
				fprintf(fp, "%s/%s(%d)", cpProc, file, line);
				colon = 1;
			}
			else if (!(iLogFlg & D_LOG_FLG_NO_PROC)) {
				fprintf(fp, "%s", cpProc);
				colon = 1;
			}
			if (iLogFlg & D_LOG_FLG_PRIORITY) {
				fprintf(fp, "<%s>", _priority(syspri));
				colon = 1;
			}
			if (colon) fprintf(fp, ": ");
			if (format) {
				if (av=(char **)Malloc(sizeof(char **)*nParm)) {
					if (nStr) {
						ret = akxa_log_str_conv(iParm,nParm,av0,av,opt|CD_FILE_CODE_CONV);
					}
					else mem_cpy_addr(av,av0,nParm);
				/*	fprintf(fp,av[0],av[1],av[2],av[3],av[4],av[5]);	*/
					akxa_fsprintfv(fp,av[0],nParm-1,av+1,(opt>>4) & CD_TYPE_CODE);
					if (nStr) {
						_log_str_conv_free(nParm,av0,av,iParm);
					}
					Free(av);
				}
			}
		/*	_new_line(fp,iLogFlg & ~D_LOG_FLG_STDOUT2MEM);	*/
			_new_line(fp,iLogFlg);
			fclose(fp);
			if (!stat(p,&tStat)) {
				tStat.st_mode |= (S_IWGRP | S_IWOTH);
				chmod(p,tStat.st_mode);
			}
		}
	}
	if (fo) {
#if 1	/* 2022.10.10 */
		akxa_log_fprintf(fo,iLogFlg,cpProc,file,line,nStr,iParm,nParm,av0,opt);
#else
		if (*cpProc && !(iLogFlg & D_LOG_FLG_NO_PROC))
			fprintf(fo,"[%s] ", cpProc);
		else if (!(iLogFlg & D_LOG_FLG_NO_SRC))
			fprintf(fo,"%s(%d): ", file, line);
		if (format) {
			if (nStr && (opt & CD_OUTPUT_MASK)) {
				ret = akxa_log_str_conv(iParm,nParm,av0,av,opt);
			}
			else mem_cpy_addr(av,av0,nParm);
			fprintf(fo,av[0],av[1],av[2],av[3],av[4],av[5]);
			if (nStr) _log_str_conv_free(nParm,av0,av,iParm);
		}
		_new_line(fo,iLogFlg);
#endif
	}
	if ((iLogFlg & D_LOG_FLG_SYSLOG) &&
	    (strlen(cpProc)+strlen(file)+strlen(format)+15 < sizeof(work))) {
		if (!(iLogFlg & D_LOG_FLG_NO_SRC))
			sprintf(work,"%s/%s(%d): ", cpProc, file, line);
		else if (!(iLogFlg & D_LOG_FLG_NO_PROC))
			sprintf(work,"%s: ", cpProc);
		if (format) {
			strcat(work,format);
		/*	syslog(syspri,work,a1,a2,a3,a4,a5);	*/
			s = akxa_fsprintfv(NULL,work,nParm-1,av0+1,opt & CD_TYPE_CODE);
		}
		else s = work;
		syslog(syspri,"%s",s);
	}
	
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int akxa_flog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,fo,format,a1,a2,a3,a4,a5)
char *cpPath,*cpProc,*file,*format,*a1,*a2,*a3,*a4,*a5;
int  iLogFlg,line,pri;
FILE *fo;
{
	char **av;
	int nParm,rc;

	rc = 0;
	nParm = 6;
	if (av=(char **)Malloc(nParm*sizeof(char **))) {
		av[0] = format;
		av[1] = a1;
		av[2] = a2;
		av[3] = a3;
		av[4] = a4;
		av[5] = a5;
		rc = akxa_fvlog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,fo,nParm,av);
		Free(av);
	}
	else rc = -1;
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int akxa_vlog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,nParm,av)
char *cpPath,*cpProc,*file,*av[];
int  iLogFlg,line,pri,nParm;
{
	return akxa_fvlog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,NULL,nParm,av);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,format,a1,a2,a3,a4,a5)
char *cpPath,*cpProc,*file,*format,*a1,*a2,*a3,*a4,*a5;
int  iLogFlg,line,pri;
{
	return akxa_flog_out_pri(cpPath,iLogFlg,cpProc,file,line,pri,NULL,format,a1,a2,a3,a4,a5);
}

/********************************************/
/*											*/
/********************************************/
int akxa_vlog_out(cpPath,iLogFlg,cpProc,file,line,nParm,av)
char *cpPath,*cpProc,*file,*av[];
int  iLogFlg,line,nParm;
{
	return akxa_vlog_out_pri(cpPath,iLogFlg,cpProc,file,line,0,nParm,av);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_out(cpPath,iLogFlg,cpProc,file,line,format,a1,a2,a3,a4,a5)
char *cpPath,*cpProc,*file,*format,*a1,*a2,*a3,*a4,*a5;
int  iLogFlg,line;
{
	return akxa_log_out_pri(cpPath,iLogFlg,cpProc,file,line,0,
	                     format,a1,a2,a3,a4,a5);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_str_conv(iParm,n,argv0,argv,opt)
char *argv0[],*argv[];
int iParm[],n,opt;
{
	char *p,*pp;
	int i,ret,sc;
/*
printf("akxa_log_str_conv: opt=%08x\n",opt);
*/
	if (opt & CD_FILE_CODE_CONV) opt = (opt>>4) & 0x0f0f | (opt & CD_USE_CODE_CONV);
	ret = 0;
	for (i=0;i<n;i++) {
		argv[i] = argv0[i];
/*
printf("akxa_log_str_conv: argv0[%d]=%08x \n",i,argv0[i]);
*/
		if (sc=iParm[i]) {
/*
printf("akxa_log_str_conv: i=%d argv0=%08x [%s]\n",i,argv0[i],argv0[i]);
*/
			if (p = argv0[i]) {
				if (sc == 1) {
					ret = akxc_file_code_conv(&pp,p,strlen(p),1,opt);
					if (ret >= 0) argv[i] = pp;
/*
printf("akxa_log_str_conv: i=%d ret=%d p=[%s] pp=[%s] \n",i,ret,p,pp);
*/
/*
if (p != pp)
printf("akxa_log_str_conv: i=%d ret=%d p=%08x pp=%08x \n",i,ret,p,pp);
*/
				}
			}
		/*	else if (sc<0 && !p) memset(&argv[i],'_',sizeof(char *));	*/
		}
	}
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_flg(tlh,i,f)
tdtLOG_CTL_HEAD *tlh;
int i,f;
{
	tdtLOG_CTL *tlc;

	if (!(tlc = akxa_log_get_ctl(tlh,i))) return -1;
	if (f >= 0) tlc->log_flg = f;

	return tlc->log_flg;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_set_proc_name(tlh,cpName)
tdtLOG_CTL_HEAD *tlh;
char *cpName;
{
	int len;
	char *p;

	if (!tlh) return -1;
	p = tlh->proc_name;
	if (!cpName) {
		if (p) {
			Free(p);
			tlh->proc_name = NULL;
		}
		return 0;
	}
	len = strlen(cpName) + 1;
	if (p) {
		p=Realloc(p,len);
	}
	else {
		p=Malloc(len);
	}
	if (p) {
		strcpy(p,cpName);
		tlh->proc_name = p;
	}
	else return -2;
	return 0;
}

/********************************************/
/*											*/
/********************************************/
char *akxa_log_get_proc_name(tlh)
tdtLOG_CTL_HEAD *tlh;
{
	if (!tlh) return NULL;
	return tlh->proc_name;
}

/********************************************/
/*											*/
/********************************************/
static int _log_file_path_free(tlc)
tdtLOG_CTL *tlc;
{
	char *p;

	if (!tlc) return -1;
	if (p=tlc->log_file_path) {
		Free(p);
		tlc->log_file_path = NULL;
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_file_path_free_all(tlh)
tdtLOG_CTL_HEAD *tlh;
{
	int i;
	tdtLOG_CTL *tlc;

	if (!tlh) return -1;
	for (i=0;i<tlh->log_max;i++) {
		if (tlc = akxa_log_get_ctl(tlh,i)) _log_file_path_free(tlc);
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
char *akxa_log_set_file_name(tlh, i, cpFile)
tdtLOG_CTL_HEAD *tlh;
int  i;
char *cpFile;
{
	int len;
	char *p=NULL;
	tdtLOG_CTL *tlc;

	if (tlc = akxa_log_get_ctl(tlh,i)) {
		p = tlc->log_file;
		if (cpFile) {
			len = strlen(cpFile) + 1 + 8;
			if (p) {
				p = Realloc(p,len);
			}
			else {
				p = Malloc(len);
			}
			if (p) {
				strcpy(p,cpFile);
				tlc->log_file = p;
			}
			_log_file_path_free(tlc);
		}
	}

	return p;
}

/********************************************/
/*											*/
/********************************************/
char *akxa_log_set_dir(tlh,cpDir)
tdtLOG_CTL_HEAD *tlh;
char *cpDir;
{
	int len;
	char *p;

	if (!tlh) return NULL;
	p = tlh->log_dir;
	if (cpDir) {
		len = strlen(cpDir) + 1;
		if (p) {
			p = Realloc(p,len);
		}
		else {
			p = Malloc(len);
		}
		if (p) {
			strcpy(p,cpDir);
			tlh->log_dir = p;
		}
		akxa_log_file_path_free_all(tlh);
	}

	return p;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_group_level(tlh, log_no, flg, iLevel)
tdtLOG_CTL_HEAD *tlh;
int log_no,flg,iLevel;
{
	tdtLOG_CTL *tlc;
	int level,group=0,i,chk_bit,grp_mask,lvl_mask;

	if (!(tlc = akxa_log_get_ctl(tlh,log_no))) return -1;
	if (flg) {
		grp_mask = tlc->log_grp_mask;
		lvl_mask = ~grp_mask;
		group = tlc->log_level & grp_mask;
		level = tlc->log_level & lvl_mask;
		if (flg & 0x02) group = iLevel & grp_mask;
		if (flg & 0x01) {
			level = iLevel & lvl_mask;
#if 1
			tlc->log_lvll[0] = level;
			chk_bit = 0x40000000;
			for (i=1;i<=AKX_LOG_MAX_BITS-2;i++) {
				if (grp_mask & chk_bit) {
					if (group & chk_bit) tlc->log_lvll[i] = level;
				}
				else break;
				chk_bit >>= 1;
			}
#endif
		}
/*
printf("akxa_log_group_level: log_no=%d group=%08x level=%d\n",log_no,group,level);
*/
		tlc->log_level = group | level;
	}
	return tlc->log_level;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_level(tlh, i,level)
tdtLOG_CTL_HEAD *tlh;
int i,level;
{
	tdtLOG_CTL *tlc;
	int flg,ret;

	if (level < 0) flg = 0;
	else flg = 3;
	return akxa_log_group_level(tlh, i, flg, level);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_grp_mask(tlh, i, levelbitc)
tdtLOG_CTL_HEAD *tlh;
int i, levelbitc;
{
	tdtLOG_CTL *tlc;

	if (!(tlc = akxa_log_get_ctl(tlh,i))) return -1;
	if (levelbitc>0 && levelbitc<AKX_LOG_MAX_BITS) {
		tlc->log_grp_mask = (0xffffffff << levelbitc) & 0x7fffffff;
	}
	else if (levelbitc == AKX_LOG_MAX_BITS) tlc->log_grp_mask = 0;

	return tlc->log_grp_mask;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_set_src_file(tlh,pCtChg,logno,ope,setno,file,line1,line2)
tdtLOG_CTL_HEAD *tlh;
tdtRB_CTL *pCtChg;
char *file;
int  logno,ope,setno,line1,line2;
{
	tdtLOG_CTL *tlc;
	tdtLOG_FILE_LINE *tlFL;
	tdtRB_CTL *pCt,*pCtW;
	char *p;
	int count=0,len,unmatch,no;
	char *buf;

	tlc = akxa_log_get_ctl(tlh,logno);
	if (!tlc) return -1;
	no = 0;
	if (ope < 0) {	/* del */
		if (!(pCt=tlc->rb_file)) return 0;
		while (tlFL=(tdtLOG_FILE_LINE *)akxs_rb_get_n(pCt)) {
			no++;
			unmatch = 0;
			if (setno > 0) {
				if (no != setno) unmatch = 1;
			}
			else if (file) {
				if (*file) unmatch = strcmp(file,tlFL->lfl_file_name);
			}
			if (!unmatch) {
				count++;
				if (pCtChg) {
					tlFL->lfl_ope = ope;
					tlFL->lfl_no = no;
					akxs_rb_set_n(pCtChg,tlFL);
				}
				else Free(tlFL);
			}
			else
				akxs_rb_set_n(tlh->rb_ct_w,tlFL);
		}
		tlc->rb_file = tlh->rb_ct_w;
		tlh->rb_ct_w  = pCt;
	}
	else if (ope > 0) {	/* add or mod */
		pCt = tlc->rb_file;
		if (setno > 0) {
			if (pCt) {
				akxs_rb_read(pCt,0);
				while (tlFL=(tdtLOG_FILE_LINE *)akxs_rb_read(pCt,1)) {
					no++;
					if (setno == no) {
						if (file && *file) {
							len = strlen(file);
							if (tlFL=(tdtLOG_FILE_LINE *)Realloc(tlFL,
							                    sizeof(tdtLOG_FILE_LINE)+len)) {
								strcpy(tlFL->lfl_file_name,file);
							}
							else return -4;
						}
						if (line1 > 0) tlFL->lfl_line[0] = line1;
						if (line2 > 0) tlFL->lfl_line[1] = line2;
						count++;
						if (pCtChg) {
							tlFL->lfl_ope = ope;
							tlFL->lfl_no = no;
							akxs_rb_set_n(pCtChg,tlFL);
						}
						break;
					}
				}
			}
		}
		else {
			if (file) {
				if (!*file) file = "%";
			}
			else file = "%";
			if (!pCt) {
				if (!(pCt=tlc->rb_file=akxs_rb_new(0,0))) return -2;
			}
			len = strlen(file);
			if (tlFL=(tdtLOG_FILE_LINE *)Malloc(sizeof(tdtLOG_FILE_LINE)+len)) {
				tlFL->lfl_line[0] = line1;
				tlFL->lfl_line[1] = line2;
				strcpy(tlFL->lfl_file_name,file);
				akxs_rb_set_n(pCt,tlFL);
				count++;
				if (pCtChg) {
					tlFL->lfl_ope = ope;
					tlFL->lfl_no = pCt->rb_used;
					akxs_rb_set_n(pCtChg,tlFL);
				}
			}
			else return -3;
		}
	}
	else {	/* ref */
		if (!(pCt=tlc->rb_file)) return 0;
		akxs_rb_read(pCt,0);
		while (tlFL=(tdtLOG_FILE_LINE *)akxs_rb_read(pCt,1)) {
			no++;
			unmatch = 0;
			if (setno > 0) {
				if (no != setno) unmatch = 1;
			}
			else if (file) {
				if (*file) unmatch = strcmp(file,tlFL->lfl_file_name);
			}
			if (!unmatch) {
				count++;
				if (pCtChg) {
					tlFL->lfl_ope = ope;
					tlFL->lfl_no = no;
					akxs_rb_set_n(pCtChg,tlFL);
				}
				if (setno > 0) break;
			}
		}
	}
	return count;
}

/*********************************************/
/*  argv[0]:"srcfile"                        */
/*  argv[1]:logno                            */
/*  argv[2]:filename  / setno    > 0         */
/*  argv[3]:line1     / filename != null     */
/*  argv[4]:line2     / line1    > 0         */
/*  argv[5]:          / line2    > 0         */
/*********************************************/
int akxa_log_set_src_parm(argc,argv,lParm)
char *argv[];
int  argc;
long lParm[];
{
	char c,*file;
	int  logno,ope,line1,line2,setno,i;

	if (argc < 2) return -1;
	c = *argv[1];
	if (c<'0' || c>'9') return -2;
	ope = line1 = line2 = i = setno = 0;
	file = "";
	logno = atoi(argv[1]);
	if (argc >= 3) {
		file = argv[2];
		c = *file;
		if (c == '-') {
			ope = -1;
			file++;
		}
		else if (c == '+') {
			ope = 1;
			file++;
		}
		if ((c = *file)>='0' && c<='9') {
			setno = atoi(file);
			file = "";
			i++;
			if (argc >= i+3) file = argv[i+2];
		}
	}
	if (argc >= i+4) line1 = atoi(argv[i+3]);
	if (argc >= i+5) line2 = atoi(argv[i+4]);
/*
printf("akxa_log_set_src_parm:logno=%d ope=%d setno=%d file=[%s] line1=%d line2=%d\n",logno,setno,ope,file,line1,line2);
*/
	lParm[0] = (long)argv[0];
	lParm[1] = logno;
	lParm[2] = ope;
	lParm[3] = setno;
	lParm[4] = (long)file;
	lParm[5] = line1;
	lParm[6] = line2;
	return 0;
}

/*********************************************/
/*  argv[0]:"srcfile"                        */
/*  argv[1]:logno                            */
/*  argv[2]:filename  / setno    > 0         */
/*  argv[3]:line1     / filename != null     */
/*  argv[4]:line2     / line1    > 0         */
/*  argv[5]:          / line2    > 0         */
/*********************************************/
int akxa_log_src_file(tlh,pCtChg,argc,argv)
tdtLOG_CTL_HEAD *tlh;
tdtRB_CTL *pCtChg;
int  argc;
char *argv[];
{
	int  rc;
	long pa[7];

	rc = akxa_log_set_src_parm(argc,argv,pa);
	if (!rc)
		rc = akxa_log_set_src_file(tlh,pCtChg,pa[1],pa[2],pa[3],pa[4],pa[5],pa[6]);
	return rc;
}

#define AKX_LOG_PARM_MAX	8
/********************************************/
/*	argv[0]:logno	  =>iParm[i]:			*/
/*	argv[1]:flag	  =>iParm[i]:			*/
/*	argv[2]:level	  =>iParm[i]:			*/
/*	argv[3]:size max  =>iParm[i]:			*/
/*	argv[4]:file max  =>iParm[i]:			*/
/*	argv[5]:option	  =>iParm[i]:			*/
/*	argv[6]:file name =>iParm[i]:			*/
/*	argv[7]:priority-+	iParm[i]:file number*/
/*	argv[8]:N/A		 |	iParm[i]:check		*/
/*	argv[9]:N/A		 +=>iParm[i]:priority	*/
/********************************************/
/******************************************************
	argv!=NULL�̂Ƃ��́Aargv[i]���g���B
	argv==NULL�̂Ƃ��́AiParm_i[i]���g���B
	argv!=NULL && argc_i<0 �̂Ƃ��́A
		argv[i]=="." || "-" �̂Ƃ��AiParm_i[i]���g���B
*******************************************************/
int akxa_log_set_parm2(tlh,argc_i,argv,nParm,iParm_i)
tdtLOG_CTL_HEAD *tlh;
int  argc_i,nParm;
long iParm_i[];
char *argv[];
{
	int  logno,i,l,iset,size_K,j,optw,opt4,argc,iADD_DEL,log_flg;
	long w,ww,iParm[10];
	char *pi,*fn=NULL,c,**ppNS,c1;
/*
printf("akxa_log_set_parm2:Enter: argc_i=%d argv=%08x nParm=%d iParm_i=%08x\n",argc_i,argv,nParm,iParm_i);
*/
	if ((argc=argc_i) < 0) argc = -argc;
	if (nParm > 10) nParm = 10;
	i = 0;
	if (iParm_i) for (;i<nParm;i++) iParm[i] = iParm_i[i];
	for (;i<10;i++) iParm[i] = -1;
	size_K = 1000;
	opt4 = 0;
	if (argc > AKX_LOG_PARM_MAX) argc = AKX_LOG_PARM_MAX;
	iADD_DEL = 1;
	if (argv) {
		ppNS = &(tlh->log_ecnv);
		akxcecvn(ppNS,NULL,0,NULL);	/* new */
	/*	for (i=0;i<AKX_LOG_PARM_MAX;i++) iParm[i] = -1;	*/
		if (argc > AKX_LOG_PARM_MAX) argc = AKX_LOG_PARM_MAX;
		for (i=0;i<argc;i++) {
/*
printf("akxa_log_set_parm2: i=%d argv=[%s] iParm=%d\n",i,argv[i],iParm[i]);
*/
			pi = argv[i];
			c = *pi;
			c1 = *(pi+1);
			if ((c=='.' || c=='-') && !c1) {
				if (argc_i >= 0) iParm[i] = -1;
				continue;
			}
			if (i == 6) {	/* LOGFILE */
			/*	if (c && c!='-') {	*/
					if (!stricmp(pi,"null")) pi = "";
					fn = pi;
					iParm[6] = (long)pi;
			/*	}	*/
			}
			else if ((i==2 || i==7) && *ppNS) {	/* level, priority */
				if ((j=akxcecvn(ppNS,pi,strlen(pi),&w)) >= 0) {
					if (w >= 0) iParm[i] = w;
				}
/*
printf("akxa_log_set_parm: parm=[%s] j=%d\n",pi,j);
*/
			}
			else {
#if 1	/* 2022.6.30 */
				if (i == 1) {
					if (c=='+' || c=='-') {
						pi++;
						if (c == '+') iADD_DEL = 2;
						else iADD_DEL = -1;
					}
				}
#endif
				if (!(j=akxcgcvn(pi,strlen(pi),&w))) {
					if (w >= 0) iParm[i] = w;
				}
				else if (i==3 && j>0 && w>=0) {	/* size max */
					c = akxcupper(*(pi+j-1));
					if (c=='K' || c=='M' || c=='B' || c=='L') {
						iParm[i] = w;
						if (c == 'B') size_K = 1;
						else if (c == 'L') {
							size_K = 1;
							opt4 = D_LOG_ROT_SIZE_LINE;
						}
						else {
							if (c == 'K') size_K = 1000;
							else if (c == 'M') size_K = 1000000;
							c = akxcupper(*(pi+j));
							if (c == 'L') opt4 = D_LOG_ROT_SIZE_LINE;
						}
					}
				}
			}
/*
printf("akxa_log_set_parm2: iParm[%d]=%08x\n",i,iParm[i]);
*/
		}
	}
	else {
		for (i=argc;i<AKX_LOG_PARM_MAX;i++) iParm[i] = -1;
		if (argc>6 && nParm>6) fn = (char *)iParm[6];
	}

	if ((logno = iParm[0]) >= 0) {
#if 1	/* 2022.6.30 */
		if (iADD_DEL == 1) ;
		else {
			log_flg = akxa_log_flg(tlh,logno,-1);
			if (iADD_DEL == 2) iParm[1] |= log_flg;
			else iParm[1] &= ~log_flg;
		}
#endif
		iParm[1] = akxa_log_flg(tlh,logno,iParm[1]);	/* LOGFLG */
		iParm[2] = akxa_log_level(tlh,logno,iParm[2]);	/* LOGLEVEL */
/*
printf("akxa_log_set_parm2: flg=%04x level=%08x\n",iParm[1],iParm[2]);
*/
		if (iParm[3] > 0) {		/* size max */
			iParm[3] *= size_K;
		}
		if (iParm[4] > 0) {		/* file max */
			if (iParm[4] > 255) iParm[4] = 255;
		}
		else if (iParm[3] > 0) iParm[4] = 5;
		optw = iParm[5];		/* option */
/*
printf("akxa_log_set_parm2: iParm[6]=%08x\n",iParm[6]);
*/
		iParm[6] = (long)akxa_log_set_file_name(tlh,logno,fn); /* LOGFILE */
/*
printf("akxa_log_set_parm2: iParm[6]=%s fn=%08x\n",iParm[6],fn);
*/
		if (fn && !iParm[6]) iParm[6] = -2;
		w = iParm[6];
		iParm[7] = akxa_log_priority(tlh,logno,iParm[7]);	/* LOGPRIORITY */
		ww = iParm[7];
		if (opt4) {
			if (optw >= 0) iParm[5] |= opt4;
			else iParm[5] = opt4;
		}
		akxa_log_size(tlh,logno,5,&iParm[3]);
		if (opt4 && optw<0) {
			iParm[3] = iParm[4] = iParm[5] = -1;
			akxa_log_size(tlh,logno,3,&iParm[3]);
		}
		iParm[8] = iParm[7];
		iParm[7] = iParm[6];
		iParm[6] = w;
		iParm[9] = ww;
	}
	if (iParm_i) for (i=0;i<nParm;i++) {
		iParm_i[i] = iParm[i];
/*
printf("akxa_log_set_parm2:Exit: iParm_i[%d]=%08x\n",i,iParm_i[i]);
*/
	}
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_set_parm(tlh,argc,argv,iParm)
tdtLOG_CTL_HEAD *tlh;
int  argc,iParm[];
char *argv[];
{
	return akxa_log_set_parm2(tlh,argc,argv,AKX_LOG_PARM_MAX,iParm);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_clear(tlh,log_no,option)
tdtLOG_CTL_HEAD *tlh;
int  log_no,option;
{
	tdtLOG_CTL *tlc;
	char   *cpPath, *log_file, *p, buf[256], *fn;
	static char *cpPath2=NULL,*cpPath3=NULL;
	tdtROTATE_CTL *rot;
	int i,len;
/*
printf("akxa_log_clear:log_no=%d,option=0x%08x\n",log_no,option);
*/
	if (!(tlc = akxa_log_get_ctl(tlh,log_no))) return -1;
	rot = &tlc->log_rot;
	cpPath = _log_file_path(tlh,tlc,0);
/*
printf("akxa_log_clear: cpPath = [%s]\n",cpPath);
*/
	if (cpPath) {
		unlink(cpPath);
		if (rot->rot_file_max>0 && (len=strlen(cpPath))<sizeof(buf)-12) {
			memcpy(buf,cpPath,len+1);
			fn = buf;
			p = buf + len;
			for (i=1;i<=rot->rot_file_max;i++) {
				sprintf(p,"%d",i);
/*
printf("akxa_log_clear: fn = [%s]\n",fn);
*/
				unlink(fn);
			}
		}
	}
	rot->rot_file_no = 0;
	rot->rot_check_point = 0;

	return 0;
}

/************************************************/
/*												*/
/************************************************/
int akxa_line_count(file, opt)
char *file;
int	 opt;
{
	FILE *fp;
	int  c,line,i,c2;

	if (!file) return -1;
	if (!(fp=fopen(file,"r"))) return -2;
	line = i = 0;
	while ((c=getc(fp)) != EOF) {
		i = 0;
		if (c == '\n') line++;
		else if (c == '\r') {
			line++;
			if ((c2=getc(fp)) == EOF) break;
			else if (c2 != '\n') i = 1;
		}
		else i = 1;
	}
	fclose(fp);
/*
printf("akxa_line_count: file=[%s] opt=%d line=%d i=%d\n",file,opt,line,i);
*/
	return line+i;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_set_command_parm(tlh,nset,logno_set,opt_string,parm_string,iOption)
tdtLOG_CTL_HEAD *tlh;
int  nset;
tdtGENERAL_DATA *logno_set;
char *opt_string,*parm_string;
int  iOption;
{
	char c2,*p;
	int  n,ret,i,is,log_no,log_flg;
	long iParm[10];
	char parm[256],*argv2[9],logno_ch[12],buf[128];
	tdtGENERAL_DATA *pset;

	if (!opt_string || !parm_string || !logno_set) return -1;

	for (is=0,pset=logno_set;is<nset;is++,pset++) {
		if (p=pset->gd_data) {
			if (!stricmp(opt_string,p)) break;
		}
	}
	if (is < nset) {
/*
printf("akxa_log_set_command_parm: is=%d opt_string=[%s]\n",is,opt_string);
*/
		ret = 0;
		log_no = pset->gd_id;	/* log_no */
		n = akxtgetargv2(parm_string,&argv2[1],7,parm,sizeof(parm),5);
		if (n > 0) {
			argv2[0] = logno_ch;
			if (is == 0) {
				for (i=1,pset=&logno_set[1];i<nset;i++,pset++) {
					sprintf(logno_ch,"%d",(int)pset->gd_id);
					akxa_log_set_parm2(tlh,n+1,argv2,0,NULL);
				}
				return 0;
			}
			else {
				sprintf(logno_ch,"%d",log_no);
				akxa_log_set_parm2(tlh,n+1,argv2,0,NULL);
			}
		}
		else if (n < 0) ret = n;
		else if ((log_flg=(int)pset->gd_resv) >= 0) {
			iParm[0] = log_no;
			iParm[1] = log_flg;
			akxa_log_set_parm2(tlh,2,NULL,2,iParm);
		}
	}
	else ret = -2;
	return ret;
}

/********1*********2*********3*********4*********5*********6*********7***/
/* �@�\ : format�ŕϊ������o�͒���max_len�𒴂��Ȃ��Œ���				*/
/*		  �t�H�[�}�b�g���o�͂���B										*/
/*		  %�ϊ��̌��ʂ�max_len�𒴂���Ƃ��́A����%�̑O�܂łƂȂ�B		*/
/*		  buf=NULL,max_len<=0�̂Ƃ��́Aformat�ϊ��ɕK�v�ȃT�C�Y��Ԃ��B	*/
/* ���� : buf		: �t�H�[�}�b�g���o�͂���G���A						*/
/*					  NULL�̂Ƃ��́A�o�͂��Ȃ�							*/
/*		  max_len	: buf�̃T�C�Y(byte) �I�[null���܂�					*/
/*					  <=0 �̂Ƃ��́A�`�F�b�N���Ȃ�						*/
/************************************************************************/
int akxa_log_printf_len2(buf,max_len,format,argc,argv,code_type)
char *buf,*format,*argv[];
int  max_len,argc,code_type;
{
	static char work[256],*p0=NULL;
	static int used_len;
	int  i,l,len,iper,width,w,flen,pos,n,wrk_len;
	char *p,c,*a,*b,*p1,wrk[32],*pp;

	if (p=format) {
		b = buf;
		i = len = iper = used_len = 0;
#if 1	/* 2022.10.10 */
		flen = strlen(format);
/*
printf("akxa_log_printf_len2: flen=%d format=[%s]\n",flen,format);
*/
		while ((c=*p) && flen>0) {
			if (max_len>0 && len>=max_len) break;
		/*	n = akxqkanjilen2(p,flen);	*/
			n = akxqmbsnlen(code_type,p,flen);
			if (n > 1) {
				flen -= n;
				len += n;
				if (b) {
					memcpy(b,p,n);
					b += n;
				}
				p += n;
				continue;
			}
			p++;
		/*	n = akxqkanjilen2(p,flen-1);	*/
			n = akxqmbsnlen(code_type,p,flen-1);
#else
		while (c = *p++) {
			if (max_len>0 && len>=max_len) break;
			n = 1;
#endif
			if (c == '\\') {
				if (b) *b++ = c;
				len++;
				flen--;
				if (n == 1) {
					if (!(c = *p++)) break;
					if (b) *b++ = c;
					len++;
					flen--;
				}
			}
			else if (c == '%') {
				if (n > 1) {
					if (b) *b++ = c;
					len++;
					flen--;
				}
				else {
					if (i >= argc) break;
					if (argv) {
						iper  = 1;
						if (b) *b++ = c;
						len++;
						flen--;
					}
#if 1	/* 2022.10.10 */
					akxccvn2(10,p,flen,&width,&pos);
#if 1	/* 2024.7.17 */
					if (b && pos>0) {
						memcpy(b,p,pos);
						b += pos;
					}
#endif
					flen -= pos;
					p += pos;
/*
printf("akxa_log_printf_len2: akxccvn2 width=%d pos=%d flen=%d\n",width,pos,flen);
*/
#else
					width = atoi(p);
#endif
				}
			}
			else if (iper) {
				a = argv[i];
				if (strchr("sdfecx",c)) {
					if (c == 's') {
						if (!a) {
							a = AKX_NULL_PRINT;
						}
						else if (!akxm_addrchk(a)) {
							sprintf(wrk,"invalid addr(%08x)",a);
							a = wrk;
						}
						w = strlen(a);
					}
					else if (c == 'd') w = 11;
					else if (c=='f' || c=='g' || c=='G') w = 18;
					else if (c == 'e') w = 14;
					else if (c == 'c') w = 1;
					else if (c == 'x') w = 8;
/*
printf("akxa_log_printf_len2: c=[%c] width=%d w=%d flen=%d\n",c,width,w,flen);
*/
					if (width>0 && width>w) w = width;
					if (max_len>0 && len+w>=max_len) break;
					len += w;
				}
				else {
					if (b) *b++ = c;
					len++;
					flen--;
					continue;
				}
				if (b) *b++ = c;
				i++;
				iper = 0;
			}
			else {
				if (b) *b++ = c;
				len++;
				flen--;
			}
		}
		if (i>=argc && flen>0) {
			if (b) {
				memzcpy(b,p,flen);
				b += flen;
			}
			len += flen;
		}
		if (b) *b = '\0';
/*
printf("akxa_log_printf_len2: buf=[%s] len=%d\n",buf,len);
*/
	}
	else len = -1;
	return len;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_printf_len(buf,max_len,format,argc,argv,code_type)
char *buf,*format,*argv[];
int  max_len,argc,code_type;
{
	return akxa_log_printf_len2(buf,max_len,format,argc,argv,0);
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_group_priority(
tdtLOG_CTL_HEAD *tlh,
int i,
int flg,
int iPriority)
{
	tdtLOG_CTL *tlc;
	int group,priority;

	if (tlc = akxa_log_get_ctl(tlh,i)) {
		if (flg) {
			group = tlc->log_priority & tlc->log_grp_mask;
			priority = tlc->log_priority & ~tlc->log_grp_mask;
/*
printf("akxa_log_group_priority:i=%d flg=%d cur_priority=%08x\n",
i,flg,tlc->log_priority);
*/
			if (flg & 0x02) group = iPriority & tlc->log_grp_mask;
			if (flg & 0x01) priority = iPriority & ~tlc->log_grp_mask;
			tlc->log_priority = group | priority;
		}
/*
printf("akxa_log_group_priority:i=%d flg=%d in_priority=%08x new_priority=%08x\n",
i,flg,iPriority,tlc->log_priority);
*/
		return tlc->log_priority;
	}
	else return -1;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_priority(
tdtLOG_CTL_HEAD *tlh,
int i, int priority)
{
	tdtLOG_CTL *tlc;
	int ret,flg;

	if (tlc = akxa_log_get_ctl(tlh,i)) {
		if (priority < 0) flg = 0;
		else flg = 3;

		if ((ret = akxa_log_group_priority(tlh, i, flg, priority)) < 0) return ret;
		return tlc->log_priority/* & ~tlc->log_grp_mask */;
	}
	else return -1;
}

/********************************************/
/*											*/
/********************************************/
int akxa_logfout(logfile,file,line,data,len)
char *logfile,*file,*data;
int  line,len;
{
	FILE *fp;
	int l,lp;
	char *p,buf[128];

	if (logfile) {
		if (!(fp = fopen(logfile,"a"))) return -1;
	}
	else fp = stdout;

	if (!file) file = "";
	p = akx_log_time();
	if (*p) fprintf(fp,"%s ",p);
	fprintf(fp, "%s(%d): ", file, line);
	l = len;
	p = data;
	while (l > 0) {
		memnzcpy(buf,p,l,sizeof(buf));
		fprintf(fp, "%s", p);
		lp = strlen(p);
		if (lp < sizeof(buf)-1) break;
		p += lp;
		l -= lp;
	}
	fprintf(fp, "\n");
	if (fp != stdout) fclose(fp);
	return 0;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_new_line_str(char *s, int iFlg)
{
	int n;

	if (s) {
		n = 0;
		if (iFlg & AKX_NEWLINE_PUT_CR) {
			*s++ = '\r';
			n++;
		}
		if (!(iFlg & AKX_NEWLINE_NOT_LF)) {
			*s++ = '\n';
			n++;
		}
		*s = '\0';
	}
	else n = -1;
	return n;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_new_line(FILE *fp, int iFlg)
{
	int n,rc;
	char buf[3];

	if (fp) {
		n = akxa_log_new_line_str(buf,iFlg);
/*
printf("akxa_log_new_line: n=%d iFlg=%08x\n",n,iFlg);
*/
		if (n > 0) {
			fwrite(buf,n,1,fp);
		}
	}
	else n = -1;
	return n;
}

/********************************************/
/*											*/
/********************************************/
int akxa_log_new_line_m(M_FILE *mfp, int iFlg)
{
	int n,rc;
	char buf[3];
	FILE *fp;

	fp = NULL;
	if ((n=m_file_valid(mfp)) < 0) {
		if (n == -2) {
			fp = (FILE *)mfp;
			n = 0;
		}
	}
/*
printf("akxa_log_new_line_m: n=%d\n",n);
*/
	if (n >= 0) {
		n = akxa_log_new_line_str(buf,iFlg);
		if (n > 0) {
			if (fp) fwrite(buf,n,1,fp);
			else if (mfp->m_mcat) {
				if ((rc=akxtmcat(mfp->m_mcat,buf,n)) < 0) n = rc;
			}
			else fwrite(buf,n,1,mfp->m_fp);
		}
	}
	return n;
}

/********************************************/
/*											*/
/********************************************/
int akxa_copy_file(fromFile,toFile,opt)
char *fromFile,*toFile;
int opt;	/* 1:not copy when toFile exist */
{
	int ret,rlen,wlen,size;
	char buf[512];
	FILE *fpr,*fpw;

	if (!fromFile || !toFile) return -1;
	if (opt) {
		if (fpr=fopen(toFile,"rb")) {
			fclose(fpr);
			return -2;
		}
	}
	ret = 0;
	if (fpr=fopen(fromFile,"rb")) {
		if (fpw=fopen(toFile,"wb")) {
			while ((rlen=fread(buf,1,sizeof(buf),fpr)) > 0) {
printf("akxa_copy_file: read len=%d\n",rlen);
				if ((wlen=fwrite(buf,1,rlen,fpw))!=rlen) {
					ret = -14;
					break;
				}
				ret += wlen;
			}
			if (ferror(fpr)) ret = -13;
			fclose(fpw);
		}
		else ret = -12;
		fclose(fpr);
	}
	else ret = -11;
	return ret;
}

/****************************************/
/*										*/
/****************************************/
char *akxa_fsprintfv(fp,format,argc,argv,code_type)
FILE *fp;
char *format;
int  argc,code_type;
char *argv[];
{
	static MCAT mcat={'M','C',256,0,0,0,NULL,0};
	static char *p1=NULL,*p2=NULL;
	static char wrk[256],*wrk2[6];
	int  len_f,i,len,ipa,pos1,pos2,slen,n;
	char *form,*p_f,*p_d,c,c0,cc,*s,*p/*,**argv*/;
	double dValue,*pdVal;
	uchar uc;
/*
printf("akxa_fsprintfv:Enter fp=%08x argc=%d code_type=%08x format=[%s]\n",fp,argc,code_type,format);
*/
	if (p_f=format) len_f = strlen(p_f);
	else len_f = 0;
	if (len_f <= 0) {
		strcpy(wrk,"");
		return wrk;
	}
	if (!fp) {
		slen = akxa_log_printf_len2(NULL,0,format,argc,argv,code_type);
/*
printf("akxa_fsprintfv: slen=%d\n",slen);
*/
		if (akxmemwork(slen,&s,&p1,wrk,sizeof(wrk)) < 0) return NULL;
/*
printf("akxa_fsprintfv: s=%08x p1=%08x wrk=%08x\n",s,p1,wrk);
*/
		mcat.mc_ipos = 0;
	}
	ipa = 0;
	for (;;) {
/*
printf("akxa_fsprintfv:1: len_f=%d p_f=[%s]\n",len_f,p_f);
*/
		c = '\0';
		i = 0;
		while (i<len_f && (c=*(p_f+i))) {
#if 1
			n = akxqmbsnlen(code_type,p_f+i,len_f-i);
			if (n > 1) {
				i += n;
				continue;
			}
#endif
			if (c=='%') {
#if 1
				n = akxqmbsnlen(code_type,p_f+i+1,len_f-i-1);
				if (n > 1) {
					i += n + 1;
					continue;
				}
#endif
				if ((cc=*(p_f+i+1))=='%') {
					i++;
					c = '\0';
				}
				else break;
			}
			i++;
		}
		if (c != '%') break;
/*
printf("akxa_fsprintfv:2: len_f=%d p_f=[%s]\n",len_f,p_f);
*/
		while (i<len_f && (c=*(p_f+i))) {
#if 1
			n = akxqmbsnlen(code_type,p_f+i,len_f-i);
			if (n > 1) {
				i += n;
				continue;
			}
#endif
			i++;
			c = toupper(c);
			pos2 = 0;
			if ((pos1=instrchar("SCDXIOU",c)) > 0) break;
			else if ((pos2=instrchar("FEGA",c)) > 0) break;
		}
		if ((pos1+pos2)>0 && ipa<argc) {
			form = strmemk(p_f,i,"akxa_fsprintfv");
/*
printf("akxa_log_fsprintfv: pos1=%d pos2=%d form=%08x[%s] i=%d c=[%c] ipa=%d\n",pos1,pos2,form,form,i,c,ipa);
*/
			p_d = argv[ipa];
			if (pos2 > 0) {
				pdVal = (double *)p_d;
				dValue = *pdVal;
				if (fp) fprintf(fp,form,dValue);
				else {
					snprintf(s,slen,form,dValue);
					akxtmcats(&mcat,s);
				}
			}
			else {
				if (pos1 == 1) {
					if (!p_d) {
						p_d = AKX_NULL_PRINT;
					}
					else if (!akxm_addrchk(p_d)) {
						sprintf(wrk,"invalid addr(%08x)",p_d);
						p_d = wrk;
					}
				}
				if (fp) fprintf(fp,form,p_d);
				else {
					snprintf(s,slen,form,p_d);
					akxtmcats(&mcat,s);
				}
			}
			ipa++;
		}
		else {
			break;
		}
		p_f += i;
		len_f -= i;
	}
	if (len_f > 0) {
/*
printf("akxa_log_fsprintfv: len_f=%d c=[%c] ipa=%d p_f=[%s]\n",len_f,c,ipa,p_f);
*/
		if (fp) fprintf(fp,p_f);
		else akxtmcats(&mcat,p_f);
	}
	if (fp) p = NULL;
	else {
		if (!(p = mcat.mc_bufp)) {
			p = wrk;
			strcpy(wrk,"");
		}
	}
	return p;
}
