static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testargv2.c akxcom.a -o testargv2
*/
#include "akxcommon.h"
#define MAXARGC	10
main()
{
	char buf[256],parm[256],*argv[MAXARGC],**argvp,*p,sep[2];
	int i,n,opt,parmlen,maxargc,maxargcs;

	parmlen = sizeof(parm);
	printf("parm len(%d) ==>",parmlen);
	gets(buf);
	parmlen = atoi(buf);
	printf("maxargc ==>");
	gets(buf);
	maxargc = maxargcs = atoi(buf);
	if (maxargc < 0) maxargc = -maxargc;
	if (maxargc > MAXARGC) {
		maxargc = MAXARGC;
		if (maxargcs < 0) maxargcs = -maxargc;
		else maxargcs = maxargc;
	}
	argvp = argv;
	printf("argv ==>");
	gets(buf);
	if (!strcmp(buf,"null")) argvp = NULL;
	printf("sep==>");
	gets(buf);
	sep[0] = buf[0];
	printf("opt==>");
	gets(buf);
	n=akxcgcvn(buf,strlen(buf),&opt);
	printf("ret=%d opt=%08x\n",n,opt);
	for (;;) {
		printf("Enter==>");
		gets(buf);
		n=akxtgetargvns2(buf,strlen(buf),argvp,maxargcs,parm,parmlen,sep,opt);
		printf("n=%d\n",n);
		if (n >= 0) {
			if (argvp) {
				for (i=0;i<maxargc;i++) {
					printf("i=%d argv=[%s]\n",i,argv[i]);
				}
			}
			if (!argvp || maxargcs<0) {
				p = parm;
				for (i=0;i<n;i++) {
					printf("i=%d parm=[%s]\n",i,p);
					p += strlen(p) + 1;
				}
			}
		}
	}
}
