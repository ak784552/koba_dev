#include <stdio.h>
#include <stdio.h>
main()
{
	int i;

	printf("pos=%08x %08x %08x\n",strchr("abc",'a'),strchr("abc",'x'),strchr("abc",'\0'));
	printf("0x80000000=%d\n",0x80000000);
	i = 0x80000000;
	printf("i=%d\n",i);
}
