/*
 *	test for akxams.c
 *
 *		coded   by A.Kobayashi 95.3.5
 *
 *
 */
#include "cpunix.h"
#include "cpunix.h"
#include "akxlib.h"

int main()
{
	int ret,i;
	int ibuf[4096];
	int lh;

	ret = akxa_ms_create("MemSpace");
	printf("akxa_ms_create ret = %d\n",ret);
	if (ret) exit(1);
	lh = akxa_ms_alloc("TestABC");
	printf("akxa_ms_alloc ret = %d\n",lh);
	for (i=0;i<4096;i++) ibuf[i]=i;
	ret = akxa_ms_write(lh,ibuf,0,4096*4);
	printf("akxa_ms_write ret = %d\n",ret);
	for (i=0;i<4096;i++) ibuf[i]=0;
	ret = akxa_ms_read(lh,ibuf,0,4096*4);
	printf("akxa_ms_read ret = %d\n",ret);
/*
	akxaxdump("buf",ibuf,4096*4);
*/
	ret = akxa_ms_free(lh);
	printf("akxa_ms_free ret = %d\n",ret);
	exit(0);
}
