static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*********************************************************/
/*								*/
/*	csv data						*/
/*								*/
/*		coded   by A.Kobayashi	1997.06.26		*/
/*								*/
/*********************************************************/

#include	"akunix.h"
#include	"akxmemtool.h"
#include	"akxlib.h"

/********************************************************/
/* ret= 0:�f�[�^�̌��ɃJ���}�Ȃ�                      */
/*    = 1:�f�[�^�̌��ɃJ���}����                      */
/*    =-1:EOF                                           */
/*    =-2:Internal Error                                */
/*    =-3:malloc   Error                                */
/********************************************************/
int akxtcsvgw(cpMsg,iHeadLen,ssp,ssparg)
char  *cpMsg;
int   iHeadLen;
SSP_S *ssp,*ssparg;	/* ssparg->sp=argl,ssparg->wd=argv */
{
	static char scWork[256],*scpWork=NULL,*scpAlloc=NULL;
	static int  scAllocLen=0;
	static char *scpWd=NULL;
	static char sep[]=",";
	int opt,len;
	char quat,*d,*s;
	int i,n;
/*
printf("akxtcsvgw1: sp=%d w=[%c]\n",ssp->sp,cpMsg[ssp->sp]);
*/
	ssparg->sp = 0;
	ssparg->wd = cpMsg + ssp->sp;
	opt = 0x27; /* 0b100111 */
	/* 0:��s�u�����N�ƃ^�u���X�L�b�v���� */
	/* 1:���p���A�Q�d���p�����͂��� */
	/* 2:���p���A�Q�d���p���̒��̘A������Q�̂������P�ɂ��� */
	/* 5:ssp->wd�Ƀ��[�h���i�[�����A���[�h�̐擪�A�h���X������  */
	len = akxtgwns(cpMsg,iHeadLen,ssp,sep,opt);
/*
printf("akxtcsvgw2: sp=%d w=[%c]\n",ssp->sp,cpMsg[ssp->sp]);
*/
	if (len) {
		if (ssp->attr[0] > 6) return 1;
	}
	else if (!ssp->attr[0]) return -1; /* EOF */
#if 0	/* 1998.5.28 Koba */
	if (ssp->attr[0]!=5 && ssp->attr[0]!=6) len = akxtsapb(0,ssp->wd,len);
	ssparg->sp = len;
	ssparg->wd = ssp->wd;
#else
	if (len < sizeof(scWork)) scpWd = scWork;
	else {
		if (len+1 > scAllocLen) {
			if (scpAlloc) scpAlloc = Realloc(scpAlloc,len+1);
			else scpAlloc = Malloc(len+1);
			if (!scpAlloc) return -3;
			scAllocLen = len + 1;
		}
		scpWd = scpAlloc;
	}
	s = ssp->wd;
	if (ssp->attr[0]==5 || ssp->attr[0]==6) {
		if (ssp->attr[3]) {
			if (ssp->attr[0]==5) quat = '\'';
			else quat = '"';
			d = scpWd;
			n = len;
			len = 0;
			for (i=0;i<n;i++) {
				if (*s == quat) {
					s++;
					i++;
				}
				*d++ = *s++;
				len++;
			}
		}
		else {
			memcpy(scpWd,s,len);
		}
	}
	else {
		memcpy(scpWd,s,len);
		len = akxtsapb(0,scpWd,len);
	}
	*(scpWd+len) = '\0';
	ssparg->wd = scpWd;
	ssparg->sp = len;
#endif
	if (!akxtgwns(cpMsg,iHeadLen,ssp,sep,opt)) {
		if (!ssp->attr[0]) return 0;
	}
/*
printf("akxtcsvgw3: sp=%d w=[%c]\n",ssp->sp,cpMsg[ssp->sp]);
*/
	if (ssp->attr[0] > 6) {
		return 1;
	}
	return -2;
}

int akxtmgetline(cpMem, iMemLen, ssp)
char *cpMem;
int  iMemLen;
SSP_S *ssp;
{
	char *p;
	int i,len;

	len = 0;
	i = ssp->sp;
	ssp->wd = p = cpMem + i;
	if (i>=iMemLen) return -1;
	while ((i < iMemLen) && (*p != '\n') && (*p != '\r') && (*p != '\0')) {
		i++;
		p++;
	}
	len = i - ssp->sp;
	if (i < iMemLen) {
		if (*p == '\r') {
			i++;
			if ((i<iMemLen) && (*(p+1)=='\n')) i++;
		}
		else if ((*p == '\n') || (*p == '\0')) i++;
	}
	ssp->sp = i;
	return len;
}


int akxtcsvset(cpSQL,cpMsg,iMsgLen)
char *cpSQL, *cpMsg;
int iMsgLen;
{
	SSP_S ssp,ssparg;
	int lb, vlen, i, iStat;
	char *vb, *p, c;
/*
printf("akxtcsvset:iMsgLen=%d\n",iMsgLen);
*/
	vlen = ssp.sp = 0;
	p = cpSQL;
	for (;;) {
		if ((iStat=akxtcsvgw(cpMsg,iMsgLen,&ssp,&ssparg))<0) break;
		if (akxqnum(ssparg.wd,ssparg.sp)) {
			memcpy(p,ssparg.wd,ssparg.sp);
			p += ssparg.sp;
			vlen += ssparg.sp;
		}
		else if (ssparg.sp > 0) {
			memcpy(p,"\"",1);
			p++;
			vlen++;
			for (i=0;i<ssparg.sp;i++) {
				c = *ssparg.wd++;
				*p++ = c;
				vlen++;
				if (c == '"') {
					*p++ = c;
					vlen++;
				}
			}
			memcpy(p,"\"",1);
			p++;
			vlen++;
		}
		if (iStat) {
			*p++ = ',';
			vlen++;
		}
	}
	return vlen;
}

int akxqnum(p,len)
char *p;
int len;
{
	int i,flg;
	char c;

	if (len<=0) return 0;
	flg=0;
	for (i=0;i<len;i++) {
		c = *p++;
		if (c==' ' || c=='\t') continue;
		if (c=='+' || c=='-' || c=='.' || (c>='0' && c<='9')) {
			flg = 1;
			continue;
		}
		return 0;
	}
	return flg;
}

int akxtcsvgavl(buf,buflen,argv,argl,maxargc,parm,len)
char *buf;
int  buflen;
char **argv;
int  *argl;
int  maxargc;
char *parm;
int  len;
{
	SSP_S ssp,ssparg;
	int argc,istat,i;
	char *p;

	if (!buf || !argv || maxargc < 1 || !parm || len < 1) return -1;

	p = parm;
	argc=ssp.sp = 0;
	for (;;) {
		if ((istat=akxtcsvgw(buf,buflen,&ssp,&ssparg))<0) {
			if (istat < -1) return istat;
			break;
		}
		if (len < ssparg.sp+1) break;
		memcpy(parm,ssparg.wd,ssparg.sp);
		*(p=parm+ssparg.sp) = '\0';
		*argv++ = parm;
		if (argl) *argl++ = ssparg.sp;
		argc++;
/*
printf("akxtcsvgavl: argc=%d l=%d w=[%s]\n",argc,ssparg.sp,parm);
*/
		if (argc>=maxargc) break;
		len  -= ++ssparg.sp;
		if (len <= 0) break;
		parm += ssparg.sp;
	}
	/* add 2008.11.27 CSK Koba */
	if (i < maxargc) {
		*p = '\0';
		for (i=argc;i<maxargc;i++) {
			*argv++ = p;
			if (argl) *argl++ = 0;
		}
	}
	return (argc);
}
#if 0	/* ==> akxlib.c */
int akxtsapb(opt,pData,len)
int  opt;
char *pData;
int  len;
{
	int i,ol;
	char *p, *pb, c;

	p = pData;
	for (ol=0;ol<len;ol++) {
		if (!*p) break;
		p++;
	}
	p = pData;
	if (opt >= 1) {
		while (ol>0 && ((c = *p) == ' ') || (c == '\t')) {
			p++;
			ol--;
		}
		if (ol <= 0) {
			*pData = '\0';
			return (0);
		}
	}
	if (opt <= 1) {
		pb = p + ol - 1;
		while (ol>0) {
			if (((c = *pb--) != ' ') && (c != '\t')) break;
			ol--;
		}
	}
	if (opt>=1 && pData != p) memcpy(pData,p,ol);

	if (ol<len) pData[ol] = '\0';
	return (ol);
}

int akxqcsv(p,len)
char *p;
int  len;
{
	while (len--)
		if (*p++ == ',') return 1;
	return 0;
}

int akxt_trim(opt,pData,len)
int  opt;
char *pData;
int  len;
{
	int i,ol,ib;
	char *p, c, *pp;

	if (!(p = pData)) return -1;
	else if ((ol = len) <= 0) return ol;

	if (opt >= 1) {
		while (ol>0 && ((c = *p) == ' ') || (c == '\t')) {
			p++;
			ol--;
		}
		if (ol <= 0) {
			*pData = '\0';
			return 0;
		}
	}
	pp = p;
	if (opt <= 1) {
		ib = -1;
		for (i=0;i<ol;i++,p++) {
			if (((c = *p)==' ') || (c=='\t')) {
				ib = i;
				for (;i<ol;i++,p++) {
					if (((c = *p)==' ') || (c=='\t')) ;
					else {
						if (c) ib = -1;
						break;
					}
				}
			}
			if (!c) {
				ol = i;
				break;
			}
		}
		if (ib >= 0) ol = ib;
	}
	if (opt>=1 && pData != pp) memcpy(pData,pp,ol);

	if (ol<len) pData[ol] = '\0';
	return ol;
}
#endif
