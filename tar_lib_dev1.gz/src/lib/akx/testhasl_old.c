static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
    cc -g -DLINUX -I../include testhasl.c akxcom.a -o testhasl
*/
#include "akxcommon.h"

main()
{
	int n,i,ret,opt;
	long key;
	char cmd[20],buf[128],c;
	HASHB *ha;
	tdtHASL_CELL *cell,*ce;
	int max,pre;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl_new2(4,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	cell = (tdtHASL_CELL *)ha->ha_reg;
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command(e/p/s/r/d/k/l) ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			ce = cell;
			printf(" i flag   hkey next   data\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %4d %6d %4d %6d\n",
				       i,ce->hc_flag,ce->hc_hkey,ce->ha_next,ce->ns_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
		/*	key = atoi(buf);	*/
			if (ret=akxcgcvn (buf,strlen(buf),&key)) break;
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				if (*buf=='\'') ha->ha_nextp = (int *)buf[1];
				else {
				/*	ha->ha_nextp = (int *)atoi(buf);	*/
					if (ret=akxcgcvn (buf,strlen(buf),&ha->ha_nextp)) break;
				}
				ret = akxshasls(ha,key);
			}
			else if (c == 'r') ret = akxshaslr(ha,key);
			else ret = akxshasld(ha,key);
			printf("ret=%d\n",ret);
			if (ret > 0) printf("data=%d\n",ha->ha_nextp);
			break;
		case 'k':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshaslk(ha,&key);
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,key,ha->ha_nextp);
			}
			break;
		case 'p':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshaslp(ha);
				if (ret > 0) printf("i=%d ret=%d key=%d data=%d\n",
				                    i,ret,*ha->ha_key,ha->ha_nextp);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
