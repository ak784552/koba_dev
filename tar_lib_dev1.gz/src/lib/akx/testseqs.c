static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testseqs.c libakx_no_iconv.a -o testseqs
*/
#include <akxcommon.h>
main()
{
	int n,i;
	char cmd[20],*p;
	char buf[128];
	int  rc,klen;
	char key[128],c;
	HASHB *pha;

	printf("Enter key len : ");
	gets(buf);
	klen = atoi(buf);
	printf("Enter max : ");
	gets(buf);
	pha = akxs_seqs_new(klen,atoi(buf));
	if (!pha) exit(0);
	pha->ha_key = key;
	for(;;) {
		printf("Enter command(end/retrieve/store/delete) ==>");
		gets(cmd);
		c = *cmd;
		if (c == 'e') break;
		printf("Enter key ==>");
		gets(key);
		switch (c) {
		case 's':
		case 'r':
		case 'd':
			rc = akxs_seqs(c,pha);
			printf("ret=%d\n",rc);
			break;
		}
		printf("MaxEnt= %d\n",pha->ha_aux);
	}
	rc = akxs_seqs_free(pha);
	printf("ret=%d\n",rc);
	exit(0);
}
