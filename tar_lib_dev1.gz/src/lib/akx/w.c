static    char    sccsid[]="%Z% %M% %I% %D% %T%";
#include <stdio.h>
#include <stdio.h>
main()
{
	unsigned int a,b,c,d,e;

	a = 1;
	b = 2;
	c = 3;
	d = 4;

	printf("d+(b-c)=%d\n",d+(b-c));
	printf("d-(c-b)=%d\n",d-(c-b));
	printf("a=d+(b-c)=%d\n",a=d+(b-c));
	printf("a=d-(c-b)=%d\n",a=d-(c-b));
}
