static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DLINUX -I../include testseqr_str.c libakx_no_iconv.a -o testseqr_str
*/
#include <akxcommon.h>
static char *code_str[]=
	{"0","SYSCODE",""
	,"1","EUC",""
	,"2","SJIS","S-JIS",""
	,"3","ISO-2022-JP-3","JIS",""
	,""
	,"5","UTF-8","UTF8","10",""
	,"6","UCS-4-INTERNAL",""
	,""
	,""
	,"257","NARROW",""
	,"258","WIDE",""
	,NULL};
static char *code_str2[]=
	{"0","SYSCODE"
	,"1","EUC"
	,"2","SJIS","2","S-JIS"
	,"3","ISO-2022-JP-3","3","JIS"
	,"",""
	,"5","UTF-8","5","UTF8"
	,"6","UCS-4-INTERNAL"
	,"",""
	,"",""
	,"257","NARROW"
	,"258","WIDE"
	,NULL};

main()
{
	int ret,max_stra,opt,n,posa[2];
	char buf[40],str[20];

	printf("Enter max : ");
	gets(buf);
	max_stra = atoi(buf);
	for (;;) {
		printf("Enter opt : ");
		gets(buf);
		akxcgcvn(buf,strlen(buf),&opt);
		printf("Enter str ==>");
		gets(str);
		if (!strcmp(str,"e")) break;
		ret = akxs_seqr_str_grp(code_str,max_stra,str,0x100000 | opt,posa);
		printf("str ret=%d opt=%08x str=[%s] posa=%d %d\n",ret,opt,str,posa[0],posa[1]);
		ret = akxs_seqr_str_num(code_str,max_stra,str,0x100000);
		printf("str_num: ret=%d\n",ret);
		ret = akxs_seqr_str2(code_str2,max_stra,str,0x100000 | opt);
		printf("str2: ret=%d\n",ret);
	}
	akxcitoa(-1234567890,buf,10,9);
	akxcitoa(1234567890,str,10,20);
	printf("%s %s\n",buf,str);
	n = 123456;
	akxcitoa(n,buf,8,-1);
	akxcitoa(n,str,16,20);
	printf("%o %s %x %s\n",n,buf,n,str);
	exit(0);
}
