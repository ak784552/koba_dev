static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
    cc -g -DSUNOS -I../include teststoj.c akxcom.a -o teststoj
*/
#include "akxcommon.h"
main()
{
	char cmd[10],in[2],out[2],buf[10];
	ushort usj,uj;
	uint  ulValue;
	int type;

	type = akxt_get_code_type();
	printf("Select Kanji/Xcode =>");
	gets(cmd);
	for (;;) {
		printf("Enter =>");
		gets(buf);
		if (*cmd == 'k') {
			if (type == CD_TYPE_EUC) akxcetos(2, buf, in);
			else memcpy(in,buf,2);
			memcpy(&usj,in,2);
		}
		else {
			akxccvx(buf,strlen(buf),&ulValue);
			usj = ulValue;
			memcpy(in,&usj,2);
		}
		uj = akxcstoj1(in,out);
		printf("sjis jis code : %04x --> %04x\n",usj,uj);
	}
}
