/*		mpa.c		Multiple-Precision Arithmetic	*/
/*
	cc -g -DLINUX -I../include testmpa2.c akxcom.a -o testmpa2
*/
#include	"akxcommon.h"

int main(void)
{
	MPA v;
	char buf[128],wrk[128];

	for (;;) {
		printf("Enter number: ");
		gets(buf);
		m_set_a(&v,buf);
		m_print("v = ", &v, 1);
		m_mpa2an(&v,wrk,sizeof(wrk),6);
		printf("v=%s\n",wrk);
	}
	return 0;
}
