static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#include <stdio.h>
#include <stdio.h>
main()
{
	int i,a;

	a = 0;
	for (i=0;i<10;i++) {
		a = a*37 + 255;
		printf("i=%d a=%d\n",i,a);
	}
}
