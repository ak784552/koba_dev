tcsh current memory allocation:
free:	    0  122   30  103   34   10    5    1    0    1    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0
used:	    0    6   98  121   78   30   11    7    1    2    2    0    1    3    2    0    0    0    0    0    0    0    0    0    0    0    0    0    0
	Total in use: 559584, total free: 24096
	Allocated memory from 0x870000 to 0xffffffff.  Real top at 0x8fe800
nbytes=65552: Out of memory
