static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testhasxz.c akxcom.a -o testhasxz
*/
#include "akxcommon.h"
main()
{
	int n,i,klen,lklen,ret,opt;
	char key[128],cmd[20],*p,*rp,**rpp,buf[128],*kp,c;
	HASHB *ha;
	tdtHASL_CELL *cell,*ce;
	int *np,nx;

	printf("Enter option(0/1/2) ==>");
	gets(cmd);
	opt=atoi(cmd);
	printf("Enter key length ==>");
	gets(cmd);
	klen=atoi(cmd);
	ha = akxs_hasx_new2(klen,10,7,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	for(;;) {
		ha->ha_key = key;
		ha->ha_hix = 0;
		printf("Enter command ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'l':
			if (ha->ha_id[1]=='L') {
				cell = (tdtHASL_CELL *)ha->ha_reg;
				ce = cell;
				printf(" i flag     hkey next     data\n");
				for (i=0;i<10;i++,ce++) {
					printf("%2d %4d %08x %4d %08x\n",
					       i,ce->hc_flag,ce->hc_hkey,ce->ha_next,ce->ns_datp);
				}
			}
			else {
				rp = ha->ha_reg;
				rpp = (char **)rp;
				p = rp + ha->ha_maxreg*sizeof(char *);
				for (i=0;i<10;i++) {
					if (np=ha->ha_nextp) nx=np[i];
					else nx=-1;
					printf("%3d %3d ",i,nx);
					if (klen>0) {
						memcpy(buf,rp,klen+1);
						buf[klen+1]='\0';
						printf("%x [%s]\n",*buf,buf+1);
						rp+=klen+1;
					}
					else if (klen<0) {
						if (kp=rpp[i]) {
							memcpy(&lklen,kp,4);
							memcpy(buf,kp+4,lklen);
							buf[lklen]='\0';
						}
						else strcpy(buf,"(null)");
						printf("%x [%s]\n",*p++,buf);
					}
					else {
						if (!(kp=rpp[i])) {
							strcpy(buf,"(null)");
							kp=buf;
						}
						printf("%x [%s]\n",*p++,kp);
					}
				}
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key ==>");
			gets(buf);
			if (klen>0) {
				memset(key,0,klen);
				strcpy(key,buf);
			}
			else if (klen<0) {
				lklen=strlen(buf);
				memcpy(key,&lklen,4);
				memcpy(key+4,buf,lklen);
			}
			else {
				strcpy(key,buf);
			}
			printf("ret=%d\n",akxshasx(*cmd,ha));
			break;
		case 'k':
		case 'p':
			printf(" i index hkey\n");
			for (i=0;i<10;i++) {
				ha->ha_hix = i + 1;
				if ((ret=akxshasx(*cmd,ha))>0) {
					if (c == 'k') kp = key;
					else kp = ha->ha_key;
					if (klen>0) {
						strnzcpy(buf,kp,klen);
					}
					else if (klen<0) {
						memcpy(&lklen,kp,4);
						strnzcpy(buf,kp+4,lklen);
					}
					else strcpy(buf,kp);
				}
				else strcpy(buf,"(null)");
				printf("%2d %4d [%s]\n",i,ret,buf);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
