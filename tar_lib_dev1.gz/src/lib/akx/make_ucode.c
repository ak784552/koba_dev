static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include make_ucode.c libakx_no_iconv.a -o make_ucode
*/
#include "akxcommon.h"
main(argc,argv)
int argc;
char *argv[];
{
	int len,ucs4,len2;
	ushort  sjis;
	uchar   utf8c[5],inc[256],outc[1024],type_s,type_d,buf[20],outc2[1024];
	tdtGeneralData tg_s,tg_d;

	if (argc > 1) {
		_set_sj_utf8(argv[1]);
	}
	else {
		_init_sj_utf8();
	}
	strcpy(inc," +-09AZaz�@��#���A�@1P");
	len = _stou8(strlen(inc), inc, outc);
	akxaxdump("sjis",inc,strlen(inc));
	akxaxdump("utf8",outc,len);
	len2=_u8tos(len, outc,outc2);
	akxaxdump("sjis",outc2,len2);
}

/****************************/
/*	UTF-8					*/
/****************************/
#define AKX_SJIS_START		0x8140
#define AKX_SJIS_AKI_START	0xA000
#define AKX_SJIS_START2		0xE040
#define AKX_SJIS_OFFSET		(AKX_SJIS_START-256)
#define AKX_SJIS_OFFSET2	(AKX_SJIS_START2-AKX_SJIS_AKI_START)
#define AKX_SJIS_MAX		(65536-AKX_SJIS_OFFSET-AKX_SJIS_OFFSET2)
#define AKX_SJIS_HASH_MAX	11500
#define AKX_SJIS_HASH_PRE	11467

static int gexe_set_utf8=0;
static UINT4 *gucs4=NULL;
static UINT4 *gutf8=NULL;
static HASHB *ha=NULL;
static HASHB *ha4=NULL;
static char *hkey[2],*h4key[2];
static char *utf8_file;

int _set_utf8_file(file)
char *file;
{
	if (!(utf8_file=Strdup(file))) return -1;
	return 0;
}

int _set_sj_utf8(file)
char *file;
{
	FILE *fp;
	char buf[128],parm[256],*argv[3],*p,c,*hkey[2],*h4key[2];
	int  i,len,n,ret,offset,iha4,nn;
	ushort ucs2;
	UINT4  val,sj,utf8,ucs4,ix;
	tdtHaslCell *cell,*ce;

	if (!file) return -1;
	if (!(fp=fopen(file,"r"))) {
		XERROROUTL5(200,"%s open error",file,0,0,0,0);
		return -2;
	}

printf("** AKX_SJIS_MAX=%d AKX_SJIS_OFFSET2=%d\n",AKX_SJIS_MAX,AKX_SJIS_OFFSET2);
	gexe_set_utf8 = 1;
	len = AKX_SJIS_MAX*sizeof(UINT4)*2;
	if (!gucs4) {
		if (!(gucs4=(UINT4 *)Malloc(len))) {
			XERROROUTL5(200,"gucs4 malloc error",0,0,0,0,0);
			ret = -3;
			goto Err;
		}
	}
	memset(gucs4,0,len);
	gutf8 = gucs4 + AKX_SJIS_MAX;
	ha = akxs_hasl_new(4,AKX_SJIS_HASH_MAX,0);
	if (!ha) {
		XERROROUTL5(200,"akxs_hasl_new errno=%d",errno,0,0,0,0);
		ret = -3;
		goto Err;
	}
/*
printf("UTF8: id=%c%c len=%d maxreg=%d mso=%d\n",
ha->ha_id[0],ha->ha_id[1],ha->ha_keylen,ha->ha_maxreg,ha->ha_prereg);
*/
	ha->ha_key = (char *)hkey;
	ha4 = akxs_hasl_new(4,AKX_SJIS_HASH_MAX,0);
	if (!ha4) {
		XERROROUTL5(200,"akxs_hasl_new errno=%d",errno,0,0,0,0);
		ret = -4;
		goto Err;
	}
/*
printf("UCS4: id=%c%c len=%d maxreg=%d mso=%d\n",
ha->ha_id[0],ha->ha_id[1],ha->ha_keylen,ha->ha_maxreg,ha->ha_prereg);
*/
	ha4->ha_key = (char *)h4key;
/*
printf("--sjis-- --ucs4-- --utf8-- - ix- -iha- -iha4\n");
*/
	nn=0;
	while ((len = akxa_read_line(buf,sizeof(buf),fp)) > 0) {
		if ((c=*buf) == '#') continue;
		else if (c == '\t') offset = 1;
		else offset = 8;
		n = akxtgetargv2(buf+offset,argv,3,parm,sizeof(parm),1);
		if (n >= 2) {
			nn++;
			p = argv[0] + 2;
			ret = akxccvx(p,strlen(p),&val);
			sj = val;
			if (n>=3 && *argv[2]=='(') p = argv[2] + 1;
			else p = argv[1] + 2;
			ret = akxccvx(p,strlen(p),&val);
			ucs4 = val;
			if (ucs4 <= 0x7f) {
				utf8 = ucs4<<24;
			}
			else if (ucs4 <= 0x7ff) {
				utf8 = ((ucs4&0x07c0)<<2 | (ucs4&0x3f) | 0xc080)<<16;
			}
			else if (ucs4 <= 0xffff) {
				utf8 = ((ucs4&0xf000)<<4 | (ucs4&0x0fc0)<<2 | (ucs4&0x3f) |
				        0xe08080)<<8;
			}
			else {
				utf8 = (ucs4&0x1c0000)<<6 | (ucs4&0x3f000)<<4 |
				       (ucs4&0xfc0)<<2 | (ucs4&0x3f) | 0xf0808080;
			}
			if ((ix=sj) >= AKX_SJIS_START) {
				 ix = sj - AKX_SJIS_OFFSET;
				 if (sj>=AKX_SJIS_START2) ix -= AKX_SJIS_OFFSET2;
			}
			gucs4[ix] = ucs4;
			gutf8[ix] = utf8;
			ha->ha_next = (int *)sj;
			ret = _Unihasls(ha,utf8);
			if (ret<=0) {
				printf("*** Error ret=%d\n",ret);
				break;
			}
			ha4->ha_next = (int *)sj;
			iha4 = _Unihasls(ha4,ucs4);
/*
printf("%08x %08x %08x %5d %5d %5d\n",sj,ucs4,utf8,ix,ret,iha4);
*/
		}
	}
printf("** gutf8 ** nn=%d max ix=%d\n",nn,ix);
	ix++;
	n=0;
	for (i=0;i<ix;i++) {
		if ((val=gutf8[i]))
			printf(",0x%x",val);
		else
			printf(",0");
		n++;
		if (n==8) {
			printf("\n");
			n=0;
		}
	}
	printf("\n");
printf("** gucs4 **\n");
	n=0;
	for (i=0;i<ix;i++) {
		if ((val=gucs4[i]))
			printf(",0x%x",val);
		else
			printf(",0");
		n++;
		if (n==8) {
			printf("\n");
			n=0;
		}
	}
	printf("\n");
printf("** ha_prereg=%d\n",ha->ha_prereg);
printf("** utf8 **\n--flag-- --hkye-- --next-- --data--\n");
	n=0;
	cell=(tdtHaslCell *)ha->ha_reg;
	for (i=0;i<ha->ha_maxreg;i++) {
		ce=&cell[i];
		printf(",%d,0x%x,%d,0x%x",ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
		n++;
		if (n==3) {
			printf("\n");
			n=0;
		}
	}
	printf("\n");
printf("** ucs4 **\n--flag-- --hkye-- --next-- --data--\n");
	n=0;
	cell=(tdtHaslCell *)ha4->ha_reg;
	for (i=0;i<ha->ha_maxreg;i++) {
		ce=&cell[i];
		printf(",%d,%d,%d,0x%x",ce->hc_flag,ce->hc_hkey,ce->hc_next,ce->hc_datp);
		n++;
		if (n==3) {
			printf("\n");
			n=0;
		}
	}
	printf("\n");
	ret = 0;
Err:
	fclose(fp);
	return ret;
}


int _Unihasli(hp)
HASHB *hp;
{
	int i=0,mx,m1;
	int  opt;
	char c;

	if (!hp) return -1;
	opt = 0;
	if ((mx=hp->ha_maxreg)<=0) i-=4;
	if ((m1=hp->ha_prereg)<=0) i-=8;
	if (hp->ha_prereg>=mx)     i-=16;
	if (!hp->ha_reg)           i-=32;

	if (i>=0) {
		memset(hp->ha_reg,0,mx*sizeof(tdtHaslCell));
		hp->ha_aux=m1;
	}

	return (i);
}

int _Unihasls(hp,key)
HASHB *hp;
long key;
{
	int i,k,maxk,iax,i_start,count,iha0,*data;
	tdtHaslCell *cell,*ce;
	char c;

	if (!hp) return -1;
	i=(ulong)key%hp->ha_prereg+1;

	cell=(tdtHaslCell *)hp->ha_reg-1;
	data=hp->ha_next;
	maxk=hp->ha_maxreg;
	iax=hp->ha_aux;
	i_start = i;
	count = 0;
  L10:
	ce=&cell[i];
	if (!ce->hc_flag) {
		ce->hc_flag=1;
		ce->hc_hkey=key;
		ce->hc_datp=data;
		return i;
	}
	else if (ce->hc_hkey==key) {
		ce->hc_datp=data;
		return i;
	}

	if (ce->hc_next>0) {
		i=ce->hc_next;
		count++;
		if (i!=i_start && count<maxk) goto L10;
	}

	if (iax<0) return (0);

	k=i;
	i=iax;
  L20:
	i++;
	if (i>maxk) {
		i=1;
	}
	ce=&cell[i];
	if (!ce->hc_flag && !ce->hc_next) {
		ce->hc_flag=1;
		ce->hc_hkey=key;
		cell[k].hc_next=i;
		ce->hc_datp=data;
		hp->ha_aux=i;
		count++;
	}
	else if (i==iax) {
		hp->ha_aux=-i;
		i=0;
	}
	else goto L20;
	return i;
}

int _Unihaslr(hp,key)
HASHB *hp;
long key;
{
	int i;
	tdtHaslCell *cell,*ce;

	if (!hp) return -1;
	i=(ulong)key%hp->ha_prereg+1;

	cell=(tdtHaslCell *)hp->ha_reg-1;
  L10:
	ce=&cell[i];
	if (ce->hc_flag && (ce->hc_hkey==key))
		hp->ha_next=ce->hc_datp;
	else if ((i=ce->hc_next)>0) goto L10;

	return i;
}

int _utf8_to_sj(utf8c,sjis,ucs4)
uchar  *utf8c;
ushort *sjis;
UINT4  *ucs4;
{
	int len,ret;
	UINT4 w,utf8,ix,sj,ucs4w;
	char **argv;

	if (!gexe_set_utf8) {
		if (ret=_set_sj_utf8(utf8_file)) return ret;
	}
	if (!ha) return -1;
	len = akxqu8len(*utf8c);
	sj = ucs4w = w = 0;
	memcpy(&w,utf8c,len);
	utf8 = ntohl(w);
	if ((ret = _Unihaslr(ha,utf8)) > 0) {
/*
printf("akxc_utf8_to_sj: ha->ha_key=%08x hkey=%08x\n",ha->ha_key,hkey);
*/
		sj = (UINT4)ha->ha_next;
		if ((ix=sj) >= AKX_SJIS_START) {
			ix = sj - AKX_SJIS_OFFSET;
			if (sj>=AKX_SJIS_START2) ix -= AKX_SJIS_OFFSET2;
		}
		ucs4w = gucs4[ix];
	}
	if (sjis) *sjis = sj;
	if (ucs4) *ucs4 = ucs4w;
/*
printf("akxc_utf8_to_sj: utf8=%08x len=%d ih=%5d sj=%04x ucs4=%04x\n",utf8,len,ret,sj,ucs4w);
*/
	return len;
}

int _u8tos(n, inc, outc)
int   n;
uchar *inc, *outc;
{
	int i,j,len;
	ushort sjis;

	j = 0;
	for (i=0;i<n;i+=len) {
		if ((len = _utf8_to_sj(inc,&sjis,NULL)) < 0) return len;
		inc += len;
		if (sjis) {
			*outc = sjis;
			if (sjis & 0xff00) {
				outc[1] = *outc;
				*outc++ = sjis>>8;
				j++;
			}
			outc++;
			j++;
		}
	}
	return j;
}

int _sj_to_utf8(sjis,utf8c,ucs4)
ushort  sjis;
uchar  *utf8c;
UINT4  *ucs4;
{
	UINT4 sj,ix,utf8,w;
	int len,ret;

	if (!gexe_set_utf8) {
		if (ret=_set_sj_utf8(utf8_file)) return ret;
	}
	if (!gutf8) return -1;
	sj = sjis;
	if ((ix=sj) >= AKX_SJIS_START) {
		ix = sj - AKX_SJIS_OFFSET;
		if (sj>=AKX_SJIS_START2) ix -= AKX_SJIS_OFFSET2;
	}
/*
printf("akxc_sj_to_utf8: %04x %08x\n",sjis,utf8);
*/
	if (utf8c) {
		utf8 = gutf8[ix];
		len = akxqu8len((utf8>>24) & 0xff);
		w = htonl(utf8);
		memcpy(utf8c,&w,len);
	}
	else len = 0;
	if (ucs4) *ucs4 = gucs4[ix];
	return len;
}

int _stou8(n, inc, outc)
int   n;
uchar *inc, *outc;
{
	int i,j,len;
	uchar  c1;
	ushort sjis;

	j = 0;
	for (i=0;i<n;i++,inc++) {
		sjis = c1 = *inc;
		if (akxqiskanji1(c1)) {
			if (i+1 < n) {
				if (akxqiskanji(inc)) {
					i++;
					sjis = sjis<<8 | *(++inc);
				}
			}
			else break;
		}
		len = _sj_to_utf8(sjis,outc,NULL);
		outc += len;
		j    += len;
	}
	return j;
}

