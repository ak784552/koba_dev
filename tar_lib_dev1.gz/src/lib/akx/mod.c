static    char    sccsid[]="%Z% %M% %I% %E% %U%";
#include <stdio.h>
#include <stdio.h>
main()
{
	int a,b,c,d,e;

	a = 0x7fbea300;
	b = 0x7fbcbf00;
	c = 0x7382bd00;
	d = 0x7382be00;
	e = 0x01000000;

	printf("a=%d mod=%d\n",a,a % 8779);
	printf("b=%d mod=%d\n",b,b % 8779);
	printf("c=%d mod=%d\n",c,c % 8779);
	printf("d=%d mod=%d\n",d,d % 8779);
	printf("e=%d mod=%d\n",e,e % 8779);
}
