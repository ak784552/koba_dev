static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include testnapl.c akbcom.a ../xcom/akxcom.a -o testnapl
*/
#include "akbcommon.h"
main()
{
	int n,i,m;
	char *argv[128],sc[128],na[128],ma[128];

	for (;;) {
		printf("Enter Section:");
		gets(sc);
		printf("Enter Name:");
		gets(na);
		printf("Enter maxargv:");
		gets(ma);
		m=atoi(ma);
		n=akb_gs_akbstpl(sc,na,argv,m);
		if (m>0) {
/*
			for (i=0;i<m;i++) printf("argv[%d](%08x)\n",i,argv[i]);
*/
			for (i=0;i<m;i++) printf("argv[%d](%08x)=[%s]\n",i,argv[i],argv[i]);
		}
	}
}
