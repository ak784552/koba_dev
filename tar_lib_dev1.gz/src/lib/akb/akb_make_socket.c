static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/******************************************************************/
/*  �֐���                                                        */
/*        int   akb_make_socket()                                   */
/*                                                                */
/*  ������                                                        */
/*                                                                */
/*                                                                */
/*  �߂�l                                                        */
/*        > 0                : �\�P�b�g�h�c                       */
/*        -1                 : �����ُ�                           */
/*                                                                */
/*  �����T�v                                                      */
/*        �ڑ��p�\�P�b�g���쐬                                    */
/******************************************************************/
#include <akbcommon.h>

static int iSLEEP = 10;
static struct  sockaddr_in   sin={0,0};
static INT4 glMakeSocketParm[5]={0,0,0,-1,0};	/* hid,port,typr,linger */

/********************************************************/
/*                                                      */
/* add 2003.2.26 Koba () */
/********************************************************/
static int _set_linger_time(linger)
char *linger;
{
	int linger_time,ret;

	if (linger && *linger) {
		if (ret = akxccvn(10,linger,strlen(linger),&linger_time)) {
			ERROROUT2("_set_linger_time: linger=[%s] error=%d",linger,ret);
			return -1;
		}
		glMakeSocketParm[3] = linger_time;
	}
	return 0;
}

/********************************************************/
/*                                                      */
/********************************************************/
int   akba_make_socket_func(cpProcName,defaultService,iRetry,socketFunc)
char *cpProcName, *defaultService;
int iRetry;
int (*socketFunc)();
{
	char *argv[5],*service;
	int n,iSleep;

	n = akb_gs_akb_stpl(BLK_SERVICE,cpProcName,argv,5);
#ifdef	DEBUG
printf("akba_make_socket: ProcName = [%s], n = %d\n", cpProcName,n);
#endif
	if (n < 0) return n;
	/******************************
	   argv[0] : ProcName
	   argv[1] : Service Name
	   argv[2] : Sleep Time (sec)
	   argv[3] : Retry Number
	   argv[4] : Linger Time (sec)
	*******************************/
	if (n >= 5) {
		if (_set_linger_time(argv[4]) < 0) return -1;
	}
	if (n >= 4) {
#ifdef	DEBUG
printf("akba_make_socket: iRetry = %s\n", argv[3]);
#endif
		iRetry = atoi(argv[3]);
	}
	if (n >= 3) {
#ifdef	DEBUG
printf("akba_make_socket: iSleep = %s\n",argv[2]);
#endif
		iSleep = atoi(argv[2]);
	}
	else iSleep = iSLEEP;
	if (n >= 2) {
		service = argv[1];
#ifdef	DEBUG
printf("akba_make_socket: service is %s\n",service);
#endif
	}
	if (n<=1) {
    	if (!defaultService) return -1;
    	service = defaultService;
	}
	return akb_make_socket_sleep_func(service,iRetry,iSleep,socketFunc);
}

/********************************************************/
/*                                                      */
/* add 2000.8.9 Koba */
/********************************************************/
int   akba_make_socket(cpProcName,defaultService,iRetry)
char *cpProcName, *defaultService;
int iRetry;
{
	return akba_make_socket_func(cpProcName,defaultService,iRetry,NULL);
}

/********************************************************/
/*                                                      */
/********************************************************/
int   akb_make_socket(service,iRetry)
char *service;
int iRetry;
{
	return akb_make_socket_sleep(service,iRetry,iSLEEP);
}

/********************************************************/
/*                                                      */
/********************************************************/
int  akb_make_socket_sleep_func(service,iRetry,iSleep,socketFunc)
char *service;	/* hostname:service/proto%linger */
int iRetry,iSleep;
int (*socketFunc)();
{
	int iSd = 0 ;
	int	t, ret;
/*
	struct  sockaddr_in   sin   ;
*/
	struct  servent      *pServ ;
	unsigned short port_no, port_n;
	int optval, optlen, type;
	char *argv[4],*proto;
	UINT4 host_addr_h;

/*
printf("akb_make_socket_sleep:service=[%s] iRetry=%d iSleep=%d\n",
service,iRetry,iSleep);
*/
	memset(glMakeSocketParm,0,sizeof(glMakeSocketParm));
	glMakeSocketParm[3] = -1;
#if 0
	ret = akb_host_service_proto(service,argv);
#else
	ret = akb_host_service_proto_linger(service,argv);
#endif
	if (ret < 0) return ret;
	if (!stricmp(argv[2],"udp")) {
		type = SOCK_DGRAM;
		proto = "udp";
	}
	else {
		type = SOCK_STREAM;
		proto = "tcp";
	}
	glMakeSocketParm[2] = type;

	host_addr_h = INADDR_ANY;
	if (argv[0]) {
		if (type==SOCK_DGRAM) {
			ret = akb_get_host_addr(argv[0],&host_addr_h);
			if (ret < 0) return ret;
		}
	}
	glMakeSocketParm[0] = host_addr_h;

	/* �|�[�g�ԍ��f���� */
	ret = akb_get_port_no_proto(argv[1],proto);
	if (ret < 0) return ret;
	port_no = ret;
	port_n = htons(port_no);
	glMakeSocketParm[1] = port_no;

	t = iRetry;
	if (iSleep<=0) iSleep = 5;

	for (;;) {
		/* �\�P�b�g�쐬 */
		/* add 2000.8.9 Koba */
		if (socketFunc) iSd = socketFunc(AF_INET, type, 0);
		else iSd = socket(AF_INET, type, 0);
		if (iSd < 0) {
			ERROROUT1("akb_make_socket_sleep: socket: %s",strerror(errno));
			return -1 ;
		}

		if (type == SOCK_STREAM) {
			/* �\�P�b�g�I�v�V�����̐ݒ�
			   �|�[�g��TIME_WAIT���ł������|�[�g���g�p�\�ɂ���*/
			optval = 1;
			optlen = sizeof(optval);
			if (setsockopt(iSd,SOL_SOCKET,SO_REUSEADDR,(char *)&optval,optlen)){
				ERROROUT1("akb_make_socket_sleep: setsockopt: %s",strerror(errno));
				close( iSd );
				return -1;
			}
#if 1	/* add 2003.2.26 Koba () */
			if (_set_linger_time(argv[3]) < 0) {
				close(iSd);
				return -1;
			}
#endif
		}

		/* �a�h�m�c */
		memset((char *)&sin, 0, sizeof(sin));
		sin.sin_family      = AF_INET;
		sin.sin_port        = port_n;
		sin.sin_addr.s_addr = htonl(host_addr_h);

		if (type==SOCK_DGRAM && argv[0])
			break;	/* UDP��host:���w�肳�ꂽ�Ƃ��́Abind���Ȃ�*/

		if (!bind(iSd, (struct sockaddr *)&sin, sizeof(sin))) {
			if (type == SOCK_STREAM) {
				/* �k�h�r�s�d�m */
				if ( listen( iSd , 5 ) ) {
					ERROROUT1("akb_make_socket_sleep: listen: %s",strerror(errno));
				/* 2000.10.6 Koba
					shutdown( iSd, 0 );
				*/
					close( iSd );
					return -1;
				}
			}
			break;
		}
		else {
			ERROROUT1("akb_make_socket_sleep: bind: %s",strerror(errno));
			ERROROUT4(" --> service=[%s] port=%d retry=%d sleep=%d(sec)",
			          service,port_no,t,iSleep);
		}
	/* 2000.10.6 Koba
		shutdown( iSd, 0 );
	*/
		close( iSd );
		iSd = -1;
		if (iRetry >= 0) {
			if (t-- <= 0) break;
		}
		sleep( iSleep );
	}
#ifdef	DEBUG
printf("akb_make_socket_sleep:service=[%s] port_no=%d iSd=%d bind&listen Ok.\n",
service,ntohs(port_n),iSd);
#endif
	return(iSd);
}

/* add 2000.8.9 Koba */
/********************************************************/
/*                                                      */
/********************************************************/
int   akb_make_socket_sleep(service,iRetry,iSleep)
char *service;
int iRetry,iSleep;
{
	return akb_make_socket_sleep_func(service,iRetry,iSleep,NULL);
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_service_proto(Service,argv)
char *Service,*argv[];
{
	char *argv2[3];
	int  ret;
	
	ret = akb_service_proto_linger(Service,argv2);
	argv[0] = argv2[0];
	argv[1] = argv2[1];

	return 0;
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_host_service_proto(String,argv)
char *String,*argv[];
{
	char *argv2[4];
	int  ret;
	
	ret = akb_host_service_proto_linger(String,argv2);
	argv[0] = argv2[0];
	argv[1] = argv2[1];
	argv[2] = argv2[2];

	return ret;
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_get_make_sock_addr(psa,len)
struct sockaddr_in  *psa;
int len;
{
	int len_sin;

	if (!psa) return -1;
	len_sin = sizeof(struct sockaddr_in);
	if (len == len_sin) memcpy(psa,&sin,len_sin);
	else len_sin = -2;
	return len_sin;
}

/********************************************************/
/*                                                      */
/* hid,port,typr,linger */
/********************************************************/
int akb_get_make_sock_parm(n,parm)
int  n;
INT4 parm[];
{
	int i,m;

	if ((m=n) > 4) m = 4;
	for (i=0;i<m;i++) parm[i] = glMakeSocketParm[i];
	return m;
}
/********************************************************/
/*                                                      */
/********************************************************/
int akb_host_service_proto_linger(String,argv)
char *String,*argv[];
{
	static char temp[256];
	char *p;
	int  ret;

	/* 0x04 is for IPv6 Host Addr */
	if ((ret=akxtget2vsep(String,argv,temp,sizeof(temp),':',0x04)) < 0)
		return ret;
	else if (ret > 0) {
		p = argv[1];
	}
	else {
		argv[0] = NULL;
		p = String;
	}

	ret = akb_service_proto_linger(p,argv+1);
/*
printf("akb_host_service_proto_linger:String=[%s] host=[%s] service=[%s] proto=[%s] linger=[%s]\n",
String,argv[0],argv[1],argv[2],argv[3]);
*/
	return ret;
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_service_proto_linger(Service,argv)
char *Service,*argv[];
{
	static char temp[128],*seps="/%";
	int ret;

#if 1
	if (!Service) return -1;
	if ((ret=strlen(Service)) >= sizeof(temp)) return -2;
	memcpy(temp,Service,ret+1);
	ret = akxtgetvseps(temp,argv,seps,0);
#else
	if ((ret=akxtget2vsep(Service,argv,temp,sizeof(temp),'/',0)) < 0)
		return ret;
	else if (ret > 0) {
		ret = akb_service_linger(argv[1],argv+1);
	}
	else {
		pp = argv[1];
		ret = akb_service_linger(argv[0],argv+1);
		if (ret >= 0) {
			argv[0] = argv[1];
			argv[1] = pp;
		}
	}
#endif
/*
printf("akb_service_proto_linger:Service=[%s] service=[%s] proto=[%s] linger=[%s]\n",
Service,argv[0],argv[1],argv[2]);
*/
	return ret;
}

/********************************************************/
/*                                                      */
/********************************************************/
int akb_service_linger(Service,argv)
char *Service,*argv[];
{
	static char temp[128];
	int ret;

	if ((ret=akxtget2vsep(Service,argv,temp,sizeof(temp),'%',0)) < 0) {
/*
printf("akb_service_linger:ret=%d\n",ret);
*/
		return ret;
	}
/*
	else if (!ret) argv[1] = NULL;
*/
/*
printf("akb_service_linger:Service=[%s] ret=%d service=[%s]\n",Service,ret,argv[0]);
if (argv[1]) printf("akb_service_linger:linger=[%s]\n",argv[1]);
*/
	return ret;
}
