static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testx2f.c akbcom.a ../xcom/akxcom.a -o testx2f
*/
#include "cpacommon.h"
#include "cpacommon.h"
int main()
{
	int len,n;
	char buf[128],*cpPacket,*cpFv[2];
	CPAMSGCOM  tSendMsg;
	tdtCOMM_PACK_HEAD   tHead,*pHead;
	pSdPacketTable pNew,pOld;

	memset(&tSendMsg,0,sizeof(CPAMSGCOM));
	tSendMsg.msg_prid = 1401;
	tSendMsg.msg_clid = 1;
	tSendMsg.msg_disp = 1;
	tSendMsg.msg_hoid = 0;
	tSendMsg.msg_pmsg   = "S,GetLog";
	tSendMsg.msg_mlen = strlen(tSendMsg.msg_pmsg) + 1;
	tSendMsg.msg_filc = 1;
	tSendMsg.msg_filv = cpFv;
	cpFv[0] = "a.dat";

	pHead = &tHead;
	pHead->cph_prt.prt_ver        = 'C' ;
	pHead->cph_prt.prt_send  = 0 ;
	pHead->cph_prt.prt_cmnd    = htons(5);
	pHead->cph_sinf.ind_hoid      = htonl(0xbbbbbbbb);
	pHead->cph_sinf.ind_clid    = htons(1);
	pHead->cph_sinf.ind_prid  = htons(10001);
	pHead->cph_sinf.ind_thrd     = 1 ;
	pHead->cph_sinf.ind_disp     = 1 ;
	pHead->cph_sinf.ind_pano    = htons(10);
	pHead->cph_dinf.ind_hoid     = htonl(0xaaaaaaaa);
	pHead->cph_dinf.ind_clid   = htons(2);
	pHead->cph_dinf.ind_prid = htons(1401);
	pHead->cph_dinf.ind_thrd    = 0 ;
	pHead->cph_dinf.ind_disp    = 0 ;
	pHead->cph_dinf.ind_pano   = 0 ;
	pHead->cph_plen            = 0 ;

	len = akb_create_pk_data(NULL,pHead,&tSendMsg,&cpPacket);
	printf("akb_create_pk_data len=%d\n",len);
	if (len<=0 || !cpPacket) exit(0);

	akxaxdump("F",cpPacket,len);

	printf("exec akbs_make_xpacket. Hit any key");
	gets(buf);
	printf("len=%d?",len);
	gets(buf);
	n = atoi(buf);
	if (n <= 0) n = len;
	if (n > len) {
		pOld = akb_packet_tbl_new(n);
		memcpy(pOld->sp_content,cpPacket,len);
	}
	else {
		pOld = akb_packet_tbl_new(0);
		pOld->sp_content = cpPacket;
	}
	len = n;
	pOld->sp_len = len;
	pHead = (tdtCOMM_PACK_HEAD *)pOld->sp_content;
	pHead->cph_plen = htonl(len-32);
	pNew = akbs_make_xpacket(pOld);
	if (!pNew) exit(0);

	akxaxdump("X",pNew->sp_content,pNew->sp_len);

	printf("exec akbs_xto_fpacket. Hit any key");
	gets(buf);
	len = pNew->sp_len;
	printf("len=%d?",len);
	gets(buf);
	n = atoi(buf);
	if (n <= 0) n = len;
	if (n > len) {
		pOld = akb_packet_tbl_new(n);
		memcpy(pOld->sp_content,pNew->sp_content,len);
	}
	else {
		pOld = akb_packet_tbl_new(0);
		pOld->sp_content = pNew->sp_content;
	}
	len = n;
	pOld->sp_len = len;
	pHead = (tdtCOMM_PACK_HEAD *)pOld->sp_content;
	pHead->cph_plen = htonl(len-32);
	pNew = akbs_xto_fpacket(pOld);
	if (pNew) akxaxdump("F",pNew->sp_content,pNew->sp_len);
}
