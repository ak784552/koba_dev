static	char	sccsid[]="%Z% %M% %I% %E% %U%";
#include "akbcommon.h"

#define TIMEOUTSET_SIZE	10
static int giTimeOutSet[TIMEOUTSET_SIZE]=
	{DEFAULT_TIMEOUT,DEFAULT_TIMEOUT,DEFAULT_TIMEOUT,DEFAULT_TIMEOUT
	,DEFAULT_TIMEOUT,DEFAULT_TIMEOUT,DEFAULT_TIMEOUT,DEFAULT_TIMEOUT
	,DEFAULT_TIMEOUT,DEFAULT_TIMEOUT
	};
	/* read, write, connect, accept */

static char gcSignalMsg[256]={'\0'};

/******************************************************************************
  �֐���
        void    akb_set_com_time_out()

  ������
		proc : 		Call���̃v���Z�X��

  �ԋp�l

  �����T�v
	�ʐM�^�C���A�E�g���Ԃ�akb.inf����ǂݍ��ݐݒ肷��
******************************************************************************/
static int _set_com_time_out_func(c1,section,na1,na2,argv,n,dummy)
char c1,*section,*na1,*na2,**argv;
int  n;
char *dummy;
{
	int i,timeset[TIMEOUTSET_SIZE];
/*
printf("_set_com_time_out_func: c1=%c section=%s na1=%s na2=%s n=%d\n",
c1,section,na1,na2,n);
*/
	if (n > 0) {
		if (--n > 0) {
			if (n > TIMEOUTSET_SIZE) n = TIMEOUTSET_SIZE;
			for (i=0;i<n;i++) {
				timeset[i] = atoi(argv[i+1]);
/*
printf("    timeset[%d] = %d\n",i,timeset[i]);
*/
			}
			akb_set_time_out_set(timeset,n);
		}
	}

	return n;
}

static int _set_com_time_out_sub(section,name1,name2,opt)
char *section,*name1,*name2;
int  opt;
{
	char *namv[3],*argv[TIMEOUTSET_SIZE+1],order[9];
	int n;
/*
printf("_set_com_time_out_sub:section=[%s] name1=[%s] name2=[%s] opt=%x\n",
section,name1,name2,opt);
*/
	namv[0] = section;
	namv[1] = name1;
	namv[2] = name2;
	strcpy(order,"1 2 3 ");
	if (opt) strcat(order,"4 ");
	n = akb_gs_akb_stpl_func(namv,'.',order,argv,TIMEOUTSET_SIZE+1,
			_set_com_time_out_func,NULL);
/*
printf("_set_com_time_out_sub:Exit n=dx\n",n);
*/
	return n;
}

int akb_set_com_time_out(proc)
char *proc;
{
	return _set_com_time_out_sub(BLK_TIMEOUT,proc,NULL,0);
}

int akb_set_sys_com_time_out(proc,opt)
char *proc;
int  opt;
{
	return _set_com_time_out_sub(BLK_AKBSYSTEM,BLK_TIMEOUT,proc,opt);
}

/************************************/
/*                                  */
/************************************/
int
akb_set_time_out(num)
int	num;
{
/*
	timeOutNumber = num;

	return timeOutNumber;
*/
	int t[1];

	t[0] = num;
	return akb_set_time_out_set(t,1);
}

/************************************/
/*                                  */
/************************************/
int
akb_get_time_out()
{
/*
	return timeOutNumber;
*/
/*
printf("akb_get_time_out:Enter \n");
*/
	return akb_get_time_outi(0);
}

/************************************/
/*                                  */
/************************************/
int akb_set_time_out_set(timeset,n)
int timeset[],n;
{
	int i,t,m;

	if (!timeset) return -1;
	if (n > TIMEOUTSET_SIZE) n = TIMEOUTSET_SIZE;
	for (m=0,i=0;i<n;i++)
		if ((t=timeset[i]) >= -2) {
			m++;
			if ((giTimeOutSet[i]=t) == -2)
				giTimeOutSet[i] = DEFAULT_TIMEOUT;
		}
	return m;
}

/************************************/
/*                                  */
/************************************/
int akb_get_time_outi(i)
int i;
{
	int t=DEFAULT_TIMEOUT;
/*
printf("akb_get_time_outi: i=%d\n",i);
*/
	if (i>=0 && i<TIMEOUTSET_SIZE) t = giTimeOutSet[i];
/*
printf("akb_get_time_outi: t=%d\n",t);
*/
	return t;
}

/************************************/
/*                                  */
/************************************/
int akb_get_time_out_set(timeset,n)
int timeset[],n;
{
	if (!timeset) return -1;
	if (n > TIMEOUTSET_SIZE) n = TIMEOUTSET_SIZE;
	memcpy(timeset,giTimeOutSet,n*sizeof(int));
	return n;
}

/************************************/
/*                                  */
/************************************/
void akb_sock_time_out()
{
	ERROROUT1("*** SIGALRM (timeout) %s",gcSignalMsg);
	alarm(0);
#ifndef SUNOS
	signal(SIGALRM, akb_sock_time_out);
#endif
	return;
}

/************************************/
/*                                  */
/************************************/
void sock_time()
{
	akb_sock_time_out();
	return;
}

/************************************/
/*                                  */
/************************************/
void akb_broken_pipe()
{
	ERROROUT1("*** SIGPIPE (broken pipe) %s",gcSignalMsg);
#ifndef SUNOS
	signal(SIGPIPE, akb_broken_pipe);
#endif
	return;
}

/************************************/
/*                                  */
/************************************/
int akb_set_signal_msg(fmt,a1,a2,a3,a4,a5)
char *fmt,*a1,*a2,*a3,*a4,*a5;
{
	sprintf(gcSignalMsg,fmt,a1,a2,a3,a4,a5);
	return 0;
}
