static  char    sccsid[]="%Z% %M% %I% %E% %U%";
#include "akbcommon.h"

int akb_set_pkt_form(pInfoParm ,pBuff)
tdtINFO_PARM  *pInfoParm;
char       *pBuff;
{
	int  rc;
	char att;
	char acc;
	int  len;
	INT4  lw,lLen,lww;
	short sw,sww;
	unsigned char uw;
	char *cpDat, *p;

	att = pInfoParm->pi_attr;
	lLen = pInfoParm->pi_dlen;
	cpDat = pInfoParm->pi_data;

	switch( att )
		{
		case DEF_ZOK_CHAR :
			if ( lLen > 255 )
				acc = D_ACC_EXT;
			else
				acc = D_ACC_STD;
			break;
		case DEF_ZOK_BINA :
			if ( lLen == sizeof( char ) )
				acc = D_ACC_CHAR;
			else if ( lLen == sizeof( short int ) )
				acc = D_ACC_SHORT;
			else if ( lLen == sizeof(INT4) )
				acc = D_ACC_LONG;
			else
				return -2;
			break;
		case DEF_ZOK_BULK :
			acc = D_ACC_EXT;
			break;
		case DEF_ZOK_KANS :
			acc = D_ACC_STD;
			break;
		defaults:
			return -1;
		}

	len = lLen;
	if ( att == DEF_ZOK_BINA ) {
			len += sizeof( FORM_S );
	}
	else {
		if ( acc == D_ACC_EXT )
			len += sizeof( FORM_K );
		else
			len += sizeof( FORM_S );
	}

	if ( att == DEF_ZOK_BINA ) {
		att =  ( att << 4 ) & 0xf0 ;
		pBuff[0] = att | acc;
		pBuff[1] = ( char )lLen;
		p = pBuff+sizeof(FORM_S);
		if (lLen == 4) {
			memcpy(&lw, cpDat, lLen );
			lww = htons(lw);
			memcpy(p, &lww, lLen );
		}
		else if (lLen == 2) {
			memcpy(&sw, cpDat, lLen );
			sww = htonl(sw);
			memcpy(p, &sww, lLen );
		}
		else memcpy(p, cpDat, lLen);
	}
	else {
		pBuff[0] = (( att << 4 ) & 0xf0 ) | acc;
		if ( att == DEF_ZOK_CHAR )
			pBuff[0] |= (pInfoParm->pi_code << 1) & 0x0e;
		if ( acc == D_ACC_EXT ) {
			pBuff[1] = 0x00;
			lw = htonl(lLen);
			memcpy(pBuff+2, (char *)&lw, sizeof(INT4) );
			 p = pBuff+sizeof(FORM_K);
		}
		else {
			pBuff[1] = ( char )lLen ,
			 p = pBuff+sizeof(FORM_S);
		}
		memcpy(p,cpDat,lLen);
	}

	return len;
}

int akb_get_data( pPrmHead, pPrmInfo )
char      *pPrmHead ;              /* �p�����[�^�̐擪�ւ̃A�h���X    */
tdtINFO_PARM *pPrmInfo ;              /* �p�����[�^���\����/*/
{
	return akb_get_data_byte_order(pPrmHead, pPrmInfo, 0);
}

int akb_get_data_byte_order(pPrmHead, pPrmInfo, ucByteOrder)
char      *pPrmHead ;              /* �p�����[�^�̐擪�ւ̃A�h���X    */
tdtINFO_PARM *pPrmInfo ;              /* �p�����[�^���\����/*/
uchar      ucByteOrder;		/* 0/1:none/ntoh */
{
	FORM_S        *pStd   = NULL;
	FORM_K        *pKak   = NULL;
	tdtINDIRECT_INFO *pInfo  = NULL;
	unsigned int   iAttr  = 0;
	unsigned int   iForm  = 0;
	char          *pData  = NULL;
	INT4           lLen   = 0;
	INT4           fLen   = 0;
	char           cAL;
	char          *pByte  = NULL;
	INT4  lw,alLen,lww;
	short sw,sww;
	unsigned char uw;
	int iScale,iCode;	/* add 94.2.2 Koba */

	if(!pPrmHead) return -1;

	/*
	 * ����������
	 */
  
	/* ���\���̂����������܂� */
	memset(pPrmInfo, 0, sizeof(tdtINFO_PARM));
    
	/* ���������x�擾 */
	cAL = (char)*(pPrmHead+0);
	iAttr = (int)( ( cAL >> 4 ) & 0x0f );
	iForm = (int)( cAL & 0x0f );
	iScale = cAL & 0x0f;
	iForm = iScale & 0x01;
	pPrmInfo->pi_scale = iScale;
	pPrmInfo->pi_code = (iScale & 0x0e)>>1;
	/*
	 * �e�f�[�^�擾
	 */
	/* �t�H�[�}�b�g���g���`���̎� */
	if( (iAttr == DEF_ZOK_CHAR && iForm == 0) || iAttr == DEF_ZOK_BULK ) {
		/* �f�[�^�����擾 */
		pKak = (FORM_K *)pPrmHead;
		memcpy((char *)&lw,pKak->dlen,sizeof(INT4));
		if (ucByteOrder) lLen = ntohl(lw);
		else lLen = lw;

		pPrmInfo->pi_id   = ' ';		/* ���ڌ`��       */
		pPrmInfo->pi_attr = iAttr;	/* ����             */
		pPrmInfo->pi_dlen  = lLen;		/* �f�[�^��       */
		pPrmInfo->pi_hlen  = sizeof( FORM_K ); /* �t�H�[�}�b�g��(�W��&�g��)*/
		pPrmInfo->pi_len  = sizeof( FORM_K );  /* �p�����[�^�� */
		                      + lLen;
		if( lLen >= 0 ) {
			alLen = lLen;
			if (iAttr == DEF_ZOK_CHAR) alLen++;
			if (alLen > 0) {
				if (!(pPrmInfo->pi_data=Malloc(alLen))) {
					return (-1);
				}
				pPrmInfo->pi_scale |= 0x80;
				if (lLen > 0) memcpy(pPrmInfo->pi_data, pKak+1, lLen );
				if (iAttr == DEF_ZOK_CHAR) pPrmInfo->pi_data[lLen] = '\0';
			}
		}
		else if (lLen < 0) return (-1);
	}
	else {
		/* �W���`���E���� */
		if( !( iAttr & DEF_ZOK_KANS ) ) {
			/* �f�[�^�����擾 */
			pStd = (FORM_S *)pPrmHead;
			lLen = (int)pStd->dlen;
			pPrmInfo->pi_id   = ' ';		/* ���ڌ`��   */
           	pPrmInfo->pi_attr = iAttr;	/* ����         */
           	pPrmInfo->pi_dlen  = lLen;		/* �f�[�^��     */
			pPrmInfo->pi_hlen  = sizeof( FORM_S ); /* �t�H�[�}�b�g��(�W��)*/
			pPrmInfo->pi_len  = sizeof( FORM_S );  /* �p�����[�^�� */
			                      + lLen;
			if( lLen >= 0 ) {
				alLen = lLen;
				if (iAttr == DEF_ZOK_CHAR) alLen++;
				if (alLen > 0) {
					if (!(pPrmInfo->pi_data=Malloc(alLen))) {
						return (-1);
					}
					pPrmInfo->pi_scale |= 0x80;
					if (lLen > 0) {
						pStd++;
						if (ucByteOrder && (iAttr==DEF_ZOK_BINA) && lLen>1) {
							if (lLen == 2) {
								memcpy(&sw, pStd, lLen );
								sww = ntohs(sw);
								memcpy(pPrmInfo->pi_data, &sww, lLen );
							}
							else {
								memcpy(&lw, pStd, lLen );
								lww = ntohl(lw);
								memcpy(pPrmInfo->pi_data, &lww, lLen );
							}
						}
						else
							memcpy(pPrmInfo->pi_data, pStd, lLen );
					}
					if (iAttr == DEF_ZOK_CHAR) pPrmInfo->pi_data[lLen] = '\0';
				}
			}
			else if (lLen < 0) return (-1);
		}
		else {
			iAttr &= 0x07;     /* ����         */
			pByte = (char *)pPrmHead;
			pStd  = (FORM_S *)pPrmHead;
			pInfo = (tdtINDIRECT_INFO *)( pPrmHead + sizeof( FORM_S ) );
			lLen  = pStd->dlen;
			fLen  = lLen - sizeof( tdtINDIRECT_INFO );
            
			pPrmInfo->pi_id   = pByte[2];
			pPrmInfo->pi_attr = iAttr;
			memcpy((char *)&lw,&pByte[6],sizeof(INT4));
			if (ucByteOrder) pPrmInfo->pi_pos = ntohl(lw);
			else pPrmInfo->pi_pos = lw;
			memcpy((char *)&lw,&pByte[10],sizeof(INT4));
			if (ucByteOrder) pPrmInfo->pi_dlen = ntohl(lw);
			else pPrmInfo->pi_dlen = lw;
			pPrmInfo->pi_hlen  = sizeof( FORM_S ); /* �t�H�[�}�b�g��(�W��)*/
			pPrmInfo->pi_len  = sizeof( FORM_S );  /* �p�����[�^�� */
			                      + sizeof( tdtINDIRECT_INFO )
			                      + fLen;
			if( fLen >= 0 ) {
				if (!(pPrmInfo->pi_data=Malloc(fLen+1))) {
					return (-1);
				}
				pPrmInfo->pi_scale |= 0x80;
				if (fLen > 0) memcpy(pPrmInfo->pi_data, pInfo+1, fLen );
				pPrmInfo->pi_data[fLen] = '\0';
			}
			else if (fLen < 0) return (-1);
		}
	}
	return NORMAL;
}

/**********************************************************/
/*              by A.Koba 6.19                            */
/**********************************************************/
int akb_chk_data( pPrmHead, pPrmInfo )
char      *pPrmHead ;              /* �p�����[�^�̐擪�ւ̃A�h���X    */
tdtINFO_PARM *pPrmInfo ;              /* �p�����[�^���\���� */
{
	return akb_change_data(pPrmHead, pPrmInfo, 0);
}

int akb_change_data(pPrmHead, pPrmInfo, ucByteOrder)
char      *pPrmHead ;              /* �p�����[�^�̐擪�ւ̃A�h���X    */
tdtINFO_PARM *pPrmInfo ;              /* �p�����[�^���\���� */
uchar      ucByteOrder;		/* 0/1:none/ntoh */
{
	FORM_S        *pStd   = NULL;
	FORM_K        *pKak   = NULL;
	tdtINDIRECT_INFO *pInfo  = NULL;
	unsigned int   iAttr  = 0;
	unsigned int   iForm  = 0;
	char          *pData  = NULL;
	INT4           lLen   = 0;
	INT4           fLen   = 0;
	char           cAL;
	char          *pByte  = NULL;
	INT4  lw,alLen,lww;
	short sw,sww;
	unsigned char uw;
	int iScale,iCode;	/* add 94.2.2 Koba */

	if( pPrmHead == NULL ) return -1;

	/* ���\���̂����������܂� */
	memset(pPrmInfo,0, sizeof(tdtINFO_PARM));

	/* ���������x�擾 */
	cAL = (char)*(pPrmHead+0);
	iAttr = (int)( ( cAL >> 4 ) & 0x0f );
	iScale = cAL & 0x0f;
	iForm = iScale & 0x01;
	pPrmInfo->pi_scale = iScale;
	pPrmInfo->pi_code = (iScale & 0x0e)>>1;
    
	/* �t�H�[�}�b�g���g���`���̎� */
	if((iAttr==DEF_ZOK_CHAR && iForm==0) || iAttr==DEF_ZOK_BULK) {
		/* �f�[�^�����擾 */
		pKak = (FORM_K *)pPrmHead;
		memcpy((char *)&lw,pKak->dlen,sizeof(INT4));
		if (ucByteOrder) {
			lLen = ntohl(lw);
			memcpy(pKak->dlen,(char *)&lLen,sizeof(INT4));
		}
		else lLen = lw;
        
		pPrmInfo->pi_id   = ' ';              /*            */
		pPrmInfo->pi_attr = iAttr;            /* ����             */
		pPrmInfo->pi_dlen  = lLen;             /* �f�[�^��       */
		pPrmInfo->pi_hlen  = sizeof( FORM_K ); /* �t�H�[�}�b�g��(�W��&�g��)*/
		pPrmInfo->pi_len  = sizeof( FORM_K );  /* �p�����[�^�� */
		                      + lLen;
		pPrmInfo->pi_data = (char *)(pKak+1);
	}
	else {
		/* �W���`���E���ځi�p�P�b�g�j */
		if( !( iAttr & DEF_ZOK_KANS ) ) {
			/* �f�[�^�����擾 */
			pStd = (FORM_S *)pPrmHead;
			lLen = (int)pStd->dlen;
			pPrmInfo->pi_id   = ' ';              /*           */
			pPrmInfo->pi_attr = iAttr;            /* ����         */
			pPrmInfo->pi_dlen  = lLen;             /* �f�[�^��     */
			pPrmInfo->pi_hlen  = sizeof( FORM_S ); /* �t�H�[�}�b�g��(�W��)*/
			pPrmInfo->pi_len  = sizeof( FORM_S );  /* �p�����[�^�� */
			                      + lLen;
			pStd++;
			pPrmInfo->pi_data = (char *)pStd;
			if (ucByteOrder && (iAttr==DEF_ZOK_BINA) && lLen>1) {
				if (lLen == 2) {
					memcpy(&sw, pStd, lLen );
					sww = ntohs(sw);
					memcpy(pPrmInfo->pi_data, &sww, lLen );
				}
				else {
					memcpy(&lw, pStd, lLen );
					lww = ntohl(lw);
					memcpy(pPrmInfo->pi_data, &lww, lLen );
				}
			}
		}
		else {
			iAttr &= 0x07;     /* ����         */
			pByte = (char *)pPrmHead;
			pStd  = (FORM_S *)pPrmHead;
			pInfo = (tdtINDIRECT_INFO *)( pPrmHead + sizeof( FORM_S ) );
			lLen  = pStd->dlen;
			fLen  = lLen - sizeof( tdtINDIRECT_INFO );
            
			pPrmInfo->pi_id   = pByte[2];
			pPrmInfo->pi_attr = iAttr;
			memcpy((char *)&lw,&pByte[6],sizeof(INT4));
			if (ucByteOrder) {
				lww = ntohl(lw);
				pPrmInfo->pi_pos = lww;
				memcpy(&pByte[6],(char *)&lww,sizeof(INT4));
			}
			else pPrmInfo->pi_pos = lw;
			memcpy((char *)&lw,&pByte[10],sizeof(INT4));
			if (ucByteOrder) {
				lww = ntohl(lw);
				pPrmInfo->pi_dlen = lww;
				memcpy(&pByte[10],(char *)&lww,sizeof(INT4));
			}
			else pPrmInfo->pi_dlen = lw;
			pPrmInfo->pi_hlen  = sizeof( FORM_S ); /* �t�H�[�}�b�g��(�W��)*/
			pPrmInfo->pi_len  = sizeof( FORM_S );  /* �p�����[�^�� */
			                      + sizeof( tdtINDIRECT_INFO )
			                      + fLen;
			pPrmInfo->pi_data = (char *)(pInfo+1);
		}
	}
    
	return 0;
}

int akb_get_int_data(p)
tdtINFO_PARM *p;
{
	int l,i=0;

	if (p && p->pi_data) {
		if ((l=p->pi_dlen) == 2) i = *(short *)p->pi_data;
		else if (l == 4) i = *(INT4 *)p->pi_data;
		else i = *(uchar *)p->pi_data;
	}
	return i;
}
