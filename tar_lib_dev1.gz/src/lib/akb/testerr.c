static    char    sccsid[]="%Z% %M% %I% %D% %T%";
/*
	cc -g -DSUNOS -I../include testerr.c -o testerr
*/
#include <stdio.h>
#include <stdio.h>
main()
{
	char wd[256];
	int  err,info;

	for (;;) {
		printf("Enter error code ==>");
		gets(wd);
		err = akb_error_code(atoi(wd),&info);
		printf("ret=%d info=%d\n",err,info);
	}
}

int akb_error_code(iError,ipErrInfo)
int iError,*ipErrInfo;
{
    int iEr,iErU;

    if ((iEr=iError) < 0) iEr = -iEr;

	iErU = iEr / 10000;
	if (ipErrInfo) *ipErrInfo = iErU;

    if (iErU>=1 && iErU<=3) {
		iEr %= 10000;
    	if (iEr <= 999) {
       	 iEr += 9000;
       	 if (iError < 0) iEr = -iEr;
       	 return iEr;
    	}
	}

    return iError;
}
