#include <stdio.h>
#include <stdio.h>
#include <sys/time.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/resource.h>
/*
int getrlimit(resource, rlp)
int resource;
struct rlimit *rlp;

int setrlimit(resource, rlp)
int resource;
struct rlimit *rlp;
struct rlimit {
int  rlim_cur; * �J�����g (�\�t�g) ���~�b�g *
int  rlim_max; * �n�[�h�E���~�b�g *
};
*/
main()
{
	int rc;
	struct rlimit rl;
	
	rc = getrlimit(RLIMIT_NOFILE, &rl);
	printf("rlim_cur=%d rlim_max=%d\n",rl.rlim_cur,rl.rlim_max);
}
