/*static    char    sccsid[]="@(#) akbcommon.h 1.1 97/08/28 11:51:38";*/
/*********************************************************/
/*                                                       */
/*     akbcommon.h                                       */
/*                                                       */
/*              coded by A.Kobayashi 96.1.17             */
/*                                                       */
/*********************************************************/
#ifndef _AKBCOMMON_H
#define _AKBCOMMON_H

#include "akxcommon.h"
#include "akb.h"

#endif	/* _AKBCOMMON_H */
