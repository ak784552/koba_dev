/*static    char    sccsid[]="@(#) akb.h 1.1 97/08/28 11:51:38";*/
/*********************************************************/
/*                                                       */
/*     akb.h                                             */
/*                                                       */
/*              coded by A.Kobayashi 95.12.12            */
/*                                                       */
/*********************************************************/
#ifndef _AKB_H
#define _AKB_H

#include "akbconst.h"
#include "akberror.h"
#include "akbstruct.h"
#include "akbmacro.h"
#include "akbprot.h"

#endif	/* _AKB_H */
