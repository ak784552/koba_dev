/*static    char    sccsid[]="@(#) akacommon.h 1.1 97/08/28 11:51:38";*/
/*********************************************************/
/*                                                       */
/*     akacommon.h                                       */
/*                                                       */
/*              coded by A.Kobayashi 96.1.30             */
/*                                                       */
/*********************************************************/
#ifndef _AKACOMMON_H
#define _AKACOMMON_H

#include "akbcommon.h"
#include "aka.h"

#endif	/* _AKACOMMON_H */
