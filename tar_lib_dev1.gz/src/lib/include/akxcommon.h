/*static    char    sccsid[]="@(#) akx.h 1.1 97/08/28 11:51:38";*/
/*********************************************************/
/*                                                       */
/*     akxcommon.h                                       */
/*                                                       */
/*              coded by A.Kobayashi 2000.8.10           */
/*                                                       */
/*********************************************************/
#ifndef _AKXCOMMON_H
#define _AKXCOMMON_H

#include "akunix.h"
#include "akx.h"

#endif	/* _AKXCOMMON_H */
