tar cvf tar_lib_dev2 \
	backup.sh .alias \
	src/Makefile src/*.mk \
	src/lib/Makefile src/lib/mdiff* \
	src/lib/include/*.h \
	src/lib/akx/*.c src/lib/akx/makefile src/lib/akx/*.txt src/lib/akx/bak \
	src/lib/akb/*.c src/lib/akb/makefile \
	src/lib/aka/*.c src/lib/aka/makefile
gzip tar_lib_dev2

tar cvf tar_appl_coal_dev2 \
	src/appl/Makefile src/appl/*.mk src/appl/mdiff* \
	src/appl/cmn/*.c src/appl/cmn/makefile \
	src/appl/coal/*.c src/appl/coal/makefile src/appl/coal/*.mk src/appl/coal/*.ctl \
	src/appl/coal/tree/*.c src/appl/coal/tree/makefile \
	src/appl/coal/cmd/*.c src/appl/coal/cmd/makefile \
	src/appl/coal/bexp/*.c src/appl/coal/bexp/makefile \
	src/appl/coal/func/*.c src/appl/coal/func/makefile \
	src/appl/coal/ep/*.c src/appl/coal/ep/makefile \
	src/appl/coal/test \
	src/appl/include/*.h \
	src/appl/tools/*.[ch] src/appl/tools/Makefile src/appl/tools/*.txt  src/appl/tools/*.sh
gzip tar_appl_coal_dev2
