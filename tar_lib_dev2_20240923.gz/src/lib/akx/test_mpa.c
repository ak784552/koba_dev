/*
	cc -DLINUX -O -I../include test_mpa.c libakx.a -o test_mpa
*/
#include "akxcommon.h"
main()
{
	MPA a,b,c;
	char buf[128],work[128];
	int  i,n;

	printf("Enter number a ==> ");
	gets(buf);
	m_set_a(&a,buf);
	printf("Enter number b ==> ");
	gets(buf);
	m_set_a(&b,buf);
	for (;;) {
		printf("Enter kaisu (quit:<=0)==> ");
		gets(buf);
		n=atoi(buf);
		if (n<1) break;
		akx_get_log_time(buf,sizeof(buf),NULL);
		printf("start   %s\n",buf);
		for (i=0;i<n;i++) {
			m_mul(&c,&a,&b);
		}
		m_mpa2an(&c,work,sizeof(work),0);
		akx_get_log_time(buf,sizeof(buf),NULL);
		printf("end mul %s c=%s\n",buf,work);
		for (i=0;i<n;i++) {
			m_div(&c,&a,&b);
		}
		m_mpa2an(&c,work,sizeof(work),0);
		akx_get_log_time(buf,sizeof(buf),NULL);
		printf("end div %s c=%s\n",buf,work);
	}
}
