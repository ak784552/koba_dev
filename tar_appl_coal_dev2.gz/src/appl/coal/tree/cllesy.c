static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************/
/* <cllesy.c>                                           */
/*      ������ & �\�����                             */
/*      �������C��                                      */
/********************************************************/

#include "colmn.h"

extern CLCOMMON  CLcommon;
#if 0
extern condList  CLcList;	/* ��񃊃X�g */
extern tableRoot CLtbl;		/* ��͂��镶�����i�[�����̈�*/
extern CLPRTBL   CLprocTable;
extern CLNCB     CLSTCB;
#endif
/************************/
/* cl_lex_file_open		*/
/************************/
FILE *cl_lex_file_open(scrname,dir,_fn_)
char *scrname,*dir,*_fn_;
{
	FILE *fp;

DEBUGOUTL1(110,"cl_lex_file_open: scrname=[%s]",scrname);

	fp = cl_file_open(scrname,dir);
	if (!fp) {
				/* *** [%s] Open Error. Check up SCRIPTPATH */
		ERROROUT2(FORMAT(49),_fn_,scrname);
				/* *** SCRIPTPATH=[%s] */
		ERROROUT2(FORMAT(50),_fn_,CLcommon.ScrPathp);
	}
DEBUGOUTL1(110,"cl_lex_file_open: fp=%08x",fp);
	return fp;
}

/************************/
/* cl_lex_syn (�������C��)*/
/************************/
int cl_lex_syn(y,scrname)
condList *y;
char *scrname;
{
	static char *_fn_="cl_lex_syn";
	char dir[256],*p;
	int  rc = 0;

DEBUGOUTL1(110,"cl_lex_syn: scrname=[%s]",scrname);

	y->fp = cl_lex_file_open(scrname,dir,_fn_);
	if (!y->fp) return ECL_SCR_NOTFOUND;	/* �t�@�C���I�[�v���G���[ */
	y->line = 0;
	y->option = 0;

	if (!(y->fullname = cl_const_malloc(strlen(dir)+1)))
		return ECL_MALLOC_ERROR;
	strcpy(y->fullname,dir);
	y->clstcb->TopStack = NULL;

#ifdef TIME
akb_ptime('S',"cl_lex_syn");
#endif
	rc = cl_lex(y);
#ifdef TIME
akb_ptime('E',"cl_lex_syn");
akb_ptime('E',scrname);
#endif

	return(rc);
}

/************************/
/* _is_reg_fopen		*/
/************************/
static FILE *_is_reg_fopen(dir)
char *dir;
{
	struct stat tStat;
	char *p;
	FILE *fp;

DEBUGOUTL1(110,"_is_reg_fopen: dir=[%s]",dir);

	if (dir) {
		if (!stat(p=akb_akb_home_add(dir),&tStat)) {
			if (S_ISREG(tStat.st_mode)) {
				if (fp = fopen(p,"r")) {
					 return fp;
				}
			}
		}
	}
	return NULL;
}

/**********************************************/
/* cl_file_open    (�X�N���v�g�t�@�C���I�[�v��) */
/**********************************************/
FILE *cl_file_open(fn,dir)
char *fn,*dir;     /* OPEN ����t�@�C���� */
{
	FILE *fp;
	char *p,*dp,c;

DEBUGOUTL1(110,"cl_file_open: fn=[%s]",fn);

	strcpy(dir,fn);
	if (fp = _is_reg_fopen(dir)) return fp;
	if ((c=*dir)=='/' || c=='\\' ||
	    !memcmp(dir,"./",2)  || !memcmp(dir,".\\",2)  ||
	    !memcmp(dir,"../",3) || !memcmp(dir,"..\\",3)) return NULL;
	if (p=CLcommon.ScrPathp) {
		while (*p) {
			dp = dir;
			while ((c = *p) && c!=':') {
				if (c == '~') {
					strcpy(dp,CLcommon.pHomeDir);
					dp += strlen(dp);
				}
				else *dp++ = c;
				p++;
			}
			if (*(dp-1)!='/') *dp++ = '/';
			*dp = '\0';
			if (strcmp(dir,"./")) {
				strcpy(dp,fn);
			/*	if (fp = fopen(dir,"r")) {	*/
			/*	if (fp = fopen(akb_akb_home_add(dir),"r")) {
					return fp;
				} */
				if (fp = _is_reg_fopen(dir)) return fp;
			}
			if (*p) p++;
		}
	}
	return NULL;	/* �t�@�C���I�[�v���G���[ */
}
