static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       leaf      *cl_make_leaf                 */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out                                     */
/*              Normal                           */
/*                  leaf  *RootLeaf              */
/*              AbNormal   NULL                  */
/* --------------------------------------------- */
/*  Function :                                   */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/*********************************************/
/*                                           */
/*********************************************/
int cl_make_leaf(y)
condList *y;
{
	Leaf  *Dummy;
	char *p;
	int len,i;
	cmdInfo *cmd;

	cmd = y->cmd;
	len = sizeof(Leaf) + sizeof(CMDObject) +
	     (sizeof(parmList *)/*+sizeof(GXObject *)*/)*(cmd->prmnum+3);	/* 2-->3 2020.10.29 */
	p = Malloc(len);
	if (p == NULL) return SysError;
	Dummy = (Leaf *)p;
	memset(p,0,sizeof(Leaf));
	p += sizeof(Leaf);
	Dummy->cmd.cmdobj = (CMDObject *)p;
	memset(p,0,sizeof(CMDObject));
	p += sizeof(CMDObject);
	Dummy->cmd.prmp = (parmList **)p;
/*	len = sizeof(parmList *)*(CLcList.cmd.prmnum+2);
	p += len;
	Dummy->cmd.bxobj = (GXObject **)p;
	memset(Dummy->cmd.bxobj,0,len);	*/
	cl_copy_cmd(&Dummy->cmd,cmd);
	memcpy(Dummy->cmd.prmp,
	       cmd->prmp,sizeof(parmList *)*(cmd->prmnum+2));	/* 1-->2 2020.10.29 */
	cmd->prmp[cmd->prmnum+2] = NULL;	/* 1-->2 2020.10.29 */
/*
for (i=0;i<CLcList.cmd.prmnum+1;i++) printf("leaf: prmp[%d]=[%s] bxobj=%08x\n",
i,cmd->prmp[i]->prp,cmd->prmp[i]->bxobj);
for (i=0;i<Dummy->cmd.prmnum;i++) printf("leaf: prmp[%d]=[%s]\n",i,Dummy->cmd.prmp[i]->prp);
*/
#if 1
	Dummy->cmd.parl = cmd->parl;
	Dummy->cmd.parnum = cmd->parnum;
	cmd->parl = NULL;
	cmd->parnum = 0;
/*
printf("cl_make_leaf: parl[0].par=[%s]\n",Dummy->cmd.parl[0].par);
printf("              parl[2].par=[%s]\n",Dummy->cmd.parl[2].par);
*/
#endif
#if 1	/* 2023.8.11 */
	Dummy->lf_label = y->cdl_label;
	y->cdl_label = NULL;
#endif
	Dummy->cmd.cmdobj->cid = Dummy->cmd.cid;
/*
printf("cl_make_leaf:Dummy->cmd.bxobj[0]=%08x\n",Dummy->cmd.bxobj[0]);
*/
/*
	Dummy->preleaf   = NULL;
	Dummy->rightleaf = NULL;
	Dummy->leftleaf  = NULL;
	Dummy->pFlag = 0;
	Dummy->cmdtag = 0;
	Dummy->pad[0] = 0;
	Dummy->pad[1] = 0;
	Dummy->type = 0;
*/
	y->AddressRoot = Dummy;
	return( NormalEnd );
}

/************************************/
/* _make_node_leaf					*/
/************************************/
static Leaf *_make_leaf(cno)
int cno;
{
	Leaf *Dummy;
	Leaf *leaf;
	char *p;
	int len,i;

	len = sizeof(Leaf) + sizeof(CMDObject) + sizeof(parmList *) + sizeof(ParList)*MAX_PARL;
	p = Malloc(len);
	if (p == NULL) return NULL;
	memset(p,0,len);
	Dummy = (Leaf *)p;
	Dummy->cmd.cid = cno;
	p += sizeof(Leaf);
	Dummy->cmd.cmdobj = (CMDObject *)p;
	p += sizeof(CMDObject);
	Dummy->cmd.prmp = (parmList **)p;
	Dummy->cmd.prmp[0] = NULL;
	p += sizeof(parmList *);
	Dummy->cmd.parl = (ParList *)p;
	Dummy->cmd.parnum = MAX_PARL;
	Dummy->cmd.cmdobj->cid = Dummy->cmd.cid;
/*
printf("_make_leaf: cid=%08x\n",Dummy->cmd.cid);
*/
	return Dummy;
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_push                      */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     �n���ꂽ���[�t���X�^�b�N�ɐς݁A          */
/*       �����P�[�W���쐬����B                  */
/*************************************************/
int cl_push(y)
condList *y;
{
	CLNCB *p;
/*
printf("cl_push: AddressRoot=%08x CLSTCB.TopStack=%08x\n",y->AddressRoot,y->CLSTCB.TopStack);
*/
	if (!y->AddressRoot) return -1;
	p = y->clstcb;
	if (p->TopStack) {
		p->TopStack->rightleaf = y->AddressRoot;
		y->AddressRoot->preleaf = p->TopStack;
	}
	else {
		p->TopTree = y->AddressRoot;
		p->DefTopStack = NULL;
	}
	p->TopStack = y->AddressRoot;
	p->StackCounter++;
	return 0;
}

int cl_pushd(y)
condList *y;
{
	CLNCB *p;
	Leaf *leaf,*Dummy;
/*
printf("cl_pushd: AddressRoot=%08x CLSTCB.TopStack=%08x\n",y->AddressRoot,y->CLSTCB.TopStack);
*/
	if (!y->AddressRoot) return -1;
	p = y->clstcb;
	if (p->TopStack) {
		if (p->TopTree->cmd.cid != C_NODE_DEFINE) {
			leaf = _make_leaf(C_NODE_DEFINE);
			leaf->rightleaf = p->TopTree;
			p->TopTree->preleaf = leaf;
			p->TopTree = leaf;
		/*	p->TopStack = leaf;	*/
			leaf->leftleaf = y->AddressRoot;
			p->DefTopStack = y->AddressRoot;
		}
		else {
			p->DefTopStack->rightleaf = y->AddressRoot;
			y->AddressRoot->preleaf = p->DefTopStack;
		}
	}
	else {
		leaf = _make_leaf(C_NODE_DEFINE);
		p->TopTree = leaf;
		leaf->leftleaf = y->AddressRoot;
		p->TopStack = leaf;
	}
	p->DefTopStack = y->AddressRoot;
	return 0;
}

/*************************************************/
/*  Program name                                 */
/*       int        cl_change_tree               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       In         Leaf  *leaf                  */
/*                                               */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     �n���ꂽ���[�t�̃����P�[�W���č쐬����B  */
/* --------------------------------------------- */
/*************************************************/
int cl_change_tree(y,leaf)
condList *y;
Leaf  *leaf;
{
	int rc,LeafCount;

	rc = LeafCount = 0;
	y->clstcb->TopStack = leaf;
#if 1	/* 2023.8.5 */
	leaf->cmd.type <<= 4;	/* ���̒l��ۑ� */
#else
	leaf->cmd.type = 0;
#endif
	if (leaf->rightleaf == (Leaf *)NULL) goto End;
	else {
		leaf->leftleaf = leaf->rightleaf;
		leaf->rightleaf = (Leaf *)NULL;
		leaf = leaf->leftleaf;
		for(;;) {
			LeafCount++;
			if (leaf->rightleaf == (Leaf *)NULL) break;
			leaf = leaf->rightleaf;
		}
	}
	y->clstcb->StackCounter -= LeafCount;
	return 0;
 End:
	return -1;
}

/************************************/
/* cl_make_node_leaf				*/
/************************************/
Leaf *cl_make_node_leaf(pConstCt, cno, name)
ConstantCt *pConstCt;
int  cno;
char *name;
{
	int len;
	parmList *lp;
	Leaf     *leafw;
	char *p;

#if 1	/* 2024.3.16 */
	len = sizeof(Leaf)+sizeof(parmList *)+sizeof(parmList)+strlen(name)+1+sizeof(ParList)*MAX_PARL;
	if (!(p = Malloc(len))) return NULL;
	memset(p,0,len);
	leafw = (Leaf *)p;
	p += sizeof(Leaf)+sizeof(parmList *);
	lp = (parmList *)p;
#else
	leafw = (Leaf *)Malloc(len=sizeof(Leaf)+sizeof(parmList *));
	if (!leafw) return NULL;

	memset(leafw,0,len);
	lp = (parmList *)cl_const_ct_malloc(pConstCt,
	                                 sizeof(parmList)+strlen(name)+1);
	if (!lp) {
		Free(leafw);
		return NULL;
	}
	memset(lp,0,sizeof(parmList));
#endif
	lp->prmlen = len;
#if 0	/* 2024.3.16 */
	lp->prp = (char *)(lp+1);
	strcpy(lp->prp,name);
#endif
	leafw->cmd.cid    = cno;
	leafw->cmd.prmp   = (parmList **)(leafw+1);
	leafw->cmd.prmp[0]= lp;
	leafw->cmd.prmnum = 1;
#if 0
#if 0	/* 2024.3.16 */
	p += sizeof(parmList);
	leafw->cmd.parl=(ParList *)p;
#else
	if (!(leafw->cmd.parl=(ParList *)cl_const_ct_malloc(pConstCt,sizeof(ParList)*MAX_PARL))) {
		Free(leafw);
		return NULL;
	}
#endif
	leafw->cmd.parnum = MAX_PARL;
	memset(leafw->cmd.parl,0,sizeof(ParList)*leafw->cmd.parnum);
#endif
#if 1	/* 2024.3.16 */
	p += sizeof(ParList)*MAX_PARL;
	lp->prp = (char *)p;
	strcpy(lp->prp,name);
#endif
	return leafw;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_make_push_leaf(y)
condList *y;
{
	int rc;

	if (!(rc=cl_make_leaf(y))) {
		cl_pre_nest(y);
		if (!(rc=cl_push(y))) rc= cl_change_stcb(y);
	}
	return rc;
}

/**************************************************************/
/* search_top_leaf                                            */
/* function; Search Top Leaf                                  */
/**************************************************************/
Leaf *search_top_leaf(y)
condList *y;
{
	Leaf *Dummy;

	if (Dummy = y->clstcb->TopStack) {
#if 1
		Dummy = y->clstcb->TopTree;
#else
		for (;;) {
			if (!Dummy->preleaf) break;
			Dummy = Dummy->preleaf;
		}
#endif
	}
	return Dummy;
}
