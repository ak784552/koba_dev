static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_if                  */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Justify no shori.                         */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"

/********************************************/
/*											*/
/********************************************/
static int _parmset(y,p,len)
condList *y;
char *p;
int len;
{
	int rc;
	ParList parl;
/*
printf("_parmset:Enter: len=%d\n",len);
*/
	rc = 0;
#if 1	/*2024.5.24 */
	if ((len=akxtstrim2(0x04,p,len,&parl," \t")) > 0)
		rc = clparmset(y,parl.par,parl.parlen);
#else
#if 1
	if ((len=akxtstrim(0,p,len," \t")) > 0)	/* 1-->0 2018.10.14 */
#else
	if (akxnskipin(p,len," \t") < len)
#endif
		rc = clparmset(y,p,len);
#endif
/*
printf("_parmset:Exit : len=%d\n",len);
*/
	return rc;
}

/********************************************/
/*											*/
/********************************************/
static int _change_try_with_resources(y)
condList *y;
{
	static char *_func_="_change_try_with_resources";
	static char sep[]={" \t\"'();"};
	SSPL_S ssp;
	int rc,len,i,num,pnm_len,st_pos,nbun;
	int kk_level;	/* ()�̃l�X�g���x�� */
	char *pnm,buf[33];
	GWPRM_S gwprm;
	cmdInfo *cmd;

	cmd = y->cmd;
	if ((rc=cl_tr_gather(y,0)) <= 0) return rc;
	pnm = cmd->prmp[0]->prp;
	pnm_len = cmd->prmp[0]->prmlen;
	num = cmd->prmnum;
/*
printf("%s: num=%d pnm_len=%d pnm=[%s]\n",_func_,num,pnm_len,pnm);
*/
	memset(&ssp,0,sizeof(SSPL_S));
	if ((len=akxtgwns(pnm,pnm_len,&ssp,sep,0x21)) > 0) {
		if (*ssp.wd != '(') {
			rc = ECL_SCRIPT_ERROR;
			memnzcpy(buf,ssp.wd,len,sizeof(buf));
			ERROROUT2("%s: ���ʂ�����܂���B[%s]",_func_,buf);
			goto Err;
		}
	}
	else {
		cmd->prmnum = 0;
		return 0;
	}
	st_pos = ssp.sp;
	kk_level = 1;
	rc = nbun = 0;
	while ((len=akxtgwns(pnm,pnm_len,&ssp,sep,0x21)) > 0) {
		switch (*ssp.wd) {
		case '(':
			kk_level++;
			break;
		case ')':
			if (--kk_level <= 0) {
				if ((len=akxtpkns(pnm,pnm_len,&ssp," \t",0x21)) > 0) {
					memnzcpy(buf,ssp.wd,len,sizeof(buf));
					/* %s: �E����')'�̌��ɗ]���Ȍ��[%s]������܂��B(sp=%d) */
					ERROROUT3(FORMAT(96),_func_,buf,ssp.sp);
				 	rc = ECL_SCRIPT_ERROR;
					goto Err;
				}
/*
printf("%s: st_pos=%d ssp.sp=%d\n",_func_,st_pos,ssp.sp);
*/
				if (rc=_parmset(y,pnm+st_pos,ssp.sp-st_pos-1)) goto Err;
			}
			break;
		case ';':
			rc = ECL_SCRIPT_ERROR;
			if (kk_level > 1) {
				/* %s: ��؂�';'�̈ʒu���s���ł��B(sp=%d) */
				ERROROUT2(FORMAT(97),_func_,ssp.sp);
				goto Err;
			}
			if (rc=_parmset(y,pnm+st_pos,ssp.sp-st_pos-1))  goto Err;
			st_pos = ssp.sp;
			break;
		}
	}
	rc = ECL_SCRIPT_ERROR;
	if (kk_level > 0) {
		ERROROUT1(FORMAT(99),_func_);	/* %s: ���ʂ����Ă��܂���B */
		goto Err;
	}
	num = --cmd->prmnum;
	for (i=0;i<num;i++) cmd->prmp[i] = cmd->prmp[i+1];
	return num;
 Err:
	cmd->prmnum = num;
 	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_if(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum == 0) {
		ERROROUT(FORMAT(91));	/* col_mn_tr_if: �_�������K�v�ł��B */
		return ECL_TR_IF;
	}
	if ((rc = cl_tr_gather(y,0)) >= 0) rc = cl_make_push_leaf(y);
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_try(y)
condList *y;
{
	static int able[]={C_ENDTRY,C_PROC};
	static int deny[]={C_TRY,C_CATCH,C_FINALLY};
	int rc;

#if 1	/* 2017.05.20 */
	if ((rc=_change_try_with_resources(y)) < 0 ) {
#else
	if (cmd->prmnum > 0) {
		ERROROUT1(FORMAT(41),"col_mn_tr_try");	/* %s: �s�v�ȃp�����[�^������܂��B */
#endif
		return ECL_TR_IF;
	}
/*	if (!(rc=cl_tr_node_check(deny,3,able,2))) */rc = cl_make_push_leaf(y);
	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_throw(y)
condList *y;
{
	int rc;

	if (y->cmd->prmnum == 0) {
		ERROROUT1(FORMAT(92),"col_mn_tr_throw");	/* %s: �����K�v�ł��B */
		return ECL_TR_IF;
	}
	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);
	return rc;
}
