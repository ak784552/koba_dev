static char sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_on                  */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*  Version                    1.00  2010/05/28  */
/*************************************************/
/* */

#include "colmn.h"
#if 0
extern condList  CLcList;
extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */
#endif
/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_on(y)
condList *y;
{
	int rc;
#if 0
	if (cl_search_not_on(y)) {
		ERROROUT(FORMAT(107));	/* col_mn_tr_on: �擪�ȊO�ɂ́A�w��ł��܂���B */
		return ECL_TR_ON;
	}
#endif
/*
�n�m�R�}���h�g���p�� �����ł́A�ŏ��p�����[�^���݂̂��`�F�b�N����B
*/
	if (y->cmd->prmnum < 3) {
		ERROROUT1(FORMAT(42),"col_mn_tr_on");
		return ECL_TR_ON;
	}
	if (!(rc=cl_make_leaf(y)))
#if 1
		rc = cl_pushd(y);
#else
		rc = cl_push(y);
#endif

	return rc;
}

/*********************************************/
/*                                           */
/*********************************************/
int cl_search_not_on(y)
condList *y;
{
	Leaf *Dummy;
	int  ret,cno;

	Dummy = y->clstcb->TopStack;
#if 0
	ret = 0;
	if (Dummy) {
printf("cl_search_not_on:TopStack: cid=%08x\n",Dummy->cmd.cid);
	/*
		if (Dummy->cmd.cid != C_NODE_DEFINE) ret = 1;
		else {
			Dummy = CLSTCB.DefTopStack;
	*/
			cno = Dummy->cmd.cid;
/*
printf("cl_search_not_on:DefTopStack: cid=%08x\n",cno);
*/
			if (cno==C_ONN || cno==C_DEFINE || cno==C_DIM ||
			    cno==C_IMPORT || cno==C_NODE_DEFINE) ret = 0;
			else ret = 1;
	/*	}	*/
	}
	return ret;
#else
	while (Dummy) {
/*
printf("cl_search_not_on: cid=%08x\n",Dummy->cmd.cid);
*/
		if (Dummy->cmd.cid != C_ONN &&
		    Dummy->cmd.cid != C_DEFINE &&
		    Dummy->cmd.cid != C_DIM &&
		    Dummy->cmd.cid != C_IMPORT &&
	/*	    Dummy->cmd.cid != 0 &&	*/
		    Dummy->cmd.cid != C_NODE_DEFINE) {
/*
printf("cl_search_not_on: cid=%08x\n",Dummy->cmd.cid);
*/
				return 1;
		}
		Dummy = Dummy->preleaf;
	}
	return 0;
#endif
}
