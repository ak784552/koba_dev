static  char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_define              */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/
/* */

#include "colmn.h"          /* �\���̒�` */

extern GlobalCt *pGlobTable;
#if 0
extern condList  CLcList;  /* ��񃊃X�g */
#endif
/*********************************************/
/*                                           */
/*********************************************/
int cl_tr_get_def_is(scno)
int scno;
{
	int is;

	if (scno == CS_TYPE) is = 3;
/*	else if (scno == CS_MAPPEDARRAY) is = 1;	*/
	else if (scno == CS_VAR) is = 1;
#if 1	/* 2023.2.25 */
	else if (scno==CS_DEFINE || scno==CS_SCALAR) is = 0;
#endif
	else if (scno==CS_OPTION || scno==CS_OPTIONS) is = -1;
	else is = 0;

	return is;
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_define(y)
condList *y;
{
	int  rc,m,scno,is,no_def_node;
	char *name,c;
	qSubCommand *sc;
	parmList *pL;
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->cid == C_DIM) {
		name = "col_mn_tr_dim";
		m = 1;
#if 1
		if (cl_nest_tag(y,1) == SysError)
			/* PROC�̊O�� */
			no_def_node = 0;
		else
			no_def_node = 1;
#else
		no_def_node = cl_search_not_on();
#endif
	}
	else if (cmd->cid == C_REDEFINE) {
		name = "col_mn_tr_re_define";
		m = 1;
		no_def_node = 1;
	}
	else {
		if (cmd->cid == C_DEFINE) {
			name = "col_mn_tr_define";
			m = 1;
			no_def_node = 0;
		}
		else if (cmd->cid == C_IMPORT) {
			name = "col_mn_tr_import";
			m = 1;
#if 1
			no_def_node = 0;
#else
			if (no_def_node=cl_search_not_on(y)) {
				ERROROUT1(FORMAT(61),name);	/* %s: �擪�ȊO�ɂ́A�w��ł��܂���B */
				return ECL_TR_DEFINE;
			}
#endif
		}
		else return -1;
#if 0
		if (no_def_node=cl_search_not_on(y)) {
			ERROROUT1(FORMAT(61),name);	/* %s: �擪�ȊO�ɂ́A�w��ł��܂���B */
			return ECL_TR_DEFINE;
		}
#endif
	}
	rc = 0;
	if (cmd->prmnum < m) {
		ERROROUT1(FORMAT(42),name);	/* %s: �p�����[�^������܂���B */
		rc = ECL_TR_DEFINE;
	}
	else if (cmd->cid==C_IMPORT && cmd->prmnum > 3) {
		/* %s: �]���ȃp�����[�^[%s]������܂��B */
		ERROROUT2(FORMAT(43),name,cmd->prmp[3]->prp);
		rc = ECL_TR_DEFINE;
	}

	if (!rc) {
		if (cmd->cid==C_DEFINE || cmd->cid==C_REDEFINE) {
			scno = cl_tr_set_scno(cmd,0/*CS_ARRAY*/,0x01,0xfe);
			if (scno == CS_TYPE) {
				if (!stricmp(cmd->prmp[1]->prp,"STRUCT")) is = 3;
				else is = 2;
				cmd->prmp[0]->prp[4] = '\0';
				cmd->prmp[0]->prmlen = 4;
			}
			if (scno==CS_DEFINE || scno==CS_SCALAR) {
				return ECL_TR_DEFINE;
			}
			else if (scno == CS_IMPLICIT) {
				if (cmd->prmnum < 3) {
					ERROROUT1(FORMAT(42),name);	/* %s: �p�����[�^������܂���B */
					return ECL_TR_DEFINE;
				}
				is = 1;
			}
			else is = cl_tr_get_def_is(scno);
			if (is >= 0) {
				if ((rc=cl_tr_gather(y,is)) > 0) rc = 0;
			}
			if (scno==CS_OPTION || scno==CS_OPTIONS) {
DEBUGOUTL1(100,"[ %s ] in col_mn_tr_define()",cl_get_pcmdc_line(cmd));
				if (scno == CS_OPTION)
					rc = let_option(cmd->prmnum,cmd->prmp,NULL);
				else
					rc = let_options(cmd->prmnum,cmd->prmp,NULL);
/*
printf("col_mn_tr_define: rc=%d\n",rc);
*/
				if (rc < 0) return rc;
			}
			else if (scno == CS_ARRAY) {
/*
printf("col_mn_tr_define: prp=[%s]\n",CLcList.cmd.prmp[0]->prp);
*/
				if ((c=*cmd->prmp[0]->prp)=='<' || c=='>') {
					cmd->sub_cid = CS_REDIRECT;
				}
			}
		}
		else if (cmd->cid == C_DIM) {
			if ((rc=cl_tr_gather(y,0)) > 0) rc = 0;
		}
	}

	if (!rc) {
		if (!(rc=cl_make_leaf(y))) {
			if (no_def_node)
				rc = cl_push(y);
			else
				rc = cl_pushd(y);
		}
	}

	return rc;
}

int col_mn_tr_re_define(y)
condList *y;
{
	int rc,scno;
	qSubCommand *sc;
	parmList *pL;
#if 1
	return col_mn_tr_define(y);
#else
	if (cmd->prmnum < 2) {
		ERROROUT1(FORMAT(42),"col_mn_tr_re_define");	/* %s: �p�����[�^������܂���B */
		rc = ECL_TR_DEFINE;
	}
	else if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	if (!rc) cl_tr_set_scno(y->cmd,CS_ARRAY,0x01,0xfe);

	return rc;
#endif
}

int col_mn_tr_un_define(y)
condList *y;
{
	int rc;

	if (!y->cmd->prmnum) {
		ERROROUT1(FORMAT(42),"col_mn_tr_un_define");	/* %s: �p�����[�^������܂���B */
		rc = ECL_TR_DEFINE;
	}
	else if (!(rc = cl_make_leaf(y))) rc = cl_push(y);
	return rc;
}
