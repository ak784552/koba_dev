static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_break               */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Paragraph �^�O�̏������s���B              */
/* --------------------------------------------- */
/*************************************************/
/* */

#include "colmn.h"          /* �\���̒�` */
#if 0
extern condList  CLcList;  /* ��񃊃X�g */
#endif
/*********************************************/
/*                                           */
/*********************************************/
static int _col_mn_tr(y,name,msg,errc)
condList *y;
char *name,*msg;
int  errc;
{
	int rc;
/*
	if ( CLcList.cmd.prmnum > 0 ) {
		ERROROUT1(FORMAT(41),name);
		return errc;
	}
*/
	if (!(y->option & D_CLST_OPT_COMMAND)) {
		if (cl_search_loop(y,0)) {
			/* %s: �k�n�n�o���Ȃ��̂�%s���ݒ肳��܂����B */
			ERROROUT2(FORMAT(56),name,msg);
			return errc;
		}
	}
	if (!(rc = cl_make_leaf(y))) rc = cl_push(y);

	return rc;
}
/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_break(y)
condList *y;
{
	return _col_mn_tr(y,"col_mn_tr_break",FORMAT(57),ECL_TR_BREAK);	/* �a�q�d�`�j */
}

/*********************************************/
/*                                           */
/*********************************************/
int col_mn_tr_continue(y)
condList *y;
{
	return _col_mn_tr(y,"col_mn_tr_continue",FORMAT(58),ECL_TR_CONTINUE);	/* �b�n�m�s�h�m�t�d */
}
