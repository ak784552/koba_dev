static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*************************************************/
/*  Program name                                 */
/*       int       col_mn_tr_loop                */
/* --------------------------------------------- */
/*  (I/O)                                        */
/*       Out        0   :Normal                  */
/*                 -1   :AbNormal                */
/* --------------------------------------------- */
/*  Function :                                   */
/*     Justify no shori.                         */
/* --------------------------------------------- */
/*************************************************/
#include "colmn.h"
#if 0
extern condList  CLcList;  /* ��񃊃X�g */
extern tableRoot CLtbl;   /* ��͂���^�O�y�ѕ������i�[�����̈�*/
extern CLNCB     CLSTCB;  /* �^�O�̍\����͂��s�����߂̗̈� */
#endif
static char sep[]={" \t\"'();"};

/********************************************/
/*	for (i=0 ; i<10; i++)					*/
/********************************************/
int cl_change_from_for_sub(line,line_len,parl)
char *line;
int line_len;
ParList parl[];
{
	static char *_func_="cl_change_from_for_sub";
	SSP_S ssp;
	int rc,wlen,i,num,pnm_len,st_pos,nbun,len;
	int kk_level;	/* ()�̃l�X�g���x�� */
	char *pnm,buf[33],*pp;

	pnm = line;
	pnm_len = line_len;
/*
printf("%s:Enter pnm_len=%d pnm=[%s]\n",_func_,pnm_len,pnm);
*/
	memset(&ssp,0,sizeof(SSP_S));
	i = 0;
	st_pos = 1;
	ssp.sp = st_pos;
	kk_level = 1;
	rc = nbun = 0;
	while ((wlen=akxtgwns(pnm,pnm_len,&ssp,sep,0x21)) > 0) {
/*
printf("%s: ssp.wd=[%c] ssp.sp=%d\n",_func_,*ssp.wd,ssp.sp);
*/
		switch (*ssp.wd) {
		case '(':
			kk_level++;
			break;
		case ')':
			if (--kk_level <= 0) {
				if ((len=akxtpkns(pnm,pnm_len,&ssp," \t",0x21)) > 0) {
					memnzcpy(buf,ssp.wd,len,sizeof(buf));
				/*	if (stricmp(buf,"AS")) {	*/
						/* %s: �E����')'�̌��ɗ]���Ȍ��[%s]������܂��B(sp=%d) */
						ERROROUT3(FORMAT(96),_func_,buf,ssp.sp);
					 	rc = ECL_SCRIPT_ERROR;
						goto Err;
				/*	}	*/
				}
/*
printf("%s: st_pos=%d ssp.sp=%d\n",_func_,st_pos,ssp.sp);
*/
				parl[i].par = pnm + st_pos;
				parl[i++].parlen = ssp.sp - st_pos - 1;
			}
			break;
		case ';':
			rc = ECL_SCRIPT_ERROR;
			if (kk_level > 1) {
				/* %s: ��؂�';'�̈ʒu���s���ł��B(sp=%d) */
				ERROROUT2(FORMAT(97),_func_,ssp.sp);
				goto Err;
			}
			else if (++nbun > 2) {
				/* %s: ��؂�';'���������܂��B(sp=%d) */
				ERROROUT2(FORMAT(98),_func_,ssp.sp);
				goto Err;
			}
			parl[i].par = pnm + st_pos;
			parl[i++].parlen = ssp.sp - st_pos - 1;
			st_pos = ssp.sp;
			break;
		}
	}
	rc = ECL_SCRIPT_ERROR;
	if (kk_level > 0) {
		ERROROUT1(FORMAT(99),_func_);	/* %s: ���ʂ����Ă��܂���B */
		goto Err;
	}
	else if (nbun < 2) {
		ERROROUT1(FORMAT(100),_func_);	/* %s: ��؂�';'������܂���B */
		goto Err;
	}
/*
printf("%s:Exit i=%d\n",_func_,i);
*/
	return i;
 Err:
/*
printf("%s:Exit rc=%d\n",_func_,rc);
*/
 	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_change_from_for(line,line_len,parl)
char *line;
int line_len;
ParList parl[];
{
	SSP_S ssp;
	int i,nbun,nparm,rc;
/*
printf("cl_change_from_for:Enter line_len=%d line=[%s]\n",line_len,line);
*/
	memset(&ssp,0,sizeof(SSP_S));
	if (akxtgwns(line,line_len,&ssp,sep,0x21) <= 0) return 0;
	if (*ssp.wd == '(') {
		nbun = 0;
		while (akxtgwns(line,line_len,&ssp,sep,0x21) > 0) {
			if (*ssp.wd == ';') {
				nbun++;
				break;
			}
		}
		if (!nbun) return 0;
	}
	else return 0;
	nparm = cl_change_from_for_sub(line,line_len,parl);
	return nparm;
}

/********************************************/
/*											*/
/********************************************/
static int _change_from_for(y)
condList *y;
{
	static char *_func_="_change_from_for";
	static char sep[]={" \t\"'();"};
	SSP_S ssp;
	int rc,len,i,num,pnm_len,st_pos,nbun,nparm;
	int kk_level;	/* ()�̃l�X�g���x�� */
	char *pnm,buf[33];
	GWPRM_S gwprm;
	SSPL_S sspl;
	ParList parl[3];
	cmdInfo *cmd;

	cmd = y->cmd;
	if (cmd->prmnum <= 1) return 0;
	memset(&sspl,0,sizeof(SSPL_S));
	gwprm.nparam = cmd->prmnum - 1;
	gwprm.maxlen = 0;
	gwprm.parmLp = &cmd->prmp[1];
	gwprm.iparam = 0;
	if (cl_gp_gwse(&gwprm,&sspl,sep,0x21) <= 0) return 0;
	if (*sspl.wd == '(') {
		nbun = 0;
		while (cl_gp_gwse(&gwprm,&sspl,sep,0x21) > 0) {
			if (*sspl.wd == ';') {
				nbun++;
				break;
			}
		}
		if (!nbun) return 0;
	}
	else return 0;
/*
printf("%s: nbun=%d\n",_func_,nbun);
*/
	if ((rc=cl_tr_gather(y,1)) < 0) return rc;
	pnm = cmd->prmp[1]->prp;
	pnm_len = cmd->prmp[1]->prmlen;
	num = cmd->prmnum;
/*
printf("%s: num=%d pnm_len=%d pnm=[%s]\n",_func_,num,pnm_len,pnm);
printf("%s: st_pos=%d\n",_func_,st_pos);
*/
	/* 2023.9.21 */
	if ((nparm=cl_change_from_for_sub(pnm,pnm_len,parl)) < 0) return nparm;
	for (i=0;i<nparm;i++) {
		if (rc=clparmset(y,parl[i].par,parl[i].parlen)) goto Err;
	}
/*
printf("%s: nparm=%d CLcList.cmd.prmnum=%d\n",_func_,nparm,cmd->prmnum);
*/
	num = --cmd->prmnum;
	for (i=1;i<num;i++) cmd->prmp[i] = cmd->prmp[i+1];
	return num;
 Err:
	cmd->prmnum = num;
 	return rc;
}

/********************************************/
/*											*/
/* �ԋp : < 0 : malloc�G���[				*/
/*		  = 2 or 4							*/
/********************************************/
int cl_set_to_step_parm(p1,p2,p3,pos,parl,pp0)
char *p1,*p2,*p3;
int pos;
ParList parl[];
char **pp0;
{
	static char *_fn_="cl_set_to_step_parm";
	int len,s,len2,len3,len4,nparm;
	char *p,*p0;
/*
printf("%s:Enter p1=[%s] p2=[%s] p3=[%s]\n",_fn_,p1,p2,p3);
*/
	p0 = *pp0;
			len4 = 0;
			nparm = 2;
			s = 1;
			if (p3) {
				if (!strcmp(p3,"1") || !strcmp(p3,"+1")) s = 1;
				else if (!strcmp(p3,"-1")) s = -1;
				else {
					s = 0;
					len4 = strlen(p3) + 9;
				}
			}
			len2 = len3 = pos + 5;
			len2 += strlen(p2);
			len = len2 + len3;
			if (len4) {
				len3 += len4;
				len += len4 + len2 + len3;
			}
			p0 = p =MRealloc(p0,len);
			*pp0 = p0;
			if (!p) return -1;
			memcpy(p,p1,pos);
			if (p3) {
				if (s < 0) {
					strcpy(p+pos,"--");
/*
printf("%s: wrk2=[%s]\n",_fn_,p);
*/
					parl[1].par = p;
					parl[1].parlen = strlen(p);
					p += len3;
					memcpy(p,p1,pos);
					sprintf(p+pos,">=(%s)",p2);
					parl[0].par = p;
					parl[0].parlen = strlen(p);
/*
printf("%s: wrk1=[%s]\n",_fn_,p);
*/
				}
				else if (s == 0) {
					sprintf(p+pos,"+=(%s)",p3);
/*
printf("%s: wrk2=[%s]\n",_fn_,p);
*/
					parl[1].par = p;
					parl[1].parlen = strlen(p);
					p += len3;
					memcpy(p,p1,pos);
					sprintf(p+pos,"<=(%s)",p2);
					parl[0].par = p;
					parl[0].parlen = strlen(p);
/*
printf("%s: wrk1=[%s]\n",_fn_,p);
*/
					p += len2;
					sprintf(p,"%s>=0?1:-1",p3);
					parl[2].par = p;
					parl[2].parlen = strlen(p);
/*
printf("%s: wrk3=[%s]\n",_fn_,p);
*/
					p += len4 + 1;
					memcpy(p,p1,pos);
					sprintf(p+pos,">=(%s)",p2);
					parl[3].par = p;
					parl[3].parlen = strlen(p);
					nparm = 4;
/*
printf("%s: wrk4=[%s]\n",_fn_,p);
*/
				}
			}
			if (s > 0) {
				strcpy(p+pos,"++");
/*
printf("%s: wrk2=[%s]\n",_fn_,p);
*/
				parl[1].par = p;
				parl[1].parlen = strlen(p);
				p += len3;
				memcpy(p,p1,pos);
				sprintf(p+pos,"<=(%s)",p2);
				parl[0].par = p;
				parl[0].parlen = strlen(p);
/*
printf("%s: wrk1=[%s]\n",_fn_,p);
*/
			}
/*	return len4;	*/
	return nparm;
}

/********************************************/
/*											*/
/********************************************/
static int _set_to_step_parm(y,p1,p2,p3,pos)
condList *y;
char *p1,*p2,*p3;
int pos;
{
	static char *_fn_="_set_to_step_parm";
	static char *p0=NULL;
	int ret,nparm,i;
	ParList parl[6];

	if ((ret=cl_set_to_step_parm(p1,p2,p3,pos,parl,&p0)) >= 0) {
		nparm = ret;
		y->cmd->prmnum = 2;
		/* 2023.9.23 */
		for (i=0;i<nparm;i++) {
/*
printf("%s: parl[%d].par=[%s]\n",_fn_,i,parl[i].par);
*/
			if (ret=clparmset(y,parl[i].par,parl[i].parlen)) break;
		}
	}
	return ret;
}

/********************************************/
/*	FOR i=0 TO 10 STEP 2					*/
/********************************************/
int cl_change_from_to_step_sub(prmL,num,parl)
parmList **prmL;
int num;
ParList parl[];
{
	static char *_fn_="cl_change_from_to_step_sub";
	int len,f,i,ret,nparm,pos;
	char *p;
/*
printf("%s:Enter num=%d prmL[1]->prp=[%s]\n",_fn_,num,prmL[1]->prp);
*/
	ret = nparm = pos = 0;
	if (num>=3) {
		if (!stricmp(prmL[2]->prp,"TO")) {
			if (num == 3) {
				ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B */
				return ECL_SCRIPT_ERROR;
			}
			p = prmL[1]->prp;
			len = prmL[1]->prmlen;
			parl[0].par = p;
			parl[0].parlen = len;
			nparm = 1;
			memset(&parl[1],0,sizeof(ParList)*2);
			if ((pos=akxnskipto(p,len,"=")) >= len) {
				/* %s: �����l��[%s]��'='������܂���B */
				ERROROUT2(FORMAT(485),_fn_,p);
				return ECL_SCRIPT_ERROR;
			}
			f = 0;
			for (i=3;i<num;i++) {
				if (!cl_is_not_space(prmL[i])) {
					ERROROUT1(FORMAT(486),_fn_);	/* %s: �p�����[�^��NULL�ł��B */
					ret = ECL_SCRIPT_ERROR;
				}
				else {
					p = prmL[i]->prp;
					if (i!=4 && !stricmp(p,"STEP")) {
						ERROROUT1(FORMAT(487),_fn_);	/* %s: STEP�̈ʒu���s���ł��B */
						ret = ECL_SCRIPT_ERROR;
						f = 1;
					}
					else if (i==3 || i==5) {
						parl[nparm].par = p;
						parl[nparm].parlen = prmL[i]->prmlen;
						nparm++;
					}
				}
			}
			if (num >= 5) {
				if (!f && stricmp(prmL[4]->prp,"STEP")) {
					ERROROUT1(FORMAT(488),_fn_);	/* %s: STEP������܂���B  */
					ret = ECL_SCRIPT_ERROR;
				}
				if (num == 5) {
					ERROROUT1(FORMAT(42),_fn_);	/* %s: �p�����[�^������܂���B */
					ret = ECL_SCRIPT_ERROR;
				}
				else if (num > 6) {
				/*	if (stricmp((p=prmL[6]->prp),"AS")) {	*/
						/* %s: �]���ȃp�����[�^[%s]������܂��B */
						ERROROUT2(FORMAT(43),_fn_,prmL[6]->prp);
						ret = ECL_SCRIPT_ERROR;
				/*	}	*/
				}
			}
		}
		if (!ret) ret = pos;
	}
/*
printf("%s:Exit ret=%d\n",_fn_,ret);
*/
	return ret;
}

/********************************************/
/*											*/
/********************************************/
int cl_change_from_to_step(prmp,prmnum,parl,parl2)
parmList **prmp;
int prmnum;
ParList parl[],parl2[];
{
	static char *_fn_="cl_change_from_to_step";
	static char *p0=NULL;
	int rc,pos;
/*
printf("%s:Enter prmnum=%d prmp[1]->prp=[%s]\n",_fn_,prmnum,prmp[1]->prp);
*/
	if ((rc=cl_change_from_to_step_sub(prmp,prmnum,parl)) > 0) {
		pos = rc;
		rc = cl_set_to_step_parm(parl[0].par,parl[1].par,parl[2].par,pos,parl2,&p0);
	}
	return rc;
}

/********************************************/
/*	FOR i=0 TO 10 STEP 2					*/
/********************************************/
static int _change_from_to_step(y)
condList *y;
{
	static char *_fn_="_change_from_to_step";
	int ret,i,len,num,pos,f;
	char *p1,*p2,*p3,*p;
	parmList **prmL;
	ParList parl[3];
	cmdInfo *cmd;

	cmd = y->cmd;
	num = cmd->prmnum;
	prmL = cmd->prmp;
	ret = 0;
	/* 2023.9.22 */
	if (num>=3) {
		if ((pos=cl_change_from_to_step_sub(prmL,num,parl)) > 0) {
			ret = _set_to_step_parm(y,parl[0].par,parl[1].par,parl[2].par,pos);
		}
	}
	return ret;
}

/********************************************/
/*	do i=0,10,2								*/
/*		= -1 : �J�b�R�̑Ή������Ă��Ȃ�	*/
/*		  -2 : ���ł�=������				*/
/*		  -3 : =���Ȃ�						*/
/*		  -4 : ,��2�ȏ゠��				*/
/*		  -5 : ,���Ȃ�						*/
/*		  -6 : �������ϐ����s��				*/
/*		  -7 : �J���}�̑O����				*/
/********************************************/
int cl_change_from_do_sub(line,line_len,parl,pConstCt)
char *line;
int line_len;
ParList parl[];
ConstantCt *pConstCt;
{
	static char *_fn_="cl_change_from_do_sub";
	static char sep[]={" \t\"'=,()[]{}"};
	int rc,i,len,k,s,num,pos,len_pn,sp,sp0,kk_level[3],kk;
	char *p,*pn,*p_inc,*pp;
	SSPL_S sspl;
/*
printf("%s: line_len=%d line=[%s]\n",_fn_,line_len,line);
*/
	rc = 0;
	memset(&sspl,0,sizeof(SSPL_S));
	i = sp0 = sp = 0;
	pn = NULL;
	mem_set_int(kk_level,0,3);
	memset(parl,0,sizeof(ParList)*3);
	/* DO i = 1, N [, k] */
	while ((len=akxtgwnsl(line,line_len,&sspl,sep,0x21)) > 0) {
/*
printf("%s: sp=%d sp0=%d sspl.sp=%d len=%d c=[%c]\n",_fn_,sp,sp0,sspl.sp,len,*sspl.wd);
*/
		if (len==2 && !memicmp(sspl.wd,"AS",2)) break;
		kk = 0;
		switch (*sspl.wd) {
		case '(':
			kk++;
		case '[':
			kk++;
		case '{':
			kk_level[kk]++;
			break;
		case ')':
			kk++;
		case ']':
			kk++;
		case '}':
			if (kk_level[kk] > 0) kk_level[kk]--;
			else rc = -1;
			break;
		case '=':
			if (pn) {
				rc = -2;
			}
			else if (!mem_sum_int(kk_level,3)) {
				len = sp - sp0;
				pp = line + sp0;
				pos = akxnskipin(pp,len,"$%#");
				if (cl_chk_name(pp+pos,len-pos)) rc = -6;
				else {
					pn = line + sp0;
					len_pn = len;
/*
printf("%s: len_pn=%d\n",_fn_,len_pn);
*/
				}
			}
			break;
		case ',':
			if (!pn) {
				rc = -3;
			}
			else if (i >= 2) {
				rc = -4;
			}
			else if (!mem_sum_int(kk_level,3)) {
				len = sp - sp0;
				pp = line + sp0;
				if (len<=0 || akxqn_is_str(pp,len,NULL)) rc = -7;	/* is_spaces */
				else {
					if (pConstCt) p = cl_const_ct_malloc(pConstCt,len+1);
					else p = cl_tmp_const_malloc(len+1);
					memzcpy(p,pp,len);
					parl[i].par = p;
					parl[i++].parlen = len;
/*
printf("%s: i=%d len=%d p=[%s]\n",_fn_,i,len,p);
*/
				}
				sp0 = sspl.sp;
			}
			break;
		}
		if (rc) break;
		sp = sspl.sp;
	}
	if (!rc) {
#if 0
		if (mem_sum_int(kk_level,3) > 0) {
			ERROROUT1(FORMAT(99),_fn_);	/* %s: ���ʂ����Ă��܂���B */
			rc = ECL_SCRIPT_ERROR;
		}
		else {
#endif
			len = sp - sp0;
			pp = line + sp0;
			if (len>0 && !akxqn_is_str(pp,len,NULL)) {	/* is_spaces */
				if (pConstCt) p = cl_const_ct_malloc(pConstCt,len+1);
				else p = cl_tmp_const_malloc(len+1);
				memzcpy(p,pp,len);
				parl[i].par = p;
				parl[i++].parlen = len;
/*
printf("%s: i=%d len=%d p=[%s]\n",_fn_,i,len,p);
*/
			}
	/*	}	*/
		if (!pn) rc = -3;
		else if (i < 2) rc = -5;
	}
	if (rc) {
/*
printf("%s: rc=%d\n",_fn_,rc);
*/
		ERROROUT2(FORMAT(440),_fn_,rc);	/* %s: SYNTAX������Ă��܂��Brc=%d */
		rc = ECL_SCRIPT_ERROR;
	}
	else {
		rc = len_pn;
/*
printf("%s: parl[0].par=[%s] parl[1].par=[%s] parl[2].par=[%s]\n",_fn_,parl[0].par,parl[1].par,parl[2].par);
*/
	}
/*
printf("%s:Exit rc=%d\n",_fn_,rc);
*/
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_change_from_do(line,line_len,parl,parl2)
char *line;
int line_len;
ParList parl[],parl2[];
{
	static char *p0=NULL;
	int rc,pos;

	rc = 0;
	if ((pos=cl_change_from_do_sub(line,line_len,parl,NULL)) > 0) {
/*
printf("cl_get_loop_ctl: len_pn=%d parl[0].par=[%s] parl[1].par=[%s] parl[2].par=[%s]\n",len_pn,parl[0].par,parl[1].par,parl[2].par);
*/
		rc = cl_set_to_step_parm(parl[0].par,parl[1].par,parl[2].par,pos,parl2,&p0);
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
static int _change_from_do(y)
condList *y;
{
	static char *_fn_="_change_from_do";
	int rc,len_pn,line_len,i;
	char *line;
	ParList parl[6];
	cmdInfo *cmd;

	cmd = y->cmd;
	line = cmd->parl[0].par;
	line_len = cmd->parl[0].parlen;
/*
printf("%s: line_len=%d line=[%s]\n",_fn_,line_len,line);
*/
	rc = 0;
	/* 2023.9.17 */
	if ((len_pn=cl_change_from_do_sub(line,line_len,parl,y->ConstCt)) > 0) {
/*
printf("%s: parl[0].par=[%s] parl[1].par=[%s] parl[2].par=[%s]\n",_fn_,parl[0].par,parl[1].par,parl[2].par);
*/
		cmd->prmnum = 0;
		if (rc=clparmset(y,"DO",2)) return rc;
		if (rc=clparmset(y,parl[0].par,parl[0].parlen)) return rc;
		rc = _set_to_step_parm(y,parl[0].par,parl[1].par,parl[2].par,len_pn);
/*
for (i=0;i<cmd->prmnum;i++) {
printf("%s: prmp[%d]->prp=[%s]\n",_fn_,i,cmd->prmp[i]->prp);
}
*/
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int col_mn_tr_loop(y)
condList *y;
{
	static char *_fn="col_mn_tr_loop";
	int rc,len,n,i,pnum,cid,scno;
	char *name,*pnm;
	cmdInfo *cmd;
	parmList **prmL;

	cmd = y->cmd;
#if 0
	if (cl_nest_tag(1) == SysError) {
		ERROROUT(FORMAT(101));
		return ( ECL_TR_LOOP );
	}
	rc = cl_search_active_loop(y);
	if ( rc ) {
		if (rc == -1) ERROROUT(FORMAT(101);
	/*	if (rc == -2) ERROROUT(FORMAT(102);	*/
		return ( ECL_TR_LOOP );
	}
#endif
/*
	if ((cid=cmd->cid)!=C_DO && !cmd->prmnum) {
		ERROROUT(FORMAT(103);
		return ( ECL_TR_LOOP );
	}
*/
	cid = cmd->cid;
	prmL = cmd->prmp;
	if (cid==C_FOR && !strnicmp(cmd->prmp[0]->prp,"EACH",4)) ;
	else if (cid==C_FOR || cid==C_WHILE || cid==C_UNTIL) {
		cl_tr_insert(y,0,cl_gets_cmd_name(cid));
		cmd->cid = C_LOOP;
	}
	pnum = cmd->prmnum;
	if (pnum > 0)
		pnm = prmL[0]->prp;
	else pnm = "";

	scno = 0;
	if (!strnicmp(pnm,"WHILE",5) || !strnicmp(pnm,"UNTIL",5) ||
	    !strnicmp(pnm,"EACH",4)) {
		cl_tr_split(y,0,"(");
		pnum = cmd->prmnum;
		pnm = prmL[0]->prp;
		if (pnum>=2 && !stricmp(pnm,"WHILE")) scno = D_LOOP_WHILE;
		else if (pnum>=2 && !stricmp(pnm,"UNTIL")) scno = D_LOOP_UNTIL;
		else if (pnum>=4) scno = D_LOOP_EACH;
		else scno = -1;
	}
	else if (!strnicmp(pnm,"FOR",3)) {
		cl_tr_split(y,0,"(");
		if ((rc=_change_from_for(y)) < 0) return rc;
		else if (!rc) {
			if (rc=_change_from_to_step(y)) return rc;
		}
		pnum = cmd->prmnum;
		if (pnum>=2) scno = D_LOOP_FOR;
		else scno = -1;
	}
	else if (cid==C_DO && cmd->prmnum>0) {
		ERROROUT1(FORMAT(41),"ColMnTrDo");
		return  ECL_TR_LOOP;
	}
	if (scno < 0) {
		ERROROUT1(FORMAT(42),_fn);
		return  ECL_TR_LOOP;
	}
	cmd->sub_cid |= scno;

	if (!(rc=cl_make_leaf(y))) {
		cl_pre_nest(y);
		if (!(rc=cl_push(y))) rc= cl_change_stcb(y);
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_tr_insert(y,ip,name)
condList *y;
int ip;
char *name;
{
	int rc,len,n,i,num;
	cmdInfo *cmd;

	cmd = y->cmd;
	num = cmd->prmnum;
	if (ip<num && num<y->max_prmnum) {
		for (i=num;i>ip;i--) cmd->prmp[i] = cmd->prmp[i-1];
		cmd->prmnum = ip;
		if (rc=clparmset(y,name,strlen(name))) return rc;
		n = cmd->prmnum = num + 1;
	}
	else n = 0;
	return n;
}

int cl_search_active_loop(y)
condList *y;
{
	Leaf  *Dummy;
	CLNCB *p;

	p = y->clstcb;
	if (!(Dummy = p->nestLev2)) return 0;
	while (Dummy) {

		if ( Dummy == p->nestLev1 ||
		    (Dummy->cmd.type == 0 && Dummy->cmd.cid == C_LOOP) )
			return ( 0 );
	/*
		else if ( Dummy->cmd.cid == C_LOOP ) return ( -2 );
	*/
		Dummy = Dummy->preleaf;
	}
	return -1;
}
