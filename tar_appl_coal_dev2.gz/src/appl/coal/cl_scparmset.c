static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************
*                                                                   *
*      �����ړI�@�@�F  							                    *
*                                                                   *
*      �֐����@�@�@�F�@int cl_scparmset( pLeaf )			        *
*                                                                   *
*      ������      �F�@(I)Leaf          * pLeaf                     *
*                                                                   *
*                                                                   *
*      �߂�l�@�@�@�F�@ERROR                                        *
*                      NORMAL                                       *
*                                                                   *
*      �����T�v�@�@�F�@                                             *
*                                                                   *
********************************************************************/
#include <colmn.h>

/****************************************************/
/* ���� : proc	: EXEC�R�}���h�����s���Ă���proc	*/
/****************************************************/
static int _get_pTBL(proc,VaryC,prp,prmlen,ppTBL,val)
ProcCT *proc;
VarTBL *VaryC;
char *prp;
int prmlen;
tdtInfoParm ****ppTBL;
int val[];
{
	char *argv[3],parm[128],*p,c;
	int ret,varmax,varall,n,*pSize1,k0,len,pos,nparm;
	long lVal;
	tdtInfoParm ***pTBL,tInfoParm2[2],*pInfoParm;
	tdtObjHead  *pObj;
/*
printf("_get_pTBL: prmlen=%d prp=[%s]\n",prmlen,prp);
*/
	pTBL = NULL;
	ret = varall = varmax = 0;
	k0 = 1;
	if (akxtgetargvns2(prp,prmlen,argv,3,parm,sizeof(parm)," \t",0) == 2) {
		c = *(p=argv[1]);
		len = strlen(p);
		if (!stricmp(argv[0],"LOCAL") && c=='%' && *(p+len-1)=='*') {
			varall = 1;
			varmax = proc->varnam_pasento;
			pTBL   = proc->pTBL_pasento;
		}
	}
	else {
		p = prp;
		len = prmlen;
		c = *prp;
		if ((c=='%' || c=='#' || c=='$') && *(p+len-1)=='*') {
			if (c == '%') {
				varall = 1;
				pTBL   = VaryC->pTBL_pasento;
			}
			else if (c == '#') {
				varall = 2;
				pTBL   = VaryC->pTBL_igeta;
			}
			else {
				varall = 3;
				pTBL   = VaryC->pTBL_dolu;
			}
		}
	}
/*
printf("_get_pTBL: varall=%d p=[%s]\n",varall,p);
*/
	if (varall) {
		p++;
		len -= 2;
		pSize1 = (int *)pTBL[0];
		varmax = pSize1[7];
/*
printf("_get_pTBL: varmax=%d\n",varmax);
*/
		n = -1;
		/* 2022.9.10 */
		if (*p == '(') {
			if (len > 2) {
				if (proc) pObj = proc->Obj;
				else pObj = NULL;
/*
printf("_get_pTBL: len=%d p=[%s]\n",len,p);
*/
				if ((ret=cl_gx_expsn_obj_opt(p+1,len-2,NULL,pObj,tInfoParm2,D_GX_OPT_PARMINFO2)) < 0) return ret;
				ret = 0;
				nparm = cl_get_InfoParm2(tInfoParm2,&pInfoParm,NULL);
				cl_get_parm_bin(pInfoParm,&lVal,"PARM1.BIN");
				k0 = lVal;
				if (nparm >= 2) {
					cl_get_parm_bin((pInfoParm+1),&lVal,"PARM2.BIN");
					n = lVal;
				}
			}
		}
		else if (len > 0) {
			k0 = atoi(p);
			if (len >= 3) {
				pos = inmemstr(p,len,",");
				if (pos > 0) n = atoi(p+pos);
			}
		}
		if (n >= 0) {
			n = k0 + n - 1;
			if (n < varmax) varmax = n;
		}
/*
printf("_get_pTBL: k0=%d n=%d varmax=%d\n",k0,n,varmax);
*/
		if (varmax > 0) {
			if (k0<1/* || k0>varmax*/) {
				ERROROUT1(FORMAT(222),k0);	/* �J�n�ʒu(%d)���s���ł��B*/
				ret = ECL_SCRIPT_ERROR;
			}
			k0--;
		}
	}
	*ppTBL = pTBL;
	val[0] = varall;
	val[1] = varmax;
	val[2] = k0;
/*
printf("_get_pTBL: varall=%d varmax=%d k0=%d\n",varall,varmax,k0);
*/
	return ret;
}

/* 2021.8.18 */
/********************************************************/
/* ���� : proc		: EXEC�R�}���h�����s���Ă���proc	*/
/*		  pScCT		: ���s����SCRIPT��ScrCt				*/
/********************************************************/
int cl_scparmset(proc,pScCT,stdiow,parl)
ProcCT  *proc;
ScrPrCT *pScCT;
FILE *stdiow[];
ParList2 *parl;
{
	int         rc,i,j,*pSize,len,opt,opt_n,rc1,rc2;
	tdtInfoParm **ppmstk,*pInfoParmW,*pInfoParm;
	VarTBL      *VaryW;
	char        *pBuff,c,*p,*pHereDocnm;
	FILE *pHereDocfp;

DEBUGOUTL2(194,"cl_scparmset: proc=%08x pScCT=%08x",proc,pScCT);

	if (!proc || !pScCT) return -1;

	if (proc) ppmstk = proc->ppExecParm;
	if (!ppmstk) return 0;

	VaryW = pScCT->Vary;
	for (i=0,j=0 ;pInfoParm=ppmstk[i];i++) {
DEBUGOUT_InfoParm(194,"cl_scparmset: i=%d pScCT=%08x",
pInfoParm,j,&pInfoParm->pi_len);
/*
printf("cl_scparmset: id=[%c]\n",pInfoParm->pi_id);
*/
		if (pInfoParm->pi_id==D_DATA_ID_PNAME && (rc=cl_is_redirect_fp(pInfoParm->pi_paux,0))>0) {
			pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			if (pInfoParm->pi_id == 'S') pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			p = pInfoParm->pi_data;
			len = pInfoParm->pi_dlen - sizeof(FILE *) - sizeof(int);
			memcpy(&pBuff,p,sizeof(FILE *));
#if defined(_LP64)
			pHereDocfp = (FILE *)x_ntohll((long)pBuff);
#else
			pHereDocfp = (FILE *)ntohl((uint)pBuff);
#endif
			p += sizeof(FILE *);
			memcpy(&opt_n,p,sizeof(int));
			opt = ntohl(opt_n);
			p += sizeof(int);
/*
printf("cl_scparmset: pHereDocfp=%08x rc=%d opt=%02x len=%d p=[%s]\n",
pHereDocfp,rc,opt,len,strtemp(p,len));
*/
			rc--;
			/* 2022.5.10 */
			if (rc) {
				rc1 = rc & 0x01;
				rc2 = rc & 0x02;
				if (rc1) stdiow[rc1] = pHereDocfp;
				if (rc2) stdiow[rc2] = pHereDocfp;
			}
			else {
				stdiow[0] = pHereDocfp;
				parl->par = p;
				parl->parlen = len;
				parl->option = opt | D_RED_PFLAG2_FILE;
/*
printf("cl_scparmset: parl->option=%08x\n",parl->option);
*/
			}
			continue;
		}
		pInfoParmW = cl_get_var_ent_opt(VaryW->pTBL_pasento,++j,'s');
		/* 2021.10.27 */
		if (cl_gx_rep_info_als(pInfoParmW,pInfoParm,D_REP_OPT_DEF_ONLY/*|1*/)) return ECL_SCRIPT_ERROR;
		pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;
		if ((c=pInfoParmW->pi_id)=='A' || c=='R' || c=='L' || c=='N') {
			pInfoParmW->pi_scale &= ~0x20;
		}
DEBUGOUT_InfoParm(194,"cl_prparmset:W: j=%d pScCT=%08x",
pInfoParmW,j,pInfoParmW->pi_len);
	}
/*
printf("cl_scparmset: j=%d\n",j);
*/
	VaryW->varnam_pasento = j;
	pSize = (int *)VaryW->pTBL_pasento[0];
	cl_set_parm_bin(cl_var_size_parm(pSize),j);
DEBUGOUT_InfoParm(194,"cl_scparmset:j: j=%d rc=%d",cl_var_size_parm(pSize),j,rc);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_prparmset(/*pLeaf,*/pProc,pExProcName)
/*Leaf *pLeaf ;*/
ProcCT  *pProc;
char *pExProcName;
{
	int         rc,j;
	ScrPrCT     *pScCT;
	int         *pSize; 
	tdtInfoParm *pInfoParmW,*pInfoParm;
	VarTBL      *VaryC;
	char        c;
	ProcCT      *proc;
	tdtInfoParm **ppmstk;

	if (!(proc = cl_search_proc_ct())) return -2;
	if (proc->varnam_pasento > 0) return 0;
	if (rc=cl_mk_pr_var_set(proc)) return rc;
	if (pProc) ppmstk = pProc->ppExecParm;
	else ppmstk = NULL;
	if (!ppmstk || !strcmp(pExProcName,"main")) {
		pScCT = cl_search_src_ct();
		VaryC = pScCT->Vary;
		proc->varnam_pasento = VaryC->varnam_pasento;
		proc->pTBL_pasento = VaryC->pTBL_pasento;
		proc->pFlag |= D_PFLAG_PARM_COPY;
		return 0;
	}

	for (j=0 ;pInfoParm=ppmstk[j];) {
		pInfoParmW = cl_get_var_ent_opt(proc->pTBL_pasento,++j,'s');
		/* 2023.6.7 */
		if (cl_prparmset_sub(pInfoParmW,pInfoParm)) return ECL_SCRIPT_ERROR;
DEBUGOUT_InfoParm(194,"cl_prparmset:W: j=%d pScCT=%08x",
pInfoParmW,j,pInfoParmW->pi_len);
	}
	proc->varnam_pasento = j;
	pSize = (int *)proc->pTBL_pasento[0];
	cl_set_parm_bin(cl_var_size_parm(pSize),j);
	return NORMAL;
}

/****************************************/
/*										*/
/****************************************/
int cl_prparmset_sub(pInfoParmW,pInfoParm)
tdtInfoParm *pInfoParmW,*pInfoParm;
{
	char c;

DEBUGOUT_InfoParm(194,"cl_prparmset_sub:Eenter ",pInfoParm,0,0);
		/* 2023.6.7 */
		/* 2022.9.19 */
		/* 2021.10.27 */
		if (cl_gx_rep_info_als(pInfoParmW,pInfoParm,D_REP_OPT_DEF_ONLY/*|1*/)) return ECL_SCRIPT_ERROR;
		/* 2023.6.7 */
		pInfoParmW->pi_aux[0] &= ~D_AUX0_ZOK_DATA;
		pInfoParmW->pi_aux[1] &= ~(D_AUX1_HASHED_NAME | D_AUX1_VAR_SCOPE);
		pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;
		if ((c=pInfoParmW->pi_id)=='A' || c=='R' || c=='L' || c=='N') {
			pInfoParmW->pi_scale &= ~0x20;
		}
DEBUGOUT_InfoParm(194,"cl_prparmset_sub:Exit ",pInfoParmW,0,0);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_exec_parm(pprmp,parmnum,pProc)
parmList **pprmp;
int  parmnum;
ProcCT  *pProc;
{
	int         i,rc,k,j,maxnum,n,numinc,inc;
	ScrPrCT     *pScCT;
	int         parmpos;
	int         *pSize,varmax,varall,val[3],k0;
	tdtInfoParm	tInfoParm,*pInfoParmW;
	VarTBL      *VaryC;
	parmList    *parm;
	char        *p;
	tdtObjHead  *pObj;
	ProcCT      *proc;
	tdtInfoParm **ppmstk,***pTBL;

DEBUGOUTL3(120,"cl_set_exec_parm:Enter pprmp=%08x parmnum=%d pProc=%08x",pprmp,parmnum,pProc);

	if (!pprmp || !pProc) {
		ERROROUT1(FORMAT(28),"cl_set_exec_parm");	/* cl_set_exec_parm: �����N�G���[ */
		return ERROR;
	}
	if (!(pScCT = cl_search_src_ct())) {
		ERROROUT("cl_set_exec_parm: ScCT not found.");
		return ERROR;
	}
	VaryC = pScCT->Vary;
	maxnum = parmnum;
	if (pProc) pObj = pProc->Obj;
	else pObj = NULL;
	if (maxnum > 0) {
		numinc = VaryC->varnam_pasento;	/* '%*'�̐��������Ă��� */
		maxnum += numinc;
	}

DEBUGOUTL1(120,"cl_set_exec_parm:0: maxnum=%d",maxnum);
/*
printf("cl_set_exec_parm:ret:0: maxnum=%d parmnum=%d\n",maxnum,parmnum);
*/
	if (!(p=cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(maxnum+1)))) {
		return ECL_MALLOC_ERROR;
	}
	ppmstk = (tdtInfoParm **)p;
	for (i=0, parmpos=0, j=0 ;i<parmnum; i++,parmpos++)  {
		parm = pprmp[parmpos];
DEBUGOUTL2(120,"cl_set_exec_parm: i=%d parm->prp=[%s]",i,parm->prp);
		/* 2021.7.8 */
		if ((rc=_get_pTBL(pProc,VaryC,parm->prp,parm->prmlen,&pTBL,val)) < 0) return rc;
		inc = 1;
		varall = val[0];
		if (varall) {
			varmax = val[1];
			inc = varmax;
		}
		if (j+inc-1 >= maxnum) {
			numinc = 16;
			if (inc > numinc) numinc = inc;
			n = maxnum + numinc;
			if (!(p=cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(n+1)))) {
				return -1;
			}
			memcpy(p,ppmstk,sizeof(tdtInfoParm *)*maxnum);
			maxnum = n;

DEBUGOUTL1(120,"cl_set_exec_parm:1: maxnum=%d",maxnum);
/*
printf("cl_set_exec_parm:ret:1: inc=%d maxnum=%d\n",inc,maxnum);
*/
			ppmstk = (tdtInfoParm **)p;
		}
		if (varall) {
			k0 = val[2];
			pSize = (int *)pTBL[0];
/*
printf("cl_set_exec_parm: pSize[2]=%d\n",pSize[2]);
*/
			for (k=k0;k<varmax;k++) {
				if (j>=pSize[2]) {
					return ECL_SCRIPT_ERROR;
				}
				ppmstk[j++] = cl_get_var_ent(pTBL,k+1);
			}
		}
		else {
			if ((rc=cl_gx_exp_obj(1,&pprmp[parmpos],pObj,&tInfoParm))<0) {
				return ECL_SCRIPT_ERROR;
			}
			if (rc==100) cl_null_parm(&tInfoParm);
DEBUGOUT_InfoParm(194,"cl_set_exec_parm: : i=%d pScCT=%08x",
&tInfoParm,i,&tInfoParm.pi_len);
			if (!(pInfoParmW=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) {
				return ECL_MALLOC_ERROR;
			}
			cl_gx_copy_info(pInfoParmW,&tInfoParm);
DEBUGOUT_InfoParm(194,"cl_set_exec_parm:W: i=%d pScCT=%08x",
pInfoParmW,i,pInfoParmW->pi_len);
			ppmstk[j++] = pInfoParmW;
		}
	}
	ppmstk[j] = NULL;
	pProc->ppExecParm = ppmstk;
/*
printf("cl_set_exec_parm:Exit j=%d\n",j);
*/
	return NORMAL;
}
