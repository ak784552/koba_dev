static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/* ��������									*/
/*	 �t���[����͋��ʊ֐�					*/
/*------------------------------------------*/
/********************************************/
/* */
#include <stdio.h>
#include "colmn.h"

extern ViewTBL ViewTb;
extern ItemTBL ItemTbl;
extern ExtTBL  ExtTbl;
extern CatCondTBL CatCondTbl;
/* */
int	cmn_read_field_frame(pFrameTp,pFrameIf)
char *pFrameTp;			/* �t���[���擪�|�C���^ */
pFrameInfo pFrameIf;	/* �t���[����̓u���b�N */
{
	char szFrId[3];
	int	iSize = 0;

	/* �e�[�u���N���A */
	memset(pFrameIf,0,sizeof(qFrameInfo));

	/* �t���[���h�c���擾 */
	memcpy(pFrameIf->szFrameID ,pFrameTp ,2);
	memcpy(szFrId ,pFrameTp ,2);
	szFrId[2] = '\0';

	pFrameTp += 2;

	/* �t���[����ʂ��Ƃɏ������� */
	sswitch(szFrId)
		scase ("FM")
			iSize = cmn_ana_cl_data_fm(pFrameTp ,pFrameIf);
		scase ("GR")
			iSize = cmn_ana_cl_data_gr(pFrameTp ,pFrameIf);
		scase ("DT")
			iSize = cmn_ana_cl_data_dt(pFrameTp ,pFrameIf);
		sdefault
	endssw
/*
printf("cmn_read_field_frame:szFrId=[%s] iSize=%d\n",szFrId,iSize);
*/
	if (iSize < 0) {
		cmn_read_fld_free(pFrameIf);
		return -1;
	}

	return iSize + 2;
}

/********************************************/
/* ��������									*/
/*	 �i�e��������  �e�l�j��͊֐�			*/
/*------------------------------------------*/
/********************************************/
/* */
int cmn_ana_cl_data_fm(pCurrent ,pFrameIf)
char *pCurrent;
pFrameInfo pFrameIf;
{
	return 4;
}

/********************************************/
/* ��������									*/
/*	 �i�e��������  �f�q�j��͊֐�			*/
/*------------------------------------------*/
/********************************************/
/* */
int cmn_ana_cl_data_gr(pCurrent ,pFrameIf)
char *pCurrent;
pFrameInfo pFrameIf;
{
	char szTmp[6];
	int	iHeadBytes = 0;
	int iDataBytes = 0;
	int	loop;
	int iPoint = 0;

	/* �t�B�[���h�ԍ� */
	if (axccvn(10,pCurrent,5,&pFrameIf->field_1)) return -1;
	iHeadBytes += 5;

	/* �^�v���ԍ� */
	if (axccvn(10,pCurrent+iHeadBytes,5,&pFrameIf->iTuple)) return -1;
	iHeadBytes += 5;

	/* �f�[�^�E�m�[�h�� */
	if (axccvn(10,pCurrent+iHeadBytes,5,&pFrameIf->iNode)) return -1;
	iHeadBytes += 5;

	/* �f�[�^�ݒ� */
	pFrameIf->pDataTbl = (pDataElm)Malloc(sizeof(qDataElm)*pFrameIf->iNode);
	if (pFrameIf->pDataTbl == NULL) return -1;

	memset(pFrameIf->pDataTbl,0,sizeof(qDataElm)*pFrameIf->iNode);

	for (loop=0;loop< pFrameIf->iNode;loop++) {
		pFrameIf->pDataTbl[loop].pData  = Malloc(4);
		if (pFrameIf->pDataTbl[loop].pData == NULL) return -1;
		if (axccvn(10,pCurrent+iHeadBytes,5,pFrameIf->pDataTbl[loop].pData)) return -1;
		pFrameIf->pDataTbl[loop].len = 4;
		pFrameIf->pDataTbl[loop].attr = DEF_ZOK_BINA;
		iHeadBytes += 5;
	}

	return iHeadBytes + iDataBytes;
}

/********************************************/
/* ��������									*/
/*	 �i�e��������  �c�s�j��͊֐�			*/
/*------------------------------------------*/
/********************************************/
/* */
int cmn_ana_cl_data_dt(pCurrent ,pFrameIf)
char *pCurrent;
pFrameInfo pFrameIf;
{
	char szTmp[6];
	int	iHeadBytes = 0;
	int iDataBytes = 0;

	/* �^�v���ԍ� */
	if (axccvn(10,pCurrent,5,&pFrameIf->iTuple)) return -1;
	iHeadBytes += 5;

	/* �f�[�^�E�m�[�h�� */
	if (axccvn(10,pCurrent+iHeadBytes,5,&pFrameIf->iNode)) return -1;
	iHeadBytes += 5;
	
	/* �f�[�^�ݒ� */

	iDataBytes = cmn_parm_data_set(pCurrent + iHeadBytes  ,pFrameIf);
	if (iDataBytes < 0) return -1;

	return iHeadBytes + iDataBytes;

}

/********************************************/
/* ��������									*/
/*	 �f�[�^�ݒ苤�ʊ֐�						*/
/*------------------------------------------*/
/********************************************/
/* */
int cmn_parm_data_set(pCurrent ,pFrameIf)
char *pCurrent;
pFrameInfo pFrameIf;
{
	int iDataBytes = 0;
	int iPoint = 0;
	int i,irc;
	tdtInfoParm	DataTbl,rParm;


	pFrameIf->pDataTbl = (pDataElm)Malloc(sizeof(qDataElm)*pFrameIf->iNode);
	if (pFrameIf->pDataTbl == NULL) return -1;

	memset(pFrameIf->pDataTbl,0,sizeof(qDataElm)*pFrameIf->iNode);

	for (i=0;i<pFrameIf->iNode;i++) {
		irc = cmn_chk_data(pCurrent ,&DataTbl);
		if (irc < 0) return -1;
		iDataBytes += DataTbl.pi_len;

		irc = cl_code_trans(&DataTbl,&rParm);
		if (irc < 0) return -1;
		if (irc == 0) {
			pFrameIf->pDataTbl[i].len   = DataTbl.pi_dlen;
			pFrameIf->pDataTbl[i].attr  = DataTbl.pi_attr;
			pFrameIf->pDataTbl[i].pData  = Malloc(DataTbl.pi_dlen + 1);
			if (pFrameIf->pDataTbl[i].pData == NULL) return -1;
			memcpy(pFrameIf->pDataTbl[i].pData,DataTbl.pi_data,DataTbl.pi_dlen);
			*(pFrameIf->pDataTbl[i].pData+DataTbl.pi_dlen) = '\0';
		}
		else {
			pFrameIf->pDataTbl[i].len   = rParm.pi_dlen;
			pFrameIf->pDataTbl[i].attr  = rParm.pi_attr;
			pFrameIf->pDataTbl[i].pData = rParm.pi_data;
		}

		pCurrent  += DataTbl.pi_len;
		iPoint	+= DataTbl.pi_len;

		DataTbl.pi_data = NULL;
	}

	return iPoint;
}

int cmn_read_fld_free(pTbl)
pFrameInfo pTbl;
{
	char *p;

	if (!pTbl) return -1;
	if (pTbl->pDataTbl) {
		while (pTbl->iNode>0) {
			if (p=pTbl->pDataTbl[pTbl->iNode-1].pData) Free(p);
			pTbl->iNode--;
		}
		Free(pTbl->pDataTbl);
		pTbl->pDataTbl = NULL;
	}
	return 0;
}
