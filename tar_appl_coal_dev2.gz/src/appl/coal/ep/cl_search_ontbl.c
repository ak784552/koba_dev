static	char	sccsid[]="%Z% %M% %I% %E% %U%";
#define	AOYAGI
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  							                              *
*                                                                             *
*      �֐����@�@�@�F�@int cl_search_ontbl( pFrameTbl )					      *
*                      (I)pFrameInfo	*pFrameTbl						      *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

int cl_search_ontbl( pFrameTbl )
pFrameInfo	pFrameTbl;
{
	int		i,rc,OnSelect_grno;
	ScrPrCT	 *pScCT;
	long	grno;
	ONTBL   **ontbl;
	pDataElm pDataTbl;
	char *pTag,*p;

	pScCT = cl_search_src_ct();

	rc = 0;
	OnSelect_grno = pScCT->OnSelect = -1;
	pTag = pFrameTbl->pDataTbl[1].pData;
/*
if (pTag) printf("cl_search_ontbl: pTag=[%s]\n",pTag);
*/
	if ((grno = pFrameTbl->field_1) == 99009) grno = 99003;
	if (pScCT->ONCOND) {
		ontbl = &pScCT->ONCOND[0];
		for (i=0;i<pScCT->on_num_max && ontbl[i];i++) {
			if (grno == ontbl[i]->FldNum) {
				if (grno==99003 && (p=ontbl[i]->PrName[3])) {
/*
printf("cl_search_ontbl: i=%d p=[%s]\n",i,p);
*/
					if (!(strcmp(p,pTag))) {
						pScCT->OnSelect = i;
						break;
					}
				}
				else {
					OnSelect_grno = i;
/*
printf("cl_search_ontbl: OnSelect = %d\n",i);
*/
				}
			}
		}
	}
	if (pScCT->OnSelect == -1) {
		if (OnSelect_grno >= 0)
			pScCT->OnSelect = OnSelect_grno;
		else {
			ERROROUT2("cl_search_ontbl: GR=%d Tag=[%s] not found.",grno,pTag);
			rc = ERROR;
		}
	}
	return rc;
}
