static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/* ��������									*/
/*	 ���C���֐�								*/
/*------------------------------------------*/
/********************************************/
/* */
 
#include "colmn.h"

/* */
#define ALL_HOST
#define SEL_MULT

/* */
extern ViewTBL  ViewTbl;
extern ItemTBL  ItemTbl;
extern ExtTBL   ExtTbl;
extern CatCondTBL CatCondTbl;

extern CLPRTBL *pCLprocTable;
 
int giItemSize;	/* koumoku no kazu */
/* */
#define  D_SW_VIEW  0
#define  D_SW_ITEM  1
 
#define  D_FRID_FM  10
#define  D_FRID_GR  11
#define  D_FRID_DT  12
  
/* */
#define  D_SW_FIRST   cl_sl_till_tbl_make
#define  D_SW_JOINT   cl_sl_till_get_elmnt
#define  D_SW_ELEMNT  cl_sl_mk_output_data
#define  D_USER_CODE  8
#define  D_COMMAND	4
#define  D_SYURUI_CODE 4

int cl_sl_till_tbl_make();
int cl_sl_till_get_elmnt();
int cl_sl_mk_output_data();

int ivElmts = 0;
int iiElmts = 0;

parmList rPrmp[SQL_PARMNUM]; /* select�R�}���h���쐬���邽�߂̍\���� */
parmList *pPrmp[SQL_PARMNUM]; /* �\���̂ւ̃|�C���^�̔z�� */
/* */
int (*funcCtrlTBL[])() = { D_SW_FIRST, D_SW_JOINT, D_SW_ELEMNT };
/* */

char *pOrgCmnd;	/* search command packet */

int cl_sel_main()
{
	static int statusSW = 0;
	int irc	  = 0;
	int vl,il,el;
	char *p;
	ProcCT *proc;

	if (pCLprocTable->SlstatusSW == 0) {
		ivElmts = 0;
		iiElmts = 0;
		if ((irc=cl_sl_till_tbl_make())<0) return -1;
		else if (irc == 100) {
			CatCondTbl.iItemNum = 0;
			pCLprocTable->SlstatusSW = 1;
			memset(rPrmp,0,sizeof(rPrmp));
			irc = cl_sl_make_select_command(pPrmp);
			if (irc) {
				ERROROUT("cl_sl_make_select_command");
				return irc;
			}
			if (!(proc = cl_search_proc_ct())) return(ECL_SYSTEM_ERROR);
			cmn_set_stat(RET_PR,&proc->ptype,L_ON);
			return 0;
		}

		vl = sizeof(ViewLine)*ViewTbl.iItemNum;
		il = sizeof(ItemLine)*ItemTbl.iItemNum;
		el = sizeof(ItemLine)*ExtTbl.iItemNum;
		if ((p=Malloc(sizeof(SlmanTBL)+vl+il+el+sizeof(rPrmp)))==NULL) {
			pCLprocTable->SlstatusSW = 0;
			return -1;
		}
/*
printf("clselmn:SlstatusSW=%d\n",pCLprocTable->SlstatusSW);
printf("clselmn:SlmanTblp =%08x\n",p);
printf("clselmn:ViewNum   =%d\n",ViewTbl.iItemNum);
printf("clselmn:ItemNum   =%d\n",ItemTbl.iItemNum);
printf("clselmn:ExtNum	=%d\n",ExtTbl.iItemNum);
*/
		pCLprocTable->SlmanTblp=(SlmanTBL *)p;
		pCLprocTable->SlmanTblp->ViewNum = ViewTbl.iItemNum;
		pCLprocTable->SlmanTblp->ViewLip = p + sizeof(SlmanTBL);
		pCLprocTable->SlmanTblp->ViewLen = vl;
		pCLprocTable->SlmanTblp->ItemNum = ItemTbl.iItemNum;
		pCLprocTable->SlmanTblp->ItemLip = pCLprocTable->SlmanTblp->ViewLip +
										 pCLprocTable->SlmanTblp->ViewLen;
		pCLprocTable->SlmanTblp->ItemLen = il;
		pCLprocTable->SlmanTblp->ExtNum = ExtTbl.iItemNum;
		pCLprocTable->SlmanTblp->ExtLip = pCLprocTable->SlmanTblp->ItemLip +
										pCLprocTable->SlmanTblp->ItemLen;
		pCLprocTable->SlmanTblp->ExtLen = el;
		pCLprocTable->SlmanTblp->rPrmLp = pCLprocTable->SlmanTblp->ExtLip +
										pCLprocTable->SlmanTblp->ExtLen;
		pCLprocTable->SlmanTblp->PrmLen = sizeof(rPrmp);
		memcpy(pCLprocTable->SlmanTblp->ViewLip,(char *)&ViewTbl.Line[0],
			pCLprocTable->SlmanTblp->ViewLen);
		memcpy(pCLprocTable->SlmanTblp->ItemLip,(char *)&ItemTbl.Line[0],
			pCLprocTable->SlmanTblp->ItemLen);
		memcpy(pCLprocTable->SlmanTblp->ExtLip,(char *)&ExtTbl.Line[0],
			pCLprocTable->SlmanTblp->ExtLen);
		memcpy(pCLprocTable->SlmanTblp->rPrmLp,(char *)&rPrmp[0],
			pCLprocTable->SlmanTblp->PrmLen);
		pCLprocTable->SlstatusSW = 1;
	}
	else if (pCLprocTable->SlstatusSW == 1) {
		ViewTbl.iItemNum = pCLprocTable->SlmanTblp->ViewNum;
		ItemTbl.iItemNum = pCLprocTable->SlmanTblp->ItemNum;
		ExtTbl.iItemNum  = pCLprocTable->SlmanTblp->ExtNum;
/*
printf("clselmn:SlstatusSW=%d\n",pCLprocTable->SlstatusSW);
printf("clselmn:SlmanTblp =%08x\n",pCLprocTable->SlmanTblp);
printf("clselmn:ViewNum   =%d\n",ViewTbl.iItemNum);
printf("clselmn:ItemNum   =%d\n",ItemTbl.iItemNum);
printf("clselmn:ExtNum	=%d\n",ExtTbl.iItemNum);
*/
		memcpy((char *)&ViewTbl.Line[0], pCLprocTable->SlmanTblp->ViewLip,
			pCLprocTable->SlmanTblp->ViewLen);
		memcpy((char *)&ItemTbl.Line[0], pCLprocTable->SlmanTblp->ItemLip,
			pCLprocTable->SlmanTblp->ItemLen);
		memcpy((char *)&ExtTbl.Line[0], pCLprocTable->SlmanTblp->ExtLip,
			pCLprocTable->SlmanTblp->ExtLen);
		memcpy((char *)&rPrmp[0], pCLprocTable->SlmanTblp->rPrmLp,
			pCLprocTable->SlmanTblp->PrmLen);
		irc=cl_sl_till_get_elmnt();
		if (pCLprocTable->SlmanTblp) Free(pCLprocTable->SlmanTblp);
		pCLprocTable->SlstatusSW = 0;
		if (irc < 0) return -1;
	}
	else {
		if (pCLprocTable->SlmanTblp) Free(pCLprocTable->SlmanTblp);
		pCLprocTable->SlstatusSW = 0;
		return -1;
	}

	return 0;
}

int cl_sl_till_tbl_make()
{
	char *pFrameTp  = NULL,
		  bfCode	= '\0';
 	char dummy[6];
	int irc = 0,
		iFrId = 0,
		iMkTblSw = -1,
		iJoint = 0;
	int iDataSize = 0,
		iReadSize = 0;
	int iPrSw = 0;
	char *frame = NULL;
	qFrameInfo FrameTbl;
	tdtInfoParm DataTbl;
	int iHeadSize = 0;
	int ifield = 0;
	int i;
	int ivelmts;
	AKAMSGCOM *tpMsgCom;
 
	tpMsgCom  = (AKAMSGCOM *)pCLprocTable->CmdPacketp;
	frame     = tpMsgCom->msg_pmsg;
	iDataSize = tpMsgCom->msg_mlen;

	pFrameTp  = frame  + sizeof(char) * (D_USER_INF + D_COMMAND) + sizeof(int);
 
	/* kensaku syurui code */
	irc = cmn_chk_data(pFrameTp, &DataTbl);
	if (irc) {
		ERROROUT("cmngetdata");
		return -1;
	}
	pFrameTp += DataTbl.pi_len;

	/* window menue infomation */
	irc = cmn_chk_data(pFrameTp, &DataTbl);
	if (irc) {
		ERROROUT("cmngetdata");
		return -1;
	}

	pFrameTp = DataTbl.pi_data;
	iDataSize = DataTbl.pi_dlen;

	while (iReadSize < iDataSize) {
		/* frame analizing */
		irc = cmn_read_field_frame(pFrameTp + iReadSize, &FrameTbl);
		if (irc < 0) {
			ERROROUT("cmn_read_field_frame");
			return irc;
		}

		iReadSize += irc;

		sswitch(FrameTbl.szFrameID)
			scase("FM")
				iMkTblSw++;
				bfCode = 'F';
			scase("GR")
				if (FrameTbl.field_1 == 1) iJoint = 1;
/*
printf("clSl:GR field_1 = %d\n",FrameTbl.field_1);
*/
				bfCode = 'G';
			scase("DT")
				bfCode = 'D';
				if (iJoint) {
					iJoint = 0;
					ivelmts = cl_sl_tbl_set_condition(&FrameTbl);
/*
printf("clSl:DT ivelmts = %d\n",ivelmts);
*/
					if (ivelmts < 0) {
						ERROROUT("error on cl_sl_tbl_set_condition");
						cmn_read_fld_free(&FrameTbl);
						return -1;
					}
				}
				else {
					if (bfCode == 'D') {
						/* table making (view, item) */
						if (iMkTblSw) {
							irc = cl_sl_tbl_mk_item_and_set_view(&FrameTbl,ivelmts);
							if (irc) {
								ERROROUT("error on cl_sl_tbl_mk_item_and_set_view");
								cmn_read_fld_free(&FrameTbl);
								return -1;
							}
						}
						else {
							irc = cl_sl_tbl_mk_view(&FrameTbl);
							switch (irc) {
								case  -1 :
									ERROROUT("error on cl_sl_tbl_mk_view");
									return -1;
								case  D_SW_ITEM :
									iMkTblSw = irc;
									break;
								default :
									;
							}
						}
					}
				}
			sdefault
		endssw

		/* Free */
		cmn_read_fld_free(&FrameTbl);
	}
 
	/* table making (extract) */
	irc = cl_sl_mk_extr();
	if (irc) {
		ERROROUT("error on cl_sl_mk_extr");
		return -1;
	}
	ViewTbl.iItemNum = ivElmts;
	ItemTbl.iItemNum = iiElmts;

#ifdef YAMADAHASKI
  axaxdump("VIEW TABLE",(char *)&ViewTbl,sizeof(ViewTBL));
  axaxdump("ITEM TABLE",(char *)&ItemTbl,sizeof(ItemTBL));
  axaxdump("EXT  TABLE",(char *)&ExtTbl,sizeof(ExtTBL));
#endif

	memset(rPrmp,0,sizeof(rPrmp));
	memset(pPrmp,0,sizeof(pPrmp));
	/* �|�C���^�[�z��Ɏ��̂̃A�h���X���Z�b�g */
	for (i=0;i<SQL_PARMNUM;i++)
		pPrmp[i] = &rPrmp[i];

	irc = cl_sl_joint_sqlsnd(pPrmp);
	if (irc == 100) return irc;
	else if (irc) {
		ERROROUT("cl_sl_joint_sqlsnd");
		return -1;
	}

	return 1;
}

int cl_sl_till_get_elmnt()
{
	int irc;

	/* get result for make joint table */
	irc = cl_sl_sqlrcv(4,pPrmp);
	if (irc) {
		ERROROUT("cl_sl_sqlrcv");
		return -1;
	}

	/* make joint table */
	irc = cl_sl_make_jnt_table();
	if (irc) {
		ERROROUT("cl_sl_make_jnt_table");
		return -1;
	}

	/* send packet for get element data */
	memset(rPrmp,0,sizeof(rPrmp));
	irc = cl_sl_make_select_command(pPrmp);
	if (irc) {
		ERROROUT("cl_sl_make_select_command");
		return -1;
	}
#ifdef ALL_HOST
	return 0;
#else
	return 2;
#endif
}

int cl_sl_mk_output_data()
{
#ifndef ALL_HOST
	int	irc = 0;

#ifdef DEBUG_OFF
printf("make format data\n");
getchar();
#endif

	irc = cl_sl_sqlrcv(pPrmp);
	if (irc) {
		ERROROUT("cl_sl_sqlrcv");
		return -1;
	}

	irc = cl_sl_mk_format_data();
	if (irc) {
		ERROROUT("cl_sl_mk_format_data");
		return -1;
	}
#endif
	return 0;
}
