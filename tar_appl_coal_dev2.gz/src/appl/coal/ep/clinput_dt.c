static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  							                              *
*                                                                             *
*      �֐����@�@�@�F�@int clinput_dt( pFrameTbl )						      *
*                      (I)pFrameInfo	*pFrameTbl						      *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;
extern CLCOMMON CLcommon;

#define	PRT_1(x)

int cl_input_dt( pFrameTbl )
pFrameInfo		pFrameTbl;
{
	int i,j,rc,iSel,inumW,len;
	int headlen,Framenum;
	ScrPrCT *pScCT;
	tdtInfoParm *pprmList,*pInfoParm,rInfoParm;
	ProcCT *pPrCT;
	char *p;
	tdtInfoParm ***pTBL;
	ONTBL   *pOntbl;
	qDataElm  *pDTbl;
	int *pSize;

	pScCT = cl_search_src_ct();
	if (pScCT->OnSelect < 0) {
		ERROROUT("cl_input_dt: skip data");
		return 0;
	}
	pTBL = pScCT->Vary->pTBL_pasento;
	pSize = (int *)pTBL[0];
	for (i=1;i<=2;i++) {
		if (i == 1) inumW = pFrameTbl->iTuple;
		else inumW = pFrameTbl->iNode;
		if (!(pprmList = cl_get_var_ent(pTBL,i))) return -1;

PRT_1(printf("cl_input_dt: i=%d pprmList=%08x num=%d\n",i,pprmList,inumW);)

		if (rc=cl_input_int_prm_set(pprmList,inumW)) return rc;
	}
/*
	for (;i<=pScCT->Vary->varnam_pasento;i++) {
		if (!(pprmList = cl_get_var_ent(pTBL,i))) return -1;
		memset(pprmList,0,sizeof(tdtInfoParm));
	}
*/
	Framenum = pFrameTbl->iNode;
	for (i=0,j=2;i<Framenum;i++,j++) {
		pDTbl = &pFrameTbl->pDataTbl[i];
		pInfoParm = cl_get_var_ent(pTBL,j+1);
	/*	info_parm_clear(pInfoParm);	*/
		memset(pInfoParm,0,sizeof(tdtInfoParm));
		pInfoParm->pi_id   = ' ';
		pInfoParm->pi_attr = pDTbl->attr;
		if (pInfoParm->pi_attr == DEF_ZOK_BULK)	/*** 5.10 Koba ***/
			headlen = sizeof( FORM_K );
		else if ((len=pDTbl->len) < 256 )
			headlen = sizeof( FORM_S );
		else
			headlen = sizeof( FORM_K );
		pInfoParm->pi_hlen = 0;
		pInfoParm->pi_pos  = headlen;
		pInfoParm->pi_dlen = len;
		pInfoParm->pi_len  = headlen + len;
		pInfoParm->pi_data = pDTbl->pData;
		if (pInfoParm->pi_attr == DEF_ZOK_CHAR) {
			pInfoParm->pi_code = cl_code_type(0,0);
PRT_1(printf("clinput_dt: pi_code=%d\n",pInfoParm->pi_code);)
			if ((rc=cl_code_trans(pInfoParm,&rInfoParm)) > 0) {
				cl_gx_copy_info(pInfoParm,&rInfoParm);
			}
		}
	}
	pScCT->Vary->varnam_pasento = Framenum + 2;
	cl_set_parm_bin(cl_var_size_parm(pSize),Framenum+2);

	pOntbl = pScCT->ONCOND[pScCT->OnSelect];
	if (iSel=pOntbl->PrSel[1]) {
		if (rc=cl_input_exec_proc(iSel,pOntbl->PrName[1])) return rc;
	}

	return NORMAL;
}
