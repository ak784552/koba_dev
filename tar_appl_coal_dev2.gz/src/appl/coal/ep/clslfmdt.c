static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************/
/*	��������								*/
/*	   �t�H�[�}�b�g�f�[�^�쐬				*/
/*------------------------------------------*/
/********************************************/
/* */
#include "colmn.h"
/* */
#define D_MAX_WORK_SIZE		4096
#define D_MAX_SP_DATA_SIZE	1024
#define D_MAX_LHEAD_SIZE	1024
#define D_MAX_CONTENT_SIZE	4096
#define D_USER_CODE		8
#define D_COMMAND		4
#define D_SYURUI_CODE	4
#define D_POSI_PRM		12+sizeof(qCommPackHead)
 
#define ALL_HOST

#define ORDER_BY

#define Head_stX	1
#define Head_stY	1

#define Fno_st	7

/* */
#ifdef L_END
#define BICOPY(A,B,C) *(C *)(A)=B;
#else
#define BICOPY(A,B,C) \
	{									\
		C con = B;						\
										\
		if (sizeof(C) == 4){			\
			*(A)   = *((char *)&con+3);	\
			*(A+1) = *((char *)&con+2);	\
			*(A+2) = *((char *)&con+1);	\
			*(A+3) = *((char *)&con);	\
		}								\
		else {							\
			*(A)   = *((char *)&con+1);	\
			*(A+1) = *((char *)&con);	\
		}								\
	}
#endif
/* */
typedef struct {
	int	 tupple;
	int	 column;
	int	*chars;
} qFMdataMkInfo;

qFMdataMkInfo  FMINFO;

typedef struct {
	char  id[2];
	char  size[4];
	uchar paperKind;
	uchar layoutKind;
	short paperDirect,
		wdSz,
		htSz,
		pageSz,
		charWd,
		charHt,
		headSz,
		footSz,
		frameCd,
		tpMg,
		btMg,
		ltMg,
		rtMg;
} qLayoutFR;
typedef qLayoutFR *pLayoutFR;

typedef struct {
	short fid	;
	char  size[4];
	short fieldCd,
			actionPs,
			actionSz;
	uchar frameCd,
			ulineCd ;
	short stX,
			stY,
			edX,
			edY	 ;
	uchar dataKd ,
			ioKd,
			nodeKd ,
			fieldKd ;
} qFieldFR;
typedef qFieldFR  *pFieldFR;

typedef struct {
	uchar charKd ,
			umekomi,
			charDec,
			charSz  ;
	uchar color[4];
	uchar linesFld[2],
			charsFld[2],
			frIndnt[2],
					rrIndnt[2] ;
	uchar quote[2];
} qCharsFR;
typedef qCharsFR *pCharsFR;

/* */
extern ViewTBL ViewTbl;
extern ItemTBL ItemTbl;
extern ExtTBL  ExtTbl;
extern CatCondTBL CatCondTbl;
extern GlobalCt *pGlobTable;

extern CLPRTBL	*pCLprocTable;
extern CLCOMMON CLcommon;

extern char *pOrgCmnd;

char *szSummury[]={"","MAX.","MIN.","SUM."," COUNT(*)",NULL};

/* */

int cl_sl_mk_format_data()
{
	char  *wrP	= NULL,
	  	  *wrPw   = NULL,
		  *layoutp,
		  *pFld,
		  *pLHead = NULL,
		  *pCont  = NULL,
		  *pSp	= NULL;
	char   dtID[2],
		   vattr[2]	;
	int	headSize	= 0,
		   workSize	= 0;
	int	posi		= 0,
		   irc		 = 0;
	long   size		= 0,
		   totalSizePs = 0;
	int	layoutps	= 0;
	qLayoutFR	qlayoutFR;
	pLayoutFR	playout;
	int i,w,tl,tli;
	int size_fm;

	FMINFO.chars = (int *)Malloc(ExtTbl.iItemNum * sizeof(int));
	if (!FMINFO.chars) goto Err;
	tl = Head_stX + 1;	/* �p�����́A���E���킹��(Head_stX+1)�̗]������� */
#ifdef ORDER_BY
	FMINFO.column = 0;
	for(i=0;i<ExtTbl.iItemNum;i++) {
		if (ExtTbl.Line[i].DisplaySequence>0) {
			w = FMINFO.chars[FMINFO.column++] = ExtTbl.Line[i].DisplayDigit;
			tli = tl + w;
			if (tli<tl || tli>32767) goto Err;
			tl = tli;
		}
	}
#else
	FMINFO.column = ExtTbl.iItemNum;
	for(i=0;i<ExtTbl.iItemNum;i++) {
		w = FMINFO.chars[i] = ExtTbl.Line[i].DisplayDigit;
		tli = tl + w;
		if (tli<tl || tli>32767) goto Err;
		tl = tli;
	}
#endif
	/* */
	cmn_set_stat(SEL_ED,&pCLprocTable->SearchSt,L_ON);
	if (!(wrP=cl_tmp_const_malloc(D_MAX_WORK_SIZE*8))) goto Err;
#if 1
	vattr[0] = 0x50;
	vattr[1] = 0x00;
	memcpy(wrP+posi,vattr,sizeof(vattr));
	posi += sizeof(vattr);
	posi += sizeof(long);
#endif

	/* attribute */
	vattr[0]	 = 0x50;
	vattr[1]	 = 0x00;
	memcpy(wrP+posi, vattr, sizeof(vattr));
	posi += sizeof(vattr);

	/* total size */
	totalSizePs = posi;
	posi += sizeof(long);

	/* LAYOUT data set */
	cl_sel_mklayout(&qlayoutFR);
	layoutps = posi;
	memcpy(wrP+posi, (char *)&qlayoutFR, sizeof(qLayoutFR));
	posi += sizeof(qLayoutFR);
	
#ifdef DEBUG_OFF
  axaxdump("Layout", (char *)&qlayoutFR, sizeof(qLayoutFR));
#endif

	/* FIELD data & CHARS data set */
	irc = cl_sel_mk_field(&pFld);
	if (irc < 0) goto Err;
	memcpy(wrP+posi, pFld, irc);
	posi += irc;

#ifdef DEBUG_OFF
  axaxdump("Field", pFld, irc);
#endif

	/* huka jouhou set */
	pSp = Malloc(D_MAX_SP_DATA_SIZE);
	if (!pSp) goto Err;
	irc = cl_sel_mk_sp_data(pSp);
	if (irc < 0) goto Err;
	memcpy(wrP+posi, pSp, irc);
	posi += irc;

#ifdef DEBUG_OFF
  axaxdump("special data", pSp, irc);
#endif

	/* layout format size */
	playout = (pLayoutFR)(wrP+layoutps);
	BICOPY(playout->size, posi-layoutps-sizeof(char)*2-sizeof(char)*4, long)

	/* bulk data size */
	size = posi-layoutps;
	size_fm = posi-layoutps;
	memcpy(wrP+totalSizePs, (char *)&size, sizeof(long));

	/* midasi info set */
	irc = cl_sel_mk_lhead(&pLHead);
	if (irc < 0) goto Err;
	memcpy(wrP+posi, pLHead, irc);
	posi += irc;

#ifdef DEBUG_OFF
  axaxdump("line head", pLHead, irc);
#endif
	if (irc=cl_sel_mk_sql()) goto Err;
	playout = (pLayoutFR)(wrP+layoutps);
	{
	short  chars,i;
	for(chars=Head_stX,i=0;i<FMINFO.column;i++)
		chars += FMINFO.chars[i];
	BICOPY((char *)&playout->wdSz, chars+1, short)
	BICOPY((char *)&playout->htSz, FMINFO.tupple+1, short)
	}
	{
	ScrPrCT	 *scrTbl   = (ScrPrCT *)NULL;
	tdtInfoParm *pInfoParm, InfoParm;
	int len;

	/* current script proces table get */
	scrTbl = cl_search_src_ct();
	if (scrTbl == (ScrPrCT *)NULL) goto Err;

	if (!(pInfoParm = cl_get_var_ent(scrTbl->Vary->pTBL_dolu,1))) goto Err;
	size = posi-6;
	memcpy(wrP+2,(char *)&size,sizeof(long));
	size -= 38;
	memcpy(wrP+totalSizePs,(char *)&size_fm,sizeof(long));
	if (cmn_chk_data(wrP,&InfoParm)) goto Err;
	if (cl_gx_rep_info_set_ign(pInfoParm,&InfoParm,1)) goto Err;

	wrPw = wrP + posi;
	sprintf(wrPw+2,"%s%d",BUNKEN_GR,pCLprocTable->iThread);
	*wrPw = 0x11;
	len = strlen(wrPw+2);
	*(wrPw+1) = len;
	if (!(pInfoParm = cl_get_var_ent(scrTbl->Vary->pTBL_dolu,2))) goto Err;
	if (cmn_chk_data(wrPw,&InfoParm)) goto Err;
	if (cl_gx_rep_info_set_ign(pInfoParm,&InfoParm,1)) goto Err;

	wrPw += len+3;
	sprintf(wrPw+2,"%s%d",BUNKEN_SQL,pCLprocTable->iThread);
	*wrPw = 0x11;
	*(wrPw+1) = strlen(wrPw+2);
	if (!(pInfoParm = cl_get_var_ent(scrTbl->Vary->pTBL_dolu,3))) goto Err;
	if (cmn_chk_data(wrPw,&InfoParm)) goto Err;
	if (cl_gx_rep_info_set_ign(pInfoParm,&InfoParm,1)) goto Err;
	}

	if(pSp)		Free(pSp);
	if(pLHead)	Free(pLHead);
	if(pCont)	Free(pCont);
	if (FMINFO.chars) Free(FMINFO.chars);
	if (pFld) Free(pFld);
	return 0;
Err:
	if(pSp)		Free(pSp);
	if(pLHead)	Free(pLHead);
	if(pCont)	Free(pCont);
	if (FMINFO.chars) Free(FMINFO.chars);
	if (pFld) Free(pFld);
	return -1;
}
/********************************************/
/*											*/
/********************************************/
int cl_sel_mk_sp_data(p)
char   *p;
{
	static char pad[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
	int	i,posi = 0;

	memcpy(p, pad, sizeof(pad));
	posi += sizeof(pad);

	/* first infomation */
	BICOPY(p+posi, 0, short)
	posi += sizeof(short);

	BICOPY(p+posi, 0, short)
	posi += sizeof(short);

	BICOPY(p+posi, 2, short)
	posi += sizeof(short);

	BICOPY(p+posi, 4, short)
	posi += sizeof(short);
	BICOPY(p+posi, Fno_st, short)
	posi += sizeof(short);

	BICOPY(p+posi, Fno_st+FMINFO.column+1, short)
	posi += sizeof(short);

	for (i = 3; i <= 6; i++) {
		BICOPY(p+posi, i, short)
		posi += sizeof(short);
	}

	/* second infomation */
	BICOPY(p+posi, Fno_st, short)
	posi += sizeof(short);

	BICOPY(p+posi, 0, short)
	posi += sizeof(short);

	BICOPY(p+posi, 0, short)
	posi += sizeof(short);

	BICOPY(p+posi, FMINFO.column, short)
	posi += sizeof(short);

	for (i=1;i<=FMINFO.column;i++) {
		BICOPY(p+posi, Fno_st+i, short)
		posi += sizeof(short);
	}

	/* third infomation */
	BICOPY(p+posi, Fno_st+FMINFO.column+1, short)
	posi += sizeof(short);

	BICOPY(p+posi, 0, short)
	posi += sizeof(short);

	BICOPY(p+posi, 0, short)
	posi += sizeof(short);

	BICOPY(p+posi, FMINFO.column, short)
	posi += sizeof(short);

	for (i=1;i<=FMINFO.column;i++) {
		BICOPY(p+posi, Fno_st+FMINFO.column+1 + i, short)
		posi += sizeof(short);
	}

	return posi;
}

#define D_SYUBETU   255 
#define D_LAYOUT	  0x11
#define D_HOUKOU	  1 
#define D_PAGE_SIZE   1 
#define D_CHAR_WIDTH  0 
#define D_CHAR_HEIGHT 0 
#define D_HEAD_SIZE   0 
#define D_FOOT_SIZE   0 
#define D_FRAME	   0 
#define D_MARGIN_TP   0 
#define D_MARGIN_BT   0 
#define D_MARGIN_RT   0 
#define D_MARGIN_LT   0 

/* */
/***********************************************/
/*											 */
/*											 */
/*											 */
/*											 */
/***********************************************/
/* */
int	cl_sel_mklayout(p)
	pLayoutFR  p;
{

	memcpy(p->id, "FM", 2);
	p->paperKind  = (uchar)D_SYUBETU;
	p->layoutKind = (uchar)D_LAYOUT;
	BICOPY((char *)&(p->paperDirect),(short)D_HOUKOU, short)
	BICOPY((char *)&(p->wdSz	  ),(short)0		, short)
	BICOPY((char *)&(p->htSz	  ),(short)0		, short)
	BICOPY((char *)&(p->pageSz	),(short)D_PAGE_SIZE , short)
	BICOPY((char *)&(p->charWd	),(short)D_CHAR_WIDTH, short)
	BICOPY((char *)&(p->charHt	),(short)D_CHAR_HEIGHT, short)
	BICOPY((char *)&(p->headSz	),(short)D_HEAD_SIZE , short)
	BICOPY((char *)&(p->footSz	),(short)D_FOOT_SIZE , short)
	BICOPY((char *)&(p->frameCd	),(short)D_FRAME	 , short)
	BICOPY((char *)&(p->tpMg	  ),(short)D_MARGIN_TP , short)
	BICOPY((char *)&(p->btMg	  ),(short)D_MARGIN_BT , short)
	BICOPY((char *)&(p->ltMg	  ),(short)D_MARGIN_RT , short)
	BICOPY((char *)&(p->rtMg	  ),(short)D_MARGIN_LT , short)

	return(0);
}
/***********************************************/
/*											 */
/*											 */
/*											 */
/*											 */
/***********************************************/
int  cl_sel_mk_field(p)
	char  **p;
{
	int	i	= 0,
		   irc  = 0,
		   posi = 0;
	int	size = 0;
	int	n, stx;

	size = (sizeof(qCharsFR)+sizeof(qFieldFR))*(FMINFO.column*2 + 4) +
			 sizeof(qFieldFR)*2;

	*p = Malloc(size);
	if (*p == (char *)NULL)
		return -1;
	stx = 1;
	n = 10;
	irc=cl_sel_mk_fl_lhnodei(*p,	  3, stx, 0, stx+n, 1, n, 1);
	stx += n;
	posi += irc;
	irc=cl_sel_mk_fl_cti	(*p+posi, 4, stx, 0, stx+n, 1, n, 1);
	stx += n;
	posi += irc;
	irc=cl_sel_mk_fl_lhnodei(*p+posi, 5, stx, 0, stx+n, 1, n, 1);
	stx += n;
	posi += irc;
	irc=cl_sel_mk_fl_cti	(*p+posi, 6, stx, 0, stx+n, 1, n, 1);
	posi += irc;

	irc = cl_sel_mk_fl_lhgroup(*p+posi,Fno_st, Head_stX, Head_stY+1);
	if (irc < 0)
		return -1;
	posi += irc;

	/* content */
	for(i=0;i<FMINFO.column;i++)
		{
		irc = cl_sel_mk_fl_ct(*p+posi, i);
		if (irc < 0)
			return -1;
		posi += irc;
		}

	irc = cl_sel_mk_fl_lhgroup(*p+posi,Fno_st+FMINFO.column+1,Head_stX,Head_stY);
	if (irc < 0)
		return -1;
	posi += irc;

	/* �w�b�_���o�� */
	for(i=0;i<FMINFO.column;i++)
		{
		irc = cl_sel_mk_fl_lhnode(*p+posi, i);
		if (irc < 0)
			return -1;
		posi += irc;
		}

	return posi;
}

/***********************************************/
/*											 */
/*											 */
/*											 */
/*											 */
/***********************************************/
/* */
#undef  D_BS_FLD
#define D_BS_FLD	  3
#undef  D_CND_FIELD
#define D_CND_FIELD   1
#undef  D_CND_FRAME
#define D_CND_FRAME   0
#undef  D_CND_ULINE
#define D_CND_ULINE   0
#undef  D_DATA_KIND
#define D_DATA_KIND   4
#undef  D_IO_KIND
#define D_IO_KIND	 0
#undef  D_NODE_KIND   
#define D_NODE_KIND   1
#undef  D_FIELD_KIND   
#define D_FIELD_KIND  0

int cl_sel_mk_fl_lhgroup(p, grno, stx, sty)
char  *p;
int   grno,stx,sty;
{
	int i,field;
	qFieldFR work;

	BICOPY((char *)&work.fid,grno,short)
	BICOPY((char *)work.size, sizeof(qFieldFR),long)
	BICOPY((char *)&work.fieldCd,D_CND_FIELD,short)
	BICOPY((char *)&work.actionPs,sizeof(qFieldFR),short)
	BICOPY((char *)&work.actionSz,0,short)
	work.frameCd  = (uchar)D_CND_FRAME;
	work.ulineCd  = (uchar)D_CND_ULINE;
	BICOPY((char *)&work.stX,stx,short)
	BICOPY((char *)&work.stY,sty,short)
	field = stx;
	for (i = 0; i < FMINFO.column; i++)
		field += FMINFO.chars[i];
	BICOPY((char *)&work.edX,field,short)
	BICOPY((char *)&work.edY,sty+1,short)
	work.dataKd   = (uchar)D_DATA_KIND;
	work.ioKd     = (uchar)D_IO_KIND;
	work.nodeKd   = (uchar)D_NODE_KIND;
	work.fieldKd  = (uchar)D_FIELD_KIND;

	memcpy(p,(char *)&work,sizeof(qFieldFR));

	return  sizeof(qFieldFR);

}
/*********************************************/
/*											 */
/*********************************************/
#undef  D_BS_FLD
#undef  D_CND_FIELD
#undef  D_CND_FRAME
#undef  D_CND_ULINE
#undef  D_ST_Y
#undef  D_ED_Y
#undef  D_DATA_KIND
#undef  D_IO_KIND
#undef  D_NODE_KIND
#undef  D_FIELD_KIND

#define D_BS_FLD		3
#define D_CND_FIELD		1
#define D_CND_FRAME		0
#define D_CND_ULINE		0
#define D_ST_Y			0
#define D_ED_Y			0
#define D_DATA_KIND		0
#define D_IO_KIND		0
#define D_NODE_KIND		0
#define D_FIELD_KIND	0

/* */
#undef  D_CHAR_KIND
#undef  D_UMEKOMI
#undef  D_CHAR_DECO
#undef  D_CHAR_SIZE
#undef  D_COLOR
#undef  D_LINES_FLD
#undef  D_FR_INDENT
#undef  D_RR_INDENT
#undef  D_QUOTE

#define D_CHAR_KIND		0
#define D_UMEKOMI		0
#define D_CHAR_DECO		0
#define D_CHAR_SIZE		0
#define D_COLOR			0
#define D_LINES_FLD		1
#define D_FR_INDENT		0
#define D_RR_INDENT		0
#define D_QUOTE			0

/* */

int cl_sel_mk_fl_lhnode(p,flg)
char  *p;
int flg;
{
	static int fieldNumber, stx, edx;
	int irc,n;

	if (!flg) {
		fieldNumber = 1;
		stx =  Head_stX;
	}
	n = FMINFO.chars[fieldNumber-1];
	edx = stx + n;

	irc = cl_sel_mk_fl_lhnodei(p, Fno_st + fieldNumber + FMINFO.column + 1,
		 stx, Head_stY, edx, Head_stY+1, n, 0);

	stx = edx;
	fieldNumber++;

	return irc;
}

int  cl_sel_mk_fl_lhnodei(p, fno, stx, sty, edx, edy, n, frame)
char  *p;
int   fno, stx, sty, edx, edy, n, frame;
{
	qFieldFR work;
	qCharsFR work_c;

	/* FIELD DATA */
	BICOPY((char *)&work.fid, fno, short)
	BICOPY((char *)&work.fieldCd,D_CND_FIELD,short)
	BICOPY((char *)&work.actionSz,0,short)
	work.frameCd  = (uchar)frame;
	work.ulineCd  = (uchar)D_CND_ULINE;
	BICOPY((char *)&work.stX,stx,short)
	BICOPY((char *)&work.stY,sty,short)
	BICOPY((char *)&work.edX,edx,short)
	BICOPY((char *)&work.edY,edy,short)
	work.dataKd   = (uchar)D_DATA_KIND;
	work.ioKd     = (uchar)D_IO_KIND;
	work.nodeKd   = (uchar)D_NODE_KIND;
	work.fieldKd  = (uchar)D_FIELD_KIND;

	/* CHARS DATA */
	work_c.charKd   = (uchar)D_CHAR_KIND;
	work_c.umekomi  = (uchar)D_UMEKOMI;
	work_c.charDec  = (uchar)D_CHAR_DECO;
	work_c.charSz   = (uchar)D_CHAR_SIZE;
	BICOPY((char *)work_c.color,D_COLOR,long)
	BICOPY((char *)work_c.linesFld,D_LINES_FLD,short)

	BICOPY((char *)work_c.charsFld,n,short)
	BICOPY((char *)work_c.frIndnt,D_FR_INDENT,short)
	BICOPY((char *)work_c.rrIndnt,D_RR_INDENT,short)
	BICOPY((char *)work_c.quote,D_QUOTE,short)

	BICOPY((char *)work.size,sizeof(qFieldFR)+sizeof(qCharsFR),long	)
	BICOPY((char *)&work.actionPs,sizeof(qFieldFR)+sizeof(qCharsFR),short)

	memcpy(p,(char *)&work,sizeof(qFieldFR));
	memcpy(p+sizeof(qFieldFR),(char *)&work_c,sizeof(qCharsFR));

	return  sizeof(qFieldFR)+sizeof(qCharsFR);
}
/*********************************************/
/*											 */
/*********************************************/
#undef  D_BS_FLD
#undef  D_CND_FIELD
#undef  D_CND_FRAME
#undef  D_CND_ULINE
#undef  D_ST_Y
#undef  D_ED_Y
#undef  D_DATA_KIND
#undef  D_IO_KIND
#undef  D_NODE_KIND
#undef  D_FIELD_KIND

#define D_BS_FLD		3
#define D_CND_FIELD		1
#define D_CND_FRAME		0
#define D_CND_ULINE		0
#define D_ST_Y			0
#define D_ED_Y			0
#define D_DATA_KIND		0
#define D_IO_KIND		0
#define D_NODE_KIND		0
#define D_FIELD_KIND	0

int  cl_sel_mk_fl_ct(p, flg)
char  *p;
int flg;
{
	static int fieldNumber, stx, edx;
	int irc,n;

	if (!flg) {
		fieldNumber = 1;
		stx =  Head_stX;
	}
	n = FMINFO.chars[fieldNumber-1];
	edx = stx + n;

	irc = cl_sel_mk_fl_cti(p, Fno_st + fieldNumber,
		 stx, Head_stY+1, edx, Head_stY+2, n, 0);

	stx = edx;
	fieldNumber++;

	return irc;
}

int  cl_sel_mk_fl_cti(p, fno, stx, sty, edx, edy, n, frame)
char *p;
int  fno,stx,sty,edx,edy,n,frame;
{
	qFieldFR work;
	qCharsFR work_c;

	/* FIELD DATA */
	BICOPY((char *)&work.fid,fno, short)
	BICOPY((char *)&work.fieldCd,D_CND_FIELD,short)
	BICOPY((char *)&work.actionSz,0,short)
	work.frameCd = (uchar)frame;
	work.ulineCd = (uchar)D_CND_ULINE;
	BICOPY((char *)&work.stX,stx,short)
	BICOPY((char *)&work.stY,sty,short)
	BICOPY((char *)&work.edX,edx,short)
	BICOPY((char *)&work.edY,edy,short)
	work.dataKd  = (uchar)D_DATA_KIND;
	work.ioKd	 = (uchar)D_IO_KIND;
	work.nodeKd  = (uchar)D_NODE_KIND;
	work.fieldKd = (uchar)D_FIELD_KIND;

	/* CHARS DATA */
	work_c.charKd  = (uchar)D_CHAR_KIND;
	work_c.umekomi = (uchar)D_UMEKOMI  ;
	work_c.charDec = (uchar)D_CHAR_DECO;
	work_c.charSz  = (uchar)D_CHAR_SIZE;
	BICOPY((char *)work_c.color,D_COLOR,long)
	BICOPY((char *)work_c.linesFld,D_LINES_FLD,short)

	BICOPY((char *)work_c.charsFld,n, short)
	BICOPY((char *)work_c.frIndnt,D_FR_INDENT,short)
	BICOPY((char *)work_c.rrIndnt,D_RR_INDENT,short)
	BICOPY((char *)work_c.quote,D_QUOTE,short)

	BICOPY((char *)work.size,sizeof(qFieldFR)+sizeof(qCharsFR),long)
	BICOPY((char *)&work.actionPs,sizeof(qFieldFR)+sizeof(qCharsFR),short)

	memcpy(p,(char *)&work,sizeof(qFieldFR));
	memcpy(p+sizeof(qFieldFR),(char *)&work_c,sizeof(qCharsFR));

	return  sizeof(qFieldFR)+sizeof(qCharsFR);
}
/***********************************************/
/*											 */
/*											 */
/*											 */
/*											 */
/***********************************************/
#if 0
int  cl_sel_mk_lhead(p)
char   *p;
#else
int  cl_sel_mk_lhead(pp)
char   **pp;
#endif
{
	short sKind,sItemLen,sKindLen;
	int   irc,posi,column,num,i;
	char  patch[2],dhead[2],*midashi[2];
#if 1
	char *p;

	midashi[0] = FORMAT(512);	/* ���������F */
	midashi[1] = FORMAT(513);	/* �o�͌����F */
	posi = 39 + (sizeof(dhead) + sizeof(patch))*2 +
	       strlen(midashi[0]) + strlen(midashi[1]) + 17 + FMINFO.column*5 + 12;

	for (i=0;i<ExtTbl.iItemNum;i++) {
#ifdef ORDER_BY
	  if (ExtTbl.Line[i].DisplaySequence>0) {
#endif
		posi += sizeof(dhead);
		posi += strlen(ExtTbl.Line[ i ].ItemName);
		posi += sizeof(patch);
#ifdef ORDER_BY
	  }
#endif
	}
/*
printf("*** cl_sel_mk_lhead:Head size = %d\n",posi);
*/
	if (!(*pp=Malloc(posi))) return -1;
	p = *pp;
	posi = 0;
#endif

	strcpy(p, "GR0000100001000020000300005DT0000100004");
	posi += 39;
	patch[0] = 0x11;	/* moji zokusei,hyoujun keisiki */
	patch[1] = 0x00;	/* NULL pointer */
	dhead[0] = 0x11 | (CLcommon.cDataCode<<1);
							/* moji zokusei,hyoujun keisiki */
	dhead[1] = (char)10;
	for (i=0;i<2;i++) {
		memcpy(p+posi, dhead, sizeof(dhead));
		posi += sizeof(dhead);
		memcpy(p+posi, midashi[i],(int)dhead[1]);
		posi += (int)dhead[1];
		memcpy(p+posi, patch, sizeof(patch));
		posi += sizeof(patch);
	}

	column = FMINFO.column;
	num = Fno_st + column + 1;
	sprintf(p+posi, "GR%05d00001%05d", num, column);
	posi += 17;

	while (column--) {
		sprintf(p+posi, "%05d", ++num);
		posi += 5;
	}
/*
printf("cl_sel_mk_lhead:[%s]\n",p);
*/
	sprintf(p+posi, "DT00001%05d", FMINFO.column*2); /* node size	  */
	posi += 12;
/*
	dhead[0] = 0x11;
*/
	for (i=0;i<ExtTbl.iItemNum;i++) {
#ifdef ORDER_BY
	  if (ExtTbl.Line[i].DisplaySequence>0) {
#endif
		sItemLen = strlen(ExtTbl.Line[i].ItemName);
		if (sKind=ExtTbl.Line[i].SummuryKind) {
			sKindLen = strlen(szSummury[sKind]);
			if (sKind == 4) {
				dhead[1] = (char)sKindLen;
				memcpy(p+posi, dhead, sizeof(dhead));
				posi += sizeof(dhead);
				memcpy(p+posi, szSummury[sKind],(int)sKindLen);
				posi += (int)sKindLen;
			}
			else {
				dhead[1] = (char)(sKindLen+sItemLen);
				memcpy(p+posi, dhead, sizeof(dhead));
				posi += sizeof(dhead);
				strcpy(p+posi,szSummury[sKind]);
				posi += (int)sKindLen;
				memcpy(p+posi, ExtTbl.Line[ i ].ItemName,(int)sItemLen);
				posi += (int)sItemLen;
			}
		}
		else {
			dhead[1] = (char)sItemLen;
			memcpy(p+posi, dhead, sizeof(dhead));
			posi += sizeof(dhead);
			memcpy(p+posi, ExtTbl.Line[ i ].ItemName,(int)sItemLen);
/*
*(p+posi+sItemLen) = '\0';
printf("cl_sel_mk_lhead:i=%d ItemName[%s]\n",i,p+posi);
*/
			posi += (int)sItemLen;
		}
		memcpy(p+posi, patch, sizeof(patch));
		posi += sizeof(patch);
#ifdef ORDER_BY
	  }
#endif
	}

	return posi;
}

int cl_sel_mk_sql()
{
	FILE *fp;
	int column, colNum;
	int rc,i,num = 8;
	char filename[20];
	char cM_QUOTE1 = pGlobTable->Quot[0];

	column = colNum = FMINFO.column;
	sprintf(filename,"%s%d",BUNKEN_GR,pCLprocTable->iThread);
	if (!(fp=fopen(akb_akb_home_add(filename),"w"))) {
		ERROROUT1("cl_sel_mk_sql: file[%s] open error!!",filename);
		return ECL_SCRIPT_ERROR;
	}
	if (fprintf(fp,"PROC main;\n\tOUTPUT GR 7 1 %d",colNum) == EOF) {
		fclose(fp);
		return ECL_SCRIPT_ERROR;
	}
	while (column--) {
		if (fprintf(fp," %d",num++) == EOF) {
			fclose(fp);
			return ECL_SCRIPT_ERROR;
		}
	}
	if (fprintf(fp,";\n\tRETURN %d;\nENDPROC;\n",colNum) == EOF) {
		fclose(fp);
		return ECL_SCRIPT_ERROR;
	}
	fclose(fp);

	sprintf(filename,"%s%d",BUNKEN_SQL,pCLprocTable->iThread);
	if (!(fp=fopen(akb_akb_home_add(filename),"a"))) {
		ERROROUT1("cl_sel_mk_sql: file[%s] open error!!",filename);
		return ECL_SCRIPT_ERROR;
	}
	if (fprintf(fp,"\t\t\tBEXP $1 = $1 + 1;\n\t\t\tOUTPUT DT $1 %d",colNum*2)==EOF) {
		fclose(fp);
		return ECL_SCRIPT_ERROR;;
	}
	for (i=1;i<=colNum;i++) {
		if (i == 1)
			rc=fprintf(fp," #%d $3",i+2);
		else
			rc=fprintf(fp," #%d $2",i+2);
		if (rc == EOF) {
			fclose(fp);
			return ECL_SCRIPT_ERROR;
		}
	}
	if (fprintf(fp,";\n\t\t\tIF $1 GE %%2;\n\t\t\t\tBEXP $1 = (CCHAR)$1;BEXP $4 = (CCHAR)$4;\n") == EOF) {
		fclose(fp);
		return ECL_SCRIPT_ERROR;;
	}
	if (fprintf(fp,"\t\t\t\tOUTPUT GR 1 1 2 4 6;\n\t\t\t\tOUTPUT DT 1 4 $4 %c%c $1 %c%c;\n\t\t\t\tRETURN %d;\n\t\t\tENDIF;\n",cM_QUOTE1,cM_QUOTE1,cM_QUOTE1,cM_QUOTE1,ECL_FIELD_MAX) == EOF) {
		fclose(fp);
		return ECL_SCRIPT_ERROR;;
	}
	if (fprintf(fp,"\t\tENDLOOP;\n\tENDIF;\n\tRETURN $1;\nENDPROC;\n")==EOF) {
		fclose(fp);
		return ECL_SCRIPT_ERROR;;
	}
	fclose(fp);
	return 0;
}
