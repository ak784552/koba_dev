static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/***********************************************/
/* ��������                                    */
/*     SELECT �ߍ쐬�֐�                       */
/*---------------------------------------------*/
/***********************************************/
#include "colmn.h"

#define BUFF_SIZE 3600
/* add 11.11 Koba */
#define DCID_NAM "dcid_nam"
#define DCID_NMB "dcid_nmb"
#define HOST_COD "host_cod"

extern ExtTBL  ExtTbl;

static char *szKind[]={"","max","min","sum","count",NULL};

char *cl_sl_ext_select()
{
	char *buf;
	char atrnam[64];
	char flg;
	char *alias;
	char *atrb;
	int   i, j=0;
	short sKind;

	/*
	*** select���߂̐���
	*/
	flg = 0;
	if (!(buf = (char *)Malloc(BUFF_SIZE))) {
		ERROROUT("memory allocate error");
		return NULL;
	}
	strcpy(buf, "select ");
	/* �A�g���r���[�g�������[�v */
	for (i=0;i<ExtTbl.iItemNum;i++) {
		if (ExtTbl.Line[i].DisplaySequence > 0) {
			if (!(alias = ExtTbl.Line[i].ALIASNAME)) return NULL;
			if (!(atrb = ExtTbl.Line[i].AttrName)) return NULL;
			sKind = ExtTbl.Line[i].SummuryKind;
			if (j==0) {
				j++;
				if (!strcmp(atrb,DCID_NAM) && sKind==0) {
					sprintf(atrnam,"%s,%s",HOST_COD,DCID_NMB);
					strcat(buf, atrnam);
				}
				else if (sKind) {
					strcat(buf, "count(*),count(*)");
				}
				else {
					strcat(buf, "'NULL','NULL'");
				}
			}
			if (sKind==4) /* count */
				strcat(atrnam,",count(*)");
			else if (sKind>0)
				sprintf(atrnam,",%s(%s.%s)", szKind[sKind],alias, atrb);
			else
				sprintf(atrnam,",%s.%s", alias, atrb);
			strcat(buf, atrnam);
		}
	}

	/* select���߂̕�����̃|�C���^�[�����^�[�� */
	return buf;
}
