static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************/
/*												*/
/*	name service								*/
/*												*/
/*		coded   by A.Kobayashi	2010/05/31		*/
/*												*/
/************************************************/
#include "colmn.h"

#define DCHOSTS	"dchosts"

int getdchostbyname(dchostp,hostp,ulpaddr_h,procidp)
char *dchostp,*hostp;
ulong *ulpaddr_h;
int  *procidp;
{
	int n,procid,ret;
	char buf[D_RECORD_BUFSIZE],*argv[3],*cpPath;

	if (!(cpPath=akb_akb_home_add(DCHOSTS))) return -2;
	n = akxagetstpl(cpPath,dchostp,argv,3,buf,D_RECORD_BUFSIZE);
	if (n < 2) {
		*hostp = 0;
		*procidp = 0;
		return -1;
	}
	strcpy(hostp,argv[1]);
	ret = akb_get_host_addr(argv[1],ulpaddr_h);
	if (n >= 3) procid = atoi(argv[2]);
	else        procid = 0;
	*procidp = procid;
	return ret;
}

int getsamehost(dchostp,samep)
char *dchostp,*samep;
{
	FILE *fp;
	int n;
	char buf[D_RECORD_BUFSIZE],*argv[2],host[D_RECORD_BUFSIZE],*cpPath;

	if (!(cpPath=akb_akb_home_add(DCHOSTS))) return -2;
	n = akxagetstpl(cpPath,dchostp,argv,2,buf,D_RECORD_BUFSIZE);
	if (n != 2) {
		*samep = 0;
		return -1;
	}
	strcpy(host,argv[1]);
	n = akxagetstpli(cpPath,2,host,argv,2,buf,D_RECORD_BUFSIZE);
	if (n>=2) {
		strcpy(samep,argv[0]);
		n = strlen(samep);
	}
	return n;
}
