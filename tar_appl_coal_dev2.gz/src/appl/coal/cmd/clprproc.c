static char sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/*	<clprproc.c>													*/
/*		Proc process												*/
/********************************************************************/
#include "colmn.h"

extern GXObjectExpand CLobjExp;	/* add 20231203 */

/************************************/
/*	_chk_var_name					*/
/************************************/
static int _chk_var_name(name,len)
char *name;
int len;
{
#if 1	/* 2024.7.6 */
	if (*name == '*') {
		name++;
		len--;
	}
#endif
	return cl_def_chk_name(name,len,"cl_process_proc",FORMAT(441));
}
#if 1	/* 2021.7.22 */
/************************************/
/*	_ProcClearVar					*/
/************************************/
static int _proc_clear_var(proc)
ProcCT  *proc;
{
	int scope;
	ScrPrCT *scrct;
	Leaf *topleaf;

	if (!(scrct=cl_search_src_ct())) return 0;
/*
printf("_proc_clear_var: varnam=[%s]\n",varnam);
*/
	scope = /*D_AUX1_GLOBAL_VAR | D_AUX1_PUBLIC_VAR | D_AUX1_PRIVATE_VAR | */D_AUX1_LOCAL_VAR;
	if (!strcmp(proc->ProcNM,"main")) scope |= D_AUX1_PRIVATE_VAR;
	topleaf = proc->ProcTop->leftleaf;
	return cl_gx_clear_var_obj2(topleaf,NULL,NULL,proc->Obj,scope);
}
#endif
/************************************/
/*	_chk_pname						*/
/************************************/
static int _chk_pname(iob0,obj,da,max_pas,tbl_pas)
int iob0,obj[],max_pas;
char *da[];
tdtInfoParm ***tbl_pas;
{
	tdtInfoParm *pInfoParm;
	int i,npa,ipa,ida,rc,iob;
	char *pnam;

	if (!obj || !da || !tbl_pas) return -1;
	rc = 0;
	for (i=1;i<=max_pas;i++) {
		if (pInfoParm = cl_get_var_ent(tbl_pas,i)) {
			if (pInfoParm->pi_id == D_DATA_ID_PNAME) {
				pnam = pInfoParm->pi_paux;
/*
printf("_chk_pname: i=%d pnam=[%s]\n",i,pnam);
*/
				iob = iob0;
				npa = obj[iob++];
				rc = ECL_SCRIPT_ERROR;
				while (npa-- > 0) {
					ipa = obj[iob++];
					ida = obj[iob++];
/*
printf("_chk_pname: ipa=%d da=[%s]\n",ipa,da[ida]);
*/
					if (!strcmp(pnam,da[ida])) {
						rc = 0;
						break;
					}
					iob += 4;
				}
				if (rc) {
					/* %s: %d �ԖڂɎw��̉�������[%s]������܂���B */
					ERROROUT3(FORMAT(509),"_chk_pname",i,pnam);
					break;
				}
			}
		}
	}
	return rc;
}

/************************************/
/*	_get_pname_var_ent				*/
/************************************/
static tdtInfoParm *_get_pname_var_ent(name,max_pas,tbl_pas,ippa)
char *name;
int max_pas,*ippa;
tdtInfoParm ***tbl_pas;
{
	tdtInfoParm *pInfoParmC,*pInfoParm;
	int i,ii,ipa;

	if (ippa) ipa = *ippa;
	else ipa=0;
DEBUGOUTL3(151,"_get_pname_var_ent: name=[%s] max_pas=%d ipa=%d",name,max_pas,ipa);
	pInfoParmC = NULL;
	for (i=1,ii=0;;i++) {
		if (pInfoParm = cl_get_var_ent(tbl_pas,i)) {
			if (pInfoParm->pi_id == D_DATA_ID_PNAME) {
				if (name) {
					if (!strcmp(name,pInfoParm->pi_paux)) {
						pInfoParmC = (tdtInfoParm *)pInfoParm->pi_pos;
#if 1	/* 2021.8.11 */
						if (pInfoParmC->pi_id == 'S') pInfoParmC = (tdtInfoParm *)pInfoParmC->pi_pos;
#endif
						break;
					}
				}
			}
			else if (name) {
				if (i > max_pas) break;
			}
			else if (ippa) {
				if (++ii == ipa) {
					pInfoParmC = pInfoParm;
					*ippa = ++ipa;
					break;
				}
			}
		}
	}
	return pInfoParmC;
}

/************************************/
/*	cl_process_proc					*/
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_proc(leaf, proc)
Leaf   *leaf;
ProcCT *proc;
{
	static char *_fn_="cl_process_proc";
	static char *sep=" \t,()='";
	static char *attr_sep=" \t()[],'=";
	int   rc,nparm,len,atr,per_flg,ipa,ix,*pSize,max_pas,iMAIN,iParm[4],cmnd,*index;
	int   sp_save,is,kk_level,lenw,line_len,iSET,atr1,lend,check[4],attr,attr0;
	parmList *prmp[4],qprmp[4],**cmd_prmp,*parmp;
	char  buf[512],w[16],*name,wrk0[256],c,c0,*pp,*line,*dflt,*wrk,*p;
	SSPL_S ssp;
	tdtInfoParm	*pInfoParmC,*pInfoParmW,tInfoParm,*pInfoParmT,*pInfo;
	tdtInfoParm ***tbl_pas,***tbl_vnm;
	GXObject *pbxObj;
	XHASHB *pha_vnm;
	tdtArrayIndex *pIndex;
	int i,npr,npa,inpa,iob,ida,ipr,*obj,*jParm,iPNAME,iPN,iADDR;
	char **da;
	CMDObject *cmdobj;
	parmList pList;

DEBUGOUTL3(110,"%s:Enter leaf=%08x proc=%08x",_fn_,leaf, proc);

	if (!leaf || !proc) return ECL_SYSTEM_ERROR;

	/* ���̃m�[�h(leaf)�����s���悤�Ƃ��Ă���proc/func�łȂ��Ƃ�
	  (���s���悤�Ƃ��Ă���proc/func����proc/func�̂Ƃ�)�́A�X�L�b�v���� */
	if (proc->ProcTop != leaf) {
		proc->Nextleaf = leaf->rightleaf;
		return 0;
	}

#ifdef CMDOBJECT
	cmdobj = leaf->cmd.cmdobj;
/*	cmdobj->cid = leaf->cmd.cid;	*/
#endif

	if (!(proc->Nextleaf=leaf->leftleaf)) {
		if ((cmnd=leaf->cmd.cid) == C_PROC) name = FORMAT(114);	/* �葱�� */
		else if (cmnd == C_FUNCTION) name = FORMAT(115);	/* �֐� */
		else name = FORMAT(120);	/* �N���X */
		ERROROUT2(FORMAT(501),_fn_,name);	/* %s: %s���ɕ�������܂���B */
		return ECL_SCRIPT_ERROR;
	}

	if (rc=cl_mk_pr_var_set(proc)) return rc;

	pha_vnm = proc->pha_vnam;
/*	tbl_vnm = proc->pTBL_vnam;	*/

	nparm = leaf->cmd.prmnum;
	cmd_prmp = leaf->cmd.prmp;
	iMAIN = 0;

DEBUGOUTL2(120,"%s: leaf->cmd.cid=[%s]",_fn_,cl_gets_cmd_name(leaf->cmd.cid));

	if ((cmnd=leaf->cmd.cid) == C_FUNCTION) {
		pInfoParmC = proc->Retval;
DEBUGOUT_InfoParm(161,"%s: name=[%s]",pInfoParmC,_fn_,proc->ProcNM);
		if (pInfoParmT=(tdtInfoParm *)pInfoParmC->pi_paux) {
			if ((c=pInfoParmT->pi_id)=='I' || c=='T') {
				if ((ix=cl_gx_chk_vnam_info('s',pha_vnm,"My",2,&pInfoParmW)) <= 0) {
					/* %s: %s�̃G���g���p�̋󂫂�����܂���Brc=%d */
					ERROROUT3(FORMAT(502),_fn_,"My",ix);
					return ECL_SCRIPT_ERROR;
				}
			/*	pInfoParmW = cl_get_var_ent(tbl_vnm,ix);	*/
#if 1	/* 2021.10.27 */
				if (cl_gx_rep_info_als(pInfoParmW,pInfoParmT,1)) return -1;
#else
				if (cl_gx_rep_info_set(pInfoParmW,pInfoParmT,1)) return -1;
#endif
DEBUGOUT_InfoParm(194,"%s: name=%s",pInfoParmW,_fn_,"My");
			}
		}
	}
	else if (cmnd==C_PROC && !strcmp(proc->ProcNM,"main")) {
		if (rc=cl_prparmset(/*NULL,*/NULL,proc->ProcNM)) return rc;
		iMAIN = 1;
#ifdef CMDOBJECT
		cmdobj->option = iMAIN;
#endif
	}

DEBUGOUTL2(120,"%s:1 proc->ProcPath=[%s]",_fn_,nval1(proc->ProcPath));

	parmp = cmd_prmp[0];

DEBUGOUTL2(120,"%s: parmp->bxobj=%08x",_fn_,parmp->bxobj);

	if (pbxObj=parmp->bxobj) {
		if (p = proc->ProcPath) {

DEBUGOUTL2(120,"%s:2 proc->ProcPath=[%s]",_fn_,p);

			if (*p != '*') p = NULL;
		}
		if (!p) {
#if 1	/* 2024.3.4 */
/*
printf("%s: pbxObj->nda=%d\n",_fn_,pbxObj->nda);
printf("%s: pbxObj->da[0]=[%s]\n",_fn_,pbxObj->da[0]);
*/
			if (pbxObj->nda > 0) {
				if (akxm_addrchk(pbxObj->da)) {
					p = pbxObj->da[0];
					if (p && !akxm_addrchk(p)) p = NULL;
					proc->ProcPath = p;
				}
				if (!p) {
			/*	else {	*/
					ERROROUT("pbxObj->da is invalid.");
					return -1;
				}
			}
		/*	proc->ProcPath = p;	*/
#else
			if (pbxObj->da) proc->ProcPath = pbxObj->da[0];
#endif

DEBUGOUTL2(120,"%s:3 proc->ProcPath=[%s]",_fn_,nval1(proc->ProcPath));

		}
	}
	_proc_clear_var(proc);	/* proc�J�n���ɁAObj��obj0��clear����邪�A
							   leaf��obj0��clear����Ȃ��̂ŁA����͕K�v */
	if (cmnd == C_CLASS) return 0;
	if (nparm <= 1) return 0;

	max_pas = proc->varnam_pasento;
	tbl_pas = proc->pTBL_pasento;
	pSize = (int *)tbl_pas[0];
/*
printf("%s: max_pas=%d\n",_fn_,max_pas);
*/
	iPNAME = 0;
	for (i=1;i<=max_pas;i++) {
		if (pInfoParmC = cl_get_var_ent(tbl_pas,i)) {
DEBUGOUT_InfoParm(151,"%s :PNAME: i=%d",pInfoParmC,_fn_,i);
			if (pInfoParmC->pi_id == D_DATA_ID_PNAME) {
				iPNAME = 1;
				break;
			}
		}
	}
#ifdef CMDOBJECT
/*
printf("%s: cmdobj->opt=%08x\n",_fn_,cmdobj->opt);
*/
	if (cmdobj->nobj > 0) {
		if (npr=cmdobj->exobj[1]) goto Exobj;
		return 0;
	}
#if 1	/* 20231203 */
	cl_im_expand(CLobjExp.ms_obj,2,&obj);
	cl_im_expand(CLobjExp.ms_da,1,&da);
#else
	cl_im_expand(CLcList.mcat_obj,2,&obj);
	cl_im_expand(CLcList.mcat_da,1,&da);
#endif
	npr = npa = 0;
	da[0] = clstrdup(proc->ProcNM,0);
	ida = 1;
	obj[0] = 0;
	obj[1] = 0;
	iob = 2;
#endif
	line = cmd_prmp[1]->prp;
	line_len = cmd_prmp[1]->prmlen;
	memset(&ssp,0,sizeof(SSPL_S));
	wrk0[0] = '$';
	wrk = wrk0 + 1;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk0) - 2;
	pInfoParmW = NULL;
	rc = 0;
	c = ',';
	per_flg = ipa = kk_level = is = atr1 = 0;
	while ((len=akxtgwnsl(line,line_len,&ssp,sep,0x01)) > 0) {
		c0 = c;
		atr = ssp.attr[0];
		c = *wrk;
/*
printf("cl_process_proc: c0=%c sp=%d atr=%d wrk=[%s]\n",c0,ssp.sp,atr,wrk);
printf("                 per_flg=%d kk_level=%d is=%d atr1=%d\n",per_flg,kk_level,is,atr1);
*/
		if (per_flg == 1) {
			if (c == '(') kk_level++;
			else if (c==',' || c==')') {
				iSET = 0;
				if (c == ')') {
					if (--kk_level < 0) break;
					else if (!kk_level) {
						per_flg = 2;
						if (atr1) iSET = 1;
						else ipa++;
					}
				}
				else {	/* ',' */
					if (kk_level == 1) {
						if (atr1) iSET = 1;
						else {
							ipa++;
							is = ssp.sp;
						}
					}
				}
				if (iSET) {
					atr1 = 0;
					ipa++;
/*
printf("cl_process_proc: set param. ipa=%d\n",ipa);
*/
						sp_save = ssp.sp;
						lenw = ssp.sp - is -1;
						pp = line + is;
						ssp.sp = 0;
#if 1	/* 2023.4.21 */
						check[1] = 0x02;
						if ((rc=cl_get_def_modifier_SSP(pp,lenw,&ssp,attr_sep,check,iParm,NULL,NULL)) < 0) return rc;
/*
printf("cl_process_proc: check[3]=%08x iParm[0]=%d\n",check[3],iParm[0]);
*/
#else
						if (rc=cl_get_def_attr_SSP_opt(pp,lenw,&ssp,attr_sep,iParm,0x05,NULL,NULL)) return rc;
#endif
/*
printf("cl_process_proc:get_def_attr: sp=%d wrk=[%s]\n",ssp.sp,wrk);
*/
						if (!(iParm[0] | check[3])) ssp.sp = 0;
						if ((len=akxtgwnsl(pp,lenw,&ssp,sep,0x01)) <= 0) {
							/* %s: ��������������܂���B */
							ERROROUT2(FORMAT(500),_fn_,strmemk(pp,lenw,_fn_));
						/*	ERROROUT2(FORMAT(500),_fn_,strmem(pp,lenw));	*/
							return ECL_SCRIPT_ERROR;
						}
/*
printf("cl_process_proc:akxtgwnsl: sp=%d wrk=[%s]\n",ssp.sp,wrk);
*/
						name = clstrdup(wrk,0);
#ifdef CMDOBJECT
						npa++;
#if 1	/* 20231203 */
						cl_im_expand(CLobjExp.ms_obj,iob+1,&obj);
						cl_im_expand(CLobjExp.ms_da,ida,&da);
#else
						cl_im_expand(CLcList.mcat_obj,iob+1,&obj);
						cl_im_expand(CLcList.mcat_da,ida,&da);
#endif
						obj[iob++] = ipa;
						obj[iob++] = ida;
						da[ida++] = name;
#endif
						if (rc=_chk_var_name(name,len)) return rc;
						dflt = NULL;
						if (akxtgwnsl(pp,lenw,&ssp,sep,0x01) > 0) {
							c = wrk[0];
							if ((iParm[0] || stricmp(wrk,"AS")) && (c!='=')) {
								/* %s: ��������(%s)�̌�ɗ]���ȕ���(%s)������܂��B */
								ERROROUT3(FORMAT(504),_fn_,name,wrk);
								return ECL_SCRIPT_ERROR;
							}
							if (c != '=') {
								if (rc=cl_get_def_attr_SSP_opt(pp,lenw,&ssp,attr_sep,iParm,0x09,NULL,NULL)) return rc;
								akxtgwnsl(pp,lenw,&ssp,sep,0x01);
								c = wrk[0];
							}
							if (c) {
								if (c != '=') {
									/* %s: ������(%s)�̑����̌�ɗ]���ȕ���(%s)������܂��B */
									ERROROUT3(FORMAT(525),_fn_,name,wrk);
									return ECL_SCRIPT_ERROR;
								}
								if ((lend=akxtgwnsl(pp,lenw,&ssp,sep,0x01)) <= 0) {
									/* %s: ������(%s)�̃f�t�H���g�l������܂���B */
									ERROROUT2(FORMAT(524),_fn_,name);
									return ECL_SCRIPT_ERROR;
								}
								else {
									if (cl_chk_parm(wrk,lend) == NAME_CONST) p = wrk0;
									else p = wrk;
									dflt = clstrdup(p,0);
/*
printf("cl_process_proc: dflt=[%s]\n",dflt);
*/
									if (ssp.attr[0] > 10) {
										/* %s: �f�t�H���g�l(%s)������Ă��܂��B */
										ERROROUT2(FORMAT(538),_fn_,wrk);
										return ECL_SCRIPT_ERROR;
									}
									if (clpeeksl(pp,lenw,&ssp,sep,0x01) > 0) {
										/* %s: �f�t�H���g�l�̌�ɗ]���ȕ���(%s)������܂��B */
										ERROROUT2(FORMAT(539),_fn_,wrk);
										return ECL_SCRIPT_ERROR;
									}
								}
							}
						}
						ssp.sp = sp_save;
						is = ssp.sp;
#ifdef CMDOBJECT
#if 1	/* 20231203 */
						cl_im_expand(CLobjExp.ms_obj,iob+4,&obj);
						cl_im_expand(CLobjExp.ms_da,ida,&da);
#else
						cl_im_expand(CLcList.mcat_obj,iob+4,&obj);
						cl_im_expand(CLcList.mcat_da,ida,&da);
#endif
						iParm[0] |= check[3];
/*
printf("cl_process_proc: iParm=%08x %d %d %d iob=%d\n",iParm[0],iParm[1],iParm[2],iParm[3],iob);
*/
						memcpy(&obj[iob],iParm,sizeof(int)*4);
						iob += 4;
/*
printf("cl_process_proc: ida=%d\n",ida);
*/
						da[ida++] = dflt;
#endif
				}
#ifdef CMDOBJECT
				if (!kk_level) {
					if (npa) {
						obj[inpa] = npa;
						npr++;
					}
					else iob -= 2;
				}
#endif
			}
			else {
				if (kk_level>1 && !stricmp(wrk,"AS")) {
					/* %s: �`�r�̈ʒu���s���ł��B */
					ERROROUT1(FORMAT(526),_fn_);
					return ECL_SCRIPT_ERROR;
				}
				atr1 = 1;
			}
		}
		else {
			if (!stricmp(wrk,"AS")) {
				if (leaf->cmd.cid==C_FUNCTION) {
					if (rc=cl_get_def_attr_SSP_opt(line,line_len,&ssp,attr_sep,iParm,0x09,NULL,NULL)) return rc;
					if (iParm[0] != DEF_ZOK_VARI) {
#ifdef CMDOBJECT
						npr++;
#if 1	/* 20231203 */
						cl_im_expand(CLobjExp.ms_obj,iob+5,&obj);
#else
						cl_im_expand(CLcList.mcat_obj,iob+5,&obj);
#endif
						obj[iob++] = 4;
						memcpy(&obj[iob],iParm,sizeof(int)*4);
						iob += 4;
#endif
					}
					per_flg = 3;
				}
				else {
					/* %s: �߂�l�̑����́A�֐��ȊO�ł͎w��ł��܂���B */
					ERROROUT1(FORMAT(528),_fn_);
					return ECL_SCRIPT_ERROR;
				}
			}
			else if (per_flg == 2) {
				/* s: [%s]�̑O�ɂ`�r���K�v�ł��B */
				ERROROUT2(FORMAT(566),_fn_,wrk);
				return ECL_SCRIPT_ERROR;
			}
			else if (per_flg == 3) {
				/* %s: �]���ȕ���(%s)������܂��B */
				ERROROUT2(FORMAT(567),_fn_,wrk);
				return ECL_SCRIPT_ERROR;
			}
			else if (atr <= 6) {
				ipa++;
				if (ipa <= 2) {
					if (rc=_chk_var_name(wrk,len)) return rc;
				}
				else {
					/* %s: �]���ȕϐ�(%s)������܂��B */
					ERROROUT2(FORMAT(505),_fn_,wrk);
					return ECL_SCRIPT_ERROR;
				}
				if (ipa == 1) {
#ifdef CMDOBJECT
					npr++;
#if 1	/* 20231203 */
					cl_im_expand(CLobjExp.ms_obj,iob+1,&obj);
					cl_im_expand(CLobjExp.ms_da,ida,&da);
#else
					cl_im_expand(CLcList.mcat_obj,iob+1,&obj);
					cl_im_expand(CLcList.mcat_da,ida,&da);
#endif
					obj[iob++] = 1;
					obj[iob++] = ida;
					da[ida++] = clstrdup(wrk,0);
#endif
				}
				else if (ipa == 2) {
#ifdef CMDOBJECT
					npr++;
#if 1	/* 20231203 */
					cl_im_expand(CLobjExp.ms_obj,iob+1,&obj);
					cl_im_expand(CLobjExp.ms_da,ida,&da);
#else
					cl_im_expand(CLcList.mcat_obj,iob+1,&obj);
					cl_im_expand(CLcList.mcat_da,ida,&da);
#endif
					obj[iob++] = 2;
					obj[iob++] = ida;
					da[ida++] = clstrdup(wrk,0);
#endif
				}
			}
			else {
				if (c=='(') {
					per_flg = kk_level = 1;
					ipa = 0;
					is = ssp.sp;
#ifdef CMDOBJECT
#if 1	/* 20231203 */
					cl_im_expand(CLobjExp.ms_obj,iob,&obj);
#else
					cl_im_expand(CLcList.mcat_obj,iob,&obj);
#endif
					obj[iob++] = 3;
					inpa = iob++;
#endif
				}
				else if (c==')') {
					if (--kk_level < 0) break;
				}
				else if (c==',' && c0==',') {
					ipa++;
				}
			}
		}
	}
	if (!rc && kk_level) {
		/* %s: �V�X�e���E�G���[�A���ʂ̑Ή������Ă��܂���Bkk_level=%d */
		ERROROUT2(FORMAT(529),_fn_,kk_level);
		rc = ECL_SCRIPT_ERROR;
	}
#ifdef CMDOBJECT
	if (rc) return rc;
	obj[1] = npr;
/*
	for (i=0;i<iob;i++) printf("obj[%d]=%d\n",i,obj[i]);
	for (i=0;i<ida;i++) printf("da[%d]=[%s]\n",i,da[i]);
*/
	cmdobj->nobj = iob;
	cmdobj->nda = ida;
	cmdobj->exobj = (int *)clmemdup(obj,iob*sizeof(int),0);
	cmdobj->da = (char **)clmemdup(da,ida*sizeof(char *),0);
Exobj:
	return cl_pr_proc_engine(cmdobj,proc,iPNAME,iMAIN);
}

/************************************/
/*	_set_pointer_args				*/
/************************************/
static int _set_pointer_args(pInfoParmW)
tdtInfoParm *pInfoParmW;
{
	tdtArrayIndex tIndex,*pIndex;
	tdtInfoParm ***pTBL;
	tdtInfoParm *pInfo;
	int rc,*index,nm,i;
	char id,*name,buf[128];

	rc = 0;
	if ((id=pInfoParmW->pi_id)=='A' || id=='R') {
		name = (char *)pInfoParmW->pi_pos;
		pIndex = &tIndex;
		if ((rc=cl_get_array_index_tbl(pInfoParmW,pIndex,&pTBL,"_set_pointer_args")) < 0) return rc;
		index = tIndex.index;
		nm = index[2];
		for (i=0;i<nm;i++) {
			if ((rc=cl_array_get_info_parm(&pInfo,pIndex,pTBL,i+1,0)) < 0) break;
			if (pInfo->pi_id == 'S') {
				if (!(pInfo->pi_aux[1] & D_AUX1_POINTER)) {
					pInfo->pi_aux[1] |= D_AUX1_POINTER;
/*
printf("_set_pointer_args: set pointer flag i=%d\n",i);
*/
					pInfo->pi_aux[1] &= ~D_AUX1_PROTECTED;
					if (!pInfo->pi_paux) {
						sprintf(buf,"%s[%d]",name,i);
						pInfo->pi_paux = clstrdup(buf,D_OPT_ALC_SCR);
					}
				}
			}
DEBUGOUT_InfoParm(151,"%s: i=%d",pInfo,"_set_pointer_args",i);
		}
	}
	return rc;
}

/************************************/
/*	cl_pr_proc_engine				*/
/************************************/
int cl_pr_proc_engine(cmdobj,proc,iPNAME,iMAIN)
CMDObject *cmdobj;
ProcCT   *proc;
int iPNAME,iMAIN;
{
	static char *_fn_="cl_pr_proc_engine";
	int max_pas,*pSize,ix,rc,len,attr,attr0,iADDR,iPN,iABLE;
	int npr,iob,ida,ipr,ipa,npa,*obj,iParm[4],*jParm;
	char **da,buf[512],*name,*dflt,c,*wrk;
	tdtInfoParm ***tbl_pas,*pInfoParmC,*pInfoParmW,tInfoParm,*pInfoParmT,*pInfo;
	XHASHB *pha_vnm;
	tdtArrayIndex *pIndex;
	parmList *prmp[4],qprmp[4],pList;

	pha_vnm = proc->pha_vnam;
	max_pas = proc->varnam_pasento;
	tbl_pas = proc->pTBL_pasento;
	pSize = (int *)tbl_pas[0];

	obj = cmdobj->exobj;
	da = cmdobj->da;
	npr = obj[1];
	iob = 2;
	while (npr-- > 0) {
		ipr = obj[iob++];
DEBUGOUTL3(120,"%s: npr=%d ipr=%d",_fn_,npr,ipr);
		if (ipr == 1) {
			ida = obj[iob++];
			sprintf(buf,"%s = %d",da[ida],max_pas);
/*
printf("cl_process_proc: ipr=%d buf=[%s]\n",ipr,buf);
*/
			if (rc=cl_set_scalar_var_info(buf,NULL,
			        D_GX_OPT_SET_LOCAL,&pInfoParmW)) break;
		/*	        D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_CONST,&pInfoParmW)) break;	2022.6.24 */
			/* shift local �����Ƃ��ɁA�l���A������悤�ɁApInfoParmC��pi_data��
			   ����悤�ɂ���B */
			pInfoParmC = cl_var_size_parm(pSize);
			*pInfoParmW = *pInfoParmC;
			pInfoParmW->pi_scale &= ~D_DATA_LPOSDATA;
			pInfoParmW->pi_aux[0] = pInfoParmW->pi_attr;
			pInfoParmW->pi_aux[1]&= ~D_AUX1_PROTECTED;
		/*	pInfoParmW->pi_aux[1]|= D_AUX1_PROTECTED;	del 2022.6.24 */
			pInfoParmW->pi_paux   = pInfoParmW->pi_data;	/* ==pInfoParmC->pi_data */
		}
		else if (ipr == 2) {
			ida = obj[iob++];
			name = da[ida];
#if 1	/* 2024.7.15 */
/*
printf("cl_process_proc: name=[%s]\n",name);
*/
			if (*name == '*') {
				name++;
				iADDR = 1;
			}
			else iADDR = 0;
#endif
			if (!(ix=max_pas) || iMAIN) ix = pSize[2];
			sprintf(buf,"%%%s 1 %d",name,ix);
			memset(&qprmp[0],0,sizeof(parmList)*2);
			prmp[0] = &qprmp[0];
#if 1	/* 2021.5.5 */
			qprmp[0].prmlen = strlen(buf);
			qprmp[0].prp = buf;
			qprmp[0].opt = D_GX_OPT_NO_USE_OBJ;
			prmp[0] = &qprmp[0];
#else
			qprmp[1].prmlen = strlen(buf);
			qprmp[1].prp = buf;
			qprmp[1].opt = D_GX_OPT_NO_USE_OBJ;
			prmp[1] = &qprmp[1];
#endif
/*
printf("%s: ipr=%d buf=[%s]\n",_fn_,ipr,buf);
*/
#if 1	/* 2021.5.5 */
			if (rc=cl_pr_ex_def_map_ary(1,prmp,NULL,proc,D_GX_OPT_SET_LOCAL)) break;
#else
			if (rc=cl_pr_ex_def_map_ary(2,prmp,NULL,proc,D_GX_OPT_SET_LOCAL)) break;
#endif
/*
printf("%s: max_pas=%d iMAIN=%d\n",_fn_,max_pas,iMAIN);
*/
			if (!iMAIN) {
				strcpy(buf+1,name);
#if 1	/* 2021.6.14 */
				qprmp[0].prmlen = strlen(buf);
				if (rc=cl_conv_parm_opt(&qprmp[0],&tInfoParm,D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_ADDR)) break;
#else
				qprmp[1].prmlen = strlen(buf);
				if (rc=cl_conv_parm_opt(&qprmp[1],&tInfoParm,D_GX_OPT_SET_LOCAL|D_GX_OPT_SET_ADDR)) break;
#endif
DEBUGOUT_InfoParm(151,"%s:",&tInfoParm,_fn_,0);
				if (tInfoParm.pi_id == D_DATA_ID_STOREVAR) {
					if (pInfoParmW = (tdtInfoParm *)tInfoParm.pi_pos) {
						if (!max_pas) {
							if (pInfoParmW->pi_id=='A' && pInfoParmW->pi_dlen==sizeof(tdtArrayIndex)) {
								pIndex = (tdtArrayIndex *)pInfoParmW->pi_data;
/*
index = pIndex->index;
printf("cl_process_proc: index=%d %d %d %d %d %d\n",
index[0],index[1],index[2],index[3],index[4],index[5]);
*/
								pIndex->index[4] = 0;
							}
						}
#if 1	/* 2024.7.15 */
						else if (iADDR) {
							_set_pointer_args(pInfoParmW);
						}
#endif
					}
				}
			}
		}
		else if (ipr == 3) {
			if (iPNAME) {
				if (rc=_chk_pname(iob,obj,da,max_pas,tbl_pas)) return rc;
			}
			npa = obj[iob++];
			iPN = 1;
			while (npa-- > 0) {
				ipa = obj[iob++];
				ida = obj[iob++];
				name = da[ida++];
				dflt = da[ida];
/*
printf("cl_process_proc: ida=%d dflt=[%s]\n",ida,dflt);
*/
#if 1	/* 2024.7.6 */
				if (*name == '*') {
					name++;
					iADDR = 1;
				}
				else iADDR = 0;
#endif
				if ((c=*name)=='$' || c=='%' || c=='#') name++;
				len = strlen(name);
				if ((ix=cl_gx_chk_vnam_info('s',pha_vnm,name,len,&pInfoParmW)) <= 0) {
					/* %s: %s�̃G���g���p�̋󂫂�����܂���Brc=%d */
					ERROROUT3(FORMAT(502),_fn_,name,ix);
					return ECL_SCRIPT_ERROR;
				}
			/*	pInfoParmW = cl_get_var_ent(tbl_vnm,ix);	*/
#if 1	/* 2023.4.21 */
				memcpy(iParm,&obj[iob],sizeof(int)*4);
/*
printf("%s: iParm=%08x %d %d %d iob=%d\n",_fn_,iParm[0],iParm[1],iParm[2],iParm[3],iob);
*/
				attr0 = iParm[0];
				attr = attr0 & DEF_ZOK_MASK;
				iParm[0] &= 0xff;
/*
printf("%s: npa=%d iParm[0]=%08x attr=%d\n",_fn_,npa,iParm[0],attr);
*/
				if (attr && attr!=DEF_ZOK_VARI) {
					if (rc=cl_set_parm_init(pInfoParmW,iParm,0x01)) {
						/* %s: �������̑����w��(attr=%d size=%d precision=%d scale=%d)���s���ł��B */
						ERROROUT5(FORMAT(530),_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);
						return ECL_SCRIPT_ERROR;
					}
				}
#else
				jParm = &obj[iob];
				if (jParm[0] && jParm[0]!=DEF_ZOK_VARI) {
					if (rc=cl_set_parm_init(pInfoParmW,jParm,0x01)) {
						/* %s: �������̑����w��(attr=%d size=%d precision=%d scale=%d)���s���ł��B */
						ERROROUT5(FORMAT(530),_fn_,jParm[0],jParm[1],jParm[2],jParm[3]);
						return ECL_SCRIPT_ERROR;
					}
				}
#endif
				iob += 4;
				if (iPNAME) {
					pInfoParmC = _get_pname_var_ent(name,max_pas,tbl_pas,NULL);
					if (!pInfoParmC) pInfoParmC = _get_pname_var_ent(NULL,max_pas,tbl_pas,&iPN);
				}
				else {
					pInfoParmC = cl_get_var_ent(tbl_pas,ipa);
				}
DEBUGOUT_InfoParm(151,"%s:C: ipr=%d",pInfoParmC,_fn_,ipa);
				if (!pInfoParmC) {
					/* "%s: �����̐ݒ肪����Ă��܂��Bipa=%d" */
					ERROROUT2(FORMAT(510),_fn_,ipa);
					return ECL_SCRIPT_ERROR;
				}
				if (cl_is_undef_parm(pInfoParmC)) {
					if (dflt) {
						pList.prp = dflt;
						pList.prmlen = strlen(dflt);
						pList.opt = 0;
						if ((rc=cl_conv_arg(&pList,pInfoParmC)) < 0) return rc;
						rc = 0;
					}
#if 1	/* 2024.7.10 */
					else {
						cl_null_parm(pInfoParmC);
						if (iADDR) {
							if (!(pInfoParmT=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm)))) return ECL_MALLOC_ERROR;
							cl_set_parm_long(pInfoParmT,(long)pInfoParmC);
							pInfoParmT->pi_id = D_DATA_ID_STOREVAR;
							pInfoParmC = pInfoParmT;
						}
					}
#else
					else cl_null_parm(pInfoParmC);
#endif
				}
#if 1	/* 2024.7.6 */
				if (pInfoParmC->pi_id == 'S') {
					if (iADDR) {
						if (!(pInfoParmC->pi_aux[1] & D_AUX1_POINTER) &&
						    !(pInfoParmW->pi_aux[0] & ~DEF_ZOK_DATA)) {
							pInfoParmC->pi_aux[1] |= D_AUX1_POINTER;
/*
printf("%s: set pointer flag\n",_fn_);
*/
							if (!pInfoParmC->pi_paux) pInfoParmC->pi_paux = clstrdup(name,D_OPT_ALC_SCR);
						}
					}
					else {
						if (!(pInfoParmC->pi_aux[1] & D_AUX1_POINTER)) {
							pInfoParmC = (tdtInfoParm *)pInfoParmC->pi_pos;
/*
printf("%s: get store var\n",_fn_);
*/
						}
					}
				}
				else if (iADDR) {
					/* %s: %s��'%s'�͎w��ł��܂���B */
					ERROROUT3(FORMAT(140),"cl_process_proc:(W)",name,"*");
				}
#endif
#if 1	/* 2023.8.24 */
				if ((c=pInfoParmC->pi_id)!=' ' && iParm[0]) {
					ERROROUT3(FORMAT(663),_fn_,name,cl_get_variable_type(c));
					return ECL_SCRIPT_ERROR;
				}
#endif
#if 1	/* 2023.4.23 */
#if 1	/* 2023.8.23 */
				if (pInfoParmC->pi_id == ' ') {
#else
				if (pInfoParmW->pi_id == ' ') {
#endif
					if (cl_gx_rep_info_als(pInfoParmW,pInfoParmC,D_REP_OPT_DEF_ONLY|1)) {
						return ECL_SCRIPT_ERROR;
					}
					pInfo = pInfoParmW;
				}
				else {
					cl_gx_copy_info(pInfoParmW,pInfoParmC);
#if 0	/* 2024.7.14 S�`���̃X�J���[�ϐ��̂Ƃ��́A�������̃A�h���X�������Ă���̂ŁA�ύX�ł��Ȃ� */
					pInfo = pInfoParmW;
					if (pInfo->pi_id=='S') {
						pInfo = (tdtInfoParm *)pInfo->pi_pos;
						if (pInfo->pi_id != ' ') pInfo->pi_scale &= ~D_DATA_MALLOC;
					else pInfo->pi_scale &= ~D_DATA_MALLOC;
#endif
				/*	pInfoParmW->pi_aux[0] &= ~D_AUX0_ZOK_DATA;	*/
				}
#if 1	/* 2024.7.14 S�`���ŁA��ʕϐ��̂Ƃ��́A�������̃A�h���X�������Ă���̂ŁA�ύX�ł��Ȃ� */
				iABLE = 1;
				pInfo = pInfoParmW;
				if (pInfo->pi_id == 'S') {
					pInfo = (tdtInfoParm *)pInfo->pi_pos;
					if (pInfo->pi_id == ' ') iABLE = 0;
				}
				if (iABLE) {
					pInfo->pi_aux[0] &= ~D_AUX0_ZOK_DATA;
					if (attr0 & D_GX_OPT_SET_CONST)
						pInfo->pi_aux[1] |= D_AUX1_PROTECTED;
					else
						pInfo->pi_aux[1] &= ~D_AUX1_PROTECTED;
				}
#if 1	/* 2024.10.17 */
				if (instrchar("ARLNTPF",pInfo->pi_id) > 0) {	/* 2025.4.28 add F */
					pInfo->pi_scale &= ~(D_DATA_INDEX_FREE | D_DATA_MALLOC);
				}
#endif
#else
				if (attr0 & D_GX_OPT_SET_CONST)
					pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;
				pInfoParmW->pi_aux[0] &= ~D_AUX0_ZOK_DATA;
#endif
#else
#if 1	/* 2022.9.19 */
				cl_gx_copy_info(pInfoParmW,pInfoParmC);
				pInfoParmW->pi_scale &= ~D_DATA_MALLOC;
				pInfoParmW->pi_aux[0] &= ~D_AUX0_ZOK_DATA;
#else
				/* 2021.10.27 */
				if (cl_gx_rep_info_als(pInfoParmW,pInfoParmC,D_REP_OPT_DEF_ONLY/*|1*/)) {
					return ECL_SCRIPT_ERROR;
				}
#endif
#endif
DEBUGOUT_InfoParm(194,"%s:W: name=%s",pInfoParmW,_fn_,wrk);
			}
		}
		else if (ipr == 4) {
			pInfoParmC = proc->Retval;
			jParm = &obj[iob];
			if (rc=cl_set_parm_init(pInfoParmC,jParm,D_GX_OPT_ALC_TMP | 0x01)) {
				/* %s: �ԋp�l�̑����w��(attr=%d size=%d precision=%d scale=%d)���s���ł��B */
				ERROROUT5(FORMAT(499),_fn_,jParm[0],jParm[1],jParm[2],jParm[3]);
				return ECL_SCRIPT_ERROR;
			}
			iob += 4;
		}
	}
#endif
	return rc;
}

/************************************/
/* cl_process_end_proc              */
/* function; check command of this  */
/*          leaf then call functions*/
/************************************/
int cl_process_end_proc(leaf, proc)
Leaf    *leaf;
ProcCT  *proc;
{
	char *name;
	int cmnd;

	if (leaf == NULL) return(ECL_SYSTEM_ERROR);
	if (proc == NULL) return(ECL_SYSTEM_ERROR);
/*
printf("cl_process_end_proc: proc=%08x name[%s]\n",proc,proc->ProcNM);
*/
	if (!(proc->pr_pFlag & D_PFLAG_CONSTRUCT)) {
		if ((cmnd=leaf->cmd.cid) == C_ENDPROC) name = FORMAT(506);	/* �d�m�c�o�q�n�b */
		else if (cmnd == C_ENDFUNC) name = FORMAT(507);	/* �d�m�c�e�t�m�b */
		else name=NULL;
				/* %s: %s���ɒB���܂����B�q�d�s�t�q�m���܂��B */
		if (name) ERROROUT2(FORMAT(508),"cl_process_end_proc",name);
	}
	cmn_set_stat(RET_PR,&proc->ptype,L_ON);
	return 0;
}
