static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �O���[�v�m�[�h�t�B���h�t���[����������                 *
*                                                                             *
*      �֐����@�@�@�F�@int cl_rp_grp_nfrm_gen( pGNCB , pBuff , len )          *
*                                                                             *
*      ������      �F�@(I) GrpNodeCB   *pGNCB                                 *
*                    �@(I) char        *pBuff                                 *
*                    �@(I) int         *len                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern CLPRTBL *pCLprocTable;

int cl_rp_grp_nfrm_gen(pLeaf,proc)
Leaf  *pLeaf;
ProcCT  *proc;
{
	int rc,i,FieldNo,TapleNo,Datanum;
	int nparm;
	char   wBuff[20];
	cmdInfo   *pwcmd;
	MCAT *mcat;
	parmList  **prm;
	tdtObjHead *pObj;

	if (!pLeaf) return( ERROR );
	pwcmd = &(pLeaf->cmd);
	nparm = pwcmd->prmnum;
	prm = pwcmd->prmp;
	pObj = proc->Obj;
	if (nparm < 4) {
		ERROROUT("Parameter is few!! (GR fn tn n F1 F2 ... Fn)");
		return ECL_EX_OUTPUT;
	}
	/* �t�B�[���h�ԍ��̃Z�b�g     */
	if (rc = cl_ot_conv_arg(prm[1],pObj,&FieldNo)) return( rc );
	/* �^�v���ԍ��̃Z�b�g         */
	if (rc = cl_ot_conv_arg(prm[2],pObj,&TapleNo)) return( rc );
	/* �f�[�^�t�B�[���h���̃Z�b�g */
	if (rc = cl_ot_conv_arg(prm[3],pObj,&Datanum)) return( rc );

	if ( nparm - 4 != Datanum ) {
		ERROROUT(FORMAT(371));		/* �t�B�[���h�̐�������Ȃ��B */
		return( ECL_EX_OUTPUT );
	}

	if (rc=cl_make_list_pbody()) return rc;
	mcat = &pCLprocTable->ListPBody->mCat;

	sprintf( wBuff ,"GR%-5d%-5d%-5d" ,  FieldNo, TapleNo, Datanum );
	if ((rc=axtmcats(mcat, wBuff))<0) return rc;

	for (i = 0 ; i < Datanum ; i++ ) {
		if (rc=cl_ot_conv_arg(prm[i+4],pObj,&FieldNo)) return( rc );
		sprintf( wBuff , "%-5d" , FieldNo);
		if ((rc=axtmcat(mcat, wBuff, 5))<0) return rc;
	}

	return NORMAL;
}

