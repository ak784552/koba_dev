static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************/
/*																		*/
/*	�����ړI	�F �d�k�r�d�R�}���h���C��								*/
/*																		*/
/*	�֐���		�F int cl_process_else(pLeaf, pProc)					*/
/*																		*/
/*	������		�F (I)Leaf		: * pLeaf								*/
/*				   (I)ProcCT	: * pProc								*/
/*																		*/
/*	�߂�l		�F ERROR												*/
/*				   NORMAL												*/
/*																		*/
/*	�����T�v	�F														*/
/*																		*/
/************************************************************************/

#include "colmn.h"
#define NEORET

extern GlobalCt *pGlobTable;

int cl_process_else(pLeaf, pProc)
Leaf   *pLeaf;
ProcCT *pProc;
{
	int rc;
	char buf[32];
	int id;
	BlockCB *pIfCB;
	BlockCB *pBlockCB;

	if (!(pIfCB = pProc->pcrBlockCB)) return -1;
	id = pIfCB->cid;
	if (id==C_IF || id==C_SWITCH || id==C_TRY) ;
	else return -1;

	if( pIfCB->ElseFlag == L_ON ) {
		if (cl_get_cmd_name(pLeaf->cmd.cid,buf)) return -2;
		ERROROUT1(FORMAT(366),buf);	/* %s���d�����Ă��܂��B */
		return ECL_EX_ELSE;
	}

	/* �d�k�r�d�R�}���h�t���O���I�� */
	pIfCB->ElseFlag = L_ON;

	/* 2017.03.18 */
	id = pLeaf->cmd.cid;
	if (id==C_DEFAULT && pIfCB->TureFlag==L_ON) {
		if (pIfCB->iLoopMax != C_BREAK) {
			pIfCB->Blockleaf = pLeaf->rightleaf;	/* Add 2021.6.27 */
			pProc->Nextleaf = pLeaf->leftleaf;
			cl_ret_leaf_push(pProc,pLeaf->rightleaf);
		}
		else
			pProc->Nextleaf = pLeaf->rightleaf;
	}
	else if (id==C_FINALLY || (id==C_ELSE && pIfCB->TureFlag!=L_ON)) {
		pIfCB->iUsed = D_SWITCH_DEFAULT;	/* Add 2017.3.25 */
		pIfCB->Blockleaf = pLeaf->rightleaf;	/* Add 2017.3.25 */
		pProc->Nextleaf = pLeaf->leftleaf;
		cl_ret_leaf_push(pProc,pLeaf->rightleaf);
#if 0	/* 2021.3.19 */
		/* Catch���ꂽ�Ƃ��́A�G���[���b�Z�[�W���N���A���� */
		if (id==C_FINALLY && !pGlobTable->exception) {
			pGlobTable->err_hist[0].parlen = 0;
			pGlobTable->err_hist[1].parlen = 0;
			*pGlobTable->errmsg = '\0';
		}
#endif
	}
	else {
		pProc->Nextleaf = pLeaf->rightleaf;
	}

	return 0;
}
