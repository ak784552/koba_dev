static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  Binominal EXPression �R�}���h         �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_bexp( pLeaf )                           *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern int giOptions[];
extern CLPRTBL  *pGLprocTable;
extern CLPRTBL  *pCLprocTable;
extern GlobalCt *pGlobTable,GlobTable;
extern CLCOMMON CLcommon;
extern char cmp_sep2[];

static int let_shift();
static int LETGlobal();
static int let_exit();
static int LETDefine();
static int let_log_parm();
/*static int LETConst();*/
static int LETTypeVar();

#if 1	/* 2023.9.30 */
/****************************************/
/*										*/
/****************************************/
int cl_proc_bexp(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
{
	static  char *_fn_="cl_proc_bexp";
	cmdInfo cmd;
	ParList parl;
	parmList *pprmp[6],prmp2[6],**parmp;
	int i,rc,prmnum;

	if (!pLeaf) {							/* �����N�`�F�b�N			*/
		ERROROUT("Link ERROR");
		return ECL_SYSTEM_ERROR;
	}
	if (pLeaf->cmd.cid != C_BEXP ) {		/* �R�}���h�h�c�`�F�b�N		*/
		ERROROUT("Command ID error !!");
		return ECL_SYSTEM_ERROR;
	}

	prmnum = pLeaf->cmd.prmnum;
	parmp = pLeaf->cmd.prmp;

	memset(prmp2,0,sizeof(prmp2));
	for (i=0;i<6;i++) pprmp[i] = &prmp2[i];
	cmd.prmp = pprmp;
	cmd.prmnum = 6;
	cmd.parl = &parl;
	if ((rc=cl_print_check_do(&cmd,parmp,prmnum)) > 0) {
/*
printf("%s: rc=%d\n",_fn_,rc);
*/
		pLeaf->cmd.prmnum = rc - 1;
		rc = cl_proc_bexp_do(pLeaf,proc,&cmd);
	}
	else if (!rc) {
		rc = cl_proc_bexp_sub(pLeaf,proc,&cmd);
	}
	pLeaf->cmd.prmnum = prmnum;
	return rc;
}

/********************************************/
/*											*/
/********************************************/
int cl_proc_bexp_do(pLeaf,proc,cmd)
Leaf *pLeaf;
ProcCT  *proc;
cmdInfo *cmd;
{
	BlockCB tLoopCB,*pcrLCB;
	ParList *parl;
	char *line;
	int i,rc,loop_max,count,line_len;

	parl = cmd->parl;
	pcrLCB = &tLoopCB;
	line = parl->par;
	line_len = parl->parlen;
	if ((rc=cl_get_loop_ctl(cmd,pcrLCB,proc->Obj,line,line_len)) >= 0) {
		rc = 0;
		for (;;) {
			if ((loop_max=cl_get_loop_max(NULL)) < 0) break;
			count = pcrLCB->iLoopCounter;
/*
printf("cl_print_echo_text_do: count=%d loop_max=%d\n",count,loop_max);
*/
			if (count<loop_max && count < pcrLCB->iLoopMax) {
				if ((rc=_exec_for(cmd,proc->Obj,pcrLCB)) <= 0) break;
				else if ((rc=cl_proc_bexp_sub(pLeaf,proc)) < 0) break;
			}
			else break;
			pcrLCB->iLoopCounter++;
		}
	}
	return rc;
}

/****************************************/
/*	BEXP a = b + c [+ d ...]			*/
/*	BEXP a = b SBSTR c d				*/
/****************************************/
int cl_proc_bexp_sub(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
#else
int cl_proc_bexp(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
#endif
{
	int rc,prmnum,iLET,len;
	char *p;
	parmList **parmp;

	if (!pLeaf) {							/* �����N�`�F�b�N			*/
		ERROROUT("Link ERROR");
		return ECL_SYSTEM_ERROR;
	}
	if (pLeaf->cmd.cid != C_BEXP ) {		/* �R�}���h�h�c�`�F�b�N		*/
		ERROROUT("Command ID error !!");
		return ECL_SYSTEM_ERROR;
	}
											/* �p�����[�^���`�F�b�N	*/
#if 0
	/* ���d�l�̈ȉ����ʂ�Ȃ��̂ŕύX�ł��Ȃ�
	   BEXP $432 = '//null/'%q''; */
	if (pLeaf->cmd.prmnum <= 5) return let_compute(pLeaf,proc);
#endif
#if 1	/* 2023.9.30 */
	iLET = 0;
	prmnum = pLeaf->cmd.prmnum;
	parmp = pLeaf->cmd.prmp;
/*
printf("cl_proc_bexp_sub: prmnum=%d\n",prmnum);
printf("cl_proc_bexp_sub: parmp[0]:len=%d p=[%s]\n",parmp[0]->prmlen,parmp[0]->prp);
*/
	if (inmemstr(parmp[0]->prp,parmp[0]->prmlen,"=") > 0) iLET = 1;
	else if (prmnum<3 || prmnum==4) iLET = 1;
	else if (prmnum >= 3) {
		p = parmp[1]->prp;
/*
printf("cl_proc_bexp_sub: parmp[1]->prp=[%s]\n",p);
*/
		if (*(p+parmp[1]->prmlen-1) != '=') iLET = 1;
		else if (prmnum > 5) {
			p = parmp[5]->prp;
			len = parmp[5]->prmlen;
/*
printf("cl_proc_bexp_sub: len=%d p=[%s]\n",len,p);
*/
			if (*p == '\'') ;
			else if (inmemchars(p,len,"+-*/&|%=^!<>,?:")>0 ||
			         !memincmp(p,len,"AND",3) ||
			         !memincmp(p,len,"OR",2) ||
			         !memincmp(p,len,"NOT",3)) iLET = 1;
		}
	}
/*
printf("cl_proc_bexp_sub: iLET=%d\n",iLET);
*/
	if (iLET) return let_compute(pLeaf,proc);
#else
	if (pLeaf->cmd.prmnum<3 || pLeaf->cmd.prmnum==4) {
		ERROROUT("Parameter error !!");
		return ECL_SCRIPT_ERROR;
	}
	p = pLeaf->cmd.prmp[1]->prp;
	if (*(p+pLeaf->cmd.prmp[1]->prmlen-1) != '=') {
		/* cl_proc_bexp: ���Z�q[%s]��'='�ł͂���܂���B */
		ERROROUT1(FORMAT(344),p);
		return ECL_SCRIPT_ERROR;
	}
#endif
	rc = cl_gx_compute(pLeaf,proc);

	return rc;
}

/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  LET                  �R�}���h         �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_let ( pLeaf )                           *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
int cl_process_let(pLeaf, proc)
Leaf   *pLeaf;
ProcCT *proc;
{
	int	rc,func,nparm,ioplen,scno,opt,*obj,iParm[8],line_len,len;
	char w[2],*pOperator,*cmnd,wrk[256],*line;
	parmList *pparm2,**pprmp;
	ScrPrCT *scrct;
	CMDObject *cmdobj;
	SSPL_S ssp;
	tdtInfoParm tInfoParm;
	tdtStackObj *pSO;

	if (!pLeaf) {
		ERROROUT("Link ERROR");
		return( ECL_SYSTEM_ERROR );
	}
	nparm = pLeaf->cmd.prmnum;
	pprmp = pLeaf->cmd.prmp;
											/* �p�����[�^���`�F�b�N	*/
	if (nparm < 1) {
		ERROROUT("Parameter too few !!");
		return( ECL_SCRIPT_ERROR );
	}

	cmn_set_stat(FUN_PR,&proc->pr_pFlag2,L_OFF);

	scrct = cl_search_src_ct();
	opt = 0;

	if (scno=pLeaf->cmd.sub_cid) {
/*
printf("cl_process_let: scno=%d\n",scno);
*/
		switch (scno) {
		case CS_OPTIONS:
				return let_options(nparm,pprmp,proc->Obj);
		case CS_OPTION:
				return let_option(nparm,pprmp,proc->Obj);
		case CS_SHIFT:
				return let_shift(nparm,pprmp,proc,pparm2);
		case CS_BREAK:
				return cl_pr_break(pLeaf,proc,1);
		case CS_CONTINUE:
				return let_continue(pLeaf,proc);
		case CS_LPRINT:
		case CS_PRINT:
		case CS_ECHO:
				return let_print_echo(pLeaf,proc,scno);
		case CS_DUMP:
				return let_dump(pLeaf,proc,scno);
		case CS_LPRINTF:
		case CS_PRINTF:
				return let_printf(pLeaf,proc,scno);
		case CS_TRY_EXIT:
				nparm = -1;
		case CS_EXIT:
				return let_exit(nparm,pprmp,proc->Obj);
		case CS_INTERACTIVE:
				return cl_process_interactive(pLeaf,proc);
		case CS_LOGPARM:
				return let_log_parm(nparm,pprmp,proc->Obj);
		case CS_GOTO:
				return let_goto(pLeaf,proc);
		case CS_GLOBAL:
		case CS_PUBLIC:
		case CS_PRIVATE:
		case CS_LOCAL:
		case CS_CONST:
		case CS_COMPLEX:
		case CS_EXPORT:
		case CS_STATIC:
		case CS_ATTR:
				opt = 1;
		case CS_MAPPEDARRAY:
		case CS_ARRAY:
				cmdobj = pLeaf->cmd.cmdobj;
				rc = cl_pr_ex_def_array(cmdobj,nparm,pprmp,scrct,proc,opt);
/*
printf("cl_process_let: rc=%d\n",rc);
*/
				if (rc != C_EX_DEF_SCALAR) return rc;
				break;
#if 1	/* 2023.2.25 *//* ���̋@�\�͕s�v������������������̂Ŏc���Ă��� */
		case CS_DEFINE:
		case CS_SCALAR:
/*
printf("cl_process_let: nparm=%d prp=[%s]\n",nparm,pprmp[0]->prp);
*/
				cmdobj = pLeaf->cmd.cmdobj;
			/*	opt |= D_GX_OPT_DEFINE;	*/
				rc = cl_pr_ex_def_array(cmdobj,nparm,pprmp,scrct,proc,opt);
				if (rc != C_EX_DEF_SCALAR) return rc;
				break;
#endif
	/*
		case CS_MAPPEDARRAY:
				return cl_pr_ex_def_map_ary(nparm,pprmp,scrct,proc,0);
	*/
		case CS_TYPE:
				return cl_pr_ex_def_type(nparm,pprmp,scrct,proc,0);
		case CS_VAR:
				cmdobj = pLeaf->cmd.cmdobj;
				return cl_pr_ex_def_var(cmdobj,nparm-1,pprmp+1,scrct,proc,0);
#if 1	/* 2023.8.1 */
		case CS_IMPLICIT:
				return cl_pr_ex_def_implicit(nparm-1,pprmp+1,scrct,proc,0);
#endif
		}
	}
	else {
		ssp.sp = 0;
		ssp.wd = wrk;
		ssp.wdmax = sizeof(wrk);
		line = pprmp[0]->prp;
		line_len = pprmp[0]->prmlen;
		if (akxtgwnsl(line,line_len,&ssp,cmp_sep2,0x841) > 0) {
			if (ssp.attr[0] == 1) {
				if (akxtgwnsl(line,line_len,&ssp,cmp_sep2,0x841) > 0) {
					if (ssp.attr[0] == 1) {
						ssp.sp = 0;
						mem_set_int(iParm,0,8);
						if ((rc=cl_get_def_type(line,line_len,&ssp,0,proc,NULL,0,iParm,&tInfoParm)) > 0) {
							cmdobj = pLeaf->cmd.cmdobj;
							iParm[6] = ssp.sp;
							iParm[7] = rc;
/*
printf("cl_process_let: ssp.sp=%d\n",ssp.sp);
*/
							rc = cl_pr_ex_def_array_parm(cmdobj,nparm,pprmp,scrct,proc,1,iParm);
/*
printf("cl_process_let: rc=%d\n",rc);
*/
							if (rc != C_EX_DEF_SCALAR) return rc;
						}
					}
				}
			}
		}
	}
/*
printf("cl_process_let: scno=%d nparm=%d p=[%s]\n",scno,nparm,pprmp[0]->prp);
*/
	cmn_set_stat(FUN_PR,&proc->pr_pFlag2,L_ON);/* ���݂̂̃R�}���h�̎����s */
DEBUGOUTL2(105,"cl_process_let:1 proc=%08x proc->pr_pFlag2=%02x",proc,proc->pr_pFlag2);
#if 1	/* 2024.5.7 */
	rc = let_compute_info(pLeaf,proc,D_GX_OPT_ALC_FUN_PR,NULL);
#else
	rc = let_compute(pLeaf,proc);
#endif
#if 1	/* 2024.8.25 */
	/* proc->ptype��FUN_PR��OFF�̂Ƃ��́A�֐������s����Ȃ������Ƃ������ƂȂ̂ŁA
	   proc->pr_pFlag2��FUN_PR��OFF����B
	   OFF�ɂ��Ȃ��ƁA���݂̂łȂ��֐����s��proc->ptype��FUN_PR��ON�ɂȂ�Acl_process_let_return()��
	   ���s����Ȃ����߁Aproc->ptype��FUN_PR��ON�̂܂܂ƂȂ�A���ʂƂ��ē���leaf�����s����Ă��܂� */
	if (!cmn_chk_stat(FUN_PR,&proc->ptype)) 
		cmn_set_stat(FUN_PR,&proc->pr_pFlag2,L_OFF);
	else 
#endif
	if (pSO = proc->pStackObj) {
/*
printf("cl_process_let: iva[10]=%d\n",pSO->so_iva[10]);
*/
		if (rc<0 || pSO->so_iva[10]==99) {
			cmn_set_stat(FUN_PR,&proc->ptype,L_OFF);
			cmn_set_stat(FUN_PR,&proc->pr_pFlag2,L_OFF);
		}
	}

DEBUGOUTL2(105,"cl_process_let:2 proc=%08x proc->pr_pFlag2=%02x",proc,proc->pr_pFlag2);

	return rc;
}

/********************************/
/*								*/
/********************************/
static int let_shift(nparm,pprmp,proc,pparmList)
int        nparm;
parmList **pprmp;
ProcCT    *proc;
parmList  *pparmList;
{
	ScrPrCT     *pScCT;
	VarTBL      *VaryC;
	tdtInfoParm   ***tbl_pas,*p,*p1,tInfoParm,*pInfoParm;
	int i,n,*pSize,*count,iLOCAL,rc;

DEBUGOUTL1(110,"let_shift:Ente nparm=%d",nparm);
	iLOCAL = 0;
	pInfoParm = NULL;
	for (i=1;i<nparm;i++) {
		if (!stricmp(pprmp[i]->prp,"LOCAL")) iLOCAL = 1;
		else {
			pInfoParm = &tInfoParm;
			if ((rc=cl_conv_arg_opt(pprmp[i],pInfoParm,0)) < 0) return rc;
		}
	}
	if (iLOCAL) {
		tbl_pas = proc->pTBL_pasento;
		count = &proc->varnam_pasento;
	}
	else {
		pScCT = cl_search_src_ct();
		VaryC = pScCT->Vary;
		tbl_pas = VaryC->pTBL_pasento;
		count = &VaryC->varnam_pasento;
	}
	n = *count;
DEBUGOUTL1(110,"let_shift: n=%d",n);
	if (n > 0) {
		p = NULL;
		for (i=1;i<=n;i++) {
			p1 = cl_get_var_ent(tbl_pas,i);
DEBUGOUT_InfoParm(198,"let_shift:p1B i=%d",p1,i,0);
/*
printf("let_shift: i=%d p1=%08x data=%08x\n",i,p1,p1->pi_data);
*/
			p  = cl_get_var_ent(tbl_pas,i+1);
DEBUGOUT_InfoParm(198,"let_shift:p B i+1=%d",p,i+1,0);
/*
printf("let_shift: i+1=%d p=%08x data=%08x\n",i+1,p,p->pi_data);
*/
#if 1	/* 2021.10.27 */
			cl_gx_copy_info(p1,p);
#else
			if (rc=cl_gx_rep_info_set(p1,p,0)) return rc;
#endif
DEBUGOUT_InfoParm(198,"let_shift:p1A i=%d",p1,i,0);
			if (i<n && p) cl_parm_set0(p);
		}
		if (p1 && p1->pi_id=='\0') cl_null_parm(p1);
		if (n==1 && pInfoParm) {
#if 1	/* 2021.10.27 */
			cl_gx_copy_info(p1,pInfoParm);
#else
			if (rc=cl_gx_rep_info_set(p1,pInfoParm,1)) return rc;
#endif
		}
		*count = --n;
		pSize = (int *)tbl_pas[0];
		cl_set_parm_bin(cl_var_size_parm(pSize),n);
	}

	return 0;
}

/********************************/
/*								*/
/********************************/
int cl_set_scalar_var_info(str,bxobj,opt,ppInfoParm)
char      *str;
GXObject  *bxobj[];
int       opt;
tdtInfoParm **ppInfoParm;
{
	parmList *prmp[2],qprmp[2];
	int      rc,iParm[4];
	ScrPrCT  *scrct=NULL;
	ProcCT   *proc=NULL;

	proc = cl_search_proc_ct();
	if (opt & D_GX_OPT_SET_LOCAL) {
		if (!proc) return -1;
		if (cl_mk_pr_var_set(proc)) return -1;
	}
	else {
		scrct = cl_search_src_ct();
	}
	memset(qprmp,0,sizeof(qprmp));
	qprmp[0].prmlen = strlen(str);
	qprmp[0].prp = str;
	qprmp[0].opt = 0;
	qprmp[0].bxobj = NULL;
	prmp[0] = &qprmp[0];
	prmp[1] = &qprmp[1];
	if (bxobj) {
		qprmp[1].bxobj = bxobj[0];
	}
	else qprmp[0].opt = D_GX_OPT_NO_USE_OBJ;
	mem_set_int(iParm,0,4);
	iParm[0] = DEF_ZOK_VARI;
	rc = cl_pr_ex_def_scalar_attr_info(0,prmp,scrct,proc,opt,iParm,ppInfoParm);
	if (bxobj) bxobj[0] = qprmp[1].bxobj;
	return rc;
}

/********************************/
/*								*/
/********************************/
int cl_set_var(str,bxobj,opt,ppInfoParm)
char *str;
GXObject  *bxobj[];
int opt;
tdtInfoParm **ppInfoParm;
{
	return cl_set_scalar_var_info(str,bxobj,opt,ppInfoParm);
}

/********************************/
/*								*/
/********************************/
int cl_set_global_var(str,bxobj)
char *str;
GXObject  *bxobj[];
{
	return cl_set_var(str,bxobj,D_GX_OPT_SET_GLOBAL,NULL);
}

/********************************/
/*								*/
/********************************/
int cl_set_public_var(str,bxobj)
char *str;
GXObject  *bxobj[];
{
	return cl_set_var(str,bxobj,D_GX_OPT_SET_PUBLIC,NULL);
/*	return cl_set_scalar_var_info(str,bxobj,D_GX_OPT_SET_PUBLIC,NULL);	*/
}

/********************************/
/*								*/
/********************************/
int cl_set_global_var_info(str,bxobj,ppInfoParm)
char *str;
GXObject  *bxobj[];
tdtInfoParm **ppInfoParm;
{
	return cl_set_var(str,bxobj,D_GX_OPT_SET_GLOBAL,ppInfoParm);
}

/********************************/
/*								*/
/********************************/
int cl_set_public_var_info(str,bxobj,ppInfoParm)
char *str;
GXObject  *bxobj[];
tdtInfoParm **ppInfoParm;
{
	return cl_set_var(str,bxobj,D_GX_OPT_SET_PUBLIC,ppInfoParm);
}

/********************************/
/*								*/
/********************************/
tdtInfoParm *cl_get_var(varnam,opt)
char *varnam;
int opt;
{
	int i,vnlen;
	tdtInfoParm *pInfo;
	XHASHB *pha_vname;
	tdtInfoParm ***pTBL_vname;
	ScrPrCT *scrct;
	ProcCT  *proc;

	pInfo = NULL;
	pha_vname = NULL;
	if (opt & D_GX_OPT_SET_GLOBAL) {
		pha_vname  = pGLprocTable->pha_vnam;
	/*	pTBL_vname = pGLprocTable->pTBL_vnam;	*/
	}
	else if (opt & D_GX_OPT_SET_PUBLIC) {
		pha_vname  = pCLprocTable->pha_vnam;
	/*	pTBL_vname = pCLprocTable->pTBL_vnam;	*/
	}
	else if (opt & D_GX_OPT_SET_PRIVATE) {
		if (scrct = cl_search_src_ct()) {
			pha_vname  = scrct->Vary->pha_vnam;
		/*	pTBL_vname = scrct->Vary->pTBL_vnam;	*/
		}
	}
	else if (opt & D_GX_OPT_SET_LOCAL) {
		if (proc = cl_search_proc_ct()) {
			pha_vname  = proc->pha_vnam;
		/*	pTBL_vname = proc->pTBL_vnam;	*/
		}
	}
	if (pha_vname) {
	/*	if ((i=cl_gx_chk_vnam('r',pha_vname,varnam, strlen(varnam))) >= 1)
			pInfo = cl_get_var_ent(pTBL_vname,i);	*/
		i = cl_gx_chk_vnam_info('r',pha_vname,varnam, strlen(varnam),&pInfo);
	}
	return pInfo;
}

/********************************/
/*								*/
/********************************/
tdtInfoParm *cl_get_global_var(varnam)
char *varnam;
{
	return cl_get_var(varnam,D_GX_OPT_SET_GLOBAL);
}

/********************************/
/*								*/
/********************************/
tdtInfoParm *cl_get_public_var(varnam)
char *varnam;
{
	return cl_get_var(varnam,D_GX_OPT_SET_PUBLIC);
}

/********************************/
/*								*/
/********************************/
int cl_mod_option(ix,g_mode)
int ix,g_mode;
{
	int i,rc,*option;
/*
printf("cl_mod_option: ix=%d g_mode=%d\n",ix,g_mode);
*/
	if (ix<=0 || ix>MAX_OPTIONS) return -1;
	ix--;
	if (!pGlobTable) pGlobTable = &GlobTable;
	option = pGlobTable->options;
/*
printf("cl_mod_option:1: option=%08x giOptios=%d\n",option[ix],giOptions[ix]);
*/
	if (ix==0) {
		if (g_mode) {
			if (giOptions[0] & 0x02) giOptions[0] |= 0x01;
			if (giOptions[0] & 0x01) giOptions[0] &= ~0x04;
		}
		if (option[0] & 0x02) option[0] |= 0x01;
		if (option[0] & 0x01) option[0] &= ~0x04;
	}
	else if (ix==8) {
		if (g_mode) {
			if (giOptions[8] & 0x04) {
				CLcommon.Quot[0] = M_QUOTE2;
				CLcommon.Quot[1] = M_QUOTE1;
			}
			else  {
				CLcommon.Quot[0] = M_QUOTE1;
				CLcommon.Quot[1] = M_QUOTE2;
			}
		}
		if (option[8] & 0x04) {
			pGlobTable->Quot[0] = M_QUOTE2;
			pGlobTable->Quot[1] = M_QUOTE1;
		}
		else  {
			pGlobTable->Quot[0] = M_QUOTE1;
			pGlobTable->Quot[1] = M_QUOTE2;
		}
		_set_log_flg_cd_opt(-1,0);
	}
	else if (ix==2) {
		rc = 0x07000;
		i = (giOptions[2]<<12) & rc;
		rc = ~rc;
		LOGFLG(D_LOG_NO_ERROR,(LOGFLG(D_LOG_NO_ERROR,-1) & rc) | i);
		LOGFLG(D_LOG_NO_PRINT,(LOGFLG(D_LOG_NO_PRINT,-1) & rc) | i);
		LOGFLG(D_LOG_NO_DEBUG,(LOGFLG(D_LOG_NO_DEBUG,-1) & rc) | i);
/*
printf("cl_mod_option: logno=%d flg=%08x\n",D_LOG_NO_ERROR,LOGFLG(D_LOG_NO_ERROR,-1));
printf("cl_mod_option: logno=%d flg=%08x\n",D_LOG_NO_PRINT,LOGFLG(D_LOG_NO_PRINT,-1));
printf("cl_mod_option: logno=%d flg=%08x\n",D_LOG_NO_DEBUG,LOGFLG(D_LOG_NO_DEBUG,-1));
*/
	}
	else if (ix==20) {
		_set_log_flg_cd_opt(-1,0);
	}
/*
printf("cl_mod_option:2: option=%08x giOptios=%d\n",option[ix],giOptions[ix]);
*/
	return option[ix];
}

/********************************/
/*								*/
/********************************/
int cl_get_option(ix,g_mode)
int ix,g_mode;
{
	int option;

	option = 0;
	if (ix>=1 && ix<=MAX_OPTIONS) {
		ix--;
		if (g_mode) option = giOptions[ix];
		else option = pGlobTable->options[ix];
	}
	return option;
}

/********************************/
/*								*/
/********************************/
int cl_opt_add_del(opt0,iADD_DEL,opt)
int opt0,iADD_DEL,opt;
{
	if (iADD_DEL) {
		if (iADD_DEL == 1) opt0 = opt;
		else if (iADD_DEL == 2) opt0 |= opt;
		else if (iADD_DEL < 0) opt0 &= ~opt;
	}
	return opt0;
}

/********************************/
/*								*/
/********************************/
int cl_get_add_del(pp,plen)
char **pp;
int *plen;
{
	char *p,c;
	int len,iADD_DEL;

	p = *pp;
	len = *plen;
	iADD_DEL = 1;
	if (len > 2) {	/* -0 */
		if (((c=*p)=='+' || c=='-') && *(p+1)=='0') {
			p++;
			len--;
			if (c == '+') iADD_DEL = 2;
			else iADD_DEL = -1;
		}
	}
	*pp = p;
	*plen = len;
	return iADD_DEL;
}

/********************************/
/*								*/
/********************************/
int let_options(prmnum, pprmp, Obj)
int      prmnum;
parmList **pprmp;
int      *Obj;
{
	parmList *prmp;
	tdtInfoParm tInfoParm;
	int i,ix,rc,val,g_mode,len,iADD_DEL,opt,bit;
	char *p,c;
/*
printf("let_options: prmnum=%d\n",prmnum);
*/
	opt = cl_get_option(30,0);
	bit = 0;
	if (opt && !(opt & 0x80000000)) bit = 1;
	g_mode = 0;
/*	for (i=1;i<prmnum && ix<MAX_OPTIONS;i++) {	*/
	for (i=1;i<prmnum;i++) {
		prmp = pprmp[i];
		/* �p�����[�^���ȗ�����Ă���ꍇ�́A�X�L�b�v���� */
		if ((len=prmp->prmlen) > 0) {
			iADD_DEL = 1;
			p = prmp->prp;
			if ((c=*p) == '/') {
				c = akxcupper(*(p+1));
				if (c == 'G') g_mode = 1;
				else g_mode = 0;
			}
			else {
				iADD_DEL = cl_get_add_del(&p,&len);
				if (rc = cl_gx_expsn_obj_opt(p,len,&prmp->bxobj,Obj,&tInfoParm,0)) return rc;
			/*	if (rc = cl_gx_exp_obj(1,&prmp,Obj,&tInfoParm)) return rc;	*/
				if (tInfoParm.pi_dlen > 0) {
					if (tInfoParm.pi_attr==DEF_ZOK_CHAR && instrchar(p=tInfoParm.pi_data,'.')>0)
						akxccvdotn(p,tInfoParm.pi_dlen,&val);
					else if (rc = cl_get_parm_bin(&tInfoParm,&val,"Options: ")) return rc;

DEBUGOUTL5(110,"let_options: i=%d val=%d iADD_DEL=%d opt=%08x bit=%08x",i,val,iADD_DEL,opt,bit);

					if (!(opt & bit)) {
						ix = i - 1;
/*
printf("let_options: ix=%d val=%08x\n",ix,val);
*/
						if (g_mode) giOptions[ix] = cl_opt_add_del(giOptions[ix],iADD_DEL,val);
						pGlobTable->options[ix] = cl_opt_add_del(pGlobTable->options[ix],iADD_DEL,val);
						cl_mod_option(ix+1,g_mode);
					}
				}
			}
		}
		bit += bit;
	}
	return 0;
}

/********************************/
/*								*/
/********************************/
int let_option(prmnum, pprmp, Obj)
int      prmnum;
parmList **pprmp;
int      *Obj;
{
	static char *_fn_="let_option";
	parmList *prmp;
	tdtInfoParm tInfoParm;
	int i,ix,ix1,rc,val[2],g_mode,len,iADD_DEL,iDOT,opt,bit,val1;
	char *p,c;

	if (prmnum < 3) {
		ERROROUT1(FORMAT(42),_fn_);		/* �p�����[�^������܂���B */
		return ECL_SCRIPT_ERROR;
	}
	g_mode = 0;
	iADD_DEL = 1;
	for (i=1,ix=0;i<prmnum;i++) {
		prmp = pprmp[i];
		if ((len=prmp->prmlen) <= 0) {
			ERROROUT1(FORMAT(341),_fn_);	/* NULL�p�����[�^�͎w��ł��܂���B */
			return ECL_SCRIPT_ERROR;
		}
		p = prmp->prp;
		if ((c=*p) == '/') {
			c = akxcupper(*(p+1));
			if (c == 'G') g_mode = 1;
			else g_mode = 0;
		}
		else if (ix > 1) {
			ERROROUT1(FORMAT(41),_fn_);		/* �s�v�ȃp�����[�^������܂��B */
			return ECL_SCRIPT_ERROR;
		}
		else {
			iADD_DEL = cl_get_add_del(&p,&len);
			if (rc = cl_gx_expsn_obj_opt(p,len,&prmp->bxobj,Obj,&tInfoParm,0)) return rc;
		/*	if (rc = cl_gx_exp_obj(1,&prmp,Obj,&tInfoParm)) return rc;	*/
			if (cl_is_null_parm(&tInfoParm)) {
				ERROROUT1(FORMAT(341),_fn_);	/* NULL�p�����[�^�͎w��ł��܂���B */
				return ECL_SCRIPT_ERROR;
			}
			iDOT = 0;
			if (ix>0 && tInfoParm.pi_attr==DEF_ZOK_CHAR) {
				p = tInfoParm.pi_data;
				len = tInfoParm.pi_dlen;
				iADD_DEL = cl_get_add_del(&p,&len);
				tInfoParm.pi_data = p;
				tInfoParm.pi_dlen = len;
				if (instrchar(p=tInfoParm.pi_data,'.') > 0) iDOT = 1;
			}
			if (iDOT) akxccvdotn(p,tInfoParm.pi_dlen,&val[ix]);
			else if (rc = cl_get_parm_bin(&tInfoParm,&val[ix],"Option: ")) return rc;
/*
printf("let_option: i=%d val=%08x\n",i,val[ix]);
*/
			ix++;
		}
	}
	if ((ix=val[0])<1 || ix>MAX_OPTIONS) {
		ERROROUT2(FORMAT(343),_fn_,ix);	/* �I�v�V�����ԍ�(%d)���s���ł��B */
		return ECL_SCRIPT_ERROR;
	}
/*
printf("let_option: ix=%d\n",ix);
*/
	ix1 = ix - 1;
	opt = cl_get_option(30,0);
	bit = 0;
	if (opt && !(opt & 0x80000000)) {
		bit = 1;
		if (ix1 > 0) bit <<= ix1;
	}
	val1 = val[1];

DEBUGOUTL5(110,"let_option:  i=%d val=%d iADD_DEL=%d opt=%08x bit=%08x",ix,val1,iADD_DEL,opt,bit);

	if (!(opt & bit)) {
		if (g_mode) giOptions[ix1] = cl_opt_add_del(giOptions[ix1],iADD_DEL,val1);
		pGlobTable->options[ix1] = cl_opt_add_del(pGlobTable->options[ix1],iADD_DEL,val1);
		cl_mod_option(ix,g_mode);
	}
	return 0;
}

/********************************/
/*								*/
/********************************/
static int let_exit(prmnum, pprmp, Obj)
int      prmnum;
parmList **pprmp;
int      *Obj;
{
	tdtInfoParm tInfoParm,*pInfoParm;
	int rc,val,n;

	n = 0;
	pInfoParm = &tInfoParm;
	if (prmnum >= 2) {
		if (rc = cl_gx_exp_obj(prmnum-1,&pprmp[1],Obj,pInfoParm)) {
			if (rc != 100) return rc;
		}
		else n = 1;
	}
	else if (prmnum <= 0) return cl_ex_exit_finally();
	return cl_ex_exit(&val,n,&pInfoParm);
}

/********************************/
/*								*/
/********************************/
int let_continue(leaf,proc)
Leaf   *leaf;
ProcCT *proc;
{
	return cl_pr_continue(leaf,proc,1);
}

/********************************/
/*								*/
/********************************/
int let_print_echo(leaf,proc,scno)
Leaf   *leaf;
ProcCT *proc;
int    scno;
{
	int opt;	/* 0x01:c_flg=1,q_flg=1,n_flg=1,l_flg=1	*/
				/* 0x02:PRINTOUT */

	if (scno == CS_LPRINT) opt = 3;
	else if (scno == CS_PRINT) opt = 1;
	else opt = 0;
	return cl_print_echo_text(&leaf->cmd.prmp[1],proc->Obj,leaf->cmd.prmnum-1,NULL,opt);
}

/********************************/
/*								*/
/********************************/
int let_dump(leaf,proc,scno)
Leaf   *leaf;
ProcCT *proc;
int    scno;
{
	return cl_dump(&leaf->cmd.prmp[1],leaf->cmd.prmnum-1,proc->Obj);
}

/********************************/
/*								*/
/********************************/
int let_printf(leaf,proc,scno)
Leaf   *leaf;
ProcCT *proc;
int    scno;
{
	int opt;	/* 0x01:c_flg=1,q_flg=1,n_flg=1,l_flg=1	*/
				/* 0x02:PRINTOUT */

	if (scno == CS_LPRINTF) opt = 0x83;
	else if (scno == CS_PRINTF) opt = 0x81;
	else opt = 0;
	return cl_printf_text(&leaf->cmd.prmp[1],proc->Obj,leaf->cmd.prmnum-1,NULL,opt);
}

/********************************/
/*								*/
/********************************/
static int let_log_parm(prmnum, pprmp, Obj)
int      prmnum;
parmList **pprmp;
int      *Obj;
{
	parmList *prmp;
	tdtInfoParm tInfoParm;
	int i,n,rc,ii,iXLIB,len;
	long iParm[7];
	char c,*argv[7],*p;

	pprmp++;
	n = X_MIN(prmnum-1,7);
	ii = iXLIB =0;
	for (i=0;i<n;i++) {
		iParm[ii] = -1;
		prmp = pprmp[i];
		if ((len=prmp->prmlen) > 0) {
/*
printf("LETLog: i=%d  len=%d p1=[%s]\n",i,len,prmp->prp);
*/
			c = prmp->prp[0];
			if (len==2 && c=='/' && akxcupper(prmp->prp[1])=='X') iXLIB = 1;
			else if (len==1 && c=='.') argv[ii++] = ".";
			else {
				if (rc = cl_gx_exp_obj(1,&prmp,Obj,&tInfoParm)) return rc;
				if (tInfoParm.pi_attr==DEF_ZOK_CHAR && *(p=tInfoParm.pi_data)=='/') {
					if (akxcupper(*(p+1)) == 'X') iXLIB = 1;
				}
				else {
					if (rc = cl_set_log_parmi(&tInfoParm,argv,iParm,ii)) return rc;
/*
printf("LETLog: ii=%d argv=[%s] iParm=%08x\n",ii,argv[ii],iParm[ii]);
*/
					ii++;
				}
			}
		}
		else argv[ii++] = ".";
	}
	n = ii;
/*
printf("LETLog: n=%d iXLIB=%d\n",n,iXLIB);
*/
	if (iXLIB) {
		akx_log_set_parm2(-n,argv,n,iParm);
		_set_log_flg_cd_opt(-1,0x01);
	}
	else {
		akb_log_set_parm2(-n,argv,n,iParm);
		_set_log_flg_cd_opt(-1,0x02);
	}
	return 0;
}

/********************************/
/*								*/
/********************************/
int let_goto(leaf,proc)
Leaf   *leaf;
ProcCT *proc;
{
	return cl_pr_goto(leaf,proc,1);
}

