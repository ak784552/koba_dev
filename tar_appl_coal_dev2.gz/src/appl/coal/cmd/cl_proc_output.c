static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************
*                                                                   *
*      �����ړI�@�@�F  �n�t�s�o�t�s���C��                           *
*                                                                   *
*      �֐����@�@�@�F�@int cl_process_output( pLeaf )               *
*                                                                   *
*      ������      �F�@(I)Leaf          * pLeaf                     *
*                                                                   *
*                                                                   *
*      �߂�l�@�@�@�F�@ERROR                                        *
*                      NORMAL                                       *
*                                                                   *
*      �����T�v�@�@�F�@                                             *
*                                                                   *
********************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;

int cl_proc_output(pLeaf,proc)
Leaf *pLeaf;                       /* �J�����g���[�t�f�[�^    */
ProcCT  *proc;
{
	int rc;
	MCAT *mcat;
                                       /* �����N�`�F�b�N          */
	if ( pLeaf == NULL ) {
		ERROROUT("pLeaf == NULL");
		return ( ECL_SYSTEM_ERROR );
	}
                                       /* output �R�}���h���H     */
	if ( pLeaf->cmd.cid != C_OUTPUT ) {
		ERROROUT("pLeaf->cmd.cid != C_OUTPUT");
		return ( ECL_SYSTEM_ERROR );
	}

	if (pLeaf->cmd.prmp[0] == NULL) return ( ECL_SYSTEM_ERROR );
/*
	if (pCLprocTable->ListPBody) {
		mcat = &pCLprocTable->ListPBody->mCat;
	}
*/
	rc = 0;
	sswitch ( pLeaf->cmd.prmp[0]->prp )
		sicase ( "GR" )                 /* �O���[�v�m�[�h���� */
			rc = cl_rp_grp_nfrm_gen(pLeaf,proc);
		sicase ( "DT" )                 /* �f�[�^�m�[�h���� */
			rc = cl_rp_data_nfrm_gen(pLeaf,proc);
		sicase ( "PR" )                 /* Print text for debug */
			rc = cl_print_text(&pLeaf->cmd.prmp[1],proc->Obj,
			                   pLeaf->cmd.prmnum-1,"Print: ");
		sicase ( "FM" )
			rc = cl_rp_frm_nfrm_gen(pLeaf);
		sicase ( "TX" )                 /* Text */
			rc = cl_rp_text_nfrm_gen(pLeaf, proc, 0);
		sicase ( "TN" )                 /* Text + (LF) */
			rc = cl_rp_text_nfrm_gen(pLeaf, proc, 1);
		sicase ( "TF" )                 /* Text File */
			rc = cl_rp_text_nfrm_gen(pLeaf, proc, 2);
		sicase ( "AC" )                 /* All Clear */
			cl_list_pac_clear(pCLprocTable->ListPBody);
			pCLprocTable->ListPBody = NULL ;
		sdefault
		{
			ERROROUT("not GT,DT,FM,TX,TN,TF,AC");
			return ( ECL_SYSTEM_ERROR );
		}
	endssw

	if (pCLprocTable->ListPBody) {
		mcat = &pCLprocTable->ListPBody->mCat;
		if (rc) mcat->mc_ipos = pCLprocTable->ListPBody->AllFieldlen;
		else pCLprocTable->ListPBody->AllFieldlen = mcat->mc_ipos;
	}
 
	return ( rc );
}
