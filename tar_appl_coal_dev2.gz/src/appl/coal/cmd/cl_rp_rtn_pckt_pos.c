static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�P�b�g�����o���㏈���@�@�@�@�@�@�@�@�@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_rp_rtn_pckt_pos( pPKCB )                        *
*                                                                             *
*      ������      �F�@(I) PacketCB    *pPKCB                                 *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL *pCLprocTable;

int cl_rp_rtn_pckt_pos()
{
	if (pCLprocTable->ListPBody) {
		if (pCLprocTable->ListPBody->mCat.mc_bufp) {
			Free(pCLprocTable->ListPBody->mCat.mc_bufp);
			pCLprocTable->ListPBody->mCat.mc_bufp = NULL;
		}
		pCLprocTable->ListPBody = NULL;
	}
	return( NORMAL );
}
