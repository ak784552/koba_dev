static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �k�n�n�o�񐔕ԋp									      *
*                                                                             *
*      �֐����@�@�@�F�@int cl_loop_max( pparmList , pValue )                  *
*                      (I)prmList	*pparmList                                *
*                      (O)int		*pValue		                              *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

int cl_get_exp_obj_info(prmnum, pprmp, Obj, opt, msg, err, pInfoParm)
int   prmnum;
parmList **pprmp;
int  *Obj;
int   opt;
char *msg;
int   err;
tdtInfoParm *pInfoParm;
{
	int rc;

	rc = NORMAL;
	rc = cl_gx_exp_obj(prmnum,pprmp,Obj,pInfoParm);
	if (rc) {
		ERROROUT2(FORMAT(48),msg,rc);	/* %s��������Ă��܂��Bret=%d */
		rc = err;
	}
	else if ((opt & 0x01) && cl_is_null_data(pInfoParm)) {
		rc = ECL_NULL_DATA;
	}
	return rc;
}

int cl_get_gx_exp_bin(prmnum, pprmp, Obj, pValue, opt, msg, err)
int   prmnum;
parmList **pprmp;
int  *Obj;
int  *pValue;
int   opt;
char *msg;
int   err;
{
	int       rc;
	tdtInfoParm InfoParm;
#if 1
	rc = cl_get_exp_obj_info(prmnum,pprmp,Obj,opt,msg,err,&InfoParm);
	if (rc == ECL_NULL_DATA)
		*pValue = 0;
	else if (rc) ;
#else
	rc = NORMAL;
	rc = cl_gx_exp_obj(prmnum,pprmp,Obj,&InfoParm);
	if (rc) {
		ERROROUT2(FORMAT(48),msg,rc);	/* %s��������Ă��܂��Bret=%d */
		return err;
	}
	if ((opt & 0x01) && cl_is_null_data(&InfoParm)) {
		rc = ECL_NULL_DATA;
		*pValue = 0;
	}
#endif
	else rc = cl_get_parm_bin(&InfoParm,pValue,msg);

	return rc;
}

int cl_loop_max(pLeaf, proc, pValue )
Leaf	*pLeaf;
ProcCT  *proc;
int		*pValue;
{
	int rc,i,n;
	cmdInfo *pcmd;

	pcmd = &(pLeaf->cmd);
	n = pcmd->prmnum;
/*	if ((i=get_pos_as_name(pcmd->prmp,n)) > 0) n = i - 1;	*/
	rc = cl_get_gx_exp_bin(n,pcmd->prmp,proc->Obj,
	                   pValue,0,"cl_loop_max: ",ECL_EX_LOOP);
/*	if (rc == ECL_NULL_DATA) rc = 0;	*/
	return rc;
}
