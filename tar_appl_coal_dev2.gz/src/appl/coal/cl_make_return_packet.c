static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�P�b�g�����o�����C��                                 *
*                                                                             *
*      �֐����@�@�@�F�@int cl_make_return_packet()                            *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include "colmn.h"
extern CLPRTBL *pCLprocTable;

int cl_make_return_packet()
{
	int rc;

	if((rc = cl_rp_packet_gen()) != NORMAL) {
		ERROROUT1("cl_make_return_packet:cl_rp_packet_gen rc = %d", rc);
		return rc;
	}

	cl_rp_rtn_pckt_pos();

	return NORMAL;
}

int cl_make_list_pbody()
{
	FILE *fp;
	ListPacBody *pListPBody;

	if (pCLprocTable->ListPBody) return 0;
	pListPBody = (ListPacBody *)cl_const_malloc(sizeof(ListPacBody));
	if (!pListPBody) return( ERROR );
	pCLprocTable->ListPBody = pListPBody;
	pListPBody->AllFieldlen   = 0;
	pListPBody->mCat.mc_extlen = 4096;
	pListPBody->mCat.mc_maxcnt = 0;
	pListPBody->mCat.mc_extcnt = 0;
	pListPBody->mCat.mc_alclen = 0;
	pListPBody->mCat.mc_bufp = NULL;
	pListPBody->mCat.mc_ipos = 0;
	pListPBody->indInfo.ini_did = 'F';
	pListPBody->indInfo.ini_dpos = 0;
	pListPBody->indInfo.ini_dlen = 0;

	sprintf(pListPBody->fname,"ColTf%03d",pCLprocTable->iThread);
	pListPBody->indInfo.ini_spos = 8 + strlen(pListPBody->fname);
	if(fp = fopen(akb_akb_home_add(pListPBody->fname), "w")) {
		fclose(fp);
	}
	else {
		/* �Ԑڃt�@�C��[%s] Open Error */
		ERROROUT1(FORMAT(336),pListPBody->fname);
		return -1;
	}
	return 0;
}
