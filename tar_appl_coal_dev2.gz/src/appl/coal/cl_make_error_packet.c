static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �G���[�p�P�b�g�����o������                             *
*                                                                             *
*      �֐����@�@�@�F�@int cl_make_error_packet()                             *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include "colmn.h"
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

int cl_make_error_packet()
{
	FreamCB    *pFRCB;
	TrmToSrv   *pwTTS,*pWrTTS;
	AKAMSGCOM  *tpMsgCom, *tpSendMsgCom;

	if (!(pWrTTS=(TrmToSrv *)Malloc(sizeof(TrmToSrv)))) return ERROR;
	/* �p�P�b�g�w�b�_�[�쐬     */
	tpMsgCom = (AKAMSGCOM *)pCLprocTable->CmdPacketp;
	pwTTS = (TrmToSrv *)tpMsgCom->msg_pmsg;
	memcpy(pWrTTS->userid,pwTTS->userid,sizeof(pwTTS->userid));
	pWrTTS->commandid = pwTTS->commandid;
	pWrTTS->parmnum = htonl(pGlobTable->Return);
	tpSendMsgCom = (AKAMSGCOM *)pCLprocTable->WrPacketp;
	tpSendMsgCom->msg_pmsg = (char *)pWrTTS;
	tpSendMsgCom->msg_mlen = sizeof(TrmToSrv);
	tpSendMsgCom->msg_filc = 0;

	return NORMAL;
}
