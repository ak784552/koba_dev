static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/********************************************************************/
/* <clfuncmath.c>                                                     */
/*      func_math                                           */
/*                              by Koba       (2007/12/22 Ver 0.1) */
/********************************************************************/

#include "colmn.h"        /* �֐��v���g�^�C�v�錾 */

extern CLCOMMON  CLcommon;
extern CLPRTBL   *pCLprocTable;
extern GlobalCt  *pGlobTable;
extern int giOptions[];

/****************************************/
/*										*/
/****************************************/
int func_math2(pInfoParmW,pOperator,nparm,ppParm,ope)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *ppParm[];
int nparm,ope;
{
	int rc,atr1,iAttr[3],format_no,iDBL,ret,iCOMPLEX1,iCOMPLEX2,iIMAGE1,iIMAGE2,iCOMPLEX;
	long Val1z[NMPA_LONG],*Val1;
	double dVal;
	MPA maz,*ma;

	if (nparm >= 1) {
		iCOMPLEX1 = ppParm[0]->pi_alen  & D_AULN_COMPLEX_DATA;
		iIMAGE1   = ppParm[0]->pi_scale & D_DATA_IMAGE;
	}
	else {
		iCOMPLEX1 = iIMAGE1 = 0;
	}
	if (ope ==  D_FUC_POWER) {
		if (nparm >= 2) {
			iCOMPLEX2 = ppParm[1]->pi_alen & D_AULN_COMPLEX_DATA;
			iIMAGE2   = ppParm[1]->pi_scale & D_DATA_IMAGE;
		}
		else return ECL_SCRIPT_ERROR;
		iCOMPLEX = iCOMPLEX1 | iCOMPLEX2 | iIMAGE1 | iIMAGE2;
	}
	else {
		iCOMPLEX = iCOMPLEX1 | iIMAGE1;
	}
	if (iCOMPLEX) {
		return func_math_complex(pInfoParmW,pOperator,nparm,ppParm,ope);
	}
	rc = 0;
	iDBL = cl_get_option(2,0) & 0x04;
	if (!iDBL && (ope==D_FUC_SQRT || ope==D_FUC_CBRT ||
	              ope==D_FUC_LOG || ope==D_FUC_LOG10)) {
		Val1 = cl_get_tmpMPA(Val1z);
		if ((rc=cl_get_parm_mpa(ppParm[0],Val1,"Parm1",iAttr)) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;

		ma = (MPA *)cl_get_tmpMPA(&maz);
		format_no = 0;
		atr1 = iAttr[0];
		if (atr1 == DEF_ZOK_DECI) {
			switch (ope) {
			case D_FUC_SQRT:
				rc = m_sqrt(ma,(MPA *)Val1);
				format_no = 402;	/* %s ���������ł��B */
				break;
			case D_FUC_CBRT:
				rc = m_cbrt(ma,(MPA *)Val1);
				break;
			case D_FUC_LOG:
				rc = m_ln(ma,(MPA *)Val1);
				format_no = 403;	/* %s �������s���ł��B */
				break;
			case D_FUC_LOG10:
				rc = m_log10(ma,(MPA *)Val1);
				format_no = 403;	/* %s �������s���ł��B */
				break;
			default:
				rc = -1;
			}
			if (rc) {
				ret = rc % 10;
				if (ret==-2 && format_no>0)
					ERROROUT1(FORMAT(format_no),pOperator);
				else if (rc > 0) rc = ECL_SCRIPT_ERROR;
			/*	else rc = ECL_SCRIPT_ERROR;	*/
			}
			else cl_set_parm_mpa(pInfoParmW,ma);
		}
	}
	else atr1 = 0;
	if (!rc && atr1!=DEF_ZOK_DECI) {
		rc = func_math(&dVal,pOperator,nparm,ppParm,ope);
		if (!rc) cl_set_parm_double(pInfoParmW,dVal);
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int func_math(pWork,pOperator,nparm,ppParm,ope)
char *pWork;
char *pOperator;
tdtInfoParm *ppParm[];
int nparm,ope;
{
	static int f_err_int[] = {FE_INVALID,FE_DIVBYZERO,FE_OVERFLOW,FE_UNDERFLOW,0};
	static char *f_err_str[] = {"INVALID","DIVBYZERO","OVERFLOW","UNDERFLOW",NULL};
	int ret,rc,atr1,atr2,Val2[2],i,iERROR,exopt2,exopt16,iUNDER;
	long Val1z[NMPA_LONG],*Val1;
	double dValue1,dValue2,dVal;
	char *p,*pp;
/*
printf("func_math: pOperator=%s nparm=%d ope=%d\n",pOperator,nparm,ope);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"func_math:Enter pOperator=[%s]",ppParm[0],pOperator,0);
*/
	ret = 0;
	dVal = 0.0;
	errno = 0;
	feclearexcept(FE_ALL_EXCEPT);
	if (ope == D_FUC_RAND1) {
		if (nparm > 0) ERROROUT1(FORMAT(401),pOperator);	/* %s �����𖳎����܂��B */
		dVal = drand48();
	}
	else if (ope == D_FUC_SRAND1) {
		Val1 = cl_get_tmpMPA(Val1z);
		if ((rc = cl_get_parm_long(ppParm[0],Val1,"Parm1"))  < 0) ret = rc;
		else if (rc > 0) ret = ECL_SCRIPT_ERROR;
		else srand48(Val1[0]);
	}
	else {
		if ((rc=cl_get_parm_double(ppParm[0],&dValue1,"Parm1")) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		dValue2 = 0.0;
		if (nparm >= 2) {
			if ((rc=cl_get_parm_double(ppParm[1],&dValue2,"Parm2")) < 0) return rc;
			else if (rc > 0) return ECL_SCRIPT_ERROR;
		}
		switch (ope) {
			case D_FUC_SQRT:
				if (dValue1 >= 0.0) dVal = sqrt(dValue1);
				else {
					ERROROUT1(FORMAT(402),pOperator);	/* %s ���������ł��B */
					ret = ECL_SCRIPT_ERROR;
				}
				break;
			case D_FUC_SIN:
				dVal = sin(dValue1);
				break;
			case D_FUC_COS:
				dVal = cos(dValue1);
				break;
			case D_FUC_TAN:
				dVal = tan(dValue1);
				break;
			case D_FUC_ASIN:
			case D_FUC_ACOS:
				if (dValue1<-1.0 || dValue1>1.0) {
					ERROROUT1(FORMAT(403),pOperator);	/* %s �������s���ł��B */
					ret = ECL_SCRIPT_ERROR;
				}
				else {
					if (ope == D_FUC_ASIN) dVal = asin(dValue1);
					else dVal = acos(dValue1);
				}
				break;
			case D_FUC_ATAN:
				dVal = atan(dValue1);
				break;
			case D_FUC_ATAN2:
				if (nparm < 2) {
					ERROROUT1(FORMAT(405),pOperator);	/* %s �x���W�l������܂���B */
					ret = ECL_SCRIPT_ERROR;
				}
				if (X_ABS(dValue2) < MINREGDBL) {
					ERROROUT1(FORMAT(403),pOperator);	/* %s �������s���ł��B */
					ret = ECL_SCRIPT_ERROR;
				}
				else dVal = atan2(dValue1,dValue2);
				break;
			case D_FUC_LOG:
			case D_FUC_LOG10:
				if (dValue1 < MINREGDBL) {
					ERROROUT1(FORMAT(403),pOperator);	/* %s �������s���ł��B */
					ret = ECL_SCRIPT_ERROR;
				}
				else {
					if (ope == D_FUC_LOG) dVal = log(dValue1);
					else dVal = log10(dValue1);
				}
				break;
			case D_FUC_EXP:
				dVal = exp(dValue1);
				break;
			case D_FUC_POWER:
				if (nparm < 2) {
					ERROROUT1(FORMAT(404),pOperator);	/* %s �w���l������܂���B */
					ret = ECL_SCRIPT_ERROR;
				}
				else dVal = pow(dValue1,dValue2);
				break;
			case D_FUC_CBRT:
				dVal = cbrt(dValue1);
				break;
			case D_FUC_SINH:
				dVal = sinh(dValue1);
				break;
			case D_FUC_COSH:
				dVal = cosh(dValue1);
				break;
			case D_FUC_TANH:
				dVal = tanh(dValue1);
				break;
			case D_FUC_ATANH:
				dVal = atanh(dValue1);
				break;
			case D_FUC_CEIL:
				dVal = ceil(dValue1);
				break;
			case D_FUC_FLOOR:
				dVal = floor(dValue1);
				break;
			case D_FUC_RINT:
				dVal = rint(dValue1);
				break;
			default:
				ERROROUT1("func_math: function=[%s] not defined!!",pOperator);
				ret = ECL_SCRIPT_ERROR;
		}
	}
	memcpy(pWork,&dVal,sizeof(double));
	rc = fetestexcept(FE_INVALID | FE_DIVBYZERO | FE_OVERFLOW | FE_UNDERFLOW);
	if (errno || rc) {
		exopt2 = cl_get_option(2,0) & 0x200;
		exopt16 = cl_get_option(16,0) & 0x0f;
		p = NULL;
		iUNDER = 0;
		if (rc) {
			if ((i=akxs_iseq(f_err_int,4,rc)) > 0) {
				p = f_err_str[i-1];
			}
			iUNDER = rc & FE_UNDERFLOW;
		}
		if (errno) {
			iERROR = 0x10000;
			pp = strerror(errno);
			if (p) pp = stradd5(pp,"(",p,")",NULL);
			ERROROUT3("func_math: function=[%s] errno=%d %s",pOperator,errno,pp);
		}
		else if (rc) {
			iERROR = 0x10000;
			rc = exopt16 & (0x04|0x08);
			if (iUNDER && rc) iERROR |= rc;
		/*	if (!iUNDER || (iUNDER && (exopt16 & 0x08))) {	*/
			if (!iUNDER || (iERROR & 0x08)) {
				if (!p) p = "MATH_EXCEPTION";
				ERROROUT2("func_math: function=[%s] %s",pOperator,p);
			}
		}
		if (iERROR) {
			pGlobTable->error = ECL_SCRIPT_ERROR;
			pGlobTable->err_no = errno;
		/*	if ((errno && exopt2) || (iUNDER && (exopt16 & 0x04))) {	*/
			if ((errno && exopt2) || (iERROR & 0x04)) {
				pGlobTable->exception = MATH_COMP_ERROR_EXCEPTION;
				ret = ECL_SCRIPT_ERROR;
			}
		}
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int func_math_complex(pInfoParmW,pOperator,nparm,ppParm,ope)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *ppParm[];
int nparm,ope;
{
	tdtInfoParm tInfoR,tInfoI,tInfo,*ppInfo[3];
	int ret,iVal[2],iCOMPLEX1,iCOMPLEX2,iIMAGE1,iIMAGE2;
	double dVal_ey,dVal_eby,dVal_sinx,dVal_cosx,dVal_r,dVal_i,dVal_expx,dVal_siny,dVal_cosy,dVal;
	double dVal_r1,dVal_i1,dVal_r2,dVal_i2,dVal_arg,dVala[3];
/*
printf("func_math_complex: pOperator=%s nparm=%d ope=%d\n",pOperator,nparm,ope);
*/
	ret = 0;
	ppInfo[0] = &tInfoR;
	ppInfo[1] = &tInfoI;
	ppInfo[2] = &tInfo;
	iCOMPLEX1 = ppParm[0]->pi_alen  & D_AULN_COMPLEX_DATA;
	iIMAGE1   = ppParm[0]->pi_scale & D_DATA_IMAGE;
/*
printf("func_math_complex: iCOMPLEX1=%04x iIMAGE1=%02x\n",iCOMPLEX1,iIMAGE1);
*/
	dVal_r = dVal_i = 0.0;
	if (ope==D_FUC_POWER) {
		if (!iCOMPLEX1) {
			if ((ret=cl_get_parm_double(ppParm[0],&dVal,"1")) < 0) return ret;
			if (dVal == 0.0) {
				cl_set_parm_double(pInfoParmW,dVal);
				return 0;
			}
			else if (dVal < 0.0) dVal = -dVal;
		}
		iCOMPLEX2 = ppParm[1]->pi_alen & D_AULN_COMPLEX_DATA;
		iIMAGE2   = ppParm[1]->pi_scale & D_DATA_IMAGE;
/*
printf("func_math_complex: iCOMPLEX2=%04x iIMAGE2=%02x\n",iCOMPLEX2,iIMAGE2);
*/
		if (iCOMPLEX2) {
			if ((ret=cl_get_range_info(ppParm[1],ppInfo,iVal,0)) < 0) return ret;
			if ((ret=cl_get_parm_double(ppInfo[0],&dVal_r2,"R")) < 0) return ret;
			if ((ret=cl_get_parm_double(ppInfo[1],&dVal_i2,"I")) < 0) return ret;
/*
printf("func_math_complex: dVal_r2=%f dVal_i2=%f\n",dVal_r2,dVal_i2);
*/
		}
		else if (iIMAGE2) {
			dVal_r2 = 0.0;
			if ((ret=cl_get_parm_double(ppParm[1],&dVal_i2,"I")) < 0) return ret;
		}
		else {
			if ((ret=cl_get_parm_double(ppParm[1],&dVal_r2,"R")) < 0) return ret;
			dVal_i2 = 0.0;
		}
		if (!(iCOMPLEX1 | iIMAGE1)) {
			dVal = log(dVal);
			dVal_r = dVal*dVal_r2;
			dVal_i = dVal*dVal_i2;
		}
		else if (iIMAGE1) {
			dVal = log(dVal);
			dVal_r = dVal*dVal_r2 - dVal_i2*M_PI*0.5;
			dVal_i = dVal*dVal_i2 + dVal_r2*M_PI*0.5;
		}
		else {
			if ((ret=cl_get_range_info(ppParm[0],ppInfo,iVal,0)) < 0) return ret;
			if ((ret=cl_vec_abs_bouble(ppInfo[0],ppInfo[1],dVala)) < 0) return ret;
			dVal = log(dVala[0]);
			dVal_r1 = dVala[1]/dVala[0];
			dVal_i1 = dVala[2]/dVala[0];
			if (dVal_r1 > dVal_i1) dVal_arg = asin(dVal_i1);
			else dVal_arg = acos(dVal_r1);
			dVal_r = dVal_r2*dVal - dVal_i2*dVal_arg;
			dVal_i = dVal_i2*dVal + dVal_r2*dVal_arg;
		}
/*
printf("func_math_complex: dVal_r=%f dVal_i=%f\n",dVal_r,dVal_i);
*/
		cl_set_parm_double(&tInfoR,dVal_r);
		cl_set_parm_double(&tInfoI,dVal_i);
		ppInfo[1]->pi_scale |= D_DATA_IMAGE;
		/* �֐��̂Ƃ��́A�ʏ�̓[���ł����̂܂ܕ��f���ɂ��� */
		if (cl_get_option(2,0) & 0x100) {
			if (cl_adjust_complex(&tInfo,ppInfo[0],ppInfo[1])) return 0;
		}
		ret = cl_gx_range_set(&tInfo,2,ppInfo,0);
		if (ret >= 0) return func_math_complex(pInfoParmW,"EXP",1,&ppInfo[2],D_FUC_EXP);
	}
	else {
		if (iCOMPLEX1) {
			if ((ret=cl_get_range_info(ppParm[0],ppInfo,iVal,0)) < 0) return ret;
			if ((ret=cl_get_parm_double(ppInfo[0],&dVal_r1,"R1")) < 0) return ret;
			if ((ret=cl_get_parm_double(ppInfo[1],&dVal_i1,"I1")) < 0) return ret;
/*
printf("func_math_complex: dVal_r=%f dVal_i=%f\n",dVal_r1,dVal_i1);
*/
		}
		else {
			dVal_r1 = 0.0;
			*ppInfo[1] = *ppParm[0];
			if ((ret=cl_get_parm_double(ppInfo[1],&dVal_i1,"I1")) < 0) return ret;
/*
printf("func_math_complex: dVal_r1=%f dVal_i1=%f\n",dVal_r1,dVal_i1);
*/
		}
		ppInfo[1]->pi_scale &= ~D_DATA_IMAGE;
		if (ope==D_FUC_SIN || ope==D_FUC_COS) {
			if ((ret=func_math(&dVal_ey,"EXP",1,&ppInfo[1],D_FUC_EXP)) < 0) return ret;
			if (iIMAGE1) {
				dVal_r = 0.0;
			}
			else {
				if ((ret=func_math(&dVal_sinx,"SIN",1,ppInfo,D_FUC_SIN)) < 0) return ret;
				if ((ret=func_math(&dVal_cosx,"COS",1,ppInfo,D_FUC_COS)) < 0) return ret;
			}
			if (ope == D_FUC_SIN) {
				if (iIMAGE1) {
					dVal_i = (dVal_ey - dVal_eby)*0.5;
				}
				else {
					dVal_r = (dVal_ey + dVal_eby)*dVal_sinx*0.5;
					dVal_i = (dVal_ey - dVal_eby)*dVal_cosx*0.5;
				}
			}
			else {
				if (iIMAGE1) {
					dVal_i = (dVal_eby + dVal_ey)*0.5;
				}
				else {
					dVal_r = (dVal_eby - dVal_ey)*dVal_sinx*0.5;
					dVal_i = (dVal_eby + dVal_ey)*dVal_cosx*0.5;
				}
			}
		}
		else {
			ret = 0;
			switch (ope) {
			case D_FUC_SQRT:
			case D_FUC_CBRT:
				if (ope == D_FUC_SQRT) dVal = 0.5;
				else dVal = 1.0/3.0;
				ppInfo[0] = ppParm[0];
				cl_set_parm_double(ppInfo[1],dVal);
			/*	return cl_cmpt_complex(pInfoParmW,"**",ppInfo[0],ppInfo[1]);	*/
				return func_math_complex(pInfoParmW,"POWER",2,ppInfo,D_FUC_POWER);
				break;
			case D_FUC_TAN:
				if ((ret=func_math2(ppInfo[0],"SIN",nparm,ppParm,D_FUC_SIN)) < 0) return ret;
				if ((ret=func_math2(ppInfo[1],"COS",nparm,ppParm,D_FUC_COS)) < 0) return ret;
				return cl_cmpt_complex(pInfoParmW,"/",ppInfo[0],ppInfo[1]);
				break;
			case D_FUC_LOG10:
			case D_FUC_LOG:
				if (iCOMPLEX1) {
					if ((ret=cl_cmpt_complex(&tInfo,"ABS",ppInfo[0],ppInfo[1])) < 0) return ret;
					if ((ret=cl_get_parm_double(&tInfo,&dVal,"")) < 0) return ret;
					dVal_r = log(dVal);
					dVal_i = atan2(dVal_i1,dVal_r1);
				}
				else if (iIMAGE1) {
					dVal_r = log(dVal_i1);
					dVal_i = M_PI*0.5;
				}
				if (ope == D_FUC_LOG10) {
				/*	log(10.0)=2.3025850929940456		*/
				/*	1.0/log(10.0)=0.43429448190325182	*/
					dVal = 0.43429448190325182;
					dVal_r *= dVal;
					dVal_i *= dVal;
				}
				break;
			case D_FUC_EXP:
				if ((ret=func_math(&dVal_r,"COS",1,&ppInfo[1],D_FUC_COS)) < 0) return ret;
				if ((ret=func_math(&dVal_i,"SIN",1,&ppInfo[1],D_FUC_SIN)) < 0) return ret;
/*
printf("func_math_complex: COS:dVal_r=%f SIN:dVal_i=%f\n",dVal_r,dVal_i);
*/
				if (iCOMPLEX1) {
					if ((ret=func_math(&dVal_expx,"EXP",1,ppInfo,D_FUC_EXP)) < 0) return ret;
					dVal_r *= dVal_expx;
					dVal_i *= dVal_expx;
				}
				break;
			default:
				ERROROUT1("func_math_complex: function=[%s] not defined!!",pOperator);
				ret = ECL_SCRIPT_ERROR;
			}
		}
	}
	if (ret >= 0) {
/*
printf("func_math_complex: dVal_r=%f dVal_i=%f\n",dVal_r,dVal_i);
*/
		cl_set_parm_double(&tInfoR,dVal_r);
		cl_set_parm_double(&tInfoI,dVal_i);
		ppInfo[1]->pi_scale |= D_DATA_IMAGE;
		/* �֐��̂Ƃ��́A�ʏ�̓[���ł����̂܂ܕ��f���ɂ��� */
		if (cl_get_option(2,0) & 0x100) {
			if (cl_adjust_complex(pInfoParmW,ppInfo[0],ppInfo[1])) return 0;
		}
		ret = cl_gx_range_set(pInfoParmW,2,ppInfo,0);
	}
	return ret;
}
