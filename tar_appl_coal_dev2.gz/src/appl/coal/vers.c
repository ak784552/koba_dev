char version[] ="@(#) ***[V/R=7.5.0 (dev2)]***";

