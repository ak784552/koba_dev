char version[] ="@(#) ***[V/R=7.3.2 (dev2)]***";

