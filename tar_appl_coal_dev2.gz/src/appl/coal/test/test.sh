#!/usr/bin/sh
exec >> xxxx.log 2>&1
echo `date +'%Y/%m/%d %T'` "test.sh: start"
echo `date +'%Y/%m/%d %T'` "test.sh: end"
