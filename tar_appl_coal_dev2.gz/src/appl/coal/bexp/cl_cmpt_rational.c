static char sccsid[]="%Z% %M% %I% %E% %U%";
/************************************************************************
*  ���� : �L�������Z����												*
*         ���q(Numerator)/����(Denominator)								*
*  ���� : int cl_cmpt_rational											*
*  ���� : (O)tdtInfoParm *pInfoParmW :									*
*         (I)char        *pOprtr     :									*
*         (I)tdtInfoParm *pInfoParm1 :									*
*         (I)tdtInfoParm *pInfoParm2 :									*
*  �ԋp : ERROR															*
*         NORMAL														*
*************************************************************************/
/********************************************/
/*	  coded by A.Kobayashi() 2025.03.24		*/
/*	  error code : -215260101�`-215269999	*/
/********************************************/
/* 01- cl_xxxx	*/
#include <colmn.h>

#define MAX_CHK_SOSU_NUM	32
#define MAX_CHK_SOSU_NUM_MAX	761

extern GlobalCt  *pGlobTable;
extern int giOptions[];

/****************************************/
/*	01									*/
/****************************************/
static int _divide_by_zero()
{
	ERROROUT(FORMAT(261));		/* zero�f�B�o�C�h���������܂����B*/
	pGlobTable->exception = MATH_COMP_DEVIDE_EXCEPTION;
	return ECL_SCRIPT_ERROR;
}

/****************************************/
/*	02									*/
/****************************************/
int _set_rational(pRational,pInfoParm1)
tdtInfoParm *pRational,*pInfoParm1;
{
	tdtInfoParm	*pm[2],tInfoParm,*pInfo;
	int rc;

	pInfo = &tInfoParm;
	cl_set_parm_mpa(pInfo,m_get_i(1));
	pm[0] = pInfoParm1;
	pm[1] = pInfo;
	rc = cl_gx_range_set(pRational,2,pm,0);
	pRational->pi_alen |= D_AULN_RATIONAL;
	return rc;
}

/****************************************/
/*	03									*/
/****************************************/
int cl_get_rational_mpa(pInfoParm,mpp)
tdtInfoParm *pInfoParm;
MPA *mpp[];
{
	int ret,len;
	char *p;

	ret = 0;
	if (mpp && pInfoParm->pi_attr==DEF_ZOK_DECI && (pInfoParm->pi_alen & D_AULN_RATIONAL)) {
		len = pInfoParm->pi_dlen;
		p = pInfoParm->pi_data;
		mpp[0] = (MPA *)p;
		p += len;
		mpp[1] = (MPA *)p;
	}
	else ret = -215260301;
	return ret;
}
/* 04 */
/********************************************************/
/*	DECI�̂Ƃ�											*/
/*		RATIONAL�̂Ƃ�									*/
/*			mp3==NULL : pInfoParm�������ɕϊ�����	(1)	*/
/*			mp3<>NULL : �ϊ�����������mp3�ɕԂ�		(2)	*/
/*		RATIONAL�łȂ��Ƃ�								*/
/*			mp3==NULL : �������Ȃ�					(0)	*/
/*			mp3<>NULL : pInfoParm->pi_data��mp3�ɕԂ�(3)*/
/*	DECI�łȂ��Ƃ�										*/
/*		�������Ȃ�									(0)	*/
/*	�ԋp : < 0 : �G���[									*/
/*		   >=0 : ()��									*/
/********************************************************/
int cl_rational_conv_real(mp3,pInfoParm)
MPA *mp3;
tdtInfoParm *pInfoParm;
{
	MPA *mpp[2],*m1,*m2,*m3,mp3z;
	int ret,len;
	char *p;

	ret = 0;
	if (pInfoParm->pi_attr == DEF_ZOK_DECI) {
		m3 = mp3;
		if (pInfoParm->pi_alen & D_AULN_RATIONAL) {
			if (!(ret=cl_get_rational_mpa(pInfoParm,mpp))) {
				if (!m3) m3 = (MPA *)cl_get_tmpMPA(&mp3z);
				if (!(ret=m_div(m3,mpp[0],mpp[1]))) {
					ret = 2;
					if (!mp3) {
						m_cpy(mpp[0],m3,0);
						pInfoParm->pi_alen &= ~(D_AULN_RANGE_DATA | D_AULN_RATIONAL);
						ret = 1;
					}
				}
			}
		}
		else if (m3) {
			m_cpy(m3,(MPA *)pInfoParm->pi_data,0);
			ret = 3;
		}
	}
/*
printf("cl_rational_conv_real: ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*	05									*/
/****************************************/
int cl_rational_to_real(pInfoParmW,pInfoParm)
tdtInfoParm *pInfoParmW,*pInfoParm;
{
	MPA *mp3,mp3z;
	int ret;

	ret = 0;
	if (pInfoParm->pi_attr==DEF_ZOK_DECI && pInfoParm->pi_alen & D_AULN_RATIONAL) {
		mp3 = (MPA *)cl_get_tmpMPA(&mp3z);
		if ((ret=cl_rational_conv_real(mp3,pInfoParm)) > 1) {
			ret = 0;
			ret = cl_set_parm_mpa(pInfoParmW,mp3);
		}
		else if (!ret || ret==1) ret = -215260501;
	}
	else cl_gx_copy_info(pInfoParmW,pInfoParm);
	return ret;
}

/****************************************/
/*	06									*/
/****************************************/
static int _cmpt_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	/* ���q(Numerator)/����(Denominator) */
	tdtInfoParm *pRational,tInfo,*ppParm[3],tNumer,tDenom;
	tdtInfoParm *pInfo1,*pInfo2;
	int ret,iRATIONAL1,iRATIONAL2,cmp_no,result,i;
	char op;
	MPA *mp,*mpp1[2],*mpp2[2];
	MPA *m0,*m1,*m2,*m3,m0z,m1z,m2z,m3z;

DEBUGOUTL1(120,"_cmpt_rational: pOperator=[%s]",pOperator);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_cmpt_rational: Enter pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                      pInfoParm2=",pInfoParm2,0,0);

	iRATIONAL1 = pInfoParm1->pi_alen & D_AULN_RATIONAL;
	iRATIONAL2 = pInfoParm2->pi_alen & D_AULN_RATIONAL;
	op = *pOperator;
	pInfo1 = pInfoParm1;
	pInfo2 = pInfoParm2;
	if (!iRATIONAL1) {
		pRational = &tNumer;
		if ((ret=_set_rational(pRational,pInfoParm1)) < 0) return ret;
		pInfo1 = pRational;
	}
	if (pInfoParm1 == pInfoParm2)
		pInfo2 = pInfo1;
	else {
		if (!iRATIONAL2) {
			pRational = &tDenom;
			if ((ret=_set_rational(pRational,pInfoParm2)) < 0) return ret;
			pInfo2 = pRational;
		}
	}

	m0 = (MPA *)cl_get_tmpMPA(&m0z);
	m1 = (MPA *)cl_get_tmpMPA(&m1z);
	m2 = (MPA *)cl_get_tmpMPA(&m2z);
	m3 = (MPA *)cl_get_tmpMPA(&m3z);

	if ((ret=cl_get_rational_mpa(pInfo1,mpp1)) < 0) return ret;
	if ((ret=cl_get_rational_mpa(pInfo2,mpp2)) < 0) return ret;
	/* a/b : mpp1[0]/mpp1[1] */
	/* c/d : mpp2[0]/mpp2[1] */
	if (op=='+' || op=='-') {	/* (a/b)+-(c/d)=(a*d+c*b)/(b*d) */
		/* a*d */
		if ((ret=m_mul(m2,mpp1[0],mpp2[1])) < 0) return ret;
		/* c*b */
		if ((ret=m_mul(m3,mpp2[0],mpp1[1])) < 0) return ret;
		/* a*d+c*b */
		if (op == '+') {
			if ((ret=m_add(m0,m2,m3)) < 0) return ret;
		}
		else {
			if ((ret=m_sub(m0,m2,m3)) < 0) return ret;
		}
		/* b*d */
		if ((ret=m_mul(m1,mpp1[1],mpp2[1])) < 0) return ret;
	}
	else if (op == '*') {	/* a*c / b*d */
		/* a*c */
		if ((ret=m_mul(m0,mpp1[0],mpp2[0])) < 0) return ret;
		/* b*d */
		if ((ret=m_mul(m1,mpp1[1],mpp2[1])) < 0) return ret;
	}
	else if (op == '/') {	/* a*d / b*c */
		/* a*d */
		if ((ret=m_mul(m0,mpp1[0],mpp2[1])) < 0) return ret;
		/* b*c */
		if ((ret=m_mul(m1,mpp1[1],mpp2[0])) < 0) return ret;
	}
	else {
		if ((cmp_no=_get_comp_no(pOperator,0)) > 0) {
			/* (a/b)-(c/d) */
			/* a*d */
			if ((ret=m_mul(m2,mpp1[0],mpp2[1])) < 0) return ret;
			/* c*b */
			if ((ret=m_mul(m3,mpp2[0],mpp1[1])) < 0) return ret;
			/* a*d-c*b */
			if ((ret=m_sub(m0,m2,m3)) < 0) return ret;
			if (m0->zero) result = 0;
			else if (m0->sign) result = -1;
			else result = 1;
			i = cl_get_comp_judge(cmp_no,result);
/*
printf("_cmpt_rational: cmp_no=%d result=%d i=%d\n",cmp_no,result,i);
*/
			cl_set_parm_int(pInfoParmW,i);
			return 0;
		}
	}
	/* �L�������� */
	ret = cl_set_parm_mpa2(&tNumer,m0,'P');
	ret = cl_set_parm_mpa2(&tDenom,m1,'P');
	ppParm[0] = &tNumer;
	ppParm[1] = &tDenom;
	ret = cl_adjust_rational(pInfoParmW,ppParm,0);
/*
printf("_cmpt_rational:Exit ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*	07	** ��p							*/
/****************************************/
static int _rational_power(pInfoParmW,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	tdtInfoParm *ppParm[3],tNumer,tDenom;
	int ret,i,iVal,sig1,sig2;
	MPA *mp,*mpp1[2];
	MPA *m0,*m1,m0z,m1z;

	cl_get_parm_bin(pInfoParm2,&iVal,"_rational_power");

	if ((ret=cl_get_rational_mpa(pInfoParm1,mpp1)) < 0) return ret;
	if (mpp1[0]->zero) {
		return cl_set_parm_mpa(pInfoParmW,mpp1[0]);
	}
	else {
		m0 = m_get_i(1);
		if (m_is_mpa1a(mpp1[0]) && m_is_mpa1a(mpp1[1])) {
			sig1 = mpp1[0]->sign;
			sig2 = mpp1[1]->sign;
			if ((sig1 && !sig2) || (!sig1 && sig2)) {
				if (iVal & 0x01) sig1 = 1;
				else sig1 = 0;
				mpp1[0]->sign = sig1;
				mpp1[1]->sign = 0;
			}
			cl_gx_copy_info(pInfoParmW,pInfoParm1);
			return 0;
		}
	}

	if (!iVal) {
		m1 = m0;
	}
	else {
		if (iVal < 0) {
			m1 = mpp1[1];
			mpp1[1] = mpp1[0];
			mpp1[0] = m1;
			iVal = -iVal;
		}
		m0 = (MPA *)cl_get_tmpMPA(&m0z);
		m1 = (MPA *)cl_get_tmpMPA(&m1z);
		m_cpy(m0,mpp1[0],0);
		m_cpy(m1,mpp1[1],0);
		for (i=0;i<iVal-1;i++) {
			m_mul1(m0,mpp1[0]);
			m_mul1(m1,mpp1[1]);
		}
	}
	/* �L�������� */
	ret = cl_set_parm_mpa2(&tNumer,m0,'P');
	ret = cl_set_parm_mpa2(&tDenom,m1,'P');
	ppParm[0] = &tNumer;
	ppParm[1] = &tDenom;
	ret = cl_adjust_rational(pInfoParmW,ppParm,0);
	return ret;
}

/****************************************/
/*	08	abs ��p						*/
/****************************************/
static int _rational_abs(pInfoParmW,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	MPA *mpp[2];
	tdtInfoParm tInfo1,tInfo2,*ppParm[2];
	int ret;

	ppParm[0] = &tInfo1;
	ppParm[1] = &tInfo2;
	ret=cl_get_rational_mpa(pInfoParm2,mpp);
	mpp[0]->sign = 0;
	mpp[1]->sign = 0;
	ret = cl_set_parm_mpa2(ppParm[0] ,mpp[0],'P');
	ret = cl_set_parm_mpa2(ppParm[1] ,mpp[1],'P');
	ret = cl_adjust_rational(pInfoParmW,ppParm,0);
	return ret;
}

/****************************************/
/*	09									*/
/****************************************/
int cl_cmpt_math_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char *pOperator;
tdtInfoParm *pInfoParm1,*pInfoParm2;
{
	int ret,iParm[5],ope,iREAL;
	long lValz[NMPA_LONG],*lVal;
	char op;
	tdtInfoParm InfoParm1,InfoParm2;

DEBUGOUTL2(120,"cl_cmpt_math_rational: pInfoParmW=%08x pOperator=[%s]",pInfoParmW,pOperator);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_cmpt_math_rational: Enter pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                             pInfoParm2=",pInfoParm2,0,0);

	if (pInfoParm1->pi_attr==DEF_ZOK_FLOA || pInfoParm2->pi_attr==DEF_ZOK_FLOA) {
		iREAL = 1;
	}
	else {
		iREAL = 0;
		op = *pOperator;
		ope = 0;
		if (op=='+' || op=='-' || (op=='*' && pOperator[1]!='*') || op=='/') {
			ret = _cmpt_rational(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
		}
		else if (op=='*' && pOperator[1]=='*' && pInfoParm2->pi_attr==DEF_ZOK_BINA) {
			ret = _rational_power(pInfoParmW,pInfoParm1,pInfoParm2);
		}
		else if (!stricmp(pOperator,"ABS")) {
			ret = _rational_abs(pInfoParmW,pInfoParm1,pInfoParm2);
		}
		else {
			iREAL = 1;
		}
	}
	if (iREAL) {
		if (pInfoParm1->pi_alen & D_AULN_RATIONAL) {
			if ((ret=cl_rational_to_real(&InfoParm1,pInfoParm1)) < 0) return ret;
			pInfoParm1 = &InfoParm1;
		}
		if (pInfoParm2->pi_alen & D_AULN_RATIONAL) {
			if ((ret=cl_rational_to_real(&InfoParm2,pInfoParm2)) < 0) return ret;
			pInfoParm2 = &InfoParm2;
		}
		ret = cl_cmpt_math_real(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
	}

	return ret;
}

/****************************************/
/*	10									*/
/****************************************/
int cl_rational_comp(ppAns,pOperator,opr,pInfoParm1,pInfoParm2)
char **ppAns,*pOperator;
int opr;
tdtInfoParm *pInfoParm1,*pInfoParm2;
{
	tdtInfoParm tInfoParmW;
	char *pStr;
	long *pAns;
	int ret;

	if ((ret=_cmpt_rational(&tInfoParmW,pOperator,pInfoParm1,pInfoParm2)) >= 0) {
		pStr = *ppAns;
		pAns = (long *)pStr;
		cl_get_parm_long(&tInfoParmW,pAns,"RATIONAL_COMP");
		ret = DEF_ZOK_BINA;
	}
	return ret;
}

/****************************************/
/*	11									*/
/****************************************/
int cl_func_rational(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm **ppParm;
{
	static char *_fn_="cl_func_rational";
	int i,rc,atr1,atr2,iAttr1[5],atr,n;
	long Val1z[NMPA_LONG*2+1],*Val1;
	double dVal1;
	char *p;
	tdtInfoParm *pInfo1,*pInfo2,tInfoParm[2],*ppInfo[2];

	rc = 0;
	pInfo1 = ppParm[0];
	if (pInfo1->pi_alen & D_AULN_RATIONAL) rc = -1;
	if (nparm >= 2) {
		pInfo2 = ppParm[1];
		if (pInfo2->pi_alen & D_AULN_RATIONAL) rc = -1;
	}
	if (rc < 0) {
		ERROROUT2(FORMAT(318),_fn_,FORMAT(673));	/*%s: %s�͎g�p�ł��܂���B*//* �L���� */
		return ECL_SCRIPT_ERROR;
	}
	atr2 = pInfo2->pi_attr;
	Val1 = cl_get_tmpMPA(Val1z);
	p = "val1:";
	if ((n=nparm) > 2) n = 2;
	for (i=0;i<n;i++) {
		if ((rc=cl_get_parm_dec(ppParm[i],Val1,p)) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		ppInfo[i] = &tInfoParm[i];
		rc = cl_set_parm_mpa(ppInfo[i],(MPA *)Val1);
		p = "val2:";
	}
	if (n == 1) {
		ppInfo[1] = &tInfoParm[1];
		rc = cl_set_parm_mpa(ppInfo[1],m_get_i(1));
	}
	else if (cl_is_zero(ppInfo[1])) {
		_divide_by_zero();
		return ECL_SCRIPT_ERROR;
	}
	if ((rc=cl_adjust_rational(pInfoParmW,ppInfo,1)) < 0) return rc;
	return rc;
}

/****************************************/
/*	21									*/
/****************************************/
static int _yakubun(m1,m1div,m2,m2div,myaku)
MPA *m1,*m1div,*m2,*m2div,*myaku;
{
	int rc,mod;
	MPA *m3,mp3z;

	mod = 0;
	m3 = (MPA *)cl_get_tmpMPA(&mp3z);
	if (m1) {
		if ((rc=m_mod2(m3,m1div,m1,myaku)) < 0) return rc;
	}
	else {
		m_cpy(m3,m_get_i(0),0);
		m_cpy(m1div,m_get_i(1),0);
	}
	if (m3->zero) {
		if ((rc=m_mod2(m3,m2div,m2,myaku)) < 0) return rc;
/*
printf("_yakubun: m3->zero=%d\n",m3->zero);
*/
		if (m3->zero) {
			mod = 1;
		}
	}
	return mod;
}

/****************************************/
/*	22									*/
/****************************************/
static int _yakubun_long(mdiva,m1,m2,yaku)
long mdiva[],m1,m2,yaku;
{
	int rc,mod;
	long m3;

	mod = 0;
	if (m1) {
		rc = 0;
		if (!(m1 % yaku)) {
			mdiva[0] = m1 / yaku;
			rc = 1;
		}
	}
	else {
		mdiva[0] = 1;
		rc = 1;
	}
	if (rc) {
		rc = 0;
		if (!(m2 % yaku)) {
			mdiva[1] = m2 / yaku;
			rc = 1;
		}
/*
printf("_yakubun_long: rc=%d\n",rc);
*/
		if (rc) {
			mod = 1;
		}
	}
	return mod;
}

/****************************************/
/*	23									*/
/****************************************/
static int _set_msq(m1sq,sosu_mpa,max_size_mpa,m1)
MPA *m1sq,*sosu_mpa,*m1;
int max_size_mpa;
{
	int ret;
	double dval;
	MPA *m3,mp3z;
	char buf[128];

	ret = 0;
	m3 = (MPA *)cl_get_tmpMPA(&mp3z);
	m_mpa2d(m1,&dval);
	if (dval >= 4.0) {
		dval = sqrt(dval);
		m_d2mpa(dval,m3);
/*
m_mpa2an(m3,buf,sizeof(buf),0);
printf("_set_msq: dval=%f m3=[%s]\n",dval,buf);
*/
		ret = akxg_sosu_over_mpa_by_tbl(m1sq,sosu_mpa,max_size_mpa,m3);
		if (!ret) {
			m_scale(m3,m_get_nmpa10(),0,2);
			m_cpy(m1sq,m3,0);
		}
/*
m_mpa2an(m1sq,buf,sizeof(buf),0);
printf("_set_msq: ret=%d m1sq=[%s]\n",ret,buf);
*/
	}
	else m_cpy(m1sq,m1,0);
	return 0;
}

/****************************************/
/*	24									*/
/****************************************/
static long _set_msq_long(sosu,max_size,m1)
long *sosu,m1;
int max_size;
{
	double dval;
	long m1sq,m3;

	if (m1 >= 4) {
		dval = m1;
		m1sq = sqrt(dval);
		if (m3=akxg_sosu_over_by_tbl(sosu,max_size,m1sq)) m1sq = m3;
	}
	else m1sq = m1;
	return m1sq;
}
/* 25 */
/********************************************************/
/*	opt = 0 : 100���������̐��ł͖񕪂��Ȃ�				*/
/*		  1 : �f����MAX_CHK_SOSU_NUM�܂Ŗ񕪂���		*/
/*		  2 : �f����MAX_CHK_SOSU_NUM_MAX�܂Ŗ񕪂���	*/
/*		      �������A���s���I�v�V�����Q��0x1000��ON��	*/
/*		      �Ƃ��́A�\���̂���f�����ׂĂŖ񕪂���	*/
/********************************************************/
static int _rational_reduction_long(la,opt)
long la[];
int opt;
{
	long m1,m2,m1sq,m2sq,msq,mdiva[2],m3,m1div,m2div;
	int rc,mod,n,k,k_b,ret,iNO_LIMIT;
	int max_sosu,kk,max_loop;
	long *sosu,yaku;
	double dval;

	m1 = la[0];
	m2 = la[1];
  if (m1>1 && m2>1) {
	if (opt) {
		if ((rc=akxg_sosu_next(0)) < 0) return rc;
		max_sosu = akxg_sosu_next_tbl(&sosu);
		if (opt == 2) max_loop = _get_loop_max();
		else max_loop = max_sosu + max_sosu;

		m1sq = _set_msq_long(sosu,max_sosu,m1);
		m2sq = _set_msq_long(sosu,max_sosu,m2);
		iNO_LIMIT = cl_get_option(2,0) & 0x1000;
		k = 0;
		k_b = -1;
		while (k < max_loop) {
			if (opt<=1 && k>=MAX_CHK_SOSU_NUM) break;
			if (m1==1 || m2==1) break;
			mod = ret = 0;
/*
printf("_rational_reduction: k=%d m1=%d m2=%d\n",k,m1,m2);
*/
			if (m1 <= m2) {
				/* m1���f�������ׂ� */
				if ((ret=akxg_sosu_chk_by_tbl(sosu,max_sosu,m1)) < 0) return ret;
				else if (ret > 0) {
/*
printf("_rational_reduction:m1 k=%d sosu_chk:ret=%d\n",k,ret);
*/
					if ((mod=_yakubun_long(mdiva,0,m2,m1)) < 0) return mod;
					else if (mod) {
						m1div = mdiva[0];
						m2div = mdiva[1];
					}
				}
/*
printf("_rational_reduction: k=%d m1sq=%d mod=%d\n",k,m1sq,mod);
*/
				msq = m1sq;
			}
			else {
				/* m2���f�������ׂ� */
				if ((ret=akxg_sosu_chk_by_tbl(sosu,max_sosu,m2)) < 0) return ret;
				else if (ret > 0) {
/*
printf("_rational_reduction:m2 k=%d sosu_chk:ret=%d\n",k,ret);
*/
					if ((mod=_yakubun_long(mdiva,0,m1,m2)) < 0) return mod;
					else if (mod) {
						m2div = mdiva[0];
						m1div = mdiva[1];
					}
				}
/*
printf("_rational_reduction: k=%d m2sq=%d mod=%d\n",k,m2sq,mod);
*/
				msq = m2sq;
			}
			if (!mod) {
				if (k > k_b) {
					if ((yaku=akxg_sosu_next(-1)) < 0) return yaku;
					else if (!yaku) break;
					max_sosu = akxg_sosu_next_tbl(&sosu);
				}
				if (msq == m1sq) {
					if ((mod=_yakubun_long(mdiva,m1,m2,yaku)) < 0) return mod;
					m1div = mdiva[0];
					m2div = mdiva[1];
				}
				else {
					if ((mod=_yakubun_long(mdiva,m2,m1,yaku)) < 0) return mod;
					m2div = mdiva[0];
					m1div = mdiva[1];
				}
/*
printf("_rational_reduction: k_b=%d k=%d mod=%d yaku=%d\n",k_b,k,mod,yaku);
*/
			}
			if (mod) {
				m1 = m1div;
				m2 = m2div;
				m1sq = _set_msq_long(sosu,max_sosu,m1);
				m2sq = _set_msq_long(sosu,max_sosu,m2);
				k_b = k;
			}
			else {
				k_b = k;
				k++;
/*
printf("_rational_reduction: k=%d yaku=%d msq=%d\n",k,yaku,msq);
*/
				if ((!iNO_LIMIT && k>=MAX_CHK_SOSU_NUM_MAX) || yaku>msq) {
/*
printf("_rational_reduction: k=%d yaku=%d msq=%d\n",k,yaku,msq);
*/
					break;
				}
			}
		}
/*
printf("_rational_reduction: max_sosu=%d k=%d yaku=%d msq=%d\n",max_sosu,k,yaku,msq);
*/
		la[0] = m1;
		la[1] = m2;
	}
  }
	return rc;
}

/* 26 */
/********************************************************/
/*	opt : _rational_reduction_long �Ɠ���				*/
/********************************************************/
static int _rational_reduction(mpp,opt)
MPA *mpp[];
int opt;
{
	MPA *m1,*m2,*m3,*m4,*m1div,*m2div,*myaku,*m1sq,*m2sq,*msq;
	MPA mp3z,mp4z,mp1divz,mp2divz,mpyakuz,*sosu_mpa,m1sqz,m2sqz;
	int rc,mod,n,k,sig,exp1,exp2,len1,len2,sa1,sa2,d1,d2,ret;
	int max_sosu,max_loop,max_sosu_mpa,k_b,iNO_LIMIT;
	long *sosu,yakul,la[2];
	double dval;
	char buf1[128],buf2[128];

	m1 = mpp[0];
	if (m1->zero) return 0;

	m2 = mpp[1];
	if (m2->zero) {
		_divide_by_zero();
		return ECL_SCRIPT_ERROR;
	}

	rc = 0;
	if (m2->sign) {
		m2->sign = 0;
		m1->sign = 1 - m1->sign;
	}
	sig = m1->sign;
	m1->sign = 0;

	if (m_is_mpa1a(m1) || m_is_mpa1a(m2)) {
		m1->sign = sig;
		return 0;
	}
/*  if (opt) {	*/
	exp2 = m2->exp;
	len2 = m2->len;
/*
printf("_rational_reduction: exp2=%d len2=%d\n",exp2,len2);
*/
	if ((sa2=len2-exp2-1) > 0) {
		m1->exp += sa2;
		m2->exp += sa2;
	}
	exp1 = m1->exp;
	len1 = m1->len;
/*
printf("_rational_reduction: exp1=%d len1=%d\n",exp1,len1);
*/
	if ((sa1=len1-exp1-1) > 0) {
		m1->exp += sa1;
		m2->exp += sa1;
	}
	if (sa1<0 && sa2<0 && sa1!=sa2) {
/*
printf("_rational_reduction: sa1=%d sa2=%d\n",sa1,sa2);
*/
		if (sa1 < sa2) sa1 = sa2;
		m1->exp += sa1;
		m2->exp += sa1;
	}
	if (!m_is_mpa1a(m1) && !m_is_mpa1a(m2)) {
	  if (opt) {
#if 1
		ret = 0;
		if (m_cmp_a(m1,m2) >= 0) {
			if (m_cmp_a(m1,m_get_LONGMAX(0)) <= 0) ret = 1;
		}
		else {
			if (m_cmp_a(m2,m_get_LONGMAX(0)) <= 0) ret = 1;
		}
		if (ret) {
			m_mpa2l(m1,&la[0]);
			m_mpa2l(m2,&la[1]);
			if ((ret=_rational_reduction_long(la,opt)) < 0) return ret;
			m_l2mpa(la[0],m1);
			m_l2mpa(la[1],m2);
			m1->sign = sig;
			return 0;
		}
#endif
		if ((rc=akxg_sosu_next_mpa(0,NULL)) < 0) return rc;
		max_sosu_mpa = akxg_sosu_next_mpa_tbl(&sosu_mpa);
		if (opt <= 1) max_loop = max_sosu_mpa + max_sosu_mpa;
		else max_loop = _get_loop_max();

		m1div = (MPA *)cl_get_tmpMPA(&mp1divz);
		m2div = (MPA *)cl_get_tmpMPA(&mp2divz);
		myaku = (MPA *)cl_get_tmpMPA(&mpyakuz);
		m1sq = (MPA *)cl_get_tmpMPA(&m1sqz);
		m2sq = (MPA *)cl_get_tmpMPA(&m2sqz);
		m3 = (MPA *)cl_get_tmpMPA(&mp3z);

		_set_msq(m1sq,sosu_mpa,max_sosu_mpa,m1);
		_set_msq(m2sq,sosu_mpa,max_sosu_mpa,m2);
		iNO_LIMIT = cl_get_option(2,0) & 0x1000;
		k = 0;
		k_b = -1;
		while (k < max_loop) {
			if (opt<=1 && k>=MAX_CHK_SOSU_NUM) break;
/*
m_mpa2an(m1,buf1,sizeof(buf1),0);
m_mpa2an(m2,buf2,sizeof(buf2),0);
printf("_rational_reduction: k_b=%d k=%d m1=[%s] m2=[%s]\n",k_b,k,buf1,buf2);
*/
			if (m_is_mpa1a(m1) || m_is_mpa1a(m2)) break;
			mod = ret = 0;
			if (m_cmp_a(m1,m2) <= 0) {
				/* m1���f�������ׂ� */
				if ((ret=akxg_sosu_chk_mpa_by_tbl(sosu_mpa,max_sosu_mpa,m1)) < 0) return ret;
				else if (ret > 0) {
/*
printf("_rational_reduction:m1 k=%d sosu_chk:ret=%d\n",k,ret);
*/
					if ((mod=_yakubun(NULL,m1div,m2,m2div,m1)) < 0) return mod;
				}
/*
printf("_rational_reduction: k=%d yaku=%d m1sq=%d mod=%d\n",k,yaku,m1sq,mod);
*/
				msq = m1sq;
			}
			else {
				/* m2���f�������ׂ� */
				if ((ret=akxg_sosu_chk_mpa_by_tbl(sosu_mpa,max_sosu_mpa,m2)) < 0) return ret;
				else if (ret > 0) {
/*
printf("_rational_reduction:m2 k=%d sosu_chk:ret=%d\n",k,ret);
*/
					if ((mod=_yakubun(NULL,m2div,m1,m1div,m2)) < 0) return mod;
				}
/*
printf("_rational_reduction: k=%d yaku=%d m2sq=%d mod=%d\n",k,yaku,m2sq,mod);
*/
				msq = m2sq;
			}
			if (!mod) {
				if (k > k_b) {
					if ((ret=akxg_sosu_next_mpa(-1,myaku)) < 0) return ret;
					else if (!ret) break;
					max_sosu_mpa = akxg_sosu_next_mpa_tbl(&sosu_mpa);
				}
				if (msq == m1sq) {
					if ((mod=_yakubun(m1,m1div,m2,m2div,myaku)) < 0) return mod;
				}
				else {
					if ((mod=_yakubun(m2,m2div,m1,m1div,myaku)) < 0) return mod;
				}
/*
m_mpa2an(myaku,buf1,sizeof(buf1),0);
printf("_rational_reduction: k_b=%d k=%d mod=%d myaku=[%s]\n",k_b,k,mod,buf1);
*/
			}
			if (mod) {
				m_cpy(m1,m1div,0);
				m_cpy(m2,m2div,0);
				_set_msq(m1sq,sosu_mpa,max_sosu_mpa,m1);
				_set_msq(m2sq,sosu_mpa,max_sosu_mpa,m2);
				k_b = k;
			}
			else {
				k_b = k;
				k++;
/*
m_mpa2an(myaku,buf1,sizeof(buf1),0);
m_mpa2an(msq,buf2,sizeof(buf2),0);
printf("_rational_reduction: k=%d myaku=[%s] msq=[%s]\n",k,buf1,buf2);
*/
				if ((!iNO_LIMIT && k>=MAX_CHK_SOSU_NUM_MAX) || m_cmp(myaku,msq)>0) {
/*
m_mpa2an(myaku,buf1,sizeof(buf1),0);
m_mpa2an(msq,buf2,sizeof(buf2),0);
printf("_rational_reduction: k=%d myaku=[%s] msq=[%s]\n",k,buf1,buf2);
*/
					break;
				}
			}
		}
/*
printf("_rational_reduction: max_sosu=%d k=%d yaku=%d msq=%d\n",max_sosu,k,yaku,msq);
*/
	  }
	}
/*  }	*/
	m1->sign = sig;
	return rc;
}
/* 27 */
/********************************************************/
/*	opt : _rational_reduction_long �Ɠ���				*/
/********************************************************/
int cl_adjust_rational(pInfoParmW,ppInfo,opt)
tdtInfoParm *pInfoParmW,*ppInfo[];
int opt;
{
	MPA *m1,*m2,*mpp[2];
	int rc;

	m1 = (MPA *)ppInfo[0]->pi_data;
	if (m1->zero) {
		return cl_set_parm_mpa(pInfoParmW,m1);
	}
	m2 = (MPA *)ppInfo[1]->pi_data;
	if (m2->zero) {
		_divide_by_zero();
		return ECL_SCRIPT_ERROR;
	}
	mpp[0] = m1;
	mpp[1] = m2;
	if ((rc=_rational_reduction(mpp,opt)) >= 0) {
		rc = cl_gx_range_set(pInfoParmW,2,ppInfo,0);
		if (opt >= 1) opt = D_AULN_RAT_YAKUBUN;
		pInfoParmW->pi_alen |= D_AULN_RATIONAL | opt;
	}
	return rc;
}

/****************************************/
/*	28									*/
/****************************************/
int cl_rational_yakubun(pInfoParmW,pInfoParm)
tdtInfoParm *pInfoParmW,*pInfoParm;
{
	tdtInfoParm *ppParm[3],tInfo1,tInfo2,tInfo3;
	int ret,iVal[2],opt,alen;
/*
printf("cl_rational_yakubun: pInfoParm1->pi_alen=%04x\n",pInfoParm1->pi_alen);
*/
	ret = 0;
	if (pInfoParm->pi_id==' ' && pInfoParm->pi_attr==DEF_ZOK_DECI) {
		alen = pInfoParm->pi_alen;
		if ((alen & D_AULN_RANGE_DATA) && (alen & D_AULN_RATIONAL)) {
			if (alen & D_AULN_RAT_YAKUBUN) opt = 0;
			else opt = 1;
			ppParm[0] = &tInfo1;
			ppParm[1] = &tInfo2;
			ppParm[2] = &tInfo3;
			if ((ret=cl_get_range_info(pInfoParm,ppParm,iVal,0)) >= 0) {
				/* �L�������� */
				ppParm[0] = &tInfo1;
				ppParm[1] = &tInfo2;
				if ((ret=cl_adjust_rational(pInfoParmW,ppParm,opt)) >= 0) ret = 1;
			}
		}
	}
	return ret;
}

/****************************************/
/*	29									*/
/****************************************/
int cl_func_reduction(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm **ppParm;
{
	tdtInfoParm *pInfoParm;
	MPA *mpp[2];
	int ret;
/*
printf("cl_rational_yakubun: pInfoParm1->pi_alen=%04x\n",pInfoParm1->pi_alen);
*/
	ret = 0;
	pInfoParm = ppParm[0];
	if (pInfoParm->pi_attr==DEF_ZOK_DECI && pInfoParm->pi_alen & D_AULN_RATIONAL) {
		if ((ret=cl_get_rational_mpa(pInfoParm,mpp)) >= 0)
			ret = _rational_reduction(mpp,2);
	}
/*	cl_gx_copy_info(pInfoParmW,pInfoParm);	*/
	cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,0);
	return ret;
}
