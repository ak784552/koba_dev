static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �������                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_rep_set( pparmList , ppmList )               *
*                      (O)parmList  *pparmList                                *
*                      (I)prmList  *pprmList                                  *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern int giOptions[];
extern GlobalCt  *pGlobTable;
extern tdtIterate_ctl gtIter_ctl[];

static int _array_hash_clr();
static int _list_array_set();

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_set(pparmList ,pInfoParm)
parmList  *pparmList;
tdtInfoParm *pInfoParm;
{
	int		rc;
	ScrPrCT *pSPCT;
	tdtInfoParm *pInfoParmW;

	pSPCT = cl_search_src_ct();

	if (rc= cl_gx_get_info_parm(pSPCT,'s',pparmList,&pInfoParmW)) {
		return rc;
	}
	/* 2021.10.27 */
	return cl_gx_rep_info_als(pInfoParmW ,pInfoParm ,1);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_set_global( pparmList ,pInfoParm )
parmList  *pparmList;
tdtInfoParm *pInfoParm;
{
	/* %s: %s�ɂ͑���ł��܂���B */
	ERROROUT2(FORMAT(126),"cl_gx_rep_set_global",pparmList->prp);
	return ECL_SCRIPT_ERROR;
}

/****************************************/
/*										*/
/****************************************/
int _get_num_msg_no(pInfoParm,msg_no,opt,pix0)
tdtInfoParm *pInfoParm;
int msg_no,opt,*pix0;
{
	int iRc,ix0;

	iRc = -1;
	ix0 = 0;
	if (msg_no <= 0) msg_no = 577;	/* (%d)���s���ł��B */
	if (pInfoParm && pix0) {
		iRc = 0;
		if (pInfoParm->pi_dlen > 0) {
			if (iRc = cl_get_parm_bin(pInfoParm,&ix0,"_get_start_pos.ix0:")) return iRc;
			if (ix0 < 0) {
				ERROROUT1(FORMAT(msg_no),ix0);	/* �E�E�E(%d)���s���ł��B */
				iRc = -1;
			}
		}
		else if (opt & 0x01) iRc = C_NULL_PARM;
		*pix0 = ix0;
	}
/*
printf("_get_num_msg_no: ix0=%d iRc=%d\n",ix0,iRc);
*/
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info(nparm,ppParm,pIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	iRc = _get_array_info_ref(nparm,ppParm,&pIndexW,ppTBL,iParm,opt);
	if (!iRc || iRc==2000) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/********1*********2*********3*********4*********5*********7*/
/*	����: nparm    : ppParm�̐� (>=2)						*/
/*		  ppParm   : tdtInfoParm�̃|�C���^�z��				*/
/*						ppParm[0] : ���ׂ�Ώ�				*/
/*						ppParm[1] : �J�n�ʒu				*/
/*						ppParm[2]�ڍs�͔C��					*/
/*		  ppIndex  : �z�����Ԃ�							*/
/*					 *ppIndex �ɂ́A&tIndex ���ݒ肳���	*/
/*						���邱��(�㏑������Ȃ�)			*/
/*					 *ppIndex �ɂ́AA or R �̂Ƃ��A�z���	*/
/*						pIndex���Ԃ����(�㏑�������)		*/
/*		  ppTBL    : <>NULL�̂Ƃ��A							*/
/*					 MappIndex(A)�̔z���ւ̃|�C���^���Ԃ�	*/
/*					 A�łȂ��Ƃ��́ANULL��Ԃ�				*/
/*		  iParm    : <>NULL�̂Ƃ��Aindex����Ԃ��z��		*/
/*					 iParm[0] : �J�n�ʒu(nparm<=1�̂Ƃ���0)	*/
/*					 iParm[1] : �ő�v�f�� - �J�n�ʒu		*/
/*					 iParm[2] : off_set + �J�n�ʒu			*/
/*					 iParm[3] : �J�n�ʒu����ݒ�ςݗv�f��	*/
/*								 �ő�ʒu�܂ł̗v�f��		*/
/*		  opt      : �I�v�V����								*/
/*						0x01 : �n�b�V���z����G���[�Ƃ��Ȃ�	*/
/*						0x02 : %��#�̔z����G���[�Ƃ���		*/
/* �ԋp : 0   : ����										*/
/*		  200 : �n�b�V���z��								*/
/*		  <0  : �G���[										*/
/************************************************************/
int _get_array_info_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtInfoParm *pInfoParm;
	int iRc,ix0,*index;
	XHASHB *xhp;
	tdtArrayIndex *pIndex;

	if (nparm<=0 || !ppParm || !ppIndex) return -1;
	pInfoParm = ppParm[0];
	if (opt & 0x02) {
		if (iRc = cl_check_use_mapped_array(pInfoParm)) return iRc;
	}
	pIndex = *ppIndex;
/*
printf("_get_array_info_ref:1 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	if (iRc = cl_get_array_info_ref(pInfoParm,ppIndex,ppTBL,iParm)) return iRc;
	pIndex = *ppIndex;
/*
printf("_get_array_info_ref:2 pIndex=%08x Index=%08x\n",pIndex,pIndex->index);
*/
	if ((opt & 0x01) && pIndex->xhp) {
		if (iParm) iParm[0] = 0;		/* �J�n�ʒu */
		return 2000;
	}
	else if (iRc = cl_check_use_hash_array(pInfoParm,pIndex)) return iRc;

	ix0 = 0;
	if (nparm >= 2) {
		if (iRc = _get_num_msg_no(ppParm[1],222,0,&ix0)) return iRc;
	}
/*
printf("_get_array_info_ref:3 ix0=%d iParm[1]..[3]=%d %d %d\n",ix0,iParm[1],iParm[2],iParm[3]);
*/
	if (iParm) {
		iParm[0] = ix0;		/* �J�n�ʒu */
		iParm[1] -= ix0;	/* �ő�v�f�� - �J�n�ʒu */
		iParm[3] = iParm[3] - iParm[2] + 1 - ix0;	/* �J�n�ʒu����ݒ�ςݗv�f�̐擪����̍ő�ʒu�܂ł̗v�f�� */
		iParm[2] += ix0;	/* off_set + �J�n�ʒu */
/*
printf("_get_array_info_ref:4 ix0=%d iParm[1]..[3]=%d %d %d\n",ix0,iParm[1],iParm[2],iParm[3]);
*/
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info_used_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtInfoParm ***pTBL,*pInfoParm;
	int iRc,*pSize;
	char c;

	if (iRc = _get_array_info_ref(nparm,ppParm,ppIndex,ppTBL,iParm,opt)) return iRc;
	pInfoParm = ppParm[0];
	c = pInfoParm->pi_id;
/*
printf("_get_array_info_used: c=[%c] iParm[0]..[3] =%d %d %d %d\n",c,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
	if (c!='R' && c!='A') {
		if (ppTBL) {
			pTBL = *ppTBL;
			pSize = (int *)pTBL[0];
			iParm[3] = pSize[7] - (iParm[2] - 1);	/* 6-->7 2020.4.30 *//* 1-->3 2021.5.9 */
		}
	}
DEBUGOUTL4(194,"_get_array_info_used: iParm[0]..[3] =%d %d %d %d",iParm[0],iParm[1],iParm[2],iParm[3]);
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _get_array_info_used(nparm,ppParm,pIndex,ppTBL,iParm,opt)
int  nparm;
tdtInfoParm *ppParm[];
tdtArrayIndex *pIndex;
tdtInfoParm ****ppTBL;
int iParm[],opt;
{
	tdtArrayIndex *pIndexW;
	int iRc;

	pIndexW = pIndex;
	iRc = _get_array_info_used_ref(nparm,ppParm,&pIndexW,ppTBL,iParm,opt);
	if (!iRc || iRc==2000) {
		if (pIndexW != pIndex) memcpy(pIndex,pIndexW,sizeof(tdtArrayIndex));
	}
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _get_array_num(nparm,ppParm,nm1,pNum)
int  nparm;
tdtInfoParm *ppParm[];
int nm1,*pNum;
{
	tdtInfoParm *pInfoParm;
	int nm,iRc;

	nm = nm1;
/*
printf("_get_array_num: nparm=%d nm1=%d nm=%d\n",nparm,nm1,nm);
*/
	if (nparm >= 1) {
		if ((iRc=_get_num_msg_no(ppParm[0],223,0x01,&nm)) == C_NULL_PARM) nm = nm1;
		else if (iRc) return iRc;
		else if (nm1>0 && nm>nm1) {
			if (cl_get_option(22,0) & 0x01) {
					/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
				ERROROUT2(FORMAT(224),nm,nm1);
			}
			nm = nm1;
		}
	}
	*pNum = nm;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_array_ix(pWork,nparm,ppParm,s_ix)
char *pWork;
int  nparm,s_ix;
tdtInfoParm *ppParm[];
{
	static char *_fn_="cl_set_array";
	tdtInfoParm *pInfoParm,*pInfoParmW,tInfoParm,**ppParmW,*pInfoP;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix0,ix,nm,count,len,attr,nset,ii,type,iCOMPLEX,num,ii_s;
	char c,*name,*p1;
	tdtArrayIndex *pIndex,tIndex;
	int *index,iParm[4];
	tdtDefType *pDeftype;

	if (s_ix < 0) s_ix = 0;
	nm = 0;
	memcpy(pWork,&nm,sizeof(int));

	/* 2023.12.17 */
	nm = nparm - 1;
	pIndex = &tIndex;

DEBUGOUTL4(170,"%s:Enter pIndex=%08x Index=%08x",_fn_,nm,pIndex,pIndex->index);

	/* 2023.12.17 */
	iRc = _get_array_info_ref(1,ppParm,&pIndex,&pTBL,iParm,3);
	if (iRc == 2000) {
		if (!s_ix) {
			if (iRc=_array_hash_clr(ppParm[0]->pi_data)) return iRc;
		}
		for (i=count=0;i<nm;i+=2) {
			/* 2023.12.17 */
			if ((len=parm_to_char_tmp(ppParm[i+1],&p1,0)) < 0) return len;
			else if (len > 0) {
				if (i+1 >= nm) {
					pInfoParm = &tInfoParm;
					cl_null_value(pInfoParm);
				}
				else {
					if (cl_is_null_parm(pInfoParm=ppParm[i+2]))
						cl_null_value(pInfoParm);
				}
				if (pInfoParm) {
					if (!(pInfoParmW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
					if (iRc = cl_gx_rep_info_set_ign(pInfoParmW,pInfoParm,1)) return iRc;
					ix = akxs_xhash2(pIndex->xhp,'s',p1,&pInfoParmW);
					if (ix <= 0) {
						if (ix == 0) ix = -12;
						return ix;
					}
					count++;
				}
			}
		}
		memcpy(pWork,&count,sizeof(int));
		return 0;
	}
	else if (iRc) return iRc;

DEBUGOUTL5(194,"%s: iParm=%d %d %d %d",_fn_,iParm[0],iParm[1],iParm[2],iParm[3]);

	iCOMPLEX = ppParm[0]->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA);
/*
printf("%s: iCOMPLEX=%08x\n",_fn_,iCOMPLEX);
*/
	ix0 = iParm[0];
	ix  = iParm[2] + s_ix;
	n = 1;
	attr = pIndex->uAttr[0];
	pInfoP = pIndex->pInfoType;

DEBUGOUT_InfoParm(194,"cl_set_array: attr=%d pInfoP=",pInfoP,attr,0);

	if (pInfoP) n = 0;
	else if ((!attr || attr==DEF_ZOK_VARI) && !pInfoP) {
		/* 2023.10.17 */
		nset = iParm[3];
		nset -= s_ix;
		for (i=0;i<nset;i++,ix++) {
			pInfoParmW = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'r');
			if (pInfoParmW) {
				if ((c=pInfoParmW->pi_id)=='T' || c=='R' || c=='A') {
					n = 0;
					break;
				}
			}
		}
		ix  = iParm[2] + s_ix;
	}
	if (n && nm>iParm[1]-s_ix) {
		if (cl_get_option(22,0) & 0x01) {
				/* �f�[�^��(%d)���z��̌�(%d)�𒴂��Ă��܂��B�������܂����B */
			ERROROUT2(FORMAT(224),nm,iParm[1]);
		}
		nm = iParm[1];
	}
/*
printf("%s:2 pIndex=%08x Index=%08x\n",_fn_,pIndex,pIndex->index);
*/
DEBUGOUTL4(194,"%s: n=%d nm=%d ix=%d",_fn_,n,nm,ix);
/*
printf("%s: n=%d nm=%d ix=%d\n",_fn_,n,nm,ix);
*/
	num = count = ii = 0;
	for (i=0;i<iParm[1];i++,ix++) {
		if (ii >= nm) break;
		ii_s = ii + 1;
		pInfoParmW = cl_get_array_and_var_ent(pIndex,pTBL,ix);
		if (pInfoParmW) {
			num++;
			pInfoParmW->pi_alen |= iCOMPLEX;
			/* 2022.12.07 */
		  if (pInfoP) {
				if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoP,1)) return iRc;
				type = pInfoP->pi_aux[0];

DEBUGOUTL3(194,"%s: i=%d type=%d",_fn_,i,type);

				if (type == D_AUX0_TYPE_STRUCT) {
					pDeftype = (tdtDefType *)pInfoP->pi_data;
					if (iRc=_def_var_struct(pInfoParmW,pDeftype,(char *)pInfoP->pi_pos,0)) return iRc;
				}
				else {
					if (type == D_AUX0_TYPE_ARRAY) {
						pInfoParmW->pi_id = 'R';
						if (iRc=_def_var_array_member(pInfoParmW)) return iRc;
					}
					else pInfoParmW->pi_id = 'A';
				}
				pInfoParmW->pi_hlen = ppParm[0]->pi_hlen;	/* add 2021.3.30 */

DEBUGOUTL5(194,"%s: nm=%d i=%d ii=%d id=[%c]",_fn_,nm,i,ii,pInfoParmW->pi_id);

			if ((c=pInfoParmW->pi_id) == 'T') {
				if (iRc=cl_set_struct(&n,pInfoParmW,nm-ii,&ppParm[ii_s])) return iRc;
				ii += n;
				count += n;
			}
			else if (c=='R' || c=='A') {
				if (!(ppParmW=(tdtInfoParm **)cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(nm-ii+2)))) return ECL_MALLOC_ERROR;
				ppParmW[0] = pInfoParmW;
				ppParmW[1] = &tInfoParm;
				cl_set_parm_bin(&tInfoParm,0);
				mem_cpy_addr(&ppParmW[2],&ppParm[ii_s],nm-ii);
				if ((iRc=cl_set_array(&n,nm-ii+2,ppParmW)) < 0) return iRc;
				ii += n;
				count += n;
			}
			/* 2022.12.07 */
		  }
			else {
				pInfoParm = ppParm[ii_s];
				if (!cl_is_null_parm(pInfoParm)) {
					if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
					count++;
				}
				ii++;
			}
		}
		else {
			return -1;
		}
	}

DEBUGOUTL3(194,"%s: num=%d count=%d",_fn_,num,count);

	/* 2023.10.22 */
	cl_set_max_array_index(pIndex,0,num);
	/* 2023.12.18 */
	/* �z�񂪃}�b�v����Ă���Ƃ��́A���̔z��̍ő�ݒ�ʒu���X�V���� */
	cl_update_map_array_max(ppParm[0]);
	memcpy(pWork,&count,sizeof(int));

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_array(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	return cl_set_array_ix(pWork,nparm,ppParm,0);
}

/****************************************/
/*										*/
/****************************************/
static int _list_copy_info(pCt,pCtI)
tdtRbCtl *pCt,*pCtI;
{
	char *(*m_alloc)();
	tdtCONSTCT *pConstCt;
	tdtInfoParm *p,*pInfoParm;
	tdtAllocCtl ac,*pAc;
	int iCHK,rc;

DEBUGOUTL2(120,"_list_copy_info:Enter pCt=%08x pCtI=%08x",pCt,pCtI);

	if (!pCt || !pCtI) return -1;
	if (pCt == pCtI) {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"_list_copy_info");
		return 0;
	}
	rc = 0;
	iCHK = 1;
	ac.ac_malloc  = pCt->rb_malloc;
	ac.ac_constct = pCt->rb_constct;
	pAc = &ac;
	akxs_rb_read(pCtI,0);
	while (p=(tdtInfoParm *)akxs_rb_read(pCtI,1)) {
DEBUGOUT_InfoParm(198,"_list_copy_info: ",p,0,0);
		if (iCHK && p->pi_id==D_DATA_ID_UNDEFVAR) {
			rc = ECL_NDEFVAR_ERROR;
			break;
		}
#if 1	/* 2024.6.2 */
		if (!(pInfoParm=(tdtInfoParm *)akxm_malloc_ctl(pAc,sizeof(tdtInfoParm))))
#else
		if (!(pInfoParm=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
#endif
			return ECL_MALLOC_ERROR;
		rc = _tmp_list_info_set_ac(pInfoParm,p,pAc);
		if (!cl_tmp_rbset_n(pCt,pInfoParm)) return ECL_MALLOC_ERROR;
	}
DEBUGOUTL1(120,"_list_copy_info:Exit rc=%d",rc);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int _tmp_list_copy(pInfoParmO,pInfoParmI)
tdtInfoParm *pInfoParmO,*pInfoParmI;
{
	tdtAllocCtl ac;

	ac.ac_malloc  = cl_tmp_const_malloc;
	ac.ac_constct = NULL;
	return _tmp_list_copy_ac(pInfoParmO,pInfoParmI,&ac);
}

/****************************************/
/*										*/
/****************************************/
int _tmp_list_copy_ac(pInfoParmO,pInfoParmI,pAc)
tdtInfoParm *pInfoParmO,*pInfoParmI;
tdtAllocCtl *pAc;
{
	int rc;
	tdtRbCtl *pCt,*pCtI;

DEBUGOUTL2(120,"_tmp_list_copy:Enter pInfoParmO=%08x pInfoParmI=%08x",pInfoParmO,pInfoParmI);

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) {
				/* %s: �R�s�[��ƃR�s�[���������ł��B�X�L�b�v���܂��B*/
		ERROROUT1(FORMAT(667),"_tmp_list_copy_ac");
		return 0;
	}
/*
printf("_tmp_list_copy: id=[%c]\n",pInfoParmI->pi_id);
*/
	pCt = akxs_rb_new2(0,0,pAc->ac_malloc,pAc->ac_constct);
	if (!pCt) return ECL_MALLOC_ERROR;
	pInfoParmO->pi_data = (char *)pCt;
	pInfoParmO->pi_scale &= ~D_DATA_MALLOC;
	pCtI = (tdtRbCtl *)pInfoParmI->pi_data;
	rc = _list_copy_info(pCt,pCtI);
DEBUGOUTL1(120,"_tmp_list_info_set:Exit rc=%d",rc);
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int _tmp_list_info_set(pInfoParmO ,pInfoParmI)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
{
	tdtAllocCtl ac;

	ac.ac_malloc  = cl_tmp_const_malloc;
	ac.ac_constct = NULL;
	return  _tmp_list_info_set_ac(pInfoParmO ,pInfoParmI,&ac);
}

/****************************************/
/*										*/
/****************************************/
int _tmp_list_info_set_ac(pInfoParmO ,pInfoParmI,pAc)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
tdtAllocCtl *pAc;
{
	int rc,opt;
	char c;

DEBUGOUTL(120,"_tmp_list_info_set:Enter");

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) return 0;
	*pInfoParmO = *pInfoParmI;
DEBUGOUT_InfoParm(198,"_tmp_list_info_set_ac: pInfoParmI=",pInfoParmI,0,0);
	if ((c=pInfoParmO->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
		if ((rc=_tmp_list_copy_ac(pInfoParmO,pInfoParmI,pAc)) < 0) return rc;
	}
	else {
		opt = 1;
		if (akxm_alloc_ctl_is(pAc)) opt |= D_GX_OPT_ALC_TMP;
		if (rc=cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,opt,NULL)) return rc;
		if (pInfoParmO->pi_id == ' ') pInfoParmO->pi_aux[1] |= D_AUX1_PROTECTED;
DEBUGOUT_InfoParm(198,"_tmp_list_info_set_ac: pInfoParmO=",pInfoParmO,0,0);
	}
DEBUGOUTL(120,"_tmp_list_info_set_ac:Exit ret=0");
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*pInfoParm2, *p;
	int i,rc,opt1,iHOLD_ERROR,f;
	tdtRbCtl *pCt;

	opt1 = pGlobTable->options[4] & 0x01;
#if 1	/* 2022.6.14 */
	cl_none_parm(pInfoParmW);
#else
	cl_null_parm(pInfoParmW);
#endif
	pInfoParmW->pi_aux[1] |= D_AUX1_PROTECTED;
	if (nparm > 0 || opt1) {
		pInfoParmW->pi_id   = D_DATA_ID_LIST;
		pInfoParmW->pi_attr = DEF_ZOK_BULK;
		pInfoParmW->pi_dlen  = sizeof(tdtRbCtl);
		if (!(pCt = cl_tmp_rb_new(0,0,NULL))) return ECL_MALLOC_ERROR;
		pInfoParmW->pi_data = (char *)pCt;
		pInfoParmW->pi_alen &= ~(D_AULN_NULL_PARM | D_AULN_NONE_PARM | D_AULN_NULL_VALUE);
		pInfoParmW->pi_aux[1] &= ~D_AUX1_PROTECTED;
	}
	iHOLD_ERROR = 0;
	for (i=0;i<nparm;i++) {
		p = ppParm[i];
DEBUGOUT_InfoParm(197,"cl_set_list:s: i=%d",p,i,0);
		/* 2021.3.27 */
		if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
			return ECL_MALLOC_ERROR;
		if ((rc=_tmp_list_info_set(pInfoParm1,p)) < 0) return rc;
DEBUGOUT_InfoParm(198,"cl_set_list:d: i=%d",pInfoParm1,i,0);
		if (!cl_tmp_rbset_n(pCt,pInfoParm1)) return ECL_MALLOC_ERROR;
		if (pInfoParm1->pi_alen & D_AULN_HOLD_ERROR) iHOLD_ERROR = D_AULN_HOLD_ERROR;
	}
	pInfoParmW->pi_alen |= iHOLD_ERROR;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
tdtRbCtl *cl_tmp_rb_new(lBS,lRM,pConstCt)
long lBS,lRM;
ConstantCt *pConstCt;
{
	char *(*m_alloc)();

	if (pConstCt) m_alloc = cl_const_ct_malloc;
	else  m_alloc = cl_tmp_const_malloc;
/*
printf("cl_tmp_rb_new: m_alloc=%08x pConstCt=%08x\n",m_alloc,pConstCt);
*/
	return akxs_rb_new2(lBS,lRM,m_alloc,pConstCt);
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_rbset_n(pCt, addr)
tdtRbCtl *pCt;
char *addr;
{
	return akxs_rb_set_n(pCt, addr);
}

/****************************************/
/*										*/
/****************************************/
int cl_cons_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*pInfoParm2, *p;
	int i,rc,opt1;
	tdtRbCtl *pCt;
	char c,c0;

DEBUGOUTL2(120,"cl_cons_list:Enter nparm=%d ppParm=%08x",nparm,ppParm);

	opt1 = cl_get_option(5,0) & 0x01;
	cl_null_data(pInfoParmW);
	if (nparm > 0 || opt1) {
		pInfoParmW->pi_id   = D_DATA_ID_LIST;
		pInfoParmW->pi_attr = DEF_ZOK_BULK;
		pInfoParmW->pi_dlen  = sizeof(tdtRbCtl);
		if (!(pCt = cl_tmp_rb_new(0,0,NULL))) return ECL_MALLOC_ERROR;
		pInfoParmW->pi_data = (char *)pCt;
		if (nparm > 0) {
			/* 2021.4.7 */
			if ((c0=ppParm[0]->pi_id)==D_DATA_ID_NARABI || c0==D_DATA_ID_LIST)
				pInfoParmW->pi_id = c0;
		}
	}
/*	c0 = pInfoParmW->pi_id;	*//* del 2021.4.7 */
	for (i=0;i<nparm;i++) {
		p = ppParm[i];
		/* 2021.4.7 */
		if (((c=p->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) &&
		    (c==c0 || (c0!=D_DATA_ID_NARABI && c0!=D_DATA_ID_LIST))) {
			pInfoParmW->pi_id = c0 = c;
			if ((rc=_list_copy_info(pCt,p->pi_data)) < 0) return rc;
		}
		else if (p->pi_aux[0] & DEF_ZOK_DATA) {
			if ((rc=_list_array_set(pCt,p)) < 0) return rc;
		}
		else if (!cl_is_null_parm(p)) {
			if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
			if ((rc=_tmp_list_info_set(pInfoParm1,p)) < 0) return rc;
			if (!cl_tmp_rbset_n(pCt,pInfoParm1)) return ECL_MALLOC_ERROR;
		}
	}
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"pInfoParmW=",pInfoParmW,0,0);
DEBUGOUTL(120,"cl_cons_list:Exit ret=0");
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_list(pInfoParmW,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int  nparm;
tdtInfoParm *ppParm[];
{
	int  ret,len;
	char w1[32],*p1;
	tdtInfoParm **pp;

	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	ret = 0;
	p1 = w1;
	if ((len = parm_to_char(ppParm[0],&p1,NULL)) < 0) {
		ERROROUT(FORMAT(225));	/* ����w�肪�s���ł��B */
		return len;
	}
	nparm--;
	pp = &ppParm[1];
	if (!stricmp(p1,"LIST")||!stricmp(p1,"APPEND"))
		ret = cl_set_list(pInfoParmW,nparm,pp);
	else if (!stricmp(p1,"FIRST")) ret = cl_ope_list(pInfoParmW,NULL,nparm,pp,D_FUC_FIRST,0);
	else if (!stricmp(p1,"REST")) ret = cl_ope_list(pInfoParmW,NULL,nparm,pp,D_FUC_REST,0);
	else if (!stricmp(p1,"CONS")) ret = cl_cons_list(pInfoParmW,nparm,pp);
	else if (!stricmp(p1,"LIST_REF")) ret = cl_ope_list(pInfoParmW,NULL,nparm,pp,D_FUC_LIST_REF,0);
	else {
		ERROROUT1(FORMAT(226),p1);	/* ����w��(%s)���s���ł��B */
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_ope_list(pInfoParmW,pdummy,nparm,ppParm,ope,dummy)
tdtInfoParm *pInfoParmW;
int  nparm,ope,dummy;
tdtInfoParm *ppParm[];
char *pdummy;
{
	tdtInfoParm *pInfoParm,*p,tInfoParm;
	int rc,n,opt1,i,m,iCONST;
	tdtRbCtl *pCt;
	char id;

	rc = 0;
	cl_null_data(pInfoParmW);
	pInfoParm = ppParm[0];
	if (cl_is_null_parm(pInfoParm) || cl_is_null_data(pInfoParm)) return 0;
	if ((id=pInfoParm->pi_id)!=D_DATA_ID_LIST && id!=D_DATA_ID_NARABI) {
		ERROROUT(FORMAT(227));	/* ���X�g�ł͂���܂���B */
		return ECL_SCRIPT_ERROR;
	}
	if (ope == D_FUC_FIRST) {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		if (p = (tdtInfoParm *)akxs_rb_get(pCt)) {
			if ((id=p->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)
				rc = _tmp_list_info_set(pInfoParmW,p);
			else {
				cl_gx_copy_info(pInfoParmW,p);
				pInfoParmW->pi_scale &= ~D_DATA_MALLOC;
			}
		}
	}
	else if (ope == D_FUC_REST) {
		rc = _tmp_list_info_set(pInfoParmW,pInfoParm);
		opt1 = pGlobTable->options[4] & 0x01;
		n = akxs_rb_used(pCt=(tdtRbCtl *)pInfoParmW->pi_data);
		if (n>1 || opt1) {
			if (nparm > 1) {
				if ((rc=cl_get_parm_bin(ppParm[1],&m,"cl_ope_list REST:"))<0) return rc;
				rc = 0;
				m = X_MIN(n,m);
				for (i=0;i<m;i++) if (!akxs_rb_get_n(pCt)) break;
			}
			else akxs_rb_get_n(pCt);
		}
		else cl_null_data(pInfoParmW);
	}
	else if (ope == D_FUC_LIST_REF) {
		iCONST = pInfoParm->pi_aux[1] & D_AUX1_PROTECTED;
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		if ((n=akxs_rb_used(pCt)) <= 0) return 0;
		if (nparm > 1) {
			if ((rc=cl_get_parm_bin(ppParm[1],&m,"cl_ope_list REF:"))<0) return rc;
		}
		else m = 0;
		rc = 0;
		if (m < 0) {
			ERROROUT1(FORMAT(228),m);	/* �Q�ƈʒu(%d)���s���ł��B */
			return ECL_SCRIPT_ERROR;
		}
		if (m < n) {
			akxs_rb_read(pCt,0);
			for (i=0;i<=m;i++) if (!(p=(tdtInfoParm *)akxs_rb_read(pCt,1))) break;
			if (p) {
				if (dummy & D_GX_OPT_GET_ADDR) {
					cl_set_parm_long(pInfoParmW,(long)p);
					pInfoParmW->pi_id = 'S';
				}
				else {
					if ((id=p->pi_id)==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)
						rc = _tmp_list_info_set(pInfoParmW,p);
					else
						cl_gx_copy_info(pInfoParmW,p);
				}
				pInfoParmW->pi_aux[1] |= iCONST;
DEBUGOUT_InfoParm(194,"cl_ope_list: p=",p,0,0);
DEBUGOUT_InfoParm(194,"cl_ope_list: ope=%d pInfoParmW=",pInfoParmW,ope,0);
			}
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_index(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	int i,n,ix;
	tdtInfoParm *ppm[MAX_ARRAY_DIM+1];

	ppm[0] = ppParm[0];
	n = X_MIN(nparm,MAX_ARRAY_DIM);
	for (i=1;i<n;i++) ppm[i+1] = ppParm[i];
	ix = cl_gx_array_bexp(NULL,nparm+1,ppm,0);
	/* 2021.10.5*/
	if (!ix) {
		ERROROUT1(FORMAT(203),"cl_func_index");	/* %s: �f�[�^�����ݒ�ł��B*/
	}
	if (ix >= 0) ix--;
	memcpy(pWork,&ix,sizeof(int));
	if (ix > 0) ix = 0;
	return ix;
}

/****************************************/
/*										*/
/****************************************/
static int _array_cpy(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm,*pInfoParmW,rInfoParm;
	tdtInfoParm ***pTBL1,***pTBL2;
	int iRc,n,i,ix1,ix2,nm,nm1,nm2,count,ix0;
	tdtArrayIndex tIndex1,tIndex2,*pIndex;
	int *index1,*index2,iParm[4];
	char c,*name,*cpKey,*cpDat,*pVal;
	XHASHB *xhpI,*xhpO;

	nm = 0;
	memcpy(pWork,&nm,sizeof(int));
	pIndex = &tIndex1;
	/* 2023.12.17 */
	if (iRc = _get_array_info_ref(1,ppParm,&pIndex,&pTBL1,iParm,3)) {
		if (iRc == 2000) xhpO = tIndex1.xhp;
		else return iRc;
	}
	else xhpO = NULL;
	nm1  = iParm[1];
	ix0 = ix1  = iParm[2];
/*
printf("_array_cpy: nm1=%d ix1=%d\n",nm1,ix1);
*/
	/* �z�Q�Ə������`�F�b�N */
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}
	/* �z�Q�Ƃ��`�F�b�N */
	if (pTBL1) name = "$()";
	else name = (char *)ppParm[0]->pi_pos;
	pVal = cl_get_circ_addr(pIndex,pTBL1);
	if ((iRc=_iterate_circ_ref(&gtIter_ctl[0],pVal,name)) == 1) return 0;
	else if (iRc < 0) return iRc;
	/* 2023.12.17 */
	if (iRc = _get_array_info_used(1,&ppParm[1],&tIndex2,&pTBL2,iParm,1)) {
		if (iRc == 2000) xhpI = tIndex2.xhp;
		else return iRc;
	}
	else xhpI = NULL;
	nm2  = iParm[1];
	ix2  = iParm[2];
/*
printf("_array_cpy: nm2=%d ix2=%d\n",nm2,ix2);
*/
	if (!((xhpO && xhpI)||(!xhpO && !xhpI))) {
		/* array_to ���A�z�z��ł͂���܂���B */
		if (!xhpO) ERROROUT1(FORMAT(229),"_array_cpy: array_to");
		/* array_from ���A�z�z��ł͂���܂���B */
		else if (!xhpI) ERROROUT1(FORMAT(229),"_array_cpy: array_from");
		return -1;
	}

	if (nm2 < nm1) nm1 = nm2;
	nm = nm1;
	/* 2023.12.17 */
	if (iRc = _get_array_num(nparm-2,&ppParm[2],nm1,&nm)) return iRc;

	if (xhpO) {
		if (iRc=_array_hash_clr(pIndex=(tdtArrayIndex *)ppParm[0]->pi_data)) return iRc;
		xhpO = pIndex->xhp;
	}
/*
printf("_array_cpy: nm=%d nm1=%d\n",nm,nm1);
*/
	for (count=0,i=1;;i++) {
		if (xhpI) {
			if (i>nm1 || count>=nm) break;
			xhpI->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhpI,'P',&cpKey,&cpDat)) > 0) {
				memcpy(&pInfoParm,cpDat,sizeof(tdtInfoParm *));
				if (!(pInfoParmW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
				memset(pInfoParmW,0,sizeof(tdtInfoParm));
				ix1 = akxs_xhash2(xhpO,'s',cpKey,&pInfoParmW);
				if (ix1 <= 0) {
					if (ix1 == 0) ix1 = -12;
					return ix1;
				}
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			if (i > nm) break;
			pInfoParmW = cl_get_array_and_var_ent(pIndex,pTBL1,ix1);
			pInfoParm  = cl_get_array_and_var_ent_opt(&tIndex2,pTBL2,ix2,'r');
			ix1++;
			ix2++;
		}
		if (pInfoParmW && pInfoParm) {
			if (iRc=cl_gx_rep_info_set(pInfoParmW,pInfoParm,1)) return iRc;
		}
		else {
			return -1;
		}
		count++;
	}
	memcpy(pWork,&count,sizeof(int));
	/* 2023.10.22 */
	if (!xhpO) {
		cl_set_max_array_index(pIndex,0,nm);
		/* 2023.12.18 */
		/* �z�񂪃}�b�v����Ă���Ƃ��́A���̔z��̍ő�ݒ�ʒu���X�V���� */
		cl_update_map_array_max(ppParm[0]);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _array_hash_clr(pIndex)
tdtArrayIndex *pIndex;
{
	int iRc,lMaxReg,lDatLen;
	XHASHB *xhp;

	if ((iRc=akxs_xhash2(xhp=pIndex->xhp,'u',NULL,NULL)) > 0) {
		lMaxReg = xhp->xha_maxreg;
		lDatLen = xhp->xha_datlen;
		akxs_xhash_free(xhp);
		if (!(pIndex->xhp = akxs_xhash_new2(0,lMaxReg,0,lDatLen))) return -9;
		iRc = 0;
	}
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _array_clr(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm,*pInfoParmW,rInfoParm;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix,nm,nm1,count,iNULL,atr,*pSize;
	char c,*name;
	tdtArrayIndex tIndex,*pIndex;
	int *index,iParm[4];

	nm = 0;
	memcpy(pWork,&nm,sizeof(int));

	pIndex = &tIndex;
	/* 2023.12.17 */
	if (iRc = _get_array_info_used_ref(1,ppParm,&pIndex,&pTBL,iParm,3)) {
		if (iRc == 2000) iRc = _array_hash_clr(ppParm[0]->pi_data);
		return iRc;
	}
	nm1 = iParm[1];		/* �ő�v�f�� */
	ix  = iParm[2];		/* off_set + �J�n�ʒu */
/*	cl_get_array_index(ppParm[0],&pIndex);	*/
	if (pTBL) atr = DEF_ZOK_VARI;
	else atr = pIndex->uAttr[0];
	index = pIndex->index;
/*
printf("_array_clr: index=%d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4]);
*/
	nm = nm1;
	/* �N���A�����w�肳��Ă����nm�ɂ��̒l������B�������Anm<=�ő�v�f�� */
	/* 2023.12.17 */
	if (iRc = _get_array_num(nparm-2,&ppParm[2],nm1,&nm)) return iRc;
/*
printf("_array_clr: ix=%d nm1=%d nm=%d pTBL=%08x atr=%d\n",ix,nm1,nm,pTBL,atr);
*/
	iNULL = 0;
	/* �N���A�l���ȗ���NULL�l�̂Ƃ��́A���ݒ�ɂ��� */
	/* 2023.12.17 */
	if (nparm >= 2) {
		pInfoParm = ppParm[1];
		if (cl_is_null_parm(pInfoParm) && atr==DEF_ZOK_VARI) {
			cl_parm_set0(pInfoParm);
			iNULL = 1;
		}
	}
	else {
		pInfoParm = &rInfoParm;
		cl_null_parm(pInfoParm);
		if (atr == DEF_ZOK_VARI) {
			cl_parm_set0(pInfoParm);
		/*	iNULL = 1;	2021.7.2 */
		}
		iNULL = 1;
	}
	/* 2021.7.2 */
	if (iNULL) {	/* �N���A�l���ȗ���NULL�l�̂Ƃ��́A�����Ă����L�܂Ŗ��ݒ�ɂ��� */
		nm1 = iParm[3];		/* �ݒ�ςݗv�f�ōő�v�f�ԍ��̗v�f�܂ł̗v�f�� */
		if (nm > nm1) nm = nm1;	/* �w��̃N���A��(nm)<=���̐�(nm1)�ɂȂ� */
	}
	for (i=count=0;i<nm;i++,ix++) {
		pInfoParmW = cl_get_array_and_var_ent(pIndex,pTBL,ix);
		if (pInfoParmW) {
			/* 2021.10.27 */
			if (iRc=cl_gx_rep_info_data(pInfoParmW,pInfoParm,1)) return iRc;
		}
		else {
			return -1;
		}
		count++;
	}
/*
printf("_array_clr: ix=%d nm1=%d nm=%d iNULL=%d\n",ix,nm1,nm,iNULL);
printf("_array_clr: index=%d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4]);
*/
/*	if (iNULL) {	2021.6.30 */
	/* �ݒ�ςݗv�f�ōő�v�f�ԍ��̗v�f�܂Ŗ��ݒ�ɂ�����A���̐����[���ɂ��� */
	if (iNULL && nm1==nm) {
		ix = iParm[2] - 1;
		if (pTBL) {
			pSize = (int *)pTBL[0];
			/* 2023.2.10 */
			nm1 = pSize[7];
/*
printf("_array_clr: ix=%d pSize[7]=%d\n",ix,pSize[7]);
*/
			cl_set_max_var_ent(pSize,-1);
			nm = 0;
			for (i=nm1;i>=1;i--) {
				if (pInfoParm = cl_get_var_ent(pTBL,i)) {
					if (!(cl_is_null_parm(pInfoParm) || cl_is_undef_parm(pInfoParm))) {
						nm = i;
						break;
					}
				}
			}
			if (nm) cl_set_max_var_ent(pSize,nm);
		}
		/* 2023.2.9 */
		index[2] = 0;
	}
	/* 2023.12.18 */
	cl_set_max_array_index(pIndex,0,nm);
	/* �z�񂪃}�b�v����Ă���Ƃ��́A���̔z��̍ő�ݒ�ʒu���X�V���� */
	cl_update_map_array_max(ppParm[0]);
	memcpy(pWork,&count,sizeof(int));

	return 0;
}

/********1*********2*********3*********4*********5*********6*********7***/
/*			cmp_opt		: ��r�I�v�V����								*/
/*							= 0x01 : ��r�Ώۂ̐����܂߂đS�Ă��A		*/
/*									 ��v�����Ƃ��A1��Ԃ�				*/
/*	�ԋp :  cmp_opt��0x01��												*/
/*			=0�̂Ƃ��A��v��											*/
/*			=1�̂Ƃ��A1/0=��v/�s��v									*/
/********1*********2*********3*********4*********5*********6*********7***/
static int _array_cmp(pWork,nparm,ppParm,cmp_opt)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
int cmp_opt;
{
	tdtInfoParm *pInfoParm1,*pInfoParm2,*pInfoParm3;
	tdtInfoParm ***pTBL1,***pTBL2;
	int iRc,n,i,ix1,ix2,nm,nm1,nm2,len,iAns,iParm[4],count,match,nu1,nu2,nm3,nmc,nu;
	tdtArrayIndex tIndex1,tIndex2;
	char *p1,*pAns;
	char *cpKey,*cpDat,*pVal;
	char id1,id2;
	XHASHB *xhp1,*xhp2,*xhp;
/*
printf("_array_cmp: nparm=%d cmp_opt=%08x\n",nparm,cmp_opt);
*/
	/* �z�Q�Ə������`�F�b�N */
	if (!gtIter_ctl[0].itc_circ_ref) {
		if (!(gtIter_ctl[0].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
		if (!(gtIter_ctl[1].itc_circ_ref=akxs_layer_new(10,cl_tmp_const_malloc,NULL))) return -215212104;
	}

	iAns = 0;
	memcpy(pWork,&iAns,sizeof(int));
	pInfoParm1 = ppParm[0];
	/* 2023.12.17 */
	pInfoParm2 = ppParm[1];
	if ((id1=pInfoParm1->pi_id) != (id2=pInfoParm2->pi_id)) {
		/* %s: �p�����[�^�̃f�[�^�h�c(id1=%c id2=%c)�������Ă��܂���B */
		ERROROUT3(FORMAT(241),"_array_cmp",id1,id2);
		return -1;
	}
	p1 = "==";
	/* 2023.12.17 */
	if (nparm >= 4) {
		pInfoParm3 = ppParm[3];
		if (iRc=cl_check_attr(pInfoParm3,DEF_ZOK_CHAR,"_array_cmp.cmp")) return iRc;
		if (pInfoParm3->pi_dlen > 0) {
			p1 = pInfoParm3->pi_data;
			if (!strcmp(p1,"=")) p1 = "==";
			if (_get_comp_no(p1,0x11) < 0) return ECL_SCRIPT_ERROR;
		}
	}
	if (id1=='L' || id1=='N') {
		ix1 = ix2 = nm = 0;
		/* 2023.12.17 */
		if (iRc = _get_array_num(nparm-2,&ppParm[2],-1,&nm)) return iRc;
		iParm[0] = ix1;
		iParm[1] = ix2;
		iParm[2] = nm;
		if ((iAns=cl_comp_list(p1,pInfoParm1,pInfoParm2,iParm,0)) >= 0) {
			memcpy(pWork,&iAns,sizeof(int));
			iRc = 0;
		}
		else iRc = iAns;
		return iRc;
	}
	/* 2023.12.17 */
	if (iRc = _get_array_info_used(1,ppParm,&tIndex1,&pTBL1,iParm,1)) {
		if (iRc == 2000) xhp1 = tIndex1.xhp;
		else return iRc;
	}
	else xhp1 = NULL;

	/* �z�Q�Ƃ��`�F�b�N */
	pVal = cl_get_circ_addr(&tIndex1,pTBL1);
	if ((iRc=_iterate_circ_ref(&gtIter_ctl[0],pVal,(char *)ppParm[0]->pi_pos)) == 1) return 0;
	else if (iRc < 0) return iRc;

	nm1  = iParm[1];
	ix1  = iParm[2];
	nu1  = iParm[3];
/*
printf("_array_cmp: nm1=%d ix1=%d nu1=%d\n",nm1,ix1,nu1);
*/
	/* 2023.12.17 */
	if (iRc = _get_array_info_used(1,&ppParm[1],&tIndex2,&pTBL2,iParm,1)) {
		if (iRc == 2000) xhp2 = tIndex2.xhp;
		else return iRc;
	}
	else xhp2 = NULL;

	/* �z�Q�Ƃ��`�F�b�N */
	pVal = cl_get_circ_addr(&tIndex2,pTBL2);
	/* 2023.12.17 */
	if ((iRc=_iterate_circ_ref(&gtIter_ctl[1],pVal,(char *)ppParm[1]->pi_pos)) == 1) return 0;
	else if (iRc < 0) return iRc;

	nm2  = iParm[1];
	ix2  = iParm[2];
	nu2  = iParm[3];
/*
printf("_array_cmp: nm2=%d ix2=%d nu2=%d\n",nm2,ix2,nu2);
*/
	if (!((xhp1 && xhp2)||(!xhp1 && !xhp2))) {
		/* array1 ���A�z�z��ł͂���܂���B */
		if (!xhp1) ERROROUT1(FORMAT(229),"_array_cmp: array1");
		/* array2 ���A�z�z��ł͂���܂���B */
		else if (!xhp2) ERROROUT1(FORMAT(229),"_array_cmp: array2");
		return -1;
	}

	nm3 = X_MIN(nm1,nm2);
	nmc = nm3;
	/* 2023.12.17 */
	if (iRc = _get_array_num(nparm-2,&ppParm[2],nm3,&nmc)) return iRc;
	nm = nmc;
	if (nu1 < nm) nm = nu1;
	if (nu2 < nm) nm = nu2;
/*
printf("_array_cmp: nm3=%d nm=%d cmp_opt=%02x nu1=%d nu2=%d\n",nm3,nm,cmp_opt,nu1,nu2);
*/
	if (cmp_opt & 0x01) {
		nu = X_MIN(nu1,nu2);
		if (nmc>=nu && nu1!=nu2) return 0;
	}
	nm1 = nm3;
/*
printf("_array_cmp: nm=%d\n",nm);
*/
	if (xhp1) {
		if (nm1 < nm2) {
			nm1 = nm2;
			xhp  = xhp1;
			xhp1 = xhp2;
			xhp2 = xhp;
		}
/*
printf("_array_cmp: HASH nm1=%d\n",nm1);
*/
	}
	count=match=0;
	for (i=1;;i++) {
		if (xhp1) {
			if (i>nm1 || count>=nm) break;
			xhp1->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhp1,'P',&cpKey,&cpDat)) > 0) {
/*
printf("_array_cmp: HASH cpKey=[%s]\n",cpKey);
*/
				memcpy(&pInfoParm1,cpDat,sizeof(tdtInfoParm *));
				if ((iRc=akxs_xhash2(xhp2,'R',cpKey,&cpDat)) > 0) {
					memcpy(&pInfoParm2,cpDat,sizeof(tdtInfoParm *));
				}
				else if (iRc < 0) return iRc;
				else continue;
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			if (i > nm) break;
			pInfoParm1 = cl_get_array_and_var_ent_opt(&tIndex1,pTBL1,ix1,'r');
			pInfoParm2 = cl_get_array_and_var_ent_opt(&tIndex2,pTBL2,ix2,'r');
			ix1++;
			ix2++;
		}
		if (pInfoParm1 && pInfoParm2) {
			count++;
/*
printf("_array_cmp: count=%d\n",count);
*/
			pAns = (char *)&iAns;
			if ((iRc=cl_cmpt_comp_opt(&pAns,p1,pInfoParm1,pInfoParm2,0,NULL,cmp_opt)) < 0) iAns = 0;
		/*	if (!iAns) break; */
			if (iAns) match++;
		}
		else {
			return -1;
		}
	}
	if (cmp_opt & 0x01) {
		if (match == nm) match = 1;
		else match = 0;
	}
	memcpy(pWork,&match,sizeof(int));
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _array_bxp(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*pInfoParmW,*pInfoParm2,tInfoParm;
	tdtInfoParm ***pTBL1,***pTBL2,***pTBL3;
	int iRc,n,i,ix1,ix2,ix3,nm,nm1,nm2,nm3,len,count,iParm[4],nu2,nu3;
	tdtArrayIndex *pIndex1,tIndex1,tIndex2,tIndex3,*pIndex;
	XHASHB *xhp1,*xhp2,*xhp3,*xhp;
	char *p1,*cpKey,*cpDat;

	count = 0;
	memcpy(pWork,&count,sizeof(int));

	pIndex1 = &tIndex1;
	/* 2023.12.17 */
	if (iRc = _get_array_info_used_ref(1,ppParm,&pIndex1,&pTBL1,iParm,3)) {
		if (iRc == 2000) xhp1 = pIndex1->xhp;
		else return iRc;
	}
	else xhp1 = NULL;
	nm1  = iParm[1];
	ix1  = iParm[2];

	/* 2023.12.17 */
	if (iRc = _get_array_info_used(1,&ppParm[1],&tIndex2,&pTBL2,iParm,1)) {
		if (iRc == 2000) xhp2 = tIndex2.xhp;
		else return iRc;
	}
	else xhp2 = NULL;
	nm2  = iParm[1];
	ix2  = iParm[2];
	nu2  = iParm[3];

	/* 2023.12.17 */
	if (iRc = _get_array_info_used(1,&ppParm[2],&tIndex3,&pTBL3,iParm,1)) {
		if (iRc == 2000) xhp3 = tIndex3.xhp;
		else return iRc;
	}
	else xhp3 = NULL;
	nm3  = iParm[1];
	ix3  = iParm[2];
	nu3  = iParm[3];

	if (!((xhp1 && xhp2 && xhp3)||(!xhp1 && !xhp2 && !xhp3))) {
		/* array_to ���A�z�z��ł͂���܂���B */
		if (!xhp1) ERROROUT1(FORMAT(229),"_array_bxp: array_to");
		/* array_1 ���A�z�z��ł͂���܂���B */
		if (!xhp2) ERROROUT1(FORMAT(229),"_array_bxp: array_1");
		/* array_2 ���A�z�z��ł͂���܂���B */
		if (!xhp3) ERROROUT1(FORMAT(229),"_array_bxp: array_2");
		return -1;
	}

	if (nm2 < nm1) nm1 = nm2;
	if (nm3 < nm1) nm1 = nm3;
	/* 2023.12.17 */
	if (iRc = _get_array_num(nparm-3,&ppParm[3],nm1,&nm)) return iRc;
	if (nu2 < nm) nm = nu2;
	if (nu3 < nm) nm = nu3;
/*
printf("_array_bxp: nm1=%d nm=%d\n",nm1,nm);
*/
	p1 = "+";
	if (nparm >= 5) {
		pInfoParmW = ppParm[4];
		if (iRc=cl_check_attr(pInfoParmW,DEF_ZOK_CHAR,"_array_bxp.bxp")) return iRc;
		if (pInfoParmW->pi_dlen > 0) p1 = pInfoParmW->pi_data;
	}

	if (xhp1) {
		if (iRc=_array_hash_clr(pIndex=(tdtArrayIndex *)ppParm[0]->pi_data)) return iRc;
		nm1 = nm2;
		if (nm2 < nm3) {
			nm1 = nm3;
			xhp  = xhp2;
			xhp2 = xhp3;
			xhp3 = xhp;
		}
/*
printf("_array_bxp: HASH nm1=%d\n",nm1);
*/
	}

	for (count=0,i=1;;i++) {
		if (xhp2) {
			if (i>nm1 || count>=nm) break;
			xhp2->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhp2,'P',&cpKey,&cpDat)) > 0) {
/*
printf("_array_bxp: HASH cpKey=[%s]\n",cpKey);
*/
				memcpy(&pInfoParm1,cpDat,sizeof(tdtInfoParm *));
			/*	if ((iRc=akxs_xhash2(xhp3,'R',cpKey,&cpDat)) > 0) {	*/
				iRc = akxs_xhash2(xhp3,'R',cpKey,&cpDat);
/*
printf("_array_bxp: HASH iRc=%d\n",iRc);
*/
				if (iRc > 0) {
					memcpy(&pInfoParm2,cpDat,sizeof(tdtInfoParm *));
				}
				else if (iRc < 0) return iRc;
				else continue;
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			if (i > nm) break;
			pInfoParmW = cl_get_array_and_var_ent(pIndex1,pTBL1,ix1);
			pInfoParm1 = cl_get_array_and_var_ent_opt(&tIndex2,pTBL2,ix2,'r');
			pInfoParm2 = cl_get_array_and_var_ent_opt(&tIndex3,pTBL3,ix3,'r');
			ix1++;
			ix2++;
			ix3++;
		}
		if (pInfoParm1 && pInfoParm2) {
			if (iRc=cl_gx_bexp(&tInfoParm,pInfoParm1,p1,pInfoParm2,0,0)) return iRc;
			if (xhp2) {
				if (!(pInfoParmW=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
				if (iRc=cl_gx_rep_info_set_ign(pInfoParmW,&tInfoParm,1)) return iRc;
				ix1 = akxs_xhash2(xhp1,'s',cpKey,&pInfoParmW);
				if (ix1 <= 0) {
					if (ix1 == 0) ix1 = -12;
					return ix1;
				}
			}
			else {
				if (!pInfoParmW) return -1;
				if (iRc=cl_gx_rep_info_set(pInfoParmW,&tInfoParm,1)) return iRc;
			}
			count++;
		}
		else {
			return -1;
		}
	}
	/* 2023.12.18 */
	cl_set_max_array_index(pIndex1,0,nm);
	/* �z�񂪃}�b�v����Ă���Ƃ��́A���̔z��̍ő�ݒ�ʒu���X�V���� */
	cl_update_map_array_max(ppParm[0]);
	memcpy(pWork,&count,sizeof(int));
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _get_matrix_info(pInfoParm,ppIndex,ppTBL,iParm)
tdtInfoParm *pInfoParm;
tdtArrayIndex **ppIndex;
tdtInfoParm ****ppTBL;
int iParm[];
{
	tdtArrayIndex *pIndex;
	tdtInfoParm ***pTBL;
	char id;
	int ret,*index,k,nm,ix0,ndim;

printf("_get_matrix_info:Enter\n");
	if (!pInfoParm || !ppIndex || !iParm) return -1;
	ret = 0;
	pIndex = *ppIndex;
	pTBL = NULL;
	if (ppTBL) *ppTBL = pTBL;
	id = pInfoParm->pi_id;
	if ((ret=cl_get_array_index_tbl_ref(pInfoParm,&pIndex,&pTBL,NULL)) < 0) return ret;
printf("_get_matrix_info: id=[%c] pTBL=%08x\n",id,pTBL);
	index = pIndex->index;
printf("_get_matrix_info: index=%d %d %d %d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4],index[5],index[6],index[7]);
	if (id=='A' || id=='R') {
		if (ppTBL) *ppTBL = pTBL;
		*ppIndex = pIndex;
		ndim = index[0];
		k = 0;
		iParm[k++] = index[4];
		iParm[k++] = index[ndim+4];
		if (ndim >= 2) {
			nm = index[1+4];
			ix0 = index[1+ndim+4];
		}
		else {
			nm = 1;
			ix0 = 0;
		}
		iParm[k++] = nm;
		iParm[k++] = ix0;
	}
	else if (pTBL) {
		if (ppTBL) *ppTBL = pTBL;
		iParm[0] = index[2];
		mem_set_int(iParm+1,0,3);
#if 0	/* ���̃`�F�b�N�́Acl_get_array_index_tbl_ref()�̒��ł���Ă��� */
		if (index[3] <= 0) {
			ERROROUT2(FORMAT(222),_get_matrix_info,iParm[7]);	/* �J�n�ʒu(%d)���s���ł��B*/
			return ECL_SCRIPT_ERROR;
		}
#endif
printf("_get_matrix_info: pTBL=%08x index[3]=%d\n",pTBL,index[3]);
	}
	else {
		ERROROUT1(FORMAT(202),"_get_matrix_info");		/* %s: �z��ł͂���܂���B*/
		ret = ECL_SCRIPT_ERROR;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static tdtInfoParm *_get_array_parm_by_index_opt(pIndex,pTBL,index_info,opt)
tdtArrayIndex *pIndex;
tdtInfoParm ***pTBL;
int  index_info[];
char opt;
{
	tdtInfoParm *pInfoParm;
	int ix,nm;

	if (!pIndex || !index_info) return NULL;

	ix = cl_gx_conv_index2(pIndex->index,index_info,"_get_parm_array_ent_index_opt");
printf("_get_array_parm_by_index_opt: opt=[%c] ix=%d\n",opt,ix);
	if (ix >= 0) {
		pInfoParm = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,opt);
	}
	else {
		pInfoParm = NULL;
	}
	return pInfoParm;
}

/****************************************/
/*										*/
/****************************************/
static int _matrix_bxp(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	static char *_fn_="_matrix_bxp";
	tdtInfoParm *pInfoParm1,*pInfoParm2,*pInfoParm3,*pInfoParmW,tInfoParm;
	tdtInfoParm ***pTBL1,***pTBL2,***pTBL3;
	int iRc,count,i,j,ix1,ix2,ix3,n,m,nm1,ndim1,*index1,*index2,*index3,ix3i;
	int ioff1,ioff2,ioff3;
	int iParm[13],ixa1[4],ixa2[4],ixa3[4],nu1,nu2,nu3;
	int index_info1[8],index_info2[8],index_info3[8];
	tdtArrayIndex tIndex1,tIndex2,tIndex3,*pIndex1,*pIndex2,*pIndex3,*pIndex;
	char *p1,op;

printf("%s:Enter nparm=%d\n",_fn_,nparm);

	pIndex1 = &tIndex1;
	if ((iRc=_get_matrix_info(ppParm[0],&pIndex1,&pTBL1,ixa1)) < 0) return iRc;
	index1 = pIndex1->index;
	mem_cpy_int(index_info1,index1,8);
	ndim1 = index1[0];
	nm1   = index1[1];
	nu1   = index1[2];
printf("%s:1 nm1=%d ndim1=%d\n",_fn_,nm1,ndim1);
printf("%s:1 nu1=%d ixa1=%d %d %d %d pTBL1=%08x\n",_fn_,nu1,ixa1[0],ixa1[1],ixa1[2],ixa1[3],pTBL1);

	pIndex2 = &tIndex2;
	if ((iRc=_get_matrix_info(ppParm[1],&pIndex2,&pTBL2,ixa2)) < 0) return iRc;
	index2 = pIndex2->index;
	mem_cpy_int(index_info2,index2,8);
	nu2   = index2[2];
printf("%s:2 nu2=%d ixa2=%d %d %d %d pTBL2=%08x\n",_fn_,nu2,ixa2[0],ixa2[1],ixa2[2],ixa2[3],pTBL2);
	if (ndim1<=1 && index2[0]>=2) {
		ixa1[0] = ixa2[0];
		ixa1[2] = ixa2[2];
		mem_cpy_int(index_info1,index2,8);
printf("%s:1_2 ixa1=%d %d %d %d\n",_fn_,ixa1[0],ixa1[1],ixa1[2],ixa1[3]);
		mem_cpy_int(index1+4,index2+4,4);
		index1[0] = index2[0];
printf("%s:1_2 index1=%d %d %d %d %d %d %d %d\n",
_fn_,index1[0],index1[1],index1[2],index1[3],index1[4],index1[5],index1[6],index1[7]);
	}

	pIndex3 = &tIndex3;
	if ((iRc=_get_matrix_info(ppParm[2],&pIndex3,&pTBL3,ixa3)) < 0) return iRc;
	index3 = pIndex3->index;
	mem_cpy_int(index_info3,index3,8);
	nu3   = index3[2];
printf("%s:3 nu3=%d ixa3=%d %d %d %d pTBL3=%08x\n",_fn_,nu3,ixa3[0],ixa3[1],ixa3[2],ixa3[3],pTBL3);

	p1 = "+";
	if (nparm >= 4) {
		pInfoParmW = ppParm[3];
		if (iRc=cl_check_attr(pInfoParmW,DEF_ZOK_CHAR,"_matrix_bxp.bxp")) return iRc;
		if (pInfoParmW->pi_dlen > 0) {
			p1 = pInfoParmW->pi_data;
			if ((op=*p1)=='+' || op=='-' || op=='*') ;
			else {
				ERROROUT2(FORMAT(45),_fn_,p1);	/* %s: �p�����[�^[%s]������Ă��܂��B*/
				return ECL_SCRIPT_ERROR;
			}
		}
	}

	if (op == '*') {
		n = X_MIN(ixa2[0],ixa3[2]);
		m = X_MIN(ixa2[2],ixa3[0]);
	}
	else {
		n = X_MIN(ixa2[0],ixa3[0]);
		m = X_MIN(ixa2[2],ixa3[2]);
	}
printf("%s: n=%d m=%d\n",_fn_,n,m);

	count = 0;
	for (i=0;i<n;i++) {
		index_info1[4] = ixa1[1] + i;
		index_info2[4] = ixa2[1] + i;
		index_info3[4] = ix3i = ixa3[1] + i;
		for (j=0;j<m;j++) {
printf("%s: i=%d j=%d\n",_fn_,i,j);
			index_info1[5] = ixa1[3] + j;
			index_info2[5] = ixa2[3] + j;
			if (op == '*') {
				index_info3[4] = ixa3[3] + j;
				index_info3[5] = ix3i;
			}
			else index_info3[5] = ixa3[3] + j;
printf("%s: index_info2=%d %d\n",_fn_,index_info2[4],index_info2[5]);
printf("%s: index_info3=%d %d\n",_fn_,index_info3[4],index_info3[5]);
			if (pInfoParm1 = _get_array_parm_by_index_opt(pIndex1,pTBL1,index_info1,'s')) {
				if (pInfoParm2 = _get_array_parm_by_index_opt(pIndex2,pTBL2,index_info2,'r')) {
					if (pInfoParm3 = _get_array_parm_by_index_opt(pIndex3,pTBL3,index_info3,'r')) {
						if (iRc=cl_gx_bexp(&tInfoParm,pInfoParm2,p1,pInfoParm3,0,0)) return iRc;
						if (iRc=cl_gx_rep_info_set(pInfoParm1,&tInfoParm,1)) return iRc;
						count++;
					}
				}
			}
		}
	}
	memcpy(pWork,&count,sizeof(int));
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_ope_opt(pAns,nparm,ppParm,ope,cmp_opt)
long *pAns;
int  nparm;
tdtInfoParm *ppParm[];
int  ope;
int  cmp_opt;
{
	int ret,ok_opt,*pWork,iAns;

DEBUGOUT_InfoParm(110,"cl_array_ope_opt:Enter ope=%d cmp_opt=%d ppParm[0]=",ppParm[0],ope,cmp_opt);
if (nparm > 2) {
DEBUGOUT_InfoParm(110,"                 ppParm[2]=",ppParm[2],0,0);
}
	ok_opt = 0x02 | 0x08 | 0x1000;
	if (cl_check_data_id(ppParm[0],~ok_opt)) return ECL_SCRIPT_ERROR;
	if (ope != D_FUC_ARRAY_CLR) {
		if (cl_check_data_id(ppParm[1],~ok_opt)) return ECL_SCRIPT_ERROR;	/* 2-->1 */
	}
	if (ope == D_FUC_ARRAY_BXP) {
		if (cl_check_data_id(ppParm[2],~ok_opt)) return ECL_SCRIPT_ERROR;	/* 4-->2 */
	}

	pWork = &iAns;
	if      (ope == D_FUC_ARRAY_CPY) ret = _array_cpy(pWork,nparm,ppParm);
	else if (ope == D_FUC_ARRAY_CLR) ret = _array_clr(pWork,nparm,ppParm);
	else if (ope == D_FUC_ARRAY_CMP) ret = _array_cmp(pWork,nparm,ppParm,cmp_opt);
	else if (ope == D_FUC_ARRAY_BXP) ret = _array_bxp(pWork,nparm,ppParm);
	else if (ope == D_FUC_MATRIX_BXP) ret = _matrix_bxp(pWork,nparm,ppParm);
	*pAns = iAns;
/*
printf("cl_array_ope_opt: ret=%d\n",ret);
*/
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_array_ope(pWork,pOperator,nparm,ppParm,ope,opt)
char *pWork,*pOperator;
int  nparm,ope,opt;
tdtInfoParm *ppParm[];
{
	return cl_array_ope_opt(pWork,nparm,ppParm,ope,0);
}

/****************************************/
/*										*/
/****************************************/
static int _list_array_set(pCt,pInfoParmI)
tdtRbCtl *pCt;
tdtInfoParm *pInfoParmI;
{
	char *(*m_alloc)();
	tdtCONSTCT *pConstCt;
	tdtInfoParm *pInfoParm1,*pInfoParm;
	tdtInfoParm ***pTBL;
	int iRc,n,i,ix,nm,len,iAns,iParm[4],count,match;
	tdtArrayIndex tIndex;
	char *p1;
	char *cpKey,*cpDat;
	XHASHB *xhp;
	tdtAllocCtl ac;

	if (iRc = _get_array_info(1,&pInfoParmI,&tIndex,&pTBL,iParm,3)) {
		if (iRc == 2000) xhp = tIndex.xhp;
		return iRc;
	}
	else xhp = NULL;
	nm = iParm[1];
	ix = iParm[2];

	m_alloc = pCt->rb_malloc;
	pConstCt = pCt->rb_constct;
	ac.ac_malloc  = m_alloc;
	ac.ac_constct = pConstCt;

	for (i=1;i<=nm;i++,ix++) {
		if (xhp) {
			xhp->xha_xhix = i;
			if ((iRc=akxs_xhash2(xhp,'P',&cpKey,&cpDat)) > 0) {
				memcpy(&pInfoParm,cpDat,sizeof(tdtInfoParm *));
			}
			else if (iRc < 0) return iRc;
			else continue;
		}
		else {
			pInfoParm = cl_get_array_and_var_ent_opt(&tIndex,pTBL,ix,'r');
		}
		if (pInfoParm) {
			if (cl_is_undef_parm(pInfoParm) || cl_is_null_parm(pInfoParm)) continue;
#if 1	/* 2024.6.2 */
			if (!(pInfoParm1=(tdtInfoParm *)akxm_malloc_constct(m_alloc,pConstCt,sizeof(tdtInfoParm))))
#else
			if (!(pInfoParm1=(tdtInfoParm *)cl_tmp_const_malloc(sizeof(tdtInfoParm))))
#endif
				return ECL_MALLOC_ERROR;
			if ((iRc=_tmp_list_info_set_ac(pInfoParm1,pInfoParm,&ac)) < 0) return iRc;
			if (!cl_tmp_rbset_n(pCt,pInfoParm1)) return ECL_MALLOC_ERROR;
		}
		else {
			return -1;
		}
	}

	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _append_list(pInfoParm,nparm,ppParm)
tdtInfoParm *pInfoParm;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm1,*p;
	tdtRbCtl *pCt;
	tdtAllocCtl ac;
	char c,c0;
	int rc,i,im;

	im = D_OPT_ALC_MALLOC;
	c0 = pInfoParm->pi_id;
	pCt = (tdtRbCtl *)pInfoParm->pi_data;
/*
printf("_append_list: pCt=%08x\n",pCt);
*/
	ac.ac_malloc  = pCt->rb_malloc;
	ac.ac_constct = pCt->rb_constct;
	for (i=0;i<nparm;i++) {
		p = ppParm[i];
		if (((c=p->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) && c==c0) {
			if ((rc=_list_copy_info(pCt,p->pi_data)) < 0) break;
		}
		else if (p->pi_aux[0] & DEF_ZOK_DATA) {
			if ((rc=_list_array_set(pCt,p)) < 0) break;
		}
		else if (!cl_is_null_parm(p)) {
			if (!(pInfoParm1=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm))))
				return ECL_MALLOC_ERROR;
			if ((rc=_tmp_list_info_set_ac(pInfoParm1,p,&ac)) < 0) break;
			if (!akxs_rb_set_n(pCt,pInfoParm1)) {
				rc = ECL_MALLOC_ERROR;
				break;
			}
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _append_incr(index,retval)
int index[],retval[];
{
	int fortran_type,ndim,nm,incr,i,ii,n,i_s,ix,num;

	fortran_type = cl_get_option(15,0) & 0x02;
	ndim = index[0];
	ii = 5;
	n = 1;
	i_s = 1;
	num = ndim;
	ix = 4;
	if (fortran_type) {
		i_s = 0;
		num = ndim - 1;
		ix = 4 + num;
	}
	for (i=i_s;i<num;i++) {
		n *= index[ii];
		ii++;
	}
	if (nm < 10) nm = 10;
	if (!n) incr = nm;
	else if (n > nm) incr = 1;
	else incr = (nm+n-1)/n;
	retval[0] = incr;
	retval[1] = n;
	retval[2] = ix;
/*
printf("_append_incr: incr=%d n=%d ix=%d\n",incr,n,ix);
*/
	return incr;
}

/****************************************/
/*										*/
/****************************************/
static int _append_redefine(pIndex,nm,pIndex0)
tdtArrayIndex *pIndex,*pIndex0;
int nm;
{
	tdtArrayIndex tIndex;
	int iParm[4],*index,ndim,i,ii,n,incr,rc,fortran_type,i_s,num,ix,retval[3],*index0,iDIFF;
/*
printf("cl_func_append: pIndex=%08x nm=%d pIndex0=%08x\n",pIndex,nm,pIndex0);
*/
	index = pIndex->index;
	index0 = pIndex0->index;
/*
printf("cl_func_append:1 index =%d %d %d %d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4],index[5],index[6],index[7]);
printf("cl_func_append:1 index0=%d %d %d %d %d %d %d %d\n",index0[0],index0[1],index0[2],index0[3],index0[4],index0[5],index0[6],index0[7]);
*/
	if (index[2]+index[3]-1+nm-1 < index0[1]+index0[3]-1) return 0;
	nm = index0[1]+index0[3]-1-index[2]-index[3]+1+1;

	iParm[0] = pIndex0->uAttr[0];
	iParm[2] = pIndex0->uAttr[2];
	iParm[3] = pIndex0->uAttr[3];
	iParm[1] = pIndex0->size;
	incr = _append_incr(index0,retval);
	n = retval[1];
	ix = retval[2];
	iDIFF = 0;
	if (memcmp(index,index0,sizeof(pIndex0->index))) {
		iDIFF = 1;
		_append_incr(index,retval);
	}
	memcpy(&tIndex,pIndex0,sizeof(tdtArrayIndex));
	num = tIndex.index[ix];
	num += incr;
	tIndex.index[ix] = num;
	tIndex.index[1] = n*num;
	rc = _def_array(-1,NULL,D_GX_OPT_REDEFINE,iParm,&tIndex,iParm[0],pIndex);
	if (!rc) {
		memcpy(pIndex0,&tIndex,sizeof(tdtArrayIndex));
/*
printf("cl_func_append:2 index0=%d %d %d %d %d %d %d %d\n",index0[0],index0[1],index0[2],index0[3],index0[4],index0[5],index0[6],index0[7]);
*/
		if (pIndex != pIndex0) {
			if (iDIFF) {
				index[1] = index0[1] - index0[3] - index[3];
				nm = (index[1]+retval[1]-1)/retval[1];
				index[retval[3]] = nm;
			}
			else memcpy(index,index0,sizeof(pIndex0->index));
			pIndex->pVarIndex = pIndex0->pVarIndex;
/*
printf("cl_func_append:2 index =%d %d %d %d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4],index[5],index[6],index[7]);
*/
		}
	}
/*
printf("cl_func_append: rc=%d\n",rc);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_append(pAns,nparm,ppParm)
long *pAns;
int  nparm;
tdtInfoParm *ppParm[];
{
	tdtInfoParm *pInfoParm,*pInfoParm1;
	tdtArrayIndex tIndex,*pIndex,tIndex0,*pIndex0;
	tdtRbCtl *pCt;
	char id;
	int rc,i,*index,s_ix,iParm[4],iAns,nm,*pWork,*index0;

DEBUGOUT_InfoParm(120,"cl_func_append:Enter nparm=%d ppParm[0]=",ppParm[0],nparm,0);
	iAns = 0;
	*pAns = iAns;
	pInfoParm = ppParm[0];
	if ((rc=cl_check_data_id2(pInfoParm,0x02|0x08|0x1000,0x03)) < 0) return rc;

	id = pInfoParm->pi_id;
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) {
		pInfoParm = ppParm[0];
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		nm = pCt->rb_used;
		rc = _append_list(pInfoParm,nparm-1,&ppParm[1]);
		iAns = pCt->rb_used - nm;
	}
	else if (id==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY) {
		if ((rc=cl_array_check_valid(pInfoParm)) < 0) return rc;
		pWork = &iAns;
		pIndex = &tIndex;
		if ((rc=_get_array_info_ref(1,&pInfoParm,&pIndex,NULL,iParm,0x03)) < 0) return rc;
/*
printf("cl_func_append: rc=%d\n",rc);
*/
		if (rc == 2000) {
			rc = cl_set_array_ix(pWork,nparm,ppParm,1);
		}
		else {
			pIndex0 = &tIndex0;
			pInfoParm1 = (tdtInfoParm *)pInfoParm->pi_paux;
			if ((rc=_get_array_info_ref(1,&pInfoParm1,&pIndex0,NULL,iParm,0x03)) < 0) return rc;
			index0 = pIndex0->index;
			index = pIndex->index;
/*
printf("cl_func_append: index =%d %d %d %d %d %d %d %d\n",index[0],index[1],index[2],index[3],index[4],index[5],index[6],index[7]);
printf("cl_func_append: index0=%d %d %d %d %d %d %d %d\n",index0[0],index0[1],index0[2],index0[3],index0[4],index0[5],index0[6],index0[7]);
*/
			s_ix = index[2];
			nm = nparm - 1;
			rc = _append_redefine(pIndex,nm,pIndex0);
			if (rc >= 0) {
				rc = cl_set_array_ix(pWork,nparm,ppParm,s_ix);
/*
printf("cl_func_append: rc=%d\n",rc);
*/
			}
		}
	}
	else {
		rc = -1;
	}
	*pAns = iAns;
DEBUGOUT_InfoParm(120,"cl_func_append:Exit iAns=%d rc=%d ppParm[0]=",ppParm[0],iAns,rc);

	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_tenkai(ppmstk,irs,pInfoParmW,da2,opt,pmstk,dastk,Ms_ppmstk,Ms_pmstk,Ms_dastk)
tdtInfoParm *pmstk,*pInfoParmW,*ppmstk[];
int irs,opt;
char *da2,*dastk[];
MCAT *Ms_ppmstk,*Ms_pmstk,*Ms_dastk;
{
	tdtRbCtl *pCt;
	tdtInfoParm *pInfo,*pmW,*pm;
	tdtInfoParm *pInfoParm1,*pParmI;
	tdtInfoParm ***pTBL;
	tdtArrayIndex tIndex,*pIndex;
	XHASHB *xhp;
	char id,*p1;
	int rc,optW,nm,*index,ix;

	id = pInfoParmW->pi_id;
	if (id==' ' && (pInfoParmW->pi_alen & D_AULN_RANGE_DATA)) {
		pInfoParmW->pi_aux[0] |= DEF_ZOK_DATA; 
		optW = opt;
		irs = cl_gx_range_tenkai(ppmstk,irs,pInfoParmW,optW,pmstk,dastk,
		                         Ms_ppmstk,Ms_pmstk,Ms_dastk);
	}
	else if (id=='L' || id=='N' || id=='A' || id=='R') {
		if (id=='L' || id=='N') {
			pCt = (tdtRbCtl *)pInfoParmW->pi_data;
		}
		else {
			pIndex = &tIndex;
			if (rc=cl_get_array_index_tbl_ref(pInfoParmW,&pIndex,&pTBL,"cl_gx_array_bexp:")) return rc;
			index = pIndex->index;
			if (xhp=pIndex->xhp) {
				if (!(p1 = (char *)pInfoParmW->pi_pos)) p1 = "";
						/* "%s: �A�z�z��(%s)�͎w��ł��܂���B*/
				ERROROUT2(FORMAT(239),"cl_gx_tenkai",p1);
				irs = ECL_SCRIPT_ERROR;
			}
		}
		nm = 0;
		ix = 1;
		while (irs >= 0) {
			if (id=='L' || id=='N') {
				if (!(pInfo = (tdtInfoParm *)akxs_rb_get_n(pCt))) break;
			}
			else {
				if (ix > index[2]) break;
				if (!(pInfo = cl_get_array_and_var_ent_opt(pIndex,pTBL,ix,'r'))) return -1;
				ix++;
			}
			pmW = &pmstk[irs];
			cl_gx_copy_info(pmW,pInfo);
			if (pmW->pi_id == 'S') pm = (tdtInfoParm *)pmW->pi_pos;
			else pm = pmW;
			if (!(id=pm->pi_id)) p1 = "";
			else if (id == ' ') parm_to_char_tmp(pm,&p1,0);
			else p1 = clstrdup(cl_get_variable_type(id),D_OPT_ALC_TMP);
			dastk[irs] = p1;
			ppmstk[irs++] = pmW;
			pInfo->pi_alen &= ~D_AULN_RANGE_INTVAL;	/* �r���͈��t���Ȃ� */
			nm++;
		}
		if (nm > 1) pmW->pi_alen |= D_AULN_RANGE_INTVAL;	/* �W�J���ꂽ�f�[�^�I���̈� */
	}
	else {
		/* %s: %s��'%s'�͎w��ł��܂���B */
		ERROROUT3(FORMAT(140),"cl_gx_tenkai",da2,"**");
		irs = ECL_EX_LET;
	}
	return irs;
}
