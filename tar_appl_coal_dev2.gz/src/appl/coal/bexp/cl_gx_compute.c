static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ���Z����                                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_compute( pLeaf )                             *
*                      (I)Leaf     *pLeaf                                     *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern GlobalCt *pGlobTable;
extern CLCOMMON CLcommon;
extern int giOptions[];
extern tdtIterate_ctl gtIter_ctl[];

/****************************************/
/*										*/
/****************************************/
static ulong _ppmm_ulong(atr,ulValue)
int atr;
ulong ulValue;
{
	if (atr == 14) {
		if (ulValue < ULONG_MAX) ulValue++;
	}
	else if (atr == 15) {
		if (ulValue > 0) ulValue--;
	}
	else if (atr == 16) ulValue = !ulValue;
	else ulValue = ~ulValue;
	return ulValue;
}

/****************************************/
/*										*/
/****************************************/
static long _ppmm_long(atr,lValue)
int atr;
long lValue;
{
	if (atr == 14) {
		if (lValue < LONG_MAX) lValue++;
	}
	else if (atr == 15) {
		if (lValue > LONG_MIN) lValue--;
	}
	else if (atr == 16) lValue = !lValue;
	else lValue = ~lValue;
	return lValue;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_ppmm_val(atr,pInfoParm)
int atr;
tdtInfoParm *pInfoParm;
{
	static char *name="_gx_ppmm_val";
	char *p;
	int  *pi,rc,iValue,size,iUNSIGNED;
	uint uiValue;
	long lValue,llen;
	ulong ulValue;
	double *pd,dValue;
	int  attr,iAttr[3],Val[2],sca;
	MPA *mpa;
	char work[64];

	p = pInfoParm->pi_paux;
	llen = pInfoParm->pi_len;
/*
printf("_gx_ppmm_val: atr=%d p=%08x\n",atr,p);
*/
	if ((attr=(int)(pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA)) == DEF_ZOK_BINA) {
		sca = pInfoParm->pi_scale;
		if (iUNSIGNED = sca & D_DATA_UNSIGNED) {
#if defined(_LP64)	/* 2021.9.7 */
			size = pInfoParm->pi_len;
			if (size == sizeof(int)) ulValue = *(uint *)p;
			else ulValue = *(ulong *)p;
			ulValue = _ppmm_ulong(atr,ulValue);
			cl_set_parm_bin(pInfoParm,ulValue);
			if (size == sizeof(int)) *(uint *)p = ulValue;
			else *(ulong *)p = ulValue;
#else
			ulValue = *(ulong *)p;
			ulValue = _ppmm_ulong(atr,ulValue);
			*(ulong *)p = ulValue;
			cl_set_parm_bin(pInfoParm,ulValue);
#endif
		}
		else {
#if defined(_LP64)	/* 2021.9.7 */
			size = pInfoParm->pi_len;
			if (size == sizeof(int)) lValue = *(int *)p;
			else lValue = *(long *)p;
			lValue = _ppmm_long(atr,lValue);
			cl_set_parm_bin(pInfoParm,lValue);
			if (size == sizeof(int)) *(int *)p = lValue;
			else *(long *)p = lValue;
#else
			lValue = *(int *)p;
			lValue = _ppmm_long(atr,lValue);
			*(int *)p = lValue;
			cl_set_parm_bin(pInfoParm,lValue);
#endif
		}
		pInfoParm->pi_scale = sca;
	}
	else if (attr == DEF_ZOK_FLOA) {
		dValue = *(double *)p;
		if (atr == 14) dValue++;
		else if (atr == 15) dValue--;
		else {
			/* %s: ���������_�f�[�^(%e)�́A�r�b�g���Z�ł��܂���B */
			ERROROUT2(FORMAT(141),name,dValue);
			return ECL_SCRIPT_ERROR;
		}
		*(double *)p = dValue;
		cl_set_parm_double(pInfoParm,dValue);
	}
	else if (attr == DEF_ZOK_DECI) {
		mpa = (MPA *)p;
		if (atr == 14) m_add1(mpa,m_get_i(1));
		else if (atr == 15) m_sub1(mpa,m_get_i(1));
		else {
			m_mpa2an(mpa,work,sizeof(work),pGlobTable->options[10]);
			/* %s: �P�O�i���������_�f�[�^(%s)�́A�r�b�g���Z�ł��܂���B */
			ERROROUT2(FORMAT(142),name,work);
			return ECL_SCRIPT_ERROR;
		}
		if (pInfoParm->pi_hlen) {
			if ((rc=cl_mpa_scale(p,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
		}
		m_cpy((MPA *)pInfoParm->pi_data,mpa,0);
	}
	else if (attr == DEF_ZOK_CHAR) {
		/* %s: �����f�[�^(%s)�́A���Z�ł��܂���B */
		ERROROUT2(FORMAT(143),name,p);
		return ECL_SCRIPT_ERROR;
	}
	pInfoParm->pi_paux = p;
	pInfoParm->pi_len = llen;
	pInfoParm->pi_aux[0] = attr;

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int _gx_ppmm(atr,pInfoParm)
int atr;
tdtInfoParm *pInfoParm;
{
	static char *name="_gx_ppmm";
	long   lValue;
	ulong ulValue;
	int  rc,iValue,mc,lenW,len,alen,iUNSIGNED;
	uint uiValue;
	int  attr0,attr,iAttr[3];
	long Valz[NMPA_LONG],*Val;
	double dValue;
	MPA *mpa;
	char work[64],*p,id,*pOpe;
	tdtInfoParm tInfoParmW,tInfoParm;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"_gx_ppmm:Enter atr=%d",pInfoParm,atr,0);

	if (!pInfoParm) return -1;
	if ((pGlobTable->options[1] & 0x02) &&
	     pInfoParm->pi_attr==DEF_ZOK_CHAR && !cl_is_none_parm(pInfoParm)) {
		if (atr==14 || atr==15) {
			mc = atr + 10;
			cl_set_parm_long(&tInfoParm,1);
			rc = cl_str_add(&tInfoParmW,mc,pInfoParm,&tInfoParm);
			if (!rc) {
				lenW = tInfoParmW.pi_dlen;
				len = pInfoParm->pi_dlen;
				alen = X_MAX(lenW,len);
				if (!(p=Strndup(tInfoParmW.pi_data,alen))) return ECL_MALLOC_ERROR;
				if (pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA) {
					if (len > lenW) memset(p+lenW,len-lenW,' ');
					memzcpy(pInfoParm->pi_paux,p,len);
					lenW = len;
				}
				cl_set_parm_char(pInfoParm,p,lenW);
			}
		}
		else {
			ERROROUT2(FORMAT(143),name,pInfoParm->pi_data);
			rc = ECL_SCRIPT_ERROR;
		}
		return rc;
	}
#if 1	/* 2021.3.29 */
	if ((id=pInfoParm->pi_id)=='A' || id=='R') {
		if (atr == 14) p = "+";
		else if (atr == 15) p = "-";
		else {
			return ECL_SCRIPT_ERROR;
		}
		cl_set_parm_long(&tInfoParm,1);
		if ((rc=cl_get_mapped_array(&tInfoParmW,pInfoParm,p,&tInfoParm)) < 0) return rc;
		cl_gx_copy_info(pInfoParm,&tInfoParmW);
		return 0;
	}
#endif
	if (rc=cl_check_data_id(pInfoParm,0)) return rc+ECL_CHK_VAR_ERROR;

	if (pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA) return _gx_ppmm_val(atr,pInfoParm);

	if ((attr0=pInfoParm->pi_attr)==DEF_ZOK_BINA && pInfoParm->pi_scale==0x40) {
		if (iUNSIGNED = pInfoParm->pi_scale & D_DATA_UNSIGNED) {
			ulValue = pInfoParm->pi_pos;
			ulValue = _ppmm_ulong(atr,ulValue);
			pInfoParm->pi_pos = ulValue;
/*
printf("_gx_ppmm: atr=%d ulValue=%ul\n",atr,ulValue);
*/
		}
		else {
			lValue = pInfoParm->pi_pos;
			lValue = _ppmm_long(atr,lValue);
			pInfoParm->pi_pos = lValue;
		}
/*
printf("_gx_ppmm: pInfoParm->pi_pos=%d\n",pInfoParm->pi_pos);
*/
	}
	else if (attr0 == DEF_ZOK_DECI) {
	  /* 2025.4.1 */
	  if ((pInfoParm->pi_alen & D_AULN_RANGE_DATA) && (pInfoParm->pi_alen & D_AULN_RATIONAL)) {
		if (atr == 14) pOpe = "+";
		else if (atr == 15) pOpe = "-";
		else {
			ERROROUT2(FORMAT(672),name,"");
			return ECL_SCRIPT_ERROR;
		}
		cl_set_parm_long(&tInfoParm,1);
		cl_cmpt_math_rational(&tInfoParmW,pOpe,pInfoParm,&tInfoParm);
		cl_gx_copy_info2(pInfoParm,&tInfoParmW);
	  }
	  else {
		mpa = (MPA *)pInfoParm->pi_data;
		if (atr == 14) m_add1(mpa,m_get_i(1));
		else if (atr == 15) m_sub1(mpa,m_get_i(1));
		else {
			m_mpa2an(mpa,work,sizeof(work),pGlobTable->options[10]);
			/* %s: �P�O�i���������_�f�[�^(%s)�́A�r�b�g���Z�ł��܂���B */
			ERROROUT2(FORMAT(142),name,work);
			return ECL_SCRIPT_ERROR;
		}
		if (pInfoParm->pi_hlen) {
			if ((rc=cl_mpa_scale(mpa,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
		}
/*
m_mpa2an(mpa,work,sizeof(work),pGlobTable->options[10]);
printf("%s ",work);
*/
	  }
	}
	else if (attr0 == DEF_ZOK_DATE) {
		mpa = (MPA *)pInfoParm->pi_data;
		if (atr == 14) lValue = 1;
		else if (atr == 15) lValue = -1;
		else {
			ERROROUT1(FORMAT(619),name);
			return ECL_SCRIPT_ERROR;
		}
		akxc_date_add_term(mpa,lValue,3);
	}
	else {
		Val = cl_get_tmpMPA(Valz);
		if ((rc=cl_get_parm_mpa(pInfoParm,Val,"_gx_ppmm:",iAttr)) < 0) return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParm->pi_scale & D_DATA_MALLOC) Free(pInfoParm->pi_data);
		if ((attr=iAttr[0]) == DEF_ZOK_BINA) {
			if (iAttr[2]  & AKX_NUM_U) {
				ulValue = _ppmm_ulong(atr,Val[0]);
/*
printf("_gx_ppmm: ulValue=%u\n",ulValue);
*/
				cl_set_parm_long(pInfoParm,ulValue);
				pInfoParm->pi_scale |= D_DATA_UNSIGNED;
			}
			else {
				lValue = _ppmm_long(atr,Val[0]);
/*
printf("_gx_ppmm: lValue=%d\n",lValue);
*/
				cl_set_parm_long(pInfoParm,lValue);
			}
		}
		else if (attr == DEF_ZOK_FLOA) {
			memcpy(&dValue,Val,sizeof(double));
			if (atr == 14) dValue++;
			else if (atr == 15) dValue--;
			else {
				/* %s: ���������_�f�[�^(%e)�́A�r�b�g���Z�ł��܂���B */
				ERROROUT2(FORMAT(141),name,dValue);
				return ECL_SCRIPT_ERROR;
			}
/*
printf("_gx_ppmm: dValue=%f\n",dValue);
*/
			cl_set_parm_double(pInfoParm,dValue);
		}
		else if (attr == DEF_ZOK_DECI) {
			if (atr == 14) m_add1((MPA *)Val,m_get_i(1));
			else if (atr == 15) m_sub1((MPA *)Val,m_get_i(1));
			else {
				m_mpa2an((MPA *)Val,work,sizeof(work),pGlobTable->options[10]);
				/* %s: �P�O�i���������_�f�[�^(%s)�́A�r�b�g���Z�ł��܂���B */
				ERROROUT2(FORMAT(142),name,work);
				return ECL_SCRIPT_ERROR;
			}
/*
printf("_gx_ppmm: dValue=%f\n",dValue);
*/
			cl_set_parm_mpa(pInfoParm,Val);
		}
		else {
			/* %s: ���l�ȊO�́A���Z�ł��܂���B */
			ERROROUT1(FORMAT(144),name);
			return ECL_SCRIPT_ERROR;
		}
	}

	return 0;
}

/********1*********2*********3*********4*********5*********6*********7***/
/* �@�\ : �R�}���h�̃p�����[�^��ϊ����ApParm�ɐݒ肷��					*/
/*		  pParm�̊e�v�f�̐擪�A�h���X��ppParm�ɐݒ肷��					*/
/*  ppParm[0]           <-- &pParm[0]			<-- 0�N���A				*/
/*  ppParm[1]           <-- &pParm[1]			<-- 0�N���A				*/
/*  ppParm[ipa]         <-- &pParm[ipa]         <-- prmp[0]�̕ϊ�����	*/
/*  ppParm[ipa+1]       <-- &pParm[ipa+1]       <-- prmp[1]		�V		*/
/*  �E�E�E																*/
/*  ppParm[ipa+nparm-1] <-- &pParm[ipa+nparm-1] <-- prmp[nparm-1] �V	*/
/*																		*/
/* ���� : ppParm	: InfoParm�\���̂ւ̃|�C���^�z��					*/
/*					  NULL�̂Ƃ��́Atmp_malloc����pppParm�ɕԂ��B		*/
/*						pppParm=NULL�̂Ƃ��́A�G���[�B					*/
/*					  pParm�́AInfoParm�\���̔z��Btmp_alloc()�����	*/
/*					  ppParm�ɂ́ApParm�̊e�v�f�̐擪�A�h���X������		*/
/*		  ipa		: prmp�̕ϊ����ʂ�ݒ肷��ppParm�̈ʒu(�擪��0)		*/
/*		  nparm		: prmp�̐�											*/
/*		  prmp		: �R�}���h�̃p�����[�^�̃|�C���^�z��				*/
/*					  =NULL�̂Ƃ��́A�ϊ����Ȃ��B			�A			*/
/*		  Obj		: Obj												*/
/*		  opt		: cl_gx_exp_obj_opt()��opt							*/
/*		  pppParm	: <>NULL�̂Ƃ��Atmp_malloc����ppParm��Ԃ��|�C���^�B*/
/*						ppParm[0]�ɂ́ApParm������B					*/
/*					  prmp=NULL,nParm>0�̂Ƃ��́AppParm0=*pppParm�ŁA	*/
/*						a)pParm0=ppParm0[0]��<>NULL�̂Ƃ��́A			*/
/*						  pParm+ipa�̗̈��pParm0�̗̈��				*/
/*						  cl_gx_copy_info()�ŃR�s�[����B				*/
/*						b)pParm0=NULL�̂Ƃ��́A0�N���A����B			*/
/*		  pSetNum	: pParm[]�ɐݒ肵����								*/
/* �ԋp : ���^�[���R�[�h												*/
/*		  = 0 : ����													*/
/*		  < 0 : �G���[													*/
/*				= ECL_MALLOC_ERROR : tmp_malloc()�G���[					*/
/*				= -1 : ppParm=NULL and pppParm=NULL						*/
/*				���̑� : cl_gx_exp_obj_opt()<0 �̂Ƃ��̒l				*/
/*======================================================================*/
/* ��1  : ipa+nparm��pParm�̈���m�ۂ���B							*/
/*		  ppParm�̈�́A�m�ۍς݁B										*/
/*			cl_gx_parm_conv_arg(ppParm,ipa,nparm,NULL,Obj,0,NULL,NULL);	*/
/* ��2  : ipa+nparm��pParm�̈��ppParm�̈���m�ۂ��AppParm�̈��		*/
/*		  �A�h���X��ppParm�ɕԂ��B										*/
/*		  (��)nparm>0�̂Ƃ��́AppParm=NULL�Ƃ��Ȃ���΂Ȃ�Ȃ�			*/
/*			cl_gx_parm_conv_arg(NULL,ipa,nparm,NULL,Obj,0,&ppParm,NULL);*/
/* ��3  : ipa+nparm��pParm�̈��ppParm�̈���m�ۂ��AppParm�̈��		*/
/*		  �A�h���X��ppParm�ɕԂ��B�ݒ�ς݂�nparm��pParm�̈��		*/
/*		  �V���Ɋm�ۂ����̈�pParm+ip�ɃR�s�[����B						*/
/*			tdtInfoParm pParm[nparm],**ppParm,*ppParmW[1];				*/
/*			ppParmW[0] = pParm;											*/
/*			ppParm = ppParmW;											*/
/*			cl_gx_parm_conv_arg(NULL,ipa,nParm,NULL,Obj,0,&ppParm,NULL);*/
/* ��4  : ipa+nparm��pParm�̈��ppParm�̈���m�ۂ��AppParm�̈��		*/
/*		  �A�h���X��ppParm�ɕԂ��Bnparm�̃R�}���h�p�����[�^��ϊ���	*/
/*		  �V���Ɋm�ۂ����̈�pParm+ip�ɐݒ肷��B						*/
/*			cl_gx_parm_conv_arg(NULL,ipa,nParm,prmp,Obj,opt,&ppParm,NULL);*/
/************************************************************************/
int cl_gx_parm_conv_arg(ppParm,ipa,nparm,prmp,Obj,opt,pppParm,pSetNum)
tdtInfoParm *ppParm[],***pppParm;
int ipa,nparm,opt,*pSetNum;
parmList *prmp[];
tdtInfoParm **Obj;
{
	int i,ii,npa,rc,ret;
	tdtInfoParm **ppParm0,*pParm0,*pParm;

/*
printf("cl_gx_parm_conv_arg:Enter: ppParm=%08x\n",ppParm);
*/
	rc = 0;
	if (pSetNum) *pSetNum = 0;
	if ((npa=ipa+nparm) > 0) {
		pParm0 = NULL;
		if (!prmp && nparm && pppParm) {
			if (akxm_addrchk(ppParm0 = *pppParm)) pParm0 = ppParm0[0];
		}
		if (!ppParm) {
			if (!pppParm) return -1;
			if (!(ppParm=(tdtInfoParm **)cl_tmp_const_malloc(npa*sizeof(tdtInfoParm *)))) return ECL_MALLOC_ERROR;
			*pppParm = ppParm;
/*
printf("cl_gx_parm_conv_arg:malloc: ppParm=%08x\n",ppParm);
*/
		}
		if (pParm=(tdtInfoParm *)cl_tmp_const_malloc(npa*sizeof(tdtInfoParm))) {
			for (i=0;i<ipa;i++) {
				ppParm[i] = pParm++;
			}
			opt &= ~D_GX_OPT_PARMINFO2;
			ii = i;
			for (i=0;i<nparm;i++) {
				if (prmp) {
					if ((ret=cl_gx_exp_obj_opt(1,&prmp[i],Obj,pParm,opt)) < 0) {
						rc = ret;
						break;
					}
				}
				else if (pParm0) cl_gx_copy_info(pParm,pParm0++);
/*
DEBUGOUT_InfoParm(0,"cl_gx_parm_conv_arg: i=%d ret=%d",pParm,i,ret);
*/
				ppParm[ii++] = pParm++;
			}
			if (pSetNum) *pSetNum = ii;
		}
		else rc = ECL_MALLOC_ERROR;
	}
/*
DEBUGOUT_InfoParm(0,"cl_gx_parm_conv_arg: rc=%d",ppParm[0],ret,0);
*/
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_bexp_func_bexp(pInfoParmW,pInfoParm1,pOperator,pInfoParm2,nparm,prmp)
tdtInfoParm *pInfoParmW;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
char *pOperator;
int nparm;
parmList  *prmp[];
{
	tdtInfoParm **ppParm,*pParm,*ppParm0[2],pParm0[2];
	int rc;

	if (nparm > 0) {
		if ((rc=cl_gx_parm_conv_arg(NULL,2,nparm,prmp,NULL,0,&ppParm,NULL)) < 0) return rc;
		cl_gx_copy_info(ppParm[0],pInfoParm1);
		cl_gx_copy_info(ppParm[1],pInfoParm2);
		pParm = ppParm[0];
	}
	else {
		ppParm = ppParm0;
#if 1	/* 2024.4.6 */
		ppParm[0] =	pInfoParm1;
		ppParm[1] =	pInfoParm2;
#else
		pParm = pParm0;
		cl_gx_copy_info(&pParm[0],pInfoParm1);
		cl_gx_copy_info(&pParm[1],pInfoParm2);
		ppParm[0] =	&pParm[0];
		ppParm[1] =	&pParm[1];
#endif
	}
	if ((rc=cl_gx_func_bexp(pInfoParmW,pOperator,nparm+2,ppParm,0,pParm)) < 0) return rc;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_compute(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
{
	static  char *fname="cl_gx_compute";
	int		rc, scale,len;
	char	*pOperator, *pWork, wk[33],c,*name,cPM;
	parmList  *pparmList1;
	parmList  *pparmList2;
	parmList  *pparmList3;
	tdtInfoParm InfoParm1,*pInfoParm1;
	tdtInfoParm InfoParm2,*pInfoParm2;
	tdtInfoParm InfoParm0,*pInfoParm0;
	tdtInfoParm InfoParmW,*pInfoParmW;
	tdtInfoParm *pInfoParm;
	ScrPrCT	  *pScCT;
	parmList  **parmp;
	char cM_QUOTE1 = pGlobTable->Quot[0];

	parmp = pLeaf->cmd.prmp;
	pInfoParm = NULL;
	pInfoParm0 = &InfoParm0;
	cPM = '\0';
	name = parmp[0]->prp;
	if ((len=parmp[0]->prmlen) > 2) {
		if (akxnrskipin(name,len,"+-") == (len-2)) {
			cPM = name[len-2];
			len -=2;
		}
	}
	if (rc=cl_gx_expsn_obj_opt(name,len,parmp[0]->bxobj,proc->Obj,pInfoParm0,
	                   D_GX_OPT_STORE|D_GX_OPT_GET_ADDR|D_GX_OPT_NOEROUT_NDEF)) return rc;
/*
printf("cl_gx_compute: pi_len=%08x pi_paux=%08x pi_hlen=%d\n",pInfoParm0->pi_len,pInfoParm0->pi_paux,pInfoParm0->pi_hlen);
*/
	if (pInfoParm0->pi_id == D_DATA_ID_STOREVAR) {
		if (pInfoParm = (tdtInfoParm *)pInfoParm0->pi_pos) {
			if (pInfoParm->pi_aux[1] & D_AUX1_PROTECTED) rc = ECL_CAN_NOT_STORE;
			else if (((c=pInfoParm->pi_id)=='A' || c=='R') &&
			    (pInfoParm->pi_scale & D_DATA_INDEX_FREE)) {
				rc = ECL_CAN_NOT_STORE;
			}
		}
		else rc = ECL_CAN_NOT_STORE;
	}
	else rc = ECL_CAN_NOT_STORE;
	if (rc == ECL_CAN_NOT_STORE) {
		/* %s: %s�ւ͑���͂ł��܂���B */
		ERROROUT2(FORMAT(126),fname,parmp[0]->prp);
		return rc;
	}
	pparmList2 = parmp[2]; 	/* �E�ӂP	*/
	if (pparmList2->prp[0] == cM_QUOTE1) {
		if (rc=cl_conv_const_c(pparmList2,&InfoParm1)) return rc;
	}
	else {
		if (rc=cl_gx_exp_obj_opt(1,&parmp[2],proc->Obj,&InfoParm1,0)) return rc;
	}
	cl_parm_set0(&InfoParm2);
	if (pLeaf->cmd.prmnum >= 5)	{	/* �񍀉��Z�q����̏ꍇ		*/
		pparmList3 = parmp[4]; 	/* �E�ӂQ	*/
		if (pparmList3->prp[0] == cM_QUOTE1) {
			if (rc=cl_conv_const_c(pparmList3,&InfoParm2)) return rc;
		}
		else {
			if (rc=cl_gx_exp_obj_opt(1,&parmp[4],proc->Obj,&InfoParm2,0)) return rc;
		}
	}
	pInfoParmW = &InfoParmW;
  if (cl_is_null_value(&InfoParm1) || cl_is_null_value(&InfoParm2)) {
  		cl_null_value(pInfoParmW);
  }
  else {
	if (pLeaf->cmd.prmnum >= 5)	{	/* �񍀉��Z�q����̏ꍇ		*/
		pOperator = parmp[3]->prp;
		rc = cl_gx_bexp(pInfoParmW,&InfoParm1,pOperator,&InfoParm2,
		            pLeaf->cmd.prmnum-5, &parmp[5]);
		if (rc) {
			/* %s: �񍀉��Z���Ɍ�肪����܂��B */
			ERROROUT1(FORMAT(145),fname);
			return rc;
		}
	}
	else {
		cl_gx_copy_info(pInfoParmW,&InfoParm1);
	}
  }
	len = parmp[1]->prmlen;
	if (len > 1) {
		if (pInfoParm0->pi_id=='\0') {
			/* %s: %s�̃f�[�^�����ݒ�ł��B */
			ERROROUT2(FORMAT(127),fname,parmp[0]->prp);
			return ECL_NDEFVAR_ERROR;
		}
		if (len > sizeof(wk)-1) {
			/* %s: ������Z�q(%)���������܂��B */
			ERROROUT2(FORMAT(146),fname,parmp[1]->prp);
			return ECL_SCRIPT_ERROR;
		}
		memzcpy(wk,parmp[1]->prp,len-1);
		if (!(pInfoParm1 = pInfoParm)) pInfoParm1 = pInfoParm0;
		pInfoParm2 = pInfoParmW;
		pInfoParmW = &InfoParm1;
		if (rc=cl_gx_bexp(pInfoParmW,pInfoParm1,wk,pInfoParm2,0,NULL))
			return rc;
	}
#if 1	/* 2021.10.27 */
	if (rc=cl_gx_rep_info_als(pInfoParm,pInfoParmW,1)) return rc;
#else
	if (rc=cl_gx_rep_info_set(pInfoParm,pInfoParmW,1)) return rc;
#endif
	if (cPM) rc = _gx_ppmm(cPM=='+'?14:15,pInfoParm);
#if 1	/* 2023.10.2 */
	if ((rc=cl_set_max_var_array_ent(pInfoParm0)) < 0) return rc;
#endif
	return rc;
}

/********1*********2*********3*********4*********5*********6*/
/*  �@�\ : ���̕��т����s���A�ŏ��̎��̑���ϐ��̃|�C���^	*/
/*		   �܂��͒l��Ԃ��B									*/
/*		   ���̕��ёS�̂�������(())�ň͂܂�Ă���Ƃ��́A	*/
/*		   �Ō�̎���Ԃ��B									*/
/*  ���� : IN	nparm	   :	*/
/*				prmp[]	   :	*/
/*				Obj		   :	*/
/*				opt		   :	*/
/*				ppInfoParm : <>NULL�̂Ƃ��A�|�C���^��Ԃ�	*/
/*				pInfoParmW : <>NULL�̂Ƃ��A�l��Ԃ�(�D��)	*/
/************************************************************/
int let_compute_sub_opt(nparm,prmp,Obj,opt,ppInfoParm,pInfoParmW)
int nparm;
parmList *prmp[];
tdtObjHead *Obj;
int opt;
tdtInfoParm **ppInfoParm,*pInfoParmW;
{
	char *_fn_="let_compute_sub_opt";
	int rc;
	tdtInfoParm tInfoParm2[2],*pInfoParm;
/*
printf("let_compute_sub_opt:Enter: nparm=%d opt=%08x ppInfoParm=%08x\n",nparm,opt,ppInfoParm);
*/
	if (pInfoParmW || ppInfoParm) opt |= D_GX_OPT_PARMINFO2;
	if (!pInfoParmW && ppInfoParm) opt |= D_GX_OPT_GET_ADDR;
	if (ppInfoParm) *ppInfoParm = NULL;
	if (pInfoParmW) cl_parm_set0(pInfoParmW);

	if ((rc=cl_gx_exp_obj_opt(nparm,prmp,Obj,tInfoParm2,opt)) < 0)	{
		/* %s: ��������Ă��܂�(rc=%d)�B */
		ERROROUT2(FORMAT(48),_fn_,rc);
		rc = ECL_EX_LET;
/*
printf("let_compute_sub_opt: rc=%d opt=%08x exception=%08x\n",rc,opt,pGlobTable->exception);
*/
	}
	else {
		cl_get_InfoParm2(tInfoParm2,&pInfoParm,NULL);
		rc = 0;
		if (pInfoParmW) {
			if (pInfoParm->pi_id == D_DATA_ID_STOREVAR)
				pInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			cl_gx_copy_info(pInfoParmW,pInfoParm);
		}
		else if (ppInfoParm) {
			if (pInfoParm->pi_id == D_DATA_ID_STOREVAR)
				*ppInfoParm = (tdtInfoParm *)pInfoParm->pi_pos;
			else {
#if 1	/* 2022.09.24 */
				ERROROUT1(FORMAT(642),_fn_);	/* %s: �ϐ��̃A�h���X���擾�ł��܂���ł����B*/
				ERROROUT1(FORMAT(51),_fn_);		/* %s: ��������K�v�ł��B */
#else
				ERROROUT2(FORMAT(126),_fn_,"ppInfoParm");	/* "%s: %s�ɂ͑���ł��܂���B*/
#endif
				rc = ECL_CAN_NOT_STORE;
			}
		}
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int let_compute_sub(nparm,prmp,Obj)
int nparm;
parmList *prmp[];
tdtObjHead *Obj;
{
	return let_compute_sub_opt(nparm,prmp,Obj,0,NULL,NULL);
}

/****************************************/
/*	ppInfoParm : �|�C���^��Ԃ�			*/
/****************************************/
int let_compute_prmp_info(nparm,prmp,proc,opt,ppInfoParm)
int nparm;
parmList *prmp[];
ProcCT  *proc;
int opt;
tdtInfoParm **ppInfoParm;
{
	tdtObjHead *pObj;

	if (proc) pObj = proc->Obj;
	else pObj = cl_gx_get_scr_obj();
	return let_compute_sub_opt(nparm,prmp,pObj,opt,ppInfoParm,NULL);
}

/****************************************/
/*	pInfoParmW : �l��Ԃ�				*/
/****************************************/
int let_compute_prmp_infoW(nparm,prmp,proc,opt,pInfoParmW)
int nparm;
parmList *prmp[];
ProcCT  *proc;
int opt;
tdtInfoParm *pInfoParmW;
{
	tdtObjHead *pObj;

	if (proc) pObj = proc->Obj;
	else pObj = cl_gx_get_scr_obj();
	return let_compute_sub_opt(nparm,prmp,pObj,opt,NULL,pInfoParmW);
}

/****************************************/
/*										*/
/****************************************/
int let_compute_info(pLeaf, proc, opt, ppInfoParm)
Leaf *pLeaf;
ProcCT  *proc;
int opt;
tdtInfoParm **ppInfoParm;
{
	tdtObjHead *pObj;

	if (proc) pObj = proc->Obj;
	else pObj = cl_gx_get_scr_obj();
	return let_compute_sub_opt(pLeaf->cmd.prmnum,pLeaf->cmd.prmp,pObj,opt,ppInfoParm,NULL);
}

/****************************************/
/*										*/
/****************************************/
int let_compute_opt(pLeaf, proc, opt)
Leaf *pLeaf;
ProcCT  *proc;
int opt;
{
	return let_compute_info(pLeaf, proc, opt, NULL);
}

/****************************************/
/*										*/
/****************************************/
int let_compute(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
{
	return let_compute_info(pLeaf, proc, 0, NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_process_let_return(pLeaf,proc)
Leaf *pLeaf;
ProcCT  *proc;
{
	tdtObjHead *pObj;
	MCAT **Msa;
	int rc,*iva,ix_obj0,iOpt,iTREE;
	tdtInfoParm tInfoParmW[2];
	GXObject *pGxObj;
	tdtStackObj *pSO;

	cmn_set_stat(FUN_PR,&proc->ptype,L_OFF);

	if (proc) pObj = proc->Obj;
	else pObj = cl_gx_get_scr_obj();

	pSO = proc->pStackObj;
	pGxObj = pSO->so_pGxObj;
	Msa = pSO->so_Msa;
	iva = pSO->so_iva;
	ix_obj0 = iva[8];
	iOpt    = iva[9];
	iTREE   = iva[10];

DEBUGOUTL3(110,"cl_process_let_return: ix_obj0=%d iOpt=%08x iTREE=%d",ix_obj0,iOpt,iTREE);

	cl_gx_copy_info(tInfoParmW,pSO->so_Info2);
DEBUGOUT_InfoParm(180,"cl_process_let_return: iTREE=%d tInfoParmW=",tInfoParmW,iTREE,0);
	if ((iTREE & 0x01) && pGxObj->ntree>0)
		rc = cl_gx_ex_tree_sub(0,pObj,ix_obj0,pGxObj,tInfoParmW,iOpt,Msa,iva);
	else
		rc = cl_gx_ex_obj_sub(pObj,ix_obj0,pGxObj,tInfoParmW,iOpt,Msa,iva);
/*
printf("cl_process_let_return: iva[10]=%d\n",iva[10]);
*/
	if (rc<0 || iva[10]==99) {
		cmn_set_stat(FUN_PR,&proc->ptype,L_OFF);
		cmn_set_stat(FUN_PR,&proc->pr_pFlag2,L_OFF);
	}
	return rc;
}

/********************************************/
/*	BEXP�R�}���h������Ă΂ꂽ�Ƃ�			*/
/*		nparm : ��3���ȍ~�̃p�����[�^��		*/
/*		prmp  : ���p�����[�^�z��ւ̃|�C���^*/
/*	������2�����Z����Ă΂ꂽ�Ƃ�			*/
/*		nparm : 0							*/
/*		prmp  : NULL						*/
/********************************************/
int cl_gx_bexp(pInfoParmW,pInfoParm1,pOperator,pInfoParm2,nparm,prmp)
char *pOperator;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm *pInfoParmW;
int nparm;
parmList  *prmp[];
{
	static char *name="cl_gx_bexp";
#if 1	/* 2021.3.10 */
	static char J[5][5]={0,0,0,0,0, 0,1,0,1,0, 0,0,1,1,2, 0,1,1,0,2, 0,0,2,2,0};
#else
	static char J[5][5]={0,0,0,0,0, 0,1,1,1,0, 0,1,1,1,0, 0,1,1,0,2, 0,0,0,2,0};
#endif
	int rc,rc2,ope;
	int dtlen,dtatr,scale,i1,i2,iParm[5],iVal,iUNSIG,code_type;
	long Valz[NMPA_LONG*2+1],lVal,*Val;
	char *pWork,msg[7],id1,id2,c;
	uchar pi_aux1,pi_aux2;
	tdtInfoParm *ppParm[2],pParm[2];
	ParList2 par2;

DEBUGOUT_InfoParm(LVL_GXEXOBJ,"cl_gx_bexp: Enter pInfoParm1=",pInfoParm1,0,0);
DEBUGOUT_InfoParm(LVL_GXEXOBJ,"                  pInfoParm2=",pInfoParm2,0,0);

#if 1	/* 2023.7.22 */
	ope = cl_gx_chk_opt(pOperator,0);			/*���Z�q�`�F�b�N			*/
	if (ope!=IS && (cl_is_null_value(pInfoParm1) || cl_is_null_value(pInfoParm2))) {
		cl_null_value(pInfoParmW);
		return 0;
	}
#endif
	memset(pInfoParmW,0,sizeof(tdtInfoParm));
	mem_set_int(iParm,0,5);

	Val = cl_get_tmpMPA2(Valz,2);
	pWork = (char *)Val;
	dtatr = DEF_ZOK_BINA;
	dtlen = iUNSIG = 0;
	scale = 0x40;
	code_type = CLcommon.cDataCode;
/*	ope = cl_gx_chk_opt(pOperator,0);	*/		/*���Z�q�`�F�b�N			*/

DEBUGOUTL2(120,"cl_gx_bexp: ope=%d pOperator=[%s]",ope,pOperator);

	id1 = pInfoParm1->pi_id;
	id2 = pInfoParm2->pi_id;
	if (id1=='S' || id2=='S') {
		if (ope==IS && id1=='S' && id2==' ') ;
		else {
					/* %s: %s�́A���Z�ł��܂���B*/
			ERROROUT2(FORMAT(187),name,FORMAT(339));
			return ECL_SCRIPT_ERROR;
		}
	}

	if (ope == MATH) {
		if (pInfoParm1->pi_attr==DEF_ZOK_DATE || pInfoParm2->pi_attr==DEF_ZOK_DATE) {
			return cl_cmpt_date(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
		}
		else if (((c=*pOperator)=='&' || c=='|') &&
		    (pInfoParm1->pi_attr==DEF_ZOK_CHAR && pInfoParm2->pi_attr==DEF_ZOK_CHAR)) {
			if (rc=concat(&pWork,pInfoParm1,pInfoParm2,nparm,prmp,NULL)) return rc;
			if (pWork) {
				dtlen = strlen(pWork);
				if ((rc=cl_sep_string_with_type(&par2,pWork,dtlen)) > 0) {
					code_type = par2.option;
					pWork = par2.par;
					dtlen = par2.parlen;
				}
			}
			else {
				dtlen = 0;
			}
			cl_set_parm_char2(pInfoParmW,pWork,dtlen,code_type);
			return 0;
		}
		else if ((pGlobTable->options[1] & 0x02) && ((c=*pOperator)=='*' || c=='+' || c=='-') &&
			     ((pInfoParm1->pi_attr==DEF_ZOK_CHAR && !cl_is_none_parm(pInfoParm1)) ||
				  (pInfoParm2->pi_attr==DEF_ZOK_CHAR && !cl_is_none_parm(pInfoParm2)))) {
			return cl_str_exp(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
		}
	/*
		id1 = pInfoParm1->pi_id;
		id2 = pInfoParm2->pi_id;
	*/
		pi_aux1 = (id1=='A'||id1=='R')&&(pInfoParm1->pi_aux[0] & DEF_ZOK_DATA);
		pi_aux2 = (id2=='A'||id2=='R')&&(pInfoParm2->pi_aux[0] & DEF_ZOK_DATA);
		i1 = i2 = 0;
		if (pi_aux1) i1 = 1;
		else if (id1=='L' || id1=='N') i1 = 2;
		else if (id1 == ' ') i1 = 3;
		else if (id1=='A'||id1=='R') i1 = 4;
		if (pi_aux2) i2 = 1;
		else if (id2=='L' || id2=='N') i2 = 2;
		else if (id2 == ' ') i2 = 3;
		else if (id2=='A'||id2=='R') i2 = 4;
/*
printf("cl_gx_bexp: pi_aux1=%02x pi_aux2=%02x id1=%c id2=%c\n",pi_aux1,pi_aux2,id1,id2);
printf("cl_gx_bexp: i1=%d i2=%d J=%d\n",i1,i2,J[i1][i2]);
*/
		if ((c=J[i1][i2]) == 1) {
			ope = AGGREGATE;
			if (cl_is_undef_parm(pInfoParm1) || cl_is_none_parm(pInfoParm1)) {
					/* %s: ���Z�q=%s�A���̏W�����Z�͂ł��܂���B */
				ERROROUT2(FORMAT(165),name,pOperator);
				return ECL_SCRIPT_ERROR;
			}
		}
		else if (c == 2) {	/* �z��̐擪�ʒu�ړ� */
			return cl_get_mapped_array(pInfoParmW,pInfoParm1,pOperator,pInfoParm2);
		}
		else {
			*msg = '\0';
			if (rc=cl_check_data_id(pInfoParm1,0)) {
				strcpy(msg,"1");
			}
			if (rc2=cl_check_data_id(pInfoParm2,0)) {
				rc = rc2;
				if (*msg) strcat(msg,",");
				strcat(msg,"2");
			}
			if (rc) {
				/* %s: �Z�p���Z�̑�%s���Ɍ�肪����܂��B */
				ERROROUT2(FORMAT(147),name,msg);
				return rc+ECL_CHK_VAR_ERROR;
			}
		}
	}
#if 1	/* 2021.4.23 */
	if (id1 == ' ') {
		if (ope == COMP) {
			if (!stricmp(pOperator,"MAX") || !stricmp(pOperator,"MIN") ||
			    !stricmp(pOperator,"SUM") || !stricmp(pOperator,"AVG")) ope = FUNCTION;
		/*	if (_get_comp_no(pOperator,0) < 0) ope = FUNCTION;	*/
		}
		else if (ope == TO) {
			if (stricmp(pOperator,"TO")) ope = FUNCTION;	/* TO �ȊO */
		}
		else if (!stricmp(pOperator,"ABS")) pInfoParm2 = pInfoParm1;
		else if (!stricmp(pOperator,"..")) {
			ope = FUNCTION;
			pOperator = "RANGE";
		}
	}
#endif
	switch (ope) {
		case MATH:							/* �Z�p���Z		*/
#if 1	/* 2022.7.12 */
			return cl_cmpt_math_info(pInfoParmW,pOperator,pInfoParm1,pInfoParm2);
#else
			if ((dtatr=cl_cmpt_math(pWork,pOperator,pInfoParm1,pInfoParm2,iParm)) < 0)
				return D_ERROR;
			break;
#endif
		case COMP:							/* ��r���Z		*/
			gtIter_ctl[0].itc_circ_ref = NULL;
			gtIter_ctl[1].itc_circ_ref = NULL;
			if ((dtatr=cl_cmpt_comp(&pWork,pOperator,pInfoParm1,pInfoParm2,nparm,prmp)) < 0)
				return D_ERROR;
			break;
		case LOGICAL:						/* �_�����Z		*/
			if ((rc=cl_cmpt_logic(pWork,pOperator,pInfoParm1,pInfoParm2)) != NORMAL)
				return D_ERROR;
			break;
		case IS:							/* is  ���Z		*/
			ppParm[0] = pInfoParm1;
			ppParm[1] = pInfoParm2;
			if (rc=cl_cmpt_is(pWork,2,ppParm)) {
				if (rc == -101) {
					cl_null_value(pInfoParmW);
					return 0;
				}
				return D_ERROR;
			}
			break;
		case STRING:						/* moji���Z		*/
			if ((rc=cl_cmpt_string(&pWork,pOperator,pInfoParm1,pInfoParm2,nparm,prmp)) != NORMAL)
				return D_ERROR;
			if (memicmp(pOperator,"ASC",3)) dtatr = DEF_ZOK_CHAR;
			else dtatr = DEF_ZOK_BINA;
			break;
		case TO:							/* to ���Z		*/
			ppParm[0] = pInfoParm1;
			ppParm[1] = pInfoParm2;
			if ((dtatr=cl_cmpt_to(&pWork,2,ppParm)) < 0)
				return dtatr;
			if (!dtatr) dtatr = DEF_ZOK_CHAR;
			else {
				if (dtatr & DEF_ZOK_USMASK) iUNSIG = D_DATA_UNSIGNED;
				dtatr &= DEF_ZOK_MASK;
			}
			break;
		case AGGREGATE:						/* �W�����Z		*/
			if ((rc=cl_cmpt_agg(pInfoParmW,pOperator,pInfoParm1,pInfoParm2)) < 0)
				return rc;
			return 0;
		case FUNCTION:						/* �֐�			*/
		case FUNCFILE:						/* �t�@�C���֐�	*/
		case FUNCMATH:						/* ���l���Z�֐�	*/
		case FUNCLOG:						/* ���O�֐�		*/
		case FUNCCAST:						/* CAST�֐�		*/
		case FUNC_OPE:						/* ���Z�q�Ŏ��s��	*/
#if 0
			if (nparm && nparm!=2) {
				/* %s: ���̐�(%d)���Q�ȊO�ł��B���Z�q=%s ope=%d */
				ERROROUT4(FORMAT(157),name,nparm,pOperator,ope);
				return ECL_SCRIPT_ERROR;
			}
#endif
			return cl_gx_bexp_func_bexp(pInfoParmW,pInfoParm1,pOperator,pInfoParm2,nparm,prmp);
		default:
			/* %s: ���Z�q(%s)�Ɍ�肪����܂��Bope=%d */
			ERROROUT3(FORMAT(148),name,pOperator,ope);
			return ECL_SCRIPT_ERROR;
	}

	if (dtatr == DEF_ZOK_CHAR) {
		if (pWork) {
			dtlen = strlen(pWork);
			scale = 0;
			if ((rc=cl_sep_string_with_type(&par2,pWork,dtlen)) > 0) {
				code_type = par2.option;
				pWork = par2.par;
				dtlen = par2.parlen;
			}
		}
	}
	else if (dtatr == DEF_ZOK_BINA) {
		memcpy(&lVal,pWork,sizeof(long));
		dtlen = sizeof(long);
		pInfoParmW->pi_pos  = lVal;
#if defined(_LP64)
		if (iParm[1] == sizeof(int)) {
			iVal = lVal;
			cl_set_parm_int(pInfoParmW,iVal);
			dtlen = sizeof(int);
		}
#endif
		pWork = (char *)&(pInfoParmW->pi_pos);
		if (iParm[D_IPARM_FLAG] & DEF_ZOK_USMASK) scale |= D_DATA_UNSIGNED;
	}
	else if (dtatr == DEF_ZOK_FLOA) {
		dtlen = sizeof(double);
		memcpy(&pInfoParmW->pi_pos,pWork,dtlen);
		pWork = (char *)&(pInfoParmW->pi_pos);
	}
	else if (dtatr == DEF_ZOK_DECI) {
		return cl_set_parm_mpa(pInfoParmW,pWork);
	}
	else if (dtatr == DEF_ZOK_DATE) {
		return cl_set_parm_date(pInfoParmW,pWork);
	}

	pInfoParmW->pi_id    = ' ';
	pInfoParmW->pi_attr  = dtatr;
	pInfoParmW->pi_scale = scale | iUNSIG;
	pInfoParmW->pi_code  = code_type;
	pInfoParmW->pi_dlen  = dtlen;
	pInfoParmW->pi_data  = pWork;
/*
printf("cl_gx_bexp: iParm=%d %d %d %d %d\n",iParm[0],iParm[1],iParm[2],iParm[3],iParm[4]);
*/
	pInfoParmW->pi_alen  = iParm[D_IPARM_FLAG] & D_AULN_OVERFLOW;

	return 0;
}

/****************************************/
/*										*/
/****************************************/
int let_compute_return(leaf,proc)
Leaf *leaf;
ProcCT  *proc;
{
	return -1;
}

/********1*********2*********3*********4*********5*********6*********/
/* ���� : opt     : �G���[�Ƃ���/�G���[�Ƃ��Ȃ�id���w�肷��			*/
/*		  opt2    : �`�F�b�N���@���w�肷��							*/
/*					01 : =0: ckid_opt��0x8000 ��������̂�			*/
/*							 �`�F�b�N���Ȃ�							*/
/*					02 : =0: opt�Ŏw�肵��id���G���[�Ƃ���			*/
/*					     =1: �G���[�Ƃ��Ȃ�							*/
/********************************************************************/
typedef struct {
	short ckid_opt;
	short ckid_no;
	short ckid_rc;
	char  ckid_id;
	char  ckid_np;
} tdtCheckId;
static tdtCheckId _chk_id[] = {
	 {0xa000,597,-14,' ',0}		/* 0x8000 + 0x2000 */
	,{0x01,115,-1,'F',0x01}
	,{0x02,149,-2,'A',0x02}
	,{0x02,150,-2,'R',0x02}
	,{0x04,589,-3,'U',0x11}		/* 151 *//* cl_get_variable_type()�Ŏg�����߂̕ύX */
	,{0x04,340,-3,'\0',0x10}	/* 152 *//* cl_get_variable_type()�Ŏg�����߂̕ύX */
	,{0x08,153,-4,D_DATA_ID_LIST,0}
	,{0x10,154,-5,'T',0}
	,{0x20,466,-6,'P',0x23}
	,{0x40,134,-7,'X',0}
	,{0x80,120,-8,'C',0x01}
	,{0x100,159,-9,'I',0x01}
	,{0x200,162,-10,'M',0x01}
	,{0x400,114,-11,'O',0x01}
	,{0x800,169,-12,D_DATA_ID_PNAME,0}
	,{0x1000,170,-13,D_DATA_ID_NARABI,0}
	,{0x4000,339,-15,'S',0}
	,{0,0,0,0,0}
};

int cl_check_data_id(pInfoParm,opt)
tdtInfoParm *pInfoParm;
int opt;
{
	return cl_check_data_id2(pInfoParm,opt,0);
}

/****************************************/
/*										*/
/****************************************/
int cl_check_data_id2(pInfoParm,opt,opt2)
tdtInfoParm *pInfoParm;
int opt,opt2;
{
	tdtCheckId *p;
	char c,*pn,*type,*fmt,cn,id,id_id;
	int ch_opt,i,j,iCHECK_NORMAL,attr,iCHECK,iCHECK_NO_ERROR,iERROR,id_no;

	if (!pInfoParm) return 0;
	iCHECK_NORMAL = opt2 & 0x01;
	iCHECK_NO_ERROR = opt2 & 0x02;
	if (!opt) opt = -1;
	c = pInfoParm->pi_id;
/*
printf("cl_check_data_id2: c=[%c] iCHECK_NORMAL=%02x iCHECK_NO_ERROR=%02x opt=%08x\n",c,iCHECK_NORMAL,iCHECK_NO_ERROR,opt);
*/
	p = &_chk_id[0];
	while (ch_opt=p->ckid_opt) {
		iERROR = 0;
#if 1	/* 2024.6.22 */
		ch_opt = opt & p->ckid_opt;
/*
id = p->ckid_id;
printf("cl_check_data_id2: id=[%c] ch_opt=%08x\n",id,ch_opt);
*/
		if (c == p->ckid_id) {
			if (!iCHECK_NORMAL && (p->ckid_opt & 0x8000)) break;
			else if (iCHECK_NO_ERROR) {
				if (ch_opt) break;
				else iERROR = 1;
			}
			else if (ch_opt) iERROR = 1;
			else break;
/*
printf("cl_check_data_id2: iERROR=%d\n",iERROR);
*/
#else
		if (!iCHECK_NORMAL && (p->ckid_opt & 0x8000));
		else if ((opt & p->ckid_opt) && (c==p->ckid_id)) {
			if (iCHECK_NO_ERROR) {
				p++;
				continue;
			}
#endif
			type = FORMAT(p->ckid_no);
			i = p->ckid_np;
			j = i & 0xf0;
			i &= 0x0f;
/*
printf("cl_check_data_id2: c=[%c] i=%02x j=%02x\n",c,i,j);
*/
			pn = "";
			if (i == 1) {
				pn = pInfoParm->pi_data;
				if ((cn=*pn)>='0' && cn<='9') pn = cl_get_func_name(atoi(pn),NULL);
			}
			else if (i == 2) pn = (char *)pInfoParm->pi_pos;
			else if (i == 3) {
				pn = (char *)pInfoParm->pi_pos;
				attr = pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA;
				if (attr == D_AUX0_TYPE_STRUCT) type = FORMAT(154);
				else if (attr == D_AUX0_TYPE_ARRAY) type = FORMAT(150);
				else if (attr == D_AUX0_TYPE_MAPPED) type = FORMAT(149);
			}
			if (!j) {
				if (i) ERROROUT2(FORMAT(155),type,pn);			/* %s(%s)�͎w��ł��܂���B*/
				else ERROROUT1(FORMAT(158),type);				/* %s�͎w��ł��܂���B*/
			}
			else if (j == 0x10) {
				id_no = p->ckid_no;
				if ((id_id=p->ckid_id) == 'U') id_no = 151;
				else if (id_id == '\0') id_no = 152;
				fmt = FORMAT(id_no);
				if (i) ERROROUT1(fmt,pn);
				else ERROROUT(fmt);
			}
			else if (j == 0x20) {
				ERROROUT2(FORMAT(155),FORMAT(p->ckid_no),pn);	/* %s(%s)�͎w��ł��܂���B*/
			}
			return p->ckid_rc;
		}
		p++;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
char *cl_get_variable_type(id)
char id;
{
	char *p;
	tdtCheckId *pch;

	pch = &_chk_id[0];
	p = "";
	while (pch->ckid_opt) {
		if (id == pch->ckid_id) {
			p = FORMAT(pch->ckid_no);
			break;
		}
		pch++;
	}
/*
{char buf[128];
sprintf(buf,"cl_get_variable_type: id=[%c] p=[%s]\n",id,p);
cl_puts(buf);}
*/
	return p;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_let_ppmm(atr,pInfoParm)
int atr;
tdtInfoParm *pInfoParm;
{
#if 0
	if (pInfoParm->pi_id == 'S') {
				/* %s: %s�́A���Z�ł��܂���B*/
		ERROROUT2(FORMAT(187),"cl_gx_let_ppmm",FORMAT(339));
		return ECL_SCRIPT_ERROR;
	}
#endif
	if (atr < 0) atr = -atr;
	return _gx_ppmm(atr,pInfoParm);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_cast(pInfoParmW,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW,*pInfoParm1,*pInfoParm2;
{
	int rc,iParm[5],len,attr,iPOINTER,iRANGE,opt;
	char *p,c,*p0,buf[32];
	tdtInfoParm InfoParm1,*ppParm[2];

	iPOINTER = rc = 0;
#if 1	/* 2023.7.22 */
	if (cl_is_null_value(pInfoParm2)) {
		cl_null_value(pInfoParmW);
		return 0;
	}
#endif
	p0 = p = pInfoParm1->pi_data;
	if (!stricmp(p,"FUNC")) {
		rc = cl_func_f(pInfoParmW,1,&pInfoParm2);
	}
	else {
#if 1	/* add 2023.5.3 */
		len = pInfoParm1->pi_dlen;
/*
printf("cl_gx_cast: len=%d p=[%s]\n",len,p);
*/
		if (*(p+len-1) == '*') {
			len--;
			iPOINTER = 1;
		}
#endif
		if ((attr=(pInfoParm1->pi_aux[0] & ~DEF_ZOK_DATA)) == FUNCCAST) {
#if 1	/* 2021.3.19 */
			if ((c=*p)=='$' || c=='%' || c=='#') {
				pInfoParm1 = &InfoParm1;
				if (rc=_conv_arg_opt2(p,len,pInfoParm1,0)) return rc;
				if (pInfoParm1->pi_id==' ' && pInfoParm1->pi_attr==DEF_ZOK_CHAR) {
					p0 = p = pInfoParm1->pi_data;
					len = pInfoParm1->pi_dlen;
				}
				else {
							/* %s: [%s]������Ă��܂��B*/
					ERROROUT2(FORMAT(125),"cl_gx_cast",p);
					return ECL_SCRIPT_ERROR;
				}
			}
#endif
			if ((c=*p)=='C' || c=='c') {
				if ((c=*(p+1))!='H' && c!='h') {
					p++;
					len--;
				}
			}
			if (rc=cl_get_def_attr_opt(p,len,iParm,0x01,NULL,NULL)) return rc;
		}
		else {
			iParm[0] = attr;
			iParm[1] = pInfoParm1->pi_len;
			iParm[2] = pInfoParm1->pi_hlen;
			iParm[3] = pInfoParm1->pi_pos;
		}
/*
printf("cl_gx_cast: %s rc=%d iParm=%d %d %d %d\n",p,rc,iParm[0],iParm[1],iParm[2],iParm[3]);
*/
		if (iParm[0]==DEF_ZOK_DATE && iParm[2]) {
			ppParm[0] = pInfoParm2;
			ppParm[1] = pInfoParm1;
			return cl_func_to_date(pInfoParmW,2,ppParm);
		}
#if 1	/* add 2023.7.17 */
		else if (iParm[0] == DEF_ZOK_IMGE) {
			if ((attr=pInfoParm2->pi_attr) == DEF_ZOK_CHAR) {
				if ((rc=cl_conv_const_n_str(pInfoParmW,pInfoParm2->pi_data,pInfoParm2->pi_dlen)) < 0) return rc;
			}
			else if (attr <= DEF_ZOK_DECI) {
				if (pInfoParm2->pi_alen & D_AULN_COMPLEX_DATA) {
					ppParm[0] = pInfoParm2;
					ppParm[1] = &InfoParm1;
					cl_set_parm_char(&InfoParm1,"Image",5);
					if ((rc=cl_func_getval(pInfoParmW,2,ppParm)) < 0) return rc;
				}
				else cl_gx_copy_info(pInfoParmW,pInfoParm2);
			}
			else {
				cl_print_attr(buf,sizeof(buf),pInfoParm2,NULL);
				ERROROUT2(FORMAT(636),"cl_gx_cast",buf);	/* %s: %s�͎w��ł��܂���B*/
				return ECL_SCRIPT_ERROR;
			}
			pInfoParmW->pi_scale |= D_DATA_IMAGE;
		}
#endif
		else if (iParm[0]) {
#if 1	/* add 2023.5.3 */
			if (iPOINTER) {
				if (!(pInfoParm2->pi_aux[1] & D_AUX1_POINTER)) {
							/*%s: (%s)�̑Ώۂ��A�|�C���^�ł͂���܂���B*/
					ERROROUT2(FORMAT(658),"cl_gx_cast",p0);
					return ECL_SCRIPT_ERROR;
				}
				cl_gx_copy_info(pInfoParmW,pInfoParm2);
				pInfoParmW->pi_len  = iParm[1];
				pInfoParmW->pi_hlen = iParm[2];
				pInfoParmW->pi_aux[0] = iParm[0];
				pInfoParmW->pi_alen = iParm[3];
			}
			else {
#endif
				iRANGE = pInfoParm2->pi_alen & (D_AULN_COMPLEX_DATA | D_AULN_RANGE_DATA);
				opt = 0x01 | D_GX_OPT_ALC_TMP | iRANGE;
				if (iParm[0] != DEF_ZOK_VARI)
					rc = cl_set_parm_init(pInfoParmW,iParm,opt);
				else
					rc = cl_parm_set0(pInfoParmW);
				pInfoParmW->pi_alen |= iRANGE;
				if (!rc) rc = cl_gx_rep_info_set(pInfoParmW,pInfoParm2,opt);
#if 1	/* add 2023.5.3 */
			}
#endif
		}
		else rc = -100;	/*ECL_SCRIPT_ERROR; 2021.4.8 */
	}
/*	if (rc < 0) {	2021.4.8 */
	if (rc == -100) {
		/* cl_gx_cast: %s is not suported cast attr. */
		ERROROUT1(FORMAT(161),p0);
		if (rc == -100) rc = ECL_SYSTEM_ERROR;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_check_attr(pInfoParm,attr0,msg)
tdtInfoParm *pInfoParm;
int attr0;
char *msg;
{
	int ret,attr;

	if (ret=cl_check_data_id(pInfoParm,0)) return ret+ECL_CHK_VAR_ERROR;
	else if ((attr=pInfoParm->pi_attr) != attr0) {
				/* %s: �f�[�^����(%d)���w�葮��(%d)�ƈقȂ��Ă��܂��B */
		if (msg) ERROROUT3(FORMAT(160),msg,attr,attr0);
		return ECL_SCRIPT_ERROR;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_mk_cast(pInfoParmW,pm,nparm,ppParm)
tdtInfoParm *pInfoParmW,*pm;
int nparm;
tdtInfoParm *ppParm[];
{
	int rc,len,attr,size,iParm[4];
	qSubCommand *sc;
	char *p,c;

	rc = 0;
	p = pm->pi_data;
	len = pm->pi_dlen;
	if ((c=*p)=='C' || c=='c') {
		if ((c=*(p+1))!='H' && c!='h') {
			p++;
			len--;
		}
	}
	if (nparm<=0 || nparm>2) {
		/* %s: �����A�܂��́A���x�A�ʎ��̎w�萔(%d)���s���ł��B */
		ERROROUT2(FORMAT(479),"cl_gx_mk_cast",nparm);
		return ECL_SCRIPT_ERROR;
	}

	if (*(p+len-1) == '*') len--;	/* add 2023.5.3 */
	if (sc=cl_get_name_attr2(p,len,0x01,0x20)) {
		size = sc->size;
		attr = sc->attr & D_AUX0_ZOK_MASK;	/* add & D_AUX0_ZOK_MASK 2021.11.4 */
/*
printf("cl_gx_mk_cast: nparm=%d attr=%d\n",nparm,attr);
*/
		if (attr==DEF_ZOK_DATE && nparm>0) {
			cl_gx_copy_info(pInfoParmW,ppParm[0]);
			pInfoParmW->pi_aux[0] = attr;
			pInfoParmW->pi_hlen   = pInfoParmW->pi_dlen;
		}
		else {
			if (attr==DEF_ZOK_CHAR || attr==DEF_ZOK_BULK) size = 0;
			iParm[0] = attr;
			iParm[1] = size;
			iParm[2] = 0;
			iParm[3] = 0;
			if (nparm > 0) {
				if (!(rc=cl_get_def_attr_check(nparm,ppParm,iParm,0x01))) {
					*pInfoParmW = *pm;
					pInfoParmW->pi_aux[0] = iParm[0];
					pInfoParmW->pi_len    = iParm[1];
					pInfoParmW->pi_hlen   = iParm[2];	/* precision */
					pInfoParmW->pi_pos    = iParm[3];	/* scale */
#if 1	/* add 2021.11.4 */
					if (attr==DEF_ZOK_BINA && (sc->attr & DEF_ZOK_USMASK))
						pInfoParmW->pi_scale |= D_DATA_UNSIGNED;
#endif
				}
			}
		}
	}
	else {
				/* "%s: [%s]�ɂ́A�����A�܂��́A���x�A�ʎ��͎w��ł��܂���B*/
		ERROROUT2(FORMAT(480),"cl_gx_mk_cast",strmemk(p,len,"cl_gx_mk_cast"));
	/*	ERROROUT2(FORMAT(480),"cl_gx_mk_cast",strmem(p,len));	*/
		rc = ECL_NOT_CAST_NAME;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_conv(pInfoParmW,ope,pOperator,nparm,ppParm)
tdtInfoParm *pInfoParmW;
int ope;
char *pOperator;
int nparm;
tdtInfoParm *ppParm[];
{
	int rc;
	tdtInfoParm tInfoParm1,*pInfoParm1,tInfoParm;

	cl_set_parm_char(&tInfoParm,pOperator,strlen(pOperator));
	if (nparm >= 2) {
		pInfoParm1 = &tInfoParm1;
		rc = cl_gx_mk_cast(pInfoParm1,&tInfoParm,nparm-1,&ppParm[1]);
/*
printf("cl_func_conv: nparm=%d attr=%d\n",nparm,pInfoParm1->pi_attr);
*/
	/*
		if (pInfoParm1->pi_attr == DEF_ZOK_DATE) {
			return cl_func_to_date(pInfoParmW,nparm,ppParm);
		}
	*/
	}
	else {
		pInfoParm1 = &tInfoParm;
		pInfoParm1->pi_aux[0] = FUNCCAST;
		rc = 0;
	}
	if (!rc) rc = cl_gx_cast(pInfoParmW,pInfoParm1,ppParm[0]);
	return rc;
}
