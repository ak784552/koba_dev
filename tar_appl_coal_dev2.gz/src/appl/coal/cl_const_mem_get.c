static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �萔�̈�l��                                           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_const_mem_get( pCnCB ,Len )			          *
*                      (O)ConstCB	*pCnCB	                                  *
*                      (I)int		Len                                       *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern CLPRTBL *pGLprocTable;
extern CLPRTBL *pCLprocTable;

/****************************************/
/*										*/
/****************************************/
char *cl_const_malloc(Len)
int		Len;
{
	if (!pCLprocTable->ConstCt) {
		pCLprocTable->ConstCt = cl_const_ct_new();
		if (!pCLprocTable->ConstCt) return NULL;
	}
	return akxm_cct_malloc(pCLprocTable->ConstCt,Len);
}

/****************************************/
/*										*/
/****************************************/
char *cl_const_ct_malloc(ConstCt,Len)
ConstantCt *ConstCt;
int		Len;
{
	return akxm_cct_malloc(ConstCt,Len);
}

/****************************************/
/*										*/
/****************************************/
ConstantCt *cl_const_ct_new()
{
	return akxm_cct_mem_new(0);
/*	return akxm_cct_mem_new_opt(0,1);	*/
}

/****************************************/
/*										*/
/****************************************/
ConstantCt *cl_const_ct_new_opt(opt)
int opt;
{
	return akxm_cct_mem_new_opt(0,opt);
}

static ConstantCt TmpConstCt = {NULL,NULL,AKX_CNBD_SIZE,0,0,0};
static ConstantCt *pTmpConstCt = NULL;

/****************************************/
/*										*/
/****************************************/
int cl_tmp_const_ct_set(pConstCt)
ConstantCt *pConstCt;
{
	pTmpConstCt = pConstCt;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_tmp_set_const_ct_size(proc,size)
ProcCT *proc;
int size;
{
	int rc;

	if (!proc) return -1;
	rc = 0;
	proc->cct_cmb_size = size;
	if (size > 0) {
		rc = akxm_cct_set_conct_size(proc->pTmpConstCt,size,0);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static char *_tmp_const_malloc_opt(mem,len,opt)
char *mem;
int len,opt;
{
	ProcCT *proc;

	if (!pTmpConstCt) {
		if (proc = cl_search_proc_ct()) {
			if (!(pTmpConstCt = proc->pTmpConstCt)) {
#if 1	/* 2025.5.18 */
/*
printf("_tmp_const_malloc_opt: proc->cct_cmb_size=%d\n",proc->cct_cmb_size);
*/
				if (!(pTmpConstCt = cl_const_ct_new_opt(proc->cct_cmb_size))) return NULL;
#else
				if (!(pTmpConstCt = cl_const_ct_new_opt(0))) return NULL;
#endif
/*
printf("_tmp_const_malloc_opt: pTmpConstCt=%08x\n",pTmpConstCt);
*/
				proc->pTmpConstCt = pTmpConstCt;
			}
		}
		else pTmpConstCt = &TmpConstCt;
	}
DEBUGOUTL3(195,"cl_tmp_const_malloc: pTmpConstCt=%08x len=%d opt=%08x",pTmpConstCt,len,opt);
	if (opt == 1)
		akxm_cct_mem_reget(pTmpConstCt,len,&mem);
	else if (opt == 2)
		akxm_cct_mem_put(pTmpConstCt,mem);
	else
		mem = akxm_cct_malloc(pTmpConstCt,len);
/*
printf("_tmp_const_malloc_opt: mem=%08x\n",mem);
*/
	if (pTmpConstCt == &TmpConstCt) pTmpConstCt = NULL;
if (!mem) printf("cl_tmp_const_malloc: pTmpConstCt=%08x len=%d opt=%08x\n",pTmpConstCt,len,opt);
DEBUGOUTL2(195,"cl_tmp_const_malloc: pTmpConstCt=%08x mem=%08x",pTmpConstCt,mem);
	return mem;
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_malloc(len)
int len;
{
	return _tmp_const_malloc_opt(NULL,len,0);
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_remalloc(mem,len)
char *mem;
int len;
{
	return _tmp_const_malloc_opt(mem,len,1);
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_free(mem)
char *mem;
{
	return _tmp_const_malloc_opt(mem,0,2);
}

/****************************************/
/*										*/
/****************************************/
int cl_const_clear(pConstCt,iopt)
tdtCONSTCT *pConstCt;
int iopt;	/* =0:no free, >=1:free */
{
	tdtCMBCTL *cmb,*cmb1;
	int n,len;

	if (!pConstCt) return -1;

	cmb = pConstCt->cct_top;
	len = 0;
	while (cmb) {
		n = cmb->cbc_rem;
		cmb1 = cmb->cbc_next;
		if (iopt >= 1) {
			len += n;
			Free(cmb);
		}
		else {
			len += cmb->cbc_msize - n;
			cmb->cbc_rem = cmb->cbc_msize;
		}
		cmb = cmb1;
	}
	return len;
}

/****************************************/
/*										*/
/****************************************/
int cl_tmp_const_clear(iopt)
int iopt;	/* 0/1/2:no free/free/free TmpConstCt */
{
	tdtCMBCTL *cmb,*cmb1;
	ProcCT *proc;
	int n,len;
	tdtCONSTCT *pConstCtW;

	if (iopt == 2) {
		pConstCtW = pTmpConstCt;
		pTmpConstCt = &TmpConstCt;
	}
	else if (!pTmpConstCt) {
		if (proc = cl_search_proc_ct()) pTmpConstCt = proc->pTmpConstCt;
		else pTmpConstCt = &TmpConstCt;
	}
/*
printf("cl_tmp_const_clear: iopt=%d pConstCtW=%08x pTmpConstCt=%08x\n",iopt,pConstCtW,pTmpConstCt);
*/
#if 1	/* 2023.11.4 */
	len = cl_const_clear(pTmpConstCt,iopt);
#else
	cmb = pTmpConstCt->cct_top;
	len = 0;
	while (cmb) {
		n = cmb->cbc_rem;
		cmb1 = cmb->cbc_next;
		if (iopt >= 1) {
			len += n;
			Free(cmb);
		}
		else {
			len += cmb->cbc_msize - n;
			cmb->cbc_rem = cmb->cbc_msize;
		}
		cmb = cmb1;
	}
#endif
	if (iopt >= 1) {
		pTmpConstCt->cct_top  = NULL;
		pTmpConstCt->cct_cur  = NULL;
		pTmpConstCt->cct_rex = pTmpConstCt->cct_ext;
	}
	if (iopt == 2) pTmpConstCt = pConstCtW;
	if (pTmpConstCt == &TmpConstCt) pTmpConstCt = NULL;
	return len;
}

/****************************************/
/*										*/
/****************************************/
char *cl_scr_const_malloc(no,iLen)
int no,iLen;
{
	char *p = NULL;
	ScrPrCT *scrprct;
	ConstantCt *pCt,**ppCt;

	if (scrprct = cl_search_src_ct()) {
/*
printf("cl_scr_const_malloc: no=%d iLen=%d scr=%08x\n",no,iLen,scrprct);
*/
		if (no == D_OPT_ALC_FUN_PR) no = D_OPT_ALC_LEAF;
		if (no==D_OPT_ALC_SCR) ppCt=&scrprct->ConstCt;
		else if (no==D_OPT_ALC_LEAF) {
			if (scrprct->sc_pFlag2 & D_LEAF_IMPORTMODE) {
				scrprct = pGLprocTable->CurScr;
/*
printf("cl_scr_const_malloc: LeafConstCt=%08x\n",scrprct->LeafConstCt);
*/
			}
			ppCt=&scrprct->LeafConstCt;
		}
		else if (no==D_OPT_ALC_INTRACT) ppCt=&scrprct->ConstCt2;
		else return cl_tmp_const_malloc(iLen);
		pCt = *ppCt;
		if (!pCt) {
			if (pCt = cl_const_ct_new()) {
				*ppCt = pCt;
/*
printf("cl_scr_const_malloc: pCt=%08x ConstCt=%08x LeafConstCt=%08x\n",
pCt,scrprct->ConstCt,scrprct->LeafConstCt);
*/
			}
			else {
				return NULL;
			}
		}
		p = cl_const_ct_malloc(pCt,iLen);
	}
	else {
		p = cl_tmp_const_malloc(iLen);
	}
	return p;
}

/****************************************/
/*										*/
/****************************************/
char *cl_scr_malloc(iLen)
int iLen;
{
	return cl_scr_const_malloc(D_OPT_ALC_SCR,iLen);
}

/****************************************/
/*										*/
/****************************************/
char *cl_leaf_malloc(iLen)
int iLen;
{
	return cl_scr_const_malloc(D_OPT_ALC_LEAF,iLen);
}

/****************************************/
/*										*/
/****************************************/
char *cl_intr_malloc(iLen)
int iLen;
{
	return cl_scr_const_malloc(D_OPT_ALC_INTRACT,iLen);
}

/****************************************/
/*										*/
/****************************************/
char *cl_opt_malloc(im,iLen)
int im,iLen;
{
	char *p;
/*
printf("cl_opt_malloc:Enter im=%d iLen=%d\n",im,iLen);
*/
	if (iLen <= 0) return NULL;
	if (im == D_OPT_ALC_FUN_PR) im = D_OPT_ALC_LEAF;
	if      (im == D_OPT_ALC_LEAF  ) p = cl_leaf_malloc(iLen);		/* 0 */
	else if (im == D_OPT_ALC_CONST ) p = cl_const_malloc(iLen);		/* 1 */
	else if (im == D_OPT_ALC_SCR   ) p = cl_scr_malloc(iLen);		/* 2 */
	else if (im == D_OPT_ALC_TMP   ) p = cl_tmp_const_malloc(iLen);	/* 3 */
	else if (im == D_OPT_ALC_MALLOC) p = Malloc(iLen);				/* 4 */
	else if (im == D_OPT_ALC_INTRACT) p = cl_intr_malloc(iLen);		/* 5 */
	else p = NULL;
/*
printf("cl_opt_malloc: p=%08x\n",p);
*/
DEBUGOUTL3(200,"cl_opt_malloc:im=%d p=%08x len=%d",im,p,iLen);
	return p;
}

/****************************************/
/*										*/
/****************************************/
char *clmemdup(s,slen,im)
char *s;
int  slen,im;
{
	char *p;

	if (s) {
		if (p = cl_opt_malloc(im,slen+1))
			memzcpy(p,s,slen);
	}
	else p = NULL;
	return p;
}

/****************************************/
/*										*/
/****************************************/
char *clstrdup(s,im)
char *s;
int  im;
{
	if (s)
		return clmemdup(s,strlen(s),im);
	else
		return NULL;
}

/****************************************/
/*										*/
/****************************************/
long cl_opt_mem_used(im)
int im;
{
	ConstantCt *p;
	ScrPrCT *scrprct;
	long len;

	len = 0;
	p = NULL;
	if (im == D_OPT_ALC_FUN_PR) im = D_OPT_ALC_LEAF;
	if (im==D_OPT_ALC_LEAF || im==D_OPT_ALC_SCR) {
		if (scrprct=cl_search_src_ct()) {
			if (im == D_OPT_ALC_LEAF) p = scrprct->LeafConstCt;
			else p = scrprct->ConstCt;
		}
	}
	else if (im == D_OPT_ALC_CONST) p = pCLprocTable->ConstCt;
	else if (im == D_OPT_ALC_TMP) p = pTmpConstCt;
	else if (im == D_OPT_ALC_MALLOC) len = akxm_stat_memory(0,NULL);
	else len = -1;
	if (p) len = akxm_cct_mem_used(p);
/*
printf("cl_opt_mem_used: im=%d len=%d\n",im,len);
*/
	return len;
}

/****************************************/
/*										*/
/****************************************/
long cl_mem_used(n,lena)
int n;
long lena[];
{
	int i;
	long rc,len;

	rc = 0;
	if (lena) {
		for (i=0;i<n;i++) {
			len = cl_opt_mem_used(i);
			rc += X_MAX(0,len);
			lena[i] = len;
		}
	}
	else rc = -1;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
char *cl_const_ct_malloc2(ConstCt,Len,file,line)
ConstantCt *ConstCt;
int Len;
char *file;
int line;
{
	char *p,msg[20];

	sprintf(msg,"ConstCt=%08x",ConstCt);
	p = cl_const_ct_malloc(ConstCt,Len);
	akxm_malloc_called(Len,p,file,line,msg);
	return p;
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_malloc2(len,file,line)
int len;
char *file;
int line;
{
	char *p;

	p = cl_tmp_const_malloc(len);
	akxm_malloc_called(len,p,file,line,"tmp const");
	return p;
}

/****************************************/
/*										*/
/****************************************/
char *cl_opt_malloc2(im,iLen,file,line)
int im,iLen;
char *file;
int line;
{
	char *p,msg[16];

	sprintf(msg,"im=%d",im);
	p = cl_opt_malloc(im,iLen);
	akxm_malloc_called(iLen,0,file,line,msg);
	return p;
}
