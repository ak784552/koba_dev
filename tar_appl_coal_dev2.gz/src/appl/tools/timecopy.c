/*******************************************/
/*						*/
/* �t�@�C���̍Ō�̃A�N�Z�X���ԂƕύX���Ԃ��R�s�[���� */
/*	timecopy file1 file2	*/
/*						*/
/*		by A.Kobayashi 2000.9.13	*/
/*						*/
/*******************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#if defined(SUNOS) || defined(SUNOS5) || defined(AIX)
#include <jctype.h>
#endif
#include <string.h>
#include <memory.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/un.h>
#ifdef LINUX
#include <sys/dirent.h>
#else
#ifndef SUNOS5
#include <sys/dir.h>
#endif
#endif
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

int main(argc,argv)
int  argc;
char *argv[];
{
	struct stat tStat;
	struct timeval tval[2];

	if (argc < 3) {
		fprintf(stderr,"Usage: %s from_file to_file\n",argv[0]);
		exit(1);
	}

	if (stat(argv[1], &tStat)) {
		fprintf(stderr,"stat error file=[%s] errno=%d\n",argv[1],errno);
		exit(2);
	}

	memset(tval,0,sizeof(tval));
	tval[0].tv_sec = tStat.st_atime;      /* �t�@�C���̍Ō�̃A�N�Z�X���� */
	tval[1].tv_sec = tStat.st_mtime;      /* �t�@�C���̍Ō�̕ύX���� */

	if (utimes(argv[2], tval)) {
		fprintf(stderr,"utime file=[%s] errno=%d\n",argv[2],errno);
		exit(3);
	}
	exit(0);
}
