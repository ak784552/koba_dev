static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include testqnumber.c libakx.a -o testqnumber
*/
#include "akxcommon.h"
main()
{
	char expbuf[256];
	int ret,num,iParm[3];
	double dVal;

	for (;;) {
		printf("Enter number==>");
		gets(expbuf);
		if (!stricmp(expbuf,"/EOF")) break;
		ret = akxqnumber(expbuf,strlen(expbuf),0,iParm);
		printf("ret=%d iParm=%d %d %d\n",ret,iParm[0],iParm[1],iParm[2]);
	}
}
