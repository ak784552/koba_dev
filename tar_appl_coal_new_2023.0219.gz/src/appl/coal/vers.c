char version[] ="@(#) ***[V/R=7.3.1 (new)]***";

