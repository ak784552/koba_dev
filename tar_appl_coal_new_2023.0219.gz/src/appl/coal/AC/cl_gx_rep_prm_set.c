static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  ��������i�E�ӂ��ϐ��̎��j            �@�@�@           *
*                                                                             *
*      �֐����@�@�@�F�@int cl_gx_rep_info_set(pInfoParmO,pInfoParmI)          *
*                      (O)tdtInfoParm *pInfoParmO                             *
*                      (I)tdtInfoParm *pInfoParmI                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>
extern CLPRTBL CLprocTable;

static int _rep_list_info_set();
static int _gx_rep_all_data();

#ifdef GET_PARM_RANGE
/****************************************/
/*										*/
/****************************************/
static int _val_set_BINA_FLOA(p,atr,size,Val,attr,len,ix)
char *p;
int atr,size,Val[],attr,len,ix;
{
	int rc,iValue;
	char *name,*pV=(char *)Val;
	double dValue;

	name = "_val_set_BINA_FLOA";
	p += size*ix;
	pV += len*ix;
	if (ix) Val++;
	if (attr == DEF_ZOK_BINA) iValue = CL_GET_VAL_BIN(Val);
	else memcpy(&dValue,pV,sizeof(double));
	if (atr == DEF_ZOK_BINA) {
		if (attr == DEF_ZOK_FLOA) iValue = cl_chk_over_flow_d2_i(dValue,name);
		*(int *)p = iValue;
DEBUGOUTL2(151,"%s:BINA:%d",name,*(int *)p);
	}
	else {
		if (attr == DEF_ZOK_BINA) dValue = iValue;
		*(double *)p = dValue;
DEBUGOUTL2(151,"%s:FLOA:%f",name,*(double *)p);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _val_set_DECI(pInfoParm,p,size,Val,attr,len,ix)
tdtInfoParm *pInfoParm;
char *p;
int size,Val[],attr,len,ix;
{
	int rc;
	char *pV=(char *)Val;
	double dValue;

	p += size*ix;
	pV += len*ix;
	if (attr == DEF_ZOK_BINA) {
		m_i2mpa(Val[ix],(MPA *)p);
	}
	else if (attr == DEF_ZOK_FLOA) {
		memcpy(&dValue,pV,len);
		m_d2mpa(dValue,(MPA *)p);
	}
	else memcpy(p,pV,len);
	if (pInfoParm->pi_hlen) {
		if ((rc=cl_mpa_scale(p,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
	}
	return 0;
}
#endif
/****************************************/
/*										*/
/****************************************/
static char *_set_mem_size_zero(pInfoParm,size)
tdtInfoParm *pInfoParm;
int size;
{
	char *p;

	if (pInfoParm->pi_scale & D_DATA_MALLOC)
		p = Realloc(pInfoParm->pi_data,size);
	else
		p = cl_tmp_const_malloc(size);
	pInfoParm->pi_data = p;
	if (p) {
		pInfoParm->pi_data = p;
		pInfoParm->pi_paux = p;
	/*
		pInfoParm->pi_aux[0] = 0;
		pInfoParm->pi_paux = NULL;
	*/
	}
	return p;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_rep_val_set(pInfoParm,pInfoParmW)
tdtInfoParm *pInfoParm,*pInfoParmW;
{
	static char *name = "_gx_rep_val_set";
	int *pi,rc,iValue,iRANGE,dlen1,dlen2,dlen;
	int  atr,attr,size,iAttr[4],Val[NMPA_INT*2],len;
	double dValue,*pd;
	char *p,w1[32],*p1,*pV,c,w2[32],*p2;
	tdtInfoParm tInfoParmW;
	time_t tt;
	long lValue;
	struct  tm *stm;
	tdtInfoParm tInfoParm;

	p = pInfoParm->pi_paux;
	atr = pInfoParm->pi_aux[0] & ~DEF_ZOK_DATA;
/*
printf("%s:Enter atr=%d\n",name,atr);
*/
#if 1	/* 2018.5.28 */
	if (atr > 0) iAttr[0] = D_GX_OPT_USE_ATTR | atr;
	else iAttr[0] = 0;
#endif
	len = size = pInfoParm->pi_len;
	iRANGE = pInfoParmW->pi_alen & D_AULN_RANGE_DATA;
#ifdef GET_PARM_RANGE
	if (iRANGE = pInfoParmW->pi_alen & D_AULN_RANGE_DATA) {
		if (size>0 && atr!=DEF_ZOK_BINA) {
			if (atr == DEF_ZOK_CHAR) len++;
			len *= 2;
			p = _set_mem_size_zero(pInfoParm,len);
		}
	}
	pInfoParm->pi_alen |= iRANGE;
	pInfoParm->pi_aux[0] = atr | (pInfoParmW->pi_aux[0] & DEF_ZOK_DATA);
	pV = (char *)Val;
#endif
DEBUGOUTL4(151,"%s: atr=%d pi_paux=%08x pi_len=%d",name,atr,p,size);
#ifdef GET_PARM_RANGE
	if (atr == DEF_ZOK_BINA || atr == DEF_ZOK_FLOA) {
		if ((rc=cl_get_parm_range_double(pInfoParmW,Val,"_gx_rep_val_set.BINA/FLOA",iAttr)) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParm->pi_scale & 0x80) Free(pInfoParm->pi_data);
		if (rc=_val_set_BINA_FLOA(p,atr,size,Val,iAttr[0],iAttr[1],0)) return rc;
		if (iRANGE) {
			if (rc=_val_set_BINA_FLOA(p,atr,size,Val,iAttr[0],iAttr[1],1)) return rc;
		}
	}
#else
	if (atr == DEF_ZOK_BINA) {
		if ((rc=cl_get_parm_long(pInfoParmW,Val,"_gx_rep_val_set.BINA")) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParm->pi_scale & 0x80) Free(pInfoParm->pi_data);
		*(int *)p = Val[0];
DEBUGOUTL2(151,"%s:BINA:%d",name,*(int *)p);
	}
	else if (atr == DEF_ZOK_FLOA) {
		if ((rc=cl_get_parm_double(pInfoParmW,Val,"_gx_rep_val_set.FLOA",iAttr)) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (pInfoParm->pi_scale & 0x80) Free(pInfoParm->pi_data);
		memcpy(&dValue,Val,sizeof(double));
		*(double *)p = dValue;
DEBUGOUTL2(151,"%s:FLOA:%f",name,*(double *)p);
	}
#endif
	else if (atr == DEF_ZOK_DECI) {
#ifdef GET_PARM_RANGE
		if ((rc=cl_get_parm_range_mpa(pInfoParmW,Val,"_gx_rep_val_set.DECI",iAttr)) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		if (rc=_val_set_DECI(pInfoParm,p,size,Val,iAttr[0],iAttr[1],0)) return rc;
		if (iRANGE) {
			if (rc=_val_set_DECI(pInfoParm,p,size,Val,iAttr[0],iAttr[1],1)) return rc;
		}
#else
		if ((rc=cl_get_parm_dec(pInfoParmW,Val,"_gx_rep_val_set.DECI",iAttr)) < 0)
			 return rc;
		else if (rc > 0) return ECL_SCRIPT_ERROR;
		memcpy(p,Val,size);
		if (pInfoParm->pi_hlen) {
			if ((rc=cl_mpa_scale(p,pInfoParm->pi_hlen,pInfoParm->pi_pos))<0) return rc;
		}
#endif
	}
	else if (atr == DEF_ZOK_CHAR) {
		p1 = w1;
		if ((rc = parm_to_char(pInfoParmW,&p1,NULL)) < 0) return rc;
#if 1	/* 2016.12.10 Koba */
		if (iRANGE && size<=0) {
#else
		if (iRANGE) {
			if (size <= 0) {
#endif
				dlen1 = rc;
				cl_gx_copy_info(&tInfoParmW,pInfoParmW);
				tInfoParmW.pi_aux[0] = tInfoParmW.pi_alen = 0;
				if (tInfoParmW.pi_attr == DEF_ZOK_BINA) tInfoParmW.pi_pos = tInfoParmW.pi_hlen;
				else tInfoParmW.pi_data += tInfoParmW.pi_dlen;
				p2 = w2;
				if ((rc = parm_to_char(&tInfoParmW,&p2,NULL)) < 0) return rc;
				dlen2 = rc;
				dlen = X_MAX(dlen1,dlen2);
				if (!(p=_set_mem_size_zero(pInfoParm,dlen*2))) return ECL_MALLOC_ERROR;
				memzcpy(p,p1,dlen1);
				memzcpy(p+dlen,p2,dlen2);
DEBUGOUTL3(151,"%s:CHAR RANGE:[%s]..[%s]",name,p,p+dlen);
				pInfoParm->pi_dlen = dlen;
				pInfoParm->pi_alen |= iRANGE;
				pInfoParm->pi_aux[0] |= pInfoParmW->pi_aux[0] & DEF_ZOK_DATA;
#if 0	/* 2016.12.10 Koba */
			}
			else return -1;
#endif
		}
		else {
			if (size <= 0) {
				size = rc;
				if (!(p=_set_mem_size_zero(pInfoParm,size+1))) return ECL_MALLOC_ERROR;
			}
			pInfoParm->pi_dlen = memnzcpy(p,p1,rc,size);
DEBUGOUTL2(151,"%s:CHAR:[%s]",name,p);
		}
	}
	else if (atr == DEF_ZOK_BULK) {
	/*	if (pInfoParm->pi_len > 0) size = pInfoParm->pi_len;	*/
		if (!(p1=_to_bulk(pInfoParmW,iAttr,0))) return iAttr[0];
		if (size <= 0) {
			size = iAttr[1];
			if (!(p=_set_mem_size_zero(pInfoParm,size+sizeof(int)))) return ECL_MALLOC_ERROR;
		}
		pInfoParm->pi_dlen = rc = X_MIN(iAttr[1],size);
		memcpy(p+size,&rc,sizeof(int));
		memcpy(p,p1,rc);
DEBUGOUTL3(151,"%s:BULK:size=%d len=%d",name,size,rc);
	}
	else if (atr == DEF_ZOK_DATE) {
		if (rc=cl_get_parm_date(pInfoParmW,p,"DATE")) return rc;
DEBUGOUT_InfoParm(151,"cl_get_parm_date: size=%d",pInfoParm,size,0);
	}
	pInfoParm->pi_aux[1] &= ~(D_AUX1_PROTECTED | D_AUX1_HASHED_NAME);
#if 1	/* 2017.10.1 */
	pInfoParm->pi_alen |= pInfoParmW->pi_alen & D_AULN_FILE_POINTER;
#endif
/*
printf("%s:Exit\n",name);
*/
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _rep_list_copy(pInfoParmO,pInfoParmI,iOpt,pAC)
tdtInfoParm *pInfoParmO,*pInfoParmI;
int iOpt;
tdtAllocCtl *pAC;
{
	tdtInfoParm *p,*pInfoParm;
	int ret,rc=0;
	tdtRbCtl *pCt,*pCtI;

DEBUGOUTL1(110,"_rep_list_copy:Enter: iOpt=0x%08x",iOpt);

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) return 0;
	ret = akxm_alloc_ctl_is(pAC);
	if (ret) pCt = cl_tmp_rb_new(0,0,pAC->ac_constct);
	else pCt = akxs_rb_new(0,0);
	if (!pCt) return ECL_MALLOC_ERROR;
	pInfoParmO->pi_data = (char *)pCt;
	pInfoParmO->pi_scale = D_DATA_MALLOC;
	pCtI = (tdtRbCtl *)pInfoParmI->pi_data;
	akxs_rb_read(pCtI,0);
	while (p=(tdtInfoParm *)akxs_rb_read(pCtI,1)) {
		if (!(pInfoParm=(tdtInfoParm *)akxm_malloc_ctl(pAC,sizeof(tdtInfoParm))))
			return ECL_MALLOC_ERROR;
		rc = _rep_list_info_set(pInfoParm,p,iOpt,pAC);
DEBUGOUT_InfoParm(198,"_rep_list_copy: ",pInfoParm,0,0);
		if (!akxs_rb_set_n(pCt,pInfoParm)) return ECL_MALLOC_ERROR;
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
static int _rep_list_info_set(pInfoParmO,pInfoParmI,iOpt,pAC)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt;
tdtAllocCtl *pAC;
{
	char c,*p;
	int rc,ret;

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) return 0;
#if 1	/* 2019.6.9 */
	if (pInfoParmI->pi_id == 'S') {
		pInfoParmI = (tdtInfoParm *)pInfoParmI->pi_pos;
	}
#endif
	*pInfoParmO = *pInfoParmI;
	if ((c=pInfoParmO->pi_id)==D_DATA_ID_LIST || c==D_DATA_ID_NARABI) {
		if ((rc=_rep_list_copy(pInfoParmO,pInfoParmI,iOpt,pAC)) < 0) return rc;
	}
	else {
#if 1
		if (rc=cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt & 0x03,pAC)) return rc;
#else
		if (pInfoParmO->pi_scale & D_DATA_LPOSDATA)
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
		else if (iOpt >= 1) {
			pInfoParmO->pi_scale &= ~D_DATA_MALLOC;
			if (pInfoParmI->pi_dlen > 0) {
				ret = akxm_malloc_ctl_pp(pAC,pInfoParmI->pi_dlen+1,&p);
				if (!(pInfoParmO->pi_data=p)) {
					return ECL_MALLOC_ERROR;
				}
				memzcpy(pInfoParmO->pi_data,pInfoParmI->pi_data,pInfoParmI->pi_dlen);
				if (!ret) pInfoParmO->pi_scale |= D_DATA_MALLOC;
			}
			if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
		}
		if (iOpt <= 1) {
			if ((c=pInfoParmO->pi_id) == 'A' || c == 'R') {
				pInfoParmO->pi_scale &= ~D_DATA_INDEX_FREE;
			}
		}
#endif
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_val_set(pInfoParmO,pInfoParmI)
tdtInfoParm *pInfoParmO,*pInfoParmI;
{
	int ret,aux0,len;
	char *paux;
	tdtInfoParm tInfoParm,*pInfoParm;

DEBUGOUT_InfoParm(120,"cl_gx_rep_val_set: pInfoParmO=",pInfoParmO,0,0);
DEBUGOUT_InfoParm(120,"cl_gx_rep_val_set: pInfoParmI=",pInfoParmI,0,0);
	if (pInfoParmO->pi_paux && (pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA)) {
		ret = _gx_rep_val_set(pInfoParmO,pInfoParmI);
	}
	else {
		tInfoParm = *pInfoParmO;
		len  = tInfoParm.pi_len;
		paux = tInfoParm.pi_paux;
		aux0 = tInfoParm.pi_aux[0];
		tInfoParm.pi_paux   = tInfoParm.pi_data;
		tInfoParm.pi_aux[0] = tInfoParm.pi_attr;
		ret = _gx_rep_val_set(&tInfoParm,pInfoParmI);
		tInfoParm.pi_len = len;
		tInfoParm.pi_paux   = paux;
		tInfoParm.pi_aux[0] = aux0;
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt0,pAC)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
tdtAllocCtl *pAC;
{
	char c,id,*p;
	uchar aux0;
	int  rc,len,attr,alen,im,iOpt,iRANGE,ret;
	char *(*m_alloc)();
	tdtCONSTCT *pConstCt;

DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data:Enter: iOpt0=%08x pInfoParmI=",pInfoParmI,iOpt0,0);

	if (iOpt0 < 0) {
		iOpt = -1;
		iOpt0 = 0;
	}
	else iOpt = iOpt0 & 0x03;

	pInfoParmO->pi_aux[1] &= ~(D_AUX1_PROTECTED | D_AUX1_HASHED_NAME |
	                           D_AUX1_LOCAL_VAR | D_AUX1_PUBLIC_VAR | D_AUX1_GLOBAL_VAR);

#if 1
	if ((aux0=pInfoParmO->pi_aux[0]) & ~DEF_ZOK_DATA) {
		/* aux0���A17,18,19 �łȂ���΁A�N���A���� */
		if (!(aux0 & 0x10)) pInfoParmO->pi_aux[0] = '\0';
		pInfoParmO->pi_alen  &= D_AULN_RANGE_DATA;
		pInfoParmO->pi_paux   = NULL;
	}
#endif

	if (pInfoParmO->pi_scale & D_DATA_LPOSDATA)
		pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
	else if (iOpt >= 1) {
		iRANGE = pInfoParmI->pi_alen & D_AULN_RANGE_DATA;
		if (!(im=(iOpt0 & D_GX_OPT_ALC_MASK)>>12)) im = D_OPT_ALC_MALLOC;
		pInfoParmO->pi_scale &= ~D_DATA_MALLOC;
		if (pInfoParmI->pi_dlen > 0) {
			alen = len = pInfoParmI->pi_dlen;
			if ((id=pInfoParmI->pi_id)==' ' || id=='U') {
				attr = pInfoParmI->pi_attr;
				if (attr==DEF_ZOK_CHAR) alen++;
				else if (attr==DEF_ZOK_BULK) alen += sizeof(int);
				if (iRANGE) alen *= 2;
			}
			else if (id == 'F') alen++;
			ret = cl_malloc_ctl_im_pp(pAC,alen,im,&p);
			if (!(pInfoParmO->pi_data = p)) {
				if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
				return ECL_MALLOC_ERROR;
			}
			if (im==D_OPT_ALC_MALLOC && !ret) pInfoParmO->pi_scale |= D_DATA_MALLOC;
			memcpy(p,pInfoParmI->pi_data,alen);
			p += len;
			if ((id=pInfoParmO->pi_id)==' ' || id=='U') {
				if (attr==DEF_ZOK_CHAR && !iRANGE) *p = '\0';
			}
			else if (id == 'F') *p = '\0';
		}
		if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
	}
	if (iOpt <= 1) {
		if ((c=pInfoParmO->pi_id)=='A' || c=='R' || c=='P' || c=='T') {
			pInfoParmO->pi_scale &= ~D_DATA_INDEX_FREE;
			pInfoParmO->pi_alen |= D_AULN_NO_AL_LPOS;
		}
	}
DEBUGOUT_InfoParm(200,"cl_gx_rep_info_copy_data: pInfoParmO=",pInfoParmO,0,0);
	return 0;
}

/************************************************************/
/*	iOpt0 < 0 --> iIGN=1, iOpt<0							*/
/*	iOpt0 = 0x7000 (D_GX_OPT_ALC_MASK) 						*/
/*	      | 0x0003 (iOpt)									*/
/*	      | 0x0010 (ignore data of pInfoParmO)				*/
/*	iOpt = 0 : copy only									*/
/*	    >= 1 : copy & Malloc to_pi_data						*/
/*	    >= 2 : copy & Malloc to_pi_data & Free from_pi_data	*/
/************************************************************/
int cl_gx_rep_info_set_name_ac(pInfoParmO,pInfoParmI,iOpt0,name,pAC)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
char *name;
tdtAllocCtl *pAC;
{
	char c,id,*p;
	int  rc,len,attr,alen,iOpt,iIGN;
	ScrPrCT *scrct;
	ProcCT  *proc;
	uchar uc;
/*
printf("cl_gx_rep_info_set_name:Enter: iOpt0=%08x pInfoParmO=%08x pInfoParmI=%08x\n",iOpt0,pInfoParmO,pInfoParmI);
*/
DEBUGOUTL3(110,"cl_gx_rep_info_set_name_ac:Enter: iOpt0=%08x name=[%s] pAC=%08x",iOpt0,nval1(name),pAC);
DEBUGOUT_InfoParm(170,"cl_gx_rep_info_set_name_ac:O: ",pInfoParmO,0,0);
DEBUGOUT_InfoParm(170,"cl_gx_rep_info_set_name_ac:I: ",pInfoParmI,0,0);

	if (!pInfoParmO || !pInfoParmI) return -1;
	if (pInfoParmO == pInfoParmI) return 0;

	proc = NULL;
	if (iOpt0 < 0) {
		iOpt = -1;
		iIGN = 1;
	}
	else {
		iOpt = iOpt0 & 0x03;
		iIGN = iOpt0 & 0x10;
		if (pAC) {
			iIGN = 1;
			proc = (ProcCT *)pAC->ac_aux;
		/*	iOpt0 |= D_OPT_ALC_TMP;	*/
			pAC->ac_opt = iOpt0;
		}
	}
	if (!iIGN) {
		uc = pInfoParmO->pi_aux[1] & (D_AUX1_LOCAL_VAR | D_AUX1_PRIVATE_VAR | D_AUX1_PUBLIC_VAR);

		if (pInfoParmO->pi_id && (pInfoParmO->pi_aux[0] & ~DEF_ZOK_DATA)) {
			rc = _gx_rep_val_set(pInfoParmO,pInfoParmI);
			if (iOpt >= 2) cl_free_info_parm(pInfoParmI);
			return rc;
		}
	}
/*
scrct = cl_search_src_ct();
if (scrct) {
DEBUGOUTL3(110,"cl_gx_rep_info_set_name_ac:1: scrct=%08x ProCT=%08x Vary=%08x",scrct,scrct->ProCT,scrct->Vary);
DEBUGOUT_InfoParm(110,"cl_gx_rep_info_set_name_ac:1: ",pInfoParmO,0,0);
}
*/
/*
printf("cl_gx_rep_info_set_name: iIGN=%d iOpt=%08x\n",iIGN,iOpt);
*/
	if (!iIGN && (iOpt>=0)) cl_free_info_parm(pInfoParmO);

	*pInfoParmO = *pInfoParmI;
	if (!(id=pInfoParmO->pi_id)) return 0;

	pInfoParmO->pi_alen &= ~D_AULN_DATA_NARABI;
	if (!iIGN) {
		if ((pInfoParmI->pi_aux[0] & DEF_ZOK_DATA) ||
		    id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI) pInfoParmO->pi_aux[1] = uc;
	}
	if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI ||
	    ((id==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY || id==D_DATA_ID_STRUCT) &&
	      (pInfoParmI->pi_aux[0] & DEF_ZOK_DATA))) {
/*
printf("cl_gx_rep_info_set_name_ac: uc=%02x\n",uc);
*/
		if (id==D_DATA_ID_LIST || id==D_DATA_ID_NARABI)
			rc = _rep_list_copy(pInfoParmO,pInfoParmI,iOpt,pAC);
		else
			rc = _gx_rep_all_data(pInfoParmO,pInfoParmI,name,pAC);
		if (!rc) {
			if (uc & D_AUX1_LOCAL_VAR) {
				if (!proc) proc=cl_search_proc_ct();
				if (proc) pInfoParmO->pi_hlen = proc->ProcGid;
			}
			else if (!(uc & D_AUX1_PUBLIC_VAR)) {
				if (scrct=cl_search_src_ct()) pInfoParmO->pi_hlen = scrct->ScrGid;
			}
			pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
		}
		return rc;
	}

	if (rc=cl_gx_rep_info_copy_data(pInfoParmO,pInfoParmI,iOpt0,pAC)) return rc;

	if (pInfoParmO->pi_id=='I' && iOpt>0 && name) {
		Free(pInfoParmO->pi_data);
		pInfoParmO->pi_data = Strdup(name);
		pInfoParmO->pi_dlen = strlen(name);
	}
/*
if (scrct) {
DEBUGOUTL3(110,"cl_gx_rep_info_set_name_ac:2: scrct=%08x ProCT=%08x Vary=%08x",scrct,scrct->ProCT,scrct->Vary);
}
*/
DEBUGOUT_InfoParm(110,"cl_gx_rep_info_set_name_ac:Exit: O:",pInfoParmO,0,0);
/*
printf("cl_gx_rep_info_set_name_ac:Exit ret=0\n");
*/
	return NORMAL;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt0,name)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt0;
char *name;
{
	return cl_gx_rep_info_set_name_ac(pInfoParmO,pInfoParmI,iOpt0,name,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_info_set(pInfoParmO ,pInfoParmI ,iOpt)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt;
{
	return cl_gx_rep_info_set_name(pInfoParmO,pInfoParmI,iOpt,NULL);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_info_set_ac(pInfoParmO ,pInfoParmI ,iOpt, pAC)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
int iOpt;
tdtAllocCtl *pAC;
{
	return cl_gx_rep_info_set_name_ac(pInfoParmO,pInfoParmI,iOpt,NULL,pAC);
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_rep_info_set_alloc(pvParmO,pInfoParmI,opt)
tdtInfoParm **pvParmO,*pInfoParmI;
int opt;
{
	tdtInfoParm *pParm;

	if (!(pParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
	memset(pParm,0,sizeof(tdtInfoParm));
	*pvParmO = pParm;
	return cl_gx_rep_info_set(pParm,pInfoParmI,opt);
}

/****************************************/
/*										*/
/****************************************/
tdtInfoParm *cl_gx_copy_info(pInfoParmO, pInfoParmI)
tdtInfoParm  *pInfoParmO, *pInfoParmI;
{
	if (pInfoParmO != pInfoParmI) {
		*pInfoParmO = *pInfoParmI;
		if (pInfoParmO->pi_scale & D_DATA_LPOSDATA)
			pInfoParmO->pi_data = (char *)&pInfoParmO->pi_pos;
	}
	return pInfoParmO;
}

/****************************************/
/*										*/
/****************************************/
static int _array_get_info_parm_opt(ppParmI,pIndex1,pTBL1,i,ix1,opt)
tdtInfoParm **ppParmI;
tdtArrayIndex *pIndex1;
tdtInfoParm ***pTBL1;
int i,ix1;
char opt;
{
	if (pIndex1->xhp) ix1 = i;
	return cl_array_get_info_parm(ppParmI,pIndex1,pTBL1,ix1,opt);
}

/****************************************/
/*										*/
/****************************************/
static int _array_get_info_parm(ppParmI,pIndex1,pTBL1,i,ix1)
tdtInfoParm **ppParmI;
tdtArrayIndex *pIndex1;
tdtInfoParm ***pTBL1;
int i,ix1;
{
	return _array_get_info_parm_opt(ppParmI,pIndex1,pTBL1,i,ix1,'s');
}

/****************************************/
/*										*/
/****************************************/
static int _gx_rep_all_hash(xhpO,xhpI)
XHASHB *xhpI,*xhpO;
{
	tdtInfoParm *pParmI,*pParmO;
	char *cpKey,*cpDat;
	int rc,i,n;

	n = akxs_xhash2(xhpI,'M',NULL,NULL);
	for (i=1;i<=n;i++) {
		xhpI->xha_xhix = i;
		if ((rc=akxs_xhash2(xhpI,'P',&cpKey,&cpDat)) > 0) {
/*
printf("_gx_rep_all_array: i=%d key=[%s]\n",i,cpKey);
*/
			memcpy(&pParmI,cpDat,sizeof(tdtInfoParm *));
			if (!(pParmO=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm)))) return -1;
			memset(pParmO,0,sizeof(tdtInfoParm));
			if (rc = cl_gx_rep_info_set(pParmO,pParmI,1)) return rc;
			if ((rc=akxs_xhash2(xhpO,'S',cpKey,&pParmO)) < 0) return  rc;
			else if (!rc) return -12;
		}
		else if (rc < 0) return rc;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_rep_all_array(pInfoParmO,pInfoParmI,pAC)
tdtInfoParm *pInfoParmO,*pInfoParmI;
tdtAllocCtl *pAC;
{
	tdtArrayIndex *pIndexO,*pIndexI,tIndex;
	int *index,attr,size,len,n,i,rc,opti,i0,iParm[4],ix,ndim,iOpt;
	tdtInfoParm **pvParmI,**pvParmO,*pParmI,*pParmO;
	tdtInfoParm ***pTBL;
	char *name,*cpKey,*cpDat;
	ScrPrCT *pScCT;
	XHASHB *xhpI,*xhpO;

DEBUGOUT_InfoParm(120,"_gx_rep_all_array:pInfoParmO:",pInfoParmO,0,0);
DEBUGOUT_InfoParm(120,"_gx_rep_all_array:pInfoParmI:",pInfoParmI,0,0);

	pIndexI = (tdtArrayIndex *)pInfoParmI->pi_data;
	pIndexO = (tdtArrayIndex *)pInfoParmO->pi_data;
	if (rc=_get_array_info(1,&pInfoParmI,&tIndex,&pTBL,iParm,1)) {
		if (rc == 2000) xhpI = tIndex.xhp;
		else return rc;
	}
	else xhpI = NULL;
	n  = iParm[1];
	ix = iParm[2];
	if (xhpI) {
		if (!(pIndexO->xhp = xhpO =
#if 1	/* 2017.7.23 koba */
		        akxs_xhashm_new2(0,pIndexO->index[4],0,pIndexO->size,pAC->ac_malloc,pAC->ac_constct))) return -9;
#else
		        akxs_xhash_new2(0,pIndexO->index[1],0,pIndexO->size))) return -9;
#endif
		if (rc=_gx_rep_all_hash(xhpO,xhpI)) return rc;
		pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
	}
	else {
		index = pIndexO->index;
		size = pIndexO->size;
		if ((attr=pIndexO->uAttr[0]) == DEF_ZOK_CHAR) size++;
		else if (attr == DEF_ZOK_BULK) size += sizeof(int);
	/*	n = index[1]*index[2]*index[3];	*/
		len = n*size;
/*
printf("_gx_rep_all_array: size=%d attr=%d n=%d\n",size,attr,n);
*/
		if (!(pIndexO->pVarIndex=(tdtInfoParm **)akxm_malloc_ctl(pAC,len))) return -10;
		if (pAC) {
			iOpt = pAC->ac_opt;
		}
		else iOpt = 1;
		if (pIndexI->pVarIndex) {
			if (attr == DEF_ZOK_VARI) {
				memset(pIndexO->pVarIndex,0,len);
				pvParmI = pIndexI->pVarIndex;
				pvParmO = pIndexO->pVarIndex;
				for (i=0;i<n;i++) {
					if (*pvParmI) {
/*
printf("_gx_rep_all_array: i=%d\n",i);
*/
						if (!(pParmO=(tdtInfoParm *)akxm_malloc_ctl(pAC,sizeof(tdtInfoParm)))) return -1;
						memset(pParmO,0,sizeof(tdtInfoParm));
						*pvParmO = pParmO;
						if (rc = cl_gx_rep_info_set_ac(pParmO,*pvParmI,iOpt,pAC)) return rc;
					}
					pvParmO++;
					pvParmI++;
				}
			}
			else memcpy(pIndexO->pVarIndex,pIndexI->pVarIndex,len);
			pInfoParmO->pi_paux = (char *)pInfoParmO;	/* �R�s�[���ꂽ�Ƃ��ɁA���̔z�񂪗L�������`�F�b�N���邽�߂ɕۑ����� */
		}
		else {	/* MAPPEDARRAY */
			memset(pIndexO->pVarIndex,0,len);
#if 1	/* 2017.7.23 koba */
#if 1	/* 2020.1.3 */
		/*	ndim = index[0];
			for (i=0;i<ndim;i++) index[i+ndim+4] = 0;	*/
			index[3] = 1;
#else
			index[3] = 0;
#endif
#else
			index[0] = 0;
#endif
			pvParmO = pIndexO->pVarIndex;
			for (i=0;i<n;i++) {
				pParmI = cl_get_array_and_var_ent(&tIndex,pTBL,ix);
				ix++;
				if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
					if (!(pParmO=(tdtInfoParm *)akxm_malloc_ctl(pAC,sizeof(tdtInfoParm)))) return -1;
					memset(pParmO,0,sizeof(tdtInfoParm));
					*pvParmO = pParmO;
					if (rc=cl_gx_rep_info_set_ac(pParmO,pParmI,iOpt,pAC)) return rc;
/*
DEBUGOUT_InfoParm(0,"_gx_rep_all_array:pParmI: i+i0=%d",pParmI,i+i0,0);
DEBUGOUT_InfoParm(0,"_gx_rep_all_array:pParmO: i=%d",pParmO,i,0);
*/
				}
				pvParmO++;
			}
		}
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_rep_all_struct(pInfoParmO,pInfoParmI,pAC)
tdtInfoParm *pInfoParmO,*pInfoParmI;
tdtAllocCtl *pAC;
{
	int  j,rc,ntype,attr,size,iOpt;
	char *p,id,ret;
	tdtInfoParm *pParmO,*pParmI;
	tdtDefType *pDeftypeO,*pDeftypeI;

	pDeftypeO = (tdtDefType *)pInfoParmO->pi_data;
	pDeftypeI = (tdtDefType *)pInfoParmI->pi_data;
	ntype = pDeftypeI->ntype;
/*
printf("_gx_rep_all_struct: ntype=%d\n",ntype);
*/
	if (!(pDeftypeO->pType=(tdtInfoParm **)akxm_malloc_ctl(pAC,ntype*sizeof(tdtInfoParm *)))) return -1;
	for (j=0;j<ntype;j++) {
		if (!(pParmO=(tdtInfoParm *)akxm_malloc_ctl(pAC,sizeof(tdtInfoParm)))) return -1;
		pDeftypeO->pType[j] = pParmO;
		pParmI = pDeftypeI->pType[j];
/*
printf("_gx_rep_all_struct: i=%d pi_id=[%c]\n",j,pParmI->pi_id);
*/
		if ((id=pParmI->pi_id)==' ' && (attr=pParmI->pi_aux[0])) {
/*
printf("_gx_rep_all_struct: attr=%d\n",attr);
*/
			cl_gx_copy_info(pParmO,pParmI);
			pParmO->pi_scale &= ~D_DATA_MALLOC;
			if (attr!=DEF_ZOK_BINA && attr!=DEF_ZOK_FLOA) {
				size = pParmI->pi_len;
				if (attr == DEF_ZOK_CHAR) size++;
				else if (attr == DEF_ZOK_BULK)
					size += sizeof(int);
				ret = akxm_malloc_ctl_pp(pAC,size,&p);
				if (p) {
					if (attr == DEF_ZOK_DECI) memcpy(p,pParmI->pi_data,size);
					else strcpy(p,pParmI->pi_data);
					if (!ret) pParmO->pi_scale |= D_DATA_MALLOC;
				}
				else rc = -1;
				pParmO->pi_data = p;
			}
			pParmO->pi_paux = pParmO->pi_data;
			pParmO->pi_aux[1] &= ~D_AUX1_PROTECTED;
		}
		else {
			memset(pParmO,0,sizeof(tdtInfoParm));
			if (pAC) {
				iOpt = pAC->ac_opt;
			}
			else iOpt = 1;
			if (rc=cl_gx_rep_info_set_ac(pParmO,pParmI,iOpt,pAC)) return rc;
			if (id=='A' || id=='R') {
				if (rc = _gx_rep_all_array(pParmO,pParmI,pAC)) return rc;
			}
		}
/*
DEBUGOUT_InfoParm(0,"_gx_rep_all_struct:pParmI: i=%d",pParmI,j,0);
DEBUGOUT_InfoParm(0,"_gx_rep_all_struct:pParmO: i=%d",pParmO,j,0);
*/
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _gx_rep_all_data(pInfoParmO,pInfoParmI,name,pAC)
tdtInfoParm *pInfoParmO,*pInfoParmI;
char *name;
tdtAllocCtl *pAC;
{
	tdtInfoParm rInfoParmI;
	char id,c,*p;
	int rc,iOpt,len;

DEBUGOUT_InfoParm(120,"_gx_rep_all_data:pInfoParmO: name=[%s]",pInfoParmO,name,0);
DEBUGOUT_InfoParm(120,"_gx_rep_all_data:pInfoParmI:",pInfoParmI,0,0);

	rInfoParmI = *pInfoParmI;
	rInfoParmI.pi_aux[0] = '\0';
	memset(pInfoParmO,0,sizeof(tdtInfoParm));
/*	if (pAC) {
		iOpt = pAC->ac_opt;
	}
	else */iOpt = 1;
	if (rc=cl_gx_rep_info_set_ac(pInfoParmO,&rInfoParmI,iOpt,pAC)) return rc;
	if (!name) name = "";
	else {
		if (*name=='<') name += D_LEN_STR_SCOPE;
		if ((c=*name)=='$' || c=='%' || c=='#') name++;
	}
	len = strlen(name);
	if (!(p = akxm_malloc_ctl(pAC,len+1))) return -1;
	memzcpy(p,name,len);
	pInfoParmO->pi_pos = (int)p;
/*
printf("_gx_rep_all_data: id=[%c]\n",pInfoParmI->pi_id);
*/
	if ((id=pInfoParmI->pi_id)==D_DATA_ID_MAPEDARY || id==D_DATA_ID_ARRAY) {
		pInfoParmO->pi_id = D_DATA_ID_ARRAY;	/* �z��̃f�[�^���R�s�[����Ƃ��́A�ʏ�̔z��ɂ��� */
		return _gx_rep_all_array(pInfoParmO,pInfoParmI,pAC);
	}
	else if(id==D_DATA_ID_STRUCT) {
		return _gx_rep_all_struct(pInfoParmO,pInfoParmI,pAC);
	}

	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _check_exist(xhpS,pInfoParm)
XHASHB *xhpS;
tdtInfoParm *pInfoParm;
{
	static char *p=NULL;
	int len,len2,n,ix;
	char *key;

	key = pInfoParm->pi_data;
	len = pInfoParm->pi_dlen;
	if (pInfoParm->pi_id!=' ' || pInfoParm->pi_attr!=DEF_ZOK_CHAR) {
		len2 = len*2 + 1;
		if (p) p = Realloc(p,len2);
		else p = Malloc(len2);
		if (!p) return -1;
		n = akxcxtoc(key,len,p);
		*(p+n) = '\0';
		key = p;
	}

	if (!(ix=akxs_xhash(xhpS,'R',key))) {
		if ((n=akxs_xhash(xhpS,'S',key))<0) ix = n;
		else if (!n) ix = -1;
	}
/*
printf("_check_exist: key=[%s] ix=%d\n",key,ix);
*/
	return ix;
}

/****************************************/
/*										*/
/****************************************/
static int _check_exist_mk_key(mcat,pInfoParm)
MCAT *mcat;
tdtInfoParm *pInfoParm;
{
	static char *p=NULL;
	tdtInfoParm *pInfo;
	tdtRbCtl *pCt;
	int len,len2,n,ix;
	char c,*key,*p1;

	if ((c=pInfoParm->pi_id)=='L' || c=='N') {
		pCt = (tdtRbCtl *)pInfoParm->pi_data;
		akxs_rb_read(pCt,0);
		while (pInfo=(tdtInfoParm *)akxs_rb_read(pCt,1)) {
			_check_exist_mk_key(mcat,pInfo);
		}
	}
	else {
		p1 = NULL;
		key = pInfoParm->pi_data;
		len = pInfoParm->pi_dlen;
		if (c == ' ' ) {
			if (pInfoParm->pi_attr != DEF_ZOK_CHAR) {
				if ((len=parm_to_char(pInfoParm,&p1,NULL)) < 0) return len;
				key = p1;
			}
		}
	/*	else if (pInfoParm->pi_attr != DEF_ZOK_CHAR) {	*/
		else {
			len2 = len*2 + 1;
			if (p) p = Realloc(p,len2);
			else p = Malloc(len2);
			if (!p) return -1;
			n = akxcxtoc(key,len,p);
			*(p+n) = '\0';
			key = p;
			len = n;
		}
		if (mcat->mc_ipos > 0) akxtmcatz(mcat,"`",1);
		akxtmcatz(mcat,key,len);
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _check_exist_all(xhpS,pInfoParm)
XHASHB *xhpS;
tdtInfoParm *pInfoParm;
{
	MCAT mcat;
	int n,ix;
	char *key;

	memset(&mcat,0,sizeof(MCAT));
	mcat.mc_extlen = 256;
	_check_exist_mk_key(&mcat,pInfoParm);

	key = mcat.mc_bufp;
	if (!(ix=akxs_xhash(xhpS,'R',key))) {
		if ((n=akxs_xhash(xhpS,'S',key))<0) ix = n;
		else if (!n) ix = -1;
	}
/*
printf("_check_exist_all: key=[%s] ix=%d\n",key,ix);
*/
	Free(key);
	return ix;
}

/****************************************/
/*										*/
/****************************************/
static int _array_add_sub(pvParmO,pos,pInfoParm1,pIndex1,pTBL1,ix1,nm1,xhpS)
int pos;
tdtArrayIndex *pIndex1;
tdtInfoParm **pvParmO,*pInfoParm1,***pTBL1;
int ix1,nm1;
XHASHB *xhpS;
{
	tdtInfoParm **pvParm,*pParmI;
	int iRc,i,count,iA;

	pvParm = pvParmO + pos;
	count = pos;
	if (pInfoParm1->pi_id == ' ') {
		pParmI = pInfoParm1;
		iA = 0;
	}
	else {
		iA = 1;
	}
	for (i=0;i<nm1;i++,ix1++) {
		if (iA) {
			if ((iRc=cl_array_get_info_parm(&pParmI,pIndex1,pTBL1,ix1,'r')) < 0) return iRc;
			else if (!iRc) continue;
		}
		if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
			if (xhpS) {
				if ((iRc=_check_exist(xhpS,pParmI))<0) return iRc;
				else if (iRc > 0) continue;
			}
			if (iRc=cl_gx_rep_info_set_alloc(pvParm,pParmI,1)) return iRc;
		}
		else if (xhpS) continue;
		pvParm++;
		count++;
	}
	return count;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_array_add(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char       op;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	static XHASHB *xhpS=NULL;
	XHASHB *xhp1,*xhp2,*xhpO;
	tdtInfoParm ***pTBL1,***pTBL2,**pvParmO;
	int iRc,ix1,ix2,nm1,nm2,len,iParm[4],*index,size;
	tdtArrayIndex tIndex1,tIndex2,*pIndex,*pIndexO;

	xhp1 = xhp2 = NULL;
	nm1 = nm2 = 1;
	if (pInfoParm1->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm1,&tIndex1,&pTBL1,iParm,1)) {
			if (iRc == 2000) xhp1 = tIndex1.xhp;
			else return iRc;
		}
		nm1  = iParm[1];
		ix1  = iParm[2];
	}

	if (pInfoParm2->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm2,&tIndex2,&pTBL2,iParm,1)) {
			if (iRc == 2000) xhp2 = tIndex2.xhp;
			else return iRc;
		}
		nm2  = iParm[1];
		ix2  = iParm[2];
	}

	info_parm_clear(pInfoParmW);
	pInfoParmW->pi_id   = 'R';
	pInfoParmW->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
	pInfoParmW->pi_attr = DEF_ZOK_BULK;
	pInfoParmW->pi_dlen  = sizeof(tdtArrayIndex);
	pInfoParmW->pi_pos  = (long)Strdup("");
	if (!(pIndexO = (tdtArrayIndex *)Malloc(sizeof(tdtArrayIndex)))) return -1;
	memset(pIndexO,0,sizeof(tdtArrayIndex));
	pInfoParmW->pi_data    = (char *)pIndexO;
	index = pIndexO->index;
	pIndexO->size = size = sizeof(tdtInfoParm *);
	pIndexO->uAttr[0] = DEF_ZOK_VARI;

#if 1	/* 2017.7.23 koba */
	if (xhp1 && xhp2) {
		index[4] = tIndex1.index[4];
		if (!(pIndexO->xhp=xhpO=akxs_xhash_new2(0,index[4],0,size))) return -9;
		if (iRc=_gx_rep_all_hash(xhpO,xhp1)) return iRc;
		if (iRc=_gx_rep_all_hash(xhpO,xhp2)) return iRc;
	}
	else {
		if (xhpS) akxs_xhash_free(xhpS);
		xhpS = NULL;
		if (op == '|') {
			if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;
		}
		index[0] = 1;
		index[2] = 0;
		index[3] = 1;
		index[4] = nm1+nm2;
		index[1] = index[4];
		index[5] = 0;
		len = index[4]*pIndexO->size;
		if (!(pvParmO=(tdtInfoParm **)Malloc(len))) return -10;
		memset(pvParmO,0,len);
		pIndexO->pVarIndex = pvParmO;
		if ((iRc=_array_add_sub(pvParmO,0,pInfoParm1,&tIndex1,pTBL1,ix1,nm1,xhpS))<0) return iRc;
		if ((iRc=_array_add_sub(pvParmO,iRc,pInfoParm2,&tIndex2,pTBL2,ix2,nm2,xhpS))<0) return iRc;
#if 1	/* 2020.7.4 koba */
		index[2] = iRc;
		if (iRc > 0) {
			index[1] = index[4] = iRc;
		}
#else
		index[4] = iRc;
		index[1] = index[4];
		index[2] = index[1];	/* 0; 2020.4.30 */
#endif
	}
#else
	if (xhp1 && xhp2) {
		index[1] = tIndex1.index[1];
		if (!(pIndexO->xhp=xhpO=akxs_xhash_new2(0,index[1],0,size))) return -9;
		if (iRc=_gx_rep_all_hash(xhpO,xhp1)) return iRc;
		if (iRc=_gx_rep_all_hash(xhpO,xhp2)) return iRc;
	}
	else {
		if (xhpS) akxs_xhash_free(xhpS);
		xhpS = NULL;
		if (op == '|') {
			if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;
		}
		index[0] = 1;
		index[1] = nm1+nm2;
		index[2] = 1;
		index[3] = 1;
		len = index[1]*pIndexO->size;
		if (!(pvParmO=(tdtInfoParm **)Malloc(len))) return -10;
		memset(pvParmO,0,len);
		pIndexO->pVarIndex = pvParmO;
		if ((iRc=_array_add_sub(pvParmO,0,pInfoParm1,&tIndex1,pTBL1,ix1,nm1,xhpS))<0) return iRc;
		if ((iRc=_array_add_sub(pvParmO,iRc,pInfoParm2,&tIndex2,pTBL2,ix2,nm2,xhpS))<0) return iRc;
		index[1] = iRc;
	}
#endif
	return 0;
}

/****************************************/
/*										*/
/****************************************/
static int _list_minus_sub(pCt,iOpt,pInfoParm1,pInfoParm2)
tdtRbCtl *pCt;
int iOpt;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	static XHASHB *xhpS=NULL;
	tdtInfoParm *p,*pInfoParm;
	int rc,iL;
	tdtRbCtl *pCt1,*pCt2;
	char c;

	if (xhpS) akxs_xhash_free(xhpS);
	xhpS = NULL;
	if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;

	if ((c=pInfoParm2->pi_id)=='L' || c=='N') {
		pCt2 = (tdtRbCtl *)pInfoParm2->pi_data;
		akxs_rb_read(pCt2,0);
		while (p=(tdtInfoParm *)akxs_rb_read(pCt2,1)) {
			if ((rc=_check_exist_all(xhpS,p))<0) return rc;
		}
	}
	else {
		if ((rc=_check_exist(xhpS,pInfoParm2))<0) return rc;
	}

	if ((c=pInfoParm1->pi_id)=='L' || c=='N') {
		pCt1 = (tdtRbCtl *)pInfoParm1->pi_data;
		akxs_rb_read(pCt1,0);
		iL = 1;
	}
	else {
		iL = 0;
		p = pInfoParm1;
	}

	for (;;) {
		if (iL) {
			if (!(p=(tdtInfoParm *)akxs_rb_read(pCt1,1))) break;
		}
		if (!cl_is_null_parm(p)) {
			if ((rc=_check_exist_all(xhpS,p))<0) return rc;
			else if ((iOpt && !rc)||(!iOpt && rc)) {
				if (!(pInfoParm=(tdtInfoParm *)Malloc(sizeof(tdtInfoParm))))
					return ECL_MALLOC_ERROR;
				if (rc=_rep_list_info_set(pInfoParm,p,0)) return rc;
				if (!akxs_rb_set_n(pCt,pInfoParm)) return ECL_MALLOC_ERROR;
			}
		}
		if (!iL) break;
	}
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_list_minus(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char       op;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	int rc,iOpt;
	tdtRbCtl *pCt,*pCt1,*pCt2;
	char c;

	if ((c=pInfoParm2->pi_id)=='L' || c=='N') {
#if 0
		pCt2 = (tdtRbCtl *)pInfoParm2->pi_data;
		if (akxs_rb_used(pCt2) <= 0) {
/*
printf("cl_gx_list_minus: 2 nil\n");
*/
			return cl_gx_rep_info_set(pInfoParmW,pInfoParm1,1);
		}
#endif
		*pInfoParmW = *pInfoParm2;
	}
	if ((c=pInfoParm1->pi_id)=='L' || c=='N') {
		pCt1 = (tdtRbCtl *)pInfoParm1->pi_data;
		if (akxs_rb_used(pCt1) <= 0) {
/*
printf("cl_gx_list_minus: 1 nil\n");
*/
			return cl_gx_rep_info_set(pInfoParmW,pInfoParm1,1);
		}
		*pInfoParmW = *pInfoParm1;
	}

	if (op == '&') iOpt = 0;
	else if (op == '-') iOpt = 1;
	else iOpt = 2;

	if (!(pCt = akxs_rb_new(0,0))) return ECL_MALLOC_ERROR;
/*
printf("cl_gx_list_minus: op=[%c] iOpt=%d\n",op,iOpt);
*/
	if ((rc=_list_minus_sub(pCt,iOpt,pInfoParm1,pInfoParm2)) < 0) return rc;
	if (iOpt == 2) {
		if ((rc=_list_minus_sub(pCt,iOpt,pInfoParm2,pInfoParm1)) < 0) return rc;
	}

	pInfoParmW->pi_data = (char *)pCt;
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_list_add(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char       op;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	tdtInfoParm *ppParm[2];
	int ret;

	ppParm[0] = pInfoParm1;
	if (op == '+') {
		ppParm[1] = pInfoParm2;
		ret = cl_cons_list(pInfoParmW,2,ppParm);
	}
	else {
		if (!(ret=cl_cons_list(pInfoParmW,1,ppParm))) {
			ret = _list_minus_sub(pInfoParmW->pi_data,1,pInfoParm2,pInfoParm1);
		}
	}
	return ret;
}

/****************************************/
/*										*/
/****************************************/
static int _array_minus_hash(iOpt,nm1,xhp1,xhp2,xhpO)
int iOpt,nm1;
XHASHB *xhp1,*xhp2,*xhpO;
{
	int i,iRc;
	tdtInfoParm *pParmI;
	char *cpKey,*cpDat;

	iRc = 0;
	for (i=1;i<=nm1;i++) {
		xhp1->xha_xhix = i;
		if ((iRc=akxs_xhash2(xhp1,'P',&cpKey,&cpDat)) > 0) {
/*
printf("_array_minus_hash: i=%d key=[%s]\n",i,cpKey);
*/
			memcpy(&pParmI,cpDat,sizeof(tdtInfoParm *));
			if ((iRc=akxs_xhash(xhp2,'R',cpKey)) < 0) break;
			else if ((iOpt && !iRc)||(!iOpt && iRc)) {
				if ((iRc=akxs_xhash2(xhpO,'S',cpKey,&pParmI)) <= 0) {
					if (!iRc) iRc = -100;
					break;
				}
			}
		}
		else if (iRc < 0) break;
		iRc = 0;
	}
	xhp1->xha_xhix = 0;
/*
printf("_array_minus_hash: iRc=%d\n",iRc);
*/
	return iRc;
}

/****************************************/
/*										*/
/****************************************/
static int _array_minus_sub(pvParmO,pos,iOpt,
	pInfoParm1,pIndex1,pTBL1,ix1,nm1,
	pInfoParm2,pIndex2,pTBL2,ix2,nm2)
tdtInfoParm **pvParmO;
int pos,iOpt;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
tdtInfoParm ***pTBL1,***pTBL2;
int ix1,ix2,nm1,nm2;
tdtArrayIndex *pIndex1,*pIndex2;
{
	static XHASHB *xhpS=NULL;
	tdtInfoParm *pParmI,**pvParm;
	int iRc,i,iA,count;
/*
printf("_array_minus_sub:Enter pos=%d iopt=%d ix1=%d nm1=%d ix2=%d nm2=%d\n",pos,iOpt,ix1,nm1,ix2,nm2);
*/
	if (xhpS) akxs_xhash_free(xhpS);
	xhpS = NULL;
	if (!(xhpS=akxs_xhash_new(0,10,0))) return -9;

	if (pInfoParm2->pi_id == ' ') {
		if ((iRc=_check_exist(xhpS,pInfoParm2))<0) return iRc;
	}
	else {
		for (i=0;i<nm2;i++,ix2++) {
			if ((iRc=cl_array_get_info_parm(&pParmI,pIndex2,pTBL2,ix2,'r')) < 0) return iRc;
			if (pParmI) {
				if (cl_is_undef_parm(pParmI) || cl_is_null_parm(pParmI)) continue;
				else if ((iRc=_check_exist(xhpS,pParmI))<0) return iRc;
				else if (iRc > 0) continue;
			}
		}
	}

	if (pInfoParm1->pi_id == ' ') {
		iA = 0;
		pParmI = pInfoParm1;
		nm1 = 1;
	}
	else {
		iA = 1;
	}

	pvParm = pvParmO + pos;
	count = pos;
	for (i=0;i<nm1;i++,ix1++) {
		if (iA) {
			if ((iRc=cl_array_get_info_parm(&pParmI,pIndex1,pTBL1,ix1,'r')) < 0) return iRc;
		}
		if (pParmI && !cl_is_undef_parm(pParmI) && !cl_is_null_parm(pParmI)) {
			if ((iRc=_check_exist(xhpS,pParmI)) < 0) return iRc;
			else if ((iOpt && !iRc)||(!iOpt && iRc)) {
				if (iRc=cl_gx_rep_info_set_alloc(pvParm,pParmI,1)) return iRc;
			}
			else if (iOpt != 1) continue;
		}
		else if (iOpt != 1) continue;
		pvParm++;
		count++;
	}
/*
printf("_array_minus_sub:Exit count=%d\n",count);
*/
	return count;
}

/****************************************/
/*										*/
/****************************************/
int cl_gx_array_minus(pInfoParmW,op,pInfoParm1,pInfoParm2)
tdtInfoParm *pInfoParmW;
char       op;
tdtInfoParm *pInfoParm1;
tdtInfoParm *pInfoParm2;
{
	static XHASHB *xhpS=NULL;
	XHASHB *xhp1,*xhp2,*xhpO;
	tdtInfoParm ***pTBL1,***pTBL2,**pvParmO,*pParmI;
	int iRc,i,nm1,nm2,ix1,ix2,len,iParm[4],*index,size,iA,iOpt;
	tdtArrayIndex tIndex1,tIndex2,*pIndexO;

	if (op == '&') iOpt = 0;
	else if (op == '-') iOpt = 1;
	else iOpt = 2;

	xhp1 = xhp2 = NULL;
	nm1 = nm2 = 1;
	if (pInfoParm1->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm1,&tIndex1,&pTBL1,iParm,1)) {
			if (iRc == 2000) xhp1 = tIndex1.xhp;
			else return iRc;
		}
		nm1  = iParm[1];
		ix1  = iParm[2];
	}

	if (pInfoParm2->pi_id != ' ') {
		if (iRc = _get_array_info(1,&pInfoParm2,&tIndex2,&pTBL2,iParm,1)) {
			if (iRc == 2000) xhp2 = tIndex2.xhp;
			else return iRc;
		}
		nm2  = iParm[1];
		ix2  = iParm[2];
	}
/*
printf("cl_gx_array_minus: xhp1=%08x nm1=%d ix1=%d\n",xhp1,nm1,ix1);
printf("cl_gx_array_minus: xhp2=%08x nm2=%d ix2=%d\n",xhp2,nm2,ix2);
*/
	info_parm_clear(pInfoParmW);
	pInfoParmW->pi_id   = 'R';
	pInfoParmW->pi_scale = D_DATA_MALLOC | D_DATA_INDEX_FREE;
	pInfoParmW->pi_attr = DEF_ZOK_BULK;
	pInfoParmW->pi_dlen  = sizeof(tdtArrayIndex);
	pInfoParmW->pi_pos  = (long)Strdup("");
	if (!(pIndexO = (tdtArrayIndex *)Malloc(sizeof(tdtArrayIndex)))) return -1;
	memset(pIndexO,0,sizeof(tdtArrayIndex));
	pInfoParmW->pi_data    = (char *)pIndexO;
	index = pIndexO->index;
	pIndexO->size = size = sizeof(tdtInfoParm *);
	pIndexO->uAttr[0] = DEF_ZOK_VARI;

#if 1	/* 2017.7.23 koba */
	if (xhp1 && xhp2) {
		index[4] = tIndex1.index[4];
		if (!(pIndexO->xhp=xhpO=akxs_xhash_new2(0,index[4],0,size))) return -9;
		if ((iRc=_array_minus_hash(iOpt,nm1,xhp1,xhp2,xhpO)) < 0) return iRc;
		if (iOpt == 2) {
			if ((iRc=_array_minus_hash(iOpt,nm2,xhp2,xhp1,xhpO)) < 0) return iRc;
		}
		return 0;
	}

	index[0] = 1;
	index[2] = 0;
	index[3] = 1;
	if (iOpt == 2) index[4] = nm1 + nm2;
	else index[4] = X_MAX(nm1,nm2);
	index[1] = index[4];	/* 2020.4.30 */
	index[5] = 0;
	len = index[4]*pIndexO->size;
#else
	if (xhp1 && xhp2) {
		index[1] = tIndex1.index[1];
		if (!(pIndexO->xhp=xhpO=akxs_xhash_new2(0,index[1],0,size))) return -9;
		if ((iRc=_array_minus_hash(iOpt,nm1,xhp1,xhp2,xhpO)) < 0) return iRc;
		if (iOpt == 2) {
			if ((iRc=_array_minus_hash(iOpt,nm2,xhp2,xhp1,xhpO)) < 0) return iRc;
		}
		return 0;
	}

	index[0] = 1;
	if (iOpt == 2) index[1] = nm1 + nm2;
	else index[1] = X_MAX(nm1,nm2);
	index[2] = 1;
	index[3] = 1;
	len = index[1]*pIndexO->size;
#endif
	if (!(pvParmO=(tdtInfoParm **)Malloc(len))) return -10;
	memset(pvParmO,0,len);
	pIndexO->pVarIndex = pvParmO;

	if ((iRc=_array_minus_sub(pvParmO,0,iOpt,
	                        pInfoParm1,&tIndex1,pTBL1,ix1,nm1,
	                        pInfoParm2,&tIndex2,pTBL2,ix2,nm2)) < 0) return iRc;
	if (iOpt == 2) {
		if ((iRc=_array_minus_sub(pvParmO,iRc,iOpt,
		                        pInfoParm2,&tIndex2,pTBL2,ix2,nm2,
		                        pInfoParm1,&tIndex1,pTBL1,ix1,nm1)) < 0) return iRc;
	}
#if 1	/* 2020.7.4 koba */
	index[2] = iRc;
	if (iRc > 0) {
		index[1] = index[4] = iRc;
	}
#else
	index[1] = iRc;
#endif
	return 0;
}

/****************************************/
/*										*/
/****************************************/
int cl_set_struct(pWork,pInfoParm,nparm,ppParm)
tdtInfoParm *pInfoParm,*ppParm[];
int *pWork,nparm;
{
	int  j,rc,ntype,size,count;
	char id;
	tdtInfoParm *pParmO,**ppParmW,tInfoParm;
	tdtDefType *pDeftype;

	count = 0;
	*pWork = 0;
	pDeftype = (tdtDefType *)pInfoParm->pi_data;
	ntype = X_MIN(pDeftype->ntype,nparm);
/*
printf("cl_set_struct: ntype=%d\n",ntype);
*/
	for (j=0;j<ntype;j++) {
		pParmO = pDeftype->pType[j];
DEBUGOUT_InfoParm(161,"cl_set_struct:pParmIO: j=%d",pParmO,j,0);
		if ((id=pParmO->pi_id) == ' ') {
			if (!cl_is_null_parm(pInfoParm)) {
				rc = cl_gx_rep_info_set(pParmO,ppParm[j],1);
				count++;
			}
		}
		else if (id == 'R') {
			if (!(ppParmW=(tdtInfoParm **)cl_tmp_const_malloc(sizeof(tdtInfoParm *)*(nparm-j+2)))) return ECL_MALLOC_ERROR;
			ppParmW[0] = pParmO;
			ppParmW[1] = &tInfoParm;
			cl_set_parm_bin(&tInfoParm,0);
			mem_cpy_addr(&ppParmW[2],&ppParm[j],nparm-j);
			rc = cl_set_array(&size,nparm-j+2,ppParmW);
			count += size;
		}
		else if (id == 'T') {
			rc = cl_set_struct(&size,pParmO,nparm-j,&ppParm[j]);
			count += size;
		}
	}
	*pWork = count;
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_func_set_struct(pWork,nparm,ppParm)
char *pWork;
int  nparm;
tdtInfoParm *ppParm[];
{
	int rc;

	rc = cl_check_data_id(ppParm[0],~0x10);
	if (rc < 0) {
		rc = ECL_SCRIPT_ERROR;
	}
	else {
		rc = cl_set_struct(pWork,ppParm[0],nparm-1,&ppParm[1]);
	}
	return rc;
}

/****************************************/
/*										*/
/****************************************/
int cl_malloc_ctl_im_pp(pAC,alen,im,pp)
tdtAllocCtl *pAC;
int alen,im;
char **pp;
{
	char *p;
	int ret;

	if (im == D_OPT_ALC_MALLOC) ret = akxm_malloc_ctl_pp(pAC,alen,pp); 
	else {
		p = cl_opt_malloc(im,alen);
		if (pp) *pp = p;
		ret = 0;
	}
	return ret;
}
