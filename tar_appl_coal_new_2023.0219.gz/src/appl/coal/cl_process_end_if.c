static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �d�m�c�h�e�R�}���h���C��                               *
*                                                                             *
*      �֐����@�@�@�F�@int cl_process_end_if( pLeaf, pProc )                  *
*                                                                             *
*      ������      �F�@(I)Leaf          * pLeaf                               *
*                      (I)ProcCT        * pProc                               *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      NORMAL                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/

#include "colmn.h"

extern CLCOMMON  CLcommon;
extern CLPRTBL *pCLprocTable;
extern GlobalCt *pGlobTable;

int cl_process_end_if(pLeaf, pProc)
Leaf    *pLeaf;
ProcCT  *pProc;
{
	int irc,id,blk_id;
	BlockCB *pIfCB;
	Leaf  *Dummy;

	if (!(pIfCB = pProc->pcrBlockCB)) return -1;
	blk_id = pIfCB->cid;

DEBUGOUTL2(110,"cl_process_end_if: Enter cid=%08x %s",blk_id,cl_gets_cmd_name(blk_id));

	if (blk_id==C_IF || blk_id==C_SWITCH || blk_id==C_TRY) ;
	else return -1;

	irc = 0;
	id = pLeaf->cmd.cid;
	if (id == C_ENDTRY) {
		pProc->ucExcept = 0;
		pGlobTable->try_level--;
/*
printf("cl_process_end_if: pGlobTable->try_level=%d\n",pGlobTable->try_level);
*/
		if (pIfCB->EndFlag) {	/* CATCH or FINALLY�̒��ŗ�O�����������Ƃ� */
			pGlobTable->exception = pIfCB->EndFlag;
			pIfCB->EndFlag = 0;
		}
		else if (pIfCB->TureFlag == L_OFF)	/* Catch����Ȃ������Ƃ� */
			pGlobTable->exception = pProc->exception;
		pProc->exception = 0;
		/* �O��TRY��Ԃɖ߂� */
		pProc->pFlag = pIfCB->pFlag;
		pProc->ucExcept = pIfCB->ucExcept;
		/* break/continue���́A���̌�Apush���Ă���break/continue�����s����悤�ɂ��� */
		if (cmn_chk_stat(BRK_PR|RET_PR,&pProc->ptype)) pProc->Nextleaf = NULL;
#if 1	/* 2021.2.1 */
		/* TRY���I������Ƃ��́A�G���[���b�Z�[�W���N���A���� */
		if (!pGlobTable->exception) {
			pGlobTable->err_hist[0].parlen = 0;
			pGlobTable->err_hist[1].parlen = 0;
			*pGlobTable->errmsg = '\0';
		}
#endif
		id = C_TRY;
	}
	else if (id == C_ENDSW) {
		if (pIfCB->TureFlag != L_ON) {
			Dummy = pLeaf->preleaf;
			while(Dummy) {
				id = Dummy->cmd.cid;
				if (id == C_DEFAULT) {
					pIfCB->TureFlag = L_ON;
					pIfCB->iUsed = D_SWITCH_DEFAULT;	/* Add 2017.3.25 */
					pIfCB->Blockleaf = Dummy->rightleaf;	/* Add 2017.3.25 */

DEBUGOUTL2(110,"cl_process_end_if: found default pIfCB=%08x TureFlag=%08x",pIfCB,pIfCB->TureFlag);

					pProc->Nextleaf = Dummy->leftleaf;
					cl_ret_leaf_push(pProc,Dummy->rightleaf);
					return 0;
				}
				else if (id == C_SWITCH) break;
				Dummy = Dummy->preleaf;
			}
			if (!Dummy) return -1;
		}
		id = C_SWITCH;
	}
	else if (id == C_ENDIF) {
		id = C_IF;
	}
	else return -1;
	if (blk_id == id) {
		pIfCB->iUsed = 0;
		pProc->pcrBlockCB = pIfCB->preBlockCB;
	}

DEBUGOUTL1(110,"cl_process_end_if: Return pProc->pcrBlockCB=%08x",pProc->pcrBlockCB);

	return irc;
}
