static	char	sccsid[]="%Z% %M% %I% %E% %U%";
/******************************************************************************
*                                                                             *
*      �����ړI�@�@�F  �p�����[�^���                                         *
*                                                                             *
*      �֐����@�@�@�F�@int cl_anal_parm( pparmList )                          *
*                      (I)prmList	*pparmList                                *
*                                                                             *
*      ������      �F�@�Ȃ�                                                   *
*                                                                             *
*                                                                             *
*      �߂�l�@�@�@�F�@ERROR                                    �@            *
*                      PARAMETER                                              *
*                      CONSTANT_NUM                                           *
*                      CONSTANT_CHR                                           *
*                      SYSVAR                                                 *
*                                                                             *
*      �����T�v�@�@�F�@                                                       *
*                                                                             *
******************************************************************************/
#include <colmn.h>

extern GlobalCt  *pGlobTable;
extern int giOptions[];
extern tdtExtValName ExtValName[];
extern tdtException ExceptionName[];

int cl_anal_parm(pparmList)
parmList *pparmList;
{
	int  len;
	char *p;

	if (!pparmList || !(p=pparmList->prp)) {
		ERROROUT(FORMAT(30));	/* �V�X�e���G���[ */
		return ECL_SYSTEM_ERROR;
	}
	if (!(len=pparmList->prmlen)) {
		return NULL_PARM;
	}
	return cl_chk_parm(p,len);
}

int cl_chk_parm(p,len)
char *p;
int len;
{
	int  rc;
	char c;

	if (!p || len<0) return ECL_SYSTEM_ERROR;
	if (!len) return NULL_PARM;
/*	rc = NAME_CONST;	2022.10.17 */
	rc = 0;
	switch (c = *p) {
		case	'%' :
		case	'#':
			if (len == 1) ;
			else rc = PARAMETER;
			break;
		case	'$':
			if (len == 1) ;
			else if (cl_chk_sysvar_name(p+1,len-1)) rc = SYSVAR;
			else rc = PARAMETER;
			break;
		case	'\'':
		case	'"':
			rc = CONSTANT_CHR;
			break;
		case	'`':
			rc = CONSTANT_CMD;
			break;
		case	'-':
		case	'+':
			if ((c=p[1])=='.' || (c>='0' && c<='9')) rc = CONSTANT_NUM;
			break;
		case	'.':
			if ((c=p[1])>='0' && c<='9') rc = CONSTANT_NUM;
			break;
		default :
			if (c>='0' && c<='9') rc = CONSTANT_NUM;
			else if (cl_chk_sysvar_name(p,len)) rc = SYSVAR;
		/*	else if (cl_gx_is_separator(c)) rc = SEPARATOR;	*/	/* decomment 2020.3.23 *//* 2022.10.17 */
	}
#if 1	/* 2022.10.17 */
	if (!rc) {
		if (len==1 && cl_gx_is_separator(c)) rc = SEPARATOR;
		else rc = NAME_CONST;
	}
#endif
	return rc;
}

/********1*********2*********3*********4*********5*********6*/
/* ���� : IN  : buf		 : ������							*/
/*				buflen	 : ������ (�o�C�g)				*/
/*				opt		 : 0x01 : 2�����ڈȍ~��'.'������	*/
/*						   0x02 : 2�����ڈȍ~��'-'������	*/
/* �ԋp : =0 : ����											*/
/*        >0 : �G���[�ʒu (�擪��1)							*/
/*        <0 : buflen<0 or �����R�[�h�ُ�					*/
/************************************************************/
int cl_chk_name_pos(buf,buflen,opt)
uchar *buf;
int  buflen,opt;
{
	uchar c,wrk[5];
	int len,n,rc,opt1,opt2,iKANA,i,code_type,m;
/*
	if (pGlobTable->options[1] & 0x01) return cl_chk_proc_name(buf,buflen);
*/
	rc = -1;
	if ((len=buflen)<=0) return rc;
	code_type = GET_TYPE_OPT(opt);
	opt1 = opt & 0x01;
	opt2 = opt & 0x02;
	n = akxqmbsnlen(code_type,buf,len);
#if 0	/* 2022.12.05 */
	if (n == 1) c = *buf;
	else {
		n = akxctohan_type_opt(n,buf,wrk,code_type,0x10);
		if (n == 1) c = *wrk;
/*
printf("cl_chk_name_pos: n=%d c=[%c]\n",n,c);
*/
	}
#endif
	iKANA = akxqis_hankaku_kana(buf,n);
	i = n;
	if (n>=2 || iKANA ||
	    (n==1 && (((c=*buf)>='A' && c<='Z') || (c>='a' && c<='z') ||
	    (c=='_') || (opt && len>1 && c=='.')))
	   ) {
		rc = 0;
		len -= n;
		buf += n;
		while (len > 0) {
			n = akxqmbsnlen(code_type,buf,len);
			iKANA = akxqis_hankaku_kana(buf,n);
			if (n>=2 || iKANA) {
				len -= n;
				buf += n;
				i += n;
			}
			else {
				if (!(((c=*buf)>='0' && c<='9') ||
				      (c>='A' && c<='Z') || (c>='a' && c<='z') ||
				     c=='_' || c=='\\' || (opt1 && c=='.') || (opt2 && c=='-'))) {
					rc = i;
					break;
				}
				len--;
				buf++;
				i++;
			}
		}
		if (len < 0) rc = -1;
	}
	else rc = i;
/*
printf("cl_chk_name_pos:Exit rc=%d\n",rc);
*/
	return rc;
}

int cl_chk_name_opt(buf,buflen,opt)
uchar *buf;
int  buflen,opt;
{
	int ret;

	if ((ret=cl_chk_name_pos(buf,buflen,opt)) > 0) ret = -1;
	return ret;
}

int cl_chk_name(buf, buflen)
uchar *buf;
int  buflen;
{
	return cl_chk_name_opt(buf,buflen,0);
}

int cl_chk_name_const(buf,buflen)
uchar *buf;
int  buflen;
{
	return cl_chk_name_opt(buf,buflen,1);
}

int cl_chk_proc_name(buf,buflen)
uchar *buf;
int  buflen;
{
	return cl_chk_name_opt(buf,buflen,2);
}

int cl_chk_file_name(buf, buflen)
uchar *buf;
int  buflen;
{
	uchar c;
	int len,i,n,rc = -1;

 	if ((len=buflen)<=0) return rc;
	rc = 0;
	while (len > 0) {
		n = akxqkanjilen2(buf,len);
		if (n >= 2) {
			len -= n;
			buf += n;
		}
		else {
		 	if ((c=*buf)==0x1b) ;
		 	else if (c<0x20 || c==0x7f || c==0xff) {
				rc = -1;
				break;
			}
			len--;
			buf++;
		}
	}
	if (len < 0) rc = -1;
	return rc;
}

int cl_chk_digit_n(prp,prmlen)
char *prp;
int   prmlen;
{
	int rc,ret;

	if ( prmlen>=3 && prp[0]=='0' ) {
		switch( prp[1] ) {
			case 'B':
			case 'b':
					rc = cl_chk_digit(2,&prp[2],prmlen-2);
					break;
			case 'O':
			case 'o':
					rc = cl_chk_digit(8,&prp[2],prmlen-2);
					break;
			case 'D':
			case 'd':
					rc = cl_chk_digit(10,&prp[2],prmlen-2);
					break;
			case 'X':
			case 'x':
					rc = cl_chk_digit_x(&(prp[2]),prmlen-2);
					break;
			default :
					if (!(rc=cl_chk_digit(10,prp,prmlen))) break;
					if (ret=cl_chk_digit_f(10,prp,prmlen)) rc = ret;
					break;
		}
	}
	else {
		if (rc=cl_chk_digit(10,prp,prmlen)) {
			if (ret=cl_chk_digit_f(10,prp,prmlen)) rc = ret;
		}
	}
	return rc;
}

/********************************************/
/*											*/
/********************************************/
tdtExtValName *cl_get_sysvar_name(name, name_len, opt)
char *name;
int  name_len,opt;
{
	tdtExtValName *p;
	int len,osize,plen;
	char *pn;

	len = name_len;

	p = &ExtValName[0];
	for (;(pn=p->name);p++) {
		osize = p->osize;
		plen = strlen(pn);
		if ((osize>0 && len>=osize && plen>=len) || (len==plen)) {
			if (opt & 0x01) {
				if (!memicmp(name,pn,len)) return p;
			}
			else {
				if (!memcmp(name,pn,len)) return p;
			}
		}
	}
	return NULL;
}

int cl_chk_sysvar_name(buf, len)
char *buf;
int  len;
{
	return (cl_get_exception_name(buf,len,0) ||
	        cl_get_sysvar_name(buf,len,0)) ? 1: 0;
}

char *strname(s,len)
char *s;
int  len;
{
	static char wrk[Var_NM_MAX+2];	/* $... */

	memnzcpy(wrk,s,len,sizeof(wrk));
	return wrk;
}

char *strname3(s1,len1,s2,len2,s3,len3)
char *s1,*s2,*s3;
int  len1,len2,len3;
{
	char *argv[5];
	int   argl[5];

	argv[0] = s1;
	argv[1] = s2;
	argv[2] = s3;
/*
	argv[3] = s4;
	argv[4] = s5;
*/
	argl[0] = len1;
	argl[1] = len2;
	argl[2] = len3;
/*
	argl[3] = len4;
	argl[4] = len5;
*/
	return memaddv(3,argv,argl);
}

char *strntmp2(s1,len1,s2,len2)
char *s1,*s2;
int  len1,len2;
{
	char *p,*p0;

	if (len1 < 0) len1 = 0;
	if (len2 < 0) len2 = 0;
	if (p0=cl_tmp_const_malloc(len1+len2+1)) {
		p = p0;
		if (s1 && len1>0) {
			memcpy(p,s1,len1);
			p += len1;
		}
		if (s2 && len2>0) {
			memcpy(p,s2,len2);
			p += len2;
		}
		*p = '\0';
	}
	else p0 = "";
	return p0;
}

char *strtmp2(s1,s2)
char *s1,*s2;
{
	int len1,len2;

	len1 = len2 = 0;
	if (s1) len1 = strlen(s1);
	if (s2) len2 = strlen(s2);
	return strntmp2(s1,len1,s2,len2);
}

char *strtemp(s,len)
char *s;
int  len;
{
	return strntmp2(s,len,NULL,0);
}

/********************************************/
/*											*/
/********************************************/
tdtException *cl_get_exception_name(name, name_len, opt)
char *name;
int  name_len,opt;
{
	tdtException *p;
	int len;
	char *pn;

	len = name_len;

	p = &ExceptionName[0];
	for (;(pn=p->name);p++) {
		if (len == strlen(pn)) {
			if (opt & 0x01) {
				if (!memicmp(name,pn,len)) return p;
			}
			else {
				if (!memcmp(name,pn,len)) return p;
			}
		}
	}
	return NULL;
}

int cl_mk_exception_code(e,rc)
int e,rc;
{
	return (e & 0xffff0000) | (X_ABS(rc) & 0x0000ffff);
}

int cl_is_exp(line,line_len,opt)
char *line;
int line_len,opt;
{
	SSPL_S ssp;
	int ret,atr;
	char wrk[4096];

	ssp.sp = 0;
	ssp.wd = wrk;
	ssp.wdmax = sizeof(wrk);
	ret = -1;
	for(;;) {
		atr = cmpgwnsl(line,line_len,&ssp,opt);
DEBUGOUTL3(120,"cl_is_exp: atr=%d sp=%d wd=[%s]",atr,ssp.sp,ssp.wd);
		if (atr <= 0) break;
		else if (atr == 99) break;
		else if (atr == 10000) ret = 0;
		else {
			ret = 1;
			break;
		}
	}
DEBUGOUTL4(120,"cl_is_exp:Exit ret=%d atr=%d sp=%d wd=[%s]",ret,atr,ssp.sp,ssp.wd);
	return ret;
}

int cl_is_proc_scr_name(buf,buflen)
uchar *buf;
int  buflen;
{
	uchar c;
	int len,n,rc,iKANA;

	rc = 0;
	if (!buf || (len=buflen)<=0) return 0;
	n = akxqkanjilen2(buf,len);
	iKANA = akxqis_hankaku_kana(buf,n);
	c = akxcupper(*buf);
	if (n>=2 || iKANA ||
	    (n==1 && ((c>='A' && c<='Z') || c=='_' || c=='.' || c=='\\' || c=='/'))
	   ) {
		rc = 1;
		len -= n;
		buf += n;
		while (len > 0) {
			n = akxqkanjilen2(buf,len);
			iKANA = akxqis_hankaku_kana(buf,n);
			if (n>=2 || iKANA) {
				len -= n;
				buf += n;
			}
			else {
				c = akxcupper(*buf);
/*
printf("cl_is_proc_scr_name: len=%d c=[%c]\n",len,c);
*/
				if (!((c>='0' && c<='9') || (c>='A' && c<='Z') ||
				     c=='_' || c=='.' || c=='\\' || c=='/' || c=='-')) {
					rc = 0;
					break;
				}
				len--;
				buf++;
			}
		}
		if (len < 0) rc = 0;
	}
/*
printf("cl_is_proc_scr_name: rc=%d\n",rc);
*/
	return rc;
}

int cl_chk_name_var(buf, buflen)
uchar *buf;
int  buflen;
{
	char c;
	int ret;

	ret = 0;
	if (buflen <= 0) ret = -1;
	else {
		c = *buf;
		if (c=='$' || c=='#' || c=='%') {
			if ((c=*(buf+1))<'0' || c>'9')
				ret = cl_chk_name_var(buf+1,buflen-1);
		}
		else
			ret = cl_chk_name(buf,buflen);
	}
	return ret;
}
