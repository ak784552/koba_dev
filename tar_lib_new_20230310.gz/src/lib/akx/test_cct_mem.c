static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_cct_mem.c libakx_no_iconv.a -o test_cct_mem
*/
#include "akxcommon.h"

tdtCONSTCT *constct;

/****************************************/
/*										*/
/****************************************/
static char *_tmp_const_malloc_opt(mem,len,opt)
char *mem;
int len,opt;
{
	if (opt == 1)
		akxm_cct_mem_reget(constct,len,&mem);
	else if (opt == 2)
		akxm_cct_mem_put(constct,mem);
	else
		mem = akxm_cct_malloc(constct,len);
	return mem;
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_malloc(len)
int len;
{
	return _tmp_const_malloc_opt(NULL,len,0);
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_realloc(mem,len)
char *mem;
int len;
{
	return _tmp_const_malloc_opt(mem,len,1);
}

/****************************************/
/*										*/
/****************************************/
char *cl_tmp_const_free(mem)
char *mem;
{
	return _tmp_const_malloc_opt(mem,0,2);
}

/****************************************/
/*										*/
/****************************************/
void main()
{
	char *p,*p1,*p2,*p3,*p4;

	constct = akxm_cct_new_opt(0,0,1);
/*
	p1 = cl_tmp_const_malloc(128);
	printf("malloc  p1=%08x\n",p1);
	p = cl_tmp_const_malloc(200);
	printf("malloc  p =%08x\n",p);
	p1 = cl_tmp_const_remalloc(p1,100);
	printf("realloc p1=%08x\n",p1);
	p = cl_tmp_const_remalloc(p,100);
	printf("realloc p =%08x\n",p);
	p = cl_tmp_const_malloc(50);
	printf("malloc  p =%08x\n",p);
	p = cl_tmp_const_remalloc(p,100);
	printf("realloc p =%08x\n",p);
	cl_tmp_const_free(p);
*/
	p1 = cl_tmp_const_malloc(101);
	p2 = cl_tmp_const_malloc(102);
	p3 = cl_tmp_const_malloc(103);
	p4 = cl_tmp_const_malloc(104);

	cl_tmp_const_free(p1);
	cl_tmp_const_free(p3);
	cl_tmp_const_free(p2);
/*
	p3 = cl_tmp_const_realloc(p3,64);
*/
	p1 = cl_tmp_const_malloc(32);
	printf("malloc  len=%d p1=%08x\n",32,p1);
	p2 = cl_tmp_const_malloc(33);
	printf("malloc  len=%d p2=%08x\n",33,p2);
}
