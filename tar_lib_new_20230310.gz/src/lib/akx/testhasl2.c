static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
    cc -g -DLINUX -I../include testhasl2.c akxcom.a -o testhasl2
*/
#include "akxcommon.h"

main()
{
	int n,i,ret,opt;
	long key[2];
	char cmd[20],buf[128],c;
	HASHB *ha;
	tdtHaslCell4 *cell,*ce;
	int max,pre;

	printf("Enter option(0/1/2) ==>");
	gets(buf);
	opt = atoi(buf);
	printf("Enter MaxReg ==>");
	gets(cmd);
	max=atoi(cmd);
	printf("Enter PreReg ==>");
	gets(cmd);
	pre=atoi(cmd);
	ha = akxs_hasl2_new2(8,max,pre,opt);
	if (!ha) {
		printf("errno=%d\n",errno);
		exit(1);
	}
	cell = (tdtHaslCell4 *)ha->ha_reg;
	for(;;) {
		ha->ha_hix = 0;
		printf("Enter command ==>");
		gets(cmd);
		switch (c = *cmd) {
		case 'p':
			ce = cell;
			printf(" i flag  hkey0  hkey1 next   data\n");
			for (i=0;i<max;i++,ce++) {
				printf("%2d %4d %6d %6d %4d %6d\n",
				       i,ce->flag,ce->akey[0],ce->akey[1],ce->ha_next,ce->ns_datp);
			}
			break;
		case 's':
		case 'r':
		case 'd':
			printf("Enter key0 ==>");
			gets(buf);
			key[0] = atoi(buf);
			printf("Enter key1 ==>");
			gets(buf);
			key[1] = atoi(buf);
			if (c == 's') {
				printf("Enter data ==>");
				gets(buf);
				ha->ha_nextp = (int *)atoi(buf);
				ret = akxshasl2s(ha,key);
			}
			else if (c == 'r') {
				ret = akxshasl2r(ha,key);
				if (ret>0) printf("data=%d\n",ha->ha_nextp);
			}
			else ret = akxshasl2d(ha,key);
			printf("ret=%d\n",ret);
			break;
		case 'k':
			for (i=0;i<max;i++) {
				ha->ha_hix = i + 1;
				ret=akxshasl2k(ha,key);
				printf("i=%d ret=%d\n",i,ret);
				if (ret>0) printf("     key=%d,%d data=%d\n",key[0],key[1],ha->ha_nextp);
			}
			break;
		case 'e':
			exit(0);
		}
	}
}
