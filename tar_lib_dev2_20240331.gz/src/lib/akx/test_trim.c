static    char    sccsid[]="%Z% %M% %I% %E% %U%";
/*
	cc -g -DLINUX -I../include test_trim.c libakx.a -o testTrim
*/
#include "akxcommon.h"
main()
{
	char buf[256],wd[256],pat[256];
	int n,opt,len,ret;

	for (;;) {
		printf("Enter opt==>");
		gets(buf);
		opt=atoi(buf);
		printf("Enter string==>");
		gets(buf);
		printf("buf=[%s] strlen(buf)=%d\n",buf,strlen(buf));
		printf("Enter len==>");
		gets(wd);
		len = atoi(wd);
		printf("Enter pat==>");
		gets(pat);
		ret = akxtstrim(opt,buf,len,pat);
		printf("ret=%d buf=[%s] strlen(buf)=%d\n",ret,buf,strlen(buf));
	}
}
